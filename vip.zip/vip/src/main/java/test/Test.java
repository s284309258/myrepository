package test;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.util.Sqlca;

public class Test {
	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://192.168.5.196:3369/webtest2018?characterEncoding=UTF-8&useUnicode=true&allowMultiQueries=true", "haohuiyi", "pwd!@#haohuiyi");
	}
	
	public static void main(String[] args) throws Exception  {
		
//		String sql = "select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,"
//				+ " (select tt.DpName from t_department tt where tt.DpId=t.DpId) as DpId,"
//				+ " t.DpId as Did,t.Post,t.State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"
//				+ " t.Telephone,t.Email,t.UserID as uid "
//				+ " from t_userinfo t where t.compId="+1299+" ";
//		
//		System.out.println(sql.substring(sql.lastIndexOf("from")));
//		
//		String mails = "s4545@163.com,45@48.com,";
//		mails.split(",");
//		System.out.println(12);
		String str = ",,sss@163.com,222@163.com";
		String[] ww = str.split(",");
		for(int kk =0;kk<ww.length;kk++)
		{
			
		}
		System.out.println(123);
		
		String regEx = "(\\d|[a-zA-Z])+";
		Pattern pattern = Pattern.compile(regEx);
		Matcher matcher = pattern.matcher("1231231456sdfsd");
		boolean rs = matcher.matches();
		System.out.println(rs);
		String ss="2018-12-25",dd="2018-12-26";
		if(dd.compareTo(ss)<0) {
			System.out.println(123);
		}
		
		String sss = "";
		
		System.out.println(encryptMD5("wangzheng"));
		System.out.println(encryptMD511("wangzheng"));
		//System.out.println(sss.substring(0, sss.length()-1));
		
//		List<Object> li = Sqlca.getArrayListFromObj("select  AdminTrueName from t_admininfo where 1=1 ", TConfinfo.class);	
	}
	
	
	
	
	
	
	
	
	public static String encryptMD5(String str) throws Exception {
    	/* try {
    	 // 生成一个MD5加密计算摘要
    	 MessageDigest md = MessageDigest.getInstance("MD5");
    	 // 计算md5函数
    	 md.update(str.getBytes());
    	 // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
    	 // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
    	 return new BigInteger(1, md.digest()).toString(16);
    	 } catch (Exception e) {
    		 throw new Exception("MD5加密出现错误");
    	 }*/
    	 String result = "";
         try {
             MessageDigest md = MessageDigest.getInstance("MD5");
             md.update(str.getBytes());
             byte b[] = md.digest();
             int i;
             StringBuffer buf = new StringBuffer("");
             for (int offset = 0; offset < b.length; offset++) {
                 i = b[offset];
                 if (i < 0)
                     i += 256;
                 if (i < 16)
                     buf.append("0");
                 buf.append(Integer.toHexString(i));
             }
             result = buf.toString();
             System.out.println("MD5(" + str + ",32) = " + result);
             System.out.println("MD5(" + str + ",16) = " + buf.toString().substring(8, 24));
         } catch (NoSuchAlgorithmException e) {
             //System.out.println(e);
         }
         return result;
    	
    	
    	
    }
	
	
	public static String encryptMD511(String str) throws Exception {
   	 try {
   	 // 生成一个MD5加密计算摘要
   	 MessageDigest md = MessageDigest.getInstance("MD5");
   	 // 计算md5函数
   	 md.update(str.getBytes());
   	 // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
   	 // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
   	 return new BigInteger(1, md.digest()).toString(16);
   	 } catch (Exception e) {
   		 throw new Exception("MD5加密出现错误");
   	 }
   }
	
}
