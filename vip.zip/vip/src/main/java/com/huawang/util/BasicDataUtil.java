package com.huawang.util;

public class BasicDataUtil {

	public static final String BIZ_STRING_ZERO_NUMBER = "0";
	public static final int BIZ_INT_ZERO_NUMBER = 0;

	public static final String BIZ_STRING_ONE_NUMBER = "1";
	public static final int BIZ_INT_ONE_NUMBER = 1;

	public static final String BIZ_STRING_TWO_NUMBER = "2";
	public static final int BIZ_INT_TWO_NUMBER = 2;

	public static final String BIZ_STRING_THREE_NUMBER = "3";
	public static final int BIZ_INT_THREE_NUMBER = 3;

	public static final String BIZ_STRING_FOUR_NUMBER = "4";
	public static final int BIZ_INT_FOUR_NUMBER = 4;

	public static final String BIZ_STRING_NUMBER = "5";
	public static final int BIZ_INT_FIVE_NUMBER = 5;

	public static final String BIZ_STRING_SEX_NUMBER = "6";
	public static final int BIZ_INT_SEX_NUMBER = 6;

	public static final String BIZ_STRING_SEVEN_NUMBER = "7";
	public static final int BIZ_INT_SEVEN_NUMBER = 7;

	public static final String BIZ_STRING_EIGHT_NUMBER = "8";
	public static final int BIZ_INT_EIGHT_NUMBER = 8;

	public static final String BIZ_STRING_NINE_NUMBER = "9";
	public static final int BIZ_INT_NINE_NUMBER = 9;

	public static final String BIZ_STRING1_PLANTYPE = "自产";
	public static final String BIZ_STRING2_PLANTYPE = "外购";
	public static final String BIZ_STRING3_PLANTYPE = "实施";
	public static final String BIZ_STRING4_PLANTYPE = "生产计划取消";
	public static final String BIZ_STRING5_PLANTYPE = "重新提交生产计划";
	public static final String BIZ_STRING_NULL = "";
	
	public static final String BIZ_STRING_BIZNAME = "生产计划提出";


	public static final String BIZ_STRING_OPERATION01 = "提出申请";
	public static final String BIZ_STRING_OPERATION02 = "审核通过";
	public static final String BIZ_STRING_OPERATION03 = "生成文件";
	public static final String BIZ_STRING_OPERATION04 = "生产计划审核";
	public static final String BIZ_STRING_OPERATION05 = "设备报废";
	public static final String BIZ_STRING_OPERATION06 = "生产工单";
	
	public static final String BIZ_STRING_PROCESSREVIEWERNAME = "最终审核";
	public static final String BIZ_STRING_PROCESSREVIEWERNAME1 = "zhangSan";
	public static final String BIZ_STRING_PROCESSREVIEWERNAME2 = "liSi";
	public static final String BIZ_STRING_PROCESSREVIEWERNAME3 = "wangWu";
	public static final String BIZ_STRING_PROCESSREVIEWERNAME4 = "zhaosi";
	public static final String BIZ_STRING_PROCESSREVIEWERNAME5 = "niuliu";
	
	public static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDQgEoj3z9JrdPNI23DbMQkl3gkGuDke7iBr5yrYyqolkTyxuBLWFwHNuGv4VKOj9fXg61QxpaJ/fxDBvMvmkBSRowHBloGFceVTx8wV/8u0DcjvTCu0IZ1zp6wjG6xBn5j66Sg/q+9hvaY2p7fkKmsvcW6VoNPgQHU1Cf01DLZmQIDAQAB+oXcINOiE3AsuZ4VJmwNZg9Y/7fY+OFRS2JAh5YMsrv2qyoGP+Z9ksre26NYR+Lt91B2lhdwJHLpQpziaANZm/ONb31fj/lwIDAQAB";  
	public static final String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBANCASiPfP0mt080jbcNsxCSXeCQa4OR7uIGvnKtjKqiWRPLG4EtYXAc24a/hUo6P19eDrVDGlon9/EMG8y+aQFJGjAcGWgYVx5VPHzBX/y7QNyO9MK7QhnXOnrCMbrEGfmPrpKD+r72G9pjant+Qqay9xbpWg0+BAdTUJ/TUMtmZAgMBAAECgYBSozY/Z4FW+31h5fPgK+DFu/8TGFAgXuTvCaJnz2Md9IkZTDejxT6cYWUr53toI5zhvz/XLw6FXNQ54KxMJq/s9PiZYUgq/PMrnyU4gBSTm5BmiWjdaGicVEZ1lofHjpkAchPNW/CzwxD8AeKI7QaObE+EkWbLAi6sa+nRdHKgrQJBAOwYLD2DncU15XCKS0RNzTrNohdBQcisOPHdtQO0CGZlxx3xjuU4WL6/EpdmbjTeYbOSDKCmY5vyVbYZdOWfEs8CQQDiFIwWpvW2WLxLVw3i2P55WmMMXuecwEzg++ae3Ht7nW0zNcWSsyvHh40sM8XqEzmWOzMY6JOePbkuVfWTc4cXAkBRzf5mQhiEoKwjVofF3v9hhKbJT/8vPR1uENgLtHHEqTdZFL3ihqeZUDNs6jz9bKCFy/E8KOsSueEg+6kZdwjZAkEAj2RW4fstd2VasDJb5ViaNqAEmJENOBej60L6KCJR07qqy0M8t+oaR2iLOtDvo6Jj8QxFQXQqRMCDVodAxjANKwJAL3KuaqA6kdy9RxdV3uP8nRXLY7C/1ZIK6U0pyZqKXEwpD+7Ar3hwwhPz9TeuoqjB/cCknZjw70BQFQ0/VUHW2g=="; 
	public static final String algorithm = "RSA";
	
	public static final String BIZ_STRING_SERVERTYPE01 = "级联服务器";
	public static final String BIZ_STRING_SERVERTYPE02 = "独立服务器";
	
	public static final String BIZ_STRING1_STR = "企业组织架构";
	
}
