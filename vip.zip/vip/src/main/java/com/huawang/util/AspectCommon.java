package com.huawang.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.huawang.interceptor.LoginInterceptor;
import com.huawang.pojo.meetingRoom.TAdmininfo;

@Aspect
@Component
public class AspectCommon {
	static Logger logger = LogManager.getLogger(LoginInterceptor.class.getName());
	
	private String requestPath = null ; // �����ַ  
    private String userName = null ; // �û���  
    private String result = null;
    private long startTimeMillis = 0; // ��ʼʱ��  
    private long endTimeMillis = 0; // ����ʱ��  
    
    @Before("execution(* com.huawang.controller..*.*(..))")
    public void doBeforeInServiceLayer(JoinPoint joinPoint) {  
        startTimeMillis = System.currentTimeMillis(); // ��¼������ʼִ�е�ʱ��  
    }
    @After("execution(* com.huawang.controller..*.*(..))")
    public void doAfterInServiceLayer(JoinPoint joinPoint) {  
        endTimeMillis = System.currentTimeMillis(); // ��¼����ִ����ɵ�ʱ��  
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();  
        ServletRequestAttributes sra = (ServletRequestAttributes)ra;  
        HttpServletRequest request = sra.getRequest(); 
        HttpServletResponse response = sra.getResponse();
        requestPath  = request.getRequestURI();
        result = joinPoint.toString();
        //��ӡ��¼�����󡢺�ʱ��־
        logger.info("\n aspectAdvice->loginUser:"+userName+";  requestPath:"+requestPath+";  costtime:"+(endTimeMillis-startTimeMillis)
    			+"ms;  access:"+result
    			);
        
    }
    
    /**
      * ��ֹ�û�����¼
     * @param request
     * @param response
     * @param user
     * @return ����true��ʾ���ڽ��ж���¼��false��ʾ������¼
     */
    public boolean preventLoginOnLogining(HttpServletRequest request) {
    	HttpSession session = request.getSession();
    	ServletContext application = session.getServletContext();
    	Map<String,String> loginMap = (Map<String,String>)application.getAttribute("loginMap");
    	if(loginMap == null) {
    		loginMap = new HashMap<String,String>();
    	}
    	
    	Object obj = session.getAttribute("USER_VIPSESSION");
        TAdmininfo user = null;
        if(obj!=null) {
      	   user = (TAdmininfo)obj;
      	    //��ֹ����¼��������û���¼��ǰ�û���������
        }
    	
    	for(String key : loginMap.keySet()) {
    		if(user!=null) {
    			if(user.getAdminName().equals(key)) {
    				//�û���¼����
    	    		if(session.getId().equals(loginMap.get(key))) {
    	    		
    	    		}else {
    	    			logger.info("\n aspectAdvice->other the same user has been down line");
    	    			return true;
    	    			//��ͬ�������¼,����ǰ���¼���û�
    	    		}
    			}
    		}
    	}
    	return false;
    	
    }
    
//    @Around("execution(* com.huawang.controller..*.*(..)) "
//    		+ "and !execution(* com.huawang.controller.UserLogin.LoginController.userLogin(..))")
//    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
//    	RequestAttributes ra = RequestContextHolder.getRequestAttributes();  
//    	
//        ServletRequestAttributes sra = (ServletRequestAttributes)ra;  
//        HttpServletRequest request = sra.getRequest(); 
//        HttpServletResponse response = sra.getResponse();
//        Object obj = request.getSession().getAttribute("USER_SESSION");
//        if(obj==null) {
////        	return request.getContextPath();        
//        	return new ModelAndView("index/loginhuaw");
////        	response.sendRedirect("redirect:index/loginhuaw");
//        }
//        
//        if(preventLoginOnLogining(request)) {
////        	return request.getContextPath();
//        	return new ModelAndView("index/loginhuaw");
//        }
//        
//        return pjp.proceed();
//    }
    
}
