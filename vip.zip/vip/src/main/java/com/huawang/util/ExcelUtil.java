package com.huawang.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.huawang.pojo.meetingRoom.TConfusersVO;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.result.Result;

public class ExcelUtil {
	
	
	//总行数
    private int totalRows = 0;  
    //总条数
    private int totalCells = 0; 
    //错误信息接收器
    private String errorMsg;
    //获取总行数
    public int getTotalRows()  { return totalRows;} 
    //获取总列数
    public int getTotalCells() {  return totalCells;} 
    //获取错误信息-暂时未用到暂时留着
    public String getErrorInfo() { return errorMsg; }
    
    //只允许有数字和字母regEx校验
    public String onlyNumAlpha = "(\\d|[a-zA-Z@_.*-])+";
    //手机格式校验
    public String phoneRex = "1[3-8]+\\d{9}";
    //座机格式校验
    public String phoneRex1 = "((0\\d{2,3})-)(\\d{7,8})(-(\\d{3,}))?";
    

	public static Workbook createWorkBook(List<Map<String, Object>> list,String []keys,String columnNames[]) {


		// 创建excel工作簿
		Workbook wb = new HSSFWorkbook();
		// 创建第一个sheet（页），并命名
		Sheet sheet = wb.createSheet(list.get(0).get("sheetName").toString());
		// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
		for(int i=0;i<keys.length;i++){
			sheet.setColumnWidth((short) i, (short) (35.7 * 150));
		}

		// 创建第一行
		Row row = sheet.createRow((short) 0);

		// 创建两种单元格格式
		CellStyle cs = wb.createCellStyle();
		CellStyle cs2 = wb.createCellStyle();
		
		Cell ztCell = row.createCell(0);

		// 创建两种字体
		Font f = wb.createFont();
		Font f2 = wb.createFont();

		// 创建第一种字体样式（用于列名）
		f.setFontHeightInPoints((short) 16);
		f.setColor(IndexedColors.BLACK.getIndex());
		f.setFontName("华文行楷"); 
		f.setColor(Font.COLOR_NORMAL); 
		cs.setFont(f);     
		ztCell.setCellStyle(cs);

		// 创建第二种字体样式（用于值）
		f2.setFontHeightInPoints((short) 16);
		f2.setColor(IndexedColors.BLACK.getIndex());
		cs2.setFont(f2);     
		ztCell.setCellStyle(cs2);

		//设置列名
		for(int i=0;i<columnNames.length;i++){
			Cell cell = row.createCell(i);
			cell.setCellValue(columnNames[i]);
			cell.setCellStyle(cs);
		}
		//设置每行每列的值
		for (short i = 1; i < list.size(); i++) {
			// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的
			// 创建一行，在页sheet上
			Row row1 = sheet.createRow((short) i);
			// 在row行上创建一个方格
			for(short j=0;j<keys.length;j++){
				Cell cell = row1.createCell(j);
				cell.setCellValue(list.get(i).get(keys[j]) == null?" ": list.get(i).get(keys[j]).toString());
				cell.setCellStyle(cs2);
			}
		}
		return wb;
	}
	
	
	
	
	
	public Result<Map<String,Integer>> getExcelInfo(MultipartFile Mfile,String username,List<TUserinfo> list,List<TUserinfo> errroUserList){
	      
		   String message ="";
		   
		   Result<Map<String,Integer>> result=null;
	      //把spring文件上传的MultipartFile转换成CommonsMultipartFile类型
	       CommonsMultipartFile cf= (CommonsMultipartFile)Mfile; //获取本地存储路径
	       File file = new  File("C:\\fileupload");
	       //创建一个目录 （它的路径名由当前 File 对象指定，包括任一必须的父路径。）
	       if (!file.exists()) file.mkdirs();
	       //新建一个文件
	       File file1 = new File("C:\\fileupload\\userList"+username+DateUtil.dateFormat(0) + ".xls"); 
	       //将上传的文件写入新建的文件中
	       try {
	           cf.getFileItem().write(file1);
	       } catch (Exception e) {
	           e.printStackTrace();
	       }
	       
	       //初始化输入流
	       FileInputStream is = null;
	       Workbook wb = null;
	       try{
	          //根据新建的文件实例化输入流
	          is = new FileInputStream(file1);
	          //根据excel里面的内容读取客户信息
	          
	          //当excel是2003时
//	          wb = new HSSFWorkbook(is);
	          //当excel是2007时
	          wb = new XSSFWorkbook(is);
	          
	          //读取Excel里面客户的信息
	          result = readExcelValue(wb,list,errroUserList);
	          is.close();
	      }catch(Exception e){
	          e.printStackTrace();
	      } finally{
	          if(is !=null)
	          {
	              try{
	                  is.close();
	              }catch(IOException e){
	                  is = null;    
	                  e.printStackTrace();  
	              }
	          }
	      }
	      return result;
	  }
	
	
	/**
	   * 读取Excel里面参会人员的信息
	   * @param wb
	   * @return
	   */
	  private Result<Map<String,Integer>> readConfuersExcelValue(Workbook wb,List<TConfusersVO> List,List<TConfusersVO> errroUserList)
	  { 
		  String message = "success";
		  Result<Map<String,Integer>> result=Result.success();
	      //得到第一个shell  
	       Sheet sheet=wb.getSheetAt(0);
	       
	      //得到Excel的行数
	       this.totalRows=sheet.getPhysicalNumberOfRows();
	       
	      //得到Excel的列数(前提是有行数)
	       if(totalRows>=1 && sheet.getRow(0) != null){//判断行数大于一，并且第一行必须有标题（这里有bug若文件第一行没值就完了）
	            this.totalCells=sheet.getRow(0).getPhysicalNumberOfCells();
	       }else{
	           return null;
	       }
	       
	      //循环Excel行数,从第二行开始。标题不入库
	       for(int r=1;r<totalRows;r++){
	           Row row = sheet.getRow(r);
	           boolean errorUserFlag=true;
	           if (row == null) continue;
	           TConfusersVO user = new TConfusersVO();
	           //循环Excel的列
	           for(int c = 0; c <this.totalCells; c++){ 
	               Cell cell = row.getCell(c);
	               if(cell==null&&c ==0)
            	   {
            		   user.setRemark("用户账号不能为空");
            		   errorUserFlag=false;
            		   
            	   }
	               if (null != cell){
	            	   cell.setCellType(cell.getCellType().STRING);
	            	   
	                   if(c==0){
	                	   user.UserName = getValue(cell);
	                	   if("".equals(user.UserName) || user.UserName==null)
	                	   {
	                		   user.setRemark("用户账号不能为空");
	                		   errorUserFlag=false;
	                		   
	                	   }
		                	
	                   }else if(c==1){//是否管理员（用户状态）
	                	   user.UserRight = getValue(cell);
	                	   if("".equals(user.UserRight) || user.UserRight==null)
	                	   {
	                		   user.setRemark("用户名称不能为空");
		                		errorUserFlag=false;
	                	   }
	                	   if(!"是".equals(user.UserRight.trim()) && !"否".equals(user.UserRight.trim()))
		                	{
	                		   user.setRemark("是否管理员只能填：是或者否 ");
		                		errorUserFlag=false;
		                	}
	                }
	               }
	           
	        } 
	           
           if(errorUserFlag) {
	        	 //添加无误的用户对象到集合中
		           List.add(user);
	           }else {
	        	 //添加有误的用户对象到集合中
	        	   errroUserList.add(user);
	        }
           
	     }
	       return result;
	  }
	
	
	/**
	 * 读取参会人员excel
	 * @param Mfile
	 * @param username
	 * @param list
	 * @param errroUserList
	 * @return
	 */
	public Result<Map<String,Integer>> getExcelConfuersInfo(MultipartFile Mfile,String username,List<TConfusersVO> list,List<TConfusersVO> errroUserList){
	      
		   String message ="";
		   
		   Result<Map<String,Integer>> result=null;
	      //把spring文件上传的MultipartFile转换成CommonsMultipartFile类型
	       CommonsMultipartFile cf= (CommonsMultipartFile)Mfile; //获取本地存储路径
	       File file = new  File("C:\\fileupload");
	       //创建一个目录 （它的路径名由当前 File 对象指定，包括任一必须的父路径。）
	       if (!file.exists()) file.mkdirs();
	       //新建一个文件
	       File file1 = new File("C:\\fileupload\\userList"+username+DateUtil.dateFormat(0) + ".xls"); 
	       //将上传的文件写入新建的文件中
	       try {
	           cf.getFileItem().write(file1);
	       } catch (Exception e) {
	           e.printStackTrace();
	       }
	       
	       //初始化输入流
	       FileInputStream is = null;
	       Workbook wb = null;
	       try{
	          //根据新建的文件实例化输入流
	          is = new FileInputStream(file1);
	          //根据excel里面的内容读取客户信息
	          
	          //当excel是2003时
//	          wb = new HSSFWorkbook(is);
	          //当excel是2007时
	          wb = new XSSFWorkbook(is);
	          
	          //读取Excel里面客户的信息
	          result = readConfuersExcelValue(wb,list,errroUserList);
	          is.close();
	      }catch(Exception e){
	          e.printStackTrace();
	      } finally{
	          if(is !=null)
	          {
	              try{
	                  is.close();
	              }catch(IOException e){
	                  is = null;    
	                  e.printStackTrace();  
	              }
	          }
	      }
	      return result;
	  }
	
	
	/**
	   * 读取Excel里面客户的信息
	   * @param wb
	   * @return
	   */
	  private Result<Map<String,Integer>> readExcelValue(Workbook wb,List<TUserinfo> List,List<TUserinfo> errroUserList)
	  { 
		  String message = "success";
		  Result<Map<String,Integer>> result=Result.success();
	      //得到第一个shell  
	       Sheet sheet=wb.getSheetAt(0);
	       
	      //得到Excel的行数
	       this.totalRows=sheet.getPhysicalNumberOfRows();
	       
	      //得到Excel的列数(前提是有行数)
	       if(totalRows>=1 && sheet.getRow(0) != null){//判断行数大于一，并且第一行必须有标题（这里有bug若文件第一行没值就完了）
	            this.totalCells=sheet.getRow(0).getPhysicalNumberOfCells();
	       }else{
	           return null;
	       }
	       
	      //循环Excel行数,从第二行开始。标题不入库
	       for(int r=1;r<totalRows;r++){
	           Row row = sheet.getRow(r);
	           boolean errorUserFlag=true;
	           if (row == null) continue;
	           TUserinfo user = new TUserinfo();
	           //循环Excel的列
	           for(int c = 0; c <this.totalCells; c++){ 
	               Cell cell = row.getCell(c);
	               if (null != cell){
	            	   cell.setCellType(cell.getCellType().STRING);
	                   if(c==0){
	                	   user.UserName = getValue(cell);
	                	   if("".equals(user.UserName) || user.UserName==null)
	                	   {
//	                		   return "用户账号不能为空";
	                		   user.setRemark("用户账号不能为空");
	                		   errorUserFlag=false;
	                		   
	                	   }
		                	Pattern pattern = Pattern.compile(onlyNumAlpha);
		               		Matcher matcher = pattern.matcher(user.UserName);
		               		boolean rs = matcher.matches();
		                	if(!rs) 
		                	{
//		                		return "用户账号只允许输入数字和字母";
		                	}
		                	if(user.UserName.trim().length()<1 || user.UserName.trim().length()>32)
		                	{
//		                		return "用户账号长度需在1-32位之间";
		                		user.setRemark("用户账号长度需在1-32位之间");
		                		errorUserFlag=false;
		                	}
		                	
		                	
	                   }else if(c==1){
	                	   user.DisplayName = getValue(cell);
	                	   if("".equals(user.DisplayName) || user.DisplayName==null)
	                	   {
//	                		   return "用户名称不能为空";
	                		   user.setRemark("用户名称不能为空");
		                		errorUserFlag=false;
	                	   }
	                	   if(user.DisplayName.trim().length()<1 || user.DisplayName.trim().length()>26)
		                	{
//		                		return "用户名称长度需在1-26位之间";
	                		   user.setRemark("用户名称长度需在1-26位之间");
		                		errorUserFlag=false;
		                	}
	                   }else if(c==2){
	                	   user.UserPassword = getValue(cell);
	                	   if("".equals(user.UserPassword) || user.UserPassword==null)
	                	   {
//	                		   return "用户密码不能为空";
	                		   user.setRemark("用户密码不能为空");
		                		errorUserFlag=false;
	                	   }
	                	   Pattern pattern = Pattern.compile(onlyNumAlpha);
		               		Matcher matcher = pattern.matcher(user.UserPassword);
		               		boolean rs = matcher.matches();
		                	if(!rs) 
		                	{
//		                		return "用户密码只允许输入数字和字母和@_.*-字符";
		                		 user.setRemark("用户密码只允许输入数字和字母和@_.*-字符");
			                		errorUserFlag=false;
		                	}
	                	   if(user.UserPassword.trim().length()<1 || user.UserPassword.trim().length()>18)
		                	{
//		                		return "用户密码长度需在1-18位之间";
	                		   user.setRemark("用户密码长度需在1-18位之间");
		                		errorUserFlag=false;
		                	}
	                   }else if(c==3) {
	                	   String sex = getValue(cell);
	                	   if("0".equals(sex) || "1".equals(sex)) {
	                		   user.UserSex =  Integer.parseInt(sex);
	                	   }
	                   }else if(c==4) {
	                	   String dpid = getValue(cell);
	                	   if(dpid!=null && !"".equals(dpid)) {
	                		   user.DpId = Integer.parseInt(dpid);
	                	   }
	                   }else if(c==5) {
	                	   user.Post = getValue(cell);
	                   }else if(c==6) {
	                	   String ustate = getValue(cell);
	                	   if("1".equals(ustate) || "0".equals(ustate)) {
	                		   user.Status = getValue(cell);
	                	   }
	                   }else if(c==7) {
	                	   String utype = getValue(cell);
	                	   if("2".equals(utype) || "".equals(utype)) {
	                		   user.UserType = utype;
	                	   }
	                   }
	                   else if(c==8) {
	                	   user.Telephone = getValue(cell);
	                   }
	                   else if(c==9) {
	                	   user.Email = getValue(cell);
	                   }else if(c==10) {
	                	   if(cell.getStringCellValue()!=null && !"".equals(cell.getStringCellValue())) 
	                	   {
	                		   if(cell.getStringCellValue().contains("-")) {
	                			   user.CreateTime = cell.getStringCellValue();
	                		   }
	                		   else
	                		   {
	                			   Calendar calendar = new GregorianCalendar(1900,0,-1);  
			                	   Date d = calendar.getTime();  
			                	   Date dd = DateUtils.addDays(d,Integer.valueOf(cell.getStringCellValue()));  
			                	   DateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			                	   String newdate = formater.format(dd);
			                	   user.CreateTime = newdate;
	                		   }
	                	   }
	                	   
	                   }else if(c==11) {
	                	   if(cell.getStringCellValue()!=null && !"".equals(cell.getStringCellValue())) 
	                	   {
	                		   if(cell.getStringCellValue().contains("-")) {
	                			   user.EndTime = cell.getStringCellValue();
	                		   }
	                		   else
	                		   {
	                			   Calendar calendar = new GregorianCalendar(1900,0,-1);  
			                	   Date d = calendar.getTime();  
			                	   Date dd = DateUtils.addDays(d,Integer.valueOf(cell.getStringCellValue()));  
			                	   DateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			                	   String newdate = formater.format(dd);
			                	   user.EndTime = newdate;
	                		   }
	                	   }
//	                	   user.EndTime =cell.getStringCellValue();
	                   }
	               }
	           }
	           if(errorUserFlag) {
	        	 //添加无误的用户对象到集合中
		           List.add(user);
	           }else {
	        	 //添加有误的用户对象到集合中
	        	   errroUserList.add(user);
	           }
	          
	       }
	       
	       return result;
	  }
	  
	  
	  
	  /**
	   * 得到Excel表中的值
	   * 
	   * @param cell
	   *            Excel中的每一个格子
	   * @return Excel中每一个格子中的值
	   */
	  private String getValue(Cell cell) {
	      if (cell.getCellType() == cell.getCellType().BOOLEAN) {
	          // 返回布尔类型的值
	          return String.valueOf(cell.getBooleanCellValue());
	      } else if (cell.getCellType() == cell.getCellType().NUMERIC) {
	          // 返回数值类型的值
	          return String.valueOf(cell.getNumericCellValue());
	      } else {
	          // 返回字符串类型的值
	          return String.valueOf(cell.getStringCellValue());
	      }
	  }

}
	


