package com.huawang.util;

import javax.servlet.ServletContext;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.ServletContextAware;


public class HWApplicationContextUtil implements ApplicationContextAware,ServletContextAware{

	public static ApplicationContext context;
	public static ServletContext servletcontext;
	
	
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		context = applicationContext;
		System.out.println(context);
	}

	public void setServletContext(ServletContext servletContext) {
		
		servletcontext = servletContext;
		System.out.println(servletcontext);
	}

}
