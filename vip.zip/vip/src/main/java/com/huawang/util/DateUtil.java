package com.huawang.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	long time = System.currentTimeMillis();
	String t = String.valueOf(time/1000); 
	String date=null;
	public String getDate(){
		date=timeStamp2Date(t, "yyyy-MM-dd HH:mm:ss");
		  return date;
	}
	
	public  String timeStamp2Date(String seconds,String format) {  
        if(seconds == null || seconds.isEmpty() || seconds.equals("null")){  
             return "";  
         }  
        if(format == null || format.isEmpty()){
             format = "yyyy-MM-dd HH:mm:ss";
         }   
         SimpleDateFormat sdf = new SimpleDateFormat(format);  
         return sdf.format(new Date(Long.valueOf(seconds+"000")));  
     }
	
	/***
	 * 日期月份加减N个月
	 * 
	 * @param datetime
	  * 日期(2014-11-11)
	 * @return 2014-10-10
	 */
	public static String dateFormat(int jj) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cl = Calendar.getInstance();
		
		cl.add(Calendar.MONTH, jj);
		String strdate = sdf.format(cl.getTime());
		return strdate;
	}
	
	/***
	 * 日期年月日时分秒格式
	 * 
	 * 日期(2014-11-11 00:00:00)
	 * @return 2014-10-10 00:00:00
	 */
	public static String dateFormat() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cl = Calendar.getInstance();
		
		String strdate = sdf.format(cl.getTime());
		return strdate;
	}
	
	/**
	 *  日期年月日时分秒格式
	 * @param date
	 * @return 2014-10-10 00:00:00
	 */
	public static String dateFormat(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}
	
	
	/***
	 * 日期月份加减N天
	 * 
	 * @param nday 加减n天
	 * @param xx 任意数字(0)，重载用
	 * 日期(2014-11-11)
	 * @return 2014-10-10
	 */
	public static String dateFormat(int nday,int xx) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cl = Calendar.getInstance();
		cl.add(Calendar.DAY_OF_MONTH, nday);
		String strdate = sdf.format(cl.getTime());
		return strdate;
	}
}
