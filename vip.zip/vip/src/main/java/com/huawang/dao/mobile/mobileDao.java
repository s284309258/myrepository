package com.huawang.dao.mobile;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.inter.TCompinfoVo;
import com.huawang.pojo.inter.TUser;
import com.huawang.pojo.meetingRoom.TConfinfo;

public interface mobileDao {
	
	//根据会议id查询会议信息
	public TConfinfo selectMeetingInfo(@Param("confId")Integer confId)throws Exception;
	//根据用户id查询用户名称
	public String selectUserDisplayNameToUserId(@Param("userId")Integer userId)throws Exception;
	//根据手机号查询组织信息
	public TCompinfoVo selectCompInfo(@Param("telePhone")String telePhone)throws Exception;
	//退出组织
	public Integer signOutOrgan(@Param("telePhone")String telePhone)throws Exception;
	//根据用户id查询用户名称和企业名称
	public TUser selectOrganInfoByUserId(@Param("userId")Integer userId)throws Exception;
	
}
