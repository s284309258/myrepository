package com.huawang.dao.company;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.company.DeviceRecordVO;
import com.huawang.pojo.company.DeviceVO;
import com.huawang.pojo.result.Page;

public interface DeviceDao {
	/**
	 * 获取设备列表
	 * @param compId
	 * @return
	 */
	public List<Map<String,Object>> getDeviceList(@Param("compId")Integer compId,@Param("state")String state,@Param("deviceId")String deviceId,@Param("page") Page page) ;
	/**
	 * 获取设备总数
	 * @param compId
	 * @return
	 */
	public int getDeviceListCount(@Param("compId")Integer compId,@Param("state")String state,@Param("deviceId")String deviceId) ;
	/**
	 * 解绑设备
	 * @param deviceId
	 * @return
	 */
	public int untieDevice(String deviceId);
	/**
	 * 操作设备记录
	 * @param deviceRecordVO
	 * @return
	 */
	public int addDeviceRecord(@Param("deviceRecordVO")DeviceRecordVO deviceRecordVO);
	/**
	 * 删除设备
	 * @param deviceId
	 * @return
	 */
	public int removeDevice(String deviceId);
	/**
	 * 新增设备
	 * @param deviceId
	 * @return
	 */
	public int addDevice(@Param("deviceVO")DeviceVO deviceVO);
	
	public int getDeviceInfo(String deviceId);
	public int getDeviceCountBydeviceId(String deviceId);
	/**
	 * 更新设备
	 * @param deviceVO
	 * @return
	 */
	public int updateDevice(@Param("deviceVO")DeviceVO deviceVO);
	
}
