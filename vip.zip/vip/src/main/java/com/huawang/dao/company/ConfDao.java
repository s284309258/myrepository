package com.huawang.dao.company;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.company.LogConfVOExtend;
import com.huawang.pojo.result.Page;

public interface ConfDao {
	public List<LogConfVOExtend> getLogConfList(@Param("compID") int compID,@Param("sellType") String sellType,@Param("page") Page page);
	public Integer getLogConfListCount(@Param("compID") int compID,@Param("sellType") String sellType);
}
