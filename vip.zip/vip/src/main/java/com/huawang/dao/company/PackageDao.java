package com.huawang.dao.company;

import java.util.List;
import java.util.Map;

import com.huawang.pojo.company.ProductVO;

public interface PackageDao {
	/**
	 * 获取套餐列表信息
	 * @param productID
	 * @return
	 */
	public List<Map<String,Object>> getPackageList(Integer productId) ;
}
