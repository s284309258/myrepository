package com.huawang.dao.organization;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.organization.UserRequestVO;
import com.huawang.pojo.organization.UserVO;
import com.huawang.pojo.organization.UserVOExtend;
import com.huawang.pojo.result.Page;

public interface UserDao {
	/**
	 * 
	 * @param userId
	 * @return
	 */
	public UserVOExtend getUserInfo(int userId);
	/**
	 * 代办列表
	 * @param compId
	 * @param userStatus
	 * @param userPhone
	 * @param page
	 * @return
	 */
	public List<Map<String,Object>> getUserRequest(@Param("compId") int compId,@Param("userStatus")Integer userStatus,@Param("userPhone")String userPhone,@Param("page") Page page);
	/**
	 * 代办列表总数
	 * @param compId
	 * @param userStatus
	 * @param userPhone
	 * @return
	 */
	public int getUserRequestCount(@Param("compId") int compId,@Param("userStatus")Integer userStatus,@Param("userPhone")String userPhone);
	/**
	 * 审核历史记录
	 * @param compId
	 * @param userStatus
	 * @param userPhone
	 * @param page
	 * @return
	 */
	public List<Map<String,Object>> getUserRequestHistory(@Param("compId") int compId,@Param("userStatus")Integer userStatus,@Param("userPhone")String userPhone,@Param("page") Page page);
	/**
	 * 审核历史记录总数
	 * @param compId
	 * @param userStatus
	 * @param userPhone
	 * @return
	 */
	public int getUserRequestHistoryCount(@Param("compId") int compId,@Param("userStatus")Integer userStatus,@Param("userPhone")String userPhone);
	/**
	 * 单人审核通过
	 * @param userId
	 * @param userInfoId
	 * @param userStatus
	 * @return
	 */
	public int agreeUserRequest(@Param("userId") int userId,@Param("userInfoId") int userInfoId,@Param("userStatus")Integer userStatus);
	/**
	 * 单人审核拒绝
	 * @param userId
	 * @param userStatus
	 * @return
	 */
	public int rejectUserRequest(@Param("userId") int userId,@Param("userStatus")Integer userStatus);
	/**
	 * 获取t_user_request单条记录
	 * @param userId
	 * @return
	 */
	public UserRequestVO getUserRequestInfo(@Param("userId")int userId);
	/**
	 * 获取t_user_request多条记录
	 * @param userIdList
	 * @return
	 */
	public List<UserRequestVO> getUserBatchRequestInfo(@Param("userIdList")List<Integer> userIdList);
	/**
	 * 添加单个用户到t_userInfo表
	 * @param userVO
	 * @return
	 */
	public int addUserToCompany(@Param("userVOExtend")UserVOExtend userVOExtend);
//	public int addBatchUserToCompany(@Param("userVOList")List<UserVOExtend> userVOList);
	/**
	 * 批量拒绝
	 * @param userIdList
	 * @param userStatus
	 * @return
	 */
	public int rejectBatchUserRequest(@Param("userIdList")List<Integer> userIdList, @Param("userStatus")int userStatus);
	
	/**
	 * 用户名唯一校验
	 * @param userIdList
	 * @param userStatus
	 * @return
	 */
	public int uniqueUserNameCheck(@Param("userName")String userName);
	
	/**
	 * 查询错误用户
	 * @return
	 */
	public List<Map<String,Object>> getErrorUserInfoList();
	
	/**
	 * 根据用户名获取用户ID
	 * @param userName
	 * @return
	 */
	public Integer getUserIdByUserName(@Param("userName")String userName);
	
	/**
	 * 批量同意
	 * @param userId
	 * @param userInfoIdList
	 * @param userStatus
	 * @return
	 */
	//public int agreeBatchUserRequest(@Param("userId")int userId, @Param("userInfoIdList")List<Integer> userInfoIdList, @Param("userStatus")int userStatus);
}


