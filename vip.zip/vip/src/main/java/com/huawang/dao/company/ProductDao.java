package com.huawang.dao.company;

import com.huawang.pojo.company.ProductVO;

public interface ProductDao {
	
	public ProductVO getProductInfo(Integer productID) ;
}
