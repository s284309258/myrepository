package com.huawang.dao.api;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.inter.TCompinfoVo;
import com.huawang.pojo.inter.TConfinfoVo;
import com.huawang.pojo.inter.TDepatMentVo;
import com.huawang.pojo.inter.TUser;
import com.huawang.pojo.meetingRoom.TConfinfo;

public interface appDao {

			//校验手机号
			public TUser verificatUserPhone(@Param("mobile")String mobile) throws Exception;
			//增加验证码记录
			public Integer addPhoneCode(@Param("mobile")String mobile,@Param("code")String code,@Param("templateid")String templateid)throws Exception;
			//手机号验证码校验
			public boolean validatePhoneToCode(@Param("telePhone")String telePhone,@Param("code")String code,@Param("codeType")String codeType);
			//用户注册
			public Integer register(@Param("tUser")TUser tUser)throws Exception;
			//判断手机短信有效期
			public String validateMessage(@Param("telePhone")String telePhone)throws Exception;
			//判断用户是否已通过审核进行找回密码，如果未通过userStatus：0；通过userStatus：1
			public String selectUserStatus(@Param("telePhone")String telePhone)throws Exception;
			//根据用户id查询新用户状态
			public String selectNewUserStatus(@Param("uid")String uid)throws Exception;
			//修改待审核用户密码
			public Integer updateUserPassword(@Param("telePhone")String telePhone,@Param("userPassword")String userPassword)throws Exception;
			//忘记密码
			public Integer retrievePassword(@Param("telePhone")String telePhone,@Param("userPassword")String userPassword)throws Exception;
			//查询用户手机是否存在
			public Integer selectUserPhone(@Param("telePhone")String telePhone);
			//登录
			public String userLogin(@Param("tUser")TUser tUser)throws Exception;
			//未审核用户登录
			public String newUserLogin(@Param("tUser")TUser tUser,@Param("type")String type)throws Exception;
			//用户登录新增token数据
			public Integer addTokenToUserId(@Param("tUser")TUser tUser)throws Exception;
			//查询用户是否审核通过后用户
			public String selectUserTokenType(@Param("tUser")TUser tUser)throws Exception;
			//查询当前用户是否存在
			public Integer selectUserCount(@Param("tUser")TUser tUser)throws Exception;
			//查询当前用户id
			public Integer selectUserId(@Param("tUser")TUser tUser)throws Exception;
			//更新登录token
			public Integer updateUserToken(@Param("tUser")TUser tUser)throws Exception;
			//根据token更新id
			public Integer updateTokenToUserId(@Param("tUser")TUser tUser)throws Exception;
			//查询用户信息
			public TUser selectUserInfo(@Param("uid")String uid,@Param("token")String token)throws Exception;
			//查询APP扫码地址
			public String selectAppDomain();
			public TUser validateUserPassword(@Param("uid")String uid)throws Exception;
			//修改用户密码
			public TUser selectUserPassword(@Param("uid")String uid)throws Exception;
			//绑定用户手机号
			public Integer bindUserPhone(@Param("uid")String uid,@Param("telePhone")String telePhone)throws Exception;;
			//查询企业认证表是否存在数据
			public Integer selectCertToCustomer(@Param("uid")String uid,@Param("token")String token)throws Exception;
			//认证表添加企业数据
			public Integer addCertCustomerInfo(@Param("tUser")TUser tUser)throws Exception;
			//营业执照上传
			public Integer updateCustomerLicense(@Param("tUser")TUser tUser)throws Exception;
			//企业头像上传
			public Integer updateCustomCompHead(@Param("headImagePath")String headImagePath,@Param("compId")Integer compId)throws Exception;
			//用户头像上传
			public Integer updateUserHeadImage(@Param("tUser")TUser tUser)throws Exception;
			//新用户头像上传
			public Integer updateNewUserHeadImage(@Param("tUser")TUser tUser)throws Exception;
			//查询用户登录到当前距离的时间
			public String selectUserTime(@Param("uid")String uid,@Param("token")String token)throws Exception;
			//修改用户信息
			public Integer updateUserInfo(@Param("tUser")TUser tUser)throws Exception;
			//修改新用户名称
			public Integer updateNewDisplayName(@Param("displayName")String displayName,@Param("uid")Integer uid)throws Exception;
			//判断同一企业下用户名是否重复
			public Integer selectUserNameRepeat(@Param("tUser")TUser tUser)throws Exception;
			//删除用户
			public Integer delUser(@Param("userIds")Integer userIds)throws Exception;
			//添加企业
			public Integer addCustomer(@Param("tUser")TUser tUser)throws Exception;
			//查询注册用户信息
			public TUser selectNewUserInfo(@Param("uid")Integer uid)throws Exception;
			//查询企业账号是否重复
			public String selectCustomerCount(@Param("compName")String compName)throws Exception;
			//添加企业用户
			public Integer addUser(@Param("tUser")TUser tUser)throws Exception;
			//查询用户是否有加入企业
			public TUser selectUserToOragn(@Param("tUser")TUser tUser)throws Exception;
			//根据企业id查询是否存在该企业
			public Integer selectCompIdCount(@Param("compId")Integer compId)throws Exception;
			//加入组织
			public Integer joinOrgan(@Param("tUser")TUser tUser)throws Exception;
			//根据企业id查询企业信息
			public TCompinfoVo  selectCustomById(@Param("compId")Integer compId)throws Exception;
			//查询企业信息
			public TCompinfoVo  selectCustomInfo(@Param("tUser")TUser tUser)throws Exception;
			//未审核通过用户查询企业信息
			public TCompinfoVo selectCustomInfoByNewUser(@Param("tUser")TUser tUser)throws Exception;
			//修改企业信息
			public Integer editCustomer(@Param("tUser")TUser tUser)throws Exception;
			//企业管理员账户查询
			public List<TUser> selectIsSuperInfo(@Param("tUser")TUser tUser)throws Exception;
			//移除企业管理员
			public Integer removeIsSuper(@Param("userIds")String userIds,@Param("isSuper")String isSuper,@Param("dpId")Integer dpId)throws Exception;
			//查询用户是否超级管理员
			public Integer selectUserIsSuper(@Param("tUser")TUser tUser)throws Exception;
			//查询企业部门
			public List<TDepatMentVo>selectCustomerDeptMent(@Param("tUser")TUser tUser)throws Exception;
			//查询企业人数
			public Integer selectCustomerDeptMentCount(@Param("tUser")TUser tUser)throws Exception;
			//查询父部门下子部门
			public List<TDepatMentVo>selectParentDeptToDept(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//查询部门用户
			public List<TUser>selectDeptToUser(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//新增部门
			public Integer addDeptMent(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//查询企业id
			public Integer selectCompId(@Param("tUser")TUser tUser)throws Exception;
			//修改部门信息
			public Integer editDeptMent(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//查询用户是否属于同一公司
			public Integer selectUserToDept(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//删除企业部门
			public Integer delDeptMent(@Param("tUser")TUser tUser)throws Exception;
			//查询父部门下，是否存在子部门及用户
			public Integer selectParentMent(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//查询部门下是否存在用户
			public Integer selectDeptMent(@Param("depatMentVo")TDepatMentVo depatMentVo)throws Exception;
			//查询新用户列表
			public List<TUser>selectNewUserList(@Param("tUser")TUser tUser)throws Exception;
			//获取待审核用户id，查询用户信息
			public List<TUser>selectExamineUser(@Param("tUser")TUser tUser)throws Exception;
			//添加审核后用户
			public Integer addUserToUserInfo(@Param("tUser")TUser tUser)throws Exception;
			//更新登录用户token表中的状态
			public Integer updateTokenStatus(@Param("tUser")TUser tUser)throws Exception;
			//更新审核后的用户状态
			public Integer updateNewUserStatus(@Param("userId")String userId,@Param("userStatus")int userStatus,@Param("compId")int compId);
			//更新加入组织的用户状态
			public Integer updateUserStatus(@Param("tUser")TUser tUser);
			//拒绝用户加入
			public Integer refuseUserAdd(@Param("userId")int userId);
			//退出组织
			public Integer signOutOragan(@Param("tUser")TUser tUser)throws Exception;
			//更换用户部门
			public Integer exchangeUserDpId(@Param("dpId")Integer dpId,@Param("userId")Integer userId)throws Exception;
			//查询通讯录中用户手机 是否存在 企业
			public Integer selectPhoneToCustom(@Param("tUser")TUser tUser)throws Exception;
			//添加手机通讯录注册用户
			public Integer addPhoneToCustom(@Param("tUser")TUser tUser)throws Exception;
			//用户会议列表查询
			public List<TConfinfoVo>selectConfinfoSuperList(@Param("tUser")TUser tUser)throws Exception;
			public List<TConfinfoVo>selectConfinfoList(@Param("tUser")TUser tUser)throws Exception;
			//查询用户是否管理员
			public String selectUserIsManager(@Param("tUser")TUser tUser)throws Exception;
			//根据父部门id查询子部门
			public List<TUser>selectSonDeptToParent(@Param("tUser")TUser tUser)throws Exception;
			//根据部门id查询部门用户
			public List<TUser>selectDeptUser(@Param("userIds")String userIds)throws Exception;
			//分配参会人员
			public Integer distributAttendMeetUser(@Param("confId")int confId,@Param("userId")int userId,@Param("userRight")String userRight)throws Exception;
			//取消参会人
			public Integer delAttendMeetUser(@Param("confId")int confId,@Param("userId")int userId)throws Exception;
			//查询会议参会用户
			public List<TUser>selectAttendList(@Param("confId")Integer confId)throws Exception;
			//查询会议详情
			public TConfinfoVo selectMeetingDetail(@Param("confId")Integer confId)throws Exception;
			//查询会议室是否重名
			public  Integer selectMeetingIsReName(@Param("tConfinfo")TConfinfo tConfinfo)throws Exception;
			
	}













