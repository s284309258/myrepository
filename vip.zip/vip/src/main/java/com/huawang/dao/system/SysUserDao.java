package com.huawang.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.system.SysUser;

public interface SysUserDao {
	
	//验证是否存在该账号
	public SysUser checkUserName(String userName);
	
	//验证用户密码是否正确
	public SysUser checkUserNameAndPassword(@Param("userName") String userName,@Param("password") String password);
	
	//更新用户sessionid
	public void updateSessionId(@Param("userId") Integer userId,@Param("sessionId") String sessionId);
	
	//查找用户sessionid
	public String findSessionIdByUserId(Integer userId);
	
	//添加用户
	public void registerUser(SysUser sysUser);
	
	//查找全部用户
	public List<SysUser> findTotalUserList();
	
	//按部门ID查找用户
	public List<SysUser> findUserBydpmentId(Integer departmentId);
	
	//按ID修改密码
	public void changePasswordByid(SysUser sysUser);
	
	//按用户ID查找用户信息
	public SysUser findUserInfoById(Integer userId);
	
	//按用户ID修改用户信息
	public void editUserInfoById(SysUser sysUser);
}
