package com.huawang.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;


import com.huawang.pojo.system.AccessWareHouse;

public interface AccessWareHouseDao {

	//获取选择下拉表类型
	public List<AccessWareHouse> getSelectType();
	
	//获取选择下拉表状态
	public List<AccessWareHouse> getSelectStatus();
	
	//获取出入库单信息
	public List<AccessWareHouse> getAccessWareHouseInfo();
	
	//按条件筛选
	public List<AccessWareHouse> getInfoBySelect(@Param("type")Integer type,
			@Param("status")Integer status,
			@Param("startDate")String startDate,
			@Param("endDate")String endDate);
}
