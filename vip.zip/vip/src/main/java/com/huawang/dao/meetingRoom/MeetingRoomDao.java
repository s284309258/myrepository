package com.huawang.dao.meetingRoom;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.inter.TConfDissolution;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.pojo.meetingRoom.TLogConfDetail;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.result.Page;

public interface MeetingRoomDao {

		//查询参会列表
		public List<TConfinfo>getAttendMeetingMap(@Param("confinfo")TConfinfo confinfo,@Param("i")int i,@Param("rows")int rows);
		//参会总数
		public int getAttendMeetingMapCounts(@Param("confinfo")TConfinfo confinfo);
		//根据会议号查询会议室密码
		public TConfinfo getConfPwd(@Param("confId")Integer confId);
		//会议管理列表
		public List<TConfinfo>getMeetingManagerMap(@Param("confinfo")TConfinfo confinfo,@Param("i")int i,@Param("rows")int rows);
		public int getMeetingManagerMapCount(@Param("confinfo")TConfinfo confinfo);
		//进入新增会议室界面
		public int comeAddMeeting(@Param("confinfo")TConfinfo confinfo);
		//获取企业产品信息
		public TConfinfo getCompProduct(@Param("userName")String userName);
		public List<String> getPlan(@Param("confId")Integer confId);//根据会议id查询周期数
		
		//添加会议室
		public int addMeeting(@Param("confinfo")TConfinfo confinfo,@Param("mcuIpId")Integer mcuIpId,@Param("productId")Integer productId);
		//根据id查询会议室信息
		public TConfinfo getMeetingInfo(@Param("confId")Integer confId);
		//根据客户id查询最大用户数
		public TCompinfo selectMaxUserCount(@Param("compId")Integer compId);
		//根据企业id查询预约会议室信息
		public List<TConfinfo> selectConfinfoList(@Param("compId")Integer compId,@Param("isReservedConf") Integer isReservedConf,@Param("startTime")java.util.Date startt,
				@Param("endTime")java.util.Date endtt,@Param("confId")Integer confId);
		public int selectConfinfoCount(@Param("compId")Integer compId,@Param("isReservedConf") Integer isReservedConf,@Param("startTime")java.util.Date startTime,@Param("endTime")java.util.Date endTime);
		
		//根据会议id查询分配用户
		public List<String>selectDistributeUser(@Param("confId")Integer confId);
		public int delDistribute(@Param("confId")Integer confId,@Param("userId")Integer userId);
		//根据confid查询分配后用户confuser表
		public List<TConfinfo> selectConfuseList(@Param("userIdList")List userIdList);
		//查询分配人员中是否重复
		public int selectUserInfoDistri(@Param("confId")Integer confId,@Param("userID")Integer userID);
		
		//根据userID查询分配的会议室
		public List<String> selectUserToConfId(@Param("userId")Integer userId);
		
		public TCompinfo selectMcuIpId(@Param("compId")Integer compId);
		//保存修改会议信息
		public int saveMeeting(@Param("confinfo")TConfinfo confinfo);
		//修改查询会议名称是否重复
		public int query_confId(@Param("confinfo")TConfinfo confinfo);
		//根据会议id查询企业id
		public TConfinfo selectconfIdBycompId(@Param("confId")Integer confId);
		//根据部门id查询部门用户是否分配了参会
		public List<TUserinfo>selectUserList(@Param("confinfo")TConfinfo confinfo,@Param("dpId")Integer dpId,@Param("attend")Integer attend,@Param("compId")Integer compId);
		public int selectUserCount(@Param("confinfo")TConfinfo confinfo,@Param("dpId")Integer dpId,@Param("attend")Integer attend,@Param("compId")Integer compId);
		//更新参会人状态
		public int updateUserStatus(@Param("attend")Integer attend,@Param("userID")Integer userID);
		//添加参会人员
		public int addAttendMeetingUser(@Param("confId")Integer confId,@Param("userID")Integer userID,@Param("userRight")String userRight);
		//根据会议id查询用户id
		public List<String> selectUserIdByConfId(@Param("confId")Integer confId);
		
		//根据企业id查询会议记录
		public List<TConfinfo>getMeetStatistics(@Param("confinfo")TConfinfo confinfo,@Param("i")int i,@Param("rows")int rows);
		public int getMeetStatisticsCount(@Param("confinfo")TConfinfo confinfo);
		//查看会议详情
		public List<TConfinfo>getMeetStatisDetail(@Param("confinfo")TConfinfo confinfo,@Param("i")int i,@Param("rows")int rows);
		public int getMeetStatisCount(@Param("confinfo")TConfinfo confinfo);
		//查询会议室状态
		public TConfinfo selectMeetStatus(@Param("confId")Integer confId);
		//删除会议室
		public int delMeetDao(@Param("confId")Integer confId);
		//查询用户的历史参会列表
		public List<TLogConfDetail> getMyMeetingHistory(@Param("userId")int userId,@Param("page")Page page);
		//查询用户的历史参会列表总记录数
		public int getMyMeetingHistoryCount(@Param("userId")int userId);
		//查询用户的会议权限列表  TODO
		public List<Map<String,Object>> getMyMeetingAuthority(@Param("userId")int userId,@Param("page")Page page);
		//查询用户的会议权限列表总记录数
		public int getMyMeetingAuthorityCount(@Param("userId")int userId);
		//查询需解散会议室
		public List<TConfDissolution>selectDissolutionList()throws Exception;
		
		//根据compId统计单个会议室的总参会人数（去重）和总登陆次数
		public List<Map<String,Object>> getPerMeetStatistics(@Param("compID")Integer compID,@Param("confName")String confName, @Param("confId")Integer confId, @Param("curUserIsSuper")String curUserIsSuper,@Param("curUserDpId") Integer curUserDpId, @Param("page")Page page);
		public int getPerMeetStatisticsCount(@Param("compID")Integer compID, @Param("confName")String confName, @Param("confId")Integer confId, @Param("curUserIsSuper")String curUserIsSuper,@Param("curUserDpId") Integer curUserDpId);
		
		
		}













