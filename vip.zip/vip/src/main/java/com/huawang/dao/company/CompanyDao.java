package com.huawang.dao.company;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.company.CompinfoVOExtend;

public interface CompanyDao {
	
	public CompinfoVOExtend getCompInfo(@Param("compId")Integer compId) ;
	
}
