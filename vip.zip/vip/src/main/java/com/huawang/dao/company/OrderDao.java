package com.huawang.dao.company;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.company.OrderVOExtend;
import com.huawang.pojo.result.Page;

public interface OrderDao {
	public List<OrderVOExtend> getOrderList(@Param("compID") String compID,@Param("osellType") String osellType,@Param("page") Page page);
	public Integer getOrderListCount(@Param("compID") String compID,@Param("osellType") String osellType);
	
	public List<OrderVOExtend> getTimeOrderList(@Param("compID") String compID,@Param("osellType") String osellType,@Param("page") Page page);
	public Integer getTimeOrderListCount(@Param("compID") String compID,@Param("osellType") String osellType);
	
	
	
}
