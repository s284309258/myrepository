package com.huawang.dao.system;

import com.huawang.pojo.system.SysField;

public interface SysDao {
	
	public SysField findField();
}
