package com.huawang.pojo.inter;

import java.io.File;

import org.springframework.format.annotation.DateTimeFormat;

public class TCompinfoVo {

	public Integer compId ;
	public String compName;
	public String compPassword;
	public String compTrueName;
	public Integer maxUserCount;
	public String lianxr;
	public String lianxrtel;
	
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String createDate;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String endDate;
	
	public String adminName;
	public String belongAgent;
	public Integer compStyle;
	public String defualtServer;
	
	private String taxNumber;//单位税号
	private String businessLicense;//营业执照
	private File businessFile;//营业执照文件
	private Integer authStatus;//营业执照审核状态0未通过 1、通过
	private String mail;
	private String address;
	private String headImagePath;//头像
	private Integer personSum;
	private String invoiceTitle;
	private String sellType;
	private String compInfoPerce;//企业信息完整度 
	
	public Integer getCompId() {
		return compId;
	}
	public void setCompId(Integer compId) {
		this.compId = compId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCompPassword() {
		return compPassword;
	}
	public void setCompPassword(String compPassword) {
		this.compPassword = compPassword;
	}
	public String getCompTrueName() {
		return compTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		this.compTrueName = compTrueName;
	}
	public Integer getMaxUserCount() {
		return maxUserCount;
	}
	public void setMaxUserCount(Integer maxUserCount) {
		this.maxUserCount = maxUserCount;
	}
	public String getLianxr() {
		return lianxr;
	}
	public void setLianxr(String lianxr) {
		this.lianxr = lianxr;
	}
	public String getLianxrtel() {
		return lianxrtel;
	}
	public void setLianxrtel(String lianxrtel) {
		this.lianxrtel = lianxrtel;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getBelongAgent() {
		return belongAgent;
	}
	public void setBelongAgent(String belongAgent) {
		this.belongAgent = belongAgent;
	}
	public Integer getCompStyle() {
		return compStyle;
	}
	public void setCompStyle(Integer compStyle) {
		this.compStyle = compStyle;
	}
	public String getDefualtServer() {
		return defualtServer;
	}
	public void setDefualtServer(String defualtServer) {
		this.defualtServer = defualtServer;
	}
	public String getTaxNumber() {
		return taxNumber;
	}
	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}
	public String getBusinessLicense() {
		return businessLicense;
	}
	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}
	public File getBusinessFile() {
		return businessFile;
	}
	public void setBusinessFile(File businessFile) {
		this.businessFile = businessFile;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHeadImagePath() {
		return headImagePath;
	}
	public void setHeadImagePath(String headImagePath) {
		this.headImagePath = headImagePath;
	}
	public Integer getPersonSum() {
		return personSum;
	}
	public void setPersonSum(Integer personSum) {
		this.personSum = personSum;
	}
	public String getInvoiceTitle() {
		return invoiceTitle;
	}
	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}
	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	public String getCompInfoPerce() {
		return compInfoPerce;
	}
	public void setCompInfoPerce(String compInfoPerce) {
		this.compInfoPerce = compInfoPerce;
	}
	public Integer getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(Integer authStatus) {
		this.authStatus = authStatus;
	}
}
