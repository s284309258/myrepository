package com.huawang.pojo.company;

import java.util.Date;

public class LogConfVOExtend extends LogConfVO {
	private String ConfName; //会议名
	private Integer confTimeCount; //会议时长
	public LogConfVOExtend() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LogConfVOExtend(Integer logConfID, Integer confID, Integer maxCount, Date startTime, Date endTime,
			String codeno, Integer personMinute, String sellType) {
		super(logConfID, confID, maxCount, startTime, endTime, codeno, personMinute, sellType);
		// TODO Auto-generated constructor stub
	}
	public LogConfVOExtend(String confName, Integer confTimeCount) {
		super();
		ConfName = confName;
		this.confTimeCount = confTimeCount;
	}
	public String getConfName() {
		return ConfName;
	}
	public void setConfName(String confName) {
		ConfName = confName;
	}
	public Integer getConfTimeCount() {
		return confTimeCount;
	}
	public void setConfTimeCount(Integer confTimeCount) {
		this.confTimeCount = confTimeCount;
	}
	@Override
	public String toString() {
		return "LogConfVOExtend [ConfName=" + ConfName + ", confTimeCount=" + confTimeCount + ", getLogConfID()="
				+ getLogConfID() + ", getConfID()=" + getConfID() + ", getMaxCount()=" + getMaxCount()
				+ ", getStartTime()=" + getStartTime() + ", getEndTime()=" + getEndTime() + ", getCodeno()="
				+ getCodeno() + ", getPersonMinute()=" + getPersonMinute() + ", getSellType()=" + getSellType()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}
	
	
	
	
}
