package com.huawang.pojo.meetingRoom;

public class TConfusersVO {
	public Integer ConfID;
	public Integer UserID;
	public String UserName;
	public String UserRight;
	public Integer UserPos;
	public Integer CsipId;
	public Integer MsipId;
	public String Remark;
	public TConfusersVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TConfusersVO(Integer confID, Integer userID, String userName, String userRight, Integer userPos,
			Integer csipId, Integer msipId, String remark) {
		super();
		ConfID = confID;
		UserID = userID;
		UserName = userName;
		UserRight = userRight;
		UserPos = userPos;
		CsipId = csipId;
		MsipId = msipId;
		Remark = remark;
	}
	public Integer getConfID() {
		return ConfID;
	}
	public void setConfID(Integer confID) {
		ConfID = confID;
	}
	public Integer getUserID() {
		return UserID;
	}
	public void setUserID(Integer userID) {
		UserID = userID;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserRight() {
		return UserRight;
	}
	public void setUserRight(String userRight) {
		UserRight = userRight;
	}
	public Integer getUserPos() {
		return UserPos;
	}
	public void setUserPos(Integer userPos) {
		UserPos = userPos;
	}
	public Integer getCsipId() {
		return CsipId;
	}
	public void setCsipId(Integer csipId) {
		CsipId = csipId;
	}
	public Integer getMsipId() {
		return MsipId;
	}
	public void setMsipId(Integer msipId) {
		MsipId = msipId;
	}
	public String getRemark() {
		return Remark;
	}
	public void setRemark(String remark) {
		Remark = remark;
	}
	@Override
	public String toString() {
		return "TConfusersVO [ConfID=" + ConfID + ", UserID=" + UserID + ", UserName=" + UserName + ", UserRight="
				+ UserRight + ", UserPos=" + UserPos + ", CsipId=" + CsipId + ", MsipId=" + MsipId + ", Remark="
				+ Remark + "]";
	}
	
	

	
}
