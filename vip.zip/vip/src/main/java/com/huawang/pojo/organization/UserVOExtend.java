package com.huawang.pojo.organization;

import java.util.Date;

public class UserVOExtend extends UserVO{
	private String DpName; //部门
	private Integer userRequestId;//t_user_request:userId
	public UserVOExtend() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserVOExtend(String codeno, Integer userID, String userName, String userPassword, String telUserName,
			String telUserPassword, String displayName, Integer userSex, String email, String telephone,
			Integer orderIndex, String userStatus, Integer dpId, String serverIP, String isSuper, Integer csId,
			Integer msId, Date createtime, Date endtime, Integer comGrade, String post, String state, String userType,
			String description, Integer attend, String isuse, String joinMode, String logo, Date registerTime,
			String applyDate, Integer compID, Integer adminID, String lastLoginTime) {
		super(codeno, userID, userName, userPassword, telUserName, telUserPassword, displayName, userSex, email, telephone,
				orderIndex, userStatus, dpId, serverIP, isSuper, csId, msId, createtime, endtime, comGrade, post, state,
				userType, description, attend, isuse, joinMode, logo, registerTime, applyDate, compID, adminID, lastLoginTime);
		// TODO Auto-generated constructor stub
	}
	public UserVOExtend(String dpName, Integer userRequestId) {
		super();
		DpName = dpName;
		this.userRequestId = userRequestId;
	}
	public String getDpName() {
		return DpName;
	}
	public void setDpName(String dpName) {
		DpName = dpName;
	}
	public Integer getUserRequestId() {
		return userRequestId;
	}
	public void setUserRequestId(Integer userRequestId) {
		this.userRequestId = userRequestId;
	}
	@Override
	public String toString() {
		return "UserVOExtend [DpName=" + DpName + ", userRequestId=" + userRequestId + ", getCodeno()=" + getCodeno()
				+ ", getUserID()=" + getUserID() + ", getUserName()=" + getUserName() + ", getUserPassword()="
				+ getUserPassword() + ", getTelUserName()=" + getTelUserName() + ", getTelUserPassword()="
				+ getTelUserPassword() + ", getDisplayName()=" + getDisplayName() + ", getUserSex()=" + getUserSex()
				+ ", getEmail()=" + getEmail() + ", getTelephone()=" + getTelephone() + ", getOrderIndex()="
				+ getOrderIndex() + ", getUserStatus()=" + getUserStatus() + ", getDpId()=" + getDpId()
				+ ", getServerIP()=" + getServerIP() + ", getIsSuper()=" + getIsSuper() + ", getCsId()=" + getCsId()
				+ ", getMsId()=" + getMsId() + ", getCreatetime()=" + getCreatetime() + ", getEndtime()=" + getEndtime()
				+ ", getComGrade()=" + getComGrade() + ", getPost()=" + getPost() + ", getState()=" + getState()
				+ ", getUserType()=" + getUserType() + ", getDescription()=" + getDescription() + ", getAttend()="
				+ getAttend() + ", getIsuse()=" + getIsuse() + ", getJoinMode()=" + getJoinMode() + ", getLogo()="
				+ getLogo() + ", getRegisterTime()=" + getRegisterTime() + ", getApplyDate()=" + getApplyDate()
				+ ", getCompID()=" + getCompID() + ", getAdminID()=" + getAdminID() + ", getLastLoginTime()="
				+ getLastLoginTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}
	

	

}
