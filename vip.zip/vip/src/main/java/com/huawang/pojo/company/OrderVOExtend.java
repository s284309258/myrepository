package com.huawang.pojo.company;

/**
   * 订单拓展类
 * @author Administrator
 *
 */
public class OrderVOExtend extends OrderVO{
	private Integer state;//开票转态 0:未开发票   1:已开票
	private String productName; //产品名称
	private String packageName; //套餐名
	private Integer minuteCount; //套餐分钟数量（时间类） 
	private Double packagePrice; //套餐价格
	public OrderVOExtend() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderVOExtend(Integer id, String oType, Integer oMaxUserCount, String oProduct, Integer oUseDays,
			String oCreateDate, String oEndDate, Integer oUseTimes, String oRemark, String oStatus, String oAdminID,
			String oApproveID, String oCreateUser, String oCreateTime, String oUpdateUser, String oUpdateTime,
			String oCompID, String oOpinion, String oflow, String obak1, String obak2, String source, String oCompName,
			String oSignRadio, String oStyle, String osellType, Double price, String createType, Integer oaid,
			Integer spid) {
		super(id, oType, oMaxUserCount, oProduct, oUseDays, oCreateDate, oEndDate, oUseTimes, oRemark, oStatus, oAdminID,
				oApproveID, oCreateUser, oCreateTime, oUpdateUser, oUpdateTime, oCompID, oOpinion, oflow, obak1, obak2, source,
				oCompName, oSignRadio, oStyle, osellType, price, createType, oaid, spid);
		// TODO Auto-generated constructor stub
	}
	public OrderVOExtend(Integer state, String productName, String packageName, Integer minuteCount,
			Double packagePrice) {
		super();
		this.state = state;
		this.productName = productName;
		this.packageName = packageName;
		this.minuteCount = minuteCount;
		this.packagePrice = packagePrice;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public Integer getMinuteCount() {
		return minuteCount;
	}
	public void setMinuteCount(Integer minuteCount) {
		this.minuteCount = minuteCount;
	}
	public Double getPackagePrice() {
		return packagePrice;
	}
	public void setPackagePrice(Double packagePrice) {
		this.packagePrice = packagePrice;
	}
	@Override
	public String toString() {
		return "OrderVOExtend [state=" + state + ", productName=" + productName + ", packageName=" + packageName
				+ ", minuteCount=" + minuteCount + ", packagePrice=" + packagePrice + ", getId()=" + getId()
				+ ", getoType()=" + getoType() + ", getoMaxUserCount()=" + getoMaxUserCount() + ", getoProduct()="
				+ getoProduct() + ", getoUseDays()=" + getoUseDays() + ", getoCreateDate()=" + getoCreateDate()
				+ ", getoEndDate()=" + getoEndDate() + ", getoUseTimes()=" + getoUseTimes() + ", getoRemark()="
				+ getoRemark() + ", getoStatus()=" + getoStatus() + ", getoAdminID()=" + getoAdminID()
				+ ", getoApproveID()=" + getoApproveID() + ", getoCreateUser()=" + getoCreateUser()
				+ ", getoCreateTime()=" + getoCreateTime() + ", getoUpdateUser()=" + getoUpdateUser()
				+ ", getoUpdateTime()=" + getoUpdateTime() + ", getoCompID()=" + getoCompID() + ", getoOpinion()="
				+ getoOpinion() + ", getOflow()=" + getOflow() + ", getObak1()=" + getObak1() + ", getObak2()="
				+ getObak2() + ", getSource()=" + getSource() + ", getoCompName()=" + getoCompName()
				+ ", getoSignRadio()=" + getoSignRadio() + ", getoStyle()=" + getoStyle() + ", getOsellType()="
				+ getOsellType() + ", getPrice()=" + getPrice() + ", getCreateType()=" + getCreateType()
				+ ", getOaid()=" + getOaid() + ", getSpid()=" + getSpid() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
	


}
