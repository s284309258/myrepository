package com.huawang.pojo.company;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class LogConfVO {
	private Integer	LogConfID;//会议日志详情id
	private Integer	ConfID;//会议日志id(会议号)
	private Integer	MaxCount;//最大在线人数
	private Date	StartTime;//开始时间
	private Date	EndTime;//结束时间
	private String	codeno;//暂无使用
	private Integer	personMinute;	//人分钟
	private String sellType;//销售方式: 1：时间类，2：并发类
	public LogConfVO() {
		super();
	}
	
	public LogConfVO(Integer logConfID, Integer confID, Integer maxCount, Date startTime, Date endTime, String codeno,
			Integer personMinute, String sellType) {
		super();
		LogConfID = logConfID;
		ConfID = confID;
		MaxCount = maxCount;
		StartTime = startTime;
		EndTime = endTime;
		this.codeno = codeno;
		this.personMinute = personMinute;
		this.sellType = sellType;
	}

	public Integer getLogConfID() {
		return LogConfID;
	}
	public void setLogConfID(Integer logConfID) {
		LogConfID = logConfID;
	}
	public Integer getConfID() {
		return ConfID;
	}
	public void setConfID(Integer confID) {
		ConfID = confID;
	}
	public Integer getMaxCount() {
		return MaxCount;
	}
	public void setMaxCount(Integer maxCount) {
		MaxCount = maxCount;
	}
	public Date getStartTime() {
		return StartTime;
	}
	public void setStartTime(Date startTime) {
		StartTime = startTime;
	}
	public Date getEndTime() {
		return EndTime;
	}
	public void setEndTime(Date endTime) {
		EndTime = endTime;
	}
	public String getCodeno() {
		return codeno;
	}
	public void setCodeno(String codeno) {
		this.codeno = codeno;
	}
	public Integer getPersonMinute() {
		return personMinute;
	}
	public void setPersonMinute(Integer personMinute) {
		this.personMinute = personMinute;
	}
	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	@Override
	public String toString() {
		return "LogConfVO [LogConfID=" + LogConfID + ", ConfID=" + ConfID + ", MaxCount=" + MaxCount + ", StartTime="
				+ StartTime + ", EndTime=" + EndTime + ", codeno=" + codeno + ", personMinute=" + personMinute
				+ ", sellType=" + sellType + "]";
	}
	

	

	
}
