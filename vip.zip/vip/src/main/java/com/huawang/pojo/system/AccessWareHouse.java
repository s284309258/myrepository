package com.huawang.pojo.system;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class AccessWareHouse {

	private Integer inboundOutboundId;
	private Integer relatedId;
	private Integer status;
	private Integer type;
	private Integer category;
	private String createBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	
	private Date createDate;
	private String description;
	private String remarks;
	public Integer getInboundOutboundId() {
		return inboundOutboundId;
	}
	public void setInboundOutboundId(Integer inboundOutboundId) {
		this.inboundOutboundId = inboundOutboundId;
	}
	public Integer getRelatedId() {
		return relatedId;
	}
	public void setRelatedId(Integer relatedId) {
		this.relatedId = relatedId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getCategory() {
		return category;
	}
	public void setCategory(Integer category) {
		this.category = category;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
}
