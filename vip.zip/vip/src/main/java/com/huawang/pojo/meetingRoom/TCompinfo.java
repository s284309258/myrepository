package com.huawang.pojo.meetingRoom;

import org.springframework.format.annotation.DateTimeFormat;

public class TCompinfo {

	public String codeno;
	public Integer compId ;
	public String compName;
	public String compPassword;
	public String compTrueName;
	public Integer adminId;
	public Integer maxUserCount;
	public String lianxr;
	public String lianxrtel;
	public String mcuIp;
	public Integer maxCurUserCount;
	public String domainName;
	public String compStatus;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String createDate;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String endDate;
	public String codePwd;
	public String mcuIpId;
	public String headImagePath;
	public String logImagePath;
	public String lmageMakdir;
	public String lianxrqq;
	public String maxEnddate;
	public String contractEndTime;
	public Integer maxConfCount;
	public String bbDate;
	public String fpDate;
	public String lrDate;
	public Integer province;
	public Integer oldAdminId;
	public String  ktDate;
	public Integer bbadminId;
	public Integer ktadminId;
	public String remark;
	public Integer isDate;
	public Integer isAddUser;
	public Integer isConfLogin;
	public String telephone;
	public String disPlayName;
	
	public String sumUser;
	public String sumTime;
	public String avgTime;
	public String meetNum;
	public String endTime;
	public String startTime;
	
	public String createBy;
	public String updateBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String updateDate;
	public String status;
	public Integer confId;
	public Integer productId;
	
	public String adminName;
	public String adminTrueName;
	public String productName;
	public String belongAgent;
	public Integer compStyle;
	public String serverName;
	public String o_type;
	public String allocatAdmin;
	public String defualtServer;
	public Integer isMeeting;
	public Integer meetingCount;
	
	public Integer getIsMeeting() {
		return isMeeting;
	}
	public void setIsMeeting(Integer isMeeting) {
		this.isMeeting = isMeeting;
	}
	public Integer getMeetingCount() {
		return meetingCount;
	}
	public void setMeetingCount(Integer meetingCount) {
		this.meetingCount = meetingCount;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	/**
	 * @return the codeno
	 */
	public String getCodeno() {
		return codeno;
	}
	/**
	 * @param codeno the codeno to set
	 */
	public void setCodeno(String codeno) {
		this.codeno = codeno;
	}
	/**
	 * @return the compId
	 */
	public Integer getCompId() {
		return compId;
	}
	/**
	 * @param compId the compId to set
	 */
	public void setCompId(Integer compId) {
		this.compId = compId;
	}
	/**
	 * @return the compName
	 */
	public String getCompName() {
		return compName;
	}
	/**
	 * @param compName the compName to set
	 */
	public void setCompName(String compName) {
		this.compName = compName;
	}
	/**
	 * @return the compPassword
	 */
	public String getCompPassword() {
		return compPassword;
	}
	/**
	 * @param compPassword the compPassword to set
	 */
	public void setCompPassword(String compPassword) {
		this.compPassword = compPassword;
	}
	/**
	 * @return the compTrueName
	 */
	public String getCompTrueName() {
		return compTrueName;
	}
	/**
	 * @param compTrueName the compTrueName to set
	 */
	public void setCompTrueName(String compTrueName) {
		this.compTrueName = compTrueName;
	}
	/**
	 * @return the adminId
	 */
	public Integer getAdminId() {
		return adminId;
	}
	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	/**
	 * @return the maxUserCount
	 */
	public Integer getMaxUserCount() {
		return maxUserCount;
	}
	/**
	 * @param maxUserCount the maxUserCount to set
	 */
	public void setMaxUserCount(Integer maxUserCount) {
		this.maxUserCount = maxUserCount;
	}
	/**
	 * @return the lianxr
	 */
	public String getLianxr() {
		return lianxr;
	}
	/**
	 * @param lianxr the lianxr to set
	 */
	public void setLianxr(String lianxr) {
		this.lianxr = lianxr;
	}
	/**
	 * @return the lianxrtel
	 */
	public String getLianxrtel() {
		return lianxrtel;
	}
	/**
	 * @param lianxrtel the lianxrtel to set
	 */
	public void setLianxrtel(String lianxrtel) {
		this.lianxrtel = lianxrtel;
	}
	/**
	 * @return the mcuIp
	 */
	public String getMcuIp() {
		return mcuIp;
	}
	/**
	 * @param mcuIp the mcuIp to set
	 */
	public void setMcuIp(String mcuIp) {
		this.mcuIp = mcuIp;
	}
	/**
	 * @return the maxCurUserCount
	 */
	public Integer getMaxCurUserCount() {
		return maxCurUserCount;
	}
	/**
	 * @param maxCurUserCount the maxCurUserCount to set
	 */
	public void setMaxCurUserCount(Integer maxCurUserCount) {
		this.maxCurUserCount = maxCurUserCount;
	}
	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}
	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	/**
	 * @return the compStatus
	 */
	public String getCompStatus() {
		return compStatus;
	}
	/**
	 * @param compStatus the compStatus to set
	 */
	public void setCompStatus(String compStatus) {
		this.compStatus = compStatus;
	}
	public Integer getConfId() {
		return confId;
	}
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the codePwd
	 */
	public String getCodePwd() {
		return codePwd;
	}
	/**
	 * @param codePwd the codePwd to set
	 */
	public void setCodePwd(String codePwd) {
		this.codePwd = codePwd;
	}
	/**
	 * @return the mcuIpId
	 */
	public String getMcuIpId() {
		return mcuIpId;
	}
	/**
	 * @param mcuIpId the mcuIpId to set
	 */
	public void setMcuIpId(String mcuIpId) {
		this.mcuIpId = mcuIpId;
	}
	/**
	 * @return the headImagePath
	 */
	public String getHeadImagePath() {
		return headImagePath;
	}
	/**
	 * @param headImagePath the headImagePath to set
	 */
	public void setHeadImagePath(String headImagePath) {
		this.headImagePath = headImagePath;
	}
	/**
	 * @return the logImagePath
	 */
	public String getLogImagePath() {
		return logImagePath;
	}
	/**
	 * @param logImagePath the logImagePath to set
	 */
	public void setLogImagePath(String logImagePath) {
		this.logImagePath = logImagePath;
	}
	/**
	 * @return the lmageMakdir
	 */
	public String getLmageMakdir() {
		return lmageMakdir;
	}
	/**
	 * @param lmageMakdir the lmageMakdir to set
	 */
	public void setLmageMakdir(String lmageMakdir) {
		this.lmageMakdir = lmageMakdir;
	}
	/**
	 * @return the lianxrqq
	 */
	public String getLianxrqq() {
		return lianxrqq;
	}
	/**
	 * @param lianxrqq the lianxrqq to set
	 */
	public void setLianxrqq(String lianxrqq) {
		this.lianxrqq = lianxrqq;
	}
	/**
	 * @return the maxEnddate
	 */
	public String getMaxEnddate() {
		return maxEnddate;
	}
	/**
	 * @param maxEnddate the maxEnddate to set
	 */
	public void setMaxEnddate(String maxEnddate) {
		this.maxEnddate = maxEnddate;
	}
	/**
	 * @return the contractEndTime
	 */
	public String getContractEndTime() {
		return contractEndTime;
	}
	/**
	 * @param contractEndTime the contractEndTime to set
	 */
	public void setContractEndTime(String contractEndTime) {
		this.contractEndTime = contractEndTime;
	}
	/**
	 * @return the maxConfCount
	 */
	public Integer getMaxConfCount() {
		return maxConfCount;
	}
	/**
	 * @param maxConfCount the maxConfCount to set
	 */
	public void setMaxConfCount(Integer maxConfCount) {
		this.maxConfCount = maxConfCount;
	}
	/**
	 * @return the bbDate
	 */
	public String getBbDate() {
		return bbDate;
	}
	/**
	 * @param bbDate the bbDate to set
	 */
	public void setBbDate(String bbDate) {
		this.bbDate = bbDate;
	}
	/**
	 * @return the fpDate
	 */
	public String getFpDate() {
		return fpDate;
	}
	/**
	 * @param fpDate the fpDate to set
	 */
	public void setFpDate(String fpDate) {
		this.fpDate = fpDate;
	}
	/**
	 * @return the lrDate
	 */
	public String getLrDate() {
		return lrDate;
	}
	/**
	 * @param lrDate the lrDate to set
	 */
	public void setLrDate(String lrDate) {
		this.lrDate = lrDate;
	}
	/**
	 * @return the province
	 */
	public Integer getProvince() {
		return province;
	}
	/**
	 * @param province the province to set
	 */
	public void setProvince(Integer province) {
		this.province = province;
	}
	/**
	 * @return the oldAdminId
	 */
	public Integer getOldAdminId() {
		return oldAdminId;
	}
	/**
	 * @param oldAdminId the oldAdminId to set
	 */
	public void setOldAdminId(Integer oldAdminId) {
		this.oldAdminId = oldAdminId;
	}
	/**
	 * @return the ktDate
	 */
	public String getKtDate() {
		return ktDate;
	}
	/**
	 * @param ktDate the ktDate to set
	 */
	public void setKtDate(String ktDate) {
		this.ktDate = ktDate;
	}
	/**
	 * @return the bbadminId
	 */
	public Integer getBbadminId() {
		return bbadminId;
	}
	/**
	 * @param bbadminId the bbadminId to set
	 */
	public void setBbadminId(Integer bbadminId) {
		this.bbadminId = bbadminId;
	}
	/**
	 * @return the ktadminId
	 */
	public Integer getKtadminId() {
		return ktadminId;
	}
	/**
	 * @param ktadminId the ktadminId to set
	 */
	public void setKtadminId(Integer ktadminId) {
		this.ktadminId = ktadminId;
	}
	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * @return the isDate
	 */
	public Integer getIsDate() {
		return isDate;
	}
	/**
	 * @param isDate the isDate to set
	 */
	public void setIsDate(Integer isDate) {
		this.isDate = isDate;
	}
	/**
	 * @return the isAddUser
	 */
	public Integer getIsAddUser() {
		return isAddUser;
	}
	/**
	 * @param isAddUser the isAddUser to set
	 */
	public void setIsAddUser(Integer isAddUser) {
		this.isAddUser = isAddUser;
	}
	/**
	 * @return the isConfLogin
	 */
	public Integer getIsConfLogin() {
		return isConfLogin;
	}
	/**
	 * @param isConfLogin the isConfLogin to set
	 */
	public void setIsConfLogin(Integer isConfLogin) {
		this.isConfLogin = isConfLogin;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getDisPlayName() {
		return disPlayName;
	}
	public void setDisPlayName(String disPlayName) {
		this.disPlayName = disPlayName;
	}
	/**
	 * @return the sumUser
	 */
	public String getSumUser() {
		return sumUser;
	}
	/**
	 * @param sumUser the sumUser to set
	 */
	public void setSumUser(String sumUser) {
		this.sumUser = sumUser;
	}
	/**
	 * @return the sumTime
	 */
	public String getSumTime() {
		return sumTime;
	}
	/**
	 * @param sumTime the sumTime to set
	 */
	public void setSumTime(String sumTime) {
		this.sumTime = sumTime;
	}
	/**
	 * @return the avgTime
	 */
	public String getAvgTime() {
		return avgTime;
	}
	/**
	 * @param avgTime the avgTime to set
	 */
	public void setAvgTime(String avgTime) {
		this.avgTime = avgTime;
	}
	/**
	 * @return the meetNum
	 */
	public String getMeetNum() {
		return meetNum;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	/**
	 * startTime
	 * @return
	 */
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	/**
	 * @param meetNum the meetNum to set
	 */
	public void setMeetNum(String meetNum) {
		this.meetNum = meetNum;
	}
	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}
	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}
	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	/**
	 * 订单状态
	 * @return
	 */
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return the adminTrueName
	 */
	public String getAdminName() {
		return adminName;
	}
	/**
	 * @param adminTrueName the adminName to set
	 */
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminTrueName() {
		return adminTrueName;
	}
	public void setAdminTrueName(String adminTrueName) {
		this.adminTrueName = adminTrueName;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBelongAgent() {
		return belongAgent;
	}
	public void setBelongAgent(String belongAgent) {
		this.belongAgent = belongAgent;
	}
	public Integer getCompStyle() {
		return compStyle;
	}
	public void setCompStyle(Integer compStyle) {
		this.compStyle = compStyle;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getO_type() {
		return o_type;
	}
	public void setO_type(String o_type) {
		this.o_type = o_type;
	}
	public String getAllocatAdmin() {
		return allocatAdmin;
	}
	public void setAllocatAdmin(String allocatAdmin) {
		this.allocatAdmin = allocatAdmin;
	}
	public String getDefualtServer() {
		return defualtServer;
	}
	public void setDefualtServer(String defualtServer) {
		this.defualtServer = defualtServer;
	}
}
