package com.huawang.pojo.company;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class ProductVO {
	private String	Codeno;
	private Integer	ProductId;
	private String	ProductName;
	private Integer	wDefaultUI;
	private Integer	wMainDisplayUI;
	private Integer	wScreenCount;
	private Integer	wMaxBitRate;
	private Integer	bMaxBroadcastVideos;
	private Integer	bMaxDownVideos;
	private Integer	bMaxUpVideos;
	private Integer	bMaxDownVideosOfChiar;
	private Integer	wMaxResolusionW;
	private Integer	wMaxResolusionH;
	private Integer	bMaxFrameRate;
	private Integer	wMaxDownAudios;
	private String	bDocShare;
	private Integer	bMaxOpenDocs;
	private Integer	bMaxWBPages;
	private String	bScreenShare;
	private String	bDesktopShare;
	private String	bAppShare;
	private String	bRemoteControl;
	private String	bScreenLabel;
	private String	bMediaShare;
	private String	bWebShare;
	private String	bChatP2P;
	private String	bChatP2All;
	private String	bClientRecord;
	private String	bServerRecord;
	private String	bPSTN;
	private String	bH323GW;
	private String	bTVWall;
	private String	bTerminal;
	private String	biOS;
	private String	bAndroid;
	private String	bMultiServer;
	private String	bVote;
	private String	bFileTrans;
	private String	bFileCabinet;
	private String	bApplause;
	private String	bRinging;
	private String	bAudioP2P;
	private String	bFreeSpeak;
	private String	bAutoSpeek;
	private String	bAutoRecvSelfVideo;
	private String	bAutoBroadcastSelfVideo;
	private String	productDescription;
	private String	ConfMode;
	private String	productStruts;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date	updateDate;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date	updateDate1;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date	updateDate3;
	private String	productCategory;
	private Double	perMinutesPrice;
	private Double	perDayPrice;
	private Double	PerYearPrice;
	private String	perOnePrice;
	public ProductVO() {
		super();
	}
	public ProductVO(String codeno, Integer productId, String productName, Integer wDefaultUI, Integer wMainDisplayUI,
			Integer wScreenCount, Integer wMaxBitRate, Integer bMaxBroadcastVideos, Integer bMaxDownVideos,
			Integer bMaxUpVideos, Integer bMaxDownVideosOfChiar, Integer wMaxResolusionW, Integer wMaxResolusionH,
			Integer bMaxFrameRate, Integer wMaxDownAudios, String bDocShare, Integer bMaxOpenDocs, Integer bMaxWBPages,
			String bScreenShare, String bDesktopShare, String bAppShare, String bRemoteControl, String bScreenLabel,
			String bMediaShare, String bWebShare, String bChatP2P, String bChatP2All, String bClientRecord,
			String bServerRecord, String bPSTN, String bH323GW, String bTVWall, String bTerminal, String biOS,
			String bAndroid, String bMultiServer, String bVote, String bFileTrans, String bFileCabinet,
			String bApplause, String bRinging, String bAudioP2P, String bFreeSpeak, String bAutoSpeek,
			String bAutoRecvSelfVideo, String bAutoBroadcastSelfVideo, String productDescription, String confMode,
			String productStruts, Date updateDate, Date updateDate1, Date updateDate3, String productCategory,
			Double perMinutesPrice, Double perDayPrice, Double perYearPrice, String perOnePrice) {
		super();
		Codeno = codeno;
		ProductId = productId;
		ProductName = productName;
		this.wDefaultUI = wDefaultUI;
		this.wMainDisplayUI = wMainDisplayUI;
		this.wScreenCount = wScreenCount;
		this.wMaxBitRate = wMaxBitRate;
		this.bMaxBroadcastVideos = bMaxBroadcastVideos;
		this.bMaxDownVideos = bMaxDownVideos;
		this.bMaxUpVideos = bMaxUpVideos;
		this.bMaxDownVideosOfChiar = bMaxDownVideosOfChiar;
		this.wMaxResolusionW = wMaxResolusionW;
		this.wMaxResolusionH = wMaxResolusionH;
		this.bMaxFrameRate = bMaxFrameRate;
		this.wMaxDownAudios = wMaxDownAudios;
		this.bDocShare = bDocShare;
		this.bMaxOpenDocs = bMaxOpenDocs;
		this.bMaxWBPages = bMaxWBPages;
		this.bScreenShare = bScreenShare;
		this.bDesktopShare = bDesktopShare;
		this.bAppShare = bAppShare;
		this.bRemoteControl = bRemoteControl;
		this.bScreenLabel = bScreenLabel;
		this.bMediaShare = bMediaShare;
		this.bWebShare = bWebShare;
		this.bChatP2P = bChatP2P;
		this.bChatP2All = bChatP2All;
		this.bClientRecord = bClientRecord;
		this.bServerRecord = bServerRecord;
		this.bPSTN = bPSTN;
		this.bH323GW = bH323GW;
		this.bTVWall = bTVWall;
		this.bTerminal = bTerminal;
		this.biOS = biOS;
		this.bAndroid = bAndroid;
		this.bMultiServer = bMultiServer;
		this.bVote = bVote;
		this.bFileTrans = bFileTrans;
		this.bFileCabinet = bFileCabinet;
		this.bApplause = bApplause;
		this.bRinging = bRinging;
		this.bAudioP2P = bAudioP2P;
		this.bFreeSpeak = bFreeSpeak;
		this.bAutoSpeek = bAutoSpeek;
		this.bAutoRecvSelfVideo = bAutoRecvSelfVideo;
		this.bAutoBroadcastSelfVideo = bAutoBroadcastSelfVideo;
		this.productDescription = productDescription;
		ConfMode = confMode;
		this.productStruts = productStruts;
		this.updateDate = updateDate;
		this.updateDate1 = updateDate1;
		this.updateDate3 = updateDate3;
		this.productCategory = productCategory;
		this.perMinutesPrice = perMinutesPrice;
		this.perDayPrice = perDayPrice;
		PerYearPrice = perYearPrice;
		this.perOnePrice = perOnePrice;
	}
	public String getCodeno() {
		return Codeno;
	}
	public void setCodeno(String codeno) {
		Codeno = codeno;
	}
	public Integer getProductId() {
		return ProductId;
	}
	public void setProductId(Integer productId) {
		ProductId = productId;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public Integer getwDefaultUI() {
		return wDefaultUI;
	}
	public void setwDefaultUI(Integer wDefaultUI) {
		this.wDefaultUI = wDefaultUI;
	}
	public Integer getwMainDisplayUI() {
		return wMainDisplayUI;
	}
	public void setwMainDisplayUI(Integer wMainDisplayUI) {
		this.wMainDisplayUI = wMainDisplayUI;
	}
	public Integer getwScreenCount() {
		return wScreenCount;
	}
	public void setwScreenCount(Integer wScreenCount) {
		this.wScreenCount = wScreenCount;
	}
	public Integer getwMaxBitRate() {
		return wMaxBitRate;
	}
	public void setwMaxBitRate(Integer wMaxBitRate) {
		this.wMaxBitRate = wMaxBitRate;
	}
	public Integer getbMaxBroadcastVideos() {
		return bMaxBroadcastVideos;
	}
	public void setbMaxBroadcastVideos(Integer bMaxBroadcastVideos) {
		this.bMaxBroadcastVideos = bMaxBroadcastVideos;
	}
	public Integer getbMaxDownVideos() {
		return bMaxDownVideos;
	}
	public void setbMaxDownVideos(Integer bMaxDownVideos) {
		this.bMaxDownVideos = bMaxDownVideos;
	}
	public Integer getbMaxUpVideos() {
		return bMaxUpVideos;
	}
	public void setbMaxUpVideos(Integer bMaxUpVideos) {
		this.bMaxUpVideos = bMaxUpVideos;
	}
	public Integer getbMaxDownVideosOfChiar() {
		return bMaxDownVideosOfChiar;
	}
	public void setbMaxDownVideosOfChiar(Integer bMaxDownVideosOfChiar) {
		this.bMaxDownVideosOfChiar = bMaxDownVideosOfChiar;
	}
	public Integer getwMaxResolusionW() {
		return wMaxResolusionW;
	}
	public void setwMaxResolusionW(Integer wMaxResolusionW) {
		this.wMaxResolusionW = wMaxResolusionW;
	}
	public Integer getwMaxResolusionH() {
		return wMaxResolusionH;
	}
	public void setwMaxResolusionH(Integer wMaxResolusionH) {
		this.wMaxResolusionH = wMaxResolusionH;
	}
	public Integer getbMaxFrameRate() {
		return bMaxFrameRate;
	}
	public void setbMaxFrameRate(Integer bMaxFrameRate) {
		this.bMaxFrameRate = bMaxFrameRate;
	}
	public Integer getwMaxDownAudios() {
		return wMaxDownAudios;
	}
	public void setwMaxDownAudios(Integer wMaxDownAudios) {
		this.wMaxDownAudios = wMaxDownAudios;
	}
	public String getbDocShare() {
		return bDocShare;
	}
	public void setbDocShare(String bDocShare) {
		this.bDocShare = bDocShare;
	}
	public Integer getbMaxOpenDocs() {
		return bMaxOpenDocs;
	}
	public void setbMaxOpenDocs(Integer bMaxOpenDocs) {
		this.bMaxOpenDocs = bMaxOpenDocs;
	}
	public Integer getbMaxWBPages() {
		return bMaxWBPages;
	}
	public void setbMaxWBPages(Integer bMaxWBPages) {
		this.bMaxWBPages = bMaxWBPages;
	}
	public String getbScreenShare() {
		return bScreenShare;
	}
	public void setbScreenShare(String bScreenShare) {
		this.bScreenShare = bScreenShare;
	}
	public String getbDesktopShare() {
		return bDesktopShare;
	}
	public void setbDesktopShare(String bDesktopShare) {
		this.bDesktopShare = bDesktopShare;
	}
	public String getbAppShare() {
		return bAppShare;
	}
	public void setbAppShare(String bAppShare) {
		this.bAppShare = bAppShare;
	}
	public String getbRemoteControl() {
		return bRemoteControl;
	}
	public void setbRemoteControl(String bRemoteControl) {
		this.bRemoteControl = bRemoteControl;
	}
	public String getbScreenLabel() {
		return bScreenLabel;
	}
	public void setbScreenLabel(String bScreenLabel) {
		this.bScreenLabel = bScreenLabel;
	}
	public String getbMediaShare() {
		return bMediaShare;
	}
	public void setbMediaShare(String bMediaShare) {
		this.bMediaShare = bMediaShare;
	}
	public String getbWebShare() {
		return bWebShare;
	}
	public void setbWebShare(String bWebShare) {
		this.bWebShare = bWebShare;
	}
	public String getbChatP2P() {
		return bChatP2P;
	}
	public void setbChatP2P(String bChatP2P) {
		this.bChatP2P = bChatP2P;
	}
	public String getbChatP2All() {
		return bChatP2All;
	}
	public void setbChatP2All(String bChatP2All) {
		this.bChatP2All = bChatP2All;
	}
	public String getbClientRecord() {
		return bClientRecord;
	}
	public void setbClientRecord(String bClientRecord) {
		this.bClientRecord = bClientRecord;
	}
	public String getbServerRecord() {
		return bServerRecord;
	}
	public void setbServerRecord(String bServerRecord) {
		this.bServerRecord = bServerRecord;
	}
	public String getbPSTN() {
		return bPSTN;
	}
	public void setbPSTN(String bPSTN) {
		this.bPSTN = bPSTN;
	}
	public String getbH323GW() {
		return bH323GW;
	}
	public void setbH323GW(String bH323GW) {
		this.bH323GW = bH323GW;
	}
	public String getbTVWall() {
		return bTVWall;
	}
	public void setbTVWall(String bTVWall) {
		this.bTVWall = bTVWall;
	}
	public String getbTerminal() {
		return bTerminal;
	}
	public void setbTerminal(String bTerminal) {
		this.bTerminal = bTerminal;
	}
	public String getBiOS() {
		return biOS;
	}
	public void setBiOS(String biOS) {
		this.biOS = biOS;
	}
	public String getbAndroid() {
		return bAndroid;
	}
	public void setbAndroid(String bAndroid) {
		this.bAndroid = bAndroid;
	}
	public String getbMultiServer() {
		return bMultiServer;
	}
	public void setbMultiServer(String bMultiServer) {
		this.bMultiServer = bMultiServer;
	}
	public String getbVote() {
		return bVote;
	}
	public void setbVote(String bVote) {
		this.bVote = bVote;
	}
	public String getbFileTrans() {
		return bFileTrans;
	}
	public void setbFileTrans(String bFileTrans) {
		this.bFileTrans = bFileTrans;
	}
	public String getbFileCabinet() {
		return bFileCabinet;
	}
	public void setbFileCabinet(String bFileCabinet) {
		this.bFileCabinet = bFileCabinet;
	}
	public String getbApplause() {
		return bApplause;
	}
	public void setbApplause(String bApplause) {
		this.bApplause = bApplause;
	}
	public String getbRinging() {
		return bRinging;
	}
	public void setbRinging(String bRinging) {
		this.bRinging = bRinging;
	}
	public String getbAudioP2P() {
		return bAudioP2P;
	}
	public void setbAudioP2P(String bAudioP2P) {
		this.bAudioP2P = bAudioP2P;
	}
	public String getbFreeSpeak() {
		return bFreeSpeak;
	}
	public void setbFreeSpeak(String bFreeSpeak) {
		this.bFreeSpeak = bFreeSpeak;
	}
	public String getbAutoSpeek() {
		return bAutoSpeek;
	}
	public void setbAutoSpeek(String bAutoSpeek) {
		this.bAutoSpeek = bAutoSpeek;
	}
	public String getbAutoRecvSelfVideo() {
		return bAutoRecvSelfVideo;
	}
	public void setbAutoRecvSelfVideo(String bAutoRecvSelfVideo) {
		this.bAutoRecvSelfVideo = bAutoRecvSelfVideo;
	}
	public String getbAutoBroadcastSelfVideo() {
		return bAutoBroadcastSelfVideo;
	}
	public void setbAutoBroadcastSelfVideo(String bAutoBroadcastSelfVideo) {
		this.bAutoBroadcastSelfVideo = bAutoBroadcastSelfVideo;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getConfMode() {
		return ConfMode;
	}
	public void setConfMode(String confMode) {
		ConfMode = confMode;
	}
	public String getProductStruts() {
		return productStruts;
	}
	public void setProductStruts(String productStruts) {
		this.productStruts = productStruts;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getUpdateDate1() {
		return updateDate1;
	}
	public void setUpdateDate1(Date updateDate1) {
		this.updateDate1 = updateDate1;
	}
	public Date getUpdateDate3() {
		return updateDate3;
	}
	public void setUpdateDate3(Date updateDate3) {
		this.updateDate3 = updateDate3;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Double getPerMinutesPrice() {
		return perMinutesPrice;
	}
	public void setPerMinutesPrice(Double perMinutesPrice) {
		this.perMinutesPrice = perMinutesPrice;
	}
	public Double getPerDayPrice() {
		return perDayPrice;
	}
	public void setPerDayPrice(Double perDayPrice) {
		this.perDayPrice = perDayPrice;
	}
	public Double getPerYearPrice() {
		return PerYearPrice;
	}
	public void setPerYearPrice(Double perYearPrice) {
		PerYearPrice = perYearPrice;
	}
	public String getPerOnePrice() {
		return perOnePrice;
	}
	public void setPerOnePrice(String perOnePrice) {
		this.perOnePrice = perOnePrice;
	}
	@Override
	public String toString() {
		return "productVO [Codeno=" + Codeno + ", ProductId=" + ProductId + ", ProductName=" + ProductName
				+ ", wDefaultUI=" + wDefaultUI + ", wMainDisplayUI=" + wMainDisplayUI + ", wScreenCount=" + wScreenCount
				+ ", wMaxBitRate=" + wMaxBitRate + ", bMaxBroadcastVideos=" + bMaxBroadcastVideos + ", bMaxDownVideos="
				+ bMaxDownVideos + ", bMaxUpVideos=" + bMaxUpVideos + ", bMaxDownVideosOfChiar=" + bMaxDownVideosOfChiar
				+ ", wMaxResolusionW=" + wMaxResolusionW + ", wMaxResolusionH=" + wMaxResolusionH + ", bMaxFrameRate="
				+ bMaxFrameRate + ", wMaxDownAudios=" + wMaxDownAudios + ", bDocShare=" + bDocShare + ", bMaxOpenDocs="
				+ bMaxOpenDocs + ", bMaxWBPages=" + bMaxWBPages + ", bScreenShare=" + bScreenShare + ", bDesktopShare="
				+ bDesktopShare + ", bAppShare=" + bAppShare + ", bRemoteControl=" + bRemoteControl + ", bScreenLabel="
				+ bScreenLabel + ", bMediaShare=" + bMediaShare + ", bWebShare=" + bWebShare + ", bChatP2P=" + bChatP2P
				+ ", bChatP2All=" + bChatP2All + ", bClientRecord=" + bClientRecord + ", bServerRecord=" + bServerRecord
				+ ", bPSTN=" + bPSTN + ", bH323GW=" + bH323GW + ", bTVWall=" + bTVWall + ", bTerminal=" + bTerminal
				+ ", biOS=" + biOS + ", bAndroid=" + bAndroid + ", bMultiServer=" + bMultiServer + ", bVote=" + bVote
				+ ", bFileTrans=" + bFileTrans + ", bFileCabinet=" + bFileCabinet + ", bApplause=" + bApplause
				+ ", bRinging=" + bRinging + ", bAudioP2P=" + bAudioP2P + ", bFreeSpeak=" + bFreeSpeak + ", bAutoSpeek="
				+ bAutoSpeek + ", bAutoRecvSelfVideo=" + bAutoRecvSelfVideo + ", bAutoBroadcastSelfVideo="
				+ bAutoBroadcastSelfVideo + ", productDescription=" + productDescription + ", ConfMode=" + ConfMode
				+ ", productStruts=" + productStruts + ", updateDate=" + updateDate + ", updateDate1=" + updateDate1
				+ ", updateDate3=" + updateDate3 + ", productCategory=" + productCategory + ", perMinutesPrice="
				+ perMinutesPrice + ", perDayPrice=" + perDayPrice + ", PerYearPrice=" + PerYearPrice + ", perOnePrice="
				+ perOnePrice + "]";
	}

	
	
}
