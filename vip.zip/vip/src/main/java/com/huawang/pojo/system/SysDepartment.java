package com.huawang.pojo.system;

import org.springframework.format.annotation.DateTimeFormat;

public class SysDepartment {
	
	private Integer departmentId;
	private Integer parentId;
	private Integer levels;
	private Integer firstLevel;
	private Integer secondLevel;
	private Integer thirdLevel;
	private String departmentName;
	private Integer status;
	private String createBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDate;
	private String updateBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String updateDate;
	private String parentDepartment;
	
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getLevels() {
		return levels;
	}
	public void setLevels(Integer levels) {
		this.levels = levels;
	}
	public Integer getFirstLevel() {
		return firstLevel;
	}
	public void setFirstLevel(Integer firstLevel) {
		this.firstLevel = firstLevel;
	}
	public Integer getSecondLevel() {
		return secondLevel;
	}
	public void setSecondLevel(Integer secondLevel) {
		this.secondLevel = secondLevel;
	}
	public Integer getThirdLevel() {
		return thirdLevel;
	}
	public void setThirdLevel(Integer thirdLevel) {
		this.thirdLevel = thirdLevel;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getParentDepartment() {
		return parentDepartment;
	}
	public void setParentDepartment(String parentDepartment) {
		this.parentDepartment = parentDepartment;
	}
	
	
}
