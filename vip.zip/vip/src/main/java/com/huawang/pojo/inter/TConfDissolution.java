package com.huawang.pojo.inter;

import org.springframework.format.annotation.DateTimeFormat;

public class TConfDissolution {

	public Integer confId;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String disConfTime;
	//public String status;
	public Integer getConfId() {
		return confId;
	}
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	public String getDisConfTime() {
		return disConfTime;
	}
	public void setDisConfTime(String disConfTime) {
		this.disConfTime = disConfTime;
	}
}
