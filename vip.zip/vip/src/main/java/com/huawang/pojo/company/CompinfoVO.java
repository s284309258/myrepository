package com.huawang.pojo.company;

import java.util.Date;

/**
 * @author Administrator
 *
 */
public class CompinfoVO {
	private String	Codeno;
	private Integer	CompID;
	private String	CompName;
	private String	CompPassword;
	private String	CompTrueName;
	private Integer	AdminID;
	private Integer	MaxUserCount;
	private String	Lianxr;
	private String	Lianxrtel;
	private Integer	McuipId;
	private Integer	MaxCurUserCount;
	private String	DomainName;
	private String	CompStatus;
	private Date	CreateDate;
	private Date	EndDate;
	private String	CodePwd;
	private String	McuIp;
	private String	HeadImagePath;
	private String	LogImagePath;
	private String	ImageMakdir;
	private String	Lianxrqq;
	private Date	MaxEnddate;
	private Date	ContractEndTime;
	private Integer	MaxConfCount;
	private Integer	IsDate;
	private Integer	IsAddUser;
	private Integer	IsConfLogin;
	private String	isuse;
	private String	belongAgent;
	private Integer	compStyle;
	private String	defualtServer;
	private String	allocatAdmin;
	private Integer	productID;
	private String	createuser;
	private String	remark;
	private Integer	IsMeeting;
	private Integer	MeetingCount;
	private String	address;
	private String	taxNumber;
	private String	sellType;
	@Override
	public String toString() {
		return "CompinfoVO [Codeno=" + Codeno + ", CompID=" + CompID + ", CompName=" + CompName + ", CompPassword="
				+ CompPassword + ", CompTrueName=" + CompTrueName + ", AdminID=" + AdminID + ", MaxUserCount="
				+ MaxUserCount + ", Lianxr=" + Lianxr + ", Lianxrtel=" + Lianxrtel + ", McuipId=" + McuipId
				+ ", MaxCurUserCount=" + MaxCurUserCount + ", DomainName=" + DomainName + ", CompStatus=" + CompStatus
				+ ", CreateDate=" + CreateDate + ", EndDate=" + EndDate + ", CodePwd=" + CodePwd + ", McuIp=" + McuIp
				+ ", HeadImagePath=" + HeadImagePath + ", LogImagePath=" + LogImagePath + ", ImageMakdir=" + ImageMakdir
				+ ", Lianxrqq=" + Lianxrqq + ", MaxEnddate=" + MaxEnddate + ", ContractEndTime=" + ContractEndTime
				+ ", MaxConfCount=" + MaxConfCount + ", IsDate=" + IsDate + ", IsAddUser=" + IsAddUser
				+ ", IsConfLogin=" + IsConfLogin + ", isuse=" + isuse + ", belongAgent=" + belongAgent + ", compStyle="
				+ compStyle + ", defualtServer=" + defualtServer + ", allocatAdmin=" + allocatAdmin + ", productID="
				+ productID + ", createuser=" + createuser + ", remark=" + remark + ", IsMeeting=" + IsMeeting
				+ ", MeetingCount=" + MeetingCount + ", address=" + address + ", taxNumber=" + taxNumber + ", sellType="
				+ sellType + ", TolTimes=" + TolTimes + ", useResources=" + useResources + ", registerTime="
				+ registerTime + ", IsJoinId=" + IsJoinId + ", isJoinApprove=" + isJoinApprove + ", Email=" + Email
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	public String getCodeno() {
		return Codeno;
	}
	public void setCodeno(String codeno) {
		Codeno = codeno;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public String getCompName() {
		return CompName;
	}
	public void setCompName(String compName) {
		CompName = compName;
	}
	public String getCompPassword() {
		return CompPassword;
	}
	public void setCompPassword(String compPassword) {
		CompPassword = compPassword;
	}
	public String getCompTrueName() {
		return CompTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		CompTrueName = compTrueName;
	}
	public Integer getAdminID() {
		return AdminID;
	}
	public void setAdminID(Integer adminID) {
		AdminID = adminID;
	}
	public Integer getMaxUserCount() {
		return MaxUserCount;
	}
	public void setMaxUserCount(Integer maxUserCount) {
		MaxUserCount = maxUserCount;
	}
	public String getLianxr() {
		return Lianxr;
	}
	public void setLianxr(String lianxr) {
		Lianxr = lianxr;
	}
	public String getLianxrtel() {
		return Lianxrtel;
	}
	public void setLianxrtel(String lianxrtel) {
		Lianxrtel = lianxrtel;
	}
	public Integer getMcuipId() {
		return McuipId;
	}
	public void setMcuipId(Integer mcuipId) {
		McuipId = mcuipId;
	}
	public Integer getMaxCurUserCount() {
		return MaxCurUserCount;
	}
	public void setMaxCurUserCount(Integer maxCurUserCount) {
		MaxCurUserCount = maxCurUserCount;
	}
	public String getDomainName() {
		return DomainName;
	}
	public void setDomainName(String domainName) {
		DomainName = domainName;
	}
	public String getCompStatus() {
		return CompStatus;
	}
	public void setCompStatus(String compStatus) {
		CompStatus = compStatus;
	}
	public Date getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(Date createDate) {
		CreateDate = createDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public String getCodePwd() {
		return CodePwd;
	}
	public void setCodePwd(String codePwd) {
		CodePwd = codePwd;
	}
	public String getMcuIp() {
		return McuIp;
	}
	public void setMcuIp(String mcuIp) {
		McuIp = mcuIp;
	}
	public String getHeadImagePath() {
		return HeadImagePath;
	}
	public void setHeadImagePath(String headImagePath) {
		HeadImagePath = headImagePath;
	}
	public String getLogImagePath() {
		return LogImagePath;
	}
	public void setLogImagePath(String logImagePath) {
		LogImagePath = logImagePath;
	}
	public String getImageMakdir() {
		return ImageMakdir;
	}
	public void setImageMakdir(String imageMakdir) {
		ImageMakdir = imageMakdir;
	}
	public String getLianxrqq() {
		return Lianxrqq;
	}
	public void setLianxrqq(String lianxrqq) {
		Lianxrqq = lianxrqq;
	}
	public Date getMaxEnddate() {
		return MaxEnddate;
	}
	public void setMaxEnddate(Date maxEnddate) {
		MaxEnddate = maxEnddate;
	}
	public Date getContractEndTime() {
		return ContractEndTime;
	}
	public void setContractEndTime(Date contractEndTime) {
		ContractEndTime = contractEndTime;
	}
	public Integer getMaxConfCount() {
		return MaxConfCount;
	}
	public void setMaxConfCount(Integer maxConfCount) {
		MaxConfCount = maxConfCount;
	}
	public Integer getIsDate() {
		return IsDate;
	}
	public void setIsDate(Integer isDate) {
		IsDate = isDate;
	}
	public Integer getIsAddUser() {
		return IsAddUser;
	}
	public void setIsAddUser(Integer isAddUser) {
		IsAddUser = isAddUser;
	}
	public Integer getIsConfLogin() {
		return IsConfLogin;
	}
	public void setIsConfLogin(Integer isConfLogin) {
		IsConfLogin = isConfLogin;
	}
	public String getIsuse() {
		return isuse;
	}
	public void setIsuse(String isuse) {
		this.isuse = isuse;
	}
	public String getBelongAgent() {
		return belongAgent;
	}
	public void setBelongAgent(String belongAgent) {
		this.belongAgent = belongAgent;
	}
	public Integer getCompStyle() {
		return compStyle;
	}
	public void setCompStyle(Integer compStyle) {
		this.compStyle = compStyle;
	}
	public String getDefualtServer() {
		return defualtServer;
	}
	public void setDefualtServer(String defualtServer) {
		this.defualtServer = defualtServer;
	}
	public String getAllocatAdmin() {
		return allocatAdmin;
	}
	public void setAllocatAdmin(String allocatAdmin) {
		this.allocatAdmin = allocatAdmin;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public String getCreateuser() {
		return createuser;
	}
	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getIsMeeting() {
		return IsMeeting;
	}
	public void setIsMeeting(Integer isMeeting) {
		IsMeeting = isMeeting;
	}
	public Integer getMeetingCount() {
		return MeetingCount;
	}
	public void setMeetingCount(Integer meetingCount) {
		MeetingCount = meetingCount;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTaxNumber() {
		return taxNumber;
	}
	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}
	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	public Integer getTolTimes() {
		return TolTimes;
	}
	public void setTolTimes(Integer TolTimes) {
		this.TolTimes = TolTimes;
	}
	public Integer getUseResources() {
		return useResources;
	}
	public void setUseResources(Integer useResources) {
		this.useResources = useResources;
	}
	public Date getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}
	public Integer getIsJoinId() {
		return IsJoinId;
	}
	public void setIsJoinId(Integer IsJoinId) {
		this.IsJoinId = IsJoinId;
	}
	public String getIsJoinApprove() {
		return isJoinApprove;
	}
	public void setIsJoinApprove(String isJoinApprove) {
		this.isJoinApprove = isJoinApprove;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public CompinfoVO(String codeno, Integer compID, String compName, String compPassword, String compTrueName,
			Integer adminID, Integer maxUserCount, String lianxr, String lianxrtel, Integer mcuipId,
			Integer maxCurUserCount, String domainName, String compStatus, Date createDate, Date endDate,
			String codePwd, String mcuIp, String headImagePath, String logImagePath, String imageMakdir,
			String lianxrqq, Date maxEnddate, Date contractEndTime, Integer maxConfCount, Integer isDate,
			Integer isAddUser, Integer isConfLogin, String isuse, String belongAgent, Integer compStyle,
			String defualtServer, String allocatAdmin, Integer productID, String createuser, String remark,
			Integer isMeeting, Integer meetingCount, String address, String taxNumber, String sellType,
			Integer TolTimes, Integer useResources, Date registerTime, Integer IsJoinId, String isJoinApprove,
			String email) {
		super();
		Codeno = codeno;
		CompID = compID;
		CompName = compName;
		CompPassword = compPassword;
		CompTrueName = compTrueName;
		AdminID = adminID;
		MaxUserCount = maxUserCount;
		Lianxr = lianxr;
		Lianxrtel = lianxrtel;
		McuipId = mcuipId;
		MaxCurUserCount = maxCurUserCount;
		DomainName = domainName;
		CompStatus = compStatus;
		CreateDate = createDate;
		EndDate = endDate;
		CodePwd = codePwd;
		McuIp = mcuIp;
		HeadImagePath = headImagePath;
		LogImagePath = logImagePath;
		ImageMakdir = imageMakdir;
		Lianxrqq = lianxrqq;
		MaxEnddate = maxEnddate;
		ContractEndTime = contractEndTime;
		MaxConfCount = maxConfCount;
		IsDate = isDate;
		IsAddUser = isAddUser;
		IsConfLogin = isConfLogin;
		this.isuse = isuse;
		this.belongAgent = belongAgent;
		this.compStyle = compStyle;
		this.defualtServer = defualtServer;
		this.allocatAdmin = allocatAdmin;
		this.productID = productID;
		this.createuser = createuser;
		this.remark = remark;
		IsMeeting = isMeeting;
		MeetingCount = meetingCount;
		this.address = address;
		this.taxNumber = taxNumber;
		this.sellType = sellType;
		this.TolTimes = TolTimes;
		this.useResources = useResources;
		this.registerTime = registerTime;
		this.IsJoinId = IsJoinId;
		this.isJoinApprove = isJoinApprove;
		Email = email;
	}
	public CompinfoVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	private Integer	TolTimes;
	private Integer	useResources;
	private Date registerTime;
	private Integer	IsJoinId;
	private String	isJoinApprove;
	private String Email;
	
	

	
	


}
