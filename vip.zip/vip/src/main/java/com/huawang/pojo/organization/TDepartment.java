package com.huawang.pojo.organization;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class TDepartment {

	private String codeNo;
	private String   dpId01;
	private String   dpId02;
	private String   dpName01;
	private String   dpName02;
	private String  description;
	private int  parentDpId;
	private int  adminId;
	private String  orderValue;
	private int  compId;
	private String  createBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String  createDate;
	private String  updateBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String  updateDate;
	
	private int id;
	private int pid;
	private String name;
	
	private List<TDepartment> children;
	private List<String> list;

	/**
	 * @return the codeNo
	 */
	public String getCodeNo() {
		return codeNo;
	}

	/**
	 * @param codeNo the codeNo to set
	 */
	public void setCodeNo(String codeNo) {
		this.codeNo = codeNo;
	}

	/**
	 * @return the dpName01
	 */
	public String getDpName01() {
		return dpName01;
	}

	/**
	 * @param dpName01 the dpName01 to set
	 */
	public void setDpName01(String dpName01) {
		this.dpName01 = dpName01;
	}

	/**
	 * @return the dpName02
	 */
	public String getDpName02() {
		return dpName02;
	}

	/**
	 * @param dpName02 the dpName02 to set
	 */
	public void setDpName02(String dpName02) {
		this.dpName02 = dpName02;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the parentDpId
	 */
	public int getParentDpId() {
		return parentDpId;
	}

	/**
	 * @param parentDpId the parentDpId to set
	 */
	public void setParentDpId(int parentDpId) {
		this.parentDpId = parentDpId;
	}

	/**
	 * @return the adminId
	 */
	public int getAdminId() {
		return adminId;
	}

	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	/**
	 * @return the orderValue
	 */
	public String getOrderValue() {
		return orderValue;
	}

	/**
	 * @param orderValue the orderValue to set
	 */
	public void setOrderValue(String orderValue) {
		this.orderValue = orderValue;
	}

	/**
	 * @return the compId
	 */
	public int getCompId() {
		return compId;
	}

	/**
	 * @param compId the compId to set
	 */
	public void setCompId(int compId) {
		this.compId = compId;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the children
	 */
	public List<TDepartment> getChildren() {
		return children;
	}

	/**
	 * @param children the children to set
	 */
	public void setChildren(List<TDepartment> children) {
		this.children = children;
	}

	/**
	 * @return the pid
	 */
	public int getPid() {
		return pid;
	}

	/**
	 * @param pid the pid to set
	 */
	public void setPid(int pid) {
		this.pid = pid;
	}

	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}

	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the list
	 */
	public List<String> getList() {
		return list;
	}

	/**
	 * @param list the list to set
	 */
	public void setList(List<String> list) {
		this.list = list;
	}

	/**
	 * @return the dpId01
	 */
	public String getDpId01() {
		return dpId01;
	}

	/**
	 * @param dpId01 the dpId01 to set
	 */
	public void setDpId01(String dpId01) {
		this.dpId01 = dpId01;
	}

	/**
	 * @return the dpId02
	 */
	public String getDpId02() {
		return dpId02;
	}

	/**
	 * @param dpId02 the dpId02 to set
	 */
	public void setDpId02(String dpId02) {
		this.dpId02 = dpId02;
	}

	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}

	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}
