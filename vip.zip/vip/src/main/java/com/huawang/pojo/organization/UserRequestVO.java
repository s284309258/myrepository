package com.huawang.pojo.organization;

import java.util.Date;

public class UserRequestVO {
	private Integer	userId;	//自增主键
	private String	displayName;	//用户名称
	private String	userPassword;	//用户密码
	private String	userPhone;	//用户手机
	private Integer	userStatus;	//用户状态
	private Date	applyTime;	//申请时间
	private Integer	CompID;	//企业id
	private Integer	inviterId;	//邀请人id
	private String	inviterName;	//邀请人名称
	private String	inviteType;	//邀请方式
	private Integer	userInfoId;	//t_userinfo表userId
	public UserRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserRequestVO(Integer userId, String displayName, String userPassword, String userPhone,
			Integer userStatus, Date applyTime, Integer compID, Integer inviterId, String inviterName,
			String inviteType, Integer userInfoId) {
		super();
		this.userId = userId;
		this.displayName = displayName;
		this.userPassword = userPassword;
		this.userPhone = userPhone;
		this.userStatus = userStatus;
		this.applyTime = applyTime;
		CompID = compID;
		this.inviterId = inviterId;
		this.inviterName = inviterName;
		this.inviteType = inviteType;
		this.userInfoId = userInfoId;
	}
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public Integer getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}
	public Date getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public Integer getInviterId() {
		return inviterId;
	}
	public void setInviterId(Integer inviterId) {
		this.inviterId = inviterId;
	}
	public String getInviterName() {
		return inviterName;
	}
	public void setInviterName(String inviterName) {
		this.inviterName = inviterName;
	}
	public String getInviteType() {
		return inviteType;
	}
	public void setInviteType(String inviteType) {
		this.inviteType = inviteType;
	}
	public Integer getUserInfoId() {
		return userInfoId;
	}
	public void setUserInfoId(Integer userInfoId) {
		this.userInfoId = userInfoId;
	}
	@Override
	public String toString() {
		return "UserRequestInfo [userId=" + userId + ", displayName=" + displayName + ", userPassword=" + userPassword
				+ ", userPhone=" + userPhone + ", userStatus=" + userStatus + ", applyTime=" + applyTime + ", CompID="
				+ CompID + ", inviterId=" + inviterId + ", inviterName=" + inviterName + ", inviteType=" + inviteType
				+ ", userInfoId=" + userInfoId + "]";
	}
	
	
}
