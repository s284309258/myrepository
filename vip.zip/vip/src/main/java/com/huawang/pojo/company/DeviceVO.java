package com.huawang.pojo.company;

import java.util.Date;

public class DeviceVO {
	private String	deviceId;	//设备Id
	private String	deviceName;	//设备名称
	private String	state;	//设备状态
	private String	pinCode;	//PIN码
	private String	createTime;	//创建时间
	private String	updateTime;	//更新时间
	private Integer	CompID;	//客户名称
	private String	CompTrueName;	//客户ID
	private Double	price;	//价格
	private String	deviceModel;	//设备型号
	private Integer	createrId;	//创建人ID
	private String	createrName;	//创建人名称
	private Integer	id;
	public DeviceVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DeviceVO(String deviceId, String deviceName, String state, String pinCode, String createTime,
			String updateTime, Integer compID, String compTrueName, Double price, String deviceModel, Integer createrId,
			String createrName, Integer id) {
		super();
		this.deviceId = deviceId;
		this.deviceName = deviceName;
		this.state = state;
		this.pinCode = pinCode;
		this.createTime = createTime;
		this.updateTime = updateTime;
		CompID = compID;
		CompTrueName = compTrueName;
		this.price = price;
		this.deviceModel = deviceModel;
		this.createrId = createrId;
		this.createrName = createrName;
		this.id = id;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public String getCompTrueName() {
		return CompTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		CompTrueName = compTrueName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public Integer getCreaterId() {
		return createrId;
	}
	public void setCreaterId(Integer createrId) {
		this.createrId = createrId;
	}
	public String getCreaterName() {
		return createrName;
	}
	public void setCreaterName(String createrName) {
		this.createrName = createrName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "DeviceVO [deviceId=" + deviceId + ", deviceName=" + deviceName + ", state=" + state + ", pinCode="
				+ pinCode + ", createTime=" + createTime + ", updateTime=" + updateTime + ", CompID=" + CompID
				+ ", CompTrueName=" + CompTrueName + ", price=" + price + ", deviceModel=" + deviceModel
				+ ", createrId=" + createrId + ", createrName=" + createrName + ", id=" + id + "]";
	}	

	
}
