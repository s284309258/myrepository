package com.huawang.pojo.company;


/**
 * @author Administrator
 *
 */
public class OrderVO {
	private Integer	id;	//id
	private String	oType;	//订单类型
	private Integer	oMaxUserCount;	//最大并发数
	private String	oProduct;	//产品id
	private Integer	oUseDays;	//试用天数
	private String	oCreateDate;	//订单生效日期
	private String	oEndDate;	//订单失效日期
	private Integer	oUseTimes;	//剩余试用次数
	private String	oRemark;	//备注
	private String	oStatus;	//订单状态
	private String	oAdminID;	//订单创建人
	private String	oApproveID;	//审批id
	private String	oCreateUser;	//创建人
	private String	oCreateTime;	//创建时间
	private String	oUpdateUser;	//更新人
	private String	oUpdateTime;	//更新时间
	private String	oCompID;	//公司id
	private String	oOpinion;	//审核意见
	private String	oflow;	//对应流转记录表id
	private String	obak1;	//o_bak1
	private String	obak2;	//o_bak2
	private String	source;	//source
	private String	oCompName;	//企业名
	private String	oSignRadio;	//o_SignRadio
	private String	oStyle;	//o_Style
	private String	osellType;	//销售方式
	private Double	price;	//价格
	private String	createType;	//类型
	private Integer	oaid;	//活动ID
	private Integer	spid;	//套餐ID

	public OrderVO() {
		super();
	}
	public OrderVO(Integer id, String oType, Integer oMaxUserCount, String oProduct, Integer oUseDays,
			String oCreateDate, String oEndDate, Integer oUseTimes, String oRemark, String oStatus, String oAdminID,
			String oApproveID, String oCreateUser, String oCreateTime, String oUpdateUser, String oUpdateTime,
			String oCompID, String oOpinion, String oflow, String obak1, String obak2, String source, String oCompName,
			String oSignRadio, String oStyle, String osellType, Double price, String createType, Integer oaid,
			Integer spid) {
		super();
		this.id = id;
		this.oType = oType;
		this.oMaxUserCount = oMaxUserCount;
		this.oProduct = oProduct;
		this.oUseDays = oUseDays;
		this.oCreateDate = oCreateDate;
		this.oEndDate = oEndDate;
		this.oUseTimes = oUseTimes;
		this.oRemark = oRemark;
		this.oStatus = oStatus;
		this.oAdminID = oAdminID;
		this.oApproveID = oApproveID;
		this.oCreateUser = oCreateUser;
		this.oCreateTime = oCreateTime;
		this.oUpdateUser = oUpdateUser;
		this.oUpdateTime = oUpdateTime;
		this.oCompID = oCompID;
		this.oOpinion = oOpinion;
		this.oflow = oflow;
		this.obak1 = obak1;
		this.obak2 = obak2;
		this.source = source;
		this.oCompName = oCompName;
		this.oSignRadio = oSignRadio;
		this.oStyle = oStyle;
		this.osellType = osellType;
		this.price = price;
		this.createType = createType;
		this.oaid = oaid;
		this.spid = spid;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getoType() {
		return oType;
	}
	public void setoType(String oType) {
		this.oType = oType;
	}
	public Integer getoMaxUserCount() {
		return oMaxUserCount;
	}
	public void setoMaxUserCount(Integer oMaxUserCount) {
		this.oMaxUserCount = oMaxUserCount;
	}
	public String getoProduct() {
		return oProduct;
	}
	public void setoProduct(String oProduct) {
		this.oProduct = oProduct;
	}
	public Integer getoUseDays() {
		return oUseDays;
	}
	public void setoUseDays(Integer oUseDays) {
		this.oUseDays = oUseDays;
	}
	public String getoCreateDate() {
		return oCreateDate;
	}
	public void setoCreateDate(String oCreateDate) {
		this.oCreateDate = oCreateDate;
	}
	public String getoEndDate() {
		return oEndDate;
	}
	public void setoEndDate(String oEndDate) {
		this.oEndDate = oEndDate;
	}
	public Integer getoUseTimes() {
		return oUseTimes;
	}
	public void setoUseTimes(Integer oUseTimes) {
		this.oUseTimes = oUseTimes;
	}
	public String getoRemark() {
		return oRemark;
	}
	public void setoRemark(String oRemark) {
		this.oRemark = oRemark;
	}
	public String getoStatus() {
		return oStatus;
	}
	public void setoStatus(String oStatus) {
		this.oStatus = oStatus;
	}
	public String getoAdminID() {
		return oAdminID;
	}
	public void setoAdminID(String oAdminID) {
		this.oAdminID = oAdminID;
	}
	public String getoApproveID() {
		return oApproveID;
	}
	public void setoApproveID(String oApproveID) {
		this.oApproveID = oApproveID;
	}
	public String getoCreateUser() {
		return oCreateUser;
	}
	public void setoCreateUser(String oCreateUser) {
		this.oCreateUser = oCreateUser;
	}
	public String getoCreateTime() {
		return oCreateTime;
	}
	public void setoCreateTime(String oCreateTime) {
		this.oCreateTime = oCreateTime;
	}
	public String getoUpdateUser() {
		return oUpdateUser;
	}
	public void setoUpdateUser(String oUpdateUser) {
		this.oUpdateUser = oUpdateUser;
	}
	public String getoUpdateTime() {
		return oUpdateTime;
	}
	public void setoUpdateTime(String oUpdateTime) {
		this.oUpdateTime = oUpdateTime;
	}
	public String getoCompID() {
		return oCompID;
	}
	public void setoCompID(String oCompID) {
		this.oCompID = oCompID;
	}
	public String getoOpinion() {
		return oOpinion;
	}
	public void setoOpinion(String oOpinion) {
		this.oOpinion = oOpinion;
	}
	public String getOflow() {
		return oflow;
	}
	public void setOflow(String oflow) {
		this.oflow = oflow;
	}
	public String getObak1() {
		return obak1;
	}
	public void setObak1(String obak1) {
		this.obak1 = obak1;
	}
	public String getObak2() {
		return obak2;
	}
	public void setObak2(String obak2) {
		this.obak2 = obak2;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getoCompName() {
		return oCompName;
	}
	public void setoCompName(String oCompName) {
		this.oCompName = oCompName;
	}
	public String getoSignRadio() {
		return oSignRadio;
	}
	public void setoSignRadio(String oSignRadio) {
		this.oSignRadio = oSignRadio;
	}
	public String getoStyle() {
		return oStyle;
	}
	public void setoStyle(String oStyle) {
		this.oStyle = oStyle;
	}
	public String getOsellType() {
		return osellType;
	}
	public void setOsellType(String osellType) {
		this.osellType = osellType;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getCreateType() {
		return createType;
	}
	public void setCreateType(String createType) {
		this.createType = createType;
	}
	public Integer getOaid() {
		return oaid;
	}
	public void setOaid(Integer oaid) {
		this.oaid = oaid;
	}
	public Integer getSpid() {
		return spid;
	}
	public void setSpid(Integer spid) {
		this.spid = spid;
	}
	@Override
	public String toString() {
		return "OrderVO [id=" + id + ", oType=" + oType + ", oMaxUserCount=" + oMaxUserCount + ", oProduct=" + oProduct
				+ ", oUseDays=" + oUseDays + ", oCreateDate=" + oCreateDate + ", oEndDate=" + oEndDate + ", oUseTimes="
				+ oUseTimes + ", oRemark=" + oRemark + ", oStatus=" + oStatus + ", oAdminID=" + oAdminID
				+ ", oApproveID=" + oApproveID + ", oCreateUser=" + oCreateUser + ", oCreateTime=" + oCreateTime
				+ ", oUpdateUser=" + oUpdateUser + ", oUpdateTime=" + oUpdateTime + ", oCompID=" + oCompID
				+ ", oOpinion=" + oOpinion + ", oflow=" + oflow + ", obak1=" + obak1 + ", obak2=" + obak2 + ", source="
				+ source + ", oCompName=" + oCompName + ", oSignRadio=" + oSignRadio + ", oStyle=" + oStyle
				+ ", osellType=" + osellType + ", price=" + price + ", createType=" + createType + ", oaid=" + oaid
				+ ", spid=" + spid + "]";
	}

	
}
