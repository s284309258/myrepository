package com.huawang.pojo.company;

import java.util.Date;

public class DeviceRecordVO {

	private Integer	id;	//自增id
	private String	deviceId;	//设备ID
	private String	deviceName;	//设备名
	private String	CompTrueName;	//客户名称
	private Integer	CompID;	//企业id
	private Date	createTime;	//创建时间
	private Integer	createrId;	//创建人ID
	private String	createrName;	//创建人名称
	private String	state;	//产品状态
	private String	remark;	//备注
	private String	deviceModel;	//设备型号
	public DeviceRecordVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DeviceRecordVO(Integer id, String deviceId, String deviceName, String compTrueName, Integer compID,
			Date createTime, Integer createrId, String createrName, String state, String remark, String deviceModel) {
		super();
		this.id = id;
		this.deviceId = deviceId;
		this.deviceName = deviceName;
		CompTrueName = compTrueName;
		CompID = compID;
		this.createTime = createTime;
		this.createrId = createrId;
		this.createrName = createrName;
		this.state = state;
		this.remark = remark;
		this.deviceModel = deviceModel;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getCompTrueName() {
		return CompTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		CompTrueName = compTrueName;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getCreaterId() {
		return createrId;
	}
	public void setCreaterId(Integer createrId) {
		this.createrId = createrId;
	}
	public String getCreaterName() {
		return createrName;
	}
	public void setCreaterName(String createrName) {
		this.createrName = createrName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	@Override
	public String toString() {
		return "DeviceRecordVO [id=" + id + ", deviceId=" + deviceId + ", deviceName=" + deviceName + ", CompTrueName="
				+ CompTrueName + ", CompID=" + CompID + ", createTime=" + createTime + ", createrId=" + createrId
				+ ", createrName=" + createrName + ", state=" + state + ", remark=" + remark + ", deviceModel="
				+ deviceModel + "]";
	}
	
	
}
