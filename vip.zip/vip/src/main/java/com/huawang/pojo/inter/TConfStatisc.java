package com.huawang.pojo.inter;

public class TConfStatisc {
	
	public Integer logConfID;
	public Integer confID;
	public Integer maxCount;
	public String startTime;
	public String endTime;
	public Integer getLogConfID() {
		return logConfID;
	}
	public void setLogConfID(Integer logConfID) {
		this.logConfID = logConfID;
	}
	public Integer getConfID() {
		return confID;
	}
	public void setConfID(Integer confID) {
		this.confID = confID;
	}
	public Integer getMaxCount() {
		return maxCount;
	}
	public void setMaxCount(Integer maxCount) {
		this.maxCount = maxCount;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
}
