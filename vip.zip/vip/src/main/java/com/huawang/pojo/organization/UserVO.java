package com.huawang.pojo.organization;

import java.util.Date;

public class UserVO {
	private String	Codeno;	//Codeno
	private Integer	UserID;	//用户id
	private String	UserName;	//用户账户
	private String	UserPassword;	//密码
	private String	TelUserName;	//联系人
	private String	TelUserPassword;	//目前无意义所有都为NULL）
	private String	DisplayName;	//显示真实姓名
	private Integer	UserSex;	//用户性别 1:男 2：女
	private String	Email;	//邮箱
	private String	Telephone;	//用户手机号
	private Integer	OrderIndex;	//未知待查看（大多为0或1）
	private String	UserStatus;	//用户状态（可用或不可用）
	private Integer	DpId;	//部门id
	private String	ServerIP;	//用户所在服务器IP
	private String	IsSuper;	//是否超级管理员
	private Integer	CsId;	//CsId
	private Integer	MsId;	//MsId
	private Date	createtime;	//用户创建时间
	private Date	endtime;	//用户结束时间
	private Integer	ComGrade;	//ComGrade
	private String	Post;	//职位
	private String	State;	//状态
	private String	UserType;	//用户类型
	private String	Description;	//描述
	private Integer	Attend;	//是否参会
	private String	isuse;	//是否使用
	private String	joinMode;	//加入方式
	private String	logo;	//用户头像
	private Date	registerTime;	//注册时间
	private String	ApplyDate;	//申请时间
	private Integer	CompID;	//企业ID
	private Integer	AdminID;	//管理员ID
	private String lastLoginTime; //最近登录时间
	public UserVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserVO(String codeno, Integer userID, String userName, String userPassword, String telUserName,
			String telUserPassword, String displayName, Integer userSex, String email, String telephone,
			Integer orderIndex, String userStatus, Integer dpId, String serverIP, String isSuper, Integer csId,
			Integer msId, Date createtime, Date endtime, Integer comGrade, String post, String state, String userType,
			String description, Integer attend, String isuse, String joinMode, String logo, Date registerTime,
			String applyDate, Integer compID, Integer adminID, String lastLoginTime) {
		super();
		Codeno = codeno;
		UserID = userID;
		UserName = userName;
		UserPassword = userPassword;
		TelUserName = telUserName;
		TelUserPassword = telUserPassword;
		DisplayName = displayName;
		UserSex = userSex;
		Email = email;
		Telephone = telephone;
		OrderIndex = orderIndex;
		UserStatus = userStatus;
		DpId = dpId;
		ServerIP = serverIP;
		IsSuper = isSuper;
		CsId = csId;
		MsId = msId;
		this.createtime = createtime;
		this.endtime = endtime;
		ComGrade = comGrade;
		Post = post;
		State = state;
		UserType = userType;
		Description = description;
		Attend = attend;
		this.isuse = isuse;
		this.joinMode = joinMode;
		this.logo = logo;
		this.registerTime = registerTime;
		ApplyDate = applyDate;
		CompID = compID;
		AdminID = adminID;
		this.lastLoginTime = lastLoginTime;
	}
	public String getCodeno() {
		return Codeno;
	}
	public void setCodeno(String codeno) {
		Codeno = codeno;
	}
	public Integer getUserID() {
		return UserID;
	}
	public void setUserID(Integer userID) {
		UserID = userID;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	public String getTelUserName() {
		return TelUserName;
	}
	public void setTelUserName(String telUserName) {
		TelUserName = telUserName;
	}
	public String getTelUserPassword() {
		return TelUserPassword;
	}
	public void setTelUserPassword(String telUserPassword) {
		TelUserPassword = telUserPassword;
	}
	public String getDisplayName() {
		return DisplayName;
	}
	public void setDisplayName(String displayName) {
		DisplayName = displayName;
	}
	public Integer getUserSex() {
		return UserSex;
	}
	public void setUserSex(Integer userSex) {
		UserSex = userSex;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getTelephone() {
		return Telephone;
	}
	public void setTelephone(String telephone) {
		Telephone = telephone;
	}
	public Integer getOrderIndex() {
		return OrderIndex;
	}
	public void setOrderIndex(Integer orderIndex) {
		OrderIndex = orderIndex;
	}
	public String getUserStatus() {
		return UserStatus;
	}
	public void setUserStatus(String userStatus) {
		UserStatus = userStatus;
	}
	public Integer getDpId() {
		return DpId;
	}
	public void setDpId(Integer dpId) {
		DpId = dpId;
	}
	public String getServerIP() {
		return ServerIP;
	}
	public void setServerIP(String serverIP) {
		ServerIP = serverIP;
	}
	public String getIsSuper() {
		return IsSuper;
	}
	public void setIsSuper(String isSuper) {
		IsSuper = isSuper;
	}
	public Integer getCsId() {
		return CsId;
	}
	public void setCsId(Integer csId) {
		CsId = csId;
	}
	public Integer getMsId() {
		return MsId;
	}
	public void setMsId(Integer msId) {
		MsId = msId;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public Date getEndtime() {
		return endtime;
	}
	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}
	public Integer getComGrade() {
		return ComGrade;
	}
	public void setComGrade(Integer comGrade) {
		ComGrade = comGrade;
	}
	public String getPost() {
		return Post;
	}
	public void setPost(String post) {
		Post = post;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Integer getAttend() {
		return Attend;
	}
	public void setAttend(Integer attend) {
		Attend = attend;
	}
	public String getIsuse() {
		return isuse;
	}
	public void setIsuse(String isuse) {
		this.isuse = isuse;
	}
	public String getJoinMode() {
		return joinMode;
	}
	public void setJoinMode(String joinMode) {
		this.joinMode = joinMode;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public Date getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}
	public String getApplyDate() {
		return ApplyDate;
	}
	public void setApplyDate(String applyDate) {
		ApplyDate = applyDate;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public Integer getAdminID() {
		return AdminID;
	}
	public void setAdminID(Integer adminID) {
		AdminID = adminID;
	}
	public String getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	@Override
	public String toString() {
		return "UserVO [Codeno=" + Codeno + ", UserID=" + UserID + ", UserName=" + UserName + ", UserPassword="
				+ UserPassword + ", TelUserName=" + TelUserName + ", TelUserPassword=" + TelUserPassword
				+ ", DisplayName=" + DisplayName + ", UserSex=" + UserSex + ", Email=" + Email + ", Telephone="
				+ Telephone + ", OrderIndex=" + OrderIndex + ", UserStatus=" + UserStatus + ", DpId=" + DpId
				+ ", ServerIP=" + ServerIP + ", IsSuper=" + IsSuper + ", CsId=" + CsId + ", MsId=" + MsId
				+ ", createtime=" + createtime + ", endtime=" + endtime + ", ComGrade=" + ComGrade + ", Post=" + Post
				+ ", State=" + State + ", UserType=" + UserType + ", Description=" + Description + ", Attend=" + Attend
				+ ", isuse=" + isuse + ", joinMode=" + joinMode + ", logo=" + logo + ", registerTime=" + registerTime
				+ ", ApplyDate=" + ApplyDate + ", CompID=" + CompID + ", AdminID=" + AdminID + ", lastLoginTime="
				+ lastLoginTime + "]";
	}
	

}
