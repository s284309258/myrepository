package com.huawang.pojo.company;

import java.util.Date;

/**
   * 企业证书相关
 * @author Administrator
 *
 */
public class CompinfoVOExtend extends CompinfoVO{
	private Integer	ccID; 
	private Integer	CompID;
	private String	CompTrueName;
	private Date	createTime;
	private String	businessLicense;
	private Integer	authStatus;
	public CompinfoVOExtend() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CompinfoVOExtend(String codeno, Integer compID, String compName, String compPassword, String compTrueName,
			Integer adminID, Integer maxUserCount, String lianxr, String lianxrtel, Integer mcuipId,
			Integer maxCurUserCount, String domainName, String compStatus, Date createDate, Date endDate,
			String codePwd, String mcuIp, String headImagePath, String logImagePath, String imageMakdir,
			String lianxrqq, Date maxEnddate, Date contractEndTime, Integer maxConfCount, Integer isDate,
			Integer isAddUser, Integer isConfLogin, String isuse, String belongAgent, Integer compStyle,
			String defualtServer, String allocatAdmin, Integer productID, String createuser, String remark,
			Integer isMeeting, Integer meetingCount, String address, String taxNumber, String sellType,
			Integer TolTimes, Integer useResources, Date registerTime, Integer IsJoinId, String isJoinApprove,
			String email) {
		super(codeno, compID, compName, compPassword, compTrueName, adminID, maxUserCount, lianxr, lianxrtel, mcuipId,
				maxCurUserCount, domainName, compStatus, createDate, endDate, codePwd, mcuIp, headImagePath, logImagePath,
				imageMakdir, lianxrqq, maxEnddate, contractEndTime, maxConfCount, isDate, isAddUser, isConfLogin, isuse,
				belongAgent, compStyle, defualtServer, allocatAdmin, productID, createuser, remark, isMeeting, meetingCount,
				address, taxNumber, sellType, TolTimes, useResources, registerTime, IsJoinId, isJoinApprove, email);
		// TODO Auto-generated constructor stub
	}
	public CompinfoVOExtend(String codeno, Integer compID, String compName, String compPassword, String compTrueName,
			Integer adminID, Integer maxUserCount, String lianxr, String lianxrtel, Integer mcuipId,
			Integer maxCurUserCount, String domainName, String compStatus, Date createDate, Date endDate,
			String codePwd, String mcuIp, String headImagePath, String logImagePath, String imageMakdir,
			String lianxrqq, Date maxEnddate, Date contractEndTime, Integer maxConfCount, Integer isDate,
			Integer isAddUser, Integer isConfLogin, String isuse, String belongAgent, Integer compStyle,
			String defualtServer, String allocatAdmin, Integer productID, String createuser, String remark,
			Integer isMeeting, Integer meetingCount, String address, String taxNumber, String sellType,
			Integer TolTimes, Integer useResources, Date registerTime, Integer IsJoinId, String isJoinApprove,
			String email, Integer ccID, Integer compID2, String compTrueName2, Date createTime, String businessLicense,
			Integer authStatus) {
		super(codeno, compID, compName, compPassword, compTrueName, adminID, maxUserCount, lianxr, lianxrtel, mcuipId,
				maxCurUserCount, domainName, compStatus, createDate, endDate, codePwd, mcuIp, headImagePath,
				logImagePath, imageMakdir, lianxrqq, maxEnddate, contractEndTime, maxConfCount, isDate, isAddUser,
				isConfLogin, isuse, belongAgent, compStyle, defualtServer, allocatAdmin, productID, createuser, remark,
				isMeeting, meetingCount, address, taxNumber, sellType, TolTimes, useResources, registerTime,
				IsJoinId, isJoinApprove, email);
		this.ccID = ccID;
		CompID = compID2;
		CompTrueName = compTrueName2;
		this.createTime = createTime;
		this.businessLicense = businessLicense;
		this.authStatus = authStatus;
	}
	public Integer getCcID() {
		return ccID;
	}
	public void setCcID(Integer ccID) {
		this.ccID = ccID;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public String getCompTrueName() {
		return CompTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		CompTrueName = compTrueName;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getBusinessLicense() {
		return businessLicense;
	}
	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}
	public Integer getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(Integer authStatus) {
		this.authStatus = authStatus;
	}
	@Override
	public String toString() {
		return "CompinfoVOExtend [ccID=" + ccID + ", CompID=" + CompID + ", CompTrueName=" + CompTrueName
				+ ", createTime=" + createTime + ", businessLicense=" + businessLicense + ", authStatus=" + authStatus
				+ ", toString()=" + super.toString() + ", getCodeno()=" + getCodeno() + ", getCompName()="
				+ getCompName() + ", getCompPassword()=" + getCompPassword() + ", getAdminID()=" + getAdminID()
				+ ", getMaxUserCount()=" + getMaxUserCount() + ", getLianxr()=" + getLianxr() + ", getLianxrtel()="
				+ getLianxrtel() + ", getMcuipId()=" + getMcuipId() + ", getMaxCurUserCount()=" + getMaxCurUserCount()
				+ ", getDomainName()=" + getDomainName() + ", getCompStatus()=" + getCompStatus() + ", getCreateDate()="
				+ getCreateDate() + ", getEndDate()=" + getEndDate() + ", getCodePwd()=" + getCodePwd()
				+ ", getMcuIp()=" + getMcuIp() + ", getHeadImagePath()=" + getHeadImagePath() + ", getLogImagePath()="
				+ getLogImagePath() + ", getImageMakdir()=" + getImageMakdir() + ", getLianxrqq()=" + getLianxrqq()
				+ ", getMaxEnddate()=" + getMaxEnddate() + ", getContractEndTime()=" + getContractEndTime()
				+ ", getMaxConfCount()=" + getMaxConfCount() + ", getIsDate()=" + getIsDate() + ", getIsAddUser()="
				+ getIsAddUser() + ", getIsConfLogin()=" + getIsConfLogin() + ", getIsuse()=" + getIsuse()
				+ ", getBelongAgent()=" + getBelongAgent() + ", getCompStyle()=" + getCompStyle()
				+ ", getDefualtServer()=" + getDefualtServer() + ", getAllocatAdmin()=" + getAllocatAdmin()
				+ ", getProductID()=" + getProductID() + ", getCreateuser()=" + getCreateuser() + ", getRemark()="
				+ getRemark() + ", getIsMeeting()=" + getIsMeeting() + ", getMeetingCount()=" + getMeetingCount()
				+ ", getAddress()=" + getAddress() + ", getTaxNumber()=" + getTaxNumber() + ", getSellType()="
				+ getSellType() + ", getTolTimes()=" + getTolTimes() + ", getUseResources()="
				+ getUseResources() + ", getRegisterTime()=" + getRegisterTime() + ", getIsJoinId()=" + getIsJoinId()
				+ ", getIsJoinApprove()=" + getIsJoinApprove() + ", getEmail()=" + getEmail() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
	



}
