package com.huawang.pojo.inter;

/**
 * 参会列表接口vo
 * @author Administrator
 *
 */
public class TAttendUserVo {

	public Integer userId;
	public String confName;
	public String userName;
	public String displayName;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getConfName() {
		return confName;
	}
	public void setConfName(String confName) {
		this.confName = confName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	 
	
	
	
}
