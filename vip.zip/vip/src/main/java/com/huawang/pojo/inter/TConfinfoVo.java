package com.huawang.pojo.inter;

import org.springframework.format.annotation.DateTimeFormat;

public class TConfinfoVo {

	public Integer confId;
	public String confName;
	public String confPwd;
	public String chairPwd;
	public Integer curUserCount;
	//@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String startTime;
	//@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String endTime;
	public String serverIp;
	public String serverName;
	public Integer maxUserCount;
	public String isPublic;
	public String isReservedConf;
	public String isOnOff;

	public String plan;
	public String beginTime;
	public String overTime;
	public Integer adminId;
	public Integer attendCount;
	public String confDesc;
	
	
	public Integer getConfId() {
		return confId;
	}
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	public String getConfName() {
		return confName;
	}
	public void setConfName(String confName) {
		this.confName = confName;
	}
	public String getConfPwd() {
		return confPwd;
	}
	public void setConfPwd(String confPwd) {
		this.confPwd = confPwd;
	}
	public Integer getCurUserCount() {
		return curUserCount;
	}
	public void setCurUserCount(Integer curUserCount) {
		this.curUserCount = curUserCount;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getServerIp() {
		return serverIp;
	}
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public Integer getMaxUserCount() {
		return maxUserCount;
	}
	public void setMaxUserCount(Integer maxUserCount) {
		this.maxUserCount = maxUserCount;
	}
	public String getIsPublic() {
		return isPublic;
	}
	public void setIsPublic(String isPublic) {
		this.isPublic = isPublic;
	}
	public String getIsOnOff() {
		return isOnOff;
	}
	public void setIsOnOff(String isOnOff) {
		this.isOnOff = isOnOff;
	}
	public String getConfDesc() {
		return confDesc;
	}
	public void setConfDesc(String confDesc) {
		this.confDesc = confDesc;
	}
	public String getChairPwd() {
		return chairPwd;
	}
	public void setChairPwd(String chairPwd) {
		this.chairPwd = chairPwd;
	}
	public String getIsReservedConf() {
		return isReservedConf;
	}
	public void setIsReservedConf(String isReservedConf) {
		this.isReservedConf = isReservedConf;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	public String getOverTime() {
		return overTime;
	}
	public void setOverTime(String overTime) {
		this.overTime = overTime;
	}
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public Integer getAttendCount() {
		return attendCount;
	}
	public void setAttendCount(Integer attendCount) {
		this.attendCount = attendCount;
	}
}
