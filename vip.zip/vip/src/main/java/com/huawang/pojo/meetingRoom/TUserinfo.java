package com.huawang.pojo.meetingRoom;

public class TUserinfo {
	  public Integer UserID;
	  public String UserName ;
	  public String UserPassword;
	  public String meetingPwd;
	  public String TelUserName;
	  public String TelUserPassword;
	  public String DisplayName;
	  public Integer UserSex;
	  public String Email;
	  public String Telephone;
	  public Integer AdminID;
	  public Integer OrderIndex;
	  public Integer CompID;
	  public String UserStatus;
	  public Integer DpId;
	  public String ServerIP;
	  public String IsSuper;
	  public Integer CsId;
	  public Integer MsId;
	  public Integer ComGrade;
	  public String Post;
	  public String Status;
	  public String UserType;
	  public String dpName;
	  public String Remark;
	  public String compTrueName;
	  public String CreateTime;
	  public String EndTime;
	  public String isuse;
	  public String State;
	  
	  
	public String getMeetingPwd() {
		return meetingPwd;
	}
	public void setMeetingPwd(String meetingPwd) {
		this.meetingPwd = meetingPwd;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getIsuse() {
		return isuse;
	}
	public void setIsuse(String isuse) {
		this.isuse = isuse;
	}
	public String getCreateTime() {
		return CreateTime;
	}
	public void setCreateTime(String createTime) {
		CreateTime = createTime;
	}
	public String getEndTime() {
		return EndTime;
	}
	public void setEndTime(String endTime) {
		EndTime = endTime;
	}
	
	  
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	public Integer getUserID() {
		return UserID;
	}
	public void setUserID(Integer userID) {
		UserID = userID;
	}
	public String getTelUserName() {
		return TelUserName;
	}
	public void setTelUserName(String telUserName) {
		TelUserName = telUserName;
	}
	public String getTelUserPassword() {
		return TelUserPassword;
	}
	public void setTelUserPassword(String telUserPassword) {
		TelUserPassword = telUserPassword;
	}
	public String getDisplayName() {
		return DisplayName;
	}
	public void setDisplayName(String displayName) {
		DisplayName = displayName;
	}
	public Integer getUserSex() {
		return UserSex;
	}
	public void setUserSex(Integer userSex) {
		UserSex = userSex;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getTelephone() {
		return Telephone;
	}
	public void setTelephone(String telephone) {
		Telephone = telephone;
	}
	public Integer getAdminID() {
		return AdminID;
	}
	public void setAdminID(Integer adminID) {
		AdminID = adminID;
	}
	public Integer getOrderIndex() {
		return OrderIndex;
	}
	public void setOrderIndex(Integer orderIndex) {
		OrderIndex = orderIndex;
	}
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public String getUserStatus() {
		return UserStatus;
	}
	public void setUserStatus(String userStatus) {
		UserStatus = userStatus;
	}
	public Integer getDpId() {
		return DpId;
	}
	public void setDpId(Integer dpId) {
		DpId = dpId;
	}
	public String getServerIP() {
		return ServerIP;
	}
	public void setServerIP(String serverIP) {
		ServerIP = serverIP;
	}
	public String getIsSuper() {
		return IsSuper;
	}
	public void setIsSuper(String isSuper) {
		IsSuper = isSuper;
	}
	public Integer getCsId() {
		return CsId;
	}
	public void setCsId(Integer csId) {
		CsId = csId;
	}
	public Integer getMsId() {
		return MsId;
	}
	public void setMsId(Integer msId) {
		MsId = msId;
	}
	public Integer getComGrade() {
		return ComGrade;
	}
	public void setComGrade(Integer comGrade) {
		ComGrade = comGrade;
	}
	public String getPost() {
		return Post;
	}
	public void setPost(String post) {
		Post = post;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public String getRemark() {
		return Remark;
	}
	public String getDpName() {
		return dpName;
	}
	public void setDpName(String dpName) {
		this.dpName = dpName;
	}
	public void setRemark(String remark) {
		Remark = remark;
	}
	public String getCompTrueName() {
		return compTrueName;
	}
	public void setCompTrueName(String compTrueName) {
		this.compTrueName = compTrueName;
	}
	@Override
	public String toString() {
		return "TUserinfo [UserID=" + UserID + ", UserName=" + UserName + ", UserPassword=" + UserPassword
				+ ", meetingPwd=" + meetingPwd + ", TelUserName=" + TelUserName + ", TelUserPassword=" + TelUserPassword
				+ ", DisplayName=" + DisplayName + ", UserSex=" + UserSex + ", Email=" + Email + ", Telephone="
				+ Telephone + ", AdminID=" + AdminID + ", OrderIndex=" + OrderIndex + ", CompID=" + CompID
				+ ", UserStatus=" + UserStatus + ", DpId=" + DpId + ", ServerIP=" + ServerIP + ", IsSuper=" + IsSuper
				+ ", CsId=" + CsId + ", MsId=" + MsId + ", ComGrade=" + ComGrade + ", Post=" + Post + ", Status="
				+ Status + ", UserType=" + UserType + ", dpName=" + dpName + ", Remark=" + Remark + ", compTrueName="
				+ compTrueName + ", CreateTime=" + CreateTime + ", EndTime=" + EndTime + ", isuse=" + isuse + ", State="
				+ State + "]";
	}
	
	
}
