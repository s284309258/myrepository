package com.huawang.pojo.inter;

/**
 * 参会列表接口vo
 * @author Administrator
 *
 */
public class TConfAttendVo {

	public Integer confId;
	public String confName;
	public String isReservedConf;
	public String startTime;
	public String endTime;
	public String confDesc;
	
	public Integer getConfId() {
		return confId;
	}
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	public String getConfName() {
		return confName;
	}
	public void setConfName(String confName) {
		this.confName = confName;
	}
	public String getIsReservedConf() {
		return isReservedConf;
	}
	public void setIsReservedConf(String isReservedConf) {
		this.isReservedConf = isReservedConf;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getConfDesc() {
		return confDesc;
	}
	public void setConfDesc(String confDesc) {
		this.confDesc = confDesc;
	}
}
