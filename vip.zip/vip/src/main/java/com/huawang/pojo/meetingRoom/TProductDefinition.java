package com.huawang.pojo.meetingRoom;

public class TProductDefinition {

	private String codeNo;
	private String productId;
	private String productStruts;
	/**
	 * 产品名称
	 */
	private String productName;
	/**
	 * 标准布局
	 */
	private String wDefaultUI;
	/**
	 * 主显内容
	 */
	private String wMainDisplayUI;
	/**
	 * 支持显示屏数
	 */
	private String wScreenCount;
	/**
	 * 最大视频码流
	 */
	private String wMaxBitRate;
	/**
	 * 最大广播视频数
	 */
	private String bMaxBroadcastVideos;
	/**
	 * 非主席最大接收视频路数(不包括本地视频)
	 */
	private String bMaxDownVideos;
	/**
	 * 最大视频上行路数
	 */
	private String bMaxUpVideos;
	/**
	 * 主席最大可接视频路数(不包括本地视频)
	 */
	private String bMaxDownVideosOfChiar;
	/**
	 * 最大分辨率
	 */
	private String wMaxResolusionW;
	/**
	 * 最大分辨率
	 */
	private String wMaxResolusionH;
	/**
	 * 最大帧率
	 */
	private String bMaxFrameRate;
	/**
	 * 最大音频同时发言路数
	 */
	private String wMaxDownAudios;
	/**
	 * 共享文档
	 */
	private String  bDocShare;
	/**
	 * 文档同开最大数量
	 */
	private String bMaxOpenDocs;
	/**
	 * 支持白板页数
	 */
	private String bMaxWBPages;
	/**
	 * 屏幕共享
	 */
	private String  bScreenShare;
	/**
	 * 桌面共享
	 */
	private String bDesktopShare;
	/**
	 * 应用程序共享
	 */
	private String bAppShare;
	/**
	 * 远程协助
	 */
	private String bRemoteControl;
	private String bScreenLabel;
	/**
	 * 媒体共享
	 */
	private String bMediaShare;
	private String bWebShare;
	/**
	 * 文字私聊
	 */
	private String bChatP2P;
	/**
	 * 文字公聊
	 */
	private String bChatP2All;
	/**
	 * 支持客户端录制
	 */
	private String bClientRecord;
	private String bServerRecord;
	private String bPSTN;
	private String bH323GW;
	private String bTVWall;
	/**
	 * 支持硬件终端 
	 */
	private String bTerminal;
	/**
	 * 支持ios
	 */
	private String biOS;
	/**
	 * 支持Android
	 */
	private String bAndroid;
	private String bMultiServer;
	private String bVote;
	private String bFileTrans;
	private String bFileCabinet;
	/**
	 * 掌声
	 */
	private String bApplause;
	private String bRinging;
	/**
	 * 语音私聊
	 */
	private String bAudioP2P;
	private String bFreeSpeak;
	/**
	 * 入会自动申请发言
	 */
	private String bAutoSpeek;
	/**
	 * 入会自动观看自己的视频
	 */
	private String bAutoRecvSelfVideo;
	/**
	 * 入会自动广播自己的视频
	 */
	private String bAutoBroadcastSelfVideo;
	private String productDescription;
	/**
	 * 入会主席模式
	 */
	private String ConfMode;
	/**
	 * @return the codeNo
	 */
	public String getCodeNo() {
		return codeNo;
	}
	/**
	 * @param codeNo the codeNo to set
	 */
	public void setCodeNo(String codeNo) {
		this.codeNo = codeNo;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the productStruts
	 */
	public String getProductStruts() {
		return productStruts;
	}
	/**
	 * @param productStruts the productStruts to set
	 */
	public void setProductStruts(String productStruts) {
		this.productStruts = productStruts;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the wDefaultUI
	 */
	public String getwDefaultUI() {
		return wDefaultUI;
	}
	/**
	 * @param wDefaultUI the wDefaultUI to set
	 */
	public void setwDefaultUI(String wDefaultUI) {
		this.wDefaultUI = wDefaultUI;
	}
	/**
	 * @return the wMainDisplayUI
	 */
	public String getwMainDisplayUI() {
		return wMainDisplayUI;
	}
	/**
	 * @param wMainDisplayUI the wMainDisplayUI to set
	 */
	public void setwMainDisplayUI(String wMainDisplayUI) {
		this.wMainDisplayUI = wMainDisplayUI;
	}
	/**
	 * @return the wScreenCount
	 */
	public String getwScreenCount() {
		return wScreenCount;
	}
	/**
	 * @param wScreenCount the wScreenCount to set
	 */
	public void setwScreenCount(String wScreenCount) {
		this.wScreenCount = wScreenCount;
	}
	/**
	 * @return the wMaxBitRate
	 */
	public String getwMaxBitRate() {
		return wMaxBitRate;
	}
	/**
	 * @param wMaxBitRate the wMaxBitRate to set
	 */
	public void setwMaxBitRate(String wMaxBitRate) {
		this.wMaxBitRate = wMaxBitRate;
	}
	/**
	 * @return the bMaxBroadcastVideos
	 */
	public String getbMaxBroadcastVideos() {
		return bMaxBroadcastVideos;
	}
	/**
	 * @param bMaxBroadcastVideos the bMaxBroadcastVideos to set
	 */
	public void setbMaxBroadcastVideos(String bMaxBroadcastVideos) {
		this.bMaxBroadcastVideos = bMaxBroadcastVideos;
	}
	/**
	 * @return the bMaxDownVideos
	 */
	public String getbMaxDownVideos() {
		return bMaxDownVideos;
	}
	/**
	 * @param bMaxDownVideos the bMaxDownVideos to set
	 */
	public void setbMaxDownVideos(String bMaxDownVideos) {
		this.bMaxDownVideos = bMaxDownVideos;
	}
	/**
	 * @return the bMaxUpVideos
	 */
	public String getbMaxUpVideos() {
		return bMaxUpVideos;
	}
	/**
	 * @param bMaxUpVideos the bMaxUpVideos to set
	 */
	public void setbMaxUpVideos(String bMaxUpVideos) {
		this.bMaxUpVideos = bMaxUpVideos;
	}
	/**
	 * @return the bMaxDownVideosOfChiar
	 */
	public String getbMaxDownVideosOfChiar() {
		return bMaxDownVideosOfChiar;
	}
	/**
	 * @param bMaxDownVideosOfChiar the bMaxDownVideosOfChiar to set
	 */
	public void setbMaxDownVideosOfChiar(String bMaxDownVideosOfChiar) {
		this.bMaxDownVideosOfChiar = bMaxDownVideosOfChiar;
	}
	/**
	 * @return the wMaxResolusionW
	 */
	public String getwMaxResolusionW() {
		return wMaxResolusionW;
	}
	/**
	 * @param wMaxResolusionW the wMaxResolusionW to set
	 */
	public void setwMaxResolusionW(String wMaxResolusionW) {
		this.wMaxResolusionW = wMaxResolusionW;
	}
	/**
	 * @return the wMaxResolusionH
	 */
	public String getwMaxResolusionH() {
		return wMaxResolusionH;
	}
	/**
	 * @param wMaxResolusionH the wMaxResolusionH to set
	 */
	public void setwMaxResolusionH(String wMaxResolusionH) {
		this.wMaxResolusionH = wMaxResolusionH;
	}
	/**
	 * @return the bMaxFrameRate
	 */
	public String getbMaxFrameRate() {
		return bMaxFrameRate;
	}
	/**
	 * @param bMaxFrameRate the bMaxFrameRate to set
	 */
	public void setbMaxFrameRate(String bMaxFrameRate) {
		this.bMaxFrameRate = bMaxFrameRate;
	}
	/**
	 * @return the wMaxDownAudios
	 */
	public String getwMaxDownAudios() {
		return wMaxDownAudios;
	}
	/**
	 * @param wMaxDownAudios the wMaxDownAudios to set
	 */
	public void setwMaxDownAudios(String wMaxDownAudios) {
		this.wMaxDownAudios = wMaxDownAudios;
	}
	/**
	 * @return the bDocShare
	 */
	public String getbDocShare() {
		return bDocShare;
	}
	/**
	 * @param bDocShare the bDocShare to set
	 */
	public void setbDocShare(String bDocShare) {
		this.bDocShare = bDocShare;
	}
	/**
	 * @return the bMaxOpenDocs
	 */
	public String getbMaxOpenDocs() {
		return bMaxOpenDocs;
	}
	/**
	 * @param bMaxOpenDocs the bMaxOpenDocs to set
	 */
	public void setbMaxOpenDocs(String bMaxOpenDocs) {
		this.bMaxOpenDocs = bMaxOpenDocs;
	}
	/**
	 * @return the bMaxWBPages
	 */
	public String getbMaxWBPages() {
		return bMaxWBPages;
	}
	/**
	 * @param bMaxWBPages the bMaxWBPages to set
	 */
	public void setbMaxWBPages(String bMaxWBPages) {
		this.bMaxWBPages = bMaxWBPages;
	}
	/**
	 * @return the bScreenShare
	 */
	public String getbScreenShare() {
		return bScreenShare;
	}
	/**
	 * @param bScreenShare the bScreenShare to set
	 */
	public void setbScreenShare(String bScreenShare) {
		this.bScreenShare = bScreenShare;
	}
	/**
	 * @return the bDesktopShare
	 */
	public String getbDesktopShare() {
		return bDesktopShare;
	}
	/**
	 * @param bDesktopShare the bDesktopShare to set
	 */
	public void setbDesktopShare(String bDesktopShare) {
		this.bDesktopShare = bDesktopShare;
	}
	/**
	 * @return the bAppShare
	 */
	public String getbAppShare() {
		return bAppShare;
	}
	/**
	 * @param bAppShare the bAppShare to set
	 */
	public void setbAppShare(String bAppShare) {
		this.bAppShare = bAppShare;
	}
	/**
	 * @return the bRemoteControl
	 */
	public String getbRemoteControl() {
		return bRemoteControl;
	}
	/**
	 * @param bRemoteControl the bRemoteControl to set
	 */
	public void setbRemoteControl(String bRemoteControl) {
		this.bRemoteControl = bRemoteControl;
	}
	/**
	 * @return the bScreenLabel
	 */
	public String getbScreenLabel() {
		return bScreenLabel;
	}
	/**
	 * @param bScreenLabel the bScreenLabel to set
	 */
	public void setbScreenLabel(String bScreenLabel) {
		this.bScreenLabel = bScreenLabel;
	}
	/**
	 * @return the bMediaShare
	 */
	public String getbMediaShare() {
		return bMediaShare;
	}
	/**
	 * @param bMediaShare the bMediaShare to set
	 */
	public void setbMediaShare(String bMediaShare) {
		this.bMediaShare = bMediaShare;
	}
	/**
	 * @return the bWebShare
	 */
	public String getbWebShare() {
		return bWebShare;
	}
	/**
	 * @param bWebShare the bWebShare to set
	 */
	public void setbWebShare(String bWebShare) {
		this.bWebShare = bWebShare;
	}
	/**
	 * @return the bChatP2P
	 */
	public String getbChatP2P() {
		return bChatP2P;
	}
	/**
	 * @param bChatP2P the bChatP2P to set
	 */
	public void setbChatP2P(String bChatP2P) {
		this.bChatP2P = bChatP2P;
	}
	/**
	 * @return the bChatP2All
	 */
	public String getbChatP2All() {
		return bChatP2All;
	}
	/**
	 * @param bChatP2All the bChatP2All to set
	 */
	public void setbChatP2All(String bChatP2All) {
		this.bChatP2All = bChatP2All;
	}
	/**
	 * @return the bClientRecord
	 */
	public String getbClientRecord() {
		return bClientRecord;
	}
	/**
	 * @param bClientRecord the bClientRecord to set
	 */
	public void setbClientRecord(String bClientRecord) {
		this.bClientRecord = bClientRecord;
	}
	/**
	 * @return the bServerRecord
	 */
	public String getbServerRecord() {
		return bServerRecord;
	}
	/**
	 * @param bServerRecord the bServerRecord to set
	 */
	public void setbServerRecord(String bServerRecord) {
		this.bServerRecord = bServerRecord;
	}
	/**
	 * @return the bPSTN
	 */
	public String getbPSTN() {
		return bPSTN;
	}
	/**
	 * @param bPSTN the bPSTN to set
	 */
	public void setbPSTN(String bPSTN) {
		this.bPSTN = bPSTN;
	}
	/**
	 * @return the bH323GW
	 */
	public String getbH323GW() {
		return bH323GW;
	}
	/**
	 * @param bH323GW the bH323GW to set
	 */
	public void setbH323GW(String bH323GW) {
		this.bH323GW = bH323GW;
	}
	/**
	 * @return the bTVWall
	 */
	public String getbTVWall() {
		return bTVWall;
	}
	/**
	 * @param bTVWall the bTVWall to set
	 */
	public void setbTVWall(String bTVWall) {
		this.bTVWall = bTVWall;
	}
	/**
	 * @return the bTerminal
	 */
	public String getbTerminal() {
		return bTerminal;
	}
	/**
	 * @param bTerminal the bTerminal to set
	 */
	public void setbTerminal(String bTerminal) {
		this.bTerminal = bTerminal;
	}
	/**
	 * @return the biOS
	 */
	public String getBiOS() {
		return biOS;
	}
	/**
	 * @param biOS the biOS to set
	 */
	public void setBiOS(String biOS) {
		this.biOS = biOS;
	}
	/**
	 * @return the bAndroid
	 */
	public String getbAndroid() {
		return bAndroid;
	}
	/**
	 * @param bAndroid the bAndroid to set
	 */
	public void setbAndroid(String bAndroid) {
		this.bAndroid = bAndroid;
	}
	/**
	 * @return the bMultiServer
	 */
	public String getbMultiServer() {
		return bMultiServer;
	}
	/**
	 * @param bMultiServer the bMultiServer to set
	 */
	public void setbMultiServer(String bMultiServer) {
		this.bMultiServer = bMultiServer;
	}
	/**
	 * @return the bVote
	 */
	public String getbVote() {
		return bVote;
	}
	/**
	 * @param bVote the bVote to set
	 */
	public void setbVote(String bVote) {
		this.bVote = bVote;
	}
	/**
	 * @return the bFileTrans
	 */
	public String getbFileTrans() {
		return bFileTrans;
	}
	/**
	 * @param bFileTrans the bFileTrans to set
	 */
	public void setbFileTrans(String bFileTrans) {
		this.bFileTrans = bFileTrans;
	}
	/**
	 * @return the bFileCabinet
	 */
	public String getbFileCabinet() {
		return bFileCabinet;
	}
	/**
	 * @param bFileCabinet the bFileCabinet to set
	 */
	public void setbFileCabinet(String bFileCabinet) {
		this.bFileCabinet = bFileCabinet;
	}
	/**
	 * @return the bApplause
	 */
	public String getbApplause() {
		return bApplause;
	}
	/**
	 * @param bApplause the bApplause to set
	 */
	public void setbApplause(String bApplause) {
		this.bApplause = bApplause;
	}
	/**
	 * @return the bRinging
	 */
	public String getbRinging() {
		return bRinging;
	}
	/**
	 * @param bRinging the bRinging to set
	 */
	public void setbRinging(String bRinging) {
		this.bRinging = bRinging;
	}
	/**
	 * @return the bAudioP2P
	 */
	public String getbAudioP2P() {
		return bAudioP2P;
	}
	/**
	 * @param bAudioP2P the bAudioP2P to set
	 */
	public void setbAudioP2P(String bAudioP2P) {
		this.bAudioP2P = bAudioP2P;
	}
	/**
	 * @return the bFreeSpeak
	 */
	public String getbFreeSpeak() {
		return bFreeSpeak;
	}
	/**
	 * @param bFreeSpeak the bFreeSpeak to set
	 */
	public void setbFreeSpeak(String bFreeSpeak) {
		this.bFreeSpeak = bFreeSpeak;
	}
	/**
	 * @return the bAutoSpeek
	 */
	public String getbAutoSpeek() {
		return bAutoSpeek;
	}
	/**
	 * @param bAutoSpeek the bAutoSpeek to set
	 */
	public void setbAutoSpeek(String bAutoSpeek) {
		this.bAutoSpeek = bAutoSpeek;
	}
	/**
	 * @return the bAutoRecvSelfVideo
	 */
	public String getbAutoRecvSelfVideo() {
		return bAutoRecvSelfVideo;
	}
	/**
	 * @param bAutoRecvSelfVideo the bAutoRecvSelfVideo to set
	 */
	public void setbAutoRecvSelfVideo(String bAutoRecvSelfVideo) {
		this.bAutoRecvSelfVideo = bAutoRecvSelfVideo;
	}
	/**
	 * @return the bAutoBroadcastSelfVideo
	 */
	public String getbAutoBroadcastSelfVideo() {
		return bAutoBroadcastSelfVideo;
	}
	/**
	 * @param bAutoBroadcastSelfVideo the bAutoBroadcastSelfVideo to set
	 */
	public void setbAutoBroadcastSelfVideo(String bAutoBroadcastSelfVideo) {
		this.bAutoBroadcastSelfVideo = bAutoBroadcastSelfVideo;
	}
	/**
	 * @return the productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}
	/**
	 * @param productDescription the productDescription to set
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	/**
	 * @return the confMode
	 */
	public String getConfMode() {
		return ConfMode;
	}
	/**
	 * @param confMode the confMode to set
	 */
	public void setConfMode(String confMode) {
		ConfMode = confMode;
	}
	
}
