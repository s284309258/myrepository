package com.huawang.pojo.meetingRoom;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class TAdmininfo {

	private String codeno;
	private Integer adminId;
	private String adminName;
	private String adminPassword;
	private String adminTrueName;
	private String adminIsSuper;
	private String compID;
	private String adminID;
	
	public String getAdminID() {
		return adminID;
	}
	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}
	public String getCompID() {
		return compID;
	}
	public void setCompID(String compID) {
		this.compID = compID;
	}
	/**
	 * @return the codeno
	 */
	public String getCodeno() {
		return codeno;
	}
	/**
	 * @param codeno the codeno to set
	 */
	public void setCodeno(String codeno) {
		this.codeno = codeno;
	}
	/**
	 * @return the adminId
	 */
	public Integer getAdminId() {
		return adminId;
	}
	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	/**
	 * @return the adminName
	 */
	public String getAdminName() {
		return adminName;
	}
	/**
	 * @param adminName the adminName to set
	 */
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	/**
	 * @return the adminPassword
	 */
	public String getAdminPassword() {
		return adminPassword;
	}
	/**
	 * @param adminPassword the adminPassword to set
	 */
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	/**
	 * @return the adminTrueName
	 */
	public String getAdminTrueName() {
		return adminTrueName;
	}
	/**
	 * @param adminTrueName the adminTrueName to set
	 */
	public void setAdminTrueName(String adminTrueName) {
		this.adminTrueName = adminTrueName;
	}
	/**
	 * @return the adminIsSuper
	 */
	public String getAdminIsSuper() {
		return adminIsSuper;
	}
	/**
	 * @param adminIsSuper the adminIsSuper to set
	 */
	public void setAdminIsSuper(String adminIsSuper) {
		this.adminIsSuper = adminIsSuper;
	}
	
	
}
