package com.huawang.filter;

import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/*
 * 增加XSS过滤
 * 自定义的RequestWrapper中，对getParameter和getParameterValues进行重写，从而达到对各个用户输入的form参数的值进行过滤
 */
public class RequestWrapper extends HttpServletRequestWrapper {
	
	private
	Map<String, String> xssMap;
	 
	public RequestWrapper(HttpServletRequest request) {
		super(request);
	}
	
	public RequestWrapper(HttpServletRequest request,Map<String, String> xssMap) {
	    super(request);
	    this.xssMap = xssMap;
	}
	
	@Override

    public String[] getParameterValues(String parameter) {

        String[] values = super.getParameterValues(parameter);

        if(values == null) {
            return null;
        }

        int count = values.length;

        // 遍历每一个参数，检查是否含有

        String[] encodedValues = new String[count];

        for (int i = 0; i < count; i++) {

            encodedValues[i] = cleanXSS(values[i]);
        }
        return encodedValues;

    }
	
	/**

      * 清除恶意的XSS脚本

     *

     * @param value

     * @return

     */

    private String cleanXSS(String value) {

        Set<String> keySet = xssMap.keySet();

        for(String key : keySet){

            String v = xssMap.get(key);

            value = value.replaceAll(key,v);

        }

        return value;

    }

	
	
}
