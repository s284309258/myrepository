package com.huawang.controller.userLogin;
 
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.util.DateUtil;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/login")
public class loginController {
 
	@RequestMapping(value="/loginUser",method= {RequestMethod.POST,RequestMethod.GET})
	public String loginUser(HttpServletRequest request,HttpSession session,HttpServletResponse response,TUserinfo tUserInfo) {
		return "index/index";
	}
	
	
	@RequestMapping(value="/userLogin",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String userLogin(HttpServletRequest request,HttpSession session,HttpServletResponse response,TUserinfo tUserInfo) throws Exception {
		
		String pyzm = (String)request.getSession().getAttribute("ccode");
		String checkcode = request.getParameter("checkcode");
		JSONObject json = new JSONObject();
		String message ="";
		String meetPwd = tUserInfo.getUserPassword();
		String pwd = SecurityUtil.encryptMD5(tUserInfo.UserPassword);
		if(!pyzm.equals(checkcode))
		{
			json.put("message", 1);
			return json.toString();
		}
		
		String sql ="select t.UserID,t.UserName,t.UserPassword,t.TelUserName,t.TelUserPassword,t.DisplayName,t.UserSex,Email," + 
				"		t.Telephone,t.AdminID,t.OrderIndex,t.CompID,t.UserStatus,t.DpId,(select DpName from t_department where DpId =t.DpId)AS dpName," + 
				"t.ServerIP,t.IsSuper,t.CsId,t.MsId,t.ComGrade,t.Post,t.State,t.UserType,t.Description,t.CreateTime,t.EndTime,t.isuse from t_userinfo t where binary t.UserName= '"+tUserInfo.UserName+"'";

		ArrayList<Object> LoginUser = Sqlca.getArrayListFromObj(sql, TUserinfo.class);
		if(LoginUser.size()==0)
		{
			json.put("message", 4);
			return json.toString();
		}
		TUserinfo User = (TUserinfo)LoginUser.get(0);
		
		if(!pwd.equals(User.UserPassword))
		{
			json.put("message", 2);
			return json.toString();
		}
		if(!"".equals(User.EndTime) && null!=User.EndTime && !"0000-00-00 00:00:00".equals(User.EndTime))
		{
			String currdate = DateUtil.dateFormat(0);
			if(User.EndTime.compareTo(currdate)<0)
			{
				json.put("message", 5);
				return json.toString();
			}
		}
		String compTrueNamesql = "select t.CompTrueName from t_compinfo t where t.CompID="+User.CompID;
		String compTrueName = Sqlca.getString(compTrueNamesql);
		User.setCompTrueName(compTrueName);
		String statussql = "select t.CompStatus from t_compinfo t where t.CompID="+User.CompID;
		String status = Sqlca.getString(statussql);
		
		/*if("6".equals(status))
		{
			json.put("message", 6);
			return json.toString();
		}*/
		if("8".equals(status))
		{
			json.put("message", 8);
			return json.toString();
		}
		
		if("0".equals(User.isuse))
		{
			json.put("message", 0);
			return json.toString();
		}
		
		if("1".equals(User.State))
		{
			json.put("message", 9);
			return json.toString();
		}
		
		
		
		//记住密码
		String remember = request.getParameter("remember");
		if("yes".equals(remember))
		{
			Cookie ckremember = new Cookie("HWremember","yes");
			ckremember.setPath(request.getContextPath());
			ckremember.setMaxAge(600*600*100);
			response.addCookie(ckremember);
			
			Cookie ckname = new Cookie("HWUserName",tUserInfo.UserName);
			ckname.setPath(request.getContextPath());
			ckname.setMaxAge(600*600*100);
			response.addCookie(ckname);
			
			Cookie ckpwd = new Cookie("HWUserPassword",tUserInfo.UserPassword);
			ckpwd.setPath(request.getContextPath());
			ckpwd.setMaxAge(600*600*100);
			response.addCookie(ckpwd);
		}
		else
		{
			Cookie[] cks = request.getCookies();
			if(cks!=null)
			{
				for(Cookie c : cks)
				{
					if("HWremember".equals(c.getName()) || "HWUserName".equals(c.getName()) || "HWUserPassword".equals(c.getName()))
					{
						c.setMaxAge(0);
						c.setValue("");
						c.setPath(request.getContextPath());
						response.addCookie(c);
					}
				}
			}
		}
		User.setMeetingPwd(meetPwd);
		session.setAttribute("USER_VIPSESSION",User);
		json.put("message", "3");
		return json.toString();
	}
	
	@RequestMapping(value="vipLogin")
	public ModelAndView vipLogin(HttpServletRequest request,HttpSession session,HttpServletResponse response)  throws Exception
	{
		String cid = (String)request.getParameter("cid");
		
		String compname = Sqlca.getString("select CompName from t_compinfo where CompID="+cid);
		String sql =
				"select t.UserID,t.UserName,t.UserPassword,t.TelUserName,t.TelUserPassword,t.DisplayName,t.UserSex,t.Email,"+
				"t.Telephone,t.AdminID,t.OrderIndex,t.CompID,t.UserStatus,t.DpId,(select DpName from t_department  where DpId =t.DpId)AS dpName,t.ServerIP,t.IsSuper,t.CsId,t.MsId,t.ComGrade,t.Post,"+
				"t.State,t.UserType,t.Description from t_userinfo t where t.UserName='"+compname+"'";
				ArrayList<Object> LoginUser = Sqlca.getArrayListFromObj(sql, TUserinfo.class);
				
		session.setAttribute("USER_VIPSESSION",LoginUser.get(0));
		
		ModelAndView view = new ModelAndView("index/index");
		
		return view;
				
	}
	
	@RequestMapping(value="/userLoginOut",method= {RequestMethod.POST,RequestMethod.GET}) 
	public void userLoginOut(HttpServletRequest request, HttpServletResponse response,HttpSession session,Model model) throws IOException {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		TUserinfo user = null;
        if(obj!=null) {
      	   user = (TUserinfo)obj;
      	   String userName = user.getUserName();
      	   session.removeAttribute(userName);
        }
        session.invalidate();
        System.out.println("redirect:"+request.getContextPath());
        response.sendRedirect("/");
	}
	
	@RequestMapping(value="/qiutOut")
	public String qiutOut(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		System.out.println("redirect:"+request.getContextPath());
         return "jsp/index/path";
	}
	
	
	
}

















