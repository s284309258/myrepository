package com.huawang.controller.meetingRoom;
 
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.huawang.controller.userManager.UserManagerController;
import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.dao.organization.OrganizationDao;
import com.huawang.dao.organization.UserDao;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.pojo.meetingRoom.TConfusersVO;
import com.huawang.pojo.meetingRoom.TLogConfDetail;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.result.Page;
import com.huawang.pojo.result.Result;
import com.huawang.util.ExcelUtil;
import com.huawang.util.Sqlca;
import com.huawang.util.httpClient;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONArray;
 

@Controller
@RequestMapping(value="/meeting")
public class meetRoomController {
	/**
	 * 临时表命名：前缀+userID 如：temp_confusers_01
	 */
	private static final String TEMP_TABLE_NAME_PRE="temp_confusers_";
	static Logger logger = LogManager.getLogger(meetRoomController.class.getName());
	@Autowired
	private MeetingRoomDao meetingRoomDao;
	@Autowired
	private  UserDao userDao;
	@Autowired
	private  OrganizationDao organizationDao;
	
	@RequestMapping(value="/AttendMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	public String AttendMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
		
		return "meetList/joinMeeting";
	}
	
		public static int compare_date(String DATE1, String DATE2) {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		        try {
		            Date dt1 = df.parse(DATE1);
		            Date dt2 = df.parse(DATE2);
		            
		            if (dt1.getTime() > dt2.getTime()) {
		                System.out.println("dt1 在dt2前");
		                return 1;
		            } else if (dt1.getTime() < dt2.getTime()) {
		                System.out.println("dt1在dt2后");
		                return -1;
		            } else {
		                return 0;
		            }
		        } catch (Exception exception) {
		            exception.printStackTrace();
		        }
		        return 0;
		    }
	
	
	/*
	 *	参会列表
	 */
	@RequestMapping(value="/AttendMeetingMap")
	@ResponseBody
	public Map<String, Object>AttendMeetingMap(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int compId = tUser.getCompID();
		int userID = tUser.getUserID();
		String curUserIsSuper=tUser.getIsSuper();
		Integer curUserDpId=tUser.getDpId();
		confinfo.setCompId(compId);
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");//设置日期格式
		String date = df1.format(new Date());
		
		String sqlId ="select t1.EndTime AS endTime,t1.ConfID AS confId,t1.IsReservedConf AS isReservedConf  from t_confinfo t1  LEFT JOIN t_compinfo t2 ON t1.CompID =t2.CompID LEFT JOIN t_confusers t3 ON t1.ConfID = t3.ConfID " ;
				
		
		
		StringBuilder sqlIdBuilder = new StringBuilder();
		sqlIdBuilder.append(sqlId);
		if("2".equals(curUserIsSuper)) {
			sqlIdBuilder.append(" LEFT JOIN t_userinfo tu on tu.UserID = t1.AdminID");
			sqlIdBuilder.append(" WHERE 1 = 1 and t1.IsOnOff=1 and t1.CompID= " + compId +" and t3.UserID ="+userID+" and tu.dpid="+curUserDpId);
		}else {
			sqlIdBuilder.append(" WHERE 1 = 1 and t1.IsOnOff=1 and t1.CompID= " + compId +" and t3.UserID ="+userID);
		}
				
				
		List<Object> obj1 = Sqlca.getArrayListFromObj(sqlIdBuilder.toString(), TConfinfo.class);
		
		StringBuffer dd = new StringBuffer();
		String	ss ="";
		for (Object tConfinfo1 : obj1) {
			String isReservered = ((TConfinfo) tConfinfo1).getIsReservedConf()==null?"":((TConfinfo) tConfinfo1).getIsReservedConf();
			if(isReservered.equals("1")) {
				String endTime = ((TConfinfo) tConfinfo1).getEndTime();
				int day = compare_date(endTime, date); 
				if(day==1) {
					int confId = ((TConfinfo) tConfinfo1).getConfId();
					dd.append(confId).append(",");
				}
			}else {
				int confId = ((TConfinfo) tConfinfo1).getConfId();
				dd.append(confId).append(",");
			}
		} 
		if(dd.length()>0) {
			ss = dd.toString().substring(0, dd.toString().length()-1);
		}else {
			ss="0";
		}
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		Map<String, Object> map = new HashMap<String,Object>();
		String sql ="SELECT  t1.IsPublic AS isPublic,t1.MaxUserCount AS maxUserCount,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.ConfID AS confId,t1.ConfID AS ids," + 
				"t1.confName AS confName,t1.CurUserCount AS curUserCount,(select COUNT(*) from t_confusers where ConfID =t1.ConfID AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"')) AS confCount," + 
				"t1.ConfDesc AS confDesc,t1.IsReservedConf AS isReservedConf  " + 
				"from     t_confinfo t1 where 1=1 and t1.ConfID IN ("+ss+") ";
		 
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue;
		}
		sql+="  limit "+i+","+rows+"";
		
		List<Object> obj = Sqlca.getArrayListFromObj(sql, TConfinfo.class);
		String total = "SELECT  count(*) from  t_confinfo t1 where 1=1 and t1.ConfID IN ("+ss+")";
		total = Sqlca.getString(total);
		
		for (Object tConfinfo : obj) { 
			String isReservered = ((TConfinfo) tConfinfo).getIsReservedConf()==null?"":((TConfinfo) tConfinfo).getIsReservedConf();
			if(isReservered.equals("0")) {
				((TConfinfo) tConfinfo).setIsReservedConf("固定");
				((TConfinfo) tConfinfo).setStartTime("无");
			}else if(isReservered.equals("2")) {
				((TConfinfo) tConfinfo).setStartTime("无");
				((TConfinfo) tConfinfo).setIsReservedConf("周例会");
			}else if(isReservered.equals("1")) {
				String endTime=""; String startTime="";
				endTime = ((TConfinfo) tConfinfo).getEndTime();
				startTime =((TConfinfo) tConfinfo).getStartTime();
				String type="1";
				Long hour = StringToDate(endTime, startTime,type);
				((TConfinfo) tConfinfo).setIsReservedConf(hour.toString()+"h");
			}
		}
		map.put("total", total);
		map.put("rows", obj);
		return map;
	} 
	public static long StringToDate(String endDate, String nowDate,String type) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date1 = sdf.parse(endDate);
		Date date2 = sdf.parse(nowDate);
		
		long nd = 1000 * 24 * 60 * 60;
	    long nh = 1000 * 60 * 60;
	    long nm = 1000 * 60;
	    // 获得两个时间的毫秒时间差异
	    long diff = date1.getTime() - date2.getTime();
	    // 计算差多少天
	    long day = diff / nd;
	    // 计算差多少小时
	    long hour = diff % nd / nh;
	    // 计算差多少分钟
	    long min = diff % nd % nh / nm;
	    
	    if(type.equals("1")) {
	    	hour =day*24+hour;
	    }else {
	    	hour =day*24*60+hour*60+min;
	    }
		return hour;
	}
	
	/**
	 * 	查询会议室类型
	 * @param request
	 * @param response
	 * @param tconfinfo
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/joinMeetingPanel",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String joinMeetingPanel(HttpServletRequest request,HttpServletResponse response,TConfinfo tconfinfo) throws Exception {
		
		int confId = Integer.parseInt(request.getParameter("confId"));
		String sql ="select t.ConfName AS confName,t.ConfPwd AS confPwd,t1.ServerIP AS serverIp,t.IsPublic AS isPublic,"
				+ "t.IsReservedConf AS isReservedConf,t.StartTime AS startTime from t_confinfo t LEFT JOIN t_serverinfo t1 on t.ServerId =t1.ServerID" + 
				"		 where t.ConfID ="+confId;
		
		List<Object> list = Sqlca.getArrayListFromObj(sql, TConfinfo.class);
		String confName="";String startTime="";String IsPublic="";
		String IsReservedConf="";
		for (Object confinfo1 : list) {
			TConfinfo tt = (TConfinfo)confinfo1;
			confName = tt.getConfName();
			startTime = tt.getStartTime();
			IsPublic =tt.getIsPublic();//0呢称加密 1 呢称不加密 2账号加密
			IsReservedConf =tt.getIsReservedConf();//0、长期 1预约 2周例会
		}
		JSONObject json = new JSONObject();
		json.put("startTime", startTime);
		json.put("IsPublic", IsPublic);
		json.put("IsReservedConf", IsReservedConf);
		json.put("confName", confName);
		
		return json.toString();
	}
	
	
	/**
	 * 	参加列表参加会议
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/joinMeetingById",method= {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=Latin1")
	public String joinMeetingById(HttpServletRequest request,HttpServletResponse response,TConfinfo tconfinfo) throws Exception {
		
		//参数说明：//ip：IP地址  //name:会议号呢称/用户名 //pwd:密码 //confid：会议号//type:类型账号登录：0；会议号登录：2
		//账号登录 ：    videoconf://ip=120.78.200.162&name=lzy555&pwd=123456&confid=13882&type=0/
		//会议号登录： videoconf://ip=192.168.5.196&name=123123&pwd=123&confid=26&type=2/
		//com.huawang.util.IPAddress ipAddress = new  com.huawang.util.IPAddress();
		//String IP = ipAddress.getIpAddress(request);	//获取访客ip
		//String account =request.getParameter("account");//账号登录
		//String acountPwd =request.getParameter("acountPwd");//账号密码
		
		
		int confId = Integer.parseInt(request.getParameter("confId"));
		TConfinfo confinfo = meetingRoomDao.getConfPwd(confId);
		String userName="";String pwd ="";
		String sql =" SELECT (SELECT serverIp FROM t_serverinfo WHERE ServerId =t.ServerId) AS serverIp  FROM t_confinfo t WHERE t.ConfID = "+confId+"";
		String ipaddress = Sqlca.getString(sql)==null?"":Sqlca.getString(sql);				
		String type= request.getParameter("type");
		JSONObject json = new JSONObject();
		
		if(type.equals("2")) {
			ipaddress = confinfo.getServerIp();
			json.put("pwd", confinfo.getConfPwd());
		}else {
			HttpSession session = request.getSession();
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			userName =tUser.getUserName();
			userName =URLEncoder.encode(userName, "utf-8");
			pwd =tUser.getMeetingPwd(); 
			json.put("name", userName);
			json.put("pwd", pwd);
		}
		json.put("ip", ipaddress);
		json.put("confid", confId);
        response.getWriter().write(json.toString());
        response.getWriter().flush();
        response.getWriter().close();
		return null;
	}
	
	
	@RequestMapping(value="/meetingManager",method= {RequestMethod.POST,RequestMethod.GET})
	public String meetingManager(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) {
		/*
			String size = request.getParameter("size")==null?"0":request.getParameter("size");
			if(Integer.parseInt(size)<1) {
				size="20";
			}else {
				size = request.getParameter("size");
			}
		model.addAttribute("size",size);*/
		return "meetingManager/meetManager";
	}
	
	/**
	 * 	会议管理列表
	 * @param request
	 * @param confinfo
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/meetingManagerMap")
	@ResponseBody
	public Map<String, Object> meetingManagerMap(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String compId = tUser.getCompID().toString();
		Integer userID = tUser.getUserID();
		Integer dpId=tUser.getDpId();
		String isSuper=tUser.getIsSuper();
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows); 
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		Map<String, Object> map = new HashMap<String,Object>();
		StringBuilder buffer = new StringBuilder(" SELECT (select DpId from t_userinfo where UserID=t1.AdminID)as DpId,t1.IsAll as isAll,t1.ConfID AS confId,t1.ConfID AS ids,t1.confName AS confName, t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
				"			t1.IsPublic AS isPublic,t1.CurUserCount AS curUserCount,t1.IsOnOff AS isOnOff,t2.ServerName AS serverName,t2.ServerIP AS serverIp,(select COUNT(*) from t_confusers where ConfID =t1.ConfID AND userID not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"')) as confCount," + 
				"			t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan,t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime " + 
				"			from t_confinfo t1  LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID  LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID ");
		
	
		
		String total = "SELECT count(1) from t_confinfo t1 " + 
				"			LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID " + 
				"			LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID " ;
				
		StringBuilder buids = new StringBuilder();
		buids.append(total);
		
		//部门管理员
		if("2".equals(isSuper)) {
			buffer.append(" LEFT JOIN t_userinfo tu on tu.UserID = t1.AdminID  WHERE  t1.CompID = "+compId+" and tu.DpId="+dpId);
			buids.append(" LEFT JOIN t_userinfo tu on tu.UserID = t1.AdminID  WHERE  t1.CompID = "+compId+" and tu.DpId="+dpId);
		}else {
			buffer.append(" WHERE t1.CompID = "+compId);
			buids.append(" WHERE t1.CompID = "+compId);
		}
		
		if(confinfo.confName!=null &&confinfo.confName!="") {
			buffer.append(" and t1.confName LIKE '%"+confinfo.confName+"%'");
			buids.append(" and t1.confName LIKE '%"+confinfo.confName+"%'");
		}
		if(confinfo.isReservedConf!=null && confinfo.isReservedConf!="") {
			buffer.append(" and t1.IsReservedConf = '"+confinfo.isReservedConf+"'");
			buids.append(" and t1.IsReservedConf = '"+confinfo.isReservedConf+"'");
		}
		if(confinfo.isOnOff!=null&&confinfo.isOnOff!="") {
			buffer.append(" and t1.isOnOff = '"+confinfo.isOnOff+"'");
			buids.append(" and t1.isOnOff = '"+confinfo.isOnOff+"'");
		} 
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			buffer.append(" order by "+SortName+" "+SortValue+" limit "+i+","+rows);
		}
		else
		{
			buffer.append( " limit "+i+","+rows);
		}
		
		List<Object> obj = Sqlca.getArrayListFromObj(buffer.toString(), TConfinfo.class);
		total = Sqlca.getString(buids.toString());
		
		for (Object tConfinfo : obj) {
			String isPublic = ((TConfinfo) tConfinfo).getIsPublic()==null?"":((TConfinfo) tConfinfo).getIsPublic();
			if(isPublic.equals("0")) {
				isPublic="昵称密码";
			}else if(isPublic.equals("1")) {
				isPublic="昵称免密";
			}else {
				isPublic="仅账号";
			}
			((TConfinfo) tConfinfo).setIsPublic(isPublic);
			String isReservedConf =((TConfinfo) tConfinfo).getIsReservedConf()==null?"":((TConfinfo) tConfinfo).getIsReservedConf();
			if(isReservedConf.equals("0")) {
				isReservedConf="长期会议";
			}else if(isReservedConf.equals("1")) {
				isReservedConf="预约会议";
			}else {
				isReservedConf="周期会议";
			}
			((TConfinfo) tConfinfo).setIsReservedConf(isReservedConf);
			String isOnOff = ((TConfinfo) tConfinfo).getIsOnOff()==null?"":((TConfinfo) tConfinfo).getIsOnOff();
			if(isOnOff.equals("0")) {
				isOnOff="停止";
			}else {
				isOnOff="启用";
			}((TConfinfo) tConfinfo).setIsOnOff(isOnOff);
		}
		map.put("total", total);
		map.put("rows", obj);
		return map;
	}
	
	/**
	 *	 进入新建会议室界面
	 * @param request
	 * @param confinfo
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	public String comeAddMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) throws Exception {
		HttpSession session = request.getSession();
		TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String sql ="select t2.ProductName,t1.CompTrueName from t_userinfo t " + 
				"			 LEFT JOIN t_compinfo t1 on t.CompID =t1.CompID" + 
				"			 LEFT JOIN t_product_definition t2 on t1.ProductId = t2.ProductId" + 
				"		where t.UserName = '"+tAdmin.getUserName()+"'";
		String productName = Sqlca.getString(sql);
		confinfo.setProductName(productName); 
		model.addAttribute("confinfo", confinfo);
		return "meetingManager/addMeeting";
	}
	/**
	 * 	添加会议室
	 * @param request
	 * @param confinfo
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/saveAddMeet",method=RequestMethod.POST)
	@ResponseBody
	public String saveAddMeet(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
		
		HttpSession session = request.getSession();
		TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		confinfo.setCompId(tAdmin.getCompID());
		
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");//设置日期格式
		String date = df1.format(new Date());
		String message = "0";
		if(confinfo.getStartTime()=="") {
			confinfo.setStartTime(date);
		} 
		String confName =request.getParameter("confName").trim();
		String confDesc =request.getParameter("confDesc");
		
		StringBuilder budider = new StringBuilder("SELECT count(1) from  t_confinfo t  WHERE 1 = 1  and t.ConfName ='"+confName+"'");
		String userCount = Sqlca.getString(budider.toString());//判断是否重名

		TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(tAdmin.getCompID());
		int maxUserCount = compinfo.getMaxUserCount();
		int mcuIpId = Integer.parseInt(compinfo.getMcuIpId());
		int productId = compinfo.getProductId();
		String endTime =request.getParameter("endTime");
		String isAll=request.getParameter("isAll");
		
		String sql ="";
		if(endTime==null||endTime=="") {
			sql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,ConfDesc,AdminID," + 
					"			IsPublic,ParentConfID,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,plan,BeginTime,overTime)VALUES("
					+ "0,?,"
					+ "		'"+confinfo.confPwd+"'," + 
					"		'"+confinfo.telConfName+"'," + 
					"		'"+confinfo.maxUserCount+"'," + 
					"			0," + 
					"		0," + 
					"		'"+confinfo.mCUIP+"'," + 
					"		'"+confinfo.startTime+"'," + 
					"		?," + 
					"			0," +  
					"		'"+confinfo.isPublic+"'," + 
					"			0," + 
					"		'"+confinfo.isOnOff+"'," + 
					"		'"+confinfo.compId+"'," + 
					"		'"+confinfo.chairPwd+"'," + 
					"		'"+productId+"'," + 
					"		'"+mcuIpId+"'," + 
					"		'"+confinfo.isReservedConf+"'," + 
					"		'"+confinfo.isAll+"'," + 
					"		'"+confinfo.plan+"'," + 
					"		'"+confinfo.beginTime+"'," + 
					"		'"+confinfo.overTime+"'" + 
					"			)";
		}else { 
			sql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,EndTime,ConfDesc,AdminID," + 
					"		IsPublic,ParentConfID,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,plan,BeginTime,overTime)VALUES("
					+ "0,?,"
					+ "		'"+confinfo.confPwd+"'," + 
					"		'"+confinfo.telConfName+"'," + 
					"		'"+confinfo.maxUserCount+"'," + 
					"			0," + 
					"		0," + 
					"		'"+confinfo.mCUIP+"'," + 
					"		'"+confinfo.startTime+"'," + 
					"		'"+confinfo.endTime+"'," + 
					"		?," + 
					"			0," +  
					"		'"+confinfo.isPublic+"'," + 
					"			0," + 
					"		'"+confinfo.isOnOff+"'," + 
					"		'"+confinfo.compId+"'," + 
					"		'"+confinfo.chairPwd+"'," + 
					"		'"+productId+"'," + 
					"		'"+mcuIpId+"'," + 
					"		'"+confinfo.isReservedConf+"'," + 
					"		'"+confinfo.isAll+"'," + 
					"		'"+confinfo.plan+"'," + 
					"		'"+confinfo.beginTime+"'," + 
					"		'"+confinfo.overTime+"'" + 
					"			)";
			}
		  
		int isMeeting = compinfo.getIsMeeting();//是否控制人数  0、不控制 1、控制  
		int meetingCount =compinfo.getMeetingCount(); //控制创建同时间段 会议室的个数 0、不控制 1 、2表示 --1个、2个
		
		if(confinfo.getIsReservedConf().equals("1")) {
			SimpleDateFormat confTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
			Date startt = confTime.parse(confinfo.getStartTime());
			Date endtt = confTime.parse(confinfo.getEndTime());

		List<TConfinfo> confinfoMation = meetingRoomDao.selectConfinfoList(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt,confinfo.getConfId());//获取预约会议室信息判断 是否允许创建同时间段多个
		String confSum="0";//参会总数
		StringBuffer dd = new StringBuffer();
		String ss ="";
		if(confinfoMation.size()>0) {
				if(meetingCount>0 && isMeeting==0) {//控制个数
					int confinfoCount1 =meetingRoomDao.selectConfinfoCount(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt);
					if(confinfoCount1>=meetingCount) {
						message="3";//message="您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！";
					}
				}
				if(meetingCount==0 && isMeeting==1) {//控制人数您所在的企业的人数
					for (TConfinfo tconfinfo : confinfoMation) { 
						dd.append(tconfinfo.getConfId().toString()).append(",");
					}
					if(dd.length()>0) {
						ss = dd.toString().substring(0, dd.toString().length()-1);
					}else {
						ss="0";
					}
					confSum = Sqlca.getString("SELECT sum(MaxUserCount) FROM t_confinfo WHERE ConfID in("+ss+")");
					
					int remainCount = maxUserCount-(Integer.parseInt(confSum)+confinfo.getMaxUserCount());
					if(remainCount<0) {
						message="4";//message = "您的企业并发点已不足，如需继续请更换时间点或修改最大用户数";
					}
					
				}
				if(meetingCount>0 && isMeeting==1) {// 控制人数和个数
					int confinfoCount =meetingRoomDao.selectConfinfoCount(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt);
						if(confinfoCount>=meetingCount) {
							message="3";//message="您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！";
						}
					if(confinfoMation.size()>0){
						for (TConfinfo tconfinfo : confinfoMation) { 
							dd.append(tconfinfo.getConfId().toString()).append(",");
						}
						if(dd.length()>0) {
							ss = dd.toString().substring(0, dd.toString().length()-1);
						}else {
							ss="0";
						}
						confSum = Sqlca.getString("SELECT sum(MaxUserCount) FROM t_confinfo WHERE ConfID in("+ss+")");
					}
					int remainCount = maxUserCount-(Integer.parseInt(confSum)+confinfo.getMaxUserCount());
					if(remainCount<0) {
						message="4";//message = "您的企业并发点已不足，如需继续请更换时间点或修改最大用户数";
					}
				}
			} 
		}else {
			message="0";
		}
		if(Integer.parseInt(message)>1) {
			if(Integer.parseInt(message)==3 ||Integer.parseInt(message)==4 ) {
				if(Integer.parseInt(message)==3) {
					message="limit";//您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！
				}else {
					message="over"; //您的企业并发点已不足，如需继续请更换时间点或修改最大用户数
				}
			}
		}else if(Integer.parseInt(userCount)>0) {
			message="rename";
		}else if(maxUserCount<confinfo.getMaxUserCount()) {
			message="out";
		}else{
			int count = Sqlca.updateObject(sql, new String[] {confName,confDesc});
			if(count>0) {
				message="success";
			}else {
				message="fail";
			}
		}
		return message;
	}
	
	 
	
	/**
	 * 	查看会议修改信息
	 * @param request
	 * @param confinfo
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editMeeting",method=RequestMethod.GET)
	public String editMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) throws Exception {
		HttpSession session = request.getSession();
		int confId = confinfo.getConfId();
		String sqlUser =" SELECT t1.IsAll AS isAll,t1.ConfID AS confId,t1.confName AS confName,t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
				"			t1.IsPublic AS isPublic,t1.IsOnOff AS isOnOff,t1.Plan as plan,t2.ServerName AS serverName,t2.ServerIP AS serverIp," + 
				"			t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan," + 
				"			t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime" + 
				"			from t_confinfo t1 LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID" + 
				"		     LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID" + 
				"		WHERE 1 = 1  and t1.ConfID ="+confId;
	 
		List<Object> list = Sqlca.getArrayListFromObj(sqlUser, TConfinfo.class);
		
		TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		
		String sql ="select t2.ProductName,t1.CompTrueName from t_userinfo t " + 
				"			 LEFT JOIN t_compinfo t1 on t.CompID =t1.CompID" + 
				"			 LEFT JOIN t_product_definition t2 on t1.ProductId = t2.ProductId" + 
				"		where t.UserName = '"+tAdmin.getUserName()+"'";
		String productName = Sqlca.getString(sql);
		 
		model.addAttribute("productName", productName);
		model.addAttribute("confinfo", list);
		return "meetingManager/editMeeting";
	}
	 
	/**
	 * 保存修改信息
	 * @param request
	 * @param confinfo
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="saveMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String saveMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) throws Exception {
		HttpSession session = request.getSession();
		TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		confinfo.setCompId(tAdmin.getCompID());
		String message ="0";
		TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(tAdmin.getCompID());
		int maxUserCount = compinfo.getMaxUserCount();
		StringBuilder budider = new StringBuilder("SELECT count(1) from  t_confinfo t  WHERE 1 = 1  and t.ConfName ='"+confinfo.confName+"' and t.ConfID <>"+confinfo.getConfId());
		String userCount = Sqlca.getString(budider.toString());//判断是否重名
//		String isAll=request.getParameter("isAll");
		
		StringBuilder buder = new StringBuilder("update t_confinfo t set  t.confName = ?,t.ConfPwd = '"+confinfo.confPwd+"',t.MaxUserCount = "+confinfo.maxUserCount+",");
		buder.append("t.ChairPwd = '"+confinfo.chairPwd+"',t.IsPublic ='"+confinfo.isPublic+"',t.isReservedConf = '"+confinfo.isReservedConf+"',"); 
		buder.append("t.IsAll='"+confinfo.isAll+"',t.IsOnOff ='"+confinfo.isOnOff+"',t.ConfDesc = ? ");
		
		String confName =request.getParameter("confName").trim();
		String confDesc = request.getParameter("confDesc");
		String IsReservedConf = request.getParameter("isReservedConf");
		String endTime="";String startTime=null;String beginTime="";
		
		if(IsReservedConf.equals("0")) {
			endTime=null;
			startTime =null;
			beginTime = null;
			buder.append(",t.EndTime ="+endTime+"");
			buder.append(",t.StartTime = "+startTime+"");
			buder.append(",t.BeginTime ="+beginTime+"");
		}else if(IsReservedConf.equals("2")){
			endTime=null;
			startTime =null;
			beginTime =request.getParameter("beginTime");
			buder.append(",t.EndTime ="+endTime+"");
			buder.append(",t.StartTime = "+startTime+"");
			buder.append(",t.BeginTime = '"+beginTime+"'");
		}else {
			endTime = request.getParameter("endTime");
			startTime =request.getParameter("startTime");
			beginTime =request.getParameter("beginTime");
			buder.append(",t.EndTime ='"+endTime+"'");
			buder.append(",t.StartTime = '"+startTime+"'");
			buder.append(",t.BeginTime = '"+beginTime+"'");
		}
		if(confinfo.plan!=null &&confinfo.plan!="") {
			buder.append(" ,t.plan = '"+confinfo.plan+"'");
		}
		buder.append(" where t.ConfID ="+confinfo.confId+"");		
		
		int isMeeting = compinfo.getIsMeeting();//是否控制人数  0、不控制 1、控制  
		int meetingCount =compinfo.getMeetingCount(); //控制创建同时间段 会议室的个数 0、不控制 1 、2表示 --1个、2个
		if(confinfo.getIsReservedConf().equals("1")) {
			SimpleDateFormat confTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
			Date startt = confTime.parse(confinfo.getStartTime());
			Date endtt = confTime.parse(confinfo.getEndTime());
			//startt = confTime.format(start);
			//endtt = confTime.format(end);
		 
		List<TConfinfo> confinfoMation = meetingRoomDao.selectConfinfoList(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt,confinfo.getConfId());//获取预约会议室信息判断 是否允许创建同时间段多个
		String confSum="0";//参会总数
		int upCount=0;//当前会议室最大并发数
		StringBuffer dd = new StringBuffer();
		String ss ="";
		String currentmaxUser ="";//当前会议室最大并发数
		int confinfoCount1=0;
		if(confinfoMation.size()>0) {
				if(meetingCount>0 && isMeeting==0) {//控制个数
					confinfoCount1 =meetingRoomDao.selectConfinfoCount(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt);
					if(meetingCount>1) {
						if(confinfoCount1>meetingCount) {
							message="3";//message="您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！";
						}
					}
				}
				if(meetingCount==0 && isMeeting==1) {//控制人数您所在的企业的人数
					confinfoCount1 =meetingRoomDao.selectConfinfoCount(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt);
					for (TConfinfo tconfinfo : confinfoMation) { 
						dd.append(tconfinfo.getConfId().toString()).append(",");
					}
					if(dd.length()>0) {
						ss = dd.toString().substring(0, dd.toString().length()-1);
					}else {
						ss="0";
					}
					confSum = Sqlca.getString("SELECT sum(MaxUserCount) FROM t_confinfo WHERE ConfID in("+ss+")");
					currentmaxUser = Sqlca.getString(" SELECT MaxUserCount FROM t_confinfo WHERE confId ="+confinfo.getConfId());
					if(Integer.parseInt(currentmaxUser)>confinfo.getMaxUserCount()) {
						 upCount = Integer.parseInt(currentmaxUser)-confinfo.getMaxUserCount();
					}else {
						 upCount = Integer.parseInt(currentmaxUser)-confinfo.getMaxUserCount();
					}
					int remainCount=0;
					if(confinfoCount1>1) {
						remainCount = maxUserCount-(Integer.parseInt(confSum)-upCount);
					}else {
						remainCount = maxUserCount-(Integer.parseInt(confSum)-upCount);
					}
					if(remainCount<0) {
						message="4";//message = "您的企业并发点已不足，如需继续请更换时间点或修改最大用户数";
					}
				}
				if(meetingCount>0 && isMeeting==1) {// 控制个数和人数
					int confinfoCount =meetingRoomDao.selectConfinfoCount(tAdmin.getCompID(), Integer.parseInt(confinfo.getIsReservedConf()),startt,endtt);
						if(meetingCount>1) {
							if(confinfoCount>meetingCount) {
									message="3";//message="您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！";
							}
						}
					if(confinfoMation.size()>0){
						for (TConfinfo tconfinfo : confinfoMation) { 
							dd.append(tconfinfo.getConfId().toString()).append(",");
						}
						if(dd.length()>0) {
							ss = dd.toString().substring(0, dd.toString().length()-1);
						}else {
							ss="0";
						}
						confSum = Sqlca.getString("SELECT sum(MaxUserCount) FROM t_confinfo WHERE ConfID in("+ss+")");
						currentmaxUser = Sqlca.getString(" SELECT MaxUserCount FROM t_confinfo WHERE confId ="+confinfo.getConfId());
						//currentmaxUser =request.getParameter("maxUserCount");
						
						if(Integer.parseInt(currentmaxUser)>confinfo.getMaxUserCount()) {
							 upCount = Integer.parseInt(currentmaxUser)-confinfo.getMaxUserCount();
						}else {
							 upCount = Integer.parseInt(currentmaxUser)-confinfo.getMaxUserCount();
						}
					}
					int remainCount = maxUserCount-(Integer.parseInt(confSum)-upCount);
					if(remainCount<0) {
						message="4";//message = "您的企业并发点已不足，如需继续请更换时间点或修改最大用户数";
					}
				}
			} 
		}
		if(Integer.parseInt(message)>1) {
			if(Integer.parseInt(message)==3 ||Integer.parseInt(message)==4 ) {
				if(Integer.parseInt(message)==3) {
					message="limit";//您所在的企业已限制创建会议室的个数，如需继续创建请联系管理员！
				}else {
					message="over"; //您的企业并发点已不足，如需继续请更换时间点或修改最大用户数
				}
			}
		}else if(Integer.parseInt(userCount)>0) {
			message="rename";
		}else if(maxUserCount<confinfo.getMaxUserCount()) {
			message="out";
		}else {
			int flag = Sqlca.updateObject(buder.toString(), new String[] {confName,confDesc});
			if(flag>0) {
				message="success";
			}else {
				message="fali";
			}
		}
		return message;
	}
	
	/**
	 * 点击分配参会人员查看公司详情
	 * @param request
	 * @param confinfo
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="distributCompany",method= {RequestMethod.POST,RequestMethod.GET})
	public String distributCompany(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) throws Exception {
		
		int confId = confinfo.getConfId();
		TConfinfo tconfinfo = meetingRoomDao.selectconfIdBycompId(confId);
		String sql = "select confName from t_confinfo  where ConfID ="+confId;
		String confName = Sqlca.getString(sql);
		ArrayList<Map<String,Object>> organList = getOrganMenu(tconfinfo.getCompId());
		model.addAttribute("confName", confName);
		model.addAttribute("confId", confId);
		model.addAttribute("organMenu", organList); 
		return "meetingManager/distributMeet";
	}
	
	/**
	 * 删除会议室
	 * @param request
	 * @param confinfo
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/delMeeting")
	@ResponseBody
	public String delMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
		JSONObject json = new JSONObject();String message="";
		//会议id
		int confId = confinfo.getConfId();
		confinfo = meetingRoomDao.selectMeetStatus(confId);
		String isOnOff = confinfo.getIsOnOff();
		if(isOnOff.equals("1")) {
			message="1";
			System.out.println("会议室开启状态");
		}else {
			System.out.println("会议室关闭状态");
			if(confId>0) {
				int flag = meetingRoomDao.delMeetDao(confId);
				message="0";
			}
		}
		json.put("message", message);
		return json.toString();
	}
	
	
	/**
	 * 查询部门下面用户
	 * @param dpid
	 * @param compid
	 * @return
	 * @throws Exception
	 */
	public static String getOrganUserList(String dpid,Integer compid,String displayName,String userName) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
		if("99999".equals(dpid)) {dpid="1";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,'' as ParentDpName,t.Description from t_department t where t.Dpid="+dpid+" or t.compid="+compid;
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(where1+",");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(where2+",");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						sqlbf.append(where3+",");
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"' and t.compid="+compid;
			sqlbf.append("'"+dpid+"',");
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"' and t.compid="+compid;
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
				sqlbf.append(where1+",");
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;
					sqlbf.append(where2+",");
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
						sqlbf.append(where3+",");
					}
				}
				
			}
		}
		String sql="";
		String where = sqlbf.toString().substring(0, sqlbf.toString().length()-1);
		if(null!=displayName && !"".equals(displayName)) {
			sql = " select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,                "+
					"  t.DpId as Did,(select DpName from t_department tt where tt.DpId=t.DpId) as DpName,                                "+
					"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
					"  t.Telephone,t.Email,t.UserID as Operation                                            "+
					"  from t_userinfo t where t.DpId in("+where+")  and t.compid="+compid+"  and t.DisplayName like "+"'%"+displayName+"%'";
		}else if(null!=userName && !"".equals(userName)) {
			sql = " select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,                "+
					"  t.DpId as Did,(select DpName from t_department tt where tt.DpId=t.DpId) as DpName,                                "+
					"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
					"  t.Telephone,t.Email,t.UserID as Operation                                            "+
					"  from t_userinfo t where t.DpId in("+where+")  and t.compid="+compid+"  and t.userName like '%"+userName+"%'";
		}else if(null!=displayName && !"".equals(displayName) && null!=userName && !"".equals(userName)) {
			sql = " select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,                "+
					"  t.DpId as Did,(select DpName from t_department tt where tt.DpId=t.DpId) as DpName,                                "+
					"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
					"  t.Telephone,t.Email,t.UserID as Operation                                            "+
					"  from t_userinfo t where t.DpId in("+where+")  and t.compid="+compid+"  and t.userName like '%"+userName+"%' and t.DisplayName like "+"'%"+displayName+"%'";
		}else {
			sql = " select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,                "+
					"  t.DpId as Did,(select DpName from t_department tt where tt.DpId=t.DpId) as dpName,                                "+
					"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
					"  t.Telephone,t.Email,t.UserID as Operation                                            "+
					"  from t_userinfo t where t.DpId in("+where+")  and t.compid="+compid;
		}
		
		return sql;
		
		}
	
	
	
	
	
	
	
	
	
		
	/**
	 * 部门树
	 * @param compid
	 * @return
	 * @throws Exception
	 */
	public static ArrayList<Map<String,Object>> getOrganMenu(Integer compid) throws Exception {
		String sql="select DpId,DpName,ParentDpId,AdminId,CompId from t_department where ParentDpId='-1'";
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		for(Map<String,Object> ob : array) {
			String dpid = (String)ob.get("DpId");
			String sql2="select * from t_department where parentdpid='"+dpid+"' and compid="+compid;
			ArrayList<Map<String,Object>> array2 = Sqlca.getArrayListFromMap(sql2);
			ob.put("children", array2);
			for(Map<String,Object> ob2 : array2) {
				String dpid3 = (String)ob2.get("DpId");
				String sql3="select * from t_department where parentdpid='"+dpid3+"' and compid="+compid;
				ArrayList<Map<String,Object>> array3 = Sqlca.getArrayListFromMap(sql3);
				ob2.put("children", array3);
				for(Map<String,Object> ob3 : array3) {
					String dpid4 = (String)ob3.get("DpId");
					String sql4="select * from t_department where parentdpid='"+dpid4+"' and compid="+compid;
					ArrayList<Map<String,Object>> array4 = Sqlca.getArrayListFromMap(sql4);
					ob3.put("children", array4);
					for(Map<String,Object> ob4 : array4) {
						String dpid5 = (String)ob4.get("DpId");
						String sql5="select * from t_department where parentdpid='"+dpid5+"' and compid="+compid;
						ArrayList<Map<String,Object>> array5 = Sqlca.getArrayListFromMap(sql5);
						ob4.put("children", array5);
					}
				}
			}
		}
		return array;
	}
		
	/**
	 * 进入查询用户方法
	 * @param request
	 * @param confinfo
	 * @param response
	 * @param model
	 * @return
	 */
		@RequestMapping(value="/selectUserById",method= {RequestMethod.POST,RequestMethod.GET})
		public String selectUserById(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) {
			int confId = Integer.parseInt(request.getParameter("confId"));
			String confName =request.getParameter("confName");
			String dpId = request.getParameter("dpid");//部门id
			model.addAttribute("confName", confName);
			model.addAttribute("dpId", dpId);
			model.addAttribute("confId",confId);
			return "meetingManager/distritLeft";
		}
	
		/**
		 * 根据企业id查询企业用户信息
		 * @param request
		 * @param confinfo
		 * @param response
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/selectUserInfo")
		@ResponseBody
		public Map<String, Object> selectUserInfo(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
			
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			HttpSession session   = request.getSession();
			TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int compId = tAdmin.getCompID();
			String dpId = request.getParameter("dpId");//部门id
			String displayName =request.getParameter("displayName"); 
			String userName = request.getParameter("userName");
			
			//查询分配后的人员
			int confId = Integer.parseInt(request.getParameter("confId"));//部门id
			String sql1 = "SELECT UserID from t_confusers where ConfID ="+confId;
			List<Map<String,Object>> ty =	Sqlca.getArrayListFromMap(sql1);
			String ss ="";
			if(ty.size()>0) {
				StringBuffer dd = new StringBuffer();
				for(Map<String, Object> map2 : ty)
				{
					String cc = (String)map2.get("UserID");
					dd.append(cc).append(",");
				}
				ss = dd.toString().substring(0, dd.toString().length()-1);
			}else {
				ss="0";
			}
			String confList = "	select t.UserId from t_userinfo t where t.UserID  IN("+ss+"";
			//根据企业树查询企业用户
			String sql = getOrganUserList(dpId, compId,displayName,userName);
			String cntsql = "select count(*) "+sql.substring(sql.lastIndexOf("from"));
			//sql+="  AND t.UserID NOT IN( "+confList+")) AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"') "; 
			//cntsql+=" AND t.UserID NOT IN( "+confList+"))  AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"') ";
			sql+="  AND t.UserID NOT IN( "+confList+")) "; 
			cntsql+=" AND t.UserID NOT IN( "+confList+"))  ";
			sql +=" order by t.UserID asc";
			String dbtotal = Sqlca.getString(cntsql); 
			sql+="  limit " +i+","+rows;
			
			Map<String, Object> map = new HashMap<String,Object>();
			ArrayList<Object> list = Sqlca.getArrayListFromObj(sql, TUserinfo.class);
			 
			map.put("total", Integer.parseInt(dbtotal));
			map.put("rows", list);
			return map;
		} 
		
		/**
		 * 查询分配后的人员
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 */
		@RequestMapping(value="/selectUserInfoRight",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public Map<String, Object> selectUserInfoRight(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) throws Exception {
			HttpSession session   = request.getSession();
			TUserinfo tAdmin = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			String username = tAdmin.getUserName();
			int compId = tAdmin.getCompID();
			
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			
			String displayName =request.getParameter("displayNames"); 
			String userName = request.getParameter("userNames");
			int confId = Integer.parseInt(request.getParameter("confId"));//部门id
			String sql = "SELECT UserID from t_confusers where ConfID ="+confId;
			List<Map<String,Object>> ty =	Sqlca.getArrayListFromMap(sql);
			String ss ="";
			if(ty.size()>0) {
				StringBuffer dd = new StringBuffer();
				for(Map<String, Object> map2 : ty)
				{
					String cc = (String)map2.get("UserID");
					dd.append(cc).append(",");
				}
				ss = dd.toString().substring(0, dd.toString().length()-1);
			}else {
				ss="0";
			}
//			String tal ="select count(*) from t_userinfo t where t.UserID IN ("+ss+") AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"') ";
//			String confList = "	select t.UserId,t.UserName,t.DisplayName,tc.UserRight AS IsSuper,(select DpName from t_department where t.DpId =DpId) AS dpName from t_userinfo t LEFT JOIN t_confusers tc ON tc.UserID = t.UserId where t.UserID " + 
//					" IN("+ss+") AND t.UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"')";
			String tal ="select count(*) from t_userinfo t where t.UserID IN ("+ss+") ";
			String confList = "	select t.UserId,t.UserName,t.DisplayName,tc.UserRight AS IsSuper,(select DpName from t_department where t.DpId =DpId) AS dpName from t_userinfo t LEFT JOIN t_confusers tc ON tc.UserID = t.UserId where t.UserID " + 
					" IN("+ss+") ";
			if(null!=userName && !"".equals(userName)) {
				confList +=" AND t.UserName LIKE '%"+userName+"%'";
				tal +=" AND t.UserName LIKE '%"+userName+"%'";
			}
			if(null!=displayName && !"".equals(displayName)) {
				confList +=" AND t.DisplayName LIKE '%"+displayName+"%'";
				tal +=" AND t.DisplayName LIKE '%"+displayName+"%'";
			}
			confList +="and tc.ConfID="+confId;
			confList +=" order by tc.UserRight,t.UserID asc";
			confList+="  limit " +i+","+rows;
			List<Object> obj = Sqlca.getArrayListFromObj(confList, TConfinfo.class);
			String total =Sqlca.getString(tal);
			
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("total", Integer.parseInt(total));
			map.put("rows", obj);
			return map;
		}  
		/**
		 * 	分配参会人员
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/getDistributUser",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String getDistributUser(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
		
			Integer confId = Integer.parseInt(request.getParameter("confId"));
			String userRight =Sqlca.switchLatin1Encoding("出席");
			
			String names[] = request.getParameterValues("names");
			names = names[0].split(",");
			String message= "";
			int count=0;
			for(int i=0;i<names.length;i++){
				String userId =names[i];
				int flag = meetingRoomDao.selectUserInfoDistri(confId, Integer.parseInt(userId));
				if(flag<1) {
					count =meetingRoomDao.addAttendMeetingUser(confId, Integer.parseInt(userId),userRight);
				}
			}
			if(names.length>0) {
				message="success";
			}else {
				message="fail";
			}
			JSONObject json = new JSONObject();
			json.put("message", message);
			return json.toString();
		}
		
		/**
		 * 取消参会
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 */
		@RequestMapping(value="/qiutMeetingUser",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String qiutMeetingUser(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
			Integer confId = Integer.parseInt(request.getParameter("confId"));
			String names[] = request.getParameterValues("names");
			names = names[0].split(",");
			String message= "";
			int count=0;
			for(int i=0;i<names.length;i++){
				String userId =names[i];
				count =meetingRoomDao.delDistribute(confId, Integer.parseInt(userId));
			}
			if(names.length>0) {
				message="success";
			}else {
				message="fail";
			}
			JSONObject json = new JSONObject();
			json.put("message", message);
			return json.toString();
		}
		
		/**
		 *  保存参会人员
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/saveMeetingUser")
		@ResponseBody
		public  String saveMeetingUser(HttpServletRequest request,HttpServletResponse response) throws Exception {
			String confId = request.getParameter("confId");
			String confadmins = request.getParameter("confadmins");
			String[] cfs = confadmins.split(",");
			for(int i=0;i<cfs.length;i++)
			{
				if(!"".equals(cfs[i]) && null!=cfs[i] )
				{
					if("1".equals(cfs[i].split("=")[1]))
					{
						Sqlca.updateObject("update t_confusers set UserRight=? where UserID=? and ConfID="+confId, new String[] {"主席",cfs[i].split("=")[0]});
					}
					else if("0".equals(cfs[i].split("=")[1]))
					{
						Sqlca.updateObject("update t_confusers set UserRight=? where UserID=? and ConfID="+confId, new String[] {"出席",cfs[i].split("=")[0]});
					}
				}
			}
			return "success";
		}
		
		/**
		 * 	清空参会人员
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 */
		@RequestMapping(value="/clearAttendMeeting")
		@ResponseBody
		public String clearAttendMeeting(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
			int confId = Integer.parseInt(request.getParameter("confId"));
			int attend = Integer.parseInt(request.getParameter("attend"));
			List<String> str = meetingRoomDao.selectUserIdByConfId(confId);//查询userId
			System.out.println("userID:"+str);
			for (String string : str) {
				int count =	meetingRoomDao.updateUserStatus(attend, Integer.parseInt(string));
			}
			return null;
		}
		
		@RequestMapping(value="/excelDistribMeeting",method= {RequestMethod.POST,RequestMethod.GET})
		public void excelDistribMeeting(HttpServletRequest request,HttpServletResponse response) {
			
			HttpSession session = request.getSession();
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int compId = tUser.getCompID(); 
			SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
			String date = df1.format(new Date());
		try 
			{ 
			OutputStream os = response.getOutputStream();// 取得输出流   
			response.reset();// 清空输出流   
			String fileName= "参会列表"+date+".xls"; 
			response.reset();// 清空输出流   
			response.setContentType("application/vnd.ms-excel;charset=utf-8");
			response.setHeader("Content-Disposition", "attachment;filename="+ new String((fileName).getBytes(), "iso-8859-1")); 
			response.setContentType("application/msexcel");// 定义输出类型 
			
			WritableWorkbook wbook = Workbook.createWorkbook(os); // 建立excel文件   
			String tmptitle = "参会列表"; // 标题   
			WritableSheet wsheet = wbook.createSheet(tmptitle, 0); // sheet名称  
			// 设置excel标题   
			WritableFont wfont = new WritableFont(WritableFont.ARIAL, 16,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
			WritableCellFormat wcfFC = new WritableCellFormat(wfont); 
			wsheet.addCell(new Label(0, 0, tmptitle, wcfFC));   
			wfont = new jxl.write.WritableFont(WritableFont.ARIAL, 14,WritableFont.BOLD,false, UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
			wcfFC = new WritableCellFormat(wfont); 
			 
			int confId = Integer.parseInt(request.getParameter("confId"));//部门id
			String sql= "SELECT UserID from t_confusers where ConfID ="+confId;
			List<Map<String,Object>> ty =	Sqlca.getArrayListFromMap(sql);
			String ss ="";
			if(ty.size()>0) {
				StringBuffer dd = new StringBuffer();
				for(Map<String, Object> map2 : ty)
				{
					String cc = (String)map2.get("UserID");
					dd.append(cc).append(",");
				}
				ss = dd.toString().substring(0, dd.toString().length()-1);
			}else {
				ss="0";
			}
			String confList = "	select t.UserId,t.UserName,t.DisplayName,(select tt.UserRight from t_confusers tt where tt.UserID=t.UserId and tt.ConfID="+confId+" and tt.UserRight='主席') as IsSuper,(select DpName from t_department where t.DpId =DpId) AS dpName from t_userinfo t where t.UserID " + 
					" IN("+ss+") AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"')";

			ArrayList<Object> userList = Sqlca.getArrayListFromObj(confList, TUserinfo.class);
			// 开始生成主体内容                    
			wsheet.addCell(new Label(0, 1, "用户账号"));
			wsheet.addCell(new Label(1, 1, "用户名称"));
			wsheet.addCell(new Label(2, 1, "所属部门"));  
			wsheet.addCell(new Label(3, 1, "管理员")); 
			int i=0;
			for(Object usert: userList)   {   
				TUserinfo m = (TUserinfo)usert;
			    wsheet.addCell(new Label(0, i+2, m.UserName));   //数据库的城市代码字段
			    wsheet.addCell(new Label(1, i+2, m.DisplayName));   
			    wsheet.addCell(new Label(2, i+2,  m.dpName));  
			    wsheet.addCell(new Label(3, i+2,  m.IsSuper==""?"出席":m.IsSuper));  
			    i++;
			}          
			// 主体内容生成结束           
			wbook.write(); // 写入文件   
			wbook.close();  
			os.close(); // 关闭流
			} 
		catch(Exception ex) 
		{ 
		ex.printStackTrace(); 
		}
	}
		
		
		
		@RequestMapping(value="/perMeetStatistics.do")
		public String perMeetStatistics(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
			return "meetingManager/perMeetStatistics";
		}
	  
		
		/**
		 * 统计单个会议室的总参会人数（去重）和总登陆次数
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/getPerMeetStatistics.do")
		@ResponseBody
		public Map<String,Object> getPerMeetStatistics(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception{
			int curPage=0;
			int pageSize=10;
			if(request.getParameter("page")!=null) {
				curPage = Integer.parseInt(request.getParameter("page"));
				pageSize = Integer.parseInt(request.getParameter("rows"));
			}
			HttpSession session = request.getSession();
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int compId = tUser.getCompID();
			String curUserIsSuper=tUser.getIsSuper();
			Integer curUserDpId=tUser.getDpId();
			String confName=request.getParameter("confName");
			String confIdString=request.getParameter("confId");
			Integer confId=null;
			if(confIdString!=null&&!"".equals(confIdString)) {
				confId=Integer.parseInt(confIdString);
			}
			int totalRow=meetingRoomDao.getPerMeetStatisticsCount(compId,confName,confId,curUserIsSuper,curUserDpId);
			Page page=new Page(totalRow, pageSize, curPage);
			List<Map<String,Object>> perMeetList=meetingRoomDao.getPerMeetStatistics(compId,confName,confId,curUserIsSuper,curUserDpId,page);
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("total", totalRow);
			map.put("rows", perMeetList);
			return map;
		}
		
		
		@RequestMapping(value="/getMeetStatics.do")
		public String getMeetStatics(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) {
			return "meetingManager/meetStatistics";
		}
		
		/**
		 * 会议统计
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/getMeetStatistics")
		@ResponseBody
		public  Map<String, Object>getMeetStatistics(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception{
			HttpSession session = request.getSession();
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int compId = tUser.getCompID(); 
			confinfo.setCompId(compId);
			confinfo.setConfName(Sqlca.switchLatin1Encoding(confinfo.getConfName()==null?"":confinfo.getConfName()));
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			String confIDStr =request.getParameter("ConfID");
			System.out.println("--------------------------confIDStr:"+confIDStr);
			int confID=-1;
			if(confIDStr!=null&&!"".equals(confIDStr)) {
				confID=Integer.parseInt(confIDStr);
			}
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows); 
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
			
			StringBuilder builder =  new StringBuilder("select t2.LogConfID,t2.LogConfID as logId,t1.ConfID AS ids,t1.ConfID AS confId,t1.ConfName AS confName,t2.MaxCount AS maxCount,t2.StartTime AS startTime,t2.EndTime AS endTime,"
					+ "concat((select count(DISTINCT(UserName)) from t_log_conf_detail where LogConfID =t2.LogConfID),'/',(select COUNT(*) from t_confusers where ConfID =t1.ConfID AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compId+"')))AS confUserCount "
					+ "from t_compinfo t  INNER JOIN t_confinfo t1 on t.CompID =t1.CompID  INNER JOIN t_log_conf t2 ON t1.ConfID =t2.ConfID  where t.CompID ="+compId+" and t1.ConfID="+confID);
			
			StringBuilder budis = new StringBuilder("select  count(1) from t_compinfo t  LEFT JOIN t_confinfo t1 on t.CompID =t1.CompID  LEFT JOIN t_log_conf t2 ON t1.ConfID =t2.ConfID  where t.CompID ="+compId+" and t1.ConfID="+confID);
			 
			
			String confName = request.getParameter("confName");
			if(confName!=null && confName!="") {
				System.out.println(confinfo.endTime+"名称："+confName+confinfo.startTime);
				builder.append(" and t1.ConfName LIKE '%"+confName+"%'");
				budis.append(" and t1.ConfName LIKE '%"+confName+"%'");
			}
			if(confinfo.startTime!=null&&confinfo.startTime!="") {
				builder.append(" and t2.StartTime >= '"+confinfo.startTime+" 00:00:00'");
				budis.append(" and t2.StartTime >= '"+confinfo.startTime+" 00:00:00'");
			}									 
			if(confinfo.endTime!=null &&confinfo.endTime!="") {
				builder.append(" and t2.EndTime <='"+confinfo.endTime+" 23:59:59'");
				budis.append(" and t2.EndTime <='"+confinfo.endTime+" 23:59:59'");
			}
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				builder.append(" order by "+SortName+" "+SortValue+" limit "+i+","+rows);
			}
			else
			{
				builder.append(" limit "+i+","+rows);
			}
			//builder.append(" limit " +i+","+Integer.parseInt(rows));
			
			List<Object> obj = Sqlca.getArrayListFromObj(builder.toString(), TConfinfo.class);
			String total = Sqlca.getString(budis.toString());
			
			for (Object tConfinfo2 : obj) { 
				String endTime=""; String startTime="";
				endTime = ((TConfinfo) tConfinfo2).getEndTime()==null?"":((TConfinfo) tConfinfo2).getEndTime();
				startTime =((TConfinfo) tConfinfo2).getStartTime()==null?"":((TConfinfo) tConfinfo2).getStartTime();
				if(endTime.equals(null)||endTime.equals("")) {
					((TConfinfo) tConfinfo2).setIsReservedConf(0+"min");
				}else {
					String type="2";
					Long hour = StringToDate(endTime, startTime,type);
					((TConfinfo) tConfinfo2).setIsReservedConf((hour).toString());
				}
			}
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("total", total);
			map.put("rows", obj);
			map.put("pageNumber", page);
			return map;
		}
	
		@RequestMapping(value="/getMeetStatisDetail",method= {RequestMethod.POST,RequestMethod.GET})
		public String getMeetStatisDetail(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response,Model model) {
			int logConfID = Integer.parseInt(request.getParameter("logConfID"));
			model.addAttribute("logConfID", logConfID);
			return "meetingManager/meetStatisticsDetail";
		}
		
		
		/**
		 * 会议统计查看详情
		 * @param request
		 * @param confinfo
		 * @param response
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/getMeetStatisDetailMap")
		@ResponseBody
		public Map<String, Object> getMeetStatisDetailMap(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
			 
			confinfo.setUserName(Sqlca.switchLatin1Encoding(confinfo.getUserName()==null?"":confinfo.getUserName()));
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
			
			StringBuilder budiler = new StringBuilder("select t2.DetailID AS detailId,t2.region AS region, t2.ConfName AS confName,t2.UserName AS userName,t2.StartTime AS startTime,t2.EndTime AS endTime,"
					+ "t2.LoginIp AS loginIp,(SELECT maxUserCount from t_confinfo WHERE t2.ConfID = ConfID) AS maxUserCount from   t_log_conf_detail t2 where t2.LogConfID ="+confinfo.getLogConfID());
			StringBuilder budis = new StringBuilder("select count(1)  from  t_log_conf_detail t2 where t2.LogConfID ="+confinfo.getLogConfID());
			String userName = request.getParameter("userName");
			
			if(userName !=null && userName !="") {
				budiler.append(" and t2.UserName LIKE '%"+userName+"%'");
				budis.append(" and t2.UserName LIKE '%"+userName+"%'");
			}
			if(null!=SortName && !"".equals(SortName)) 
			{
				budiler.append(" order by "+SortName+" "+SortValue+" limit "+i+","+rows);
			}
			else
			{
				budiler.append(" limit "+i+","+rows);
			}
			 
			
			List<Object> obj = Sqlca.getArrayListFromObj(budiler.toString(), TConfinfo.class);
			String total = Sqlca.getString(budis.toString());
			
			for (Object tConfinfo2 : obj) {
				String endTime=""; String startTime="";String loginIp="";
				endTime = ((TConfinfo) tConfinfo2).getEndTime()==null?"":((TConfinfo) tConfinfo2).getEndTime();
				startTime =((TConfinfo) tConfinfo2).getStartTime()==null?"":((TConfinfo) tConfinfo2).getStartTime();
				int detailId = ((TConfinfo) tConfinfo2).getDetailId();
				
				if(endTime.equals(null)||endTime.equals("")) {
					((TConfinfo) tConfinfo2).setIsReservedConf(0+"min");
				}else {
					String type="2";
					Long hour = StringToDate(endTime, startTime,type);
					((TConfinfo) tConfinfo2).setIsReservedConf((hour).toString()+"min");
				}
				
				String address="";String region="";
				loginIp =((TConfinfo) tConfinfo2).getLoginIp()==null?"":((TConfinfo) tConfinfo2).getLoginIp();
				region =((TConfinfo) tConfinfo2).getRegion()==null?"":((TConfinfo) tConfinfo2).getRegion();
				
				if(region.equals("")|| region.equals(null)) {
					 loginIp =loginIp+ region;
				}else {
					loginIp =loginIp+region;
				}
				((TConfinfo) tConfinfo2).setLoginIp(loginIp);
		 		
			}
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("total", total);
			map.put("rows", obj);
			return map;
		}
		
		
		/**
		  * 高德根据IP获取省市
		  * @param cph
		  * @return
		  * @throws Exception
		  */
		 public static String ipGetCity(String ip) throws Exception{
			 	 
			 	String key ="780435d689f5fc3782b4942de06dcb6f";
			 	String result =null;
			 	String url = "http://restapi.amap.com/v3/ip?ip="+ip+"&output=json&key="+key;
		        Map params = new HashMap();//请求参数
		            params.put("ip",ip);//获取到的ip
		            params.put("key",key);//密钥
		            result = httpClient.net(url, params, "GET");
		            System.out.println("返回城市信息："+result);
		            String ii = getCity(result);
				   return ii;
		    }
		 
		 	public static String getCity(String result){
		 		
		 		net.sf.json.JSONObject jsonStr = net.sf.json.JSONObject.fromObject(result);
		 		JSONArray jsonArr = JSONArray.fromObject(jsonStr);
		 		String province ="";String city="";
		 		int status=0; String info ="";
		 		for (int i = 0; i < jsonArr.size(); i++) {
					net.sf.json.JSONObject jsonObj = jsonArr.getJSONObject(i);
		 			province = jsonObj.getString("province");
		 			city =  jsonObj.getString("city");
		 			status = jsonObj.getInt("status");
					info = jsonObj.getString("info");
				}
		 		String str = province+city ;
		 		return str;
		 	}
		
		@RequestMapping(value="/getLocalRegion",method = {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String getLocalRegion(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
			
			int detailId = Integer.parseInt(request.getParameter("detailId"));
			String loginIp = Sqlca.getString("SELECT LoginIp from t_log_conf_detail WHERE DetailID="+detailId);
			String region ="";
			int count =0;String pp="";
			if(!String.valueOf(detailId).equals("") && !String.valueOf(detailId).equals(null)) {
				pp = ipGetCity(loginIp);
				region =pp;
				if(!region.equals(null)&&!region.equals("")) {
					String upSql ="UPDATE t_log_conf_detail SET region =? WHERE DetailID = ?";
					count =Sqlca.updateObject(upSql, new String[] {region,String.valueOf(detailId)});
				}
			}
			JSONObject json = new JSONObject();
			if(count>0) {
				json.put("message", "success");
			}else {
				json.put("message", "fail");
			}
			return json.toString();
		}
		
		@RequestMapping("myMeetingHistory.do")
		public String myMeetingHistory() {
			return "meetingManager/myMeetingHistory";
		}
		
		@RequestMapping("getMyMeetingHistory.do")
		@ResponseBody
		public Map<String,Object> getMyMeetingHistory(HttpServletRequest request,HttpServletResponse response){
			HttpSession session = request.getSession();
			int curPage=0;
			int pageSize=10;
			if(request.getParameter("page")!=null) {
				curPage = Integer.parseInt(request.getParameter("page"));
			}
			if(request.getParameter("page")!=null) {
				pageSize = Integer.parseInt(request.getParameter("rows"));
			}
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int userId = tUser.getUserID();
			int totalRow=meetingRoomDao.getMyMeetingHistoryCount(userId);
			Page page=new Page(totalRow, pageSize, curPage);
			List<TLogConfDetail> historyList=meetingRoomDao.getMyMeetingHistory(userId,page);
			
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("total", totalRow);
			map.put("rows", historyList);
			return map;
		}
	
		@RequestMapping("myMeetingAuthority.do")
		public String myMeetingAuthority() {
			return "meetingManager/myMeetingAuthority";
		}
		
		@RequestMapping("getMyMeetingAuthority.do")
		@ResponseBody
		public Map<String,Object> getMyMeetingAuthority(HttpServletRequest request,HttpServletResponse response){
			HttpSession session = request.getSession();
			int curPage=0;
			int pageSize=10;
			if(request.getParameter("page")!=null) {
				curPage = Integer.parseInt(request.getParameter("page"));
			}
			if(request.getParameter("page")!=null) {
				pageSize = Integer.parseInt(request.getParameter("rows"));
			}
			TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
			int userId = tUser.getUserID();
			int totalRow=meetingRoomDao.getMyMeetingAuthorityCount(userId);
			Page page=new Page(totalRow, pageSize, curPage);
			//isReservedConf 会议类型 0长期 2周例会1 预约
			List<Map<String,Object>> myMeetingAuthority=meetingRoomDao.getMyMeetingAuthority(userId,page);
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("total", totalRow);
			map.put("rows", myMeetingAuthority);
			return map;
		}
	
		
		/**
		 * 参会人员导入
		 * @param file
		 * @param request
		 * @param response
		 * @param session
		 * @return
		 * @throws Exception
		 */
//		@RequestMapping(value="/BatchImportSubmit.do",produces = "text/html;charset=UTF-8")
		@RequestMapping(value="batchImportConfusers.do")
		@ResponseBody
		public Result<Map<String,Integer>> batchImportConfusers(@RequestParam(value="filename") MultipartFile file,HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception
		{
			Object obj = session.getAttribute("USER_VIPSESSION");
			String username = null;
			String confIdStr=request.getParameter("confId");
			Integer confId=-1;
			if(confIdStr!=null&&!"".equals(confIdStr)) {
				confId=Integer.parseInt(confIdStr);
			}
			
			TUserinfo userinfo=new TUserinfo();
			Result<Map<String,Integer>> result=new Result<Map<String,Integer>>(-1, "error", null);
			if(obj!=null)
			{
				userinfo = (TUserinfo)obj;
				username = userinfo.UserName;
				
			}
			ExcelUtil excel = new ExcelUtil();
			List<TConfusersVO> list = new ArrayList<TConfusersVO>();
			List<TConfusersVO> errorUserlist = new ArrayList<TConfusersVO>();
			
			excel.getExcelConfuersInfo(file,username,list,errorUserlist);
			int excelTotalRow=list.size()+errorUserlist.size();
			Connection conn = Sqlca.getConnection();
			conn.setAutoCommit(false);  
			PreparedStatement ps = null;
			try
			{
				String confusersSql="INSERT INTO t_confusers(ConfID,UserID,UserRight,UserPos,CsipId,MsipId)values(?,?,?,?,?,?)";
				ps = conn.prepareStatement(confusersSql);
				 int listLen = list.size();
				 int i=0;
				//导入正确参会人员
				if(list.size()>0) {
					for(TConfusersVO u :list)
					{
						//用户名唯一校验
						Integer userId =userDao.getUserIdByUserName(u.getUserName().trim());
						if(userId==null) {
							u.setRemark("该用户未注册");
							errorUserlist.add(u);
						}else {
							int userCount=meetingRoomDao.selectUserInfoDistri(confId,userId);
							if(userCount>0) {//用户已存在
								u.setRemark("参会人员已经存在");
								u.setUserID(userId);
								errorUserlist.add(u);
							}else {
		                		if("是".equals(u.UserRight.trim())){
		                			u.setUserRight("主席");
		                		}
		                		if("否".equals(u.UserRight.trim())){
		                			u.setUserRight("出席");
		                		}
				                ps.setString(1, confId==null?null:confId.toString());
				                ps.setString(2, userId==null?null:userId.toString());
				                ps.setString(3, u.UserRight);
				                ps.setString(4, "0");
				                ps.setString(5, "0");
				                ps.setString(6, "0");
		                		
				                ps.addBatch();
							}
						}
						
						 //每200次提交一次 
		                if((i!=0 && i%200==0) || i==listLen-1){//可以设置不同的大小；如50，100，200，500，1000等等  
		                    ps.executeBatch();  
		                    //优化插入第三步       提交，批量插入数据库中。
		                    conn.commit();  
		                    ps.clearBatch();        //提交后，Batch清空。
		                }
		                
						i++;
						
					}
				}
				
				
				//导入有错误参会人员
				if(errorUserlist.size()>0) {
					//创建临时表
					String tempTableName=TEMP_TABLE_NAME_PRE+userinfo.getUserID().toString().trim();
					int createCount=-1;
					Map<String,Object> map=new HashMap<String,Object>();
					map.put("tableName", tempTableName);
					String databaseName=getDatabaseName();
					map.put("dbName", databaseName);
					map.put("result", createCount);
					organizationDao.createTempConfusersTable(map);
					System.out.println("result:"+map.get("result"));
					
					 String sql = "INSERT INTO "+tempTableName+"(ConfID,UserID,UserName,UserRight,Description,UserPos,CsipId,MsipId)values(?,?,?,?,?,?,?,?)";
					 ps = conn.prepareStatement(sql);
					 int len = errorUserlist.size();
					 int j=0;
					//用户格式错误
					for(TConfusersVO u :errorUserlist){
						 	ps.setString(1, confId==null?null:confId.toString());
			                ps.setString(2, u.getUserID()==null?null:u.getUserID().toString());
			                ps.setString(3, u.getUserName());
			                ps.setString(4, u.UserRight);
			                ps.setString(5, u.Remark);
			                ps.setString(6, "0");
			                ps.setString(7, "0");
			                ps.setString(8, "0");
			                ps.addBatch(); 
			              //每200次提交一次 
			                if((j!=0 && j%200==0) || j==len-1){//可以设置不同的大小；如50，100，200，500，1000等等  
			                    ps.executeBatch();  
			                    //优化插入第三步       提交，批量插入数据库中。
			                    conn.commit();  
			                    ps.clearBatch();        //提交后，Batch清空。
			                }
			                j++;
					
					}
				}
				
				
				Map<String,Integer> resultMap=new HashMap<String,Integer>();
				resultMap.put("successCount", excelTotalRow-errorUserlist.size());
				resultMap.put("errorCount", errorUserlist.size());
			       
		       if(errorUserlist.size()>0) {
		    	   result=new Result<Map<String,Integer>>(-1, "error", resultMap);
		       }else {
		    	   result=Result.success(resultMap);
		       }
			       
			}catch(BatchUpdateException e){
				int[] i=e.getUpdateCounts();
				logger.info(i, e);
				System.out.println("i[]="+i);
				e.printStackTrace();
				return result;
			}catch(Exception e){
				e.printStackTrace();
				return result;
			}finally{
				ps.close();
				conn.close();
			}
			  
			return result;
		}
		
		
			/**
			 * 	导出错误参会人员信息
			 * @param request
			 * @param response
			 */
			@RequestMapping(value="/errorConfusersImportExcel.do",method= {RequestMethod.POST,RequestMethod.GET})
			public void errorConfusersImportExcel(HttpServletRequest request,HttpServletResponse response) {
				HttpSession session = request.getSession();
				TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
				SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
				String date = df1.format(new Date());
			try 
				{ 
				OutputStream os = response.getOutputStream();// 取得输出流   
				response.reset();// 清空输出流   
				String fileName= "参会人员信息导入失败"+date+".xls"; 
				response.reset();// 清空输出流   
				response.setContentType("application/vnd.ms-excel;charset=utf-8");
				response.setHeader("Content-Disposition", "attachment;filename="+ new String((fileName).getBytes(), "iso-8859-1")); 
				response.setContentType("application/msexcel");// 定义输出类型 
				
				WritableWorkbook wbook = Workbook.createWorkbook(os); // 建立excel文件   
				String tmptitle = "参会人员信息"; // 标题   
				WritableSheet wsheet = wbook.createSheet(tmptitle, 0); // sheet名称  
				// 设置excel标题   
				WritableFont wfont = new WritableFont(WritableFont.ARIAL, 16,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				WritableCellFormat wcfFC = new WritableCellFormat(wfont); 
				wsheet.addCell(new Label(0, 0, tmptitle, wcfFC));   
				wfont = new jxl.write.WritableFont(WritableFont.ARIAL, 14,WritableFont.BOLD,false, UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				wcfFC = new WritableCellFormat(wfont); 
				String sql ="";
				Map<String,Object> map=new HashMap<String,Object>();
				map.put("tablName",TEMP_TABLE_NAME_PRE+tUser.getUserID());
				//查询所有用户
				List<Map<String,String>> userList=organizationDao.errorConfusersImportExcel(map);
				System.out.println(userList);
				
				
				// 开始生成主体内容                   
				wsheet.addCell(new Label(0, 1, "用户账号*"));
				wsheet.addCell(new Label(1, 1, "是否管理员(是、否)*"));
				wsheet.addCell(new Label(2, 1, "导入失败原因"));
				int i=0;
				
				for(Map<String,String> m: userList)   {   
//					TUserinfo m = (TUserinfo)usert;
				    wsheet.addCell(new Label(0, i+2, m.get("UserName")));   //数据库的城市代码字段
				    wsheet.addCell(new Label(1, i+2, m.get("UserRight")));   
				    wsheet.addCell(new Label(2, i+2,  m.get("Remark")));   
				    i++;
				}          
				// 主体内容生成结束           
				wbook.write(); // 写入文件   
				wbook.close();  
				os.close(); // 关闭流
				} 
			catch(Exception ex) 
			{ 
			ex.printStackTrace(); 
			}
		}
				
			
		
		
		/**
		 * 获取数据库名称
		 * @return
		 */
		public String getDatabaseName() {
			String databaseName=null;
			try {
				Properties prop = new Properties();
				InputStream in = UserManagerController.class.getClassLoader().getResourceAsStream("config.properties");
		        prop.load(in);
		        String jdbcUrl=prop.getProperty("jdbc.url");
		        databaseName=jdbcUrl.substring(jdbcUrl.lastIndexOf("/")+1, jdbcUrl.lastIndexOf("?"));
		       
			} catch (Exception e) {
				new Throwable(e);
			}
			 return databaseName;
		}
		
		
		/**
		 * 删除User导入错误临时表
		 * @param request
		 * @param response
		 * @param session
		 * @return
		 */
		@RequestMapping("dropTempConfuserTable.do")
		@ResponseBody
		public Result<String> dropTempUserTable(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
			
			Object obj = session.getAttribute("USER_VIPSESSION");
			Integer userId = null;
			if(obj!=null){
				TUserinfo userinfo = (TUserinfo)obj;
				userId = userinfo.getUserID();
			};
			Result<String> result=new Result<String>(-1, "删除临时表失败", TEMP_TABLE_NAME_PRE+userId);
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("dbName",getDatabaseName());
			map.put("tableName", TEMP_TABLE_NAME_PRE+userId);
			map.put("result",-1);
			organizationDao.dropTempUserTable(map);
			Object resultObj=map.get("result");
			Integer i=Integer.parseInt(resultObj.toString());
			if(i==0) {
				result=Result.success(TEMP_TABLE_NAME_PRE+userId);
			}
			return result;
		}
		
		
}









































