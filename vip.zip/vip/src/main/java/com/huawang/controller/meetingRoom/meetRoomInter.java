package com.huawang.controller.meetingRoom;

import java.sql.Connection;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap; 
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.huawang.dao.api.appDao;
import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.pojo.inter.TUser;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.pojo.meetingRoom.TLogConfDetail;
import com.huawang.pojo.inter.TAttendUserVo;
import com.huawang.pojo.inter.TCompinfoVo;
import com.huawang.pojo.inter.TConfAttendVo;
import com.huawang.pojo.inter.TConfDissolution;
import com.huawang.pojo.inter.TConfStatisc;
import com.huawang.pojo.inter.TConfinfoVo;
import com.huawang.pojo.inter.TDepatMentVo;
import com.huawang.util.MailUtil;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;
import com.huawang.util.httpClient;

import net.sf.json.JSONArray;

@Controller
@RequestMapping(value="/meetingRoom")
public class meetRoomInter {

	
	@Autowired
	private MeetingRoomDao meetingRoomDao;
	
	/**
	 * 公共方法验证用户名密码
	 * @param UserName
	 * @param UserPassword
	 * @return 返回消息说明  错误码  企业id
	 * @throws Exception
	 */
	public String[] checkUserInfo(String UserName,String UserPassword) throws Exception {
		
		String message ="";String error_code =""; 
		JSONObject json = new JSONObject();
		String pwd = SecurityUtil.encryptMD5(UserPassword);//给密码加密
		
		String sql ="select  count(1) from t_userinfo where UserName ='"+UserName+"' and UserPassword ='"+pwd+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+pwd+"' AND ((IsSuper = '1')OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		
		String compIDSql = " select CompID from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+pwd+"'";
		String compId = Sqlca.getString(compIDSql)==null?"0":Sqlca.getString(compIDSql);//查询企业compId
		 
		String userIdSql ="select UserID from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+pwd+"'";
		String userID = Sqlca.getString(userIdSql);
		
		if(sqlCount.equals("0") || !count.equals("1") ) {
			if(sqlCount.equals("0")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(!count.equals("1")) {
				message="您不是管理员不能创建会议室！";
				error_code="2";
			} 
			json.put("error_code", error_code);
		}else {
			message="请求成功！";
			error_code="200";
		}
		json.put("message", message);
		String[]str = {message,error_code,compId,userID};
		return str;
	}
	
	/**
	 * 比较开始结束时间先后
	 * @param DATE1
	 * @param DATE2
	 * @return
	 */
	public static int compare_date(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            if (dt1.getTime() > dt2.getTime()) {
                System.out.println("前面的小于后面");
                return 1;
            } else if (dt1.getTime() < dt2.getTime()) {
                System.out.println("前面的大于后面");
                return -1;
            } else {
                return 0;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }
	
	private static boolean isValidDate(String str) {
        boolean convertSuccess = true;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            format.setLenient(false);
            format.parse(str);
        } catch (ParseException e) {
            convertSuccess = false;
        }
        return convertSuccess;
    } 
	
	/**
	 *   用户登录获取用户信息
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/userLogin")
	@ResponseBody
	public Map<String, Object>userLogin(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception{
		String userName= request.getParameter("UserName")==null?"":request.getParameter("UserName");
		String UserPassword = request.getParameter("UserPassword")==null?"":request.getParameter("UserPassword");
		JSONObject json = new JSONObject();
		JSONObject str = new JSONObject();
		
		String message ="";
		String error_code="";
		String pwd = SecurityUtil.encryptMD5(UserPassword);//给密码加密
		String sql ="select IsSuper from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+pwd+"'" ;	//查询用户身份
		String CompSql ="select CompID from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+pwd+"'" ;//查询企业id
		String userSql ="select UserID from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+pwd+"'" ;//查询用户id
		String userId =Sqlca.getString(userSql)==null?"0":Sqlca.getString(userSql);//用户id
		String token = TokenProccessor.getInstance().makeToken();//创建令牌
		
		if(Integer.parseInt(userId)>0) {
			String sqlCount =Sqlca.getString(sql)==null?"":Sqlca.getString(sql);//判断账户密码
			String count =Sqlca.getString(CompSql)==null?"":Sqlca.getString(CompSql);//企业id
			str.put("isSuper", sqlCount);
			str.put("compId", count);
			str.put("userId", userId);
			str.put("token", token);
			json.put("result",str);
			session.setAttribute("token", token); 
			session.setMaxInactiveInterval(86400);
			message="请求成功！";
			error_code="200";
		}else {
			str.put("userId", userId);
			json.put("result",str);
			message="账户或密码错误！";
			error_code="16";
		}
		System.out.println("获取token："+session.getAttribute("token"));
		json.put("message", message);
		json.put("error_code", error_code);
		return json;
	}
	
	
	
	 /**
	  * 	创建会议室
	  * @param UserName 用户名
	  * @param UserPassword 密码
	  * @param ConfName 会议室名
	  * @param ConfPwd 会议密码
	  * @param maxUserCount 最大用户数
	  * @param chairPwd 主席密码
	  * @param isPublic 登录模式  呢称加密0  不加密1  账号2
	  * @param isReservedConf 会议类型  0 固定 1 预约
	  * @param startTime 开始时间
	  * @param endTime	 结束时间
	  * @param isOnOff  会议室状态 0、关闭 1、开启
	  * @return
	  * @throws Exception
	  */
	@RequestMapping(value="/addMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>addMeeting(HttpServletRequest request,String UserName,String UserPassword,String ConfName,String ConfPwd,int MaxUserCount,
			String ChairPwd,String IsPublic,String IsReservedConf,String IsOnOff) throws Exception{
		
		//http://192.168.5.111:8080/vip/meetingRoom/addMeeting.do?UserName='15173509397'&UserPassword='123456'&ConfName='会议仨'&ConfPwd='123456'
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df1.format(new Date());
		
		String pwd = SecurityUtil.encryptMD5(UserPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+UserName+"' and UserPassword ='"+pwd+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+pwd+"' AND ((IsSuper = '1')OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		String compIDSql = " select CompID from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+pwd+"'";
		String getCompID = Sqlca.getString(compIDSql)==null?"0":Sqlca.getString(compIDSql);//查询企业compId
		int compId =Integer.parseInt(getCompID);
		String message = "";
		
		String confSql= "select count(1) from t_confinfo where confName ='"+ConfName+"'";
		String confCount =Sqlca.getString(confSql);//判断会议室是否重名
		
		int mcuIpId=0;int productId=0;int maxUserComp=0;
		TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(compId);
		if(compinfo!=null) {
			mcuIpId = Integer.parseInt(compinfo.getMcuIpId()); //服务器serverId
			productId = compinfo.getProductId()==null?0:compinfo.getProductId(); //产品id
			maxUserComp=compinfo.getMaxUserCount()==null?0:compinfo.getMaxUserCount();
		}
		String StartTime = request.getParameter("StartTime")==null?"":request.getParameter("StartTime");
		String EndTime = request.getParameter("EndTime")==null?"":request.getParameter("EndTime");
		String ConfDesc = request.getParameter("ConfDesc")==null?"":request.getParameter("ConfDesc");
		ConfDesc =Sqlca.switchLatin1Encoding(ConfDesc);
		
		String bAutoBroadcastSelfVideo = request.getParameter("BAutoBroadcastSelfVideo")==null?"":request.getParameter("BAutoBroadcastSelfVideo");//自动广播视频
		String bAutoSpeek = request.getParameter("BAutoSpeek")==null?"":request.getParameter("BAutoSpeek");//申请自动发言
		String bFreeSpeak = request.getParameter("BFreeSpeak")==null?"":request.getParameter("BFreeSpeak");//自由插话
		String bChatP2All = request.getParameter("BChatP2All")==null?"":request.getParameter("BChatP2All");//文字公聊
		String bChatP2P = request.getParameter("BChatP2P")==null?"":request.getParameter("BChatP2P");//文字私聊
		String bClientRecord = request.getParameter("BClientRecord")==null?"":request.getParameter("BClientRecord");//是否录制视频
		
		int date1=0;
		boolean flag =false; 
		boolean flag1=false;
		boolean weekTime =false;
		String addmeetsql = "";
		if(IsReservedConf.equals("0")) {//长期
			date1=0;flag=true;weekTime=true;
			addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
					+ "(0,?,'"+ConfPwd+"','88888','"+MaxUserCount+"',0,0,'',0,'"+IsPublic+"','"+1+"','"+compId+"','"+ChairPwd+"','"+productId+"','"+mcuIpId+"','"+IsReservedConf+"',1,'"+ConfDesc+"')";
		}else if(IsReservedConf.equals("1")){//预约
			weekTime=true;
			flag = isValidDate(StartTime); 
			flag1 = isValidDate(EndTime); 
			if(flag == false || flag1==false) {
				flag =false;
			}
			addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,EndTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
					+ "(0,?,'"+ConfPwd+"','88888','"+MaxUserCount+"',0,0,'','"+StartTime+"','"+EndTime+"',0,'"+IsPublic+"','"+1+"','"+compId+"','"+ChairPwd+"','"+productId+"','"+mcuIpId+"','"+IsReservedConf+"',1,'"+ConfDesc+"')";
			if(StartTime.equals("")||EndTime.equals("")) {
				date1=0;
			}else {
				date1 =compare_date(StartTime, EndTime);
			}
		}else if(IsReservedConf.equals("2")){ //周期
			date1=0;
			flag=true;
			String plan = request.getParameter("Plan")==null?"":request.getParameter("Plan");
			String overTime = request.getParameter("OverTime")==null?"":request.getParameter("OverTime");
			String BeginTime = request.getParameter("BeginTime")==null?"":request.getParameter("BeginTime");
		
			String Begin="";String over="";
			if(BeginTime.equals("")||BeginTime.equals(null) || overTime.equals("")||overTime.equals(null) ) {
				weekTime=false;
				message="时间格式错误";
			}else {
				Begin =BeginTime.substring(0, 2);
				over  =overTime.substring(0, 2);
				if(Begin.equals(over)) {
					Begin =BeginTime.substring(3, 5);
					over  =overTime.substring(3, 5);
				}
			}
			if(Integer.parseInt(Begin)>=Integer.parseInt(over)) {
				weekTime=false;
				message="时间格式错误";
			}else {
				weekTime=true;
				message="ok";
			}
			addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,plan,BeginTime,overTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
					+ "(0,?,'"+ConfPwd+"','88888','"+MaxUserCount+"',0,0,'','"+plan+"','"+BeginTime+"','"+overTime+"',0,'"+IsPublic+"','"+1+"','"+compId+"','"+ChairPwd+"','"+productId+"','"+mcuIpId+"','"+IsReservedConf+"',1,'"+ConfDesc+"')";
		} else { //即时
			date1=0;
			flag=true;
			weekTime=true;
			addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
					+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
					+ "(0,?,'"+ConfPwd+"','88888','"+MaxUserCount+"',0,0,'','"+date+"',0,'"+IsPublic+"','"+1+"','"+compId+"','"+ChairPwd+"','"+productId+"','"+mcuIpId+"','"+IsReservedConf+"',1,'"+ConfDesc+"')";
		}
		String confIdsql = "select ConfID  from t_confinfo where confName  ='"+ConfName+"'";
		JSONObject json = new JSONObject();
		JSONObject jstr = new JSONObject();
		String error_code ="";//错误提示码 
		
		if(sqlCount.equals("0") || !count.equals("1") || confCount.equals("1") ||date1==1 || MaxUserCount>maxUserComp || flag==false ||weekTime==false) {
			if(sqlCount.equals("0")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(!count.equals("1")) {
				message="您不是管理员不能创建会议室！";
				error_code="2";
			}else if(confCount.equals("1")) {
				message="会议室名称已存在！";
				error_code="3"; 
			}else if(flag ==false || weekTime ==false) {
				message="时间格式错误！";
				error_code="14";
			}else if(date1==1) {
				message="预约会议开始时间不能大于结束时间！";
				error_code="4";
			}else if(MaxUserCount>maxUserComp) {
				message="会议室最大用户数不能大于企业最大并发数！";
				error_code="5";
			}
			json.put("error_code", error_code);
		}else { 
			int confMeet = Sqlca.updateObject(addmeetsql, new String[] {ConfName});
			String productSql ="UPDATE t_product_definition SET updateDate ='"+date+"'";
			
			if(bAutoBroadcastSelfVideo!=null && bAutoBroadcastSelfVideo !="") {
						productSql+=" ,bAutoBroadcastSelfVideo ='"+bAutoBroadcastSelfVideo+"'";
					}
					if(bAutoSpeek!=null && bAutoSpeek!="") {
						productSql +=" ,bAutoSpeek = '"+bAutoSpeek+"'";
					}
					if(bFreeSpeak!=null && bFreeSpeak !="") {
						productSql +=" ,bFreeSpeak ='"+bFreeSpeak+"' ";
					}
					if(bChatP2All!=null && bChatP2All!="") {
						productSql+=" ,bChatP2All='"+bChatP2All+"'";
					}
					if(bChatP2P!=null && bChatP2P !="") {
						productSql +=",bChatP2P='"+bChatP2P+"' ";
					}
					if(bClientRecord!=null &&bClientRecord!="") {
						productSql+=",bClientRecord='"+bClientRecord+"'";
					}
					productSql +=" WHERE ProductId ='"+productId+"'";
			if(confMeet>0) {
				String confId = Sqlca.getString(confIdsql);
				Sqlca.updateObject(productSql, new String[] {});//更新产品参数到对应产品
				message="创建会议室成功！";
				error_code="200"; 
				jstr.put("confId", confId);
				json.put("result", jstr);
			}else {
				message="创建会议室失败！";
			}
		}
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	/**
	 *  修改会议室信息
	 *  @param UserName 用户名
	  * @param UserPassword 密码
	  * @param ConfName 会议室名
	  * @param ConfPwd 会议密码
	  * @param maxUserCount 最大用户数
	  * @param chairPwd 主席密码
	  * @param isPublic 登录模式  呢称加密0  不加密1  账号2
	  * @param isReservedConf 会议类型  0 固定 1 预约
	  * @param startTime 开始时间
	  * @param endTime	 结束时间
	  * @param isOnOff  会议室状态 0、关闭 1、开启
	 *  @return
	 *  @throws Exception
	 */
	@RequestMapping(value="/editMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>editMeeting(HttpServletRequest request,String UserName,String UserPassword,int ConfID,String ConfName,String ConfPwd,int MaxUserCount,String ChairPwd,
			String IsPublic,String IsReservedConf,String IsOnOff) throws Exception{
		
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df1.format(new Date());
		String StartTime = request.getParameter("StartTime")==null?"":request.getParameter("StartTime");
		String EndTime = request.getParameter("EndTime")==null?"":request.getParameter("EndTime");
		String plan = request.getParameter("Plan")==null?"":request.getParameter("Plan");
		String overTime = request.getParameter("OverTime")==null?"":request.getParameter("OverTime");
		String BeginTime = request.getParameter("BeginTime")==null?"":request.getParameter("BeginTime");
		String ConfDesc =request.getParameter("ConfDesc")==null?"":request.getParameter("ConfDesc");
		ConfDesc =Sqlca.switchLatin1Encoding(ConfDesc);
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code = str[1];
		int compId = Integer.parseInt(str[2]);
		String message="";
		
		String editSql = "SELECT count(1) from t_confinfo where ConfName ='"+ConfName+"' and ConfID <> "+ConfID;
		String sql =Sqlca.getString(editSql);
		  
		int mcuIpId=0;
		int productId=0;
		int maxUserComp=0;
		TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(compId);
		if(compinfo!=null) {
			mcuIpId = Integer.parseInt(compinfo.getMcuIpId()); //服务器serverId
			productId = compinfo.getProductId(); //产品id
			maxUserComp=compinfo.getMaxUserCount();
		} 
		int date1=0;
		if(IsReservedConf.equals("1")) {
			date1 =compare_date(StartTime, EndTime);
		}
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") || Integer.parseInt(sql)>0 ||date1==1 || MaxUserCount>maxUserComp) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能修改会议室！";
				error_code="2";
			}else if(Integer.parseInt(sql)>0) {
				message="修改会议室重名！";
				error_code="3";
			}else if(date1==1) {
				message="预约会议开始时间不能大于结束时间！";
				error_code="4";
			}else if(MaxUserCount>maxUserComp) {
				message="会议室最大用户数不能大于企业最大并发数！";
				error_code="5";
			}
		}else {
			String editMeetSql = "";
				editMeetSql ="UPDATE t_confinfo set  ";
			if(ConfName!=null && ConfName !="") {
				ConfName=Sqlca.switchLatin1Encoding(ConfName);
				editMeetSql+=" ConfName = '"+ConfName+"'";
			}
			if(ConfPwd!=null && ConfPwd!="") {
				editMeetSql+=" ,ConfPwd = '"+ConfPwd+"'";
			}
			if(String.valueOf(MaxUserCount)!=null && String.valueOf(MaxUserCount)!="") {
				editMeetSql+=" ,MaxUserCount = '"+MaxUserCount+"'";
			}
			if(IsPublic!=null && IsPublic!="") {
				editMeetSql+=" ,IsPublic = '"+IsPublic+"'";
			}
			if(IsOnOff!=null && IsOnOff!="") {
				editMeetSql+=" ,IsOnOff = '"+IsOnOff+"'";
			}
			if(ChairPwd!=null && ChairPwd !="") {
				editMeetSql+=" ,ChairPwd = '"+ChairPwd+"'";
			}
			if(IsReservedConf!=null && IsReservedConf !="") {
				editMeetSql+=" ,IsReservedConf = '"+IsReservedConf+"'";
			}
			if(StartTime !=null && StartTime!="") {
				editMeetSql+=" ,StartTime = '"+StartTime+"'";
			}
			if(EndTime !=null && EndTime !="") {
				editMeetSql+=" ,EndTime = '"+EndTime+"'";
			}
			if(plan!=null && plan !="") {
				editMeetSql+=" ,plan = '"+plan+"'";
			}
			if(BeginTime !=null && BeginTime !="") {
				editMeetSql+=" ,BeginTime = '"+BeginTime+"'";
			}
			if(overTime!=null && overTime!="") {
				editMeetSql+=" ,overTime = '"+overTime+"'";
			}
			if(ConfDesc!=null && ConfDesc!="") {
				editMeetSql+=" ,ConfDesc = '"+ConfDesc+"'";
			}
			editMeetSql+=" WHERE ConfID = '"+ConfID+"'";
			
			String bAutoBroadcastSelfVideo = request.getParameter("BAutoBroadcastSelfVideo")==null?"":request.getParameter("BAutoBroadcastSelfVideo");//自动广播视频
			String bAutoSpeek = request.getParameter("BAutoSpeek")==null?"":request.getParameter("BAutoSpeek");//申请自动发言
			String bFreeSpeak = request.getParameter("BFreeSpeak")==null?"":request.getParameter("BFreeSpeak");//自由插话
			String bChatP2All = request.getParameter("BChatP2All")==null?"":request.getParameter("BChatP2All");//文字公聊
			String bChatP2P = request.getParameter("BChatP2P")==null?"":request.getParameter("BChatP2P");//文字私聊
			String bClientRecord = request.getParameter("BClientRecord")==null?"":request.getParameter("BClientRecord");//是否录制视频
			
			String productSql ="";
			if(bAutoBroadcastSelfVideo!="" || bAutoSpeek!="" || bFreeSpeak!="" || bChatP2All!="" || bChatP2P!="" ||bClientRecord!="") {
				productSql ="UPDATE t_product_definition SET updateDate ='"+date+"' ";
				if(bAutoBroadcastSelfVideo!=null && bAutoBroadcastSelfVideo !="") {
					productSql+=" ,bAutoBroadcastSelfVideo ='"+bAutoBroadcastSelfVideo+"'";
				}
				if(bAutoSpeek!=null && bAutoSpeek!="") {
					productSql +=" ,bAutoSpeek = '"+bAutoSpeek+"'";
				}
				if(bFreeSpeak!=null && bFreeSpeak !="") {
					productSql +=" ,bFreeSpeak ='"+bFreeSpeak+"' ";
				}
				if(bChatP2All!=null && bChatP2All!="") {
					productSql+=" ,bChatP2All='"+bChatP2All+"'";
				}
				if(bChatP2P!=null && bChatP2P !="") {
					productSql +=",bChatP2P='"+bChatP2P+"' ";
				}
				if(bClientRecord!=null &&bClientRecord!="") {
					productSql+=",bClientRecord='"+bClientRecord+"'";
				}  
				productSql +=" WHERE ProductId ='"+productId+"'";
				Sqlca.updateObject(productSql, new String[] {});//更新产品参数到对应产品
			}
			int count = Sqlca.updateObject(editMeetSql, new String[] {});
			if(count>0) {
				message="修改会议室成功！";
			}else {
				error_code="-1";
				message="修改会议室失败！";
			}
		}
		json1.put("confId", ConfID);
		JSONObject json = new JSONObject();
		json.put("result", json1);
		json.put("message", message);
		json.put("error_code", error_code);
		return json;
	}
	 
	/**
	 * 删除会议室
	 * @param UserName
	 * @param UserPassword
	 * @param ConfID
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/delMeeting",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>delMeeting(String UserName,String UserPassword,int ConfID) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code = str[1];
		int compId = Integer.parseInt(str[2]);
		String message="";
		String confSql = "SELECT COUNT(1) from t_confinfo WHERE CompID ="+compId+" AND confId ="+ConfID;
		String conf =Sqlca.getString(confSql);
		
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")||conf.equals("0")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能修改会议室！";
				error_code="2";
			}else if(conf.equals("0")) {
				message="该会议室不在您的企业名下，不能删除！";
				error_code="6";
			}
		}else {
			String delSql ="DELETE FROM t_confinfo WHERE ConfID = "+ConfID;
			int del = Sqlca.updateObject(delSql, new String[] {});
			if(del>0) {
				error_code="200";
				message="删除会议室成功！";
			}else {
				message="删除会议室失败！";
			}
		}
		json1.put("confId", ConfID);
		JSONObject json = new JSONObject();
		json.put("message", message);
		json.put("error_code",error_code);
		return json;
	}
	
	
	/**
	 *  会议室分配参会人员
	 * @param ConfId
	 * @param userId
	 * @param userRight
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/distributAttendUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>distributAttendMeetUser(String UserName,String UserPassword,Integer ConfID,String[] UserIDs) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String message=""; 
		
		JSONObject json = new JSONObject();
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能分配参会列表！";
				error_code="2";
			}  
		}else {
			int count=0;
			try {
			for(int i=0;i<UserIDs.length;i++){
				String userId =UserIDs[i];
				int flag = meetingRoomDao.selectUserInfoDistri(ConfID, Integer.parseInt(userId));
				if(flag<1) {
					String chuxi=Sqlca.switchLatin1Encoding("出席");
					String sql ="INSERT INTO t_confusers(ConfID,UserID,UserRight,UserPos,CsipId,MsipId)values('"+ConfID+"','"+userId+"','"+chuxi+"',0,0,0)";
					sts.addBatch(sql);
					sts.executeBatch();
					count++;
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				sts.close();
				conn.close();
			}
			JSONObject json1 = new JSONObject();
			json1.put("count", count);
			json1.put("ConfId", ConfID);
			message="分配参会人员成功！";
			error_code="200"; 
			json.put("result", json1);
		} 
		json.put("error_code", error_code);
		json.put("message", message);
		 
		return json;
	}
	
	/**
	 * 	取消参会人员
	 * @param UserName
	 * @param UserPassword
	 * @param ConfId 会议id
	 * @param UserIds 参会人员一个或多个
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/delAttendMeetUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>delAttendMeetUser(String UserName,String UserPassword,Integer ConfID,String[] UserIDs) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1]; 
		String message=""; 
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		
		JSONObject json = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能分配参会列表！";
				error_code="2";
			}  
		}else {
			int count=0;
			try {
				for(int i=0;i<UserIDs.length;i++){
					String userId =UserIDs[i];
					String sql ="delete from t_confusers where ConfID ="+ConfID+" and UserID ="+userId;
					sts.addBatch(sql);
					sts.executeBatch();
					count++;
				}
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				sts.close();
				conn.close();
			}
			JSONObject json1 = new JSONObject();
			json1.put("count", count);
			json1.put("ConfId", ConfID);
			message="取消参会人员成功！";
			error_code="200"; 
			json.put("result", json1);
		} 
		json.put("error_code", error_code);
		json.put("message", message);
		
		return json;
	}
	
	/**
	 *  修改会议用户角色
	 * @param UserName
	 * @param UserPassword
	 * @param ConfId
	 * @param UserIds 
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editAttendMeetingUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>editAttendMeetingUser(String UserName,String UserPassword,int ConfID,String[] UserIds,String UserRight) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1]; 
		String message=""; 
		if(UserRight.equals("1")) {
			UserRight="主席";
		}else {
			UserRight="出席";
		}
		JSONObject json1 = new JSONObject();
		JSONObject json = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能参会列表信息！";
				error_code="2";
			}  
		}else {
			int count=0;
			for(int i=0;i<UserIds.length;i++){
				String userId =UserIds[i];
				String edtSql ="update t_confusers set UserRight = ? where ConfID =? and UserID = ?";
				Sqlca.updateObject(edtSql, new String[] {UserRight,String.valueOf(ConfID),userId});
				count++;
			}
			json1.put("count", count);
			json1.put("ConfId", ConfID);
		}
		message="修改成功！";
		error_code="200"; 
		json.put("result", json1); 
		json.put("message", message);
		json.put("error_code", error_code);
		return json;
	}
	
	
	
	/**
	 *  会议管理
	 * @param UserName
	 * @param UserPassword
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/meetingManager",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> meetingManager(String UserName,String UserPassword,String Type,HttpServletRequest request) throws Exception{
		
		//1、会议管理添加  2、会议管理修改 3、会议管理删除
		//1、用户添加 2、用户修改 3、用户删除
		//1、部门添加 2、部门修改 3、部门删除
				
		String CompId = request.getParameter("CompId")==null?"0":request.getParameter("CompId");
		String DpId = request.getParameter("DpId")==null?"0":request.getParameter("DpId");
		String ConfID = request.getParameter("ConfID")==null?"0":request.getParameter("ConfID");
		String LogConfID =request.getParameter("LogConfID")==null?"0":request.getParameter("LogConfID");
		String userID =request.getParameter("UserID")==null?"0":request.getParameter("UserID");
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String message = str[0];
		String error_code =str[1];
		String total="0";
		
		//1、会议管理查询  2、部门查询 3、用户查询 4、会议统计查询 5、会议详情查询 6、客户查询 
		List<Object> obj =  new ArrayList<>();
		JSONObject json = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能查看企业客户！";
				error_code="2";
			}
		}else {
			String sqltotal="";
			String sql="";
			String page = request.getParameter("page")==null?"0":request.getParameter("page");//页数
			String rows = request.getParameter("rows")==null?"0":request.getParameter("rows");//每页显示行数
			int beginrow = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				if(Type.equals("1")) {//会议管理
					sqltotal ="SELECT count(*)from t_confinfo t1  LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID  LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID WHERE 1 = 1 and t1.CompID ="+CompId+"";
					sql="SELECT t1.ConfID AS confId,t1.ConfID AS ids,t1.confName AS confName, t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
							"t1.IsPublic AS isPublic,t1.IsOnOff AS isOnOff,t2.ServerName AS serverName,t2.ServerIP AS serverIp,(select COUNT(*) from t_confusers where ConfID =t1.ConfID) as curUserCount," + 
							"t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan,t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime " + 
							"from t_confinfo t1  LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID  LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID WHERE 1 = 1 and t1.CompID ="+CompId;
					sql +=" limit "+beginrow+","+rows+"";
					obj = Sqlca.getArrayListFromObj(sql, TConfinfoVo.class);
				}
				if(Type.equals("2")) {//部门查询  ||
					 sql =" SELECT DpId,DpName,AdminId,compId,ParentDpId from  t_department where compId ="+CompId;
					 obj =Sqlca.getArrayListFromObjStr(sql, TDepatMentVo.class);
				}
				if(Type.equals("3")) {//用户查询
					 sql =" select t.UserID,t.UserName,t.UserPassword,t.DisplayName,t.CompID,t.DpId   from t_userinfo t where t.DpId= "+DpId+" AND compId= "+CompId+"";
					obj = Sqlca.getArrayListFromObj(sql, TUser.class);
				} 
				if(Type.equals("4")) {//会议统计查询 ||
					sql =" select LogConfID,ConfID,MaxCount,StartTime,EndTime from t_log_conf where ConfID = "+ConfID+"";
					obj =Sqlca.getArrayListFromObj(sql, TConfStatisc.class);
				}
				if(Type.equals("5")) {//会议详情查询
					sql =" select  t.UserID,t.DetailID,t.LogConfID,t.UserName,t.StartTime,t.EndTime,t.Times,t.ConfID,t.LoginIp,t.ConfName from t_log_conf_detail t where t.LogConfID ="+LogConfID;
					obj= Sqlca.getArrayListFromObj(sql, TLogConfDetail.class);
				}
				if(Type.equals("6")) {//客户查询
					sql="select t1.CompId,t1.CompName,t1.CompPassword,t1.CompTrueName,t1.belongAgent,(SELECT t.AdminName from t_admininfo t WHERE t.AdminID =t1.AdminID) AS AdminName,"
							+ "t1.compStyle,(SELECT w.ServerIp from t_serverinfo w WHERE w.ServerID = t1.defualtServer)AS defualtServer,t1.Lianxr,t1.Lianxrtel,"
							+ "t1.MaxUserCount,t1.CreateDate,t1.EndDate from t_compinfo t1 where t1.CompID = "+CompId+" ";
						    obj = Sqlca.getArrayListFromObj(sql, TCompinfoVo.class);
						    message="请求成功！";
					} 
				if(Type.equals("7")) {
					 sql =" select t1.ConfID AS confId,t1.confName AS confName,t1.IsReservedConf AS isReservedConf,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.ConfDesc AS confDesc from t_confinfo t1 " + 
							"LEFT JOIN t_compinfo t2 ON t1.CompID =t2.CompID LEFT JOIN t_confusers t3 ON t1.ConfID = t3.ConfID  " + 
							"WHERE 1 = 1  and t1.CompID= "+CompId+" and t3.UserID ="+userID+" ";
							obj = Sqlca.getArrayListFromObj(sql, TConfAttendVo.class);
						    message="请求成功！";
					}
					//total =Sqlca.getString(sqltotal);
				}
			//json.put("total", total);
			json.put("error_code", error_code);
			json.put("result", obj);
			json.put("message", message);
			return json;
		}
	
	/**
	 * 	会议室列表查询
	 * @param UserName
	 * @param UserPassword
	 * @param Type
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/meetingManager2",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> meetingManager2(String UserName,String UserPassword,String Type,HttpServletRequest request) throws Exception{
				
		String CompId = request.getParameter("CompId")==null?"0":request.getParameter("CompId");
		String sql ="select  count(1) from t_userinfo where UserName ='"+UserName+"' and UserPassword ='"+UserPassword+"'";
		String sqlCount =Sqlca.getString(sql)==null?"":Sqlca.getString(sql);//判断账户密码
	
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+UserPassword+"'and IsSuper = '1'";
		String count = Sqlca.getString(managerSql)==null?"":Sqlca.getString(managerSql);//判断账户是否管理员
		String message ="";String error_code="";

		List<Object> obj =  new ArrayList<>();
		JSONObject json = new JSONObject();
		if(sqlCount.equals("0") || count.equals("0")) {
			if(sqlCount.equals("0")) {
				message="用户名或密码错误！";
				error_code ="1";  
			}else if(!count.equals("1")) {
				message="您不是管理员不能查看企业客户！";
				error_code="2";
			}
		}else {
			String sqlmeeting="";
				if(Type.equals("1")) {//会议管理
					sqlmeeting="SELECT t1.ConfID AS confId,t1.ConfID AS ids,t1.confName AS confName, t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
							"t1.IsPublic AS isPublic,t1.IsOnOff AS isOnOff,t2.ServerName AS serverName,t2.ServerIP AS serverIp,(select COUNT(*) from t_confusers where ConfID =t1.ConfID) as curUserCount," + 
							"t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan,t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime " + 
							"from t_confinfo t1  LEFT JOIN t_serverinfo t2 ON t1.ServerId =t2.ServerID  LEFT JOIN t_compinfo t3 ON t1.CompID =t3.CompID WHERE 1 = 1 and t1.CompID ="+CompId;
							obj = Sqlca.getArrayListFromObj(sqlmeeting, TConfinfoVo.class);
							message="请求成功！";
							error_code="0";
					}
				}
			json.put("error_code", error_code);
			json.put("result", obj);
			json.put("message", message);
			return json;
		}
	
	/**
	 * 	查询会议室新增接口
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectMeetingAdd",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectMeetingAdd(HttpServletRequest request) throws Exception{
		
		JSONObject json = new JSONObject();
		String userName =request.getParameter("UserName")==null?"":request.getParameter("UserName");
		String userPassword = request.getParameter("UserPassword")==null?"":request.getParameter("UserPassword");
		String password = SecurityUtil.encryptMD5(userPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+password+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+userName+"' and UserPassword ='"+password+"' AND ((IsSuper = '1') OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		String compIDSql = " select CompID from t_userinfo where UserName = '"+userName+"' and UserPassword ='"+password+"'";
		String compId = Sqlca.getString(compIDSql)==null?"0":Sqlca.getString(compIDSql);//查询企业compId
		
		String message="";
		String error_code ="";//错误提示码
		List<Object> obj =  new ArrayList<>();
		if(sqlCount.equals("0") || !count.equals("1")) {
			if(sqlCount.equals("0")) {
				error_code="1";
				message="管理员用户名或密码错误！";
			}else if(!count.equals("1")) {
				error_code="2";
				message="您不是管理员不能添加用户！";
			} 
			json.put("error_code", error_code);
		}else { 
			sql="SELECT t1.ConfID AS confId,t1.AdminID AS adminId,t1.confName AS confName, t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
					"t1.IsPublic AS isPublic,t1.IsOnOff AS isOnOff,t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan,t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime,t1.overTime AS overTime " + 
					"from t_confinfo t1 WHERE 1 = 1 and t1.CompID ="+compId + " AND t1.IsNeedSendToJF = 1  AND t1.IsEditNeedTOJF = 0";
			obj = Sqlca.getArrayListFromObj(sql, TConfinfoVo.class);
			if(obj.size()>0) {
				for (Object tConfinfoVo : obj) {
					int confId =((TConfinfoVo) tConfinfoVo).getConfId();
					String JF ="  UPDATE t_confinfo SET IsNeedSendToJF = '0',IsEditNeedTOJF = '0' WHERE ConfID = "+confId+" ";
					Sqlca.updateObject(JF, new String[] {});
				}
			}
			message ="Request successful";
			error_code="200";
		}
		json.put("error_code", error_code);
		json.put("result", obj);
		json.put("message", message);
		return json;
	}
	
	/**
	 * 	查询会议室修改接口
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectMeetingEdit",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectMeetingEdit(HttpServletRequest request) throws Exception{
		
		JSONObject json = new JSONObject();
		String userName =request.getParameter("UserName")==null?"":request.getParameter("UserName");
		String userPassword = request.getParameter("UserPassword")==null?"":request.getParameter("UserPassword");
		String password = SecurityUtil.encryptMD5(userPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+password+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+userName+"' and UserPassword ='"+password+"' AND ((IsSuper = '1') OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		String compIDSql = " select CompID from t_userinfo where UserName = '"+userName+"' and UserPassword ='"+password+"'";
		String compId = Sqlca.getString(compIDSql)==null?"0":Sqlca.getString(compIDSql);//查询企业compId
		
		String message="";
		String error_code ="";//错误提示码
		List<Object> obj =  new ArrayList<>();
		if(sqlCount.equals("0") || !count.equals("1")) {
			if(sqlCount.equals("0")) {
				error_code="1";
				message="管理员用户名或密码错误！";
			}else if(!count.equals("1")) {
				error_code="2";
				message="您不是管理员不能添加用户！";
			} 
			json.put("error_code", error_code);
		}else { 
			sql="SELECT t1.ConfID AS confId,t1.AdminID AS adminId,t1.confName AS confName, t1.MaxUserCount AS maxUserCount,t1.IsReservedConf AS isReservedConf," + 
					"t1.IsPublic AS isPublic,t1.IsOnOff AS isOnOff,t1.ConfPwd AS confPwd,t1.ChairPwd AS chairPwd,t1.plan AS plan,t1.ConfDesc AS confDesc,t1.StartTime AS startTime,t1.EndTime AS endTime,t1.BeginTime AS beginTime,t1.overTime AS overTime " + 
					"from t_confinfo t1 WHERE 1 = 1 and t1.CompID ="+compId + " AND t1.IsEditNeedTOJF = 1 AND t1.IsNeedSendToJF = 0";
			obj = Sqlca.getArrayListFromObj(sql, TConfinfoVo.class);
			if(obj.size()>0) {
				for (Object tConfinfoVo : obj) {
					int confId =((TConfinfoVo) tConfinfoVo).getConfId();
					String JF ="  UPDATE t_confinfo SET IsNeedSendToJF = '0',IsEditNeedTOJF = '0' WHERE ConfID = "+confId+" ";
					Sqlca.updateObject(JF, new String[] {});
				}
			}
			message ="Request successful";
			error_code="200";
		}
		json.put("error_code", error_code);
		json.put("result", obj);
		json.put("message", message);
		return json;
	}
	
	/**
	 * 	解散会议查询
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectMeetingDissolution",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectMeetingDissolution(HttpServletRequest request) throws Exception{
		JSONObject json = new JSONObject();
		String error_code="";String message ="";
		
		String userName =request.getParameter("UserName")==null?"":request.getParameter("UserName");
		String userPassword = request.getParameter("UserPassword")==null?"":request.getParameter("UserPassword");
		String password = SecurityUtil.encryptMD5(userPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+password+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		 
		List<TConfDissolution> obj =  new ArrayList<>();
		if(sqlCount.equals("0")) {
			if(sqlCount.equals("0")) {
				error_code="1";
				message="管理员用户名或密码错误！";
			}
			json.put("error_code", error_code);
		}else { 
			obj = meetingRoomDao.selectDissolutionList();
			for (TConfDissolution tConfDissolution : obj) {
				String JF =" UPDATE t_disconfrecord SET `Status` =0 WHERE ConfID =  "+tConfDissolution.getConfId()+" ";
				Sqlca.updateObject(JF, new String[] {});
			}
			message ="Request successful";
			error_code="200";
		}
		json.put("error_code", error_code);
		json.put("result", obj);
		json.put("message", message);
		return json;
	}
	/**
	 * 参会列表
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectAttendMeetingList",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectAttendMeetingList(HttpServletRequest request) throws Exception{
		
		JSONObject json = new JSONObject();
		String userName =request.getParameter("UserName")==null?"":request.getParameter("UserName");
		String userPassword = request.getParameter("UserPassword")==null?"":request.getParameter("UserPassword");
		String password = SecurityUtil.encryptMD5(userPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+userName+"' and UserPassword ='"+password+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+userName+"' and UserPassword ='"+password+"' AND ((IsSuper = '1') OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		String confId = request.getParameter("ConfId")==null?"":request.getParameter("ConfId");
		
		String message="";
		String error_code ="";//错误提示码
		List<TConfAttendVo> userList = new ArrayList<>();
		List<Object> obj = new ArrayList<>();
		
		if(sqlCount.equals("0") || !count.equals("1")) {
			if(sqlCount.equals("0")) {
				error_code="1";
				message="管理员用户名或密码错误！";
			}else if(!count.equals("1")) {
				error_code="2";
				message="您不是管理员不能添加用户！";
			} 
			json.put("error_code", error_code);
		}else {
			String sql1 = "SELECT userId,userName,displayName,(select t.confName from t_confinfo t where t.confId = "+confId+") as confName FROM t_userinfo WHERE userId IN (SELECT userId from  t_confusers WHERE confId = "+confId+" )";
			obj = Sqlca.getArrayListFromObj(sql1, TAttendUserVo.class);
			message ="Request successful";
			error_code="200";
		}
		json.put("error_code", error_code);
		json.put("result", obj);
		json.put("message", message);
		return json;
	}
	
	
/**
	 * 	添加用户
	 * @param UserName 用户名
	 * @param UserPassword 密码
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> addUser(HttpServletRequest request,String UserName,String UserPassword,String User,String Pwd,int DpId,String DisplayName) throws Exception {
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");//设置日期格式
		String date = df1.format(new Date());
		
		String isSuper =request.getParameter("IsSuper")==null?"":request.getParameter("IsSuper");
		String password = SecurityUtil.encryptMD5(UserPassword);//给密码加密
		String sql ="select  count(1) from t_userinfo where UserName ='"+UserName+"' and UserPassword ='"+password+"'";
		String sqlCount =Sqlca.getString(sql);//判断账户密码
		String managerSql ="select  count(1) from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+password+"' AND ((IsSuper = '1')OR (IsSuper = '2'))";
		String count = Sqlca.getString(managerSql);//判断账户是否管理员
		String compIDSql = " select CompID from t_userinfo where UserName = '"+UserName+"' and UserPassword ='"+password+"'";
		String CompID = Sqlca.getString(compIDSql)==null?"0":Sqlca.getString(compIDSql);//查询企业compId
		Pwd =SecurityUtil.encryptMD5(Pwd);
		
		String addSQL="INSERT into t_userinfo(UserName,UserPassword,CompID,createtime,DpId,DisplayName,State,IsSuper)VALUES(?,?,?,?,?,?,1,?)";//添加用户
		String selUserId = "SELECT UserID from t_userinfo where UserName = '"+User+"'";//查询用户id
		String IsSql = "  SELECT count(1) FROM t_userinfo WHERE CompID = "+CompID+" AND IsSuper =1"; 
		String isCount =Sqlca.getString(IsSql);
		
		JSONObject json = new JSONObject();
		String message="";String error_code ="";//错误提示码
		if(sqlCount.equals("0") || !count.equals("1") ||isCount.equals(isSuper)) {
			if(sqlCount.equals("0")) {
				error_code="1";
				message="管理员用户名或密码错误！";
			}else if(!count.equals("1")) {
				error_code="2";
				message="您不是管理员不能添加用户！";
			} else if(isCount.equals(isSuper)) {
				error_code="16";
				message="已存在超级管理员";
			}
			json.put("error_code", error_code);
		}else { 
			JSONObject jsonObj = new JSONObject();
			StringBuilder budider = new StringBuilder("SELECT count(1) from  t_userinfo   WHERE UserName = '"+User+"'");
			String userCount = Sqlca.getString(budider.toString());//判断是否重名
			
			if(Integer.parseInt(userCount)>0) {
				error_code="7";
				message="用户名已经存在！";
			}else {
				int addUser = Sqlca.updateObject(addSQL, new String[] {User,Pwd,CompID,date,String.valueOf(DpId),DisplayName,isSuper});
				if(addUser>0) {
					error_code="200";
					String userId = Sqlca.getString(selUserId);
					message="添加用户成功！";
					jsonObj.put("userId", userId);
					json.put("result", jsonObj);
				}else {
					message="添加用户失败！";
				}
			}
		}
		json.put("error_code", error_code);
		json.put("message", message);
		return json; 
	}
	
	/**
	  *    编辑用户信息
	 * @param UserName
	 * @param UserPassword
	 * @param User
	 * @param Pwd
	 * @param DisplayName
	 * @param UserID 用户id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/editUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> editUser(String UserName,String UserPassword,String User,String DisplayName,String UserID,HttpServletRequest request) throws Exception {
		
		String Pwd = request.getParameter("Pwd")==null?"":request.getParameter("Pwd");		
		String DpId =request.getParameter("DpId")==null?"":request.getParameter("DpId");
		String IsSuper =request.getParameter("IsSuper")==null?"0":request.getParameter("IsSuper");
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId = str[2];
		String message=""; 
		
		StringBuilder budider = new StringBuilder("SELECT count(1) from  t_userinfo   WHERE UserName = '"+User+"' and UserID <>"+UserID);
		String userCount = Sqlca.getString(budider.toString());//判断是否重名
		
		String sqldp = " select count(1) from t_userinfo where CompID ="+compId+" and UserID ="+UserID+"";
		String cout = Sqlca.getString(sqldp);
		String IsSql = "  SELECT count(1) FROM t_userinfo WHERE CompID = "+compId+" AND IsSuper =1"; 
		String isCount =Sqlca.getString(IsSql);
		
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") || userCount.equals("1") || !cout.equals("1")||isCount.equals(IsSuper)) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建用户！";
				error_code="2";
			}else if(userCount.equals("1")) {
				message="用户名已经存在！";
				error_code="7";
			} else if(!cout.equals("1")) {
				message="企业不存在该用户！";
				error_code="8";
			}else if(isCount.equals(IsSuper)) {
				error_code="16";
				message="已存在超级管理员";
			}
		}else {
			if(Pwd=="" || Pwd ==null) {
				String sql =" UPDATE t_userinfo SET UserName='"+User+"',DisplayName=?,IsSuper ='"+IsSuper+"' WHERE  UserID= "+UserID+" ";
				Sqlca.updateObject(sql, new String[] {DisplayName});
			}else {
				Pwd = SecurityUtil.encryptMD5(Pwd);
				String sql =" UPDATE t_userinfo SET UserName='"+User+"',UserPassword='"+Pwd+"',DisplayName=?,IsSuper ='"+IsSuper+"' WHERE  UserID= "+UserID+" ";
				Sqlca.updateObject(sql, new String[] {DisplayName});
			}
			message="修改用户成功！";
			error_code="200";
			json1.put("userId", UserID);
			json.put("result", json1);
		}
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	
	/**
	 * 	删除企业用户
	 * @param UserName
	 * @param UserPassword
	 * @param UserID
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/delUser",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>delUser(String UserName,String UserPassword,String UserID) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId = str[2];
		String message=""; 

		String selSql =" select  count(1) from t_userinfo where CompID ="+compId+" AND UserID = "+UserID;
		String sel = Sqlca.getString(selSql);
		
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") || !sel.equals("1")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建部门！";
				error_code="2";
			}else if(!sel.equals("1")) {
				message="该用户不属于您的企业，不能删除！";
				error_code="8";
			} 
		}else {
			String sql = "DELETE FROM t_userinfo where UserID = "+UserID+"";
			Sqlca.updateObject(sql, new String[] {});
			message="删除用户成功！";
			json1.put("userId", UserID);
			json.put("result", json1);
		}
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	
	
	
	/**
	  *    添加部门
	 * @param UserName
	 * @param UserPassword
	 * @param DpName
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/addDeptMent",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>addDeptMent(String UserName,String UserPassword,HttpServletRequest request) throws Exception{
		
		String DpName = request.getParameter("DpName")==null?"":request.getParameter("DpName");
		String ParentDpId =request.getParameter("ParentDpId")==null?"0":request.getParameter("ParentDpId");
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId =str[2]; 
		String message=""; 
		String dparent = Sqlca.getString("select ParentDpId from t_department  where DpId='"+ParentDpId+"' and compid="+compId);//查询父部门id
		if(dparent==null) {
			ParentDpId="1";
		}
		
		String dp = Sqlca.getString("select DpId from t_department  where DpName='"+DpName+"' and compid="+compId);//查询部门id
		
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") || dp!=null) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建部门！";
				error_code="2";
			}else if(dp!=null) {
				message="部门已存在！";
				error_code="9";
			} 
		}else {
			Sqlca.updateObject("insert into t_department(codeno,dpname,description,ParentDpId,adminid,ordervalue,compid)values ('',?,?,?,"+compId+",'0',"+compId+")", new String[] {DpName,UserName,ParentDpId});
			String dp1 = Sqlca.getString("select DpId from t_department  where DpName='"+DpName+"' and compid="+compId);//查询部门id
			String parenId = Sqlca.getString(" select ParentDpId from t_department  where DpName='"+DpName+"' and compid="+compId);
			
			message="添加部门成功！";
			error_code="200";
			json1.put("parentDpId", parenId);
			json1.put("dpId", dp1);//查询部门id
		} 
		json1.put("compId", compId);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	/**
	 * 	修改部门信息
	 * @param UserName
	 * @param UserPassword
	 * @param DpId
	 * @param DpName
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editDeptMent",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> editDeptMent(String UserName,String UserPassword,HttpServletRequest request) throws Exception{
		
		
		String DpId = request.getParameter("DpId")==null?"":request.getParameter("DpId");
		String ParentDpId =request.getParameter("ParentDpId")==null?"":request.getParameter("ParentDpId");
		String DpName = request.getParameter("DpName")==null?"":request.getParameter("DpName");
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId =str[2]; 
		String message=""; 
		String dp = Sqlca.getString("select DpId from t_department  where DpName='"+DpName+"' and compid='"+compId+"' AND DpId <>'"+DpId+"' ");//查询部门id
		String dp1="";
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") || dp!=null) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建部门！";
				error_code="2";
			}else if(dp!=null) {
				message="修改企业部门名称重复！";
				error_code="9";
			} 
		}else {
			String editSql ="";
			if(ParentDpId.equals("") || DpName.equals("")) {
				if(ParentDpId.equals("")) {
					editSql =" UPDATE t_department SET DpName =? WHERE DpId = "+DpId+" ";
				}else if(DpName.equals("")) {
					editSql =" UPDATE t_department SET ParentDpId ="+ParentDpId+" WHERE DpId = "+DpId+" and compId = "+compId+"";
				}
			}else {
				editSql =" UPDATE t_department SET ParentDpId ="+ParentDpId+" ,DpName =? WHERE DpId = "+DpId+" and compId = "+compId+"";
			}
			int edit =Sqlca.updateObject(editSql, new String[] {DpName});
			
			if(edit==1) {
				String parenId = Sqlca.getString(" select ParentDpId from t_department  where DpName='"+DpName+"' and compid="+compId);
				dp1 = Sqlca.getString("select DpId from t_department  where DpName='"+DpName+"' and compId="+compId);//查询部门id
				json1.put("parentDpId", parenId);
				json1.put("dpId", dp1);
				message="修改部门成功！";
				error_code="200";
			}else {
				message="修改部门失败！";
			}
		}  
		json1.put("compId", compId);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	
	/**
	   *    删除企业部门 
	 * @param UserName
	 * @param UserPassword
	 * @param DpId
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/delDeptMent",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>delDeptMent(String UserName,String UserPassword,int DpId) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId =str[2]; 
		String message=""; 
		
		String dp = Sqlca.getString("select DpId from t_department t where DpId='"+DpId+"' and compId="+compId);//查询部门id
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2") ||dp==null) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建部门！";
				error_code="2";
			}else if(dp==null) {
				message="您企业不存在该部门！";
				error_code="10";
			}
		}else {
			String delSql =" DELETE FROM t_department WHERE DpId = "+DpId+"";
			Sqlca.updateObject(delSql, new String[] {});
			json1.put("dpId", dp);
			message="删除部门成功！";
			error_code="200";
		}
		json1.put("compId", compId);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	 /**
	    *  新增客户
	  * @param UserName 管理员用户名
	  * @param UserPassword 管理员密码
	  * @param CompName	客户账户
	  * @param CompPassword 客户账户密码
	  * @param CompTrueName 客户名称
	  * @param belongAgent 所属代理商
	  * @param AdminName   客户管理员
	  * @param compStyle  客户类型
	  * @param defualtServer 默认服务器
	  * @param Lianxr  联系人
	  * @param Lianxrtel 联系方式
	  * @return
	  * @throws Exception
	  */
	@RequestMapping(value="/addCustomer",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> addCustomer(HttpServletRequest request,String UserName,String UserPassword,String CompName,String CompPassword,String CompTrueName,String BelongAgent,
			String AdminName,int CompStyle,String Lianxr,String Lianxrtel,int MaxUserCount,String CreateDate,String EndDate) throws Exception {
		
		String product = request.getParameter("ProductId")==null?"":request.getParameter("ProductId");
		String pro = " SELECT ProductId from t_product_definition WHERE ProductId = "+product+"";
		String ProductId = Sqlca.getString(pro)==null?"":Sqlca.getString(pro); //查询产品id
		 
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df1.format(new Date());
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String compId =str[2]; 
		String message=""; 
		CompPassword = SecurityUtil.encryptMD5(CompPassword);
		
		String adminsql ="select AdminID from t_admininfo where AdminName ='"+AdminName+"'";
		String AdminID =Sqlca.getString(adminsql)==null?"":Sqlca.getString(adminsql);
		String admin="";

		String ServerID = request.getParameter("ServerID")==null?"":request.getParameter("ServerID");
		String serverSql=" select ServerID from t_serverinfo where ServerID ='"+ServerID+"' AND ((ServerType = '0' AND IsPad = '0') OR (ServerType = '1' AND IsPad = '0')OR (ServerType = '0' AND IsPad = '1'))"; 
		String server = Sqlca.getString(serverSql)==null?"":Sqlca.getString(serverSql);//客户默认服务器
		
		String compCount = Sqlca.getString("select count(1) from t_compinfo where CompName = '"+CompName+"'"); 
		String userCount = Sqlca.getString("select count(1) from t_userinfo where UserName ='"+CompName+"'");
		
		if(AdminID.equals(null) || AdminID.equals("")) {
			admin="1";
		}
		
		String compid="";
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")||admin.equals("1") || Integer.parseInt(compCount)>0 ||Integer.parseInt(userCount)>0 ||ProductId.equals("") || server.equals("")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能创建客户！";
				error_code="2";
			}else if(admin.equals("1")) {
				message="管理员账户不存在！";
				error_code="11";
			}else if(Integer.parseInt(compCount)>0) {
				message="新建客户名称重复!";
				error_code="12";
			}else if(Integer.parseInt(userCount)>0) {
				message="新建用户名称重复!";
				error_code="7";
			}else if(ProductId.equals("")) {
				message="产品不存在！";
				error_code="13";
			}else if(server.equals("")) {
				message="ServerID对应的非CS服务器！";
			}
		}else {
				String addSql ="INSERT INTO t_compinfo(CompName,CompPassword,CompTrueName,Lianxr,Lianxrtel,belongAgent,compStyle,MaxCurUserCount,      "
				+ "IsDate,IsAddUser,IsConfLogin,CreateDate,AdminID,allocatAdmin,defualtServer,CompStatus,createuser,MaxConfCount,MaxUserCount,McuipId,EndDate,productID)"
				+ "VALUES(?,?,?,?,?,?,'"+CompStyle+"',999,1,1,1,'"+date+"','"+AdminID+"',?,?,1,?,1,'"+MaxUserCount+"',?,'"+EndDate+"','"+ProductId+"')";
			Sqlca.updateObject(addSql, new String[] {CompName,CompPassword,CompTrueName,Lianxr,Lianxrtel,
				BelongAgent,"1",server,CompName,server});
			String selectGetKey =" select compId from t_compinfo where  CompName ='"+CompName+"'";
			compid = Sqlca.getString(selectGetKey);
			
			String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
					" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
					" VALUES(?,'1',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
			int cnt = Sqlca.updateObject(insertOrder, new String[] {"1","1","1",ProductId,"100","10",date,"2030-10-10 12:12:12","100","","guijie","1"});
			String addCustPert="insert into t_compinfo_product(compId,productId)VALUES(?,?)";
			int CustPert = Sqlca.updateObject(addCustPert, new String[] {compid,ProductId});
					String addUserInfo =" INSERT INTO t_userinfo (AdminID,CompID,UserName,UserPassword,DisplayName,Telephone,IsSuper,createtime,DpId)VALUES('"+AdminID+"',"+
					compid+",?,?,?,?,'1','"+date+"',1)";
			Sqlca.updateObject(addUserInfo, new String[] {CompName,CompPassword,Lianxr,Lianxrtel});	
			message="添加客户成功！";
		}
		json1.put("compId", compid);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	/**
	 *   修改客户信息
	 * @param UserName
	 * @param UserPassword
	 * @param CompName
	 * @param CompPassword
	 * @param CompTrueName
	 * @param BelongAgent
	 * @param AdminName
	 * @param CompStyle
	 * @param DefualtServer
	 * @param Lianxr
	 * @param Lianxrtel
	 * @param MaxUserCount
	 * @param CreateDate
	 * @param EndDate
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/editCustomer",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>editCustomer(HttpServletRequest request,String UserName,String UserPassword,String CompName,String CompPassword,String CompTrueName,String BelongAgent,String AdminName,
			String Lianxr,String Lianxrtel,int MaxUserCount,String CreateDate,String EndDate,int CompID) throws Exception {
		
		String product = request.getParameter("ProductId")==null?"0":request.getParameter("ProductId");
		String pro = " SELECT ProductId from t_product_definition WHERE ProductId = "+product+"";
		String ProductId = Sqlca.getString(pro)==null?"":Sqlca.getString(pro); //查询产品id
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");//设置日期格式
		String date = df1.format(new Date());
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String message=""; 
		CompPassword = SecurityUtil.encryptMD5(CompPassword);
		
		String adminsql ="select AdminID from t_admininfo where AdminName ='"+AdminName+"'";
		String AdminID =Sqlca.getString(adminsql)==null?"":Sqlca.getString(adminsql);
		String admin="";
		 
		String ServerID = request.getParameter("ServerID")==null?"":request.getParameter("ServerID");
		String serverSql=" select ServerID from t_serverinfo where ServerID ='"+ServerID+"' AND ((ServerType = '0' AND IsPad = '0') OR (ServerType = '1' AND IsPad = '0')OR (ServerType = '0' AND IsPad = '1'))"; 
		String server = Sqlca.getString(serverSql)==null?"":Sqlca.getString(serverSql);//客户默认服务器
		
		
		String compCount = Sqlca.getString("select count(1) from t_compinfo where CompName = '"+CompName+"' AND CompID <>"+CompID); 
		 
		if(AdminID.equals(null) || AdminID.equals("")) {
			admin="1";
		}
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")||admin.equals("1") || Integer.parseInt(compCount)>0 ||ProductId.equals("")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能修改客户！";
				error_code="2";
			}else if(admin.equals("1")) {
				message="管理员账户不存在！";
				error_code="11";
			}else if(Integer.parseInt(compCount)>0) {
				message="修改客户名称重复!";
				error_code="12";
			}else if(ProductId.equals("")) {
				message="产品不存在！";
				error_code="13";
			}else if(server.equals("")) {
				error_code="15";
				message="ServerID对应的非CS服务器！";
			}
		}else {
			String updSql ="UPDATE t_compinfo SET CompName= ?,CompPassword=?,CompTrueName=?,BelongAgent=?,"
					+ "AdminID=?,DefualtServer=?,Lianxr=?,Lianxrtel=?,MaxUserCount=?," + 
					" EndDate=?,productID=?  where CompID ="+CompID+" ";
			Sqlca.updateObject(updSql, new String[] {CompName,CompPassword,CompTrueName,BelongAgent,AdminID,server,Lianxr,Lianxrtel,String.valueOf(MaxUserCount),EndDate,ProductId});
			message="修改客户成功！";
			error_code="200";
		}
		json1.put("compId", CompID);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	
	/**
	 *  删除客户
	 * @param UserName
	 * @param UserPassword
	 * @param CompID
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/delCustomer",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>delCustomer(String UserName,String UserPassword,int CompID) throws Exception {
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String message=""; 
		UserPassword = SecurityUtil.encryptMD5(UserPassword);
		
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能删除部门！";
				error_code="2";
			}
		}else {
			String delCom = " delete from t_compinfo WHERE CompID = "+CompID+" ";
			int com = Sqlca.updateObject(delCom, new String[] {});
			if(com>0) {
				message="删除客户成功！";
				error_code="200";
			}else {
				message="删除客户失败";
				error_code="-1";
			}
		}
		json1.put("compId", CompID);
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
		
	
	/**
	 * 	查询客户信息
	 * @param UserName
	 * @param UserPassword
	 * @param CompID
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selCustomer",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>selCustomer(String UserName,String UserPassword,int CompID) throws Exception {
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code =str[1];
		String message=""; 
		
		JSONObject json = new JSONObject();
		List<Object> obj =  new ArrayList<>(); 
		 
		if(error_code.equals("1") || error_code.equals("2")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能查看企业客户！";
				error_code="2";
			}
		}else {
			String selSql ="select t1.CompId,t1.CompName,t1.CompPassword,t1.CompTrueName,t1.belongAgent,(SELECT t.AdminName from t_admininfo t WHERE t.AdminID =t1.AdminID) AS AdminName,"
					+ "t1.compStyle,(SELECT w.ServerIp from t_serverinfo w WHERE w.ServerID = t1.defualtServer)AS defualtServer,t1.Lianxr,t1.Lianxrtel,"
					+ "t1.MaxUserCount,t1.CreateDate,t1.EndDate from t_compinfo t1 where t1.CompID = "+CompID+" ";
				    obj = Sqlca.getArrayListFromObj(selSql, TCompinfo.class);
				    message="请求成功！";
		}
		
		json.put("result",obj);
		json.put("message",message);
		json.put("error_code",error_code);
		return json;
	}
	
	/**
	 * 	发送邮件 --通知参会人
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/sendEmail",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> sendEmail(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String UserName = request.getParameter("UserName")==null?"0":request.getParameter("UserName");
		String UserPassword = request.getParameter("UserPassword")==null?"0":request.getParameter("UserPassword");
		String[] str = checkUserInfo(UserName, UserPassword);
		String compId = str[2];
		
		JSONObject json = new JSONObject();
		String message ="";
		String error_code ="";
		String confid = request.getParameter("ConfId");
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap("select t.SmtpAddr,t.SmtpPort,t.SmtpUserName,t.SmtpUserMail,t.SmtpUserPwd,t.SmtpId,"
				+ "t.CompId,t.InNetAddress,t.OutNetAddress from t_smtpinfo t where t.CompId="+compId);
		
		String sql = "select Email from t_userinfo u where u.UserID in(select UserID from t_confusers where ConfID="+confid+") AND Email is not null";
		
		String contentsql = "select ConfName,StartTime,EndTime,ConfID,ConfPwd,ConfDesc from t_confinfo where ConfID="+confid;
		ArrayList<Map<String, Object>> ct = Sqlca.getArrayListFromMap(contentsql);
		
		Map<String, Object> ccc =ct.get(0);
		
		ArrayList<Map<String, Object>> maillist = Sqlca.getArrayListFromMap(sql);
		
		ArrayList<String> receiveList = new ArrayList<String>();
		for(Map<String, Object> map : maillist)
		{
			String mm = (String)map.get("Email");
			if(!"".equals(mm) && null!=mm)
			{
				receiveList.add(mm);	
			}
		}
		
		if(list.size()==0)
		{
			message="邮件服务器未配置";
			error_code="13";
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
		}
		
		Map<String, Object> smt = list.get(0);
		String SmtpAddr = (String)smt.get("SmtpAddr");
		String SmtpPort = (String)smt.get("SmtpPort");
		String SmtpUserName = (String)smt.get("SmtpUserName");
		String SmtpUserMail = (String)smt.get("SmtpUserMail");
		String SmtpUserPwd = (String)smt.get("SmtpUserPwd");
		String[] receives = new String[receiveList.size()];
		receives = (String[]) receiveList.toArray(receives);
		if(receiveList.size()==0)
		{
			message="参会成员邮箱地址未配置";
			error_code="14";
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
			
		}
		String content = "会议室名:"+ccc.get("ConfName").toString()
				+ "<br>会议时间:"+ccc.get("StartTime").toString()+" - "+ccc.get("EndTime").toString()
				+ "<br>会议号:"+ccc.get("ConfID")
				+ "<br>会议密码:"+ccc.get("ConfPwd")
				+ "<br>会议说明:"+ccc.get("ConfDesc").toString();
		
		String msg = MailUtil.sendMail(SmtpAddr, SmtpPort, SmtpUserMail, SmtpUserPwd,SmtpUserName, receives, content,ccc.get("ConfName").toString());
		
		if("yes".equals(msg))
		{
			message="邮件发送成功！";
			error_code="200";
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
		}
		else
		{
			message="邮件发送失败,请检查网络和邮件服务器配置！";
			error_code="15";
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
		}
	}
	
	/**
	 * 终止会议室
	 * @param UserName
	 * @param UserPassword
	 * @param ConfID
	 * @param ConfName
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/stopMeeting",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>stopMeeting(String UserName,String UserPassword,int ConfID,String ConfName) throws Exception{
		
		String[] str = checkUserInfo(UserName, UserPassword);
		String error_code = str[1];
		int compId = Integer.parseInt(str[2]);
		String message="";
		String confSql = "SELECT COUNT(1) from t_confinfo WHERE CompID ="+compId+" AND confId ="+ConfID;
		String conf =Sqlca.getString(confSql);
		
		JSONObject json = new JSONObject();
		JSONObject json1 = new JSONObject();
		if(error_code.equals("1") || error_code.equals("2")||conf.equals("0")) {
			if(error_code.equals("1")) {
				message="用户名或密码错误！";
				error_code ="1";
			}else if(error_code.equals("2")) {
				message="您不是管理员不能终止会议室！";
				error_code="2";
			}else if(conf.equals("0")) {
				message="该会议室不在您的企业名下，不能操作！";
				error_code="6";
			}
		}else {
			String upSql = " UPDATE t_confinfo SET IsOnOff =0 WHERE ConfID =? AND ConfName=? ";
			Sqlca.updateObject(upSql, new String[] {String.valueOf(ConfID),ConfName});
			message="关闭成功！";
			error_code="200";
		}
		json.put("message", message);
		json.put("error_code", error_code);
		json1.put("ConfName", ConfName);
		json.put("result", json1);
		return json;
	}
	
	/**
	  * 高德根据IP获取省市
	  * @param cph
	  * @return
	  * @throws Exception
	  */
	 public static String ipGetCity(String ip) throws Exception{
		 	 
		 	String key ="780435d689f5fc3782b4942de06dcb6f";
		 	String result =null;
		 	String url = "http://restapi.amap.com/v3/ip?ip="+ip+"&output=json&key="+key;
	        Map params = new HashMap();//请求参数
	            params.put("ip",ip);//获取到的ip
	            params.put("key",key);//密钥
	            result = httpClient.net(url, params, "GET");
	            System.out.println("返回城市信息："+result);
	            String ii = getCity(result);
			   return ii;
	    }
	 
	 	public static String getCity(String result){
	 		
	 		net.sf.json.JSONObject jsonStr = net.sf.json.JSONObject.fromObject(result);
	 		JSONArray jsonArr = JSONArray.fromObject(jsonStr);
	 		String province ="";String city="";
	 		int status=0; String info ="";
	 		for (int i = 0; i < jsonArr.size(); i++) {
				net.sf.json.JSONObject jsonObj = jsonArr.getJSONObject(i);
	 			province = jsonObj.getString("province");
	 			city =  jsonObj.getString("city");
	 			status = jsonObj.getInt("status");
				info = jsonObj.getString("info");
			}
	 		String str = province+city ;
	 		return str;
	 	}
	
	@RequestMapping(value="/getLocalRegion",method = {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String getLocalRegion(HttpServletRequest request,TConfinfo confinfo,HttpServletResponse response) throws Exception {
		
		int detailId = Integer.parseInt(request.getParameter("detailId"));
		String loginIp = Sqlca.getString("SELECT LoginIp from t_log_conf_detail WHERE DetailID="+detailId);
		String region ="";
		int count =0;String pp="";
		if(!String.valueOf(detailId).equals("") && !String.valueOf(detailId).equals(null)) {
			pp = ipGetCity(loginIp);
			region =pp;
			if(!region.equals(null)&&!region.equals("")) {
				String upSql ="UPDATE t_log_conf_detail SET region =? WHERE DetailID = ?";
				count =Sqlca.updateObject(upSql, new String[] {region,String.valueOf(detailId)});
			}
		}
		JSONObject json = new JSONObject();
		if(count>0) {
			json.put("message", "success");
			json.put("region", pp);
			json.put("loginIp", loginIp);
		}else {
			json.put("message", "fail");
		}
		return json.toString();
	}
	

/*	public static void main(String[] args) throws Exception {
		
		Map<String, Object> map = new HashMap<String,Object>();
		
		meetRoomInter meet = new meetRoomInter();
		
		//map = meet.addMeeting("15173509397", "123456", "会议室", "123456");
		
		
		System.out.println("返回参数map:"+map);
	}*/
	
	
	
	
}
