package com.huawang.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.util.Sqlca;

@Controller
public class CommonController {

	@RequestMapping(params = "Option_UserStatus")
	@ResponseBody
	public String OptionCommon(HttpServletRequest request) throws Exception 
	{
//		String us = request.getParameter("userStatus");
		String sql = "select op_value,op_display from t_option where op_param='userStatus'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_DepartMent")
	@ResponseBody
	public String DepartMentCommon(HttpServletRequest request,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		String sql = "select dpid as op_value,dpname as op_display from t_department where dpid=1 or compid="+compid;
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_UserRole")
	@ResponseBody
	public String UserRoleCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select role_id as op_value,role_name as op_display from t_roles";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	
	@RequestMapping(params = "Option_Sex")
	@ResponseBody
	public String SexCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='sex'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Flag")
	@ResponseBody
	public String FlagCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='flag'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Product")
	@ResponseBody
	public String ProductCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select ProductId as op_value,ProductName as op_display from t_product_definition";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Admin")
	@ResponseBody
	public String AdminCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select AdminID as op_value,AdminTrueName as op_display from t_admininfo";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_OrderType")
	@ResponseBody
	public String OrderTypeCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='orderType'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_ApproveStatus")
	@ResponseBody
	public String ApproveStatuCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='approveStatus'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_CompanyName")
	@ResponseBody
	public String CompanyNameCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select CompID as op_value,CompTrueName as op_display from t_compinfo";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	
	@RequestMapping(params = "Option_ServerName")
	@ResponseBody
	public String Option_ServerName(HttpServletRequest request) throws Exception 
	{
		String sql="select ServerID as op_value,ServerName as op_display from t_serverinfo "+
				" where ((ServerType = '0' AND IsPad = '0') OR (ServerType = '1' AND IsPad = '0'))";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
}
