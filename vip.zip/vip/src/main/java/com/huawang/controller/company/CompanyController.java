package com.huawang.controller.company;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.dao.company.CompanyDao;
import com.huawang.dao.company.ConfDao;
import com.huawang.dao.company.DeviceDao;
import com.huawang.dao.company.OrderDao;
import com.huawang.dao.company.PackageDao;
import com.huawang.dao.company.ProductDao;
import com.huawang.pojo.company.CompinfoVOExtend;
import com.huawang.pojo.company.DeviceRecordVO;
import com.huawang.pojo.company.DeviceVO;
import com.huawang.pojo.company.LogConfVOExtend;
import com.huawang.pojo.company.OrderVOExtend;
import com.huawang.pojo.company.ProductVO;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.result.CodeMsg;
import com.huawang.pojo.result.Page;
import com.huawang.pojo.result.Result;
import com.huawang.util.DateUtil;

@Controller
@RequestMapping("company")
public class CompanyController {

	private static final Logger logger = LogManager.getLogger(CompanyController.class);
	
	@Autowired
	private CompanyDao companyDao;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private OrderDao orderDao;
	@Autowired
	private ConfDao confDao;
	@Autowired
	private PackageDao packageDao;
	@Autowired
	private DeviceDao deviceDao;
	/**
	 *  查询公司基本信息和产品信息
	 * @param session
	 * @return
	 */
	@RequestMapping("concurrentCompany.do")
	public ModelAndView concurrentCompany(HttpSession session) {
		Object obj = session.getAttribute("USER_VIPSESSION");
		ModelAndView mv=new ModelAndView("company/concurrentCompany");
		Integer compId = null;
		try {
			if(obj!=null){
				TUserinfo userinfo = (TUserinfo)obj;
				compId = userinfo.getCompID();
				//userinfo.getSellType()  1：时间类，2：并发类
				CompinfoVOExtend compinfoVOExtend=companyDao.getCompInfo(compId);
				mv.addObject("compInfo",compinfoVOExtend);
				logger.info("查询企业信息成功！企业ID:"+compId);
				ProductVO productVO=productDao.getProductInfo(compinfoVOExtend.getProductID());
				mv.addObject("productInfo",productVO);
				logger.info("查询企业正在使用的产品信息成功！产品ID:"+compinfoVOExtend.getProductID());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("查询企业信息异常！企业ID:"+compId, e);
		}
		return mv;
	}
	
	
	/**
	 * 查询公司资本信息
	 * @return
	 */
	@RequestMapping("concurrentCompInfo.do")
	public ModelAndView concurrentCompInfo(HttpSession session) {
		Object obj = session.getAttribute("USER_VIPSESSION");
		ModelAndView mv=new ModelAndView("company/concurrentCompInfo");
		Integer compId = null;
		try {
			if(obj!=null){
				TUserinfo userinfo = (TUserinfo)obj;
				compId = userinfo.getCompID();
				//userinfo.getSellType()  1：时间类，2：并发类
				CompinfoVOExtend compinfoVOExtend=companyDao.getCompInfo(compId);
				mv.addObject("compInfo",compinfoVOExtend);
				logger.info("查询企业信息成功！企业ID:"+compId);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("查询企业信息异常！企业ID:"+compId, e);
		}
		return mv;
	}
	
	/**
	 * 获取本公司购买列表
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("orderList.do")
	@ResponseBody
	public Map<String, Object> getOrderList(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		int curPage=0;
		int pageSize=10;
		if(request.getParameter("page")!=null) {
			curPage = Integer.parseInt(request.getParameter("page"));
			pageSize = Integer.parseInt(request.getParameter("rows"));
		}
		String osellType=request.getParameter("osellType");//1：时间类，2：并发类
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String compID = tUser.getCompID().toString();
		int totalRow=-1;
		List<OrderVOExtend> orderList=null;
		if("1".equals(osellType)) {//1：时间类
			 totalRow=orderDao.getTimeOrderListCount(compID,osellType);
			Page page=new Page(totalRow, pageSize, curPage);
			orderList=orderDao.getTimeOrderList(compID,osellType,page);
		}
		if("2".equals(osellType)) {//2：并发类
			totalRow=orderDao.getOrderListCount(compID,osellType);
			Page page=new Page(totalRow, pageSize, curPage);
			orderList=orderDao.getOrderList(compID,osellType,page);
		}
		
		
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("total", totalRow);
		map.put("rows", orderList);
		return map;
	}
	
	@RequestMapping("timeTypeRecord.do")
	public String timeTypeRecord() {
		return "company/timeTypeRecord";
	} 
	
	@RequestMapping("concurrentTypeRecord.do")
	public String concurrentTypeRecord() {
		return "company/concurrentTypeRecord";
	} 
	
	@RequestMapping("logConfRecord.do")
	public String logConfRecord() {
		return "company/logConfRecord";
	} 
	
	/**
	 * 获取消费列表
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("logConfList.do")
	@ResponseBody
	public Map<String,Object> getLogConfList(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		int curPage=0;
		int pageSize=10;
		if(request.getParameter("page")!=null) {
			curPage = Integer.parseInt(request.getParameter("page"));
			pageSize = Integer.parseInt(request.getParameter("rows"));
		}
		String sellType=request.getParameter("sellType");//1：时间类，2：并发类
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String compIDString = tUser.getCompID().toString();
		int compID=-1;
		if(compIDString!=null||!"".equals(compIDString)) {
			compID=Integer.parseInt(compIDString);
		}
		int totalRow=confDao.getLogConfListCount(compID,sellType);
		Page page=new Page(totalRow, pageSize, curPage);
		List<LogConfVOExtend> logConfList=confDao.getLogConfList(compID,sellType,page);
		
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("total", totalRow);
		map.put("rows", logConfList);
		return map;
	}
	
	/**
	 * 根据productId获取套餐列表
	 * @return
	 */
	@RequestMapping("getPackageInfo.do")
	@ResponseBody
	public Result<List<Map<String,Object>>> getPackageInfo(HttpServletRequest request,HttpServletResponse response) {
		String productIdStr=request.getParameter("productId");
		Integer productId=-1;
		if(productIdStr!=null&&!"".equals(productIdStr)) {
			productId=Integer.parseInt(productIdStr);
		}
		Result<List<Map<String,Object>>> result=Result.error(CodeMsg.NOT_FIND_DATA,"获取套餐列表失败productId:"+productId);
		List<Map<String,Object>> packageList=packageDao.getPackageList(productId);
		result=Result.success(packageList);
		return result;
	}
	
	@RequestMapping("deviceRecord.do")
	public String deviceRecord() {
		return "company/deviceRecord";
	}
	
	/**
	 * 获取公司的设备列表
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("deviceList.do")
	@ResponseBody
	public Map<String,Object> getDeviceList(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		int curPage=0;
		int pageSize=10;
		if(request.getParameter("page")!=null) {
			curPage = Integer.parseInt(request.getParameter("page"));
			pageSize = Integer.parseInt(request.getParameter("rows"));
		}
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String compIDString = tUser.getCompID().toString();
		int compID=-1;
		if(compIDString!=null||!"".equals(compIDString)) {
			compID=Integer.parseInt(compIDString);
		}
		String state=request.getParameter("state");
		String deviceId=request.getParameter("deviceId");
		int totalRow=deviceDao.getDeviceListCount(compID,state,deviceId);
		Page page=new Page(totalRow, pageSize, curPage);
		List<Map<String,Object>> deviceList=deviceDao.getDeviceList(compID,state,deviceId,page);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("total", totalRow);
		map.put("rows", deviceList);
		return map;
	}
	
	
	/**
	 * 解绑设备
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("untieDevice.do")
	@ResponseBody
	public Result<String> untieDevice(HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String deviceId=request.getParameter("deviceId");
		Result<String> result=Result.error(CodeMsg.NOT_FIND_DATA,"解绑失败！deviceId: "+deviceId);
		int untieLine=deviceDao.untieDevice(deviceId);
		if(untieLine>0) {
			DeviceRecordVO deviceRecordVO=new DeviceRecordVO();
			deviceRecordVO.setDeviceId(deviceId);
			deviceRecordVO.setDeviceName(request.getParameter("deviceName"));
			deviceRecordVO.setCompTrueName(tUser.getCompTrueName());
			deviceRecordVO.setCompID(tUser.getCompID());
			deviceRecordVO.setCreateTime(new Date());
			deviceRecordVO.setCreaterId(tUser.getUserID());
			deviceRecordVO.setCreaterName(tUser.getUserName());
			deviceRecordVO.setState("解绑");
			deviceRecordVO.setRemark("由 "+tUser.getUserName()+" 解绑设备 "+deviceId);
			deviceRecordVO.setDeviceModel(request.getParameter("deviceModel"));
			int addLine=deviceDao.addDeviceRecord(deviceRecordVO);
			if(addLine>0) {
				result=Result.success("解绑成功！deviceId: "+deviceId);
			}
		}
		
		return result;
	}
	
	/**
	 * 删除设备
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("removeDevice.do")
	@ResponseBody
	public Result<String> removeDevice (HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String deviceId=request.getParameter("deviceId");
		Result<String> result=Result.error(CodeMsg.NOT_FIND_DATA,"删除设备失败！deviceId: "+deviceId);
		if("".equals(deviceId)||deviceId==null) {
			return result;
		}
		int untieLine=deviceDao.removeDevice(deviceId);
		if(untieLine>0) {
			DeviceRecordVO deviceRecordVO=new DeviceRecordVO();
			deviceRecordVO.setDeviceId(deviceId);
			deviceRecordVO.setDeviceName(request.getParameter("deviceName"));
			deviceRecordVO.setCompTrueName(tUser.getCompTrueName());
			deviceRecordVO.setCompID(tUser.getCompID());
			deviceRecordVO.setCreateTime(new Date());
			deviceRecordVO.setCreaterId(tUser.getUserID());
			deviceRecordVO.setCreaterName(tUser.getUserName());
			deviceRecordVO.setState("删除");
			deviceRecordVO.setRemark("由 "+tUser.getUserName()+" 删除设备 "+deviceId);
			deviceRecordVO.setDeviceModel(request.getParameter("deviceModel"));
			int addLine=deviceDao.addDeviceRecord(deviceRecordVO);
			if(addLine>0) {
				result=Result.success("删除设备成功！deviceId: "+deviceId);
			}
		}
		
		return result;
	}
	
	
	/**
	 * 添加设备
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("addDevice.do")
	@ResponseBody
	public Result<String> addDevice (HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String deviceId=request.getParameter("deviceId");
		Result<String> result=Result.error(CodeMsg.NOT_FIND_DATA,"新增设备失败！deviceId: "+deviceId);
		DeviceVO deviceVO=new DeviceVO();
		deviceVO.setDeviceId(deviceId);
		deviceVO.setDeviceName(request.getParameter("deviceName"));
		deviceVO.setCreateTime(DateUtil.dateFormat(new Date()));
		deviceVO.setUpdateTime(DateUtil.dateFormat(new Date()));
		deviceVO.setState("等待激活");
		deviceVO.setCreaterId(tUser.getUserID());
		deviceVO.setCreaterName(tUser.getUserName());
		deviceVO.setCompID(tUser.getCompID());
		int untieLine=deviceDao.addDevice(deviceVO);
		if(untieLine>0) {
			DeviceRecordVO deviceRecordVO=new DeviceRecordVO();
			deviceRecordVO.setDeviceId(deviceId);
			deviceRecordVO.setDeviceName(request.getParameter("deviceName"));
			deviceRecordVO.setCompTrueName(tUser.getCompTrueName());
			deviceRecordVO.setCompID(tUser.getCompID());
			deviceRecordVO.setCreateTime(new Date());
			deviceRecordVO.setCreaterId(tUser.getUserID());
			deviceRecordVO.setCreaterName(tUser.getUserName());
			deviceRecordVO.setState("新增");
			deviceRecordVO.setRemark("由 "+tUser.getUserName()+" 新增设备 "+deviceId);
			deviceRecordVO.setDeviceModel(request.getParameter("deviceModel"));
			int addLine=deviceDao.addDeviceRecord(deviceRecordVO);
			if(addLine>0) {
				result=Result.success("新增设备成功！deviceId: "+deviceId);
			}
		}
		
		return result;
	}
	
	/**
	 * 设备ID唯一校验
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("validateDeviceId.do")
	@ResponseBody
	public boolean validateDeviceId (HttpServletRequest request,HttpServletResponse response) {
		String deviceId=request.getParameter("deviceId");
		int devCount=deviceDao.getDeviceCountBydeviceId(deviceId);
		return devCount<1;
	}
	
	/**
	 * 修改设备
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("updateDevice.do")
	@ResponseBody
	public Result<String> updateDevice (HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String deviceId=request.getParameter("deviceId");
		Result<String> result=Result.error(CodeMsg.NOT_FIND_DATA,"修改设备失败！deviceId: "+deviceId);
		DeviceVO deviceVO=new DeviceVO();
		deviceVO.setDeviceName(request.getParameter("deviceName"));
		deviceVO.setDeviceId(deviceId);
		int untieLine=deviceDao.updateDevice(deviceVO);
		if(untieLine>0) {
			DeviceRecordVO deviceRecordVO=new DeviceRecordVO();
			deviceRecordVO.setDeviceId(deviceId);
			deviceRecordVO.setDeviceName(request.getParameter("deviceName"));
			deviceRecordVO.setCompTrueName(tUser.getCompTrueName());
			deviceRecordVO.setCompID(tUser.getCompID());
			deviceRecordVO.setCreateTime(new Date());
			deviceRecordVO.setCreaterId(tUser.getUserID());
			deviceRecordVO.setCreaterName(tUser.getUserName());
			deviceRecordVO.setState("更新");
			deviceRecordVO.setRemark("由 "+tUser.getUserName()+"把原设备名 "+request.getParameter("oldDeviceName")+"  更改为  "+request.getParameter("deviceName"));
			deviceRecordVO.setDeviceModel(request.getParameter("deviceModel"));
			int addLine=deviceDao.addDeviceRecord(deviceRecordVO);
			if(addLine>0) {
				result=Result.success("修改设备成功！deviceId: "+deviceId);
			}
		}
		
		return result;
	}
	
	
}
