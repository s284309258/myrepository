package com.huawang.controller.userManager; 

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.huawang.controller.deptManager.DeptManagerController;
import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.dao.organization.OrganizationDao;
import com.huawang.dao.organization.UserDao;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.organization.UserVO;
import com.huawang.pojo.result.Result;
import com.huawang.util.ExcelUtil;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

@Controller
@RequestMapping(value="/User")
public class UserManagerController {
	private static final Logger logger = LogManager.getLogger(UserManagerController.class);
	@Autowired
	private MeetingRoomDao meetingRoomDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private OrganizationDao organizationDao;
	/**
	 * 临时表命名：前缀+userID 如：temp_userinfo_01
	 */
	private static final String TEMP_TABLE_NAME_PRE="temp_userinfo_";
	@RequestMapping(value="UserManager.do")
	public ModelAndView UserManager(HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		ArrayList<Map<String,Object>> arraylist = DeptManagerController.getOrganMenu(compid);
		
		ModelAndView view = new ModelAndView("userManager/userManager");
		view.addObject("organMenu", arraylist);
		return view;
	}
	
	@RequestMapping(value="/UserContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid) throws Exception {
		
//		ArrayList<Map<String,Object>> array = getOrganUserList(dpid);
		ModelAndView view = new ModelAndView("userManager/userContent");
//		view.addObject("organUserList", array);
		view.addObject("dpid", dpid);
		return view;
	}
	
	@RequestMapping(value="/AddDepartMentUser.do")
	public ModelAndView AddDepartMent(HttpServletRequest request) {
		ModelAndView view = new ModelAndView("userManager/addDeptUser");
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int DpId = tUser.getDpId();
		view.addObject("DpId", DpId);
		return view;
	}
	
	@RequestMapping(value="/AddBatchUserSubmit.do")
	@ResponseBody
	public String AddBatchUserSubmit(HttpServletRequest request,HttpSession session) throws Exception 
	{
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
			String UserNamePre = request.getParameter("UserNamePre");
			String DisplayPre = request.getParameter("DisplayPre");
			String IDStart = request.getParameter("IDStart");
			String IDEnd = request.getParameter("IDEnd");
			String UserPwd = request.getParameter("UserPwd");
			String DpId = request.getParameter("DpId");
			String CreateTime = request.getParameter("CreateTime");
			String EndTime = request.getParameter("EndTime");
			if(CreateTime==null) {CreateTime="";}
			if(EndTime==null) {EndTime="";}
			int start = Integer.parseInt(IDStart);
			int end = Integer.parseInt(IDEnd);
			UserPwd = SecurityUtil.encryptMD5(UserPwd);
			
			Connection conn = Sqlca.getConnection();
			Statement sts = conn.createStatement();
			try
			{
				if(!"".equals(CreateTime) && !"".equals(EndTime)) 
				{
					for(;start<=end;start++)
					{
						String DispPre = Sqlca.switchLatin1Encoding(DisplayPre);
						String UNamePre = Sqlca.switchLatin1Encoding(UserNamePre);
						sts.addBatch("insert into t_userinfo(UserName,DisplayName,UserPassWord,DpId,CompID,State,UserSex,UserType,CreateTime,EndTime) "
								+ " values('"+UNamePre+start+"','"+DispPre+start+"','"+UserPwd+"',"+DpId+","+compid+",'0','1','1','"+CreateTime+"','"+EndTime+"')");
					}
				}
				else
				{
					for(;start<=end;start++)
					{
						String DispPre = Sqlca.switchLatin1Encoding(DisplayPre);
						String UNamePre = Sqlca.switchLatin1Encoding(UserNamePre);
						sts.addBatch("insert into t_userinfo(UserName,DisplayName,UserPassWord,DpId,CompID,State,UserSex,UserType) "
								+ " values('"+UNamePre+start+"','"+DispPre+start+"','"+UserPwd+"',"+DpId+","+compid+",'0','1','1')");
					}
				}
				
				sts.executeBatch();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "用户名已存在";
			}
			finally
			{
				sts.close();
				conn.close();
			}
		return "success";
	}
	
	
	@RequestMapping(value="/AddDepartMentUserSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {

		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String UserPassWord = request.getParameter("UserPassWord");
		String UserSex = request.getParameter("UserSex");
		String DpId = request.getParameter("DpId");
		String Post = request.getParameter("Post");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		String UserType = request.getParameter("UserType");
		String Description = request.getParameter("Description");
		String State = request.getParameter("State");
		String CreateTime = request.getParameter("CreateTime");
		String EndTime = request.getParameter("EndTime");
		
		
		/*if(!"".equals(EndTime))
		{
			String enddate = Sqlca.getString("select substr(EndDate,1,10) as enddate from t_compinfo where CompID="+compid);
			if(EndTime.compareTo(enddate)>0)
			{
				return "结束时间不能大于合约的结束时间";
			}
		}*/
		
		String UName = Sqlca.getString("select UserName from t_userinfo where UserName='"+UserName+"'");
		if(null!=UName)
		{
			return "该账号已存在";
//			throw new Exception("该账号已存在");
		}
		
		UserPassWord = SecurityUtil.encryptMD5(UserPassWord);
		
		if(!"".equals(EndTime))
		{
			int cnt = Sqlca.updateObject("insert into t_userinfo(UserName,DisplayName,UserPassWord,UserSex,DpId,Post,Telephone,Email,UserType,Description,CompID,State,CreateTime,EndTime) " + 
					"value(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", new String[] {UserName,DisplayName,UserPassWord,UserSex,DpId,Post,Telephone,Email,UserType,Description,compid+"",State,CreateTime,EndTime});
			if(cnt>0) {
				return "success";
			}
		}
		else
		{
			int cnt = Sqlca.updateObject("insert into t_userinfo(UserName,DisplayName,UserPassWord,UserSex,DpId,Post,Telephone,Email,UserType,Description,CompID,State) " + 
					"value(?,?,?,?,?,?,?,?,?,?,?,?)", new String[] {UserName,DisplayName,UserPassWord,UserSex,DpId,Post,Telephone,Email,UserType,Description,compid+"",State});
			if(cnt>0) {
				return "success";
			}
		}
		
		return "fail";
	
	}
	
	@RequestMapping(value="/DelDepartMentUserSubmit.do")
	@ResponseBody
	public String DelDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserID = request.getParameter("UserID");
		int cnt = Sqlca.updateObject("delete from t_userinfo where UserID=?", new String[] {UserID});
		Sqlca.updateObject("DELETE FROM t_confusers WHERE UserID = ?", new String[] {UserID});
		
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	
	@RequestMapping(value="/ModifyDepartMentUserSubmit.do")
	@ResponseBody
	public String ModifyDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String UserID = request.getParameter("UserID");
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String State = request.getParameter("State");
		String Post = request.getParameter("Post");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		String UserSex = request.getParameter("UserSex");
		String Description = request.getParameter("Description");
		String IsSuper = request.getParameter("IsSuper");
		String CreateTime = request.getParameter("CreateTime");
		String EndTime = request.getParameter("EndTime");
		String UserPassWord = request.getParameter("UserPassWord");
		if(UserPassWord==null) {UserPassWord="";}
		if(CreateTime!=null && !"".equals(CreateTime))
		{
			if("".equals(UserPassWord)) 
			{
				int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpID="+DpId+",State="+State+",Telephone=?,Email=?,UserSex="+UserSex+",Description=?,Post=?,IsSuper=?,CreateTime=?,EndTime=?" + 
						" where UserID=?", new String[] {UserName,DisplayName,Telephone,Email,Description,Post,IsSuper,CreateTime,EndTime,UserID});
				if(cnt>0) 
				{
					return "success";
				}
			}
			else
			{
				UserPassWord = SecurityUtil.encryptMD5(UserPassWord);
				int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpID="+DpId+",State="+State+",Telephone=?,Email=?,UserSex="+UserSex+",Description=?,Post=?,IsSuper=?,CreateTime=?,EndTime=?,UserPassWord=?" + 
						" where UserID=?", new String[] {UserName,DisplayName,Telephone,Email,Description,Post,IsSuper,CreateTime,EndTime,UserPassWord,UserID});
				if(cnt>0) 
				{
					return "success";
				}
			}
			
		}
		else
		{
			if("".equals(UserPassWord)) 
			{
				int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpID="+DpId+",State="+State+",Telephone=?,Email=?,UserSex="+UserSex+",Description=?,Post=?,IsSuper=?,CreateTime=null,EndTime=null" + 
						" where UserID=?", new String[] {UserName,DisplayName,Telephone,Email,Description,Post,IsSuper,UserID});
				if(cnt>0) {
					return "success";
				}
			}
			else
			{
				UserPassWord = SecurityUtil.encryptMD5(UserPassWord);
				int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpID="+DpId+",State="+State+",Telephone=?,Email=?,UserSex="+UserSex+",Description=?,Post=?,IsSuper=?,CreateTime=null,EndTime=null,UserPassWord=?" + 
						" where UserID=?", new String[] {UserName,DisplayName,Telephone,Email,Description,Post,IsSuper,UserPassWord,UserID});
				if(cnt>0) {
					return "success";
				}
			}
			
		}
		
		return "fail";
	}
	
	@RequestMapping(value="/ModifyDepartMentUser.do")
	public ModelAndView ModifyDepartMent(@RequestParam("UserID") String UserID) throws Exception {
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select UserID,UserName,DisplayName,UserPassWord,UserSex,DpId,Post,Telephone,Email,IsSuper,Description,State,"
				+ " SUBSTR(t.CreateTime,1,10) as CreateTime,SUBSTR(t.EndTime,1,10) as EndTime from t_userinfo t where t.UserID='"+UserID+"'");
		ModelAndView view = new ModelAndView("userManager/modiyDeptUser");
		view.addObject("user", array.get(0));
		return view;
	}
	
	/**
	 * 	批量修改
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/ResetPwdSubmit",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String ResetPwdSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		String names[] = request.getParameterValues("names");
		names = names[0].split(",");
		String password = request.getParameter("password");
		String createTime = request.getParameter("createTime");
		String endTime = request.getParameter("endTime");
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		 
		try {
			if(!endTime.equals("")&&!endTime.equals(null)&&!createTime.equals("")&&!createTime.equals(null)&&!password.equals("")&&!password.equals(null)) {
				for(int i=0;i<names.length;i++){
					String userId =names[i];
					String pwd = SecurityUtil.encryptMD5(password);
					sts.addBatch("update t_userinfo set UserPassWord='"+pwd+"',createtime ='"+createTime+"',endtime = '"+endTime+"'where UserID= "+userId+" ");
				}
			}
			
			if(!createTime.equals("")&&!createTime.equals(null)&&!password.equals("")&&!password.equals(null) && endTime.equals("")) {
				for(int i=0;i<names.length;i++){
					String userId =names[i];
					String pwd = SecurityUtil.encryptMD5(password);
					sts.addBatch("update t_userinfo set UserPassWord='"+pwd+"',createtime ='"+createTime+"' where UserID="+userId+"");
				}
			}
			if(createTime.equals("")&&!password.equals("")&&!password.equals(null) && !endTime.equals("")) {
				for(int i=0;i<names.length;i++){
					String userId =names[i];
					String pwd = SecurityUtil.encryptMD5(password);
					sts.addBatch("update t_userinfo set UserPassWord='"+pwd+"',endtime = '"+endTime+"' where UserID= "+userId+"");
				}
			}
			if(!password.equals("")&&!password.equals(null) && createTime.equals("") && endTime.equals("")) {
				for(int i=0;i<names.length;i++){
					String userId =names[i];
					String pwd = SecurityUtil.encryptMD5(password);
					sts.addBatch("update t_userinfo set UserPassWord='"+pwd+"' where UserID= "+userId+" ");
				}
			}
			if(password.equals("") && !createTime.equals("") && !endTime.equals("")) {
				for(int i=0;i<names.length;i++){
					String userId =names[i];
					sts.addBatch("update t_userinfo set createtime ='"+createTime+"',endtime = '"+endTime+"' where UserID= "+userId+" ");
				}
			}
			sts.executeBatch();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			sts.close();
			conn.close();
		}
			JSONObject json = new JSONObject();
			json.put("message", "success");
			return json.toString();
		}
	
	/**
	 * 	批量删除 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/DeleteMoreUser",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String DeleteMoreUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String names[] = request.getParameterValues("names");
		names = names[0].split(","); 
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		try {
			for(int i=0;i<names.length;i++){
				String userId =names[i];
				sts.addBatch("DELETE FROM t_userinfo WHERE UserID = "+userId+"");
				sts.addBatch(" DELETE FROM t_confusers WHERE UserID = "+userId+" ");
			}
			sts.executeBatch();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			sts.close();
			conn.close();
		}
		JSONObject json = new JSONObject();
		json.put("message", "success");
		return json.toString();
	}
	 
	
			/**
			 * 	导出用户信息
			 * @param request
			 * @param response
			 */
			@RequestMapping(value="/UserImportExcel",method= {RequestMethod.POST,RequestMethod.GET})
			public void UserImportExcel(HttpServletRequest request,HttpServletResponse response) {
				HttpSession session = request.getSession();
				TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
				int compId = tUser.getCompID();
				String userName = tUser.getUserName();
				String type= request.getParameter("type");
				SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
				String date = df1.format(new Date());
			try 
				{ 
				OutputStream os = response.getOutputStream();// 取得输出流   
				response.reset();// 清空输出流   
				String fileName= "用户信息"+date+".xls"; 
				response.reset();// 清空输出流   
				response.setContentType("application/vnd.ms-excel;charset=utf-8");
				response.setHeader("Content-Disposition", "attachment;filename="+ new String((fileName).getBytes(), "iso-8859-1")); 
				response.setContentType("application/msexcel");// 定义输出类型 
				
				WritableWorkbook wbook = Workbook.createWorkbook(os); // 建立excel文件   
				String tmptitle = "用户信息"; // 标题   
				WritableSheet wsheet = wbook.createSheet(tmptitle, 0); // sheet名称  
				// 设置excel标题   
				WritableFont wfont = new WritableFont(WritableFont.ARIAL, 16,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				WritableCellFormat wcfFC = new WritableCellFormat(wfont); 
				wsheet.addCell(new Label(0, 0, tmptitle, wcfFC));   
				wfont = new jxl.write.WritableFont(WritableFont.ARIAL, 14,WritableFont.BOLD,false, UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				wcfFC = new WritableCellFormat(wfont); 
				String sql ="";
				
				if(type.equals("1")) {
							//查询所有用户
							sql ="select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,(select tt.DpName from t_department tt where tt.DpId=t.DpId) as DpName,"
							+ "(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"
							+ "SUBSTR(t.CreateTime,1,10) as CreateTime,SUBSTR(t.EndTime,1,10) as EndTime,t.Telephone,t.Email  from t_userinfo t where t.compId= "+compId+" AND t.userName <> '"+userName+"'";
				}else {
					String names[] = request.getParameterValues("names");
					String name =names[0];
					//String st2 = name.substring(name.indexOf("[")+1,name.indexOf("]"));
					sql ="select t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,(select tt.DpName from t_department tt where tt.DpId=t.DpId) as DpName," + 
							"(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus," + 
							"SUBSTR(t.CreateTime,1,10) as CreateTime,SUBSTR(t.EndTime,1,10) as EndTime,t.Telephone,t.Email  from t_userinfo t where t.compId= "+compId+" AND UserID in("+name+")";
					}
				ArrayList<Object> userList = Sqlca.getArrayListFromObj(sql, TUserinfo.class);
				
				// 开始生成主体内容                   
				wsheet.addCell(new Label(0, 1, "ID"));
				wsheet.addCell(new Label(1, 1, "用户账号"));
				wsheet.addCell(new Label(2, 1, "用户名称"));
				wsheet.addCell(new Label(3, 1, "所属部门"));  
				wsheet.addCell(new Label(4, 1, "职位"));  
				wsheet.addCell(new Label(5, 1, "开始时间"));  
				wsheet.addCell(new Label(6, 1, "结束时间"));
				wsheet.addCell(new Label(7, 1, "状态"));  
				wsheet.addCell(new Label(8, 1, "电话"));   
				wsheet.addCell(new Label(9, 1, "邮箱"));   
				int i=0;
				
				for(Object usert: userList)   {   
					TUserinfo m = (TUserinfo)usert;
				    wsheet.addCell(new Label(0, i+2, m.UserID.toString()));   //数据库的城市代码字段
				    wsheet.addCell(new Label(1, i+2, m.UserName));   
				    wsheet.addCell(new Label(2, i+2,  m.DisplayName));   
				    wsheet.addCell(new Label(3, i+2,  m.dpName));  
				    wsheet.addCell(new Label(4, i+2,  m.Post));  
				    wsheet.addCell(new Label(5, i+2,  m.CreateTime));   
				    wsheet.addCell(new Label(6, i+2,  m.EndTime));  
				    wsheet.addCell(new Label(7, i+2,  m.UserStatus));   
				    wsheet.addCell(new Label(8, i+2,  m.Telephone));  
				    wsheet.addCell(new Label(9, i+2,  m.Email));  
				    i++;
				}          
				// 主体内容生成结束           
				wbook.write(); // 写入文件   
				wbook.close();  
				os.close(); // 关闭流
				} 
			catch(Exception ex) 
			{ 
			ex.printStackTrace(); 
			}
		}
			
			
			
			/**
			 * 	导出错误用户信息
			 * @param request
			 * @param response
			 */
			@RequestMapping(value="/ErrorUserImportExcel.do",method= {RequestMethod.POST,RequestMethod.GET})
			public void errorUserImportExcel(HttpServletRequest request,HttpServletResponse response) {
				HttpSession session = request.getSession();
				TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
				int compId = tUser.getCompID();
				String userName = tUser.getUserName();
				String type= request.getParameter("type");
				SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
				String date = df1.format(new Date());
			try 
				{ 
				OutputStream os = response.getOutputStream();// 取得输出流   
				response.reset();// 清空输出流   
				String fileName= "用户信息导入失败"+date+".xls"; 
				response.reset();// 清空输出流   
				response.setContentType("application/vnd.ms-excel;charset=utf-8");
				response.setHeader("Content-Disposition", "attachment;filename="+ new String((fileName).getBytes(), "iso-8859-1")); 
				response.setContentType("application/msexcel");// 定义输出类型 
				
				WritableWorkbook wbook = Workbook.createWorkbook(os); // 建立excel文件   
				String tmptitle = "用户信息"; // 标题   
				WritableSheet wsheet = wbook.createSheet(tmptitle, 0); // sheet名称  
				// 设置excel标题   
				WritableFont wfont = new WritableFont(WritableFont.ARIAL, 16,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				WritableCellFormat wcfFC = new WritableCellFormat(wfont); 
				wsheet.addCell(new Label(0, 0, tmptitle, wcfFC));   
				wfont = new jxl.write.WritableFont(WritableFont.ARIAL, 14,WritableFont.BOLD,false, UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
				wcfFC = new WritableCellFormat(wfont); 
				String sql ="";
				Map<String,Object> map=new HashMap<String,Object>();
				map.put("tablName",TEMP_TABLE_NAME_PRE+tUser.getUserID());
				//查询所有用户
				List<Map<String,String>> userList=organizationDao.errorUserImportExcel(map);
				System.out.println(userList);
				
				
				// 开始生成主体内容                   
				wsheet.addCell(new Label(0, 1, "用户账号*"));
				wsheet.addCell(new Label(1, 1, "用户名称*"));
				wsheet.addCell(new Label(2, 1, "用户密码*"));
				wsheet.addCell(new Label(3, 1, "用户性别（女=0,男=1）"));  
				wsheet.addCell(new Label(4, 1, "所属部门(默认为1)*"));  
				wsheet.addCell(new Label(5, 1, "职位"));  
				wsheet.addCell(new Label(6, 1, "状态（在职=0,离职=1）"));
				wsheet.addCell(new Label(7, 1, "用户类别（部门管理员=2）"));  
				wsheet.addCell(new Label(8, 1, "电话"));   
				wsheet.addCell(new Label(9, 1, "邮箱"));  
				wsheet.addCell(new Label(10, 1, "开始时间(yyyy-mm-dd)"));
				wsheet.addCell(new Label(11, 1, "结束时间(yyyy-mm-dd)"));
				wsheet.addCell(new Label(12, 1, "导入失败原因"));
				int i=0;
				
				for(Map<String,String> m: userList)   {   
//					TUserinfo m = (TUserinfo)usert;
				    wsheet.addCell(new Label(0, i+2, m.get("UserName")));   //数据库的城市代码字段
				    wsheet.addCell(new Label(1, i+2, m.get("DisplayName")));   
				    wsheet.addCell(new Label(2, i+2,  m.get("UserPassword")));   
				    wsheet.addCell(new Label(3, i+2,  m.get("UserSex")));  
				    wsheet.addCell(new Label(4, i+2,  m.get("DpId")));  
				    wsheet.addCell(new Label(5, i+2,  m.get("Post")));   
				    wsheet.addCell(new Label(6, i+2,  m.get("State")));  
				    wsheet.addCell(new Label(7, i+2,  m.get("IsSuper")));   
				    wsheet.addCell(new Label(8, i+2,  m.get("Telephone")));  
				    wsheet.addCell(new Label(9, i+2,  m.get("Email")));  
				    wsheet.addCell(new Label(10, i+2,  m.get("createtime")));
				    wsheet.addCell(new Label(11, i+2,  m.get("endtime")));
				    wsheet.addCell(new Label(12, i+2,  m.get("Remark")));
				    i++;
				}          
				// 主体内容生成结束           
				wbook.write(); // 写入文件   
				wbook.close();  
				os.close(); // 关闭流
				} 
			catch(Exception ex) 
			{ 
			ex.printStackTrace(); 
			}
		}
			
			
	/**
	 *   修改用户会议权限
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/UserDistritMeeting",method=RequestMethod.GET)
	public String UserDistritMeeting(HttpServletRequest request, HttpServletResponse response,Model model){
		String UserID = request.getParameter("UserID");
		model.addAttribute("userId", UserID);
		return "userManager/userDistribte";
	}
			
	/**
	 *  根据用户查询企业会议室
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectmeetingByUserId")
	@ResponseBody
	public Map<String, Object>selectmeetingByUserId(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception{
		
		TUserinfo obj = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int compId = obj.getCompID();
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String confId = request.getParameter("confId")==null?"":request.getParameter("confId");
		String confName = request.getParameter("confName")==null?"":request.getParameter("confName");
		String userId = request.getParameter("userId");
		
		String sql ="SELECT  (SELECT s.UserId FROM t_confusers s WHERE s.UserID =t.UserID AND s.ConfID = t1.ConfID) AS id,"
				+ "(SELECT s.UserRight FROM t_confusers s WHERE s.UserID =t.UserID AND s.ConfID = t1.ConfID) AS userRight" + 
				",t.UserID AS userId,t.UserName AS userName,t1.ConfID as confId,t1.ConfID as confIds,t1.ConfName as confName,t1.IsReservedConf as isReservedConf," + 
				"t1.StartTime as startTime,t1.EndTime as endTime FROM t_userinfo t INNER JOIN t_confinfo t1 ON  t.CompID =t1.CompID  WHERE t.CompID ="+compId+" AND t.UserID ="+userId+" ";
		
		String total ="SELECT count(*) FROM t_userinfo t INNER JOIN t_confinfo t1 ON  t.CompID =t1.CompID  WHERE t.CompID ="+compId+" AND t.UserID ="+userId+"";
	
		if(!confId.equals("") && !confId.equals(null)) {
			sql +=" AND t1.ConfID ="+confId;
			total +=" AND t1.ConfID ="+confId;
		}
		if(!confName.equals("") && !confName.equals(null)) {
			sql +=" AND t1.ConfName like '%"+confName+"%'";
			total += " AND t1.ConfName like '%"+confName+"%'";
		}
		
		sql+=" ORDER BY id is null,confId DESC ";
		sql+="  limit "+i+","+rows+"";
		List<Map<String, Object>> objList = Sqlca.getArrayListFromMap(sql);
		String tal = Sqlca.getString(total);
		JSONObject json  = new JSONObject();
		json.put("rows", objList);
		json.put("total", tal);
		return json;
	}
			
	/**
	 * 	保存用户参会信息
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/updateUserMeetingConfuse",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String updateUserMeetingConfuse(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int compId = tUser.getCompID();
		
		String confadmins = request.getParameter("confadmins");
		String upConfId = request.getParameter("upConfId")==""?"0":request.getParameter("upConfId");//取消的confId
		System.out.println(upConfId+"取消id");
		String confId = request.getParameter("confId"); 
		String userId = request.getParameter("userId");
		String[] confIds = confId.split(",");
		 
		String sql ="  DELETE FROM t_confusers WHERE ConfID in("+upConfId+") AND UserID = "+userId+"";
		Sqlca.updateObject(sql, new String[] {});
		
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		
		if(!confId.equals("") && !confId.equals(null)) {//添加参会人
			int count=0;
			for(int i=0;i<confIds.length;i++){
				String conf =confIds[i]; 
				if(conf.equals("")) {
					conf="0";
				}
				String chuxi = (Sqlca.getString("SELECT UserRight from t_confusers WHERE ConfID="+Integer.parseInt(conf)+" AND UserID="+Integer.parseInt(userId)+" ")==null?"":Sqlca.getString("SELECT UserRight from t_confusers WHERE ConfID="+Integer.parseInt(conf)+" AND UserID="+Integer.parseInt(userId)+" "));
				if(chuxi.equals("")||chuxi.equals(null)) {
						chuxi=Sqlca.switchLatin1Encoding("出席");
					}
				int flag = meetingRoomDao.selectUserInfoDistri(Integer.parseInt(conf), Integer.parseInt(userId));
				if(flag<1) {
					count =meetingRoomDao.addAttendMeetingUser(Integer.parseInt(conf), Integer.parseInt(userId),chuxi);
					}
			}
			String[] cfs = confadmins.split(",");
			for(int i=0;i<cfs.length;i++) 	//修改参会用户角色
			{	
				if(!"".equals(cfs[i]) && null!=cfs[i] )
				{
					String t1 =cfs[i];
					String confId1 = t1.substring(0,t1.lastIndexOf("="));
					String userRight1 = t1.substring(t1.length()-2);
					Sqlca.updateObject("update t_confusers set UserRight=? where UserID=? and ConfID= ?", new String[] {userRight1,userId,confId1});
					}
			}
		}
		if(confId.equals(null) || confId.equals("")) {//查询该用户不属于分配会议室的其他会议室
			confId ="0";
		}
		
		int t =confIds.length;
		List<String> tt = meetingRoomDao.selectUserToConfId(Integer.parseInt(userId));
		System.out.println(t+"-----中间-----"+tt.size());
		
		
		StringBuffer dd = new StringBuffer();String ss ="";
		if(tt.size()>0) {
			for (String string : tt) {
				ss = dd.append(string).append(",").toString();
				System.out.println("已经存在的："+ss);
				for(int i=0;i<confIds.length;i++){
					String conf =confIds[i];
				System.out.println("--提交的id-"+conf);
				}
			}
		}else {
			ss="0";
		} 
		String delSql ="SELECT  t.UserID AS userId ,t1.ConfID as confId   FROM t_userinfo t INNER JOIN t_confinfo t1 ON  t.CompID =t1.CompID " + 
				" WHERE t.CompID ="+compId+" AND t.UserID ="+userId+" AND t1.ConfID NOT IN("+ss+confId+")";
		List<Map<String, Object>> objList = Sqlca.getArrayListFromMap(delSql);
		try {
				for (Map<String, Object> map : objList) {//删除没有分配的会议室
					String userIdel = (String) map.get("userId");
					String confIdel = (String) map.get("confId");
					sts.addBatch(" DELETE FROM t_confusers WHERE UserID = '"+userIdel+"' AND ConfID = '"+confIdel+"' ");
				}
				sts.executeBatch();
				}catch(Exception e){
				e.printStackTrace();
			}finally{
				sts.close();
				conn.close();
			}
		JSONObject json = new JSONObject();
		json.put("message", "success");
		return json.toString();
	}
	
	
	
	@RequestMapping(value="/DepartMentUserQuery.do")
	@ResponseBody
	public Map<String,Object> DepartMentUserQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		 
		TUserinfo obj = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		String username = obj.getUserName();
		Integer dpId=obj.getDpId();
		String isSuper=obj.getIsSuper();
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		String UserName = request.getParameter("UserName");
		String displayName = request.getParameter("displayName");
//		String State = request.getParameter("State");
		String bindPhoneState = request.getParameter("bindPhoneState");
		String dpid = request.getParameter("dpid");
		String layout = request.getParameter("layout");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int beginrow = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		if(dpid!=null && layout==null)
		{
			String usql = getOrganUserList(dpid,compid)+"";
			String cntsql = "select count(*) "+usql.substring(usql.lastIndexOf("from"))+"";
			cntsql+=" AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compid+"')";
			//usql+=" AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compid+"')";
			
			String dbtotal = Sqlca.getString(cntsql);
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				usql +=" order by "+SortName+" "+SortValue+" limit "+beginrow+","+rows;
			}
			else
			{
				usql +=" limit "+beginrow+","+rows;
			} 
			ArrayList<Map<String,Object>> organUserList = Sqlca.getArrayListFromMap(usql);
			HashMap<String,Object> reMap = new HashMap<String,Object>();
			reMap.put("rows", organUserList);
			reMap.put("total", dbtotal);
			return reMap;
		}
		else
		{
			String sql = "select t.IsSuper,t.bindPhoneState,t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,"
					+ " (select tt.DpName from t_department tt where tt.DpId=t.DpId) as DpId,"
					+ " t.DpId as Did,t.Post,t.State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"
					+ " SUBSTR(t.CreateTime,1,10) as CreateTime,SUBSTR(t.EndTime,1,10) as EndTime,"
					+ " t.Telephone,t.Email,t.UserID as Operation "
					+ " from t_userinfo t where t.compId="+compid;//+" AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compid+"')"
			
			String sqlTotal = " select count(*) from t_userinfo t where t.compId="+compid;//+" AND UserId not in (SELECT UserID from t_userinfo  WHERE  IsSuper =1 AND compId = '"+compid+"')"
			
			if(!"".equals(displayName) && displayName!=null) 
			{
				sql+= " and t.DisplayName like '%"+displayName+"%'";
				sqlTotal+= " and t.DisplayName like '%"+displayName+"%'";
			}
			
			if(!"".equals(bindPhoneState) && bindPhoneState!=null) {
				sql+= " and t.bindPhoneState='"+bindPhoneState+"'";
				sqlTotal+= " and t.bindPhoneState='"+bindPhoneState+"'";
			}
			
			if(!"".equals(UserName) && UserName!=null) 
			{
				sql+= " and t.UserName like '%"+UserName+"%'";
				sqlTotal+= " and t.UserName like '%"+UserName+"%'";
			}
			 
			if(null!=SortName && !"".equals(SortName)) 
			{
				sql +=" order by "+SortName+" "+SortValue+" limit "+beginrow+","+rows;
			}
			else
			{
				sql +=" limit "+beginrow+","+rows;
			}
			
			ArrayList<Map<String,Object>> organUserList = Sqlca.getArrayListFromMap(sql);
			request.setAttribute("organList", organUserList);
			
			HashMap<String,Object> reMap = new HashMap<String,Object>();
			
			String dbtotal = Sqlca.getString(sqlTotal);
			reMap.put("rows", organUserList);
			reMap.put("total", dbtotal);
			
			return reMap;
		}
		
	}
	
	
	
	public String getOrganUserList(String dpid,Integer compid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
		if("99999".equals(dpid)) {dpid="1";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,'' as ParentDpName,t.Description from t_department t where t.Dpid="+dpid+" or t.compid="+compid;
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(where1+",");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
//				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(where2+",");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;
//					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
//						sqlbf.append(" union ").append(menus3).append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"' and t.compid="+compid;
			sqlbf.append("'"+dpid+"',");
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"' and t.compid="+compid;
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
//				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
				sqlbf.append(where1+",");
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
//					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;
					sqlbf.append(where2+",");
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
//						sqlbf.append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}
		
		String where = sqlbf.toString().substring(0, sqlbf.toString().length()-1);
		
		String sql = " select t.IsSuper,t.bindPhoneState,t.UserID,t.UserName,t.DisplayName,t.Post,t.UserType,                "+
				"  t.DpId as Did,(select DpName from t_department tt where tt.DpId=t.DpId) as DpId,                                "+
				"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
				"  t.Telephone,t.Email,t.UserID as Operation,"+
				"  SUBSTR(t.CreateTime,1,10) as CreateTime,SUBSTR(t.EndTime,1,10) as EndTime                   "+
				"  from t_userinfo t where t.DpId in("+where+")  and t.compid="+compid;
		
//		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		
		return sql;
		
		}
	
	/**
	 * 用户导入
	 * @param file
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception
	 */
//	@RequestMapping(value="/BatchImportSubmit.do",produces = "text/html;charset=UTF-8")
	@RequestMapping(value="/BatchImportSubmit.do")
	@ResponseBody
	public Result<Map<String,Integer>> BatchImportSubmit(@RequestParam(value="filename") MultipartFile file,HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_VIPSESSION");
		String username = null;
		Integer compid = null;
		TUserinfo userinfo=new TUserinfo();
		Result<Map<String,Integer>> result=new Result<Map<String,Integer>>(-1, "error", null);
		if(obj!=null)
		{
			userinfo = (TUserinfo)obj;
			username = userinfo.UserName;
			compid = userinfo.CompID;
			
		}
		ExcelUtil excel = new ExcelUtil();
		List<TUserinfo> list = new ArrayList<TUserinfo>();
		List<TUserinfo> errorUserlist = new ArrayList<TUserinfo>();
		
		excel.getExcelInfo(file,username,list,errorUserlist);
		int excelTotalRow=list.size()+errorUserlist.size();
		Connection conn = Sqlca.getConnection();
		Statement sts = conn.createStatement();
		try
		{
			
			//导入正确用户
			if(list.size()>0) {
				for(TUserinfo u :list)
				{
					//用户名唯一校验
					int userCount=userDao.uniqueUserNameCheck(u.UserName.trim());
					if(userCount>0) {//用户已存在
						u.setRemark("用户账号已经存在");
						errorUserlist.add(u);
					}else {
						u.Post = Sqlca.switchLatin1Encoding(u.Post);
						u.UserName = Sqlca.switchLatin1Encoding(u.UserName);
						u.DisplayName = Sqlca.switchLatin1Encoding(u.DisplayName);
						u.UserPassword = Sqlca.switchLatin1Encoding(SecurityUtil.encryptMD5(u.UserPassword));
						u.Post=u.Post==null?"":u.Post;
						u.UserName=u.UserName==null?"":u.UserName;
						u.DisplayName=u.DisplayName==null?"":u.DisplayName;
						u.UserPassword=u.UserPassword==null?"":u.UserPassword;
						u.UserSex=u.UserSex==null?1:u.UserSex;
						u.Status=u.Status==null?"0":u.Status;
//						u.UserType=u.UserType==null?"":u.UserType;
						u.Telephone=u.Telephone==null?"":u.Telephone;
						u.Email=u.Email==null?"":u.Email;
						u.DpId=u.DpId==null?1:u.DpId;
						u.CreateTime=u.CreateTime==null?"":u.CreateTime;
						u.EndTime=u.EndTime==null?"":u.EndTime;
						if("".equals(u.CreateTime) && "".equals(u.EndTime)) {
							sts.addBatch("insert into t_userinfo(UserName,DisplayName,UserPassword,UserSex,DpId,Post,State,IsSuper,Telephone,Email,CompID) "
									+ " values('"+u.UserName+"','"+u.DisplayName+"','"+u.UserPassword+"','"+u.UserSex+"',"+u.DpId+",'"+u.Post+"','"+u.Status+"',"+u.UserType+",'"+u.Telephone+"','"+u.Email+"',"+compid+")");
						}
						else
						{
							sts.addBatch("insert into t_userinfo(UserName,DisplayName,UserPassword,UserSex,DpId,Post,State,IsSuper,Telephone,Email,CompID,createtime,endtime) "
									+ " values('"+u.UserName+"','"+u.DisplayName+"','"+u.UserPassword+"','"+u.UserSex+"',"+u.DpId+",'"+u.Post+"','"+u.Status+"',"+u.UserType+",'"+u.Telephone+"','"+u.Email+"',"+compid+",'"+u.CreateTime+"','"+u.EndTime+"')");
						}
					}
				}
				int[] resultSuccess=sts.executeBatch();
				System.out.println(resultSuccess);
			}
			
			
			//导入有错误用户
			if(errorUserlist.size()>0) {
				//创建临时表
				String tempTableName=TEMP_TABLE_NAME_PRE+userinfo.getUserID().toString().trim();
				int createCount=-1;
				Map<String,Object> map=new HashMap<String,Object>();
				map.put("tableName", tempTableName);
				String databaseName=getDatabaseName();
				map.put("dbName", databaseName);
				map.put("result", createCount);
//				organizationDao.dropTempUserTable(tempTableName,"webtest2019",result);
				organizationDao.createTempUserTable(map);
				System.out.println("result:"+map.get("result"));
				//用户格式错误
				for(TUserinfo u :errorUserlist){
					u.Post = Sqlca.switchLatin1Encoding(u.Post);
					u.UserName = Sqlca.switchLatin1Encoding(u.UserName);
					u.DisplayName = Sqlca.switchLatin1Encoding(u.DisplayName);
					u.UserPassword = u.UserPassword==null?null:Sqlca.switchLatin1Encoding(u.UserPassword);
					u.Post=u.Post==null?"":u.Post;
					u.UserName=u.UserName==null?"":u.UserName;
					u.DisplayName=u.DisplayName==null?"":u.DisplayName;
					u.UserPassword=u.UserPassword==null?"":u.UserPassword;
					u.UserSex=u.UserSex==null?1:u.UserSex;
					u.Status=u.Status==null?"0":u.Status;
//					u.UserType=u.UserType==null?"":u.UserType;
					u.Telephone=u.Telephone==null?"":u.Telephone;
					u.Email=u.Email==null?"":u.Email;
					u.DpId=u.DpId==null?1:u.DpId;
					u.CreateTime=u.CreateTime==null?"":u.CreateTime;
					u.EndTime=u.EndTime==null?"":u.EndTime;
					if("".equals(u.CreateTime) && "".equals(u.EndTime)) {
						sts.addBatch("insert into "+tempTableName+"(UserName,DisplayName,UserPassword,UserSex,DpId,Post,State,IsSuper,Telephone,Email,CompID,Description) "
								+ " values('"+u.UserName+"','"+u.DisplayName+"','"+u.UserPassword+"','"+u.UserSex+"',"+u.DpId+",'"+u.Post+"','"+u.Status+"',"+u.UserType+",'"+u.Telephone+"','"+u.Email+"',"+compid+",'"+u.Remark+"'"+")");
					}
					else
					{
						sts.addBatch("insert into "+tempTableName+"(UserName,DisplayName,UserPassword,UserSex,DpId,Post,State,IsSuper,Telephone,Email,CompID,createtime,endtime,Description) "
								+ " values('"+u.UserName+"','"+u.DisplayName+"','"+u.UserPassword+"','"+u.UserSex+"',"+u.DpId+",'"+u.Post+"','"+u.Status+"',"+u.UserType+",'"+u.Telephone+"','"+u.Email+"',"+compid+",'"+u.CreateTime+"','"+u.EndTime+"','"+u.Remark+"'"+")");
					}
				}
				int[] resultError=sts.executeBatch();
				System.out.println(resultError);
			}
			
			
			Map<String,Integer> resultMap=new HashMap<String,Integer>();
			resultMap.put("successCount", excelTotalRow-errorUserlist.size());
			resultMap.put("errorCount", errorUserlist.size());
		       
	       if(errorUserlist.size()>0) {
	    	   result=new Result<Map<String,Integer>>(-1, "error", resultMap);
	       }else {
	    	   result=Result.success(resultMap);
	       }
		       
		}catch(BatchUpdateException e){
			int[] i=e.getUpdateCounts();
			logger.info(i, e);
			System.out.println("i[]="+i);
			e.printStackTrace();
			return result;
		}catch(Exception e){
			e.printStackTrace();
			return result;
		}finally{
			sts.close();
			conn.close();
		}
		
		
		  
		return result;
	}
	
	
	@RequestMapping(value="/Modifypwdsubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String Modifypwdsubmit(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_VIPSESSION");
		String username = null;
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			username = userinfo.UserName;
			compid = userinfo.CompID;
			
		}	
		String oldpwd = request.getParameter("oldpwd");
		String newpwd = request.getParameter("newpwd");
		
		oldpwd = SecurityUtil.encryptMD5(oldpwd);
		String check = "select 1 from t_userinfo where UserName='"+username+"' and UserPassword='"+oldpwd+"'";
		String str = Sqlca.getString(check);
		if(str==null)
		{
			return "fail";
		}
		String pwd = SecurityUtil.encryptMD5(newpwd);
		int cnt = Sqlca.updateObject("update t_userinfo set UserPassword=? where UserName=?", new String[] {pwd,username});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	/**
	 * 修改个人信息
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editUserInfo")
	@ResponseBody
	public String editUserInfo(HttpServletRequest request,HttpServletResponse response,TUserinfo tuserInfo) throws Exception {
		int cnt = Sqlca.updateObject("update t_userinfo set UserSex =?, Telephone =?,Email=?,displayName=? where UserID=?", new String[] {tuserInfo.UserSex.toString(),tuserInfo.Telephone,tuserInfo.Email,tuserInfo.DisplayName,tuserInfo.UserID.toString()});
		Sqlca.updateObject(" update t_compinfo set Lianxr =?,Lianxrtel=? WHERE CompName =?", new String[] {tuserInfo.DisplayName,tuserInfo.Telephone,tuserInfo.UserName});
		
		if(cnt>0) {
			return "success";
		}
		
		return "success";
	}
	
	/**
	 * 查看用户详情
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 */
	@RequestMapping("userInfo.do")
	public ModelAndView getUserInfo(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		ModelAndView mv=new ModelAndView("userManager/userDetail");
		String userIdStr=request.getParameter("userId");
		int userId=-1;
		if(userIdStr!=null&&!"".equals(userIdStr)) {
			userId=Integer.parseInt(userIdStr);
		}
		UserVO userVO=userDao.getUserInfo(userId);
		mv.addObject("user", userVO);
		return mv;
	}
	
	/**
	 * 获取数据库名称
	 * @return
	 */
	public String getDatabaseName() {
		String databaseName=null;
		try {
			Properties prop = new Properties();
			InputStream in = UserManagerController.class.getClassLoader().getResourceAsStream("config.properties");
	        prop.load(in);
	        String jdbcUrl=prop.getProperty("jdbc.url");
	        databaseName=jdbcUrl.substring(jdbcUrl.lastIndexOf("/")+1, jdbcUrl.lastIndexOf("?"));
	       
		} catch (Exception e) {
			new Throwable(e);
		}
		 return databaseName;
	}
	
	/**
	 * 删除User导入错误临时表
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 */
	@RequestMapping("dropTempUserTable.do")
	@ResponseBody
	public Result<String> dropTempUserTable(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer userId = null;
		if(obj!=null){
			TUserinfo userinfo = (TUserinfo)obj;
			userId = userinfo.getUserID();
		};
		Result<String> result=new Result<String>(-1, "删除临时表失败", TEMP_TABLE_NAME_PRE+userId);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("dbName",getDatabaseName());
		map.put("tableName", TEMP_TABLE_NAME_PRE+userId);
		map.put("result",-1);
		organizationDao.dropTempUserTable(map);
		Object resultObj=map.get("result");
		Integer i=Integer.parseInt(resultObj.toString());
		if(i==0) {
			result=Result.success(TEMP_TABLE_NAME_PRE+userId);
		}
		return result;
	}
	
	
	/*@RequestMapping(value="UserManager.do")
	public ModelAndView UserManager() throws Exception {
		
		ArrayList<Map<String,Object>> arraylist = OrganManagerController.getOrganMenu();
		
		ModelAndView view = new ModelAndView("system/UserManager");
		view.addObject("organMenu", arraylist);
		return view;
	}
	
	@RequestMapping(value="/UserContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid) throws Exception {
		
		ArrayList<Map<String,Object>> array = getOrganUserList(dpid);
		ModelAndView view = new ModelAndView("system/UserContent");
		view.addObject("organUserList", array);
		return view;
	}
	
	@RequestMapping(value="/AddDepartMentUser.do")
	public ModelAndView AddDepartMent() {
		ModelAndView view = new ModelAndView("system/AddDepartMentUser");
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int DpId = tUser.get
		return view;
	}
	
	
	@RequestMapping(value="/AddDepartMentUserSubmit.do")
	@ResponseBody
	public String AddDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String CompID = request.getParameter("CompID");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		
		
		int cnt = Sqlca.updateObject("insert into t_userinfo(UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email,OrderIndex) " + 
				"value(?,?,?,?,?,?,?,'0')", new String[] {UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DelDepartMentUserSubmit.do")
	@ResponseBody
	public String DelDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserID = request.getParameter("UserID");
		int cnt = Sqlca.updateObject("delete from t_userinfo where UserID=?", new String[] {UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	
	@RequestMapping(value="/ModifyDepartMentUserSubmit.do")
	@ResponseBody
	public String ModifyDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String UserID = request.getParameter("UserID");
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String CompID = request.getParameter("CompID");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		
		int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpId=?,CompID=?,UserStatus=?,Telephone=?,Email=? " + 
				"where UserID=?", new String[] {UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email,UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyDepartMentUser.do")
	public ModelAndView ModifyDepartMent(@RequestParam("UserID") String UserID) throws Exception {
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select UserID,UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email from t_userinfo t where t.UserID='"+UserID+"'");
		ModelAndView view = new ModelAndView("system/ModifyDepartMentUser");
		view.addObject("user", array.get(0));
		return view;
	}
	
	@RequestMapping(value="/DepartMentUserQuery.do")
	@ResponseBody
	public ArrayList<Map<String,Object>> DepartMentQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String displayName = request.getParameter("displayName");
		String sql = " select t.UserID,t.UserName,t.DisplayName,(select DpName from t_department tt where tt.DpId=t.DpId) as DpId," + 
				" (select rolename from t_sys_role where roleid=t.CompID) as CompID," + 
				" (select op_display from t_option where op_param='userStatus' and op_value=t.UserStatus) as UserStatus," + 
				" t.Telephone,t.Email,t.UserID as Operation "+
				" from t_userinfo t where t.DisplayName like '%"+displayName+"%'";
		ArrayList<Map<String,Object>> organList = Sqlca.getArrayListFromMap(sql);
		request.setAttribute("organList", organList);
//		request.getRequestDispatcher(request.getContextPath()+"\\system\\OrganContent").forward(request, response);
		return organList;
	}
	
	
	
	public ArrayList<Map<String,Object>> getOrganUserList(String dpid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
//		if("99999".equals(dpid)) {dpid="0";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,'' as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(where1+",");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
//				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(where2+",");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
//					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
//						sqlbf.append(" union ").append(menus3).append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
//				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
				sqlbf.append(where1+",");
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
//					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
					sqlbf.append(where2+",");
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
//						sqlbf.append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}
		
		String where = sqlbf.toString().substring(0, sqlbf.toString().length()-1);
		
		String sql = " select t.UserID,t.UserName,t.DisplayName,(select DpName from t_department tt where tt.DpId=t.DpId) as DpId," + 
				" (select rolename from t_sys_role where roleid=t.CompID) as CompID," + 
				" (select op_display from t_option where op_param='userStatus' and op_value=t.UserStatus) as UserStatus," + 
				" t.Telephone,t.Email,t.UserID as Operation "+
				" from t_userinfo t where t.DpId in("+where+")";
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		
		return array;
		
		}*/
}
