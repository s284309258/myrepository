package com.huawang.controller.mobile;

import org.springframework.ui.Model;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huawang.dao.api.appDao;
import com.huawang.pojo.inter.TCompinfoVo;
import com.huawang.pojo.inter.TUser;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.util.SecurityUtil;
import com.huawang.util.qRcodeUtil.QRCodeUtil;

import net.sf.json.JSONObject;



@Controller
@RequestMapping(value="/mobile")
public class mobileController {

	@Autowired
	private com.huawang.dao.mobile.mobileDao mobileDao;
	@Autowired
	private appDao appDao;
	
	/**
	 *	 进入会议分享页面
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectConfMeetingInfo",method= {RequestMethod.POST,RequestMethod.GET})
	public String selectConfMeetingInfo(HttpServletRequest request,Model model) throws Exception {
		
		String userId ="90254" ;//request.getParameter("userId")==null?"":request.getParameter("userId");
		String confId ="14409";//request.getParameter("confId")==null?"":request.getParameter("confId");
		
		String userAgent = request.getHeader("user-agent");
		int Android =1;
		if(userAgent.indexOf("Android") != -1){
	 		//安卓
			Android =1;
			System.out.println("安卓"+Android);
			request.setAttribute("AndroidList", Android);
	 	}else if(userAgent.indexOf("iPhone") != -1 || userAgent.indexOf("iPad") != -1){
	 		//苹果
	 		Android =2;
	 		System.out.println("苹果");
	 		request.setAttribute("AndroidList", Android);
	 	}else{
	 		//电脑
	 		Android =3;
	 		System.out.println("电脑端"+Android);
	 	}
		/*TConfinfo tConfinfo = mobileDao.selectMeetingInfo(Integer.parseInt(confId));
		String displayName = mobileDao.selectUserDisplayNameToUserId(Integer.parseInt(userId));*/
		TConfinfo tConfinfo = mobileDao.selectMeetingInfo(14409);
		String displayName = mobileDao.selectUserDisplayNameToUserId(90254);
		tConfinfo.setDisplayName(displayName);
		model.addAttribute("Android", Android);//1:安卓 2：苹果 3：电脑端
		model.addAttribute("tConfinfo", tConfinfo);
		return "mobile/share/inviteMeeting";
	}
	
	/**
	 * 	比较开始结束时间先后
	 * @param DATE1
	 * @param DATE2
	 * @return
	 */
	public static int compare_date(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            if (dt1.getTime() > dt2.getTime()) {
                System.out.println("前面时间大于后面时间");
                return 1;
            } else if (dt1.getTime() < dt2.getTime()) {
                System.out.println("前面时间小于后面时间");
                return -1;
            } else {
            	System.out.println("前面时间等于后面时间");
                return 0;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }
	
	/**
	 * 	根据登录方式获取登录url
	 * @param request
	 * @return
	 */
	public String getLoginMeetingUrl(HttpServletRequest request) {
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = df.format(new Date());//当前时间
		String isReservedConf =request.getParameter("isReservedConf")==null?"":request.getParameter("isReservedConf");//0、长期 1、预约 2、周期
		String isPublic  =request.getParameter("isPublic")==null?"":request.getParameter("isPublic");//呢称加密0  不加密1  账号2
		String startTime ="";
		String endTime ="";
		startTime =request.getParameter("startTime")==null?"date":request.getParameter("startTime");
		endTime = request.getParameter("endTime")==null?"date":request.getParameter("endTime");
		String account = request.getParameter("account")==null?"":request.getParameter("account");
		
		String url ="";
		String pwd ="";
		String loginType = request.getParameter("loginType")==null?"0":request.getParameter("loginType");//APP登录类型 1、华望云 2、云会议 3、其他定制
		if(loginType.equals("1")) {//APP登录类型 1、华望云 2、云会议 3、其他定制
			if(isReservedConf.equals("1")) {
				int day = compare_date(startTime, date);//判断与当前时间比较
				int day1 = compare_date(endTime, date);//判断与结束时间比较
				if(day==1&&day1==1) {
					if(isPublic.equals("0")) {
						pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
						url="hwapp://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
					}else {
						url="hwapp://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
					}
				}else {
					url ="-1";
				}
			}else {
				if(isPublic.equals("0")) {
					pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
					url="hwapp://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
				}else {
					url="hwapp://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
				}
			}
		}else if(loginType.equals("2")){//APP登录类型 1、华望云 2、云会议 3、其他定制
			if(isReservedConf.equals("1")) {
				int day = compare_date(startTime, date);//判断与当前时间比较
				int day1 = compare_date(endTime, date);//判断与结束时间比较
				if(day==1&&day1==1) {
					if(isPublic.equals("0")) {
						pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
						url="appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
					}else {
						url="appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
					}
				}else {
					url ="-1";
				}
			}else {
				if(isPublic.equals("0")) {
					pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
					url="appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
				}else {
					url="appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
				}
			}
		}else if(loginType.equals("3")) {
			if(isReservedConf.equals("1")) {
				int day = compare_date(startTime, date);//判断与当前时间比较
				int day1 = compare_date(endTime, date);//判断与结束时间比较
				if(day==1&&day1==1) {
					if(isPublic.equals("0")) {
						pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
						url="app:appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
					}else {
						url="app:appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
					}
				}else {
					url ="-1";
				}
			}else {
				if(isPublic.equals("0")) {
					pwd =request.getParameter("pwd")==null?"":request.getParameter("pwd");
					url="app:appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account+"&pwd="+pwd+"";
				}else {
					url="app:appnormal://com.cloudmeeting?server=sz1.hwactive.com&type=1&account="+account;
				}
			}
		}else {
			url ="-1";
		}
		return url;
	}
	
	 
	
		/**
		 *	 用户参加会议
		 * @param request
		 * @param model
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/userAttendMeeting",method= {RequestMethod.POST,RequestMethod.GET})
		public String userAttendMeeting(HttpServletRequest request,Model model) throws Exception {
			
			String Android =request.getParameter("Android");
			String confId =request.getParameter("confId")==null?"":request.getParameter("confId");
			String url="";
			if(Android.equals("1")) {//安卓
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}
			}else if(Android.equals("2")) {//苹果
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}
			}else {
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}
			}
			System.out.println("参会链接："+url);
			TConfinfo tConfinfo = mobileDao.selectMeetingInfo(Integer.parseInt(confId));
			model.addAttribute("fileUrl", url);
			model.addAttribute("tConfinfo", tConfinfo);
			return "mobile/share/attendMeeting";
		}
	
	
		/**
		 *	 获取扫码参会二维码
		 * @param request
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/getQrcodeurl",method= {RequestMethod.POST,RequestMethod.GET})
		public String getQrcodeurl(HttpServletRequest request,Model model)throws Exception {
	
			String Android =request.getParameter("Android");
			String confId = request.getParameter("confId")==null?"":request.getParameter("confId");
			String url="";
			if(Android.equals("1")) {//安卓
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}else {
					return url;
				}
			}else if(Android.equals("2")) {//苹果
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}else {
					return url;
				}
			}else {
				url =  getLoginMeetingUrl(request);
				if(url.equals("-1")) {
					url ="会议室过期！";
				}else {
					return url;
				}
			}
			
			@SuppressWarnings("deprecation")
			String realPath = request.getRealPath("images/confQrcode");
			String text = url;
			String fileUrl = QRCodeUtil.encode(text, "", realPath, true);
			System.out.println("二维码生成了！"+fileUrl);
			TConfinfo tConfinfo = mobileDao.selectMeetingInfo(Integer.parseInt(confId));
			model.addAttribute("fileUrl", fileUrl);
			model.addAttribute("tConfinfo", tConfinfo);
			return "mobile/share/shareQrcode";
		}
		
		
		
	
		/**
		 *    扫码中转站
		 * @param request
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/qrcodeTransfer",method = {RequestMethod.POST,RequestMethod.GET})
		public String qrcodeTransfer(HttpServletRequest request,Model model) throws Exception {
			 
			 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
			 String type = request.getParameter("type")==null?"":request.getParameter("type");//扫码进入方式
			
			 
			 if(type.equals("1")) {//邀请参会
					 TUser tUser = mobileDao.selectOrganInfoByUserId(Integer.parseInt(uid));
					 model.addAttribute("tUser", tUser);
				 return "mobile/organ/verifyIdentity";
				 }else {//加入组织
					 	//检测分享用户是否有下载华望云APP如果没有，跳转至下载页面，已经下载
					String userAgent = request.getHeader("user-agent");
					int Android =1;
					if(userAgent.indexOf("Android") != -1){
				 		//安卓
						Android =1;
						System.out.println("安卓"+Android);
						request.setAttribute("AndroidList", Android);
				 	}else if(userAgent.indexOf("iPhone") != -1 || userAgent.indexOf("iPad") != -1){
				 		//苹果
				 		Android =2;
				 		System.out.println("苹果");
				 		request.setAttribute("AndroidList", Android);
				 	}else{
				 		//电脑
				 		Android =3;
				 		System.out.println("电脑端"+Android);
				 	}
	
				    String compId =request.getParameter("oid")==null?"":request.getParameter("oid");//企业id
				    String confId =request.getParameter("cid")==null?"":request.getParameter("cid");//会议id
					 
					TConfinfo tConfinfo = mobileDao.selectMeetingInfo(Integer.parseInt(confId));
					String displayName = mobileDao.selectUserDisplayNameToUserId(Integer.parseInt(uid));
					tConfinfo.setDisplayName(displayName);
					tConfinfo.setCompId(Integer.parseInt(compId));
					model.addAttribute("Android", Android);//1:安卓 2：苹果 3：电脑端
					model.addAttribute("tConfinfo", tConfinfo);
					return "mobile/share/inviteMeeting";
				 }
		}
	
 
		 public String daysOfTwo_2(String telePhone) throws Exception {
			 String create  = appDao.validateMessage(telePhone);
			 	SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化时间  
		        String nowtime = d.format(new Date());// 按以上格式 将当前时间转换成字符串  
		        System.out.println("当前时间：" + nowtime);  
		        String testtime = "2019-05-15 12:40:35";// 测试时间  
		        System.out.println("测试时间：" + testtime);  
		        long result=0;
		        try {  
		        	// 当前时间减去测试时间   // 这个的除以1000得到秒，相应的60000得到分，3600000得到小时  
		            result = (d.parse(nowtime).getTime() - d.parse(create).getTime()) / 60000;
		            System.out.println("当前时间减去测试时间=" + result + "分钟");  
		        } catch (ParseException e) {  
		            e.printStackTrace();  
		        }  
		        return String.valueOf(result);
		    }
		/**
		 * 	获取验证码注册
		 * @param request
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/getCodeRegister",method = {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String getCodeRegister(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception {
			
			String message = "";
			String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			String code = request.getParameter("phoneCode")==null?"":request.getParameter("phoneCode");
	    	String type = "1";
			boolean flag = appDao.validatePhoneToCode(telePhone, code,type);
			TUser tUser = appDao.verificatUserPhone(telePhone);//验证手机号是否已注册
			String time = daysOfTwo_2(telePhone);
			
			if(!flag) {
				message ="0";//
				return message;
			}else if(null==tUser){
				message ="1";
				return message;
			}else if(Integer.parseInt(time)>30){
				message="2";
				return message;
			}else{
				JSONObject json = new JSONObject();
				json.put("telePhone", telePhone);
				json.put("phoneCode", code);
				return json.toString();
			}
		}
		
		/**
		 * 	进入完善信息页面
		 * @param request
		 * @param response
		 * @param model
		 * @return
		 */
		@RequestMapping(value="/comInPerfectInfo",method= {RequestMethod.POST,RequestMethod.GET})
		public String comInPerfectInfo(HttpServletRequest request,HttpServletResponse response,Model model) {
			
			String compId = request.getParameter("compId")==null?"":request.getParameter("compId");
			String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			String phoneCode = request.getParameter("phoneCode")==null?"":request.getParameter("phoneCode");
			model.addAttribute("compId", compId);
			model.addAttribute("telePhone", telePhone);
			model.addAttribute("phoneCode", phoneCode);
			return "mobile/organ/registerUser";
		}
		
		/**
		 * 	跳转至已经加入企业页面
		 * @param request
		 * @param response
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/alreadAddOrgan",method= {RequestMethod.POST,RequestMethod.GET})
		public String alreadAddOrgan(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception {
			
			String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			TCompinfoVo compModel  =mobileDao.selectCompInfo(telePhone);
			model.addAttribute("tcompInfo", compModel);
			model.addAttribute("telePhone", telePhone);
			return "mobile/organ/alreadyReg";
		}
		/**
		 * 	申请成功
		 * @param request
		 * @param response
		 * @param model
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/applaySuccess",method= {RequestMethod.POST,RequestMethod.GET})
		public String applaySuccess(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception {
		
			String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			String displayName=request.getParameter("displayName")==null?"":request.getParameter("displayName");
			String userPassword =request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
			model.addAttribute("telePhone", telePhone);
			model.addAttribute("displayName", displayName);
			model.addAttribute("userPassword", userPassword);
			return "mobile/organ/applaySuccess";
		}
		
		/**
		 * 	添加申请数据
		 * @param request
		 * @param response
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/addUserRequest",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String addUserRequest(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception {
			
			TUser tUser = new TUser();
			String telePhone =request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			String displayName = request.getParameter("displayName")==null?"":request.getParameter("displayName");
			String userPassword =request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
			String compId =request.getParameter("compId")==null?"":request.getParameter("compId");
			userPassword = SecurityUtil.encryptMD5(userPassword);
			tUser.setDisplayName(displayName);
			tUser.setUserPassword(userPassword);
			tUser.setUserPhone(telePhone);
			tUser.setCompId(Integer.parseInt(compId));
			
			String message ="";
			TUser tUsers = appDao.verificatUserPhone(telePhone);//验证手机号是否已注册
			int count=0;
			if(null==tUsers){
				count = appDao.register(tUser);
				if(count>0) {
					message="0";
				}
			}else {
				message ="1";
			} 
			return message;
		}
		
		/**
		 * 	退出组织
		 * @param request
		 * @param response
		 * @param model
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/signOutOrgan",method= {RequestMethod.POST,RequestMethod.GET})
		public String signOutOrgan(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception {

			String message ="";
			String telephone =request.getParameter("telephone")==null?"":request.getParameter("telephone");
			int count = mobileDao.signOutOrgan(telephone);
			if(count>0) {
				message="退出成功！";
			}else {
				message ="退出失败！";
			}
			return "mobile/organ/addOrgan";
		}
	
}





























