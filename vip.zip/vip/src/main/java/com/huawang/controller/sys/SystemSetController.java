package com.huawang.controller.sys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.util.MailUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Sys")
public class SystemSetController 
{
	@RequestMapping(value="/SetServerInfo.do")
	public ModelAndView SetServerInfo(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select SmtpAddr,SmtpPort,SmtpUserName,SmtpUserMail,SmtpUserPwd,SmtpId,CompId,OutNetAddress,InNetAddress from t_smtpinfo where CompId='"+compid+"'");
		
		if(array.size()==0)
		{
			ModelAndView view = new ModelAndView("sys/emailServerSet");
			view.addObject("server", new HashMap<String,Object>());
			return view;
		}
		else
		{
			ModelAndView view = new ModelAndView("sys/emailServerInfo");
			view.addObject("server", array.get(0));
			return view;
		}
		
	}
	@RequestMapping(value="/SetServer.do")
	public ModelAndView SetServer(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select SmtpAddr,SmtpPort,SmtpUserName,SmtpUserMail,SmtpUserPwd,SmtpId,CompId,OutNetAddress,InNetAddress from t_smtpinfo where CompId='"+compid+"'");
		ModelAndView view = new ModelAndView("sys/emailServerSet");
		if(array.size()==0)
		{
			view.addObject("server", new HashMap<String,Object>());
		}
		else
		{
			view.addObject("server", array.get(0));
		}
		
		return view;
	}
	
	/**
	 *  企业信息管理查询
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="ModifyCompInfo.do")
	public ModelAndView ModifyCompInfo(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		String sql = " select tcci.CompTrueName as certCompanyName,t.Email,t.taxNumber,t.isJoinApprove,t.IsJoinId,t.CompID,t.CompName,t.CompTrueName,t.MaxCurUserCount,t.Lianxr,t.Lianxrtel,(select min(o_CreateDate) as o_CreateDate from t_order where o_CompID="+compid+") as CreateDate,t.EndDate,"+
		" (select ServerIP from t_serverinfo where ServerID=t.McuipId) as CompIP,t.MaxUserCount,(select ee.AdminTrueName from t_admininfo ee where ee.AdminID=t.AdminID) as AdminID"
		+ " ,t.McuipId,t.McuIp,t.IsMeeting, t.MeetingCount from t_compinfo t LEFT JOIN t_comp_certification_info tcci ON t.CompID=tcci.CompID where t.CompID="+compid;
		
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("sys/companyInfo");
		if(array.size()==0)
		{
			view.addObject("compinfo", new HashMap<String,Object>());
		}
		else
		{
			view.addObject("compinfo", array.get(0));
		}
		
		return view;
	}
	
	/**
	 * 查询页面点击进入修改
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="ModifyCompInfoEdit.do")
	public ModelAndView ModifyCompInfoEdit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		String sql = " select tcci.CompTrueName as certCompanyName,t.Email,t.taxNumber,t.isJoinApprove,t.IsJoinId,t.CompID,t.CompName,t.CompTrueName,t.MaxCurUserCount,t.Lianxr,t.Lianxrtel,(select min(o_CreateDate) as o_CreateDate from t_order where o_CompID="+compid+") as CreateDate,t.EndDate,"+
		" (select ServerIP from t_serverinfo where ServerID=t.McuipId) as CompIP,t.MaxUserCount,(select ee.AdminTrueName from t_admininfo ee where ee.AdminID=t.AdminID) as AdminID"
		+ " ,t.McuipId,t.McuIp,t.IsMeeting, t.MeetingCount from t_compinfo t LEFT JOIN t_comp_certification_info tcci ON t.CompID=tcci.CompID where t.CompID="+compid;
		
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("sys/companyInfosave");
		if(array.size()==0)
		{
			view.addObject("compinfo", new HashMap<String,Object>());
		}
		else
		{
			view.addObject("compinfo", array.get(0));
		}
		
		return view;
	}
	
	/**
	 * 	保存企业修改设置数据
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="ModifyCompInfoSubmit.do")
	@ResponseBody
	public String ModifyCompInfoSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		
		String CompID = (String)request.getParameter("CompID");
		String Lianxr = (String)request.getParameter("Lianxr");
		String Lianxrtel = (String)request.getParameter("Lianxrtel");
		String Email=request.getParameter("Email");
		String taxNumber=request.getParameter("taxNumber");
		String IsJoinId=request.getParameter("IsJoinId");
		String IsMeeting=request.getParameter("IsMeeting");
		String MeetingCount=request.getParameter("MeetingCount");
		String isJoinApprove=request.getParameter("isJoinApprove");
		
		int cnt = Sqlca.updateObject("update t_compinfo set Lianxr=?,Lianxrtel=?,Email=?,taxNumber=?,IsJoinId=?,IsMeeting=?,MeetingCount=?,isJoinApprove=? where CompID=?", new String[] {Lianxr,Lianxrtel,Email,taxNumber,IsJoinId,IsMeeting,MeetingCount,isJoinApprove,CompID});
		
		if(cnt>0)
		{
			return "success";
		}
		else
		{
			return "fail";
		}
		
		
	}
	
	
	
	
	@RequestMapping(value="EmailServerSubmit.do")
	@ResponseBody
	public String EmailServerSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		String SmtpAddr = (String)request.getParameter("SmtpAddr");
		String SmtpPort = (String)request.getParameter("SmtpPort");
		String SmtpUserName = (String)request.getParameter("SmtpUserName");
		String SmtpUserMail = (String)request.getParameter("SmtpUserMail");
		String SmtpUserPwd = (String)request.getParameter("SmtpUserPwd");
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
		}
		String cnt = Sqlca.getString("select compid from t_smtpinfo where compid='"+compid+"'");
		if(cnt==null)
		{
			Sqlca.updateObject("insert into t_smtpinfo(SmtpAddr,SmtpPort,SmtpUserName,SmtpUserMail,SmtpUserPwd,CompId) values(?,?,?,?,?,"+compid+")", 
					new String[] {SmtpAddr,SmtpPort,SmtpUserName,SmtpUserMail,SmtpUserPwd});
		}
		else
		{
			Sqlca.updateObject("update t_smtpinfo set SmtpAddr=?,SmtpPort=?,SmtpUserName=?,SmtpUserMail=?,SmtpUserPwd=? where CompId="+compid, 
					new String[] {SmtpAddr,SmtpPort,SmtpUserName,SmtpUserMail,SmtpUserPwd});
		}
		
		return "success";
	}
	
	
	@RequestMapping(value="SendEmail.do",produces = "text/html;charset=utf-8",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String SendEmail(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String confid = request.getParameter("confId");
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
		}
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap("select t.SmtpAddr,t.SmtpPort,t.SmtpUserName,t.SmtpUserMail,t.SmtpUserPwd,t.SmtpId,"
				+ "t.CompId,t.InNetAddress,t.OutNetAddress from t_smtpinfo t where t.CompId="+compid);
		
		String sql = "select Email from t_userinfo u where u.UserID in(select UserID from t_confusers where ConfID="+confid+") AND Email is not null";
		
		String contentsql = "select ConfName,StartTime,EndTime,ConfID,ConfPwd,ConfDesc from t_confinfo where ConfID="+confid;
		ArrayList<Map<String, Object>> ct = Sqlca.getArrayListFromMap(contentsql);
		
		Map<String, Object> ccc =ct.get(0);
		
		ArrayList<Map<String, Object>> maillist = Sqlca.getArrayListFromMap(sql);
		
		ArrayList<String> receiveList = new ArrayList<String>();
		for(Map<String, Object> map : maillist)
		{
			String mm = (String)map.get("Email");
			if(!"".equals(mm) && null!=mm)
			{
				receiveList.add(mm);	
			}
		}
		
		if(list.size()==0)
		{
			return "邮件服务器未配置";
		}
		
		Map<String, Object> smt = list.get(0);
		String SmtpAddr = (String)smt.get("SmtpAddr");
		String SmtpPort = (String)smt.get("SmtpPort");
		String SmtpUserName = (String)smt.get("SmtpUserName");
		String SmtpUserMail = (String)smt.get("SmtpUserMail");
		String SmtpUserPwd = (String)smt.get("SmtpUserPwd");
		String[] receives = new String[receiveList.size()];
		receives = (String[]) receiveList.toArray(receives);
		if(receiveList.size()==0)
		{
			return "参会成员邮箱地址未配置";
		}
		String content = "会议室名:"+ccc.get("ConfName").toString()
				+ "<br>会议时间:"+ccc.get("StartTime").toString()+" - "+ccc.get("EndTime").toString()
				+ "<br>会议号:"+ccc.get("ConfID")
				+ "<br>会议密码:"+ccc.get("ConfPwd")
				+ "<br>会议说明:"+ccc.get("ConfDesc").toString();
		
		String msg = MailUtil.sendMail(SmtpAddr, SmtpPort, SmtpUserMail, SmtpUserPwd,SmtpUserName, receives, content,ccc.get("ConfName").toString());
		
		if("yes".equals(msg))
		{
			return "邮件发送成功";
		}
		else
		{
			return "邮件发送失败,请检查网络和邮件服务器配置";
		}
//    	String result = MailUtil.sendMail(rs.getString("smtpAddr"),
//				rs.getString("smtpPort"), rs.getString("smtpUserName"),
//				rs.getString("smtpUserPwd"), new String(new String(rs.getString("SmtpUserMail").getBytes("ISO-8859-1"), "GBK").getBytes("UTF-8"), "UTF-8"),
//				receiveMail.split(","), mailDesc.replaceAll("\n", "<br>"));
	}
	
	@RequestMapping(value="DownloadSoftware.do")
	public ModelAndView DownloadSoftware()
	{
		ModelAndView view = new ModelAndView("sys/downloadSoftware");
		
		return view;
	}
}
