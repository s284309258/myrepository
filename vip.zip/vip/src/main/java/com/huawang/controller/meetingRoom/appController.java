package com.huawang.controller.meetingRoom;

import java.io.File;
import java.sql.Connection;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.huawang.dao.api.appDao;
import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.pojo.inter.TCompinfoVo;
import com.huawang.pojo.inter.TConfinfoVo;
import com.huawang.pojo.inter.TDepatMentVo;
import com.huawang.pojo.inter.TUser;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.util.Sqlca;
import com.huawang.yzx.client.apiClient;

@Controller
@RequestMapping(value="/app")
public class appController {

	@Autowired
	private appDao APPDao;
	@Autowired
	private MeetingRoomDao meetingRoomDao;
	
	/**
	 * 	获取手机号验证码
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/verificatPhone",method=RequestMethod.POST)
	@ResponseBody
	public  Map<String, Object> getPhoneCode(HttpServletRequest request) throws Exception {
		 
		String error_code ="";
		String templateid = request.getParameter("type");//1、注册 2、忘记密码3、管理员验证
		String mobile =request.getParameter("telePhone");//手机号
		String param = getRamdom();  //随机数
		JSONObject jsonStr = new JSONObject();
		JSONObject jsons = new JSONObject(); 
		
		if(templateid.equals("1")) {
			TUser tUser = APPDao.verificatUserPhone(mobile);//验证手机号是否已注册
			 
			if(null==tUser) {
				APPDao.addPhoneCode(mobile, param, templateid);
				templateid="452906";
			}else {
				error_code ="1";//手机号已经注册
				jsonStr.put("displayName", tUser.getDisplayName());
				jsonStr.put("userPhone", tUser.getUserPhone());
				jsons.put("result",jsonStr);
				jsons.put("error_code", error_code);
				return jsons;
			}
		}else if(templateid.equals("2")) {
			APPDao.addPhoneCode(mobile, param, templateid);
			templateid="452907";
		}else if(templateid.equals("3")) {
			APPDao.addPhoneCode(mobile, param, templateid);
			templateid="454124";
		}else if(templateid.equals("4")){
			APPDao.addPhoneCode(mobile, param, templateid);
			templateid="466348";
		}else {
			APPDao.addPhoneCode(mobile, param, templateid);
			templateid="454143";
		}
		String msg = apiClient.sendSms(templateid,mobile,param);//触发短信接口
		JSONObject json = JSONObject.parseObject(msg);
		String message =json.get("msg").toString();
		 
		if(message.equals("OK")) {
			error_code ="000000";
		}else {
			error_code ="2";//请求失败！
		}
		jsonStr.put("msg", message);
		jsonStr.put("error_code", error_code);
		return jsonStr;
	}
	
	/**
	 * 获取四位随机数
	 * @return
	 */
	public static String getRamdom() {
		int i=1;//i在此程序中只作为判断是否是将随机数添加在首位，防止首位出现0；
		Random r=new Random();
		int tag[]={0,0,0,0,0,0,0,0,0,0};
		String str="";
		int temp=0;
		while(str.length()<4)
			  { temp=r.nextInt(10);//取出0(含)~10(不含)之间任意数
			    if(i==1&&temp==0)
			      {
			    	continue;
			      }
			    else{
			      i=2;
				if(tag[temp]==0)
				 {
				     str=str+temp;
				     tag[temp]=1;
			     }
		      }
		   } 
		return str;
	}

	/**
	 * 	校验是否为合法手机号
	 * @param phone
	 * @return
	 */
	public static boolean isPhone(String phone) {
	    String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$";
	    if (phone.length() != 11) {
	    	System.out.println("false");
	        return false;
	    } else {
	        Pattern p = Pattern.compile(regex);
	        Matcher m = p.matcher(phone);
	        boolean isMatch = m.matches();
	         
	        if (!isMatch) {
	        	System.out.println("false");
	        	return false;
	        }
	        return isMatch;
	    }
	}
	
	/**
	 *    校验手机验证码
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="validatePhoneCode",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>validatePhoneCode(HttpServletRequest request)throws Exception{
		String error_code ="";
		String telePhone = request.getParameter("telePhone");
    	String code = request.getParameter("code");
    	String type = request.getParameter("type");
    	boolean flag = APPDao.validatePhoneToCode(telePhone,code,type);
    	String time = daysOfTwo_2(telePhone);
    	
    	if(Integer.parseInt(time)>30 ||flag) {
    		if(Integer.parseInt(time)>30) {
    			error_code="25";
    		}else if(flag) {
    			error_code ="000000";
    		}
    	}else {
			error_code ="4";//验证码错误！
		}
    	
		JSONObject json = new JSONObject();
		json.put("error_code", error_code);
		return json;
	}
	/**
	 * 获取当前时间距离短信发送分钟数
	 * @param telePhone
	 * @return
	 * @throws Exception
	 */
	 public String daysOfTwo_2(String telePhone) throws Exception {
		 String create  = APPDao.validateMessage(telePhone);
		 	SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化时间  
	        String nowtime = d.format(new Date());// 按以上格式 将当前时间转换成字符串  
	        System.out.println("当前时间：" + nowtime);  
	        String testtime = "2019-05-15 12:40:35";// 测试时间  
	        System.out.println("测试时间：" + testtime);  
	        long result=0;
	        try {  
	        	// 当前时间减去测试时间   // 这个的除以1000得到秒，相应的60000得到分，3600000得到小时  
	            result = (d.parse(nowtime).getTime() - d.parse(create).getTime()) / 60000;
	            System.out.println("当前时间减去测试时间=" + result + "分钟");  
	        } catch (ParseException e) {  
	            e.printStackTrace();  
	        }  
	        return String.valueOf(result);
	    }
	
	 /**
	  *  	用户注册
	  * @param request
	  * @return
	 * @throws Exception 
	  */
	 @RequestMapping(value="register",method=RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>userRegister(HttpServletRequest request) throws Exception{
		 JSONObject jsonStr= new JSONObject();
		 JSONObject json = new JSONObject();
		 String error_code ="";
		 
		 String displayName =request.getParameter("displayName");
		 String telePhone = request.getParameter("telePhone");
		 String userPassword = request.getParameter("userPassword");
		 String code = request.getParameter("code");
		 boolean flag = APPDao.validatePhoneToCode(telePhone, code,"1");
		 if(flag) {//校验成功
			 TUser tUser = new TUser();
			 tUser.setUserPhone(telePhone);
			 tUser.setUserPassword(userPassword);
			 tUser.setUserStatus(0);
			 tUser.setDisplayName(displayName);
			 int count = APPDao.register(tUser);
			 if(count>0) {
				 error_code ="000000";
				 json.put("displayName", displayName);
				 json.put("telePhone", telePhone);
				 json.put("userPassword", userPassword);
			 }else {
				 error_code ="3";//新增用户失败！
			 }
		 }else {
			 error_code ="4";//手机验证码输入错误
		 }
		 jsonStr.put("error_code", error_code);
		 jsonStr.put("result", json);
		 return jsonStr;
	 }
	
	 /**
	  * 	忘记密码
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/retrievePassword",method=RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>retrievePassword(HttpServletRequest request) throws Exception{
		
		 String error_code ="";
		 String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
		 String userPassword = request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
		 String code = request.getParameter("code")==null?"":request.getParameter("code");
		 boolean flag = false;
		 String userStatus = APPDao.selectUserStatus(telePhone)==null?"0":APPDao.selectUserStatus(telePhone);
		 flag =  APPDao.validatePhoneToCode(telePhone, code, "2");
		 
		 int count =0;//获取修改数量
		 if(flag && userStatus.equals("0")) {
			 APPDao.updateUserPassword(telePhone, userPassword);
			 error_code="000000";
		 }else if(flag && userStatus.equals("2")) {
			 int isPhone = APPDao.selectUserPhone(telePhone);
			 if(isPhone>0) {
				 count = APPDao.retrievePassword(telePhone,userPassword);
			 }else {
				 error_code ="5";//手机号不存在，或未绑定
			 }
			 if(count>0) {
				 error_code="000000";
			 }else {
				 error_code="6";//修改密码失败！
			 }
		 }else {
			 error_code ="4";//手机验证码输入错误
		 }
		 JSONObject json = new JSONObject();
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 绑定手机号
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/bindUserPhone",method=RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>bindUserPhone(HttpServletRequest request) throws Exception{
		 JSONObject json = new JSONObject();
		 String error_code="";
		 String token = request.getParameter("token")==null?"":request.getParameter("token").replace(' ', '+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 int days = daysOfTwo_1(uid,token);
		
		 int count=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			String telePhone = request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			if(!telePhone.equals("")) {
				String  userStatus = APPDao.selectUserStatus(telePhone);
				if(userStatus.equals("2")) {
					count = APPDao.bindUserPhone(uid, telePhone);
					error_code="000000";
				}else {
					String sql = " UPDATE t_user_request SET userPhone ='"+telePhone+"' WHERE userId = "+uid;
					count =Sqlca.updateObject(sql, new String[] {});
					error_code="000000";
				}
			}
		 }
		 json.put("count", count);
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 
	
	 /**
	   *  	用户登录
	   * @param request
	   * @return
	   * @throws Exception 
	  */
	 @RequestMapping(value="/userLogin",method=RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>userLogin(HttpServletRequest request) throws Exception{
		 String error_code ="";
		 String type = request.getParameter("type");
		 String userPassword = request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
		 String userName="";
		 String telePhone="";
		 String token ="";
		 String userStatus="0";
		 
		 TUser tUser = new TUser();
		 if(type.equals("1")) {//账号登录
			 userName = request.getParameter("userName")==null?"0":request.getParameter("userName");
			 tUser.setUserName(userName);
			 userStatus ="2";
			 tUser.setType("1");
		 }else if(type.equals("2")) {
			 telePhone = request.getParameter("telePhone")==null?"0":request.getParameter("telePhone");
			 tUser.setUserPhone(telePhone);
			 userStatus = APPDao.selectUserStatus(telePhone)==null?"0":APPDao.selectUserStatus(telePhone);
			 tUser.setUserStatus(Integer.parseInt(userStatus));
			 tUser.setType("2");
		 }else {
			 userName = request.getParameter("userName")==null?"0":request.getParameter("userName");
			 boolean flag  = isPhone(userName);
			 if(flag) {
				 userStatus = APPDao.selectUserStatus(userName)==null?"0":APPDao.selectUserStatus(userName);
				 tUser.setUserStatus(Integer.parseInt(userStatus));
				 tUser.setType("2");
				 tUser.setUserPhone(userName);
			 }else {
				 tUser.setUserName(userName);
				 userStatus ="2";
				 tUser.setType("1");
			 }
		 }
		 
		 JSONObject jsonStr = new JSONObject();
		 JSONObject json = new JSONObject();
		 tUser.setUserPassword(userPassword);
		 String userId ="";
		 
		 if(userStatus.equals("2")) {
			 userId = APPDao.userLogin(tUser)==null?"0":APPDao.userLogin(tUser);
			 tUser.setTokenType("1");
		 }else {
			 userId = APPDao.newUserLogin(tUser, type)==null?"0":APPDao.newUserLogin(tUser, type);
			 tUser.setTokenType("0");
			 if(Integer.parseInt(userId)<1) {
				 error_code="8";//手机号或密码错误！
			 }else {
				 error_code="000000";
			 }
		 }
		 
		 if(userId.equals("0") && type.equals("1")) {
			 error_code="7";//用户名或密码错误！
		 }else if(userId.equals("0") && type.equals("2")) {
			 error_code="8";//手机号或密码错误！
		 }else if(userId.equals("0") && type.equals("3")&&tUser.getType().equals("1")){
			 error_code="7";//用户名或密码错误！
		 }else if(userId.equals("0") && type.equals("3")&&tUser.getType().equals("2")){
			 error_code="8";//手机号或密码错误！
		 }else
		 {
			 token = TokenProccessor.getInstance().makeToken();//创建令牌
			 error_code ="000000";
			 json.put("uid", userId);
			 json.put("token", token);
			 tUser.setUserId(Integer.parseInt(userId));
			 tUser.setToken(token);
			 int count =  APPDao.selectUserCount(tUser);
			 if(count>0) {
				 APPDao.updateUserToken(tUser);
			 }else {
				 APPDao.addTokenToUserId(tUser);
			 }
		 }
		 jsonStr.put("result",json);
		 jsonStr.put("error_code", error_code);
		 return jsonStr;
	 }
	
	 /**
	  * 判断本次操作距离上次多少天
	  * @param loginTime
	 * @throws Exception 
	  */
	 public int daysOfTwo_1(String uid,String token) throws Exception {
		 String upperTime = APPDao.selectUserTime(uid,token)==null?"":APPDao.selectUserTime(uid,token);
		 int days=0;
		 if(upperTime.equals("")) {
			 days=7;
		 }else {
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
			 String date = sdf.format(new Date());
			 Date fDate=sdf.parse(date);
			 Date oDate=sdf.parse(upperTime);
			 Calendar aCalendar = Calendar.getInstance();
			 aCalendar.setTime(fDate);
			 int day1 = aCalendar.get(Calendar.DAY_OF_YEAR);
			 aCalendar.setTime(oDate);
			 int day2 = aCalendar.get(Calendar.DAY_OF_YEAR);
			 days=day1-day2;
		 }
	        return days;
	    }
	 
	 
	 /**
	  *     查询用户自己的信息
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/selectUserInfo",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectUserInfo(HttpServletRequest request,TUser user) throws Exception{
		
		 JSONObject json = new JSONObject();
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ', '+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 user.setUserId(Integer.parseInt(uid));
		 TUser tUser = new TUser();
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 //String www = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort();
			 String useStatus = APPDao.selectUserTokenType(user)==null?"0":APPDao.selectUserTokenType(user);
			 if(useStatus.equals("1")) {
				 tUser = APPDao.selectUserInfo(uid, token);
				 String appDomain =APPDao.selectAppDomain();
				 tUser.setAppDomain(appDomain);
				 String headImage =tUser.getLogo()==null?"":tUser.getLogo();
				 if(headImage.equals("")) {
					 tUser.setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
				 }else {
					 tUser.setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
				 }
			 }else {
				 tUser =APPDao.selectNewUserInfo(Integer.parseInt(uid));
				 String appDomain =APPDao.selectAppDomain()==null?"":APPDao.selectAppDomain();
				 tUser.setAppDomain(appDomain);
				 
				 String headImage =tUser.getLogo()==null?"":tUser.getLogo();
				 if(headImage.equals("")) {
					 tUser.setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
				 }else {
					 tUser.setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
				 }
			 }
			 error_code="000000";
			 json.put("result", tUser);
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 /**
	  *   	修改用户信息
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/editUser",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object> editUser(HttpServletRequest request,TUser tUser)throws Exception{
		 String error_code ="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ', '+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 int days = daysOfTwo_1(String.valueOf(uid),tUser.getToken().replace(' ', '+'));
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 TUser user = APPDao.selectNewUserInfo(Integer.parseInt(uid)); 
			 int userStatus = user.getUserStatus()==null?0:user.getUserStatus();
			 if(userStatus==2) {
				 APPDao.updateUserInfo(tUser);
			 }else {
				 APPDao.updateNewDisplayName(tUser.getDisplayName(),Integer.parseInt(uid));
			 }
			 error_code="000000";
		 }
		 JSONObject json = new JSONObject();
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  *  	删除用户
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/delUser",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>delUser(HttpServletRequest request,TUser tUser)throws Exception{
		 String error_code ="";
		 String uid = request.getParameter("uid").replace(' ', '+')==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
		 int count =0;
		 
		 int days = daysOfTwo_1(String.valueOf(uid),tUser.getToken().replace(' ', '+'));
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 JSONArray jsonArr = JSONArray.parseArray(userIds); 
				for (Object userId : jsonArr) {
					int ids = Integer.parseInt(userId.toString());
					count = APPDao.delUser(ids);
				} 
		 	}
		 if(count>0) {
			 error_code="000000";
		 }else {
			 error_code="-1";//删除用户失败！
		 }
		 JSONObject json = new JSONObject();
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  *  	创建组织----(创建企业)
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/addCustomer",method=RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>addCustomer(HttpServletRequest request,TUser tUsers)throws Exception{
		 String error_code ="";
		 
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ', '+');
		 tUsers.setToken(token);
		 int uid = Integer.parseInt(request.getParameter("uid"));
		 int days = daysOfTwo_1(String.valueOf(uid),token);
		 int usesId=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 String belongAgent ="深圳华望技术有限公司";
			 TUser tUser = APPDao.selectNewUserInfo(uid);
			 tUser.setCompTrueName(tUsers.getCompTrueName());
			 tUser.setUserName("hw"+tUser.getUserPhone());
			 tUser.setBelongAgent(belongAgent);
			 String flag =  APPDao.selectCustomerCount(tUser.getUserName())==null?"":APPDao.selectCustomerCount(tUser.getUserName());//查询用户账号是否已存在
			 if(flag.equals("")) {
				 
				 APPDao.addCustomer(tUser);
				 String compIds = APPDao.selectCustomerCount(tUser.getUserName());
				 tUser.setCompId(Integer.parseInt(compIds));
				 String otid = Sqlca.getString("select otid from t_operation_activity where type=1 and CURRENT_DATE BETWEEN startTime and endTime and action=1 and isuse=1");
				 String oaCode = Sqlca.getString("select oaCode from t_operation_activity where type=1 and CURRENT_DATE BETWEEN startTime and endTime and action=1 and isuse=1");
				 
				 ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap("select freeProduct,freeMinute,freeTime,freeTimeUnit from t_operation_template where spid='"+otid+"'");
				 if(mm.size()>0)
				 {
					 String freeProduct = (String)mm.get(0).get("freeProduct");
					 String freeMinute = (String)mm.get(0).get("freeMinute");
					 
					 
					 String insertOrder="insert into t_timeorder(o_Type,o_MaxUserCount,o_Product,o_Status,o_AdminID,"
								+ " o_CreateTime,o_CreateUser,o_CompID,o_CompName,o_sellType,o_amount,createtype,oaid,spid,o_totalTime,o_Style)"
								+ " values(? ,? ,? ,? ,? ,? ,? ,? ,?,?,?,?,?,?,?,?)";
					Sqlca.updateObject(insertOrder, new String[] {"5","99999",freeProduct,"1","admin","","admin",compIds,tUsers.getCompTrueName(),"1","0","1",oaCode,"",freeMinute,"2"});
					
					String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+compIds+" and productId="+freeProduct);
					if(exsits==null)
					{
						Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+compIds+","+freeProduct+",0,2)", new String[] {});
					}
					 Sqlca.updateObject("update t_compinfo set productID='"+freeProduct+"',TolTimes='"+freeMinute+"',sellType=1,MaxUserCount=99999 where CompID=?", new String[] {compIds});
				 }
				 Sqlca.updateObject("update t_compinfo set sellType=1 where CompID=?", new String[] {compIds});
 
				 APPDao.addUser(tUser);
				 usesId = APPDao.selectUserId(tUser);
				 APPDao.updateNewUserStatus(String.valueOf(tUser.getUserId()), 2,Integer.parseInt(compIds)); 
				 tUser.setUserId(usesId);
				 tUser.setToken(token);
				 APPDao.updateTokenToUserId(tUser);
				 String ss = " UPDATE t_user_request SET userId ="+usesId+" WHERE userPhone = '"+tUser.getUserPhone()+"'";
				 Sqlca.updateObject(ss, new String[] {});
				 error_code="000000";
			 }else {
				 error_code ="12";//企业已存在！
			 	}
		 }
		 
		 JSONObject str = new JSONObject();
		 str.put("userId", usesId);
		 json.put("result",str);
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  *	  加入组织
	  * @param request
	  * @param tUsers
	  * @return
	 * @throws Exception 
	  */
	@SuppressWarnings("unlikely-arg-type")
	@RequestMapping(value="/joinOrgan", method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>joinOrgan(HttpServletRequest request,TUser tUser) throws Exception{
		JSONObject json = new JSONObject();
		String error_code ="";
		int uid = Integer.parseInt(request.getParameter("uid"));
		tUser.setUserId(uid);
		String token = request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		
		TUser user = APPDao.selectUserToOragn(tUser);
		if(null ==user) {
			error_code="13";
		}else {
			if(null!=user.getCompId()&&user.getUserStatus().equals("2")) {
				error_code ="14";//该用户已加入企业组织
			}else {
				int compId = tUser.getCompId();
				int count = APPDao.selectCompIdCount(compId);
				if(count<1) {
					error_code ="13";//输入的企业id不存在
				}else {
					tUser.setUserName("hw"+tUser.getUserPhone());
					tUser.setCompId(compId);
					tUser.setUserStatus(1);
					APPDao.updateUserStatus(tUser);
					error_code="000000";
				}
			}
		}
		json.put("error_code", error_code);
		return json;
	}
	
	/**
	 *   修改企业信息
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editCustomer",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>editCustomer(HttpServletRequest request,TUser tUser) throws Exception{
		String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		String token = request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		String lianxrtel = request.getParameter("lianxrtel");
		String mail = request.getParameter("mail");
		
		tUser.setUserMail(mail);
		tUser.setUserPhone(lianxrtel);
		tUser.setUserId(Integer.parseInt(uid));
		String error_code ="";
		String message ="";
		JSONObject json = new JSONObject();
		JSONObject str = new JSONObject();
		int compids = APPDao.selectCompId(tUser);
		tUser.setCompId(compids);
		
		if(tUser!=null) {
			int compId = APPDao.selectCertToCustomer(uid, token)==null?0:APPDao.selectCertToCustomer(uid, token);
			int count=0;
			if(compId>0) {
				count =APPDao.editCustomer(tUser);
			}else {
				APPDao.addCertCustomerInfo(tUser);
				count =APPDao.editCustomer(tUser);
			}
			error_code="000000";
			message ="Request successful";
			str.put("count", count);
		} 
		json.put("result", str);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
		
	}
	
	
	/**
	 * 	 文件上传
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/mutlUploadFile", method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object>mutlUploadFile(HttpServletRequest request,TUser tUser) throws Exception{

		 String error_code ="";
		 String token =  request.getParameter("token").replace(' ','+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid =  request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 int type = Integer.parseInt(request.getParameter("type"));	//1：营业执照
		 
		 int days = daysOfTwo_1(uid, token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			long  startTime=System.currentTimeMillis();// //将当前上下文初始化给  CommonsMutipartResolver （多部分解析器）
	        CommonsMultipartResolver multipartResolver=new CommonsMultipartResolver(request.getSession().getServletContext());////检查form中是否有enctype="multipart/form-data"
	       
	      if(multipartResolver.isMultipart(request))
	      {
	           MultipartHttpServletRequest multiRequest=(MultipartHttpServletRequest)request; //将request变成多部分request
	           Iterator iter=multiRequest.getFileNames();//获取multiRequest 中所有的文件名
	           String path ="";
	           String fileName ="";
	           int compId =0;
	           while(iter.hasNext())
	           {
	               //一次遍历所有文件
	               MultipartFile file=multiRequest.getFile(iter.next().toString());
	               if(file!=null)
	               { 
	            	  compId = APPDao.selectCertToCustomer(uid, token)==null?0:APPDao.selectCertToCustomer(uid, token);
	            	  String userStatus = APPDao.selectNewUserStatus(uid)==null?"0":APPDao.selectNewUserStatus(uid);
	            	  
	            	  String realPath="";
	                   if(type==1) {
	                	   realPath = request.getRealPath("images/business");
	                	   String filename =file.getOriginalFilename();
	                	   String fileName1 = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
	                	   String real  =new Date().getTime()+"."+fileName1;
	                	   path=realPath+"/"+real;
	                	   if(compId>0) {
	                		   tUser.setBusiness(real);
	                		   tUser.setCompId(compId);
	                		   APPDao.updateCustomerLicense(tUser);
	                		   error_code="000000";
	                	   }else {
	                		   compId=APPDao.selectCompId(tUser);
	                		   error_code="000000";
	                		   tUser.setBusiness(real);
	                		   tUser.setCompId(compId);
	                		   APPDao.addCertCustomerInfo(tUser);
	                	   }
	                	   String up ="UPDATE t_compinfo tc SET tc.IsVerified ='0' WHERE tc.CompID = "+compId+"";
	                	   Sqlca.updateObject(up, new String[] {});
	                   }else if(type==2) {
	                	   realPath = request.getRealPath("images/compHead");
	                	   path=realPath+"/"+new Date().getTime()+file.getOriginalFilename();
	                	   String filename = new Date().getTime()+file.getOriginalFilename();
	                	   APPDao.updateCustomCompHead(filename, compId);
	                	   error_code="000000";
	                   }else {
	                	   realPath = request.getRealPath("images/userHead");
	                	   path=realPath+"/"+new Date().getTime()+file.getOriginalFilename();
	                	   tUser.setHeadImagePath(new Date().getTime()+file.getOriginalFilename());
	                	   if(userStatus.equals("2")) {
	                		   APPDao.updateUserHeadImage(tUser);
	                	   }else {
	                		   APPDao.updateNewUserHeadImage(tUser);
	                	   }
	                	   error_code="000000";
	                   }
	                   		//上传
	                   		file.transferTo(new File(path));
	               		}
	           		}
	       		}
	       long  endTime=System.currentTimeMillis();
	       System.out.println("方法三的运行时间："+String.valueOf(endTime-startTime)+"ms");
		 }
		JSONObject json = new JSONObject();
        json.put("error_code",error_code);
		return json;
	}
	
	 
	
	/**
	 *     查询新用户列表
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectNewsUser",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectNewsUser(HttpServletRequest request,TUser tUser) throws Exception{
		
		String error_code ="";
		String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		tUser.setUserId(Integer.parseInt(uid));
		String token = request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		List<TUser>userList = APPDao.selectNewUserList(tUser);
			for (TUser tUser2 : userList) {
				String headImage =tUser2.getLogo()==null?"":tUser2.getLogo();
				if(headImage.equals("")) {
					tUser2.setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
				}else {
					tUser2.setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
				}
			}
		error_code="000000";
		JSONObject json = new JSONObject();
		json.put("result", userList);
		json.put("error_code", error_code);
		return json;
	}


	/**
	 * 	  审核新用户
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/examineUser",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>examineUser(HttpServletRequest request,TUser tUsers) throws Exception{
		String token = request.getParameter("token").replace(' ','+');
		tUsers.setToken(token);
		String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		tUsers.setUserId(Integer.parseInt(uid));
		String error_code="";
		JSONArray jsonArrary = new JSONArray();
		JSONObject arr = new JSONObject();
		int isSuper = APPDao.selectUserIsSuper(tUsers);
		
		if(isSuper>0) {
			String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
			StringBuffer dd = new StringBuffer();
			String sss ="";
			JSONArray jsonArr = JSONArray.parseArray(userIds); 
			for (Object ss : jsonArr) {
				dd.append(ss).append(",");
			}
			if(dd.length()>0) {
				sss = dd.toString().substring(0, dd.toString().length()-1);
			}else {
				sss="0";
			}
			int userId =0;
			String selSa = "SELECT userId,displayName,userPassword,userPhone,userStatus FROM t_user_request WHERE userId in("+sss.toString()+")";
			List<Object> obj = Sqlca.getArrayListFromObj(selSa, TUser.class);
			String up ="UPDATE t_user_request SET userStatus = 2  WHERE userId in ("+sss.toString()+")";
			Sqlca.updateObject(up,  new String[] {});
			String up1 ="UPDATE t_user_token SET tokenType= 1 WHERE userId in("+sss.toString()+")";
			Sqlca.updateObject(up1,  new String[] {});
			
			for (Object tUserObj : obj) { 
				int compId =APPDao.selectCompId(tUsers);
				String dpId = request.getParameter("dpId")==null?"1":request.getParameter("dpId");
				TUser tUser = new TUser();
				tUser.setCompId(compId);
				tUser.setDpId(Integer.parseInt(dpId));
				tUser.setUserName("hw"+((TUser) tUserObj).getUserPhone());
				tUser.setUserPhone(((TUser) tUserObj).getUserName());
				tUser.setUserPassword(((TUser) tUserObj).getUserPassword());
				tUser.setDisplayName(((TUser) tUserObj).getDisplayName());
				int userIdss = APPDao.selectUserId(tUsers)==null?0:APPDao.selectUserId(tUsers);
				if(userIdss<1) {
					APPDao.addUserToUserInfo(tUser);
				}
				userId = APPDao.selectUserId(tUser);
				tUser.setUserId(userId); 
				error_code ="000000";
				jsonArrary.add(tUser);
				error_code="000000";//
			}
		}else {
			error_code="18";
		}
		arr.put("result", jsonArrary);
		arr.put("error_code", error_code);
		arr.put("message", "Request successful");
		return arr;
	}
	
	
	/**
	 *	 拒绝用户加入
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/refuseUserAdd",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>refuseUserAdd(HttpServletRequest request,TUser tUser) throws Exception{
		String error_code ="";
		
		String token = request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
		JSONObject json = new JSONObject();
		 
		StringBuffer dd = new StringBuffer();
		String ss ="";
		JSONArray jsonArr = JSONArray.parseArray(userIds); 
		
		for (Object object : jsonArr) {
			dd.append(object).append(",");
		} 
		if(dd.length()>0) {
			ss = dd.toString().substring(0, dd.toString().length()-1);
		}else {
			ss="0";
		} 
		if(dd.length()>0) {
			ss = dd.toString().substring(0, dd.toString().length()-1);
		}else {
			ss="0";
		}
		int status =3;
		String sql ="UPDATE t_user_request SET userStatus = "+status+"  WHERE userId in ("+ss+")";
		int count = Sqlca.updateObject(sql, new String[] {});
		if(count>0) {
			error_code ="000000";
			json.put("count", count);
		}else {
			error_code="000000";
			json.put("count", count);
		}
		json.put("error_code", error_code);
		return json;
	}
	
	/**
	 *  	用户放弃申请
	 * @param request
	 * @param tUser
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/userApplyCancel",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>userApplyCancel(HttpServletRequest request,TUser tUser) throws Exception{
		String error_code ="";
		String uid = request.getParameter("uid").replace(' ', '+')==null?"":request.getParameter("uid").replace(' ', '+');
		String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		
		JSONObject json = new JSONObject();
		String msg ="";
		int days = daysOfTwo_1(uid,tUser.getToken());
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 APPDao.updateNewUserStatus(uid, 0,0);
			 error_code="000000";
			 msg="Request successful";
		 }
		json.put("error_code", error_code);
		json.put("msg",msg);
		return json;
	}
	
	
	/**
	 * 	查询企业部门
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectCustomerDeptMent",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectCustomerDeptMent(HttpServletRequest request,TUser tUser) throws Exception{
		String error_code ="";
		String uid = request.getParameter("uid").replace(' ', '+')==null?"":request.getParameter("uid").replace(' ', '+');
		tUser.setUserId(Integer.parseInt(uid));
		String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		tUser.setToken(token);
		List<TDepatMentVo> deptVoList =APPDao.selectCustomerDeptMent(tUser);
		if(deptVoList.size()>0) {
			error_code ="000000";
		}else {
			error_code="000000";//error_code ="16";企业部门为空！
		}
		JSONObject json = new JSONObject();
		json.put("error_code", error_code);
		json.put("result", deptVoList);
		return json;
	}
	
	/**
	 *	 查询父部门下子部门
	 * @param request
	 * @param tUser
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectParentDeptToDept",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectParentDeptToDept(HttpServletRequest request,TDepatMentVo depatMentVo) throws Exception{
		
		 JSONObject json = new JSONObject();
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 List<TDepatMentVo> sonDeptVo =new ArrayList<>();
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			sonDeptVo = APPDao.selectParentDeptToDept(depatMentVo);
			error_code ="000000";
			//error_code ="17";//父部门下没有子部门！
		 }
	 
		json.put("error_code", error_code);
		json.put("result", sonDeptVo);
		return json;
	}
	
	/**
	 * 	查询部门用户
	 * @param request
	 * @param depatMentVo
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping(value="/selectDeptToUser",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectDeptToUser(HttpServletRequest request,TDepatMentVo depatMentVo) throws Exception{
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 List<TUser> sonDeptVo =new ArrayList<>();
		 String userName = request.getParameter("userName")==null?"":request.getParameter("userName");
		 
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 if(null != userName) {
				 depatMentVo.setDpName(userName);
				 sonDeptVo = APPDao.selectDeptToUser(depatMentVo);
				 for (TUser tUser : sonDeptVo) {
					tUser.setLogo(tUser.getLogo()==null?"http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg":tUser.getLogo());
				}
				 error_code ="000000";
			 }
			/*if(sonDeptVo.size()>0) {
			}else {
				error_code ="17";//父部门下没有子部门！
			}*/
		 }
		json.put("error_code", error_code);
		json.put("result", sonDeptVo);
		return json;
	}
	
	
	/**
	 * 查询部门所有用户
	 * @param request
	 * @param depatMentVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectDeptAllUser",method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectDeptAllUser(HttpServletRequest request,TUser tUser) throws Exception{
		 String error_code ="";
		 String message="";
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 String i = request.getParameter("i")==null?"1":request.getParameter("i");
		 String rows = request.getParameter("rows")==null?"1":request.getParameter("rows");
		 int ii = (Integer.parseInt(i)-1)*Integer.parseInt(rows);	
		 
		 List<TDepatMentVo> deptVoList =APPDao.selectCustomerDeptMent(tUser);
		 StringBuffer dd = new StringBuffer();
		 String	ss ="";
		 for (TDepatMentVo tDepatMentVo : deptVoList) {
			 String dpId = tDepatMentVo.getDpId();
			 dd.append(dpId).append(",");
		 }
		 if(dd.length()>0) {
			 ss = dd.toString()+"1";
		 }else {
			 ss="1";
		 }
		 int compId = APPDao.selectCompId(tUser);
		 String selectAll =" SELECT DpId AS dpId,CompID as compId,TelePhone AS userPhone,UserID AS userId,UserName AS userName,DisplayName AS disPlayName,TelePhone AS telePhone,IsSuper AS isSuper,logo FROM t_userinfo"
		 		+ " WHERE compId = "+compId+" AND DpId in("+ss+")";
		 selectAll+=" limit "+ii+","+rows ;
		 List<Object> obj = Sqlca.getArrayListFromObj(selectAll, TUser.class);
		
		 error_code="000000";
		 for (Object tUsers : obj) { 
			 String headImage =((TUser) tUsers).getLogo()==null?"":((TUser) tUsers).getLogo();
			 if(headImage.equals("")) {
				 ((TUser) tUsers).setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
			 }else {
				 ((TUser) tUsers).setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
			 }
			}
		 message="Request successful";	  
		 json.put("result", obj);
		 json.put("error_code", error_code);
		 json.put("message", message);		 
		 return json;
	}
	
	
	
	
	
	/**
	 * 	查询组织架构列表
	 * @param request
	 * @param tUser
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectOrganList",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object>selectOrganList(HttpServletRequest request,TDepatMentVo depatMentVo,TUser tUser)throws Exception{
		 String error_code="";
		
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 //参数 父部门id 企业id
		 JSONObject json = new JSONObject(); 
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
				error_code="000000";
			 	json.put("msg", "Request successful");
			 	json.put("error_code", error_code);
			 	
			 	//查询父部门下子部门
			 	List<TDepatMentVo>dpList =  APPDao.selectParentDeptToDept(depatMentVo);
				List<TUser> tUserList =new ArrayList<>();
				int compId = APPDao.selectCompId(tUser);
				depatMentVo.setCompId(String.valueOf(compId));
				if(dpList.size()>0) {
					
					depatMentVo.setDpId("1");
					tUserList =  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
					json.put("1",tUserList);
					
					for (TDepatMentVo tDepatMentVo : dpList) {
						String dpId =tDepatMentVo.getDpId();
						depatMentVo.setDpId(dpId);
						tUserList=  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
						json.put(dpId, tUserList);
						
						List<TDepatMentVo>dpList1 =  APPDao.selectParentDeptToDept(depatMentVo);
						for (TDepatMentVo tDepatMentVo1 : dpList1) {
							String dpId1 =tDepatMentVo1.getDpId();
							tDepatMentVo1.setDpId(dpId1);
							tUserList=  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
							json.put(dpId, tUserList);
					
							List<TDepatMentVo>dpList2 =  APPDao.selectParentDeptToDept(depatMentVo);
							for (TDepatMentVo tDepatMentVo2 : dpList2) {
								String dpId2 =tDepatMentVo2.getDpId();
								tDepatMentVo2.setDpId(dpId2);
								tUserList =  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
								json.put(dpId, tUserList);
								List<TDepatMentVo>dpList3 =  APPDao.selectParentDeptToDept(depatMentVo);
								for (TDepatMentVo tDepatMentVo3 : dpList3) {
									String dpId3 =tDepatMentVo3.getDpId();
									tDepatMentVo2.setDpId(dpId3);
									tUserList =  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
									json.put(dpId, tUserList);
								}
							}
						}
					} 
				}else {
					List<TUser> tUserList1 =  APPDao.selectDeptToUser(depatMentVo);//查询部门用户
					json.put("tUserList", tUserList1);
				}
			 }
			
		 	return json;
	}
	
	
	
	
	 /**
	  *  	查询企业信息
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/selectCustomInfo",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectCustomInfo(HttpServletRequest request,TUser tUser) throws Exception{
		 JSONObject json = new JSONObject();
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"0":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 TCompinfoVo compInfoVo = new TCompinfoVo();
		 
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 	String sql ="SELECT userStatus FROM t_user_request WHERE userId = "+uid;
			 	String stauts = Sqlca.getString(sql)==null?"0":Sqlca.getString(sql);
			 	
			 	if(stauts.equals("2")) {
			 		compInfoVo = APPDao.selectCustomInfo(tUser);
			 		compInfoVo.setAuthStatus(compInfoVo.getAuthStatus()==null?0:compInfoVo.getAuthStatus());
			 		String headImage =compInfoVo.getHeadImagePath()==null?"":compInfoVo.getHeadImagePath();
			 		String businessLicense = compInfoVo.getBusinessLicense()==null?"":compInfoVo.getBusinessLicense();
			 		
			 		if(businessLicense.equals("")) {
			 			compInfoVo.setBusinessLicense("http://testvip.hwactive.com/images/business/am_admin@3x.png");
			 		}else {
			 			compInfoVo.setBusinessLicense("http://192.168.35.111:8080/vip/images/business/"+businessLicense);
			 		}
			 		if(headImage.equals("")) {
			 			compInfoVo.setHeadImagePath("http://testvip.hwactive.com/images/compHead/am_admin@3x.png");
			 		}else {
			 			compInfoVo.setHeadImagePath("http://192.168.35.111:8080/vip/images/compHead/"+headImage);
			 		}
			 	}else { 
				 	compInfoVo = APPDao.selectCustomInfoByNewUser(tUser);
			 	}
				 int ti = getCompInfoPerce(compInfoVo);
				 if(ti==96) {
					 ti=100;
				 }
				 compInfoVo.setCompInfoPerce(ti+"%");
				 error_code="000000";
				 json.put("result", compInfoVo);
		 	}
		 
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 public int getCompInfoPerce(TCompinfoVo compInfoVo) {
		 
		 String compTrueName = compInfoVo.getCompTrueName()==null?"0":"12";
		 String lianxrtel  =compInfoVo.getLianxrtel()==null?"0":"12";
		 String headImage = compInfoVo.getHeadImagePath()==null?"0":"12";
		 String address =compInfoVo.getAddress()==null?"0":"12";
		 String taxNuber = compInfoVo.getTaxNumber()==null?"0":"12";
		 String mail =compInfoVo.getMail()==null?"0":"12";
		 String invoiceTitle = compInfoVo.getInvoiceTitle()==null?"0":"12";
		 String businss =compInfoVo.getBusinessLicense()==null?"0":"12";
		 int total = 0;

		 total +=Integer.parseInt(compTrueName)==0?0:12;
		 total +=Integer.parseInt(lianxrtel)==0?0:12;
		 total +=Integer.parseInt(headImage)==0?0:12;
		 total +=Integer.parseInt(address)==0?0:12;
		 total +=Integer.parseInt(taxNuber)==0?0:12;
		 total +=Integer.parseInt(mail)==0?0:12;
		 total +=Integer.parseInt(invoiceTitle)==0?0:12;
		 total +=Integer.parseInt(businss)==0?0:12;
		 return total;
	 }
	 
	 
	 /**
	  *  	企业管理员列表查询
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/selectIsSuperInfo",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectIsSuperInfo(HttpServletRequest request,TUser tUser) throws Exception{
		 JSONObject json = new JSONObject();
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 List<TUser> users = new ArrayList<>();
		 int days = daysOfTwo_1(uid,token);
		 
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			int flag = APPDao.selectUserIsSuper(tUser);
			if(flag>0) {
				users =  APPDao.selectIsSuperInfo(tUser);
				for (TUser tUser2 : users) {
					tUser2.setHeadImagePath(tUser2.getHeadImagePath()==null?"http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg":tUser2.getHeadImagePath());
				}
				if(users==null) {
					error_code="18";//非超级管理员操作！
				}else {
					error_code ="000000";
					json.put("result", users);
				}
			}else {
				error_code="18";//您不是超级管理员不能操作！
			}
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  *    	移除企业管理员
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/removeIsSuper",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>removeIsSuper(HttpServletRequest request,TUser tUser) throws Exception{
		 JSONObject json = new JSONObject();
		 JSONObject jsonStr = new JSONObject();
		 
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");//json串
		 int dpId = request.getParameter("dpId")==null?0:Integer.parseInt(request.getParameter("dpId"));
		 
		 int days = daysOfTwo_1(uid,token);
		 int count=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			int flag = APPDao.selectUserIsSuper(tUser);
			if(flag>0) {
				String isSuper =null; 
				count  =  APPDao.removeIsSuper(userIds,isSuper,dpId);
				jsonStr.put("count", count);
				json.put("result", jsonStr);
				error_code ="000000";
			}else {
				error_code="18";//您不是超级管理员不能操作！
			}
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 添加部门管理员
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/addUserToSuper",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>addUserToSuper(HttpServletRequest request,TUser tUser) throws Exception{
		 JSONObject json = new JSONObject();
		 JSONObject jsonStr = new JSONObject();
		 
		 String error_code="";
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");//json串
		 int dpId = request.getParameter("dpId")==null?0:Integer.parseInt(request.getParameter("dpId"));
		 
		 int days = daysOfTwo_1(uid,token);
		 int count=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			int flag = APPDao.selectUserIsSuper(tUser);
			if(flag>0) {
				count  =  APPDao.removeIsSuper(userIds,"2",dpId);
				jsonStr.put("count", count);
				json.put("result", jsonStr);
				error_code ="000000";
			}else {
				error_code="18";//您不是超级管理员不能操作！
			}
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 
	 /**
	  * 	新增部门
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/addDeptMent",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>addDeptMent(HttpServletRequest request,TUser tUser,TDepatMentVo deptMent) throws Exception{
		
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 //DpName,ParentDpId,CompId,AdminId
		 deptMent.setDpName(deptMent.getDpName());
		 deptMent.setParentDpId(deptMent.getParentDpId());
		 deptMent.setAdminId(deptMent.getParentDpId());
		 
		 int days = daysOfTwo_1(uid,tUser.getToken());
		 int count=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 int compId = APPDao.selectCompId(tUser);
			 deptMent.setCompId(String.valueOf(compId));
			 count = APPDao.addDeptMent(deptMent);
			 String dpIdsql= "SELECT DpId FROM t_department WHERE DpName ='"+deptMent.getDpName()+"' ";
			 String dpId =Sqlca.getString(dpIdsql);
			 deptMent.setDpId(dpId);
			 
			 json.put("result", deptMent);
			 error_code ="000000";
		 }
		 json.put("error_code", error_code);
		 json.put("message", "Request successful");
		 return json;
	 }
	 
	 /**
	  * 	修改企业部门信息
	  * @param request
	  * @param tUser
	  * @param deptMent
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/editDeptMent",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>editDeptMent(HttpServletRequest request,TUser tUser,TDepatMentVo deptMent) throws Exception{
		 
		 String error_code="";
		 JSONObject json = new JSONObject(); 
		 JSONObject jsonStr = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 String ParentDpId =request.getParameter("parentDpId")==null?"0":request.getParameter("parentDpId");
		 deptMent.setParentDpId(ParentDpId);
		 int days = daysOfTwo_1(uid,token);
		 int count=0;
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			count = APPDao.editDeptMent(deptMent);
			if(count>0) {
				error_code="000000";
				jsonStr.put("count", count);
				json.put("result", jsonStr);
			}else {
				error_code="-1";//系统出错
			}
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 	删除企业部门
	  * @param request
	  * @param tUser
	  * @param deptMent
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/delDeptMent",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>delDeptMent(HttpServletRequest request,TUser tUser,TDepatMentVo deptMent) throws Exception{
		 
		 String error_code="";
		 JSONObject json = new JSONObject(); 
		 JSONObject jsonStr = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		
		 int count =0;
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 int flag = APPDao.selectUserIsSuper(tUser);
			 if(flag>0) {
				 int t = APPDao.selectParentMent(deptMent);
				 int s =APPDao.selectDeptMent(deptMent);
				 if(t>0 ||s>0) {
					 error_code="19";//部门下还有其他用户
				 }else {
					 count = APPDao.delDeptMent(tUser);
					 jsonStr.put("count", count);
					 json.put("result", jsonStr);
					 error_code ="000000";
				 }
			 }else {
				 error_code="21";//您不是超级管理员不能操作！
			 }
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 	退出企业
	  * @param request
	  * @param tUser
	  * @return
	 * @throws Exception 
	  */
	 @RequestMapping(value="/signOut",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>signOut(HttpServletRequest request,TUser tUser) throws Exception{
		 String error_code="";
		 JSONObject json = new JSONObject();
		 JSONObject jsonStr = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 int count =0;
		 int days = daysOfTwo_1(uid,tUser.getToken());
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			count = APPDao.signOutOragan(tUser);
			if(count>0) {
				jsonStr.put("count", count);
				json.put("result", jsonStr);
				error_code ="000000";
			}else {
				error_code ="-1";//系统错误
			}
		 }
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 	更换用户部门
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/exchangeUserDpId",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>exchangeUserDpId(HttpServletRequest request,TUser tUser) throws Exception{
		 String error_code="";
		 JSONObject json = new JSONObject();
		 JSONObject jsonStr = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 int dpId = Integer.parseInt(request.getParameter("dpId")); 
		 String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
		 
		 int count =0;
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 JSONArray jsonArr = JSONArray.parseArray(userIds); 
				for (Object userId : jsonArr) {
					Integer dd = Integer.parseInt(userId.toString());
					APPDao.exchangeUserDpId(dpId, dd);
					count++;
				} 
			 if(count>0) {
					jsonStr.put("count", count);
					json.put("result", jsonStr);
					error_code ="000000";
				}else {
					error_code ="-1";//系统错误
				}
		 	}
		 	json.put("error_code", error_code);
		 return json;
	 }
	 
	 
	 /**
	  * 	查询通讯录中用户是否已存在
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @SuppressWarnings("unchecked")
	@RequestMapping(value="/selectPhoneToCustom",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectPhoneToCustom(HttpServletRequest request)throws Exception{
		 String error_code="";
		 JSONObject json = new JSONObject();
		 JSONObject arr = new JSONObject();
		 net.sf.json.JSONArray arrList = new net.sf.json.JSONArray();
		 
	 	 String userPhones = request.getParameter("userPhones")==null?"":request.getParameter("userPhones");
	 	 Integer count = 0; 
		 Integer status =0;
		 net.sf.json.JSONArray netArr =net.sf.json.JSONArray.fromObject(userPhones);
		 TUser tUser= new TUser();
		 List list = new ArrayList<>();
		 
		 if(netArr.size()>0) {
			for (Object phone : netArr) {
				String ttPhone = String.valueOf(phone);
				tUser.setUserPhone(ttPhone);
				count =  APPDao.selectPhoneToCustom(tUser);
				if(count>0) {//已经注册了
					status =1;
				}else {
					status = 0;
					error_code="000000";
				}
				json.put("userPhone", phone);
				json.put("status", status);
				arrList.add(json); 
			}
		 }else {
			 error_code="-1";
		 }
		 arr.put("result", arrList);
		 arr.put("error_code", error_code); 
		 return arr;
	 }
	  
	 /**
	  * 	 添加通讯录用户注册
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/addPhoneToCustom",method =RequestMethod.POST,produces ="application/json;utf-8")
	 @ResponseBody
	 public Map<String, Object>addPhoneToCustom(HttpServletRequest request,TUser tUser)throws Exception{
		 String error_code="";
		 JSONObject json = new JSONObject();
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 int compId = APPDao.selectCertToCustomer(uid,tUser.getToken());
	 	 String dpId =  request.getParameter("dpId")==null?"":request.getParameter("dpId");
	 	 String userPhones = request.getParameter("userPhones")==null?"":request.getParameter("userPhones");
	 	 String displayName = request.getParameter("displayName")==null?"":request.getParameter("displayName");
	 	 
	 	 int count =0;
	 	 JSONArray arr = JSONArray.parseArray(userPhones);
	 	 JSONArray arrName =  JSONArray.parseArray(displayName);
	 	  
	 	 if(arr.size()>0) {
	 		 for (Object arrList : arr) {
	 			 for (Object disName : arrName) {
	 				 tUser.setCompId(compId);
	 				 tUser.setDpId(Integer.parseInt(dpId));
	 				 tUser.setUserPhone(arrList.toString()+"");
	 				 tUser.setUserName("hw"+arrList.toString());
	 				 tUser.setUserPassword("123456");
	 				 tUser.setDisplayName(disName.toString());
	 				 APPDao.addPhoneToCustom(tUser);
	 				 error_code ="000000";
	 				 count++;
				}
	 		 }
	 	 }else {
	 		 count=0;
	 		 error_code ="-1";
	 	 }
	 	 json.put("personCount",count);
		 json.put("error_code", error_code);
		 return json;
	 }
	
	 /**
	  * 消息列表
	  * @param request
	  * @param tUser
	  * @return
	  */
	 @RequestMapping(value="/selectNewsList",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectNewsList(HttpServletRequest request,TUser tUser){
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 
		 
		 
		 
		 return json;
	 }
	 
	 /**
	  *  校验用户密码
	  * @param request
	  * @param tUser
	  * @return
	 * @throws Exception 
	  */
	 @RequestMapping(value="/validateUserPassword",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>validateUserPassword(HttpServletRequest request) throws Exception{
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 
		 int count =0;
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 String userPassword =request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
			 TUser tUser =APPDao.validateUserPassword(uid);
			 String password = tUser.getUserPassword()==null?"":tUser.getUserPassword();
			 if(userPassword.equals(password)) {
				 count = 1;
				 error_code="000000";
			 }else {
				 count=0;
			 }
		 }
		 json.put("count", count);
		 json.put("error_code", error_code);
		 return json;
	 }
	 /**
	  * 修改密码
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/updateUserPassword",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>updateUserPassword(HttpServletRequest request) throws Exception{
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 
		 int count =0;
		 int days = daysOfTwo_1(uid,token);
		 if(days>=7) {
			 error_code="-2";//token过期
		 }else {
			 String userPassword =request.getParameter("userPassword")==null?"":request.getParameter("userPassword");
			 String telePhone =request.getParameter("telePhone")==null?"":request.getParameter("telePhone");
			 String userStatus = APPDao.selectUserStatus(telePhone)==null?"0": APPDao.selectUserStatus(telePhone);
			 if(userStatus.equals("2")) {
				 count =APPDao.retrievePassword(telePhone, userPassword);
				 error_code="000000";
			 }else {
				 count =APPDao.updateUserPassword(telePhone, userPassword);
				 error_code="000000";
			 }
		 }
		 json.put("count", count);
		 json.put("error_code", error_code);
		 return json;
	 }
 
	 /**
	  * 	会议列表
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception   
	  */
	 @RequestMapping(value="/selectAttendMeetingUser",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectAttendMeetingUser(HttpServletRequest request,TUser tUser)throws Exception{
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 String isSuper = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);
		 int compId = APPDao.selectCompId(tUser)==null?0:APPDao.selectCompId(tUser);
		 String sql ="";
		 
		 if(isSuper.equals("1")) {
			 sql = "SELECT (select count(*) FROM t_confusers WHERE ConfID =t.ConfId)AS attendCount,t.AdminID AS adminID,t.BeginTime as beginTime,t.ChairPwd as chairPwd,t.ConfDesc as confDesc,t.ConfId as confId,t.ConfName as confName,t.ConfPwd as confPwd,t.CurUserCount as curUserCount,t.EndTime as endTime,t.IsOnOff as isOnOff, t.IsPublic as isPublic,"
			 		+ "t.IsReservedConf as isReservedConf,t.MaxUserCount as maxUserCount,t.OverTime as overTime,t.Plan as plan,(SELECT t1.ServerIP FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS  serverIp,"
			 		+ "(SELECT t1.ServerName FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS serverName,startTime FROM t_confinfo t WHERE t.CompID="+compId;
			 sql+=" ORDER BY t.ConfID DESC";
		 }else if(isSuper.equals("2")){
		 
			  String sqlD=" select DpId from t_userInfo where userId ="+uid; 
			  String dpId = Sqlca.getString(sqlD);//用户自己部门
			  String useDp ="SELECT DpId FROM t_department WHERE parentDpId =(SELECT DpId FROM t_userinfo WHERE UserID ="+uid+") AND CompID ="+compId;
			  List<Object> obj1 = Sqlca.getArrayListFromObj(useDp, TDepatMentVo.class);
			  StringBuffer dd = new StringBuffer(); String ss ="";
		  if(obj1.size()>0) {
			  for (Object userDpId : obj1) {
				  String sdpId =((TDepatMentVo)userDpId).getDpId();
				  dd.append(sdpId).append(",");
			  }
		  } 
		  if(dd.length()>0) {
				ss = dd.toString()+dpId;
			}else {
				ss=dpId;
		  } 
		  sql = "SELECT (select count(*) FROM t_confusers WHERE ConfID =t.ConfId)AS attendCount,t.AdminID AS adminID,t.BeginTime as beginTime,t.ChairPwd as chairPwd,t.ConfDesc as confDesc,t.ConfId as confId,t.ConfName as confName,t.ConfPwd as confPwd,t.CurUserCount as curUserCount,t.EndTime as endTime,t.IsOnOff as isOnOff, t.IsPublic as isPublic,"
			 		+ "t.IsReservedConf as isReservedConf,t.MaxUserCount as maxUserCount,t.OverTime as overTime,t.Plan as plan,(SELECT t1.ServerIP FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS  serverIp,"
			 		+ "(SELECT t1.ServerName FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS serverName,startTime FROM t_confinfo t WHERE "
		  		+ "AdminId in(SELECT UserID FROM t_userinfo WHERE DpID in("+ss+") AND IsSuper =2 AND CompID ="+compId+")";
		  sql+=" ORDER BY t.ConfID DESC"; 
		 }else {
			 sql = "SELECT (select count(*) FROM t_confusers WHERE ConfID =t.ConfId)AS attendCount,t.AdminID AS adminID,t.BeginTime as beginTime,t.ChairPwd as chairPwd,t.ConfDesc as confDesc,t.ConfId as confId,t.ConfName as confName,t.ConfPwd as confPwd,t.CurUserCount as curUserCount,t.EndTime as endTime,t.IsOnOff as isOnOff, t.IsPublic as isPublic,"
				 		+ "t.IsReservedConf as isReservedConf,t.MaxUserCount as maxUserCount,t.OverTime as overTime,t.Plan as plan,(SELECT t1.ServerIP FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS  serverIp,"
				 		+ "(SELECT t1.ServerName FROM t_serverinfo t1 WHERE t1.ServerId =t.ServerId)AS serverName,startTime FROM t_confusers t3 	"
					 + "LEFT JOIN t_confinfo t  ON t.ConfID = t3.ConfID  WHERE 1 = 1 and t.IsOnOff=1 and  t.CompID= "+compId+" "
					 		+ "and t3.UserID =(SELECT userId FROM t_user_token WHERE userId = "+tUser.getUserId()+" AND token = '"+tUser.getToken()+"')";
			 sql+=" ORDER BY t.ConfID DESC";
		 }
		 error_code="000000";
		 List<Object> obj = Sqlca.getArrayListFromObj(sql, TConfinfoVo.class);
		 json.put("result", obj);
		 json.put("error_code", error_code);
		 json.put("message", "Request successful");
		 return json;
	 }
	 
	 /**
	  * 	会议详情
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/meetingDetatil",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>meetingDetatil(HttpServletRequest request,TUser tUser)throws Exception{
		 
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 int confId = Integer.parseInt(request.getParameter("confId"));
		
		 TConfinfoVo tUserList =  APPDao.selectMeetingDetail(confId);
		 error_code="000000";
		 json.put("result", tUserList);
		 json.put("error_code", error_code);
		 return json;
	 }
	 
	 /**
	  * 	参会用户列表
	  * @param request
	  * @param tUser
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping(value="/selectAttendList",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>selectAttendList(HttpServletRequest request,TUser tUser)throws Exception{
		 
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 int confId = Integer.parseInt(request.getParameter("confId"));
		 int count =0;
		 List<TUser> tUserList =  APPDao.selectAttendList(confId);
			 for (TUser tUser2 : tUserList) {
				tUser2.setUserName(tUser2.getUserName()==null?"":tUser2.getUserName());
				tUser2.setDisplayName(tUser2.getDisplayName()==null?"":tUser2.getDisplayName());
				
				String userRight = tUser2.getUserRight();
				if(userRight.equals("主席")) {
					tUser2.setUserRight("1");
				}else {
					tUser2.setUserRight("2");
				}
				 String headImage =tUser.getLogo()==null?"":tUser.getLogo();
				 if(headImage.equals("")) {
					 tUser2.setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
				 }else {
					 tUser2.setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
				 } 
			}
		 error_code="000000";
		 json.put("result", tUserList);
		 json.put("error_code", error_code);
	 
		 return json;
	 }

		/**
		 * 比较开始结束时间先后
		 * @param DATE1
		 * @param DATE2
		 * @return
		 */
		public static int compare_date(String DATE1, String DATE2) {
	        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        try {
	            Date dt1 = df.parse(DATE1);
	            Date dt2 = df.parse(DATE2);
	            if (dt1.getTime() > dt2.getTime()) {
	                System.out.println("前面的小于后面");
	                return 1;
	            } else if (dt1.getTime() < dt2.getTime()) {
	                System.out.println("前面的大于后面");
	                return -1;
	            } else {
	                return 0;
	            }
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        }
	        return 0;
	    }
		
		 private static boolean isValidDate(String str) {
		        boolean convertSuccess = true;
		        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		        try {
		            format.setLenient(false);
		            format.parse(str);
		        } catch (ParseException e) {
		            convertSuccess = false;
		        }
		        return convertSuccess;
		    } 
	 
	 /**
	  * 	创建会议室
	  * @param request
	  * @return
	  */
	 @RequestMapping(value="/addMeeting",method =RequestMethod.POST)
	 @ResponseBody
	 public Map<String, Object>addMeeting(HttpServletRequest request,TUser tUser,TConfinfo tConfinfo)throws Exception{
		 
		 String message ="";
		 String error_code ="";
		 JSONObject json = new JSONObject();
		 String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		 tUser.setUserId(Integer.parseInt(uid));
		 String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
		 tUser.setToken(token);
		 
		 SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		 String date = df1.format(new Date());
		 String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
		 
		 String confSql= "select count(1) from t_confinfo where confName ='"+tConfinfo.getConfName()+"'";
		 String confCount =Sqlca.getString(confSql);//判断会议室是否重名
		 
		 if(isManager.equals("1") || isManager.equals("2")) {
			 int mcuIpId=0;int productId=0;int maxUserComp=0;
			 int compId = APPDao.selectCompId(tUser);
			 TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(compId);
			 if(compinfo!=null) {
				mcuIpId = Integer.parseInt(compinfo.getMcuIpId()); //服务器serverId
				productId = compinfo.getProductId()==null?0:compinfo.getProductId(); //产品id
				maxUserComp=compinfo.getMaxUserCount()==null?0:compinfo.getMaxUserCount();
			 }			
			 String StartTime = tConfinfo.getStartTime();
			 String EndTime = tConfinfo.getEndTime();
			 String ConfDesc = tConfinfo.getConfDesc();
			
			    int date1=0;
				boolean flag =false; 
				boolean flag1=false;
				boolean weekTime =false;
				String addmeetsql = "";
				
				if(tConfinfo.getIsReservedConf().equals("0")) {//长期
					date1=0;flag=true;weekTime=true;
					addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
							+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
							+ "(0,?,'"+tConfinfo.getConfPwd()+"','88888','"+maxUserComp+"',0,0,'',"+uid+",'"+tConfinfo.getIsPublic()+"','"+1+"','"+compId+"','123456','"+productId+"','"+mcuIpId+"',0,1,'"+tConfinfo.getConfDesc()+"')";
				}else if(tConfinfo.getIsReservedConf().equals("1")){//预约
					weekTime=true;
					flag = isValidDate(StartTime); 
					flag1 = isValidDate(EndTime); 
					if(flag == false || flag1==false) {
						flag =false;
					}
					addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,EndTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
							+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
							+ "(0,?,'"+tConfinfo.getConfPwd()+"','88888','"+maxUserComp+"',0,0,'','"+StartTime+"','"+EndTime+"',"+uid+",'"+tConfinfo.getIsPublic()+"','"+1+"','"+compId+"','"+tConfinfo.getChairPwd()+"','"+productId+"','"+mcuIpId+"','"+tConfinfo.getIsReservedConf()+"',1,'"+ConfDesc+"')";
					if(StartTime.equals("")||EndTime.equals("")) {
						date1=0;
					}else {
						date1 =compare_date(StartTime, EndTime);
					}
				}else if(tConfinfo.getIsReservedConf().equals("2")){ //周期
					date1=0;
					flag=true;
					String plan = tConfinfo.getPlan();
					String overTime = tConfinfo.getOverTime();
					String BeginTime = tConfinfo.getBeginTime();
				
					String Begin="";String over="";
					if(BeginTime.equals("")||BeginTime.equals(null) || overTime.equals("")||overTime.equals(null) ) {
						weekTime=false;
						message="时间格式错误";
					}else {
						Begin =BeginTime.substring(0, 2);
						over  =overTime.substring(0, 2);
						if(Begin.equals(over)) {
							Begin =BeginTime.substring(3, 5);
							over  =overTime.substring(3, 5);
						}
					}
					if(Integer.parseInt(Begin)>=Integer.parseInt(over)) {
						weekTime=false;
						message="时间格式错误";
					}else {
						weekTime=true;
						message="ok";
					}
					addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,plan,BeginTime,overTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
							+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
							+ "(0,?,'"+tConfinfo.getConfPwd()+"','88888','"+maxUserComp+"',0,0,'','"+plan+"','"+BeginTime+"','"+overTime+"',"+uid+",'"+tConfinfo.getIsPublic()+"','"+1+"','"+compId+"','"+tConfinfo.getChairPwd()+"','"+productId+"','"+mcuIpId+"','"+tConfinfo.getIsReservedConf()+"',1,'"+ConfDesc+"')";
				} else { //即时
					date1=0;
					flag=true;
					weekTime=true;
					addmeetsql = "INSERT INTO t_confinfo (Codeno,ConfName,ConfPwd,TelConfName,MaxUserCount,CurUserCount,ConfStatus,MCUIP,StartTime,AdminID,IsPublic,IsOnOff,CompID,ChairPwd,ProductType,"
							+ "ServerId,IsReservedConf,IsAll,ConfDesc)VALUES"
							+ "(0,?,'"+tConfinfo.getConfPwd()+"','88888','"+maxUserComp+"',0,0,'','"+date+"',"+uid+",'"+tConfinfo.getIsPublic()+"','"+1+"','"+compId+"','"+tConfinfo.getChairPwd()+"','"+productId+"','"+mcuIpId+"','"+tConfinfo.getIsReservedConf()+"',1,'"+ConfDesc+"')";
				}
				JSONObject jstr = new JSONObject();
			
				if(confCount.equals("1") ||date1==1 || flag==false ||weekTime==false) {
					if(confCount.equals("1")) {
						message="会议室名称已存在！";
						error_code="20"; 
					}else if(flag ==false || weekTime ==false) {
						message="时间格式错误！";
						error_code="21";
					}else if(date1==1) {
						message="预约会议开始时间不能大于结束时间！";
						error_code="22";
					}
					json.put("error_code", error_code);
				}else { 
					int confMeet = Sqlca.updateObject(addmeetsql, new String[] {tConfinfo.getConfName()});
					String confIds= Sqlca.getString(" SELECT ConfID FROM t_confinfo WHERE ConfName = '"+tConfinfo.getConfName()+"'");
					if(confMeet>0) {
							 message="Request successful";
							 error_code="000000";
							 jstr.put("confId", confIds);
						 }else {
							 error_code="-1";
						 }
						json.put("result", jstr);}
		 	
			 }else {
				error_code="18";
			}
			 json.put("error_code", error_code);
			 json.put("message", message);
			 return json;
	 	}
	  
	 
		/**
		 *  修改会议室信息
		 *  @param UserName 用户名
		  * @param UserPassword 密码
		  * @param ConfName 会议室名
		  * @param ConfPwd 会议密码
		  * @param maxUserCount 最大用户数
		  * @param chairPwd 主席密码
		  * @param isPublic 登录模式  呢称加密0  不加密1  账号2
		  * @param isReservedConf 会议类型  0 固定 1 预约
		  * @param startTime 开始时间
		  * @param endTime	 结束时间
		  * @param isOnOff  会议室状态 0、关闭 1、开启
		 *  @return
		 *  @throws Exception
		 */
		@RequestMapping(value="/editMeeting",method= RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>editMeeting(HttpServletRequest request,TUser tUser,TConfinfo tConfinfo) throws Exception{
			
			String StartTime = request.getParameter("startTime")==null?"":request.getParameter("startTime");
			String EndTime = request.getParameter("endTime")==null?"":request.getParameter("endTime");
			String plan = request.getParameter("plan")==null?"":request.getParameter("plan");
			String overTime = request.getParameter("OverTime")==null?"":request.getParameter("overTime");
			String BeginTime = request.getParameter("beginTime")==null?"":request.getParameter("beginTime");
			String ConfDesc =request.getParameter("confDesc")==null?"":request.getParameter("confDesc");
			ConfDesc =Sqlca.switchLatin1Encoding(ConfDesc);
			String error_code="";
			String message="";
			
			String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
			tUser.setUserId(Integer.parseInt(uid));
			String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			tUser.setToken(token);
			JSONObject json1 = new JSONObject();
			String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
			
			if(isManager.equals("1") || isManager.equals("2")) {
				int compId = APPDao.selectCompId(tUser);
				//String editSql = "SELECT count(1) from t_confinfo where ConfName ='"+tConfinfo.getConfName()+"' and ConfID <> "+tConfinfo.getConfId();
				//String sql =Sqlca.getString(editSql);
				int sql= APPDao.selectMeetingIsReName(tConfinfo);
				String editMeetSql = "";
				  
				int mcuIpId=0;
				int productId=0;
				int maxUserComp=0;
				TCompinfo compinfo= meetingRoomDao.selectMaxUserCount(compId);
				if(compinfo!=null) {
					mcuIpId = Integer.parseInt(compinfo.getMcuIpId()); //服务器serverId
					productId = compinfo.getProductId(); //产品id
					maxUserComp=compinfo.getMaxUserCount();
				} 
				int date1=0;
				if(tConfinfo.getIsReservedConf().equals("1")) {
					date1 =compare_date(StartTime, EndTime);
				}
				if(sql>0 ||date1==1) {
					if(sql>0) {
						message="修改会议室重名！";
						error_code="20";
					}else if(date1==1) {
						message="预约会议开始时间不能大于结束时间！";
						error_code="22";
					}/*else if(tConfinfo.getMaxUserCount()>maxUserComp) {
						message="会议室最大用户数不能大于企业最大并发数！";
						error_code="23";
					}*/
				}else {
						editMeetSql ="UPDATE t_confinfo set  ";
					if(tConfinfo.getConfName()!=null && tConfinfo.getConfName() !="") {
					String ConfName=Sqlca.switchLatin1Encoding(tConfinfo.getConfName());
						editMeetSql+=" ConfName = '"+ConfName+"'";
					}
					if(tConfinfo.getConfPwd()!=null && tConfinfo.getConfPwd()!="") {
						editMeetSql+=" ,ConfPwd = '"+tConfinfo.getConfPwd()+"'";
					}
					/*if(String.valueOf(tConfinfo.getMaxUserCount())!=null && String.valueOf(tConfinfo.getMaxUserCount())!="") {
						editMeetSql+=" ,MaxUserCount = '"+tConfinfo.getMaxUserCount()+"'";
					}*/
					if(tConfinfo.getIsPublic()!=null && tConfinfo.getIsPublic()!="") {
						editMeetSql+=" ,IsPublic = '"+tConfinfo.getIsPublic()+"'";
					}
					if(tConfinfo.getIsOnOff()!=null && tConfinfo.getIsOnOff()!="") {
						editMeetSql+=" ,IsOnOff = '"+tConfinfo.getIsOnOff()+"'";
					}
					if(tConfinfo.getChairPwd()!=null && tConfinfo.getChairPwd() !="") {
						editMeetSql+=" ,ChairPwd = '"+tConfinfo.getChairPwd()+"'";
					}
					if(tConfinfo.getIsReservedConf()!=null && tConfinfo.getIsReservedConf() !="") {
						editMeetSql+=" ,IsReservedConf = '"+tConfinfo.getIsReservedConf()+"'";
					}
					if(StartTime !=null && StartTime!="") {
						editMeetSql+=" ,StartTime = '"+StartTime+"'";
					}
					if(EndTime !=null && EndTime !="") {
						editMeetSql+=" ,EndTime = '"+EndTime+"'";
					}
					if(plan!=null && plan !="") {
						editMeetSql+=" ,plan = '"+plan+"'";
					}
					if(BeginTime !=null && BeginTime !="") {
						editMeetSql+=" ,BeginTime = '"+BeginTime+"'";
					}
					if(overTime!=null && overTime!="") {
						editMeetSql+=" ,overTime = '"+overTime+"'";
					}
					if(ConfDesc!=null && ConfDesc!="") {
						editMeetSql+=" ,ConfDesc = '"+ConfDesc+"'";
					}
					editMeetSql+=" WHERE ConfID = '"+tConfinfo.getConfId()+"'";
				}
	
					int count = Sqlca.updateObject(editMeetSql, new String[] {});
					if(count>0) {
						message="Request successful";
						error_code="000000";
					}else {
						error_code="-1";
						message="修改会议室失败！";
					}
				}else {
					error_code="18";
				}
			
			json1.put("confId", tConfinfo.getConfId());
			JSONObject json = new JSONObject();
			json.put("result", json1);
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
		}
		 
		/**
		 *	 删除会议室
		 * @param UserName
		 * @param UserPassword
		 * @param ConfID
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/delMeeting",method = RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>delMeeting(HttpServletRequest request,TUser tUser,TConfinfo tConfinfo) throws Exception{
			
			String error_code = "";
			String message="";
			String uid =request.getParameter("uid")==null?"":request.getParameter("uid");
			String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			tUser.setToken(token);
			
			String confSql = "SELECT COUNT(1) from t_confinfo WHERE CompID =(SELECT u.CompID FROM t_userinfo u WHERE " + 
					" 			u.UserID=(SELECT userId FROM t_user_token WHERE userId ="+uid+" AND token = '"+tUser.getToken()+"')) "
					+ "AND confId ="+tConfinfo.getConfId();
			String conf =Sqlca.getString(confSql);
			
			tUser.setUserId(Integer.parseInt(uid));
			String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
			JSONObject json1 = new JSONObject();
			
			if(isManager.equals("") || conf.equals("0")) {
				if(isManager.equals("")) {
					message="您不是管理员不能修改会议室！";
					error_code="18";
				}else if(conf.equals("0")) {
					message="该会议室不在您的企业名下，不能删除！";
					error_code="24";
				}
			}else {
				String delSql ="DELETE FROM t_confinfo WHERE ConfID = "+tConfinfo.getConfId();
				int del = Sqlca.updateObject(delSql, new String[] {});
				if(del>0) {
					error_code="000000";
					message="Request successful";
				}else {
					message="-1";
				}
			}
			json1.put("confId", tConfinfo.getConfId());
			JSONObject json = new JSONObject();
			json.put("message", message);
			json.put("error_code",error_code);
			return json;
		}
	 
		/**
		 * IM推送消息给手机端
		 * @param request
		 * @param type
		 * @return
		 */
		@RequestMapping(value="/imPushMsg",method=RequestMethod.POST)
		public Map<String, Object> imPushMsg(HttpServletRequest request,String type) {
			JSONObject json = new JSONObject();
			String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		    String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			
			
			
			return json;
		}
		
	 
	 
		/**
		 *  会议室分配参会人员
		 * @param ConfId
		 * @param userId
		 * @param userRight
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/distributAttendUser",method= RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>distributAttendMeetUser(HttpServletRequest request,TUser tUser,Integer confId) throws Exception{
			
			String error_code ="";
			String message=""; 
			JSONObject json = new JSONObject();
			Connection conn = Sqlca.getConnection();
			Statement sts = conn.createStatement();
		    String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
		    tUser.setUserId(Integer.parseInt(uid));
		    String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			tUser.setToken(token);
		    String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
		    String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
		   
			if(isManager.equals("1") || isManager.equals("2")) {
				int count=0;
				String sqlDel =" DELETE FROM t_confusers WHERE ConfID ="+confId;
				Sqlca.updateObject(sqlDel, new String[] {});
				try {
					JSONArray jsonArr = JSONArray.parseArray(userIds); 
					for (Object userId : jsonArr) {
						int dd = Integer.parseInt(userId.toString());
						int flag = meetingRoomDao.selectUserInfoDistri(confId, dd);
						if(flag<1) {
							String chuxi=Sqlca.switchLatin1Encoding("出席");
							String sql ="INSERT INTO t_confusers(ConfID,UserID,UserRight,UserPos,CsipId,MsipId)values('"+confId+"','"+dd+"','"+chuxi+"',0,0,0)";
							sts.addBatch(sql);
							sts.executeBatch();
							count++;
						}
						String	ss ="";
						StringBuffer ff = new StringBuffer();
						ff.append(userId).append(",");
						if(ff.length()>0) {
							ss = ff.toString().substring(0, ff.toString().length()-1);
						}else {
							ss="";
						}
						String now = "now()";
						String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(1,"+confId+",'"+ss+"',"+now+")";
						Sqlca.updateObject(insert, new String[] {});
					} 
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					sts.close();
					conn.close();
				}
				JSONObject json1 = new JSONObject();
				json1.put("count", count);
				json1.put("confId", confId);
				message="Request successful";
				error_code="000000"; 
				json.put("result", json1);
			}else {
				message="您不是管理员不能分配参会列表！";
				error_code="18";
				
			} 
			json.put("error_code", error_code);
			json.put("message", message);
			 
			return json;
		}
		
		/**
		 * 	取消参会人员
		 * @param UserName
		 * @param UserPassword
		 * @param ConfId 会议id
		 * @param UserIds 参会人员一个或多个
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/delAttendMeetUser",method= RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>delAttendMeetUser(HttpServletRequest request,TUser tUser,Integer confId) throws Exception{
			
			String error_code =""; 
			String message=""; 
			Connection conn = Sqlca.getConnection();
			Statement sts = conn.createStatement();
			
			String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
			tUser.setUserId(Integer.parseInt(uid));
			String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			tUser.setToken(token);
			String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
			JSONObject json = new JSONObject();
			String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
			
			if(isManager.equals("")) {
					message="您不是管理员不能分配参会列表！";
					error_code="18";
			}else {
				int count=0;
					try {
					JSONArray jsonArr = JSONArray.parseArray(userIds); 
						for (Object userId : jsonArr) {
							String	ss ="";
							StringBuffer ff = new StringBuffer();
							ff.append(userId).append(",");
							if(ff.length()>0) {
								ss = ff.toString().substring(0, ff.toString().length()-1);
							}else {
								ss="";
							}
							String now = "now()";
							String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(2,"+confId+",'"+ss+"',"+now+")";
							Sqlca.updateObject(insert, new String[] {});
							
							int dd = Integer.parseInt(userId.toString());
							String sql ="delete from t_confusers where ConfID ="+confId+" and UserID ="+dd;
							sts.addBatch(sql);
							sts.executeBatch();
							count++;
							
						}
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					sts.close();
					conn.close();
				}
				JSONObject json1 = new JSONObject();
				json1.put("count", count);
				json1.put("confId", confId);
				message="Request successful";
				error_code="000000"; 
				json.put("result", json1);
			} 
			json.put("error_code", error_code);
			json.put("message", message);
			return json;
		}
		
		/**
		 *  修改会议用户角色
		 * @param UserName
		 * @param UserPassword
		 * @param ConfId
		 * @param UserIds 
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/editAttendMeetingUser",method= RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>editAttendMeetingUser(HttpServletRequest request,TUser tUser,int confId,String userRight) throws Exception{
			
			String error_code =""; 
			String message=""; 
			if(userRight.equals("1")) {
				userRight="主席";
			}else {
				userRight="出席";
			}
			String uid = request.getParameter("uid")==null?"":request.getParameter("uid");
			tUser.setUserId(Integer.parseInt(uid));
			String token = request.getParameter("token").replace(' ', '+')==null?"":request.getParameter("token").replace(' ','+');
			tUser.setToken(token);
			String isManager = APPDao.selectUserIsManager(tUser)==null?"":APPDao.selectUserIsManager(tUser);//用户是否管理员
			String userIds = request.getParameter("userIds")==null?"":request.getParameter("userIds");
			JSONObject json1 = new JSONObject();
			JSONObject json = new JSONObject();
			
			if(isManager.equals("")) {
					error_code="18";
			}else {
				int count=0;
				JSONArray jsonArr = JSONArray.parseArray(userIds); 
				for (Object userId : jsonArr) {
					String dd = userId.toString();
					String edtSql ="update t_confusers set UserRight = ? where ConfID =? and UserID = ?";
					count = Sqlca.updateObject(edtSql, new String[] {userRight,String.valueOf(confId),dd});
					if(count>0) {
						count++;
					}
				} 
				json1.put("count", count);
				json1.put("confId", confId);
			}
			message="Request successful";
			error_code="000000"; 
			json.put("result", json1); 
			json.put("message", message);
			json.put("error_code", error_code);
			return json;
		}
	 
	 
		
		/**
		 * 根据部门分配参会
		 * @param request
		 * @param tUser
		 * @param confId
		 * @param userRight
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/deptdistributAttendMeetUser",method= RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>deptdistributAttendMeetUser(HttpServletRequest request,TUser tUser) throws Exception{
			
		String error_code =""; 
		String message="";
		JSONObject json =new JSONObject();
		int confId = Integer.parseInt(request.getParameter("confId"));
		List<TUser>dpIdList =  APPDao.selectSonDeptToParent(tUser);
		String userRight=Sqlca.switchLatin1Encoding("出席");
		int count =0;
		
		if(dpIdList.size()>0) {
			TUser dp = new TUser();
			dp.setDpId(tUser.getDpId());
			dpIdList.add(dp);
			for (TUser string : dpIdList) {
				String tt= string.getDpId().toString();
				List<TUser>users =  APPDao.selectDeptUser(tt);
				for (TUser tUser2 : users) {
					int flag = meetingRoomDao.selectUserInfoDistri(confId, tUser2.getUserId());
					if(flag<1) {
						APPDao.distributAttendMeetUser(confId, tUser2.getUserId(), userRight);
						count++;
					}
					String	ss ="";
					StringBuffer ff = new StringBuffer();
					ff.append(tUser2.getUserId()).append(",");
					if(ff.length()>0) {
						ss = ff.toString().substring(0, ff.toString().length()-1);
					}else {
						ss="";
					}
					String now = "now()";
					String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(1,"+confId+",'"+ss+"',"+now+")";
					Sqlca.updateObject(insert, new String[] {});
				}
			}
		}else {
			List<TUser>users =  APPDao.selectDeptUser(tUser.getDpId().toString());
			for (TUser tUser2 : users) {
				int flag = meetingRoomDao.selectUserInfoDistri(confId, tUser2.getUserId());
				if(flag<1) {
					APPDao.distributAttendMeetUser(confId, tUser2.getUserId(), userRight);
					count++;
				}
				String	ss ="";
				StringBuffer ff = new StringBuffer();
				ff.append(tUser2.getUserId()).append(",");
				if(ff.length()>0) {
					ss = ff.toString().substring(0, ff.toString().length()-1);
				}else {
					ss="";
				}
				String now = "now()";
				String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(1,"+confId+",'"+ss+"',"+now+")";
				Sqlca.updateObject(insert, new String[] {});
			}
		} 
		JSONObject json1 = new JSONObject();
		json1.put("count", count);
		json1.put("confId", confId);
		message="Request successful";
		error_code="000000"; 
		json.put("result", json1);
		json.put("error_code", error_code);
		json.put("message", message);
		return json;
	}
	 
	 
		
		/**
		 * 根据部门id取消参会人员
		 * @param request
		 * @param tUser
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/deptdelAttendMeetUser",method = RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>deptdelAttendMeetUser(HttpServletRequest request,TUser tUser) throws Exception{
			
			String error_code =""; 
			String message="";
			JSONObject json =new JSONObject();
			int confId = Integer.parseInt(request.getParameter("confId"));
			List<TUser>dpIdList =  APPDao.selectSonDeptToParent(tUser);
			int count =0;
			
			if(dpIdList.size()>0) {
				TUser dp = new TUser();
				dp.setDpId(tUser.getDpId());
				dpIdList.add(dp);
				for (TUser string : dpIdList) {
					String tt= string.getDpId().toString();
					List<TUser>users =  APPDao.selectDeptUser(tt);
					for (TUser tUser2 : users) {
						String	ss ="";
						StringBuffer ff = new StringBuffer();
						ff.append(tUser2.getUserId()).append(",");
						if(ff.length()>0) {
							ss = ff.toString().substring(0, ff.toString().length()-1);
						}else {
							ss="";
						}
						String now = "now()";
						String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(2,"+confId+",'"+ss+"',"+now+")";
						Sqlca.updateObject(insert, new String[] {});
						//APPDao.delAttendMeetUser(confId, tUser2.getUserId());
						String sql ="delete from t_confusers where ConfID ="+confId+" and UserID in("+ss+")";
						Sqlca.updateObject(sql, new String[] {});
						count++;
					}
				}
			}else {
				List<TUser>users =  APPDao.selectDeptUser(tUser.getDpId().toString());
				for (TUser tUser2 : users) {
					String	ss ="";
					StringBuffer ff = new StringBuffer();
					ff.append(tUser2.getUserId()).append(",");
					if(ff.length()>0) {
						ss = ff.toString().substring(0, ff.toString().length()-1);
					}else {
						ss="";
					}
					String now = "now()";
					String insert = "INSERT INTO t_im_pushmsg(imsgtype,confid,pushmsg,pushtime)VALUES(2,"+confId+",'"+ss+"',"+now+")";
					Sqlca.updateObject(insert, new String[] {});
					String sql ="delete from t_confusers where ConfID ="+confId+" and UserID in("+ss+")";
					Sqlca.updateObject(sql, new String[] {});
					//APPDao.delAttendMeetUser(confId, tUser2.getUserId());
					count++;
				}
			} 
			JSONObject json1 = new JSONObject();
			json1.put("count", count);
			json1.put("confId", confId);
			message="Request successful";
			error_code="000000"; 
			json.put("result", json1);
			json.put("error_code", error_code);
			json.put("message", message);
			return json;
		}
		
		
		public static boolean isMobileNO(String mobile){ 
			if(mobile.length()!=11) {
				return false;
			}else {
				/**
				 * 移动号段正则表达式
	             */
				String pat1 = "^((13[4-9])|(147)|(15[0-2,7-9])|(178)|(18[2-4,7-8]))\\\\d{8}|(1705)\\\\d{7}$";
				/**
				 * 联通号段正则表达式
	             */
				String pat2 ="^((13[0-2])|(145)|(15[5-6])|(176)|(18[5,6]))\\\\d{8}|(1709)\\\\d{7}$";
				/**
				 * 电信号段正则表达式
	             */
				String pat3 ="^((133)|(153)|(177)|(18[0,1,9])|(149))\\\\d{8}$";
				/**
				 * 虚拟运营商正则表达式
	             */
				String pat4 = "^((170))\\\\d{8}|(1718)|(1719)\\\\d{7}$";
				
				Pattern pattern1 =Pattern.compile(pat1);
				Matcher match1 = pattern1.matcher(mobile);
				boolean isMatch1 = match1.matches();
				if(isMatch1) {
					return true;
				}
				Pattern pattern2 =Pattern.compile(pat2);
				Matcher match2 = pattern2.matcher(mobile);
				boolean isMatch2 = match2.matches();
				if(isMatch2) {
					return true;
				}
				Pattern pattern3 =Pattern.compile(pat3);
				Matcher match3 = pattern3.matcher(mobile);
				boolean isMatch3 = match3.matches();
				if(isMatch3) {
					return true;
				}
				Pattern pattern4 =Pattern.compile(pat4);
				Matcher match4 = pattern4.matcher(mobile);
				boolean isMatch4 = match4.matches();
				if(isMatch4) {
					return true;
				}
			}
			return false;
		}
		
		/**
		 * 根据企业id查询企业信息
		 * @return
		 * @throws Exception 
		 * @throws NumberFormatException 
		 */
		@RequestMapping(value="/selectCompInfoById",method=RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>selectCompInfoById(HttpServletRequest request) throws NumberFormatException, Exception{
			JSONObject json = new JSONObject();
			String compId =request.getParameter("compId")==null?"":request.getParameter("compId");
			TCompinfoVo compInfo = APPDao.selectCustomById(Integer.parseInt(compId));
			String headImage =compInfo.getHeadImagePath()==null?"":compInfo.getHeadImagePath();
			if(headImage.equals("")) {
				compInfo.setHeadImagePath("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
			 }else {
				 compInfo.setHeadImagePath("http://192.168.35.111:8080/vip/images/compHead/"+headImage);
			 }
			json.put("result", compInfo);
			json.put("error_code", "000000");
			return json;
		}
		
		/**
		 *  根据会议id查询其他会议信息
		 * @param request
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/selectMeetingByConfId",method=RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>selectMeetingByConfId(HttpServletRequest request) throws Exception{
			JSONObject json = new JSONObject();
			int confId = request.getParameter("confId")==null?0:Integer.parseInt(request.getParameter("confId"));
			TConfinfoVo tConfVo =  APPDao.selectMeetingDetail(confId);
			
			json.put("result", tConfVo);
			json.put("error_code", "000000");
			return json;
		}
		/**
		 * 根据用户id查询其他用户
		 * @param request
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/selectUserInfoByID",method=RequestMethod.POST)
		@ResponseBody
		public Map<String, Object>selectUserInfoByID(HttpServletRequest request) throws Exception{
			JSONObject json = new JSONObject();
			String userId =request.getParameter("userId")==null?"0":request.getParameter("userId");
			TUser tUser =APPDao.validateUserPassword(userId);
			
			String headImage =tUser.getLogo()==null?"":tUser.getLogo();
			 if(headImage.equals("")) {
				 tUser.setLogo("http://testvip.hwactive.com/images/userHead/am_admin@3x.jpg");
			 }else {
				 tUser.setLogo("http://192.168.35.111:8080/vip/images/userHead/"+headImage);
			 }
			
			json.put("result", tUser);
			json.put("error_code", "000000");
			return json;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}














































