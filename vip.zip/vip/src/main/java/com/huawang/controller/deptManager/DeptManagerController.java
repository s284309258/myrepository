package com.huawang.controller.deptManager;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Organ")
public class DeptManagerController 
{


	@RequestMapping(value="/OrganManager.do")
	public ModelAndView OrganManager(HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		ArrayList<Map<String,Object>> arraylist = getOrganMenu(compid);
		ModelAndView view = new ModelAndView("deptManager/deptManager");
		view.addObject("organMenu", arraylist);
		return view ;
	}
	
	@RequestMapping(value="/OrganContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid,HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		ArrayList<Map<String,Object>> array = getOrganList(dpid,compid);
		ModelAndView view = new ModelAndView("deptManager/deptContent");
		view.addObject("organList", array);
		return view;
	}
	
	@RequestMapping(value="/AddDepartMent.do")
	public ModelAndView AddDepartMent() {
		ModelAndView view = new ModelAndView("deptManager/addDept");
		return view;
	}
	
	@RequestMapping(value="/ModifyDepartMent.do")
	public ModelAndView ModifyDepartMent(@RequestParam("dpid") String dpid,HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select DpId,DpName,Description,ParentDpId from t_department t where t.DpId='"+dpid+"' and t.compid="+compid);
		ModelAndView view = new ModelAndView("deptManager/modifyDept");
		view.addObject("organ", array.get(0));
		return view;
	}
	
	
	@RequestMapping(value="/AddDepartMentSubmit.do",produces = "text/html;charset=utf-8")
	@ResponseBody
	public String AddDepartMentSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		String DpName = request.getParameter("DpName");
		String ParentDpId = request.getParameter("ParentDpId");
		String Description = request.getParameter("Description");
		
		String gg = Sqlca.getString("select DpId from t_department t where t.DpName='"+DpName+"' and compid="+compid);
		if(gg!=null)
		{
			return "部门名称已存在";
		}
		int cnt = Sqlca.updateObject("insert into t_department(codeno,dpname,description,parentdpid,adminid,ordervalue,compid) " + 
				"values ('',?,?,?,"+compid+",'0',"+compid+")", new String[] {DpName,Description,ParentDpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DelDepartMentSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String DelDepartMentSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String DpId = request.getParameter("DpId");
		String ck1 = Sqlca.getString("select dpid from t_department where ParentDpId='"+DpId+"'");
		if(ck1!=null) 
		{
			return "该部门下面包括子部门,请先删除子部门";
		}
		String obj = Sqlca.getString("select dpid from t_userinfo where dpid='"+DpId+"'");
		if(obj!=null) 
		{
			return "已有用户关联此部门,不能删除";
		}
		int cnt = Sqlca.updateObject("delete from t_department where DpId=?", new String[] {DpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyDepartMentSubmit.do",produces = "text/html;charset=utf-8")
	@ResponseBody
	public String ModifyDepartMentSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		
		String DpId = request.getParameter("DpId");
		String DpName = request.getParameter("DpName");
		String ParentDpId = request.getParameter("ParentDpId");
		String Description = request.getParameter("Description");
		
		String ck1 = Sqlca.getString("select DpId from t_department where DpName='"+DpName+"' and DpId<>'"+DpId+"' and compId="+compid);
		
		if(ck1!=null)
		{
			return "部门名称已存在";
		}
		
		int cnt = Sqlca.updateObject("update t_department t set t.DpName=?,"
				+ "t.Description=?,t.ParentDpId=? where t.DpId=?", new String[] {DpName,Description,ParentDpId,DpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DepartMentQuery.do")
	@ResponseBody
	public ArrayList<Map<String,Object>> DepartMentQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception {
		
		Object obj = session.getAttribute("USER_VIPSESSION");
		Integer compid = null;
		if(obj!=null)
		{
			TUserinfo userinfo = (TUserinfo)obj;
			compid = userinfo.CompID;
			
		}
		
		String DpName = request.getParameter("DpName");
		String sql = "select t.DpId,t.DpName,(select tt.DpName from t_department tt"
				+ " where tt.DpId=t.ParentDpId) as ParentDpName,t.Description,t.DpId as Operation from t_department t where t.DpName like '%"+DpName+"%' and t.DpId<>'1' and t.compid="+compid;
		ArrayList<Map<String,Object>> organList = Sqlca.getArrayListFromMap(sql);
		request.setAttribute("organList", organList);
//		request.getRequestDispatcher(request.getContextPath()+"\\system\\OrganContent").forward(request, response);
		return organList; 
	}
	
	public ArrayList<Map<String,Object>> getOrganList(String dpid,Integer compid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
		if("99999".equals(dpid)) {dpid="1";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"' and t.compid="+compid;
			
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if("".equals(buffer.toString()))
			{
				String menus01 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId="+dpid;
				buffer = Sqlca.getStringBuffer(menus01);
			}
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;
					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						sqlbf.append(" union ").append(menus3).append(" union ");
						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+") and t.compid="+compid;
						sqlbf.append(menus4);
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"' and t.compid="+compid;
			sqlbf.append(menus);
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"' and t.compid="+compid;
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+") and t.compid="+compid;
				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+") and t.compid="+compid;
					sqlbf.append(menus3);
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
						sqlbf.append(" union ");
						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+") and t.compid="+compid;
						sqlbf.append(menus4);
					}
				}
				
			}
		}
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sqlbf.toString());
		
		return array;
		
	}
	
	public static ArrayList<Map<String,Object>> getOrganMenu(Integer compid) throws Exception {
		String sql="select DpId,DpName,ParentDpId,AdminId,CompId from t_department where ParentDpId='-1'";
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		for(Map<String,Object> ob : array) {
			String dpid = (String)ob.get("DpId");
			String sql2="select * from t_department where parentdpid='"+dpid+"' and compid="+compid;
			ArrayList<Map<String,Object>> array2 = Sqlca.getArrayListFromMap(sql2);
			ob.put("children", array2);
			for(Map<String,Object> ob2 : array2) {
				String dpid3 = (String)ob2.get("DpId");
				String sql3="select * from t_department where parentdpid='"+dpid3+"' and compid="+compid;
				ArrayList<Map<String,Object>> array3 = Sqlca.getArrayListFromMap(sql3);
				ob2.put("children", array3);
				for(Map<String,Object> ob3 : array3) {
					String dpid4 = (String)ob3.get("DpId");
					String sql4="select * from t_department where parentdpid='"+dpid4+"' and compid="+compid;
					ArrayList<Map<String,Object>> array4 = Sqlca.getArrayListFromMap(sql4);
					ob3.put("children", array4);
					for(Map<String,Object> ob4 : array4) {
						String dpid5 = (String)ob4.get("DpId");
						String sql5="select * from t_department where parentdpid='"+dpid5+"' and compid="+compid;
						ArrayList<Map<String,Object>> array5 = Sqlca.getArrayListFromMap(sql5);
						ob4.put("children", array5);
					}
				}
			}
			
		}
		
		return array;
	}
	
	//������ҵ��̨��ߵĽ�����ҵ��̨������
	/*public static ArrayList<Map<String,Object>> getOrganMenu() throws Exception {
		String sql="select DpId,DpName,ParentDpId,AdminId,OrderValue,CompId,CodeNo from t_department where ParentDpId='-1'";
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		for(Map<String,Object> ob : array) {
			String dpid = (String)ob.get("DpId");
			String sql2="select * from t_department where parentdpid='"+dpid+"'";
			ArrayList<Map<String,Object>> array2 = Sqlca.getArrayListFromMap(sql2);
			ob.put("children", array2);
			for(Map<String,Object> ob2 : array2) {
				String dpid3 = (String)ob2.get("DpId");
				String sql3="select * from t_department where parentdpid='"+dpid3+"'";
				ArrayList<Map<String,Object>> array3 = Sqlca.getArrayListFromMap(sql3);
				ob2.put("children", array3);
				for(Map<String,Object> ob3 : array3) {
					String dpid4 = (String)ob3.get("DpId");
					String sql4="select * from t_department where parentdpid='"+dpid4+"'";
					ArrayList<Map<String,Object>> array4 = Sqlca.getArrayListFromMap(sql4);
					ob3.put("children", array4);
					for(Map<String,Object> ob4 : array4) {
						String dpid5 = (String)ob4.get("DpId");
						String sql5="select * from t_department where parentdpid='"+dpid5+"'";
						ArrayList<Map<String,Object>> array5 = Sqlca.getArrayListFromMap(sql5);
						ob4.put("children", array5);
					}
				}
			}
			
		}
		
		return array;
	}*/
	
	
	//������ҵ��̨�м���س����Ľ�����ҵ��̨���������б�
	/*public ArrayList<Map<String,Object>> getOrganList(String dpid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
//		if("99999".equals(dpid)) {dpid="0";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						sqlbf.append(" union ").append(menus3).append(" union ");
						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(menus4);
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"'";
			sqlbf.append(menus);
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
					sqlbf.append(menus3);
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
						sqlbf.append(" union ");
						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(menus4);
					}
				}
				
			}
		}
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sqlbf.toString());
		
		return array;
		
	}*/
	//�����ѯ��ѯ�����Ľ�����ҵ��̨���������б�
	/*@RequestMapping(value="/DepartMentQuery.do")
	@ResponseBody
	public ArrayList<Map<String,Object>> DepartMentQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String DpName = request.getParameter("DpName");
		String sql = "select t.DpId,t.DpName,(select tt.DpName from t_department tt"
				+ " where tt.DpId=t.ParentDpId) as ParentDpName,t.Description,t.DpId as Operation from t_department t where t.DpName like '%"+DpName+"%' and t.DpId<>'0'";
		ArrayList<Map<String,Object>> organList = Sqlca.getArrayListFromMap(sql);
		request.setAttribute("organList", organList);
//		request.getRequestDispatcher(request.getContextPath()+"\\system\\OrganContent").forward(request, response);
		return organList; 
	}*/
	
	//ѡ��һ�е���޸ĸ��½�����ҵ��̨����
	/*@RequestMapping(value="/ModifyDepartMentSubmit.do")
	@ResponseBody
	public String ModifyDepartMentSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String DpId = request.getParameter("DpId");
		String DpName = request.getParameter("DpName");
		String ParentDpId = request.getParameter("ParentDpId");
		String Description = request.getParameter("Description");
		int cnt = Sqlca.updateObject("update t_department t set t.DpName=?,"
				+ "t.Description=?,t.ParentDpId=? where t.DpId=?", new String[] {DpName,Description,ParentDpId,DpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}*/
	
	//ɾ��������ҵ��̨����
	/*@RequestMapping(value="/DelDepartMentSubmit.do")
	@ResponseBody
	public String DelDepartMentSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String DpId = request.getParameter("DpId");
		int cnt = Sqlca.updateObject("delete from t_department where DpId=?", new String[] {DpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}*/
	
	//����������ҵ��̨����
	/*@RequestMapping(value="/AddDepartMentSubmit.do")
	@ResponseBody
	public String AddDepartMentSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String DpName = request.getParameter("DpName");
		String ParentDpId = request.getParameter("ParentDpId");
		String Description = request.getParameter("Description");
		
		int cnt = Sqlca.updateObject("insert into t_department(codeno,dpname,description,parentdpid,adminid,ordervalue,compid) " + 
				"values ('',?,?,?,'4','0','4')", new String[] {DpName,Description,ParentDpId});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}*/
	
	
	//����޸ļ��س�������ҵ��̨�������ݽ�������
	/*@RequestMapping(value="/ModifyDepartMent.do")
	public ModelAndView ModifyDepartMent(@RequestParam("dpid") String dpid) throws Exception {
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select DpId,DpName,Description,ParentDpId from t_department t where t.DpId='"+dpid+"'");
		ModelAndView view = new ModelAndView("system/ModifyDepartMent");
		view.addObject("organ", array.get(0));
		return view;
	}*/
	
	
	//����������ҵ��̨�������ݽ���
	/*@RequestMapping(value="/AddDepartMent.do")
	public ModelAndView AddDepartMent() {
		ModelAndView view = new ModelAndView("system/AddDepartMent");
		return view;
	}*/
	
	
	//������ҵ��̨�������ݽ���
	/*@RequestMapping(value="/OrganContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid) throws Exception {
		
		ArrayList<Map<String,Object>> array = getOrganList(dpid);
		ModelAndView view = new ModelAndView("system/OrganContent");
		view.addObject("organList", array);
		return view;
	}*/
	
	//��ҵ��̨�������ݽ�����߲������˵�
	/*@RequestMapping(value="/OrganManager.do")
	public ModelAndView OrganManager() throws Exception {
		
		ArrayList<Map<String,Object>> arraylist = getOrganMenu();
		ModelAndView view = new ModelAndView("system/OrganManager");
		view.addObject("organMenu", arraylist);
		return view ;
	}*/

}
