package com.huawang.controller.userManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huawang.dao.organization.UserDao;
import com.huawang.pojo.meetingRoom.TUserinfo;
import com.huawang.pojo.organization.UserRequestVO;
import com.huawang.pojo.organization.UserVO;
import com.huawang.pojo.organization.UserVOExtend;
import com.huawang.pojo.result.CodeMsg;
import com.huawang.pojo.result.Page;
import com.huawang.pojo.result.Result;
import com.huawang.util.DateUtil;

@Controller
@RequestMapping("/apply")
public class UserRequestContorller {

	@Autowired
	private UserDao userDao;

	@RequestMapping("userRequest.do")
	public String userRequest() {
		return "userManager/userRequest";
	}

	@RequestMapping("userRequestInfo.do")
	public String userRequestInfo() {
		return "userManager/userRequestInfo";
	}

	/**
	 * 待办数据展示
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("getUserRequest.do")
	@ResponseBody
	public Map<String, Object> getUserRequest(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		int curPage = 0;
		int pageSize = 10;
		Integer userStatus = 1;
		String userPhone = request.getParameter("userPhone");
		if (request.getParameter("page") != null) {
			curPage = Integer.parseInt(request.getParameter("page"));
			pageSize = Integer.parseInt(request.getParameter("rows"));
		}
		if (request.getParameter("userStatus") != null && !"".equals(request.getParameter("userStatus"))) {
			userStatus = Integer.parseInt(request.getParameter("userStatus"));
		}
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int compID = tUser.getCompID();
		int totalRow = userDao.getUserRequestCount(compID, userStatus, userPhone);
		Page page = new Page(totalRow, pageSize, curPage);
		List<Map<String, Object>> UserRequestList = userDao.getUserRequest(compID, userStatus, userPhone, page);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", totalRow);
		map.put("rows", UserRequestList);
		return map;
	}

	@RequestMapping("userRequestHistory.do")
	public String userRequestHistory() {
		return "userManager/userRequestHistory";
	}

	/**
	 * 审核历史记录
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("getUserRequestHistory.do")
	@ResponseBody
	public Map<String, Object> getUserRequestHistory(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		int curPage = 0;
		int pageSize = 10;
		Integer userStatus = -1;
		String userPhone = request.getParameter("userPhone");
		if (request.getParameter("page") != null) {
			curPage = Integer.parseInt(request.getParameter("page"));
			pageSize = Integer.parseInt(request.getParameter("rows"));
		}
		if (request.getParameter("userStatus") != null && !"".equals(request.getParameter("userStatus"))) {
			userStatus = Integer.parseInt(request.getParameter("userStatus"));
		}
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int compID = tUser.getCompID();
		int totalRow = userDao.getUserRequestHistoryCount(compID, userStatus, userPhone);
		Page page = new Page(totalRow, pageSize, curPage);
		List<Map<String, Object>> UserRequestList = userDao.getUserRequestHistory(compID, userStatus, userPhone, page);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", totalRow);
		map.put("rows", UserRequestList);
		return map;
	}

	/**
	 * 单个人的审批通过
	 * 
	 * @return
	 */
	@RequestMapping("agreeUserRequest.do")
	@ResponseBody
	public Result<String> agreeUserRequest(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int userId = -1;
		int adminId = -1;
		if (tUser != null) {
			adminId = tUser.getUserID();
		}
		if (request.getParameter("userId") != null) {
			userId = Integer.parseInt(request.getParameter("userId"));
		}
		UserRequestVO userRequestVO = userDao.getUserRequestInfo(userId);
		UserVOExtend userVO = new UserVOExtend();
		userVO.setUserName("HW" + userRequestVO.getUserPhone());
		userVO.setUserPassword(userRequestVO.getUserPassword());
		userVO.setTelephone(userRequestVO.getUserPhone());
		userVO.setDpId(1);
		userVO.setIsSuper("1");
		userVO.setJoinMode(userRequestVO.getInviteType());
		userVO.setRegisterTime(new Date());
		userVO.setCompID(userRequestVO.getCompID());
		userVO.setAdminID(adminId);
		userVO.setLastLoginTime(DateUtil.dateFormat(new Date()));
		int addCount = userDao.addUserToCompany(userVO);
		Result<String> result = Result.error(CodeMsg.NOT_FIND_DATA, "userId:" + userId);
		// userStatus默认是0 、待审核1、 已通过2、 已拒绝3
		int userStatus = 2;
		if (addCount > 0) {
			int i = userDao.agreeUserRequest(userId, userVO.getUserID(), userStatus);
			if (i > 0) {
				result = Result.success(new String("审核通过！" + "userId:" + userId));
			}
		}
		return result;
	}

	/**
	 * 审核批量同意
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("agreeBatchUserRequest.do")
	@ResponseBody
	public Result<String> agreeBatchUserRequest(HttpServletRequest request, HttpServletResponse response) {
		String[] userIdListstr=request.getParameterValues("userIdList[]");
		if(userIdListstr==null||userIdListstr.length<1) {
			return Result.error(CodeMsg.NOT_FIND_DATA, "没有选择待审核用户");
		}
		List<Integer> userIdList=new ArrayList<Integer>();
		if(userIdListstr!=null&&userIdListstr.length>0) {
			for(String userIdStr:userIdListstr) {
				userIdList.add(Integer.parseInt(userIdStr));
			}
		}
		HttpSession session = request.getSession();
		TUserinfo tUser = (TUserinfo) session.getAttribute("USER_VIPSESSION");
		int adminId = -1;
		if (tUser != null) {
			adminId = tUser.getUserID();
		}
		//查询需要审核的成员信息
		List<UserRequestVO> userRequestVOList = userDao.getUserBatchRequestInfo(userIdList);
		StringBuilder sb=new StringBuilder();
		Result<String> result = Result.error(CodeMsg.NOT_FIND_DATA, "userIdList:" + userIdList);
		for(UserRequestVO userRequestVO:userRequestVOList) {
			UserVOExtend userVO = new UserVOExtend();
			userVO.setUserName("HW" + userRequestVO.getUserPhone());
			userVO.setUserPassword(userRequestVO.getUserPassword());
			userVO.setTelephone(userRequestVO.getUserPhone());
			userVO.setDpId(1);
			userVO.setIsSuper("1");
			userVO.setJoinMode(userRequestVO.getInviteType());
			userVO.setRegisterTime(new Date());
			userVO.setCompID(userRequestVO.getCompID());
			userVO.setAdminID(adminId);
			userVO.setLastLoginTime(DateUtil.dateFormat(new Date()));
			userVO.setUserRequestId(userRequestVO.getUserId());
			//批量加入组织
			int addCount = userDao.addUserToCompany(userVO);
			// userStatus默认是0 、待审核1、 已通过2、 已拒绝3
				int userStatus = 2;
				if (addCount > 0) {
					//审核通过
					int i = userDao.agreeUserRequest(userVO.getUserRequestId(),userVO.getUserID(), userStatus);
					if (i > 0) {
						sb.append("审核通过！" + "userId:" + userVO.getUserID()+"  ");
					}
				}
		}
		result = Result.success(sb.toString());
		return result;
	}

	/**
	 * 单个人的审批不通过
	 * 
	 * @return
	 */
	@RequestMapping("rejectUserRequest.do")
	@ResponseBody
	public Result<String> rejectUserRequest(HttpServletRequest request, HttpServletResponse response) {
		String userIdStr = request.getParameter("userId");
		int userId = -1;
		if (userIdStr != null) {
			userId = Integer.parseInt(userIdStr);
		}
		// userStatus默认是0 、待审核1、 已通过2、 已拒绝3
		int userStatus = 3;
		int i = userDao.rejectUserRequest(userId, userStatus);

		Result<String> result = Result.error(CodeMsg.NOT_FIND_DATA, "userId:" + userId);
		if (i > 0) {
			result = Result.success(new String("审核拒绝！" + "userId:" + userId));
		}
		return result;
	}
	
	
	/**
	 * 批量审批不通过
	 * 
	 * @return
	 */
	@RequestMapping("rejectBatchUserRequest.do")
	@ResponseBody
	public Result<String> rejectBatchUserRequest(HttpServletRequest request, HttpServletResponse response) {
		String[] userIdListstr=request.getParameterValues("userIdList[]");
		List<Integer> userIdList=new ArrayList<Integer>();
		if(userIdListstr!=null&&userIdListstr.length>0) {
			for(String userIdStr:userIdListstr) {
				userIdList.add(Integer.parseInt(userIdStr));
			}
		}
		
		// userStatus默认是0 、待审核1、 已通过2、 已拒绝3
		int userStatus = 3;
		int i = userDao.rejectBatchUserRequest(userIdList, userStatus);

		Result<String> result = Result.error(CodeMsg.NOT_FIND_DATA, "userIdList:" + userIdList);
		if (i > 0) {
			result = Result.success(new String("审核拒绝！" + "userIdList:" + userIdList));
		}
		return result;
	}

}
