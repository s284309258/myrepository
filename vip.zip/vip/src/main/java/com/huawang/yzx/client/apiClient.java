package com.huawang.yzx.client;

import com.alibaba.fastjson.JSONObject;
import com.huawang.yzx.util.HttpClientUtil;

public class apiClient {

	public static String sendSms(String templateid,String mobile,String param) {
		String sid = "750d072f1e7897cf63608289f029853a";
		String token = "8912066087885de90220b45c18fd291c";
		String appid = "3988f3a71e5e44e99e99fe5309ee4c2f";
		String uid = "";
		//param = "258639";
		//templateid = "452906";//短信模板编号
		//mobile = "15013795215";//手机号
		String result = "";
		try {
			String url ="https://open.ucpaas.com/ol/sms/sendsms";  
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("sid", sid);
			jsonObject.put("token", token);
			jsonObject.put("appid", appid);
			jsonObject.put("templateid", templateid);
			jsonObject.put("param", param);
			jsonObject.put("mobile", mobile);
			jsonObject.put("uid", uid);
			String body = jsonObject.toJSONString();
			System.out.println("body = " + body);
			result = HttpClientUtil.postJson(url, body, null);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static void main(String[] args) {
		sendSms("452907", "15013795215", "258639");
	}
	
}
