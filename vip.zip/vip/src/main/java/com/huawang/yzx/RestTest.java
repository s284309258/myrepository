/**
 * @author Tony
 * @date 2018-01-10
 * @project rest_demo
 */
package com.huawang.yzx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.lang.StringUtils;

import com.huawang.yzx.client.AbsRestClient;
import com.huawang.yzx.client.JsonReqClient;


public class RestTest {

	static AbsRestClient InstantiationRestAPI() {
		return new JsonReqClient();
	}
	
	public static void testSendSms(String sid, String token, String appid, String templateid, String param, String mobile, String uid){
		try {
			String result=InstantiationRestAPI().sendSms(sid, token, appid, templateid, param, mobile, uid);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void testSendSmsBatch(String sid, String token, String appid, String templateid, String param, String mobile, String uid){
		try {
			String result=InstantiationRestAPI().sendSmsBatch(sid, token, appid, templateid, param, mobile, uid);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void testAddSmsTemplate(String sid, String token, String appid, String type, String template_name, String autograph, String content){
		try {
			String result=InstantiationRestAPI().addSmsTemplate(sid, token, appid, type, template_name, autograph, content);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	
	public static void testGetSmsTemplate(String sid, String token, String appid, String templateid, String page_num, String page_size){
		try {
			String result=InstantiationRestAPI().getSmsTemplate(sid, token, appid, templateid, page_num, page_size);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void testEditSmsTemplate(String sid, String token, String appid, String templateid, String type, String template_name, String autograph, String content){
		try {
			String result=InstantiationRestAPI().editSmsTemplate(sid, token, appid, templateid, type, template_name, autograph, content);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void testDeleterSmsTemplate(String sid, String token, String appid, String templateid){
		try {
			String result=InstantiationRestAPI().deleterSmsTemplate(sid, token, appid, templateid);
			System.out.println("Response content is: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * 测试说明  启动main方法后，请在控制台输入数字(数字对应 相应的调用方法)，回车键结束
	 * 参数名称含义，请参考rest api 文档
	 * @throws IOException 
	 * @method main
	 * 
	 * body = {"appid":"3988f3a71e5e44e99e99fe5309ee4c2f","page_num":"","templateid":"","sid":"750d072f1e7897cf63608289f029853a","token":"8912066087885de90220b45c18fd291c","page_size":""}
		Response content is: {"code":"000000","msg":"OK","report":[
		{"autograph":"云之讯","content":"感谢您的注册，本次注册验证码为{1}，请于3分钟内正确输入，切勿泄露他人。（仅供参考）","create_date":"2019-04-09 10:42:00",
		"examine":"2","locked":"0","npreason":"","template_name":"验证测试模板","templateid":"452906","type":"4","update_date":"2019-04-09 10:42:00"},
		
		{"autograph":"云之讯","content":"尊敬的用户，您已成功报名我司的活动，请准时参加。（仅供参考）","create_date":"2019-04-09 10:42:00","examine":"2","locked":"0","npreason":"",
		"template_name":"通知短信测试模板","templateid":"452907","type":"0","update_date":"2019-04-09 10:42:00"}
		]}
	 * 
	 * 
	 */
	public static void main(String[] args) throws IOException{
		
		System.out.println("请输入方法对应的数字(例如1),Enter键结束:");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String methodNumber = br.readLine();
		
		if (StringUtils.isBlank(methodNumber)){
			System.out.println("请输入正确的数字，不可为空");
			return;
		}
		
		if (methodNumber.equals("1")) {  //指定模板单发
			String sid = "750d072f1e7897cf63608289f029853a";
			String token = "8912066087885de90220b45c18fd291c";
			String appid = "3988f3a71e5e44e99e99fe5309ee4c2f";
			String templateid = "452907";
			String param = "";
			String mobile = "15013795215";
			String uid = "";
			testSendSms(sid, token, appid, templateid, param, mobile, uid);
		} else if (methodNumber.equals("2")) { //指定模板群发
			String sid = "";
			String token = "";
			String appid = "";
			String templateid = "";
			String param = "";
			String mobile = "";
			String uid = "";
			testSendSmsBatch(sid, token, appid, templateid, param, mobile, uid);
		} else if (methodNumber.equals("3")) {  //增加模板
			String sid = "750d072f1e7897cf63608289f029853a";
			String token = "8912066087885de90220b45c18fd291c";
			String appid = "3988f3a71e5e44e99e99fe5309ee4c2f";
			String type = "4";
			String template_name = "注册验证";
			String autograph = "深圳华望";
			String content = "您的验证码是{123456}";
			testAddSmsTemplate(sid, token, appid, type, template_name, autograph, content);
		} else if (methodNumber.equals("4")) {  //查询模板
			String sid = "750d072f1e7897cf63608289f029853a";
			String token = "8912066087885de90220b45c18fd291c";
			String appid = "3988f3a71e5e44e99e99fe5309ee4c2f";
			String templateid = "";
			String page_num = "";
			String page_size = "";
			testGetSmsTemplate(sid, token, appid, templateid, page_num, page_size);
		} else if (methodNumber.equals("5")) {  //编辑模板
			String sid = "";
			String token = "";
			String appid = "";
			String templateid = "";
			String type = "";
			String template_name = "";
			String autograph = "";
			String content = "";
			testEditSmsTemplate(sid, token, appid, templateid, type, template_name, autograph, content);
		} else if (methodNumber.equals("6")) {  //删除模板
			String sid = "";
			String token = "";
			String appid = "";
			String templateid = "";
			testDeleterSmsTemplate(sid, token, appid, templateid);
		} 	
	}
}
