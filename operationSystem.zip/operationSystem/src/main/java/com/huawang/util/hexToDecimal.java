package com.huawang.util;

/**
 * 16进制转10进制类
 * @author Administrator
 *
 */
public class hexToDecimal {

			public static void main(String[] args) {
				String s="0x02";
				System.out.println("获取10进制数："+hexToTen(s));
			} 
		    
		    
			public static int getRealValue(char c){
				int n=0;
				if(c>='a'&&c<='f') n=c-'a'+10;
				if(c>='A'&&c<='F') n=c-'A'+10;
				if(c>='0'&&c<='9') n=c-'0';
				return n;
			}
			//16进制转10进制
			public static int hexToTen(String s){
				int m=0;
				for(int i=0;i<s.length();i++){
					System.out.println("16*"+m+"   getRealValue(s.charAt(i)   "+getRealValue(s.charAt(i)));
					m=16*m+getRealValue(s.charAt(i));
				}
				return m;
			}
}
