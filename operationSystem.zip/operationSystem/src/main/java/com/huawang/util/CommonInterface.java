package com.huawang.util;

import java.util.ArrayList;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.huawang.timer.RemainUseTimerTask;

public class CommonInterface 
{
	static Logger logger = LogManager.getLogger(RemainUseTimerTask.class.getName());
	
	/***
	 * 生成(plus单(叠加单),plus+single单,single单(普通单))
	 * @param orderid
	 * @return 
	 * @throws Exception
	 */
	public static String GenerateBillRecord(String orderid) throws Exception
	{
		logger.info("GenerateBillRecord(String orderid)");
		ArrayList<Map<String,Object>> list = Sqlca.getArrayListFromMap("select o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,o_SignRadio,o_Type from t_order where id="+orderid);
		Map<String,Object> map = list.get(0);
		String o_CompID = (String)map.get("o_CompID");
		String o_Product = (String)map.get("o_Product");
		String o_MaxUserCount = (String)map.get("o_MaxUserCount");
		String o_CreateDate = DateUtil.getDateYMD((String)map.get("o_CreateDate"),"00:00:00");
		String o_EndDate = DateUtil.getDateYMD((String)map.get("o_EndDate"),"23:59:59");
		String o_SignRadio = (String)map.get("o_SignRadio");
		String o_Type = (String)map.get("o_Type");
		
		ArrayList<Map<String,Object>> complist = Sqlca.getArrayListFromMap("select ContractEndTime,EndDate,CreateDate,ProductID,MaxUserCount from t_compinfo where CompID="+o_CompID);
		String ContractEndTime = DateUtil.getDateYMD((String)complist.get(0).get("ContractEndTime"),"23:59:59");
		String EndDate = DateUtil.getDateYMD((String)complist.get(0).get("EndDate"),"23:59:59");
		String CreateDate = DateUtil.getDateYMD((String)complist.get(0).get("CreateDate"),"00:00:00");
		String BillNo = "B"+o_CompID+DateUtil.dateFormat("YYYYMMddHHmmss");
		String ProductID = (String)complist.get(0).get("ProductID");
		String CompMaxUserCount = (String)complist.get(0).get("MaxUserCount");
		if("".equals(CompMaxUserCount)) {CompMaxUserCount=o_MaxUserCount;}
		
		if("4".equals(o_SignRadio))
		{
			Sqlca.updateObject("update t_validbill set CreateDate='2099-01-01 00:00:00',EndDate='2099-01-01 23:59:59' where OrderID in(" + 
					"(select id from t_order where id in(select id from  (select id from t_order where o_compid=? and id <>?) t)))", new String[] {o_CompID,orderid});
			
			Sqlca.updateObject("update t_order set o_Status=5 where id in(select id from "
					+ " (select id from t_order where o_compid=? and id <>?) t)", new String[] {o_CompID,orderid});
		}
		if("3".equals(o_SignRadio))
		{
			Sqlca.updateObject("update t_validbill set CreateDate='2099-01-01 00:00:00',EndDate='2099-01-01 23:59:59' where OrderID in(" + 
					"select id from t_order where id in(select id from  (select id from t_order where o_compid=? and o_type=2 and id <>?) t))", new String[] {o_CompID,orderid});
			
			Sqlca.updateObject("update t_order set o_Status=5 where id in(select id from "
					+ " (select id from t_order where o_compid=? and o_type=2 and id <>?) t)", new String[] {o_CompID,orderid});
		}
//		String CompStatus = Sqlca.getString("select CompStatus from t_compinfo where CompID="+o_CompID);
		
		if("".equals(ContractEndTime))
		{
			if("2".equals(o_Type))
			{
				Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
//				Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
//						new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"plus",BillNo,CompMaxUserCount,orderid});
				Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
						new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"single",BillNo,CompMaxUserCount,orderid});
				
				Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
						new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,BillNo,"plus",BillNo,CompMaxUserCount,orderid});
			}
			else
			{
				Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
						new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"single",BillNo,CompMaxUserCount,orderid});
			}
		}
		else
		{
			String RelateBillNo = Sqlca.getString("select BillNO from t_validbill where CompID="+o_CompID+" ORDER BY ID DESC LIMIT 1");
			if(RelateBillNo==null) {RelateBillNo=BillNo;}
			if(o_CreateDate.compareTo(ContractEndTime)<0 && o_EndDate.compareTo(ContractEndTime)>=0)
			{
				if("2".equals(o_Type))
				{
					Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
					
					if("2".equals(o_SignRadio))
					{
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
					}
					else if("3".equals(o_SignRadio))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else if("4".equals(o_SignRadio))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else if("1".equals(o_SignRadio))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					}
					CommonInterface.UpdateCompStatus(o_CompID, "1");
				}
				else if("3".equals(o_Type))
				{
					
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					
					CommonInterface.UpdateCompStatus(o_CompID, "10");
				}
				else
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
				}
				
			}
			else if(DateUtil.getDateYMD(ContractEndTime, "23:59:59").compareTo(DateUtil.getDateYMD(o_EndDate, "23:59:59"))>=0)
			{
				if("2".equals(o_Type))
				{
					Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
					
					if("2".equals(o_SignRadio))
					{
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else if("4".equals(o_SignRadio))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else if("3".equals(o_SignRadio))
					{
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
						
						CommonInterface.UpdateCompStatus(o_CompID, "10");
					}
					else if("1".equals(o_SignRadio))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					}
					else
					{
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					}
					
					CommonInterface.UpdateCompStatus(o_CompID, "1");
				}
				else if("3".equals(o_Type))
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
					
					CommonInterface.UpdateCompStatus(o_CompID, "10");
				}
				else
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
				}
			}
			else
			{
				if("2".equals(o_Type))
				{
					Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
					Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
					CommonInterface.UpdateCompStatus(o_CompID, "1");
				}
				if("3".equals(o_Type))
				{
					CommonInterface.UpdateCompStatus(o_CompID, "10");
				}
				
				if("2".equals(o_Type) && "2".equals(o_SignRadio))
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
				}
				if("2".equals(o_Type) && "3".equals(o_SignRadio))
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
				}
				if("2".equals(o_Type) && "4".equals(o_SignRadio))
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
				}
				if("2".equals(o_Type) && "1".equals(o_SignRadio))
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
					
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,orderid});
				}
				else
				{
					Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
							new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
				}
				
			}
		}
 		return "success";
	}
	
	
	/***
	 * 只生成单据single单(普通单)
	 * @param orderid
	 * @param xx 任意整数都行
	 * @return
	 * @throws Exception
	 */
	public static String GenerateBillRecord(String orderid,int xx) throws Exception
	{
		logger.info("GenerateBillRecord(String orderid,int xx)");
		ArrayList<Map<String,Object>> list = Sqlca.getArrayListFromMap("select o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID from t_order where id="+orderid);
		Map<String,Object> map = list.get(0);
		String o_CompID = (String)map.get("o_CompID");
		String o_Product = (String)map.get("o_Product");
		String o_MaxUserCount = (String)map.get("o_MaxUserCount");
		String o_CreateDate = DateUtil.getDateYMD((String)map.get("o_CreateDate"),"00:00:00");
		String o_EndDate = DateUtil.getDateYMD((String)map.get("o_EndDate"),"23:59:59");
		
		ArrayList<Map<String,Object>> complist = Sqlca.getArrayListFromMap("select ContractEndTime,EndDate,CreateDate,ProductID,MaxUserCount from t_compinfo where CompID="+o_CompID);
		String ContractEndTime = DateUtil.getDateYMD((String)complist.get(0).get("ContractEndTime"),"23:59:59");
		String EndDate = DateUtil.getDateYMD((String)complist.get(0).get("EndDate"),"23:59:59");
		String CreateDate = DateUtil.getDateYMD((String)complist.get(0).get("CreateDate"),"00:00:00");
		String BillNo = "B"+o_CompID+DateUtil.dateFormat("YYYYMMddHHmmss");
		String ProductID = (String)complist.get(0).get("ProductID");
		String CompMaxUserCount = (String)complist.get(0).get("MaxUserCount");
		if("".equals(CompMaxUserCount)) {CompMaxUserCount=o_MaxUserCount;}
		if("".equals(EndDate))
		{
			Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
					new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"single",BillNo,CompMaxUserCount,orderid});
		}
		else
		{
			String RelateBillNo = Sqlca.getString("select MAX(BillNO) BillNO from t_validbill where CompID="+o_CompID);
			if(RelateBillNo==null || "".equals(RelateBillNo)) {RelateBillNo=BillNo;}
			Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
					new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,orderid});
		}
		
		return "success";
	}
	
	
	public static String UpdateStatusUsing(String OrderID) throws Exception
	{
		logger.info("UpdateStatusUsing(String CompID1)");
//		String selBill = "select ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo from t_validbill where BillNo IN (" + 
//				"select MAX(BillNo) from t_validbill " + 
//				" where SUBSTR(CreateDate,1,10)='"+DateUtil.dateFormat(0)+"' and CompID="+CompID1 + 
//				")  AND SUBSTR(CreateDate,1,10)='"+DateUtil.dateFormat(0)+"'";
		String selBill = "select ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo from t_validbill where OrderID="+OrderID;
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(selBill);
		if(list.size()>0)
		{
			for(Map<String, Object> map : list)
			{
				String ProductID = (String)map.get("ProductID");
				String MaxUserCount = (String)map.get("MaxUserCount");
				String CreateDate = (String)map.get("CreateDate");
				String EndDate = (String)map.get("EndDate");
				String CompID = (String)map.get("CompID");
				String RelateBillNo = (String)map.get("RelateBillNo");
				String BillType = (String)map.get("BillType");
				String BillNo = (String)map.get("BillNo");
//				String sql = "select EndDate from t_validbill where CompID= "+CompID+" and SUBSTR(EndDate,1,10)>'"+DateUtil.dateFormat(0,0)+"' and SUBSTR(EndDate,1,10)<>'2099-01-01' ORDER BY EndDate";
				String sql = "select min(o_EndDate) from t_order where o_CompID="+CompID+" and o_Status=1";
				String RecentlyEndDate = Sqlca.getString(sql);
				if(RecentlyEndDate==null) {RecentlyEndDate=EndDate;}
				if("plus".equals(BillType) && !"2010-10-10 00:00:00".equals(CreateDate))
				{
					Sqlca.updateObject("update t_compinfo SET MaxUserCount=(case when MaxUserCount is null then "+MaxUserCount+" else MaxUserCount+"+MaxUserCount+" end),ProductID="+ProductID+","
							+ " CreateDate=(CASE WHEN CreateDate IS NULL THEN '"+CreateDate+"' else CreateDate END ),EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
					
					Sqlca.updateObject("update t_compinfo_product set productId="+ProductID+",productProperty=2,productCount=0 where compId=?", new String[] {CompID});
					
					Sqlca.updateObject("update t_confinfo set ProductType="+ProductID+" where CompID=?", new String[] {CompID});
					
				}
				if("single".equals(BillType))
				{
					Sqlca.updateObject("update t_compinfo SET MaxUserCount="+MaxUserCount+",ProductID="+ProductID+","
							+ " CreateDate=(CASE WHEN CreateDate IS NULL THEN '"+CreateDate+"' else CreateDate END ),EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
					
					String productId = Sqlca.getString("select productId from t_compinfo_product where compId="+CompID);
					if(productId==null) 
					{
						Sqlca.updateObject("INSERT INTO t_compinfo_product(compid,productid,productcount,productproperty) " + 
								" VALUES(?,?,?,?)", new String[] {CompID,ProductID,"0","2"});
					}
					else
					{
						Sqlca.updateObject("update t_compinfo_product set productId="+ProductID+",productProperty=2,productCount=0 where compId=?", new String[] {CompID});
						Sqlca.updateObject("update t_confinfo set ProductType="+ProductID+" where CompID=?", new String[] {CompID});
					}
				}
			}
		}
		
		return "success";
	}
	
	
	//更新客户公司状态
	public static String UpdateCompStatus(String CompID) throws Exception
	{
		logger.info("update UpdateCompStatus execute");
		////延期日期到期
		String compstatus2 = "1";
		String updatesql2 = "select CompID,ContractEndTime,CreateDate,EndDate,CompStatus from t_compinfo where CompID="+CompID;
		
		ArrayList<Map<String, Object>> list2 = Sqlca.getArrayListFromMap(updatesql2);
		Map<String,Object> map2 = list2.get(0);
		String ContractEndTime2 = (String)map2.get("ContractEndTime");
		String EndDate2 = (String)map2.get("EndDate");
		String CreateDate2 = (String)map2.get("CreateDate");
		String CurrentDate = DateUtil.getDateYMD(DateUtil.dateFormat(0), "00:00:00");
		String temptatus = (String)map2.get("CompStatus");
		
		if(ContractEndTime2!=null && !"".equals(ContractEndTime2))
		{
			if(CurrentDate.compareTo(ContractEndTime2)>0)
			{
				compstatus2="6";
			}
			else
			{
				if("10".equals(temptatus))
				{
					if(CurrentDate.compareTo(EndDate2)<0)
					{
						compstatus2="10";
					}
				}
				else
				{
					compstatus2="1";
				}
			}
		}
		else
		{
			if(CurrentDate.compareTo(EndDate2)>0)		
			{
				compstatus2 = "8";
			}
			else
			{
				compstatus2 = "5";
			}
		}
		
		Sqlca.updateObject("update t_compinfo set CompStatus="+compstatus2+" where CompID=?", new String[] {CompID});
		
		return compstatus2;
	}
	
	//更新客户公司状态
	public static String UpdateCompStatus(String CompID,int xx) throws Exception
	{
		logger.info("update UpdateCompStatus execute");
		////延期日期到期
		String compstatus2 = "1";
		String updatesql2 = "select CompID,ContractEndTime,CreateDate,EndDate,CompStatus from t_compinfo where CompID="+CompID;
		
		ArrayList<Map<String, Object>> list2 = Sqlca.getArrayListFromMap(updatesql2);
		Map<String,Object> map2 = list2.get(0);
		String ContractEndTime2 = (String)map2.get("ContractEndTime");
		String EndDate2 = (String)map2.get("EndDate");
		String CreateDate2 = (String)map2.get("CreateDate");
		String CurrentDate = DateUtil.getDateYMD(DateUtil.dateFormat(0), "00:00:00");
		String temptatus = (String)map2.get("CompStatus");
		
		if(ContractEndTime2!=null && !"".equals(ContractEndTime2))
		{
			if(CurrentDate.compareTo(ContractEndTime2)>0)
			{
				compstatus2="6";
			}
			else
			{
				compstatus2="1";
			}
		}
		else
		{
			if(CurrentDate.compareTo(EndDate2)>0)		
			{
				compstatus2 = "8";
			}
			else
			{
				compstatus2 = "5";
			}
		}
		
		Sqlca.updateObject("update t_compinfo set CompStatus="+compstatus2+" where CompID=?", new String[] {CompID});
		
		return "success";
	}
	
	//更新客户公司状态
	public static String UpdateCompStatus(String CompID,String status) throws Exception
	{
		logger.info("update UpdateCompStatus(String CompID,String status) execute");
		
		Sqlca.updateObject("update t_compinfo set CompStatus="+status+" where CompID=?", new String[] {CompID});
		
		return "success";
	}
	
	public static String UpdateStatuUsingSign(String orderid) throws Exception
	{
		String sql = "select o_CompID,o_Product,o_CreateDate,o_EndDate,o_MaxUserCount from t_order where ID="+orderid;
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		Map<String, Object> map = list.get(0);
		
		String o_CompID = (String)map.get("o_CompID");
		String o_EndDate = (String)map.get("o_EndDate");
		Sqlca.updateObject("UPDATE t_compinfo SET ContractEndTime='"+o_EndDate+"' where CompID=? ", new String[] {o_CompID});
		
		return "success";
	}
	
	
	public static String OverSignOrderUsing(String CompID,String OrderID) throws Exception
	{
		
		Sqlca.updateObject("update t_validbill set EndDate='2099-01-01 23:59:59' where OrderID=?", new String[] {OrderID});
		
		String sqlenddate = "select min(o_EndDate) from t_order where o_CompID="+CompID+" and o_Status=1";
		String RecentlyEndDate = Sqlca.getString(sqlenddate);
		if(RecentlyEndDate==null) {RecentlyEndDate= DateUtil.dateFormat(-1, 0);}
		String signdate = Sqlca.getString("select max(o_EndDate) from t_order where o_CompID="+CompID+" and o_Type=2 and o_Status=1 and id<>"+OrderID);
		if(signdate!=null)
		{
			String sql = " select sum(MaxUserCount) from t_validbill where OrderID in(" + 
			" select id from t_order where o_CompID="+CompID+" and OrderID<>"+OrderID+" and o_status=1 and CreateDate<>'2010-10-10 00:00:00' and EndDate<>'2099-01-01 23:59:59'" + 
			" )";
			String SumMaxUserCount = Sqlca.getString(sql);
			Sqlca.updateObject("update t_compinfo set MaxUserCount=?,EndDate=?,ContractEndTime=? where CompID=?", new String[] {SumMaxUserCount,RecentlyEndDate,signdate,CompID});
		}
		else
		{
			String maxenddatesql = "select MAX(o_EndDate) from t_order where o_CompID="+CompID+" and o_Type=2 and id<>"+OrderID;
			String maxenddate = Sqlca.getString(maxenddatesql);
			
			String sql1 = " select sum(MaxUserCount) from t_validbill where OrderID in(" + 
					" select id from t_order where o_CompID="+CompID+" and OrderID<>"+OrderID+" and o_status=1 and CreateDate<>'2010-10-10 00:00:00' and EndDate<>'2099-01-01 23:59:59' and o_type<>3" + 
					" )";
			String o_MaxUserCount = Sqlca.getString(sql1);
			
			if(maxenddate==null)
			{
				Sqlca.updateObject("update t_compinfo set MaxUserCount="+o_MaxUserCount+",EndDate=?,ContractEndTime=null where CompID=?", new String[] {RecentlyEndDate,CompID});
			}
			else
			{
				Sqlca.updateObject("update t_compinfo set MaxUserCount="+o_MaxUserCount+",EndDate=?,ContractEndTime="+maxenddate+" where CompID=?", new String[] {RecentlyEndDate,CompID});
			}
		}
		return "success";
	}
		
}
