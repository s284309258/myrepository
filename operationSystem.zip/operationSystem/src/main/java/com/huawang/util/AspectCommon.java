package com.huawang.util;


import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.interceptor.LoginInterceptor;
import com.huawang.pojo.meetingRoom.TAdmininfo;

@Aspect
@Component
public class AspectCommon {
	static Logger logger = LogManager.getLogger(LoginInterceptor.class.getName());
	
	private String requestPath = null ; // 请求地址  
    private String userName = null ; // 用户名  
    private String result = null;
    private long startTimeMillis = 0; // 开始时间  
    private long endTimeMillis = 0; // 结束时间  
    
    @Before("execution(* com.huawang.controller..*.*(..))")
    public void doBeforeInServiceLayer(JoinPoint joinPoint) {  
        startTimeMillis = System.currentTimeMillis(); // 记录方法开始执行的时间  
    }
    @After("execution(* com.huawang.controller..*.*(..))")
    public void doAfterInServiceLayer(JoinPoint joinPoint) {  
        endTimeMillis = System.currentTimeMillis(); // 记录方法执行完成的时间  
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();  
        ServletRequestAttributes sra = (ServletRequestAttributes)ra;  
        HttpServletRequest request = sra.getRequest(); 
        HttpServletResponse response = sra.getResponse();
        requestPath  = request.getRequestURI();
        result = joinPoint.toString();
        //打印登录、请求、耗时日志
        logger.info("\n aspectAdvice->loginUser:"+userName+";  requestPath:"+requestPath+";  costtime:"+(endTimeMillis-startTimeMillis)
    			+"ms;  access:"+result
    			);
        
    }
    
    /**
      * 防止用户多点登录
     * @param request
     * @param response
     * @param user
     * @return 返回true表示正在进行多点登录，false表示正常登录
     */
    public boolean preventLoginOnLogining(HttpServletRequest request) {
    	HttpSession session = request.getSession();
    	ServletContext application = session.getServletContext();
    	Map<String,String> loginMap = (Map<String,String>)application.getAttribute("loginMap");
    	if(loginMap == null) {
    		loginMap = new HashMap<String,String>();
    	}
    	
    	Object obj = session.getAttribute("USER_SESSION");
        TAdmininfo user = null;
        if(obj!=null) {
      	   user = (TAdmininfo)obj;
      	    //防止多点登录，如果有用户登录当前用户被挤下线
        }
    	
    	for(String key : loginMap.keySet()) {
    		if(user!=null) {
    			if(user.getAdminName().equals(key)) {
    				//用户登录正常
    	    		if(session.getId().equals(loginMap.get(key))) {
    	    		
    	    		}else {
    	    			logger.info("\n aspectAdvice->other the same user has been down line");
    	    			return true;
    	    			//不同浏览器登录,挤掉前面登录的用户
    	    		}
    			}
    		}
    	}
    	return false;
    	
    }
    
//    @Around("execution(* com.huawang.controller..*.*(..)) "
//    		+ "and !execution(* com.huawang.controller.UserLogin.LoginController.userLogin(..))")
//    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
//    	RequestAttributes ra = RequestContextHolder.getRequestAttributes();  
//    	
//        ServletRequestAttributes sra = (ServletRequestAttributes)ra;  
//        HttpServletRequest request = sra.getRequest(); 
//        HttpServletResponse response = sra.getResponse();
//        Object obj = request.getSession().getAttribute("USER_SESSION");
//        if(obj==null) {
////        	return request.getContextPath();        
//        	return new ModelAndView("index/loginhuaw");
////        	response.sendRedirect("redirect:index/loginhuaw");
//        }
//        
//        if(preventLoginOnLogining(request)) {
////        	return request.getContextPath();
//        	return new ModelAndView("index/loginhuaw");
//        }
//        
//        return pjp.proceed();
//    }
    
}
