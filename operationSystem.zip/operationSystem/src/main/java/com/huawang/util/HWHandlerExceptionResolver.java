package com.huawang.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.druid.support.json.JSONUtils;


public class HWHandlerExceptionResolver implements HandlerExceptionResolver{

	Logger logger = LogManager.getLogger(HWHandlerExceptionResolver.class.getName());
	@Override
	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		
		logger.info(ex.getMessage());
		// 判断是否ajax请求(非ajax请求)
        if (!(request.getHeader("accept").indexOf("application/json") > -1 || (request
                .getHeader("X-Requested-With") != null && request.getHeader(
                "X-Requested-With").indexOf("XMLHttpRequest") > -1))) {
        	
        	response.setContentType("text/html; charset=UTF-8");
        	
            try {
				PrintWriter writer = response.getWriter();
				writer.flush();
				writer.write(ex.getMessage());
            } catch (IOException e) {
				e.printStackTrace();
			}
            logger.info("No ajax request HWHandlerExceptionResolver");
        	
        } else {
            // 如果是ajax请求，JSON格式返回
            try {
                response.setContentType("application/json;charset=UTF-8");
                PrintWriter writer = response.getWriter();
                writer.write(ex.getMessage());
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            logger.info("ajax request HWHandlerExceptionResolver");
        }
        ex.printStackTrace();
		return null;
	}

}
