package com.huawang.util;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

public class SecurityUtil {
	
	
	/** 
    * 定义加密方式 
     */  
    private final static String KEY_SHA = "SHA";  
    private final static String KEY_SHA1 = "SHA-1";
    
    /** 
     * 全局数组 
     */  
    private final static String[] hexDigits = { "0", "1", "2", "3", "4", "5",  
            "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };  
  
    /** 
     * SHA 加密 
     * @param data 需要加密的字节数组 
     * @return 加密之后的字节数组 
     * @throws Exception 
     */  
    private static byte[] encryptSHA(byte[] data) throws Exception {  
        // 创建具有指定算法名称的信息摘要  
//        MessageDigest sha = MessageDigest.getInstance(KEY_SHA);  
        MessageDigest sha = MessageDigest.getInstance(KEY_SHA1);  
        // 使用指定的字节数组对摘要进行最后更新  
        sha.update(data);  
        // 完成摘要计算并返回  
        return sha.digest();  
    }  
  
    /** 
     * SHA 加密 
     * @param data 需要加密的字符串 
     * @return 加密之后的字符串 
     * @throws Exception 
     */  
    private static String encryptSHA(String data) throws Exception {  
        // 验证传入的字符串  
        if (data == null || data.equals("")) {  
            return "";  
        }  
        // 创建具有指定算法名称的信息摘要  
        MessageDigest sha = MessageDigest.getInstance(KEY_SHA);  
        // 使用指定的字节数组对摘要进行最后更新  
        sha.update(data.getBytes());  
        // 完成摘要计算  
        byte[] bytes = sha.digest();  
        // 将得到的字节数组变成字符串返回  
        return byteArrayToHexString(bytes);  
    }  
  
    /** 
     * 将一个字节转化成十六进制形式的字符串 
     * @param b 字节数组 
     * @return 字符串 
     */  
    private static String byteToHexString(byte b) {  
        int ret = b;  
        //System.out.println("ret = " + ret);  
        if (ret < 0) {  
            ret += 256;  
        }  
        int m = ret / 16;  
        int n = ret % 16;  
        return hexDigits[m] + hexDigits[n];  
    }  
  
    /** 
     * 转换字节数组为十六进制字符串 
     * @param bytes 字节数组 
     * @return 十六进制字符串 
     */  
    private static String byteArrayToHexString(byte[] bytes) {  
        StringBuffer sb = new StringBuffer();  
        for (int i = 0; i < bytes.length; i++) {  
            sb.append(byteToHexString(bytes[i]));  
        }  
        return sb.toString();  
    }
    
    
    public static String encryptMD5(String str) throws Exception {
    	/* try {
   	 // 生成一个MD5加密计算摘要
   	 MessageDigest md = MessageDigest.getInstance("MD5");
   	 // 计算md5函数
   	 md.update(str.getBytes());
   	 // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
   	 // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
   	 return new BigInteger(1, md.digest()).toString(16);
   	 } catch (Exception e) {
   		 throw new Exception("MD5加密出现错误");
   	 }*/
   	 String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString();
        } catch (NoSuchAlgorithmException e) {
            //System.out.println(e);
        }
        return result;
   	
   	
   	
   }

	/** 
	 * 加密 
	 * @param key 需要加密的字符串 
	 */  
    private static String passWordEncrypt(String key) throws Exception{  
		byte[] decode = Base64.getDecoder().decode(BasicDataUtil.privateKey);  
		PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(decode);  
		KeyFactory kf = KeyFactory.getInstance(BasicDataUtil.algorithm);  
		PrivateKey generatePrivate = kf.generatePrivate(pkcs8EncodedKeySpec);  
		Cipher ci = Cipher.getInstance(BasicDataUtil.algorithm);  
		ci.init(Cipher.ENCRYPT_MODE, generatePrivate);  

		byte[] bytes = key.getBytes();  
		int inputLen = bytes.length;  
		int offLen = 0;//偏移量  
		int i = 0;  
		ByteArrayOutputStream bops = new ByteArrayOutputStream();  
		while(inputLen - offLen > 0){  
			byte [] cache;  
			if(inputLen - offLen > 117){  
				cache = ci.doFinal(bytes, offLen,117);  
			}else{  
				cache = ci.doFinal(bytes, offLen,inputLen - offLen);  
			}  
			bops.write(cache);  
			i++;  
			offLen = 117 * i;  
		}  
		bops.close();  
		byte[] encryptedData = bops.toByteArray();  
		String encodeToString = Base64.getEncoder().encodeToString(encryptedData);  
		return encodeToString;  
	}  
    
    public static void main(String[] args) throws Exception {
    	System.out.println(passWordEncrypt("admin"));
	}




	/** 
	 * 解密 
	 * @param data 需要解密的字符串
	 */  
    private static String passWordDecrypt(String data) throws Exception{  
		byte[] decode = Base64.getDecoder().decode(BasicDataUtil.publicKey);  
		//      PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(decode); //java底层 RSA公钥只支持X509EncodedKeySpec这种格式  
		X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(decode);  
		KeyFactory kf = KeyFactory.getInstance(BasicDataUtil.algorithm);  
		PublicKey generatePublic = kf.generatePublic(x509EncodedKeySpec);  
		Cipher ci = Cipher.getInstance(BasicDataUtil.algorithm);  
		ci.init(Cipher.DECRYPT_MODE,generatePublic);  

		byte[] bytes = Base64.getDecoder().decode(data);  
		int inputLen = bytes.length;  
		int offLen = 0;  
		int i = 0;  
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();  
		while(inputLen - offLen > 0){  
			byte[] cache;  
			if(inputLen - offLen > 128){  
				cache = ci.doFinal(bytes,offLen,128);   
			}else{  
				cache = ci.doFinal(bytes,offLen,inputLen - offLen);  
			}  
			byteArrayOutputStream.write(cache);  
			i++;  
			offLen = 128 * i;  

		}  
		byteArrayOutputStream.close();  
		byte[] byteArray = byteArrayOutputStream.toByteArray();  
		return new String(byteArray);  
	}
}
