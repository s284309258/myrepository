package com.huawang.util;

public class MsgtUtil {

	private Integer code;
	private String msg="";
	private Long count=0L;
	private Object data;
	
	/**
	 * @return the code
	 */
	public Integer getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(Integer code) {
		this.code = code;
	}
	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}
	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
	/**
	 * @return the count
	 */
	public Long getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(Long count) {
		this.count = count;
	}
	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}
	
	public static MsgtUtil ok(Object list){
		MsgtUtil result = new MsgtUtil();
		result.setCode(0);
		result.setData(list);;
		return result;
	}
	public static MsgtUtil ok(String msg){
		MsgtUtil result = new MsgtUtil();
		result.setCode(0);
		result.setMsg(msg);
		return result;
	}
	
}
