package com.huawang.util;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.jdbc.datasource.DataSourceUtils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.fastjson.JSON;

public class Sqlca {
	
	static Logger logger = LogManager.getLogger(Sqlca.class.getName());
	private static ServletContext sc = HWApplicationContextUtil.servletcontext;
	private static String osEncoding = sc.getInitParameter("osEncoding");
	
//	private static int ss = 0;
//	private static void setlatin1(Connection conn) throws SQLException 
//	{
//		if(ss==0) 
//		{
//			Statement sts = conn.createStatement();
//			sts.execute("set names latin1");
//			sts.close();
////			ss=1;
//		}
//	}
	
	public static Connection getConnection() {
		DruidDataSource dataSource = (DruidDataSource)HWApplicationContextUtil.context.getBean("dataSource");
		Connection conn = DataSourceUtils.getConnection(dataSource);
//		if("utf8".equals(osEncoding)) {
//			try {
//				setlatin1(conn);
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
		return conn;
	}
	
	/***
	 * 更新数据根据sql(参数用?作为占位符)和传过来的参数，参数只支持String
	 * @param sql
	 * @param objs
	 * @return
	 * @throws Exception
	 */
	public static int updateObject(String sql,String[] objs) throws Exception 
	{
		logger.info("Sqlca:sql->"+sql);
		objs = switchLatin1Encoding(objs);
		int cnt = 0;
		
		Connection conn = getConnection();
		PreparedStatement ps = conn.prepareStatement(sql);
		int len = objs.length;
		for(int i=1; i<=len; i++) 
		{
			ps.setString(i, objs[i-1]);
		}
		try 
		{
			cnt = ps.executeUpdate();
		}
		finally 
		{
			closeAll(conn,null,ps);
		}
		
		return cnt;
		
	}
	
	
	/***
	 * 更新数据根据sql(参数用?作为占位符)和传过来的参数，参数只支持String,可事务控制
	 * @param sql
	 * @param objs
	 * @return
	 * @throws Exception
	 */
	public static int updateObject(Connection conn,String sql,String[] objs) throws Exception 
	{
		logger.info("Sqlca:sql->"+sql);
		objs = switchLatin1Encoding(objs);
		int cnt = 0;
		PreparedStatement ps = conn.prepareStatement(sql);
		int len = objs.length;
		for(int i=1; i<=len; i++) 
		{
			ps.setString(i, objs[i-1]);
		}
		try 
		{
			cnt = ps.executeUpdate();
		}
		finally 
		{
			closeAll(null,null,ps);
		}
		
		return cnt;
		
	}
	
	
	/***
	 * 得到JOPO，只支持一条记录，如果多条取第一条
	 * @param sql
	 * @param clss 需要得到的对象class
	 * @return
	 * @throws Exception
	 */
	public static Object getObject(String sql,Class<?> clss) throws Exception 
	{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		Object obj = null;
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			if (rs.next()) 
			{
				obj = clss.newInstance();
				Field[] fields = obj.getClass().getFields();
				for(Field f : fields) 
				{
					String fieldname = f.getName();
					f.set(obj, switchUtf8Encoding(rs.getBytes(fieldname)));
				}
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		
		return obj;
	}
	
	/***
	 * 得到一个数据库字段，只支持查询一个字段，只返回第一条记录的一个字段
	 * @param sql
	 * @return String
	 * @throws Exception
	 */
	public static String getString(String sql) throws Exception 
	{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		String obj = null;
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			if (rs.next()) 
			{
				obj = switchUtf8Encoding(rs.getBytes(1));
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return obj;
	}
	
	/***
	 * 得到一个数据库字段，只支持查询一个字段，只返回第一条记录的一个字段
	 * @param sql
	 * @return String
	 * @throws Exception
	 */
	public static String getString(Connection conn,String sql) throws Exception 
	{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		String obj = null;
//		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			if (rs.next()) 
			{
				obj = switchUtf8Encoding(rs.getBytes(1));
			}
		}
		finally
		{
			closeAll(null,rs,ps);
		}
		return obj;
	}
	
	/***
	 * 得到多个数据库字段，拼接成一个String返回['String','String',],号隔开
	 * @param sql
	 * @return String
	 * @throws Exception
	 */
	public static StringBuffer getStringBuffer(String sql) throws Exception {
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		StringBuffer obj = new StringBuffer();
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while (rs.next()) 
			{
				obj = obj.append("'").append(switchUtf8Encoding(rs.getBytes(1))).append("'").append(",") ;
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return obj;
	}
	
	private static StringBuffer getStringBuffer(String sql,Connection conn) throws Exception {
		StringBuffer obj = new StringBuffer();
//		Connection conn = getConnection();
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) 
		{
			obj = obj.append("'").append(rs.getString(1)).append("'").append(",") ;
		}
		closeAll(null,rs,ps);
		return obj;
	}
	
	/**
	  * 返回ArrayList<Map> 将sql语句中的字段用map对象封装到ArrayList返回，默认数据源
	 * @param sql 
	 * @return ArrayList<Map<String,Object>>
	 * @throws Exception
	 */
	public static ArrayList<Map<String,Object>> getArrayListFromMap(String sql) throws Exception{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		ArrayList<Map<String,Object>> array = new ArrayList<Map<String,Object>>();
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			
			while (rs.next()) {
				Map<String,Object> map = new HashMap<String,Object>();
				for(int i = 1;i<=metaData.getColumnCount();i++) {
					String columname = metaData.getColumnLabel(i);
					byte[] columnValue = rs.getBytes(i);
					
					
					
//					System.out.println(columnValue);
//
//			        System.out.println("getBytes"+columnValue.getBytes());
//
//			        System.out.println("GB2312"+columnValue.getBytes("GB2312"));
//
//			        System.out.println("ISO8859_1"+columnValue.getBytes("ISO8859_1"));
//
//			        System.out.println("new getBytes"+new String(columnValue.getBytes()));
//
//			        System.out.println("new GB2312"+new String(columnValue.getBytes(), "GB2312"));
//
//			        System.out.println("new ISO8859_1"+new String(columnValue.getBytes(), "ISO8859_1"));
//
//			        System.out.println("new GB2312"+new String(columnValue.getBytes("GB2312")));
//
//			        System.out.println("new GB2312-GB2312"+new String(columnValue.getBytes("GB2312"), "GB2312"));
//
//			        System.out.println("new GB2312-ISO8859_1"+new String(columnValue.getBytes("GB2312"), "ISO8859_1"));
//
//			        System.out.println("new ISO8859_1"+new String(columnValue.getBytes("ISO8859_1")));
//
//			        System.out.println("new ISO8859_1-GB2312"+new String(columnValue.getBytes("ISO8859_1"), "GB2312"));
//
//			        System.out.println("new ISO8859_1-ISO8859_1"+new String(columnValue.getBytes("ISO8859_1"), "ISO8859_1"));

					map.put(columname, new String(switchUtf8Encoding(columnValue)));
				}
				array.add(map);
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return array;
	}
	
	/***
	 * 返回JSON 将sql语句中的字段用map对象封装到ArrayList,转换成JSON返回
	 * @param sql
	 * @return
	 * @throws Exception
	 */
	public static String getJsonFromArrayMap(String sql) throws Exception{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		ArrayList<Map<String,Object>> array = new ArrayList<Map<String,Object>>();
		String json = "";
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			
			while (rs.next()) 
			{
				Map<String,Object> map = new HashMap<String,Object>();
				for(int i = 1;i<=metaData.getColumnCount();i++) {
					String columname = metaData.getColumnLabel(i);
					byte[] columnValue = rs.getBytes(i);
					
//					if(columnValue==null)
//					{
//						columnValue = "";
//					}
					
//					map.put(columname, columnValue);
					
					map.put(columname, switchUtf8Encoding(columnValue));
				}
				array.add(map);
			}
			json = JSON.toJSONString(array);
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		logger.info("Sqlca:sql->"+sql);
		return json;
	}
	
	
	
	/**
	  * 返回ArrayList<Map> 将sql语句中的字段用map对象封装到ArrayList返回
	 * @param sql
	 * @param conn 指定的数据库连接不能传空
	 * @return ArrayList<Map<String,Object>>
	 * @throws Exception
	 */
	private static ArrayList<Map<String,Object>> getArrayListFromMap(String sql,Connection conn) throws Exception{
		ArrayList<Map<String,Object>> array = new ArrayList<Map<String,Object>>();
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		while (rs.next()) {
			Map<String,Object> map = new HashMap<String,Object>();
			for(int i = 1;i<=metaData.getColumnCount();i++) {
				String columname =metaData.getColumnLabel(i);
				String columnValue = rs.getString(i);
				
				if(columnValue==null)
				{
					columnValue = "";
				}
				map.put(columname, columnValue);
				
//				map.put(columname, new String(columnValue.getBytes("ISO8859_1"),"GB2312"));
		       
			}
			array.add(map);
		}
		closeAll(null,rs,ps);
		return array;
	}
	
	/***
	 *   返回一个ArrayList<Object>,Object字段与数据库字段一致才能匹配上，实体属性类型与数据库字段类型一致实体只可存String,Integer两种类型
	 * @param sql
	 * @param clss 指定的Bean
	 * @return ArrayList<?>
	 * @throws Exception
	 */
	public static ArrayList<Object> getArrayListFromObj(String sql,Class clss) throws Exception{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		ArrayList<Object> array = new ArrayList<Object>();
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			
			while (rs.next()) {
				Object obj = clss.newInstance();
				Field[] fields = obj.getClass().getFields();
				for(int i = 1;i<=metaData.getColumnCount();i++) {
					String columname =metaData.getColumnLabel(i);
					String columnType = metaData.getColumnTypeName(i);
					if("varchar".equalsIgnoreCase(columnType) || "char".equalsIgnoreCase(columnType) 
							|| "datetime".equalsIgnoreCase(columnType) || "VARBINARY".equalsIgnoreCase(columnType) || "DATETIME".equalsIgnoreCase(columnType))
					{
//						String columnValue = "";
						byte[] columnValue = rs.getBytes(i);
						for(Field f : fields) {
							String fieldname = f.getName();
							if(fieldname.equalsIgnoreCase(columname))
							{
								String dd = f.getType().toString();
								if("class java.lang.String".equals(dd))
								{
									f.set(obj, switchUtf8Encoding(columnValue));
								}
							}
						}
					}
					if("int".equalsIgnoreCase(columnType) || "bigint".equalsIgnoreCase(columnType) || "INT UNSIGNED".equalsIgnoreCase(columnType) ||"FLOAT".equalsIgnoreCase(columnType))
					{
						int columnValue = 0;
						columnValue = rs.getInt(i);
						for(Field f : fields) {
							String fieldname = f.getName();
							if(fieldname.equalsIgnoreCase(columname))
							{
								String dd = f.getType().toString();
								if("class java.lang.Integer".equals(dd))
								{
									f.set(obj, columnValue);
								}
							}
						}
					}
				}
				
				array.add(obj);
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return array;
	}
	
	
	/***
	 *   返回一个ArrayList<Object>,Object字段与数据库字段一致才能匹配上，只适用实体属性全部是String类型
	 * @param sql
	 * @param clss 指定的Bean
	 * @return ArrayList<?>
	 * @throws Exception
	 */
	public static ArrayList<Object> getArrayListFromObjStr(String sql,Class clss) throws Exception{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		ArrayList<Object> array = new ArrayList<Object>();
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			
			while (rs.next()) {
				Object obj = clss.newInstance();
				Field[] fields = obj.getClass().getFields();
				for(int i = 1;i<=metaData.getColumnCount();i++) {
					String columname =metaData.getColumnLabel(i);
					byte[] columnValue = rs.getBytes(i);
					for(Field f : fields) {
						String fieldname = f.getName();
						if(fieldname.equalsIgnoreCase(columname))
						{
							f.set(obj, switchUtf8Encoding(columnValue));
						}
					}
				}
				
				array.add(obj);
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return array;
	}
	
	/***
	 *   返回一个ArrayList<Object>,Object字段与数据库字段一致才能匹配上
	 * @param sql
	 * @param clss 指定的Bean
	 * @param conn 指定的数据库连接不能传空
	 * @return ArrayList<?>
	 * @throws Exception
	 */
	private static ArrayList<Object> getArrayListFromObj(String sql,Class<?> clss,Connection conn) throws Exception{
		ArrayList<Object> array = new ArrayList<Object>();
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Object obj = clss.newInstance();
			Field[] fields = obj.getClass().getFields();
			for(Field f : fields) {
				String fieldname = f.getName();
				f.set(obj, rs.getString(fieldname));
			}
			array.add(obj);
		}
		closeAll(conn,rs,ps);
		return array;
	}
	
	/**
	 * 只支持查询一个字段的sql,多个字段可以拼接成一个,封装将该字段封装到ArrayList<String>里面
	 * @param sql example: select CONCAT_WS('-',t_option.op_param,t_option.op_value) from t_option 
	 * @return ArrayList<String>
	 * @throws Exception
	 */
	public ArrayList<String> getArrayListFromString(String sql) throws Exception{
		logger.info("Sqlca:sql->"+sql);
		sql = switchLatin1Encoding(sql);
		ArrayList<String> array = new ArrayList<String>();
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				
				String val = switchUtf8Encoding(rs.getBytes(1));
				array.add(val);
			}
		}
		finally
		{
			closeAll(conn,rs,ps);
		}
		return array;
		
	}
	
	/**
	 * 关闭连接
	 * @param conn
	 * @param rs
	 * @param ps
	 */
	public static void closeAll(Connection conn,ResultSet rs,PreparedStatement ps) {
		
		try {
			if(rs!=null) {
				rs.close();
			}
			if(ps!=null) {
				ps.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}catch(SQLException e) {
			logger.info(e.getMessage());
		}finally {
			try {
				if(rs!=null && !rs.isClosed()) {
					rs.close();
				}
				if(ps!=null && !ps.isClosed()) {
					ps.close();
				}
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	
	public static String[] switchLatin1Encoding(String[] strs) throws Exception 
	{
		
		if("latin1".equals(osEncoding)) 
		{
			if(strs!=null)
			{
				String[] ss = new String[strs.length];
				for(int i=0;i<strs.length;i++) {
					
					ss[i] = new String(strs[i].getBytes("GBK"),"ISO8859_1");
					
				}
				return ss;
			}
			
		}
		return strs;
	}
	
	
	public static String switchLatin1Encoding(String strs) throws Exception 
	{
		
		if("latin1".equals(osEncoding)) 
		{
			if(strs!=null)
			{
				String ss = new String(strs.getBytes("GBK"),"ISO8859_1");
					
				return ss;
			}
		}
		return strs;
	}
	
	
	public static String switchUtf8Encoding(byte[] str) throws Exception 
	{
		
		if("latin1".equals(osEncoding)) 
		{
			if(str!=null) 
			{
				String ss = new String(str,"GBK");
				return ss;
			}
		}
		else
		{
			if(str!=null) 
			{
				String ss = new String(str,"utf8");
				return ss;
			}
		}
		return "";
	}
	
	
}
