package com.huawang.interceptor;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.Sqlca;

public class LoginInterceptor extends HandlerInterceptorAdapter {

	// 日志
	static Logger logger = LogManager.getLogger(LoginInterceptor.class.getName());

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		request.setCharacterEncoding("UTF-8");  
		response.setCharacterEncoding("UTF-8");  
		response.setContentType("text/html;charset=UTF-8");

		HttpSession session = request.getSession();
		if(session==null) {
			String url = Sqlca.getString("select op_bak1 from t_option where op_param='redirecturl' and op_isuse='1'");
			logger.info("session==null login again");
			response.setContentType("text/html;charset=UTF-8");
	        response.setCharacterEncoding("UTF-8");
	        response.setHeader("Cache-Control", "no-cache");
	        PrintWriter out = response.getWriter();
	        out.println("<script language='javascript'>");
	        out.println("parent.location.href='"+url+"'");
	        out.println("</script>");
	        out.flush();
	        out.close();
			return false;
		}
		
        Object obj = request.getSession().getAttribute("USER_SESSION");
        if(obj==null) {
        	logger.info("USER_SESSION==null login again");
        	String url = Sqlca.getString("select op_bak1 from t_option where op_param='redirecturl' and op_isuse='1'");
			response.setContentType("text/html;charset=UTF-8");
	        response.setCharacterEncoding("UTF-8");
	        response.setHeader("Cache-Control", "no-cache");
	        PrintWriter out = response.getWriter();
	        out.println("<script language='javascript'>");
	        out.println("parent.location.href='"+url+"'");
	        out.println("</script>");
	        out.flush();
	        out.close();
      		return false;
        }
        
        if(preventLoginOnLogining(request)==null) {
        	String url = Sqlca.getString("select op_bak1 from t_option where op_param='redirecturl' and op_isuse='1'");
        	logger.info("preventLoginOnLogining==null login again");
			response.setContentType("text/html;charset=UTF-8");
	        response.setCharacterEncoding("UTF-8");
	        response.setHeader("Cache-Control", "no-cache");
	        PrintWriter out = response.getWriter();
	        out.println("<script language='javascript'>");
	        out.println("parent.location.href='"+url+"'"); 
	        out.println("</script>");
	        out.flush();
	        out.close();
      		return false;
        }

		return super.preHandle(request, response, handler);  
	}
	
	public String preventLoginOnLogining(HttpServletRequest request) {
    	HttpSession session = request.getSession();
    	ServletContext application = session.getServletContext();
    	Map<String,String> loginMap = (Map<String,String>)application.getAttribute("loginMap");
    	if(loginMap == null) {
    		loginMap = new HashMap<String,String>();
    	}
    	
    	Object obj = session.getAttribute("USER_SESSION");
        TAdmininfo user = null;
        if(obj!=null) {
      	   user = (TAdmininfo)obj;
      	    //防止多点登录，如果有用户登录当前用户被挤下线
        }
    	
    	for(String key : loginMap.keySet()) {
    		if(user!=null) {
    			if(user.getAdminName().equals(key)) {
    				//用户登录正常
    	    		if(session.getId().equals(loginMap.get(key))) {
    	    		
    	    		}else {
    	    			logger.info("\n aspectAdvice->other the same user has been down line");
    	    			return null;
    	    			//不同浏览器登录,挤掉前面登录的用户
    	    		}
    			}
    		}
    	}
    	return "";
    	
    }

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
