package com.huawang.timer;

import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Timer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class TimerManager {
	static Logger logger = LogManager.getLogger(RemainUseTimerTask.class.getName());
	//时间间隔
//    private static final long PERIOD_DAY = 24 * 60 * 60 * 1000;
    public TimerManager() throws Exception {
    	
         Calendar calendar = Calendar.getInstance(); 
         logger.info("TimerManager execution "+calendar.getTime());   
         Properties properties = new Properties();
         InputStream in = TimerManager.class.getClassLoader().getResourceAsStream("config.properties");
         properties.load(in);
         // 获取key对应的value值
         
         /*** 定制每日2:00执行方法 ***/
         String HOUR_OF_DAY = properties.getProperty("HOUR");
         String MINUTE = properties.getProperty("MINUTE");
         String SECOND = properties.getProperty("SECOND");
         String PERIOD_DAY = properties.getProperty("PERIOD");
         in.close();
         calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(HOUR_OF_DAY));
         calendar.set(Calendar.MINUTE, Integer.parseInt(MINUTE));
         calendar.set(Calendar.SECOND, Integer.parseInt(SECOND));
          
         Date date=calendar.getTime(); //第一次执行定时任务的时间
         System.out.println(date);
         System.out.println("before 方法比较(为true则加一天)："+date.before(new Date()));
         //如果第一次执行定时任务的时间 小于 当前的时间
         //此时要在 第一次执行定时任务的时间 加一天，以便此任务在下个时间点执行。如果不加一天，任务会立即执行。循环执行的周期则以当前时间为准
         if (date.before(new Date())) {
             date = this.addDay(date, 1);
             logger.info(date);
         }
         
         Timer timer = new Timer();
         
         RemainUseTimerTask task = new RemainUseTimerTask();
         //安排指定的任务在指定的时间开始进行重复的固定延迟执行。
         timer.schedule(task, date, Integer.parseInt(PERIOD_DAY));
        }

        // 增加或减少天数
        public Date addDay(Date date, int num) {
         Calendar startDT = Calendar.getInstance();
         startDT.setTime(date);
         startDT.add(Calendar.DAY_OF_MONTH, num);
         return startDT.getTime();
        }
}
