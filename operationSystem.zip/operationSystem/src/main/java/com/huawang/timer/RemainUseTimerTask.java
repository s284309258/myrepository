package com.huawang.timer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import java.util.TimerTask;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.huawang.util.CommonInterface;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;


public class RemainUseTimerTask extends TimerTask {

	static Logger logger = LogManager.getLogger(RemainUseTimerTask.class.getName());
	@Override
	public void run() 
	{
		logger.info("RemainUseTimerTask begin execute");
		try 
		{
			//更新订单状态 
			UpdateOrderStatus();
			//签约订单生效更新合同日期结束试用订单
			UpdateStatuUsingSign(); 
			//系统订单(生效的订单)转换成开单记录
			GenerateBillRecord();
			//更新公司状态(5试用中\1合约中\6合约过期\8未签约\10扩点试用)
			UpdateCompStatus();
			//订单到到期日,更新为已结束
			UpdateStatusOver();
			//未开始的订单,到开始时间,更新为使用中
			UpdateStatusUsing();
			//更新公司状态(5试用中\1合约中\6合约过期\8未签约\10扩点试用)
			UpdateCompStatus();
			//同步用户部门和产品映射表到旧系统
			DataSynchronized();
			//旧系统产品同步到新系统订单
//			SynProductToOrder();
			//更新会议统计表
			MeetingStatistical();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void GenerateBillRecord() throws Exception
	{
		logger.info("GenerateBillRecord execute");
		String selAllOrder = "select id,o_Type,o_MaxUserCount,o_Product,o_UseDays,o_CreateDate,"
				+ " o_EndDate,o_UseTimes,o_Remark,o_Status,o_AdminID,o_ApproveID,o_CreateUser,"
				+ " o_CreateTime,o_UpdateUser,o_UpdateTime,o_CompID,o_Opinion,o_flow,o_bak1,o_bak2,"
				+ " source,o_CompName,o_SignRadio from t_order where SUBSTR(o_CreateDate,1,10) = '"+DateUtil.dateFormat(0)+"'"
				+ " and o_Status='8'";
		
		Connection connection = Sqlca.getConnection();
		PreparedStatement selps = connection.prepareStatement(selAllOrder);
		ResultSet selrs = selps.executeQuery();
		try
		{
			while(selrs.next())
			{
				String id = selrs.getString("id");
				String o_Type = selrs.getString("o_Type");
				String o_Status = selrs.getString("o_Status");
				String o_CompID = selrs.getString("o_CompID");
				String o_CreateDate = DateUtil.getDateYMD(selrs.getString("o_CreateDate"),"00:00:00");
				String o_EndDate = DateUtil.getDateYMD(selrs.getString("o_EndDate"),"23:59:59");
				String o_Product = selrs.getString("o_Product");
				String o_MaxUserCount = selrs.getString("o_MaxUserCount");
				String o_SignRadio = selrs.getString("o_SignRadio");
				
				ArrayList<Map<String,Object>> complist = Sqlca.getArrayListFromMap("select ContractEndTime,EndDate,CreateDate,ProductID,MaxUserCount from t_compinfo where CompID="+o_CompID);
				String ContractEndTime = DateUtil.getDateYMD((String)complist.get(0).get("ContractEndTime"),"23:59:59");
				String EndDate = DateUtil.getDateYMD((String)complist.get(0).get("EndDate"),"23:59:59");
				String CreateDate = DateUtil.getDateYMD((String)complist.get(0).get("CreateDate"),"00:00:00");
				String BillNo = "B"+o_CompID+DateUtil.dateFormat("YYYYMMddHHmmss");
				String ProductID = (String)complist.get(0).get("ProductID");
				String CompMaxUserCount = (String)complist.get(0).get("MaxUserCount");
				if("".equals(CompMaxUserCount)) {CompMaxUserCount = o_MaxUserCount;}
				
				if("4".equals(o_SignRadio))
				{
					Sqlca.updateObject("update t_validbill set CreateDate='2099-01-01 00:00:00',EndDate='2099-01-01 23:59:59' where OrderID in(" + 
							"(select id from t_order where id in(select id from  (select id from t_order where o_compid=? and id <>?) t)))", new String[] {o_CompID,id});
					
					Sqlca.updateObject("update t_order set o_Status=5 where id in(select id from "
							+ " (select id from t_order where o_compid=? and id <>?) t)", new String[] {o_CompID,id});
				}
				if("3".equals(o_SignRadio))
				{
					Sqlca.updateObject("update t_validbill set CreateDate='2099-01-01 00:00:00',EndDate='2099-01-01 23:59:59' where OrderID in(" + 
							"select id from t_order where id in(select id from  (select id from t_order where o_compid=? and o_type=2 and id <>?) t))", new String[] {o_CompID,id});
					
					Sqlca.updateObject("update t_order set o_Status=5 where id in(select id from "
							+ " (select id from t_order where o_compid=? and o_type=2 and id <>?) t)", new String[] {o_CompID,id});
				}
//				String CompStatus = Sqlca.getString("select CompStatus from t_compinfo where CompID="+o_CompID);
				
				if("".equals(ContractEndTime))
				{
					if("2".equals(o_Type))
					{
						Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
//						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
//								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"plus",BillNo,CompMaxUserCount,id});
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"single",BillNo,CompMaxUserCount,id});
						
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,BillNo,"plus",BillNo,CompMaxUserCount,id});
						
						CommonInterface.UpdateCompStatus(o_CompID, "1");
					}
					else
					{
						Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
								new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,BillNo,"single",BillNo,CompMaxUserCount,id});
						CommonInterface.UpdateCompStatus(o_CompID, "5");
					}
				}
				else
				{
					String RelateBillNo = Sqlca.getString("select BillNO from t_validbill where CompID="+o_CompID+" ORDER BY ID DESC LIMIT 1");
					if(RelateBillNo==null) {RelateBillNo=BillNo;}
					if(o_CreateDate.compareTo(ContractEndTime)<0 && o_EndDate.compareTo(ContractEndTime)>=0)
					{
						if("2".equals(o_Type))
						{
							Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
							
							if("2".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
							}
							else if("3".equals(o_SignRadio))
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
								
							}
							else if("4".equals(o_SignRadio))
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							else if("1".equals(o_SignRadio))
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							else
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
							}
							CommonInterface.UpdateCompStatus(o_CompID, "1");
						}
						else if("3".equals(o_Type))
						{
							Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
									new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							
							CommonInterface.UpdateCompStatus(o_CompID, "10");
						}
						else
						{
							Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
									new String[] {o_Product,o_MaxUserCount,o_CreateDate,EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
						}
					}
					else if(DateUtil.getDateYMD(ContractEndTime, "23:59:59").compareTo(DateUtil.getDateYMD(o_EndDate, "23:59:59"))>=0)
					{
						if("2".equals(o_Type))
						{
							Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
							if("2".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							else if("3".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
								
								CommonInterface.UpdateCompStatus(o_CompID, "10");
							}
							else if("4".equals(o_SignRadio))
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							else if("1".equals(o_SignRadio))
							{
								Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							else
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
							}
							CommonInterface.UpdateCompStatus(o_CompID, "1");
						}
						else if("3".equals(o_Type))
						{
							Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
									new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							
							CommonInterface.UpdateCompStatus(o_CompID, "10");
						}
						else
						{
							Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
									new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
						}
					}
					else
					{
						if("3".equals(o_Type))
						{
							CommonInterface.UpdateCompStatus(o_CompID, "10");
						}
						else if("2".equals(o_Type))
						{
							if("2".equals(o_Type) && "2".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							if("2".equals(o_Type) && "3".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							if("2".equals(o_Type) && "4".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							if("2".equals(o_Type) && "1".equals(o_SignRadio))
							{
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
								
								Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
										new String[] {o_Product,o_MaxUserCount,"2010-10-10 00:00:00",o_EndDate,o_CompID,RelateBillNo,"plus",BillNo,CompMaxUserCount,id});
							}
							CommonInterface.UpdateCompStatus(o_CompID, "1");
						}
						else
						{
							Sqlca.updateObject("insert into t_validbill(ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,CompMaxUserCount,OrderID) values(?,?,?,?,?,?,?,?,?,?)", 
									new String[] {o_Product,o_MaxUserCount,o_CreateDate,o_EndDate,o_CompID,RelateBillNo,"single",BillNo,CompMaxUserCount,id});
						}
					}
				}
				Sqlca.updateObject("update t_order set o_Status='1' where id=?", new String[] {id});
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			Sqlca.closeAll(connection,selrs,selps);
		}
		
		logger.info("GenerateBillRecord execute end");
	}
	
	private void UpdateStatuUsingSign() throws Exception 
	{
		logger.info("UpdateStatuUsingSign execute");
		String sql = "select o_CompID,o_Product,o_CreateDate,o_EndDate,o_MaxUserCount,o_SignRadio from t_order where o_Type=2 and o_Status=8 AND SUBSTR(o_CreateDate,1,10)='"+DateUtil.dateFormat(0)+"'";
		Connection connection = Sqlca.getConnection();
		PreparedStatement selps = connection.prepareStatement(sql);
		ResultSet selrs = selps.executeQuery();
		try
		{
			while(selrs.next())
			{
				String o_CompID = selrs.getString("o_CompID");
				String o_EndDate = selrs.getString("o_EndDate");
				String o_SignRadio = selrs.getString("o_SignRadio");
				if(!"2".equals(o_SignRadio))
				{
					Sqlca.updateObject("UPDATE t_compinfo SET ContractEndTime=(case when '"+o_EndDate+"'>ContractEndTime then '"+o_EndDate+"' else ContractEndTime end) where CompID=?", new String[] {o_CompID});
				}
				Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			Sqlca.closeAll(connection,selrs,selps);
		}
		logger.info("UpdateStatuUsingSign execute end");
	}
	
	private void UpdateStatusUsing() throws Exception 
	{
		
		logger.info("GenerateBillRecord execute");
		String selBill = "select ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo from t_validbill where SUBSTR(CreateDate,1,10)='"+DateUtil.dateFormat(0)+"'";
		
		Connection connection = Sqlca.getConnection();
		PreparedStatement selps = connection.prepareStatement(selBill);
		ResultSet selrs = selps.executeQuery();
		try
		{
			while(selrs.next())
			{
				String ProductID =selrs.getString("ProductID");
				String MaxUserCount =selrs.getString("MaxUserCount");
				String CreateDate =selrs.getString("CreateDate");
				String EndDate =selrs.getString("EndDate");
				String CompID =selrs.getString("CompID");
				String RelateBillNo =selrs.getString("RelateBillNo");
				String BillType =selrs.getString("BillType");
				String BillNo =selrs.getString("BillNo");
//				String sql = "select EndDate from t_validbill where CompID= "+CompID+" and SUBSTR(EndDate,1,10)>'"+DateUtil.dateFormat(0,0)+"' and SUBSTR(EndDate,1,10)<>'2099-01-01' ORDER BY EndDate";
				String sql = "select min(o_EndDate) from t_order where o_CompID="+CompID+" and o_Status=1";
				String RecentlyEndDate = Sqlca.getString(sql);
				if(RecentlyEndDate==null) {RecentlyEndDate=EndDate;}
				
				if("plus".equals(BillType))
				{
					Sqlca.updateObject("update t_compinfo SET MaxUserCount=(case when MaxUserCount is null then "+MaxUserCount+" else MaxUserCount+"+MaxUserCount+" end),EndDate='"+RecentlyEndDate+"',ProductID="+ProductID+","
							+ " CreateDate=(CASE WHEN CreateDate IS NULL THEN '"+CreateDate+"' else CreateDate END ) where CompID=?", new String[] {CompID});
					
					Sqlca.updateObject("update t_compinfo_product set productId="+ProductID+",productProperty=2,productCount=0 where compId=?", new String[] {CompID});
					Sqlca.updateObject("update t_confinfo set ProductType="+ProductID+" where CompID=?", new String[] {CompID});
					
				}
				if("single".equals(BillType))
				{
					Sqlca.updateObject("update t_compinfo SET MaxUserCount="+MaxUserCount+",ProductID="+ProductID+","
							+ " CreateDate=(CASE WHEN CreateDate IS NULL THEN '"+CreateDate+"' else CreateDate END ),EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
					
					String productId = Sqlca.getString("select productId from t_compinfo_product where compId="+CompID);
					if(productId==null) 
					{
						Sqlca.updateObject("INSERT INTO t_compinfo_product(compid,productid,productcount,productproperty) " + 
								" VALUES(?,?,?,?)", new String[] {CompID,ProductID,"0","2"});
					}
					else
					{
						Sqlca.updateObject("update t_compinfo_product set productId="+ProductID+",productProperty=2,productCount=0 where compId=?", new String[] {CompID});
						Sqlca.updateObject("update t_confinfo set ProductType="+ProductID+" where CompID=?", new String[] {CompID});
					}
				}
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			Sqlca.closeAll(connection,selrs,selps);
		}
		
		logger.info("UpdateStatusUsing execute end");
	}
	
	
	private void UpdateStatusOver() throws Exception 
	{
		logger.info("UpdateStatusOver execute");
		//select ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo from t_validbill where SUBSTR(EndDate,1,10)=date_add( CURRENT_DATE, INTERVAL -1 DAY )
		String selAllOrder = "select ProductID,MaxUserCount,CreateDate,EndDate,CompID,RelateBillNo,BillType,BillNo,OrderID from t_validbill where SUBSTR(EndDate,1,10)='"+DateUtil.dateFormat(-1,0)+"'";
		
		Connection connection = Sqlca.getConnection();
		PreparedStatement selps = connection.prepareStatement(selAllOrder);
		ResultSet selrs = selps.executeQuery();
		try
		{
			while(selrs.next())
			{
				String ProductID =selrs.getString("ProductID");
				String MaxUserCount =selrs.getString("MaxUserCount");
				String CreateDate =selrs.getString("CreateDate");
				String EndDate =selrs.getString("EndDate");
				String CompID =selrs.getString("CompID");
				String RelateBillNo =selrs.getString("RelateBillNo");
				String BillType =selrs.getString("BillType");
				String BillNo =selrs.getString("BillNo");
				String OrderID = selrs.getString("OrderID");
				//String sql = "select EndDate from t_validbill where CompID= "+CompID+" and SUBSTR(EndDate,1,10)>'"+DateUtil.dateFormat(-1,0)+"' and SUBSTR(EndDate,1,10)<>'2099-01-01' ORDER BY EndDate";
				String sql = "select min(o_EndDate) from t_order where o_CompID="+CompID+" and o_Status=1";
				String RecentlyEndDate = Sqlca.getString(sql);
				if(RecentlyEndDate==null || "".equals(RecentlyEndDate)) {RecentlyEndDate=EndDate;}
				if("plus".equals(BillType))
				{
					String MaxContractDate = Sqlca.getString("select SUBSTR(MAX(ContractEndTime),1,10) from t_compinfo where CompID="+CompID);
					if(MaxContractDate==null || "".equals(MaxContractDate)) {MaxContractDate=DateUtil.dateFormat(0,0);}
					if(DateUtil.dateFormat(0,0).compareTo(MaxContractDate)<0)
					{
						String enlarge = Sqlca.getString("select id from t_order where id="+OrderID+" and o_Type=3 and (select max(o_CreateDate)"
								+ " from t_order where o_CompID="+CompID+" and o_Status=1 and o_SignRadio=3) BETWEEN o_CreateDate and o_EndDate");
						if(enlarge!=null && !"".equals(enlarge))
						{
							Sqlca.updateObject("UPDATE t_compinfo SET EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
						}
						else
						{
							Sqlca.updateObject("UPDATE t_compinfo SET MaxUserCount=MaxUserCount-"+MaxUserCount+","
									+ " EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
						}
					}
				}
				
//				if("single".equals(BillType))
//				{
//					String sqlsingle = "select id from t_order where o_CompID="+CompID+" and o_Type=2 and o_Status=1 and o_SignRadio=2 and "
//							+ " (select o_EndDate from t_order tt where tt.id="+OrderID+") between o_CreateDate and o_EndDate";
//					String id = Sqlca.getString(sqlsingle);
//					if(id!=null)
//					{
//						Sqlca.updateObject("UPDATE t_compinfo SET MaxUserCount=MaxUserCount-"+MaxUserCount+","
//								+ " EndDate='"+RecentlyEndDate+"' where CompID=?", new String[] {CompID});
//					}
//				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			Sqlca.closeAll(connection,selrs,selps);
		}
		logger.info("UpdateStatusOver execute end");
	}
	
	
	private synchronized void MeetingStatistical() throws Exception
	{
		logger.info("update t_meeting_statistical execute");
		String month12 = DateUtil.dateFormat(-12)+" 00:00:00";
		String month6 = DateUtil.dateFormat(-6)+" 00:00:00";
		String month3 = DateUtil.dateFormat(-3)+" 00:00:00";
		String month1 = DateUtil.dateFormat(-1)+" 00:00:00";
		String monthnow = DateUtil.dateFormat(0)+" 23:59:59";
		
		Connection connection = Sqlca.getConnection();
		Statement statps = connection.createStatement();
		try
		{
			statps.execute("TRUNCATE t_meeting_statistical");
			
			
			//查询全部
//			String statistical = " insert into t_meeting_statistical(meetNum,compTrueName,compId,sumTime,sumUser,avgTime,datetype) "+ 
//					 " select count(*) as meetNum,(select t.compTrueName from t_compinfo t where t.CompID=logdetail.compId) as compTrueName,logdetail.compId,logdetail.sumTime,"+
//					 " logdetail.sumUser,logdetail.avgTime,'99' from t_log_conf conflog,t_confinfo conf,("+
//					 " select cc.CompID as compId,"+
//					 " sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//					 " select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail"+
//					 " group by ConfID"+
//					 " )cd where cc.ConfID=cd.ConfID group by cc.CompID"+
//					 " ) logdetail where conflog.ConfID=conf.ConfID and logdetail.compId=conf.CompID GROUP BY logdetail.compId";
			String statistical = " insert into t_meeting_statistical(meetNum,compTrueName,compName,compId,sumTime,sumUser,avgTime,datetype) "+ 
					" select meetnum,(SELECT tt.CompTrueName from t_compinfo tt where tt.CompID=conflog.CompID) as comptruename,"+
					" (SELECT tt.CompName from t_compinfo tt where tt.CompID=conflog.CompID) as CompName,"+
					" conflog.CompID,conflog.sumtime,logdetail.sumuser,conflog.sumtime/logdetail.sumuser as avgTime,'99' from "+
					" ("+
					" select sum(UNIX_TIMESTAMP(t2.EndTime)-UNIX_TIMESTAMP(t2.StartTime))/60 as sumtime,count(*) as meetnum,t3.CompID"+ 
					" from t_confinfo t1,t_log_conf t2,t_compinfo t3 where t1.ConfID=t2.ConfID and t3.CompID=t1.CompID GROUP BY t3.CompID"+
					" ) conflog,"+
					" ("+
					" select sum(sumuser) as sumuser,tt.CompID from (select COUNT(DISTINCT UserName) as sumuser,ConfID from t_log_conf_detail GROUP BY ConfID) t,t_confinfo tt where t.ConfID=tt.ConfID GROUP BY tt.CompID"+
					" ) logdetail where conflog.compid=logdetail.CompID";
			statps.execute(statistical);	
			
			
			//统计半年内的
//			String statistical6 = " insert into t_meeting_statistical(meetNum,compTrueName,compId,sumTime,sumUser,avgTime,datetype)" +
//			" select count(*) as meetNum,(select t.compTrueName from t_compinfo t where t.CompID=logdetail.compId) as compTrueName,logdetail.compId,logdetail.sumTime,logdetail.sumUser,logdetail.avgTime,'6' "+
//			" from t_log_conf conflog,t_confinfo conf,("+
//			" select cc.CompID as compId,"+
//			" sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//			" select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail t1 where t1.StartTime BETWEEN '"+month6+"' and '"+monthnow+"'"+
//			" group by ConfID"+
//			" )cd where cc.ConfID=cd.ConfID group by cc.CompID"+
//			" ) logdetail where conflog.ConfID=conf.ConfID and logdetail.compId=conf.CompID and conflog.StartTime BETWEEN '"+month6+"' and '"+monthnow+"' GROUP BY logdetail.compId";
			
			String statistical6 = " insert into t_meeting_statistical(meetNum,compTrueName,compName,compId,sumTime,sumUser,avgTime,datetype)" +
			" select meetnum,(SELECT tt.CompTrueName from t_compinfo tt where tt.CompID=conflog.CompID) as comptruename,"+
			" (SELECT tt.CompName from t_compinfo tt where tt.CompID=conflog.CompID) as CompName,"+
			" conflog.CompID,conflog.sumtime,logdetail.sumuser,conflog.sumtime/logdetail.sumuser as avgTime,'6' from "+
			" ("+
			" select sum(UNIX_TIMESTAMP(t2.EndTime)-UNIX_TIMESTAMP(t2.StartTime))/60 as sumtime,count(*) as meetnum,t3.CompID" +
			" from t_confinfo t1,t_log_conf t2,t_compinfo t3 where t1.ConfID=t2.ConfID and t3.CompID=t1.CompID AND t2.StartTime BETWEEN '"+month6+"' AND '"+monthnow+"' GROUP BY t3.CompID"+
			" ) conflog,"+
			" ("+
			" select sum(sumuser) as sumuser,tt.CompID from (select COUNT(DISTINCT UserName) as sumuser,ConfID from t_log_conf_detail where StartTime BETWEEN '"+month6+"' AND '"+monthnow+"' GROUP BY ConfID) t,t_confinfo tt where t.ConfID=tt.ConfID GROUP BY tt.CompID"+
			" ) logdetail where conflog.compid=logdetail.CompID";
			statps.execute(statistical6);
			
			//统计一年内的
//			String statistical12 = " insert into t_meeting_statistical(meetNum,compTrueName,compId,sumTime,sumUser,avgTime,datetype)" +
//			" select count(*) as meetNum,(select t.compTrueName from t_compinfo t where t.CompID=logdetail.compId) as compTrueName,logdetail.compId,logdetail.sumTime,logdetail.sumUser,logdetail.avgTime,'12' "+
//			" from t_log_conf conflog,t_confinfo conf,("+
//			" select cc.CompID as compId,"+
//			" sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//			" select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail t1 where t1.StartTime BETWEEN '"+month12+"' and '"+monthnow+"'"+
//			" group by ConfID"+
//			" )cd where cc.ConfID=cd.ConfID group by cc.CompID"+
//			" ) logdetail where conflog.ConfID=conf.ConfID and logdetail.compId=conf.CompID and conflog.StartTime BETWEEN '"+month12+"' and '"+monthnow+"' GROUP BY logdetail.compId";
			
			String statistical12 = " insert into t_meeting_statistical(meetNum,compTrueName,compName,compId,sumTime,sumUser,avgTime,datetype)" +
			" select meetnum,(SELECT tt.CompTrueName from t_compinfo tt where tt.CompID=conflog.CompID) as comptruename,"+
			" (SELECT tt.CompName from t_compinfo tt where tt.CompID=conflog.CompID) as CompName,"+
			" conflog.CompID,conflog.sumtime,logdetail.sumuser,conflog.sumtime/logdetail.sumuser as avgTime,'12' from "+
			" ("+
			" select sum(UNIX_TIMESTAMP(t2.EndTime)-UNIX_TIMESTAMP(t2.StartTime))/60 as sumtime,count(*) as meetnum,t3.CompID" +
			" from t_confinfo t1,t_log_conf t2,t_compinfo t3 where t1.ConfID=t2.ConfID and t3.CompID=t1.CompID AND t2.StartTime BETWEEN '"+month12+"' AND '"+monthnow+"' GROUP BY t3.CompID"+
			" ) conflog,"+
			" ("+
			" select sum(sumuser) as sumuser,tt.CompID from (select COUNT(DISTINCT UserName) as sumuser,ConfID from t_log_conf_detail where StartTime BETWEEN '"+month12+"' AND '"+monthnow+"' GROUP BY ConfID) t,t_confinfo tt where t.ConfID=tt.ConfID GROUP BY tt.CompID"+
			" ) logdetail where conflog.compid=logdetail.CompID";
			statps.execute(statistical12);
			
			//统计3个月内的
//			String statistical3 = " insert into t_meeting_statistical(meetNum,compTrueName,compId,sumTime,sumUser,avgTime,datetype)"+ 
//			" select count(*) as meetNum,(select t.compTrueName from t_compinfo t where t.CompID=logdetail.compId) as compTrueName,logdetail.compId,logdetail.sumTime,logdetail.sumUser,logdetail.avgTime,'3' "+
//			" from t_log_conf conflog,t_confinfo conf,("+
//			" select cc.CompID as compId,"+
//			" sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//			" select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail t1 where t1.StartTime BETWEEN '"+month3+"' and '"+monthnow+"'"+
//			" group by ConfID"+
//			" )cd where cc.ConfID=cd.ConfID group by cc.CompID"+
//			" ) logdetail where conflog.ConfID=conf.ConfID and logdetail.compId=conf.CompID and conflog.StartTime BETWEEN '"+month3+"' and '"+monthnow+"' GROUP BY logdetail.compId";
			
			String statistical3 = " insert into t_meeting_statistical(meetNum,compTrueName,compName,compId,sumTime,sumUser,avgTime,datetype)"+
			" select meetnum,(SELECT tt.CompTrueName from t_compinfo tt where tt.CompID=conflog.CompID) as comptruename,"+
			" (SELECT tt.CompName from t_compinfo tt where tt.CompID=conflog.CompID) as CompName,"+
			" conflog.CompID,conflog.sumtime,logdetail.sumuser,conflog.sumtime/logdetail.sumuser as avgTime,'3' from "+
			" ("+
			" select sum(UNIX_TIMESTAMP(t2.EndTime)-UNIX_TIMESTAMP(t2.StartTime))/60 as sumtime,count(*) as meetnum,t3.CompID" +
			" from t_confinfo t1,t_log_conf t2,t_compinfo t3 where t1.ConfID=t2.ConfID and t3.CompID=t1.CompID AND t2.StartTime BETWEEN '"+month3+"' AND '"+monthnow+"' GROUP BY t3.CompID"+
			" ) conflog,"+
			" ("+
			" select sum(sumuser) as sumuser,tt.CompID from (select COUNT(DISTINCT UserName) as sumuser,ConfID from t_log_conf_detail where StartTime BETWEEN '"+month3+"' AND '"+monthnow+"' GROUP BY ConfID) t,t_confinfo tt where t.ConfID=tt.ConfID GROUP BY tt.CompID"+
			" ) logdetail where conflog.compid=logdetail.CompID";
			statps.execute(statistical3);
			
			//统计一个月内的
//			String statistical1 = " insert into t_meeting_statistical(meetNum,compTrueName,compId,sumTime,sumUser,avgTime,datetype)"+ 
//			" select count(*) as meetNum,(select t.compTrueName from t_compinfo t where t.CompID=logdetail.compId) as compTrueName,logdetail.compId,logdetail.sumTime,logdetail.sumUser,logdetail.avgTime,'1' from t_log_conf conflog,t_confinfo conf,("+
//			" select cc.CompID as compId,"+
//			" sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//			" select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail t1 where t1.StartTime BETWEEN '"+month1+"' and '"+monthnow+"'"+
//			" group by ConfID"+
//			" )cd where cc.ConfID=cd.ConfID group by cc.CompID"+
//			" ) logdetail where conflog.ConfID=conf.ConfID and logdetail.compId=conf.CompID and conflog.StartTime BETWEEN '"+month1+"' and '"+monthnow+"' GROUP BY logdetail.compId";
			
			String statistical1 = " insert into t_meeting_statistical(meetNum,compTrueName,compName,compId,sumTime,sumUser,avgTime,datetype)"+
			" select meetnum,(SELECT tt.CompTrueName from t_compinfo tt where tt.CompID=conflog.CompID) as comptruename,"+
			" (SELECT tt.CompName from t_compinfo tt where tt.CompID=conflog.CompID) as CompName,"+
			" conflog.CompID,conflog.sumtime,logdetail.sumuser,conflog.sumtime/logdetail.sumuser as avgTime,'1' from "+
			" ("+
			" select sum(UNIX_TIMESTAMP(t2.EndTime)-UNIX_TIMESTAMP(t2.StartTime))/60 as sumtime,count(*) as meetnum,t3.CompID" +
			" from t_confinfo t1,t_log_conf t2,t_compinfo t3 where t1.ConfID=t2.ConfID and t3.CompID=t1.CompID AND t2.StartTime BETWEEN '"+month1+"' AND '"+monthnow+"' GROUP BY t3.CompID"+
			" ) conflog,"+
			" ("+
			" select sum(sumuser) as sumuser,tt.CompID from (select COUNT(DISTINCT UserName) as sumuser,ConfID from t_log_conf_detail where StartTime BETWEEN '"+month1+"' AND '"+monthnow+"' GROUP BY ConfID) t,t_confinfo tt where t.ConfID=tt.ConfID GROUP BY tt.CompID"+
			" ) logdetail where conflog.compid=logdetail.CompID";
			statps.execute(statistical1);
			
					//					" select cc.CompID as compId,(select t.CompName from t_compinfo t where t.CompID=cc.CompID) as compTrueName,"+
//					" sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_confinfo cc,("+
//					" select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail"+
//					" group by ConfID"+
//					" )cd where cc.ConfID=cd.ConfID group by cc.CompID";
			
//			 " select cc.CompID as compId,(select t.compTrueName from t_compinfo t where t.CompID=cc.CompID) as compTrueName,"+
//			 " sum(rc) as sumUser,sum(hs) as sumTime,sum(hs)/sum(rc) as avgTime,count(*) as meetNum,cd.StartTime,cd.EndTime from t_log_conf lc,t_confinfo cc,("+
//			 " select ConfID,count(*) rc,sum(times) hs,StartTime,EndTime from t_log_conf_detail"+
//			 " group by ConfID"+
//			 " )cd where lc.ConfID=cc.ConfID and lc.ConfID=cd.ConfID group by cc.CompID";
			
//			statps.execute(statistical);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			statps.close();
			connection.close();
		}
		logger.info("update t_meeting_statistical end");
		
	}
	
	
	//同步数据到旧系统
	private synchronized void DataSynchronized() throws Exception
	{
		logger.info("update DataSynchronized");
		Connection connection = Sqlca.getConnection();
		//同步用户部门
		String sql = "select t.AdminID,t.DpID from t_admininfo t "
				+ " LEFT JOIN t_admin_department tt on t.AdminID=tt.AdminId WHERE tt.AdminId IS NULL";
		PreparedStatement pp = connection.prepareStatement(sql);
		ResultSet rr = pp.executeQuery();
		try
		{
			while(rr.next())
			{
				String AdminID =rr.getString("AdminID");
				String DpID = rr.getString("DpID");
				if(AdminID!=null && DpID!=null)
				{
					Sqlca.updateObject("insert into t_admin_department(adminid,dpid) values(?,?)", new String[] {AdminID,DpID});
				}
			}
			rr.close();
			pp.close();
			
			//同步产品id到旧系统
			String psql = "select t.CompID,t.productID,t.compStyle from t_compinfo t "
					+ " left JOIN t_compinfo_product tt on t.CompID=tt.compId where tt.compId is null and t.productID is not null";
			PreparedStatement productps = connection.prepareStatement(psql);
			ResultSet productrs = productps.executeQuery();
			while(productrs.next())
			{
				String CompID = productrs.getString("CompID");
				String productID = productrs.getString("productID");
				String compStyle = productrs.getString("compStyle");
				if(CompID!=null && productID!=null)
				{
					Sqlca.updateObject("insert into t_compinfo_product(compid,productid,productProperty,productCount) values(?,?,?,?)", new String[] {CompID,productID,compStyle,"0"});
				}
			}
			productrs.close();
			productps.close();
			
			//同步旧系统产品独立租赁到新系统字段
			Statement updateproduct = connection.createStatement();
			PreparedStatement prodcutidps = connection.prepareStatement("select tcp.compId,tcp.productId,tcp.productProperty from t_compinfo tc INNER JOIN t_compinfo_product tcp on tc.CompID=tcp.compId and tc.compstyle is null");
			ResultSet prodcutidrs = prodcutidps.executeQuery();
			while(prodcutidrs.next())
			{
				String compId = prodcutidrs.getString("compId");
				String productId = prodcutidrs.getString("productId");
				String productProperty = prodcutidrs.getString("productProperty");
				if(null!=compId && null!=productId && null!=productProperty && !"".equals(productProperty))
				{
					updateproduct.addBatch("update t_compinfo set compStyle="+productProperty+" where CompID="+compId);
				}
			}
			updateproduct.executeBatch();
			updateproduct.close();
			prodcutidrs.close();
			prodcutidps.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally
		{
			connection.close();
		}
		
		logger.info("update DataSynchronized end");
	}
	
	//旧系统同步产品到订单
//	private synchronized void SynProductToOrder() throws Exception
//	{
//		logger.info("update SynProductToOrder execute");
//		String updatesql = " select t.CompID "+
//				" from t_compinfo t left JOIN t_order tt on t.CompID=tt.o_CompID "+ 
//				" where t.MaxEnddate is not null and CreateDate>='2018-12-11 00:00:00' and tt.o_CompID is null ";
//		
//		
//		String sql = "INSERT INTO t_order(o_type,o_maxusercount,o_product,o_usedays,o_createdate,o_enddate,o_usetimes,o_status,o_adminid,o_compid,o_CompName,source) "+ 
//		" select (case when t.CompStatus='5' then '1' when t.CompStatus='10' then '3' when t.CompStatus='6' then '1' when t.CompStatus='9' then '2' when t.CompStatus='1' then '2' end ) as type "+
//		" ,t.MaxUserCount,(select pp.productId from t_compinfo_product pp where pp.compId=t.compid) as product, "+
//		" (to_days(SUBSTR(t.EndDate,1,10))-to_days(SUBSTR(t.CreateDate,1,10))) as usedays,t.CreateDate,t.EndDate,10 as usetimes,'1' as ostatus,t.AdminID,t.CompID,t.CompTrueName,'old' "+
//		" from t_compinfo t left JOIN t_order tt on t.CompID=tt.o_CompID "+ 
//		" where t.MaxEnddate is not null and CreateDate>='2018-12-11 00:00:00' and tt.o_CompID is null ";
//		
//		
//		Connection connection = Sqlca.getConnection();
//		try
//		{
//			PreparedStatement ps = connection.prepareStatement(updatesql);
//			ResultSet rs = ps.executeQuery();
//			while(rs.next())
//			{
//				String CompID = rs.getString("CompID");
//				String pid = Sqlca.getString("select tp.productId from t_compinfo_product tp where tp.compId='"+CompID+"'");
//				Sqlca.updateObject("UPDATE t_compinfo tt set tt.productID=? where tt.CompID=?", new String[] {pid,CompID});
//			}
//			rs.close();
//			ps.close();
//			
//			
//			PreparedStatement pp = connection.prepareStatement(sql);
//			pp.execute();
//			pp.close();
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//			logger.info(e.getMessage());
//		}
//		finally
//		{
//			connection.close();
//		}
//		
//		logger.info("update SynProductToOrder end");
//	}
	
	//更新客户公司状态
	private void UpdateCompStatus() throws Exception
	{
		logger.info("update UpdateCompStatus execute");
		////延期日期到期
		String CurrentDate = DateUtil.getDateYMD(DateUtil.dateFormat(0), "00:00:00");
		String compstatus2 = "1";
		String updatesql2 = "select CompID,ContractEndTime,CreateDate,EndDate,CompStatus from t_compinfo where SUBSTR(EndDate,1,10)='"+DateUtil.dateFormat(-1,0)+"'";
		
		ArrayList<Map<String, Object>> list2 = Sqlca.getArrayListFromMap(updatesql2);
		for(Map<String, Object> map2 : list2)
		{
//			Map<String,Object> map2 = list2.get(0);
			String CompID = (String)map2.get("CompID");
			String ContractEndTime2 = (String)map2.get("ContractEndTime");
			String EndDate2 = (String)map2.get("EndDate");
			String CreateDate2 = (String)map2.get("CreateDate");
			String temptatus = (String)map2.get("CompStatus");
			
			
			if(ContractEndTime2!=null && !"".equals(ContractEndTime2))
			{
				if(CurrentDate.compareTo(ContractEndTime2)>0)
				{
					compstatus2="6";
				}
				else
				{
					compstatus2="1";
				}
			}
			else
			{
				if(CurrentDate.compareTo(EndDate2)>0)	
				{
					compstatus2 = "8";
				}
				else
				{
					compstatus2 = "5";
				}
			}
			Sqlca.updateObject("update t_compinfo set CompStatus="+compstatus2+" where CompID=?", new String[] {CompID});
		}
		
		//合同到期
		String compstatus3="1";
		String updatesql3 = "select CompID,ContractEndTime,CreateDate,EndDate,CompStatus from t_compinfo where SUBSTR(ContractEndTime,1,10)='"+DateUtil.dateFormat(-1,0)+"'";
		
		ArrayList<Map<String, Object>> list3 = Sqlca.getArrayListFromMap(updatesql3);
		for(Map<String, Object> map3 : list3)
		{
//			Map<String,Object> map2 = list2.get(0);
			String CompID = (String)map3.get("CompID");
			String ContractEndTime3 = (String)map3.get("ContractEndTime");
			String EndDate3 = (String)map3.get("EndDate");
			String CreateDate3 = (String)map3.get("CreateDate");
			String temptatus = (String)map3.get("CompStatus");
			
			if(ContractEndTime3!=null && !"".equals(ContractEndTime3))
			{
				if(CurrentDate.compareTo(ContractEndTime3)>0)
				{
					compstatus3="6";
				}
				else
				{
					compstatus3="1";
				}
			}
			Sqlca.updateObject("update t_compinfo set CompStatus="+compstatus3+" where CompID=?", new String[] {CompID});
		}
		
		
		
		
		////生效日期开始
		String compstatus1 = "1";
		String updatesql1 = "select CompID,ContractEndTime,CreateDate,EndDate,CompStatus from t_compinfo where SUBSTR(CreateDate,1,10)='"+DateUtil.dateFormat(0)+"'";
		ArrayList<Map<String, Object>> list1 = Sqlca.getArrayListFromMap(updatesql1);
		for(Map<String, Object> map1 : list1)
		{
			String CompID = (String)map1.get("CompID");
			String ContractEndTime = (String)map1.get("ContractEndTime");
			String CreateDate = (String)map1.get("CreateDate");
			String temptatus = (String)map1.get("CompStatus");
			String EndDate = (String)map1.get("EndDate");
			if(ContractEndTime!=null && !"".equals(ContractEndTime))
			{
				if(CurrentDate.compareTo(ContractEndTime)>0)
				{
					compstatus1="6";
				}
				else
				{
//					if("10".equals(temptatus))
//					{
//						if(CurrentDate.compareTo(EndDate)<0)
//						{
//							compstatus2="10";
//						}
//					}
//					else
//					{
//						compstatus2="1";
//					}
				}
			}
			else
			{
				if(CurrentDate.compareTo(CreateDate)>0)	
				{
					compstatus1 = "5";
				}
				else
				{
					compstatus1 = "8";
				}
			}
			Sqlca.updateObject("update t_compinfo set CompStatus="+compstatus1+" where CompID=?", new String[] {CompID});
		}
		
		
		logger.info("update UpdateCompStatus execute end");
	}
	
	private void UpdateOrderStatus() throws Exception
	{
		logger.info("update UpdateOrderStatus execute");
		String sql = "update t_order set o_Status=? where id IN(SELECT * FROM (select tt.id from t_order tt where SUBSTR(tt.o_EndDate,1,10)='"+DateUtil.dateFormat(-1,0)+"') t)";
		Sqlca.updateObject(sql, new String[] {"5"});
		logger.info("update UpdateOrderStatus execute end");
	}

}
