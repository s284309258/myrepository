package com.huawang.page;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnect {
	private Connection connection = null;

	private ResultSet res = null;

	private Statement statement = null;

	private PreparedStatement preparedStatement = null;

	private DBConnectionManager dcm = null;

	public PreparedStatement getPreparedStatement() {		
		return preparedStatement;
	}
	public PreparedStatement getPreparedStatement( String sql) {
		this.setPreparedStatement(sql);
		return preparedStatement;
	}
	public PreparedStatement getPreparedStatement( String sql,int key) {
		this.setPreparedStatement(sql, key);
		return preparedStatement;
	}
	public Statement getStatement()
	{
		this.setStatement();
		return statement;
	}
	public void setPreparedStatement( String sql) {
		try {
			
			this.preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setPreparedStatement( String sql,int key) {
		try {
			
			this.preparedStatement = connection.prepareStatement(sql,key);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public DBConnectionManager getDcm() {
		return dcm;
	}	
	/**
	 * 返回连接
	 * @return Connection 连接
	 * 为了更好的扩展性
	 */
	public Connection getConnection() {
		return connection;
	}

	public void setDcm() {
		this.dcm = DBConnectionManager.getInstance();
	}

	public void setConnection() {
		this.connection = dcm.getConnection();
	}

	public void setStatement() {
		try {
			this.statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void init() {
		this.setDcm();
		this.setConnection();
	}

	/**
	 * 构造数据库的连接和访问类
	 */
	public DBConnect(){
		init();
		this.setStatement();
	}
	/**
	 * 构造数据库的连接和访问类 预编译SQL语句
	 * 
	 * @param sql
	 *            SQL语句
	 */
	
	public DBConnect(String sql)  {
		init();
		this.setPreparedStatement(sql);	
	}
	
	/**
	 * PreparedStatement
	 * 
	 * @return sql 预设SQL语句
	 */
	public void clearParameters() throws SQLException {
	
		preparedStatement.close();
		preparedStatement = null;
	}

	/**
	 * 执行SQL语句返回字段集
	 * 
	 * @param sql
	 *            SQL语句
	 * @return ResultSet 字段集
	 */
	public ResultSet executeQuery(String sql) throws SQLException {
		if ( preparedStatement != null) {
			return preparedStatement.executeQuery( sql);
		} else {
			return null;
		}			
	}

	public ResultSet executeQuery() throws SQLException {
		if (preparedStatement != null) {
			return preparedStatement.executeQuery();
		}else {	
			return null;
		}
	}

	/**
	 * 执行SQL语句
	 * 
	 * @param sql
	 *            SQL语句
	 * @throws SQLException
	 */
	public int executeUpdate(String sql) throws SQLException {
		int i = 0;
		if (preparedStatement != null) {
			i = preparedStatement.executeUpdate(sql);
		}
		return i;
	}

	public int executeUpdate() throws SQLException {
		int i = 0;
		if (preparedStatement != null) {
			i = preparedStatement.executeUpdate();
		}
		return i;
	}
	
	/**
	 * 关闭连接
	 */
	public void release() {
		try {
			if(res!= null)
			{
				res.close();
				res = null;
			}
			if (preparedStatement != null) {

				preparedStatement.close();
				preparedStatement = null;
			}
			if (statement != null) {
				statement.close();
				statement = null;
			}
			if (connection != null) {
				dcm.freeConnection( connection);
			}
		} catch (SQLException e) {
			// TODO 自动生成 catch 块
			e.printStackTrace();
		}	
	}
}