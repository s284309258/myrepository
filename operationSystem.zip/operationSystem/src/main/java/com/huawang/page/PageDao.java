package com.huawang.page;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 

public class PageDao {
	DBConnect tool = new DBConnect();
	ResultSet res;
	PreparedStatement prestam;
	public int getCount(String countSql)
	{
		int amount = 0;
		prestam = tool.getPreparedStatement(countSql);
		try {
			res = prestam.executeQuery();
			res.next();
			amount = res.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			tool.release();
		}
		return amount;
	}
}
