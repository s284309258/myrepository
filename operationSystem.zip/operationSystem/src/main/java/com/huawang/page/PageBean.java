package com.huawang.page;

public class PageBean {
	/**
     * 这是一个分页的类，因为MySQL数据库检索可以使用分页的SQL指令
     * 所在在这里主要是处理出这样的指令
     * 并获得相应的页数信息
     *MySql语句如下:select * from test limit 10;这句是从1到10的信息条数
     *select * from test limit 10,5;   这句是第十条以后的五条
     */
    int curr; //当前页

    int count; //总页数

    int size; //每页显示数据数

    int rows=0; //数据的所有行数

    boolean last; // 是否是最后一页
    /**
     * 构造器
     * @param counSql
     */
    PageDao pageDao = new PageDao();
    public PageBean(String counSql) {
         if (this.rows == 0) {//获取所有的数据条数
            this.rows = pageDao.getCount(counSql);
         }
         this.curr=getCurr();
         this.size = 35;//设定页面显示数据大小
         this.count = (int) Math.ceil((double) this.rows / this.size);//获得页数
         this.last=isLast();
    }
    public PageBean(String counSql,int size){
     if (this.rows == 0) {//获取所有的数据条数
        this.rows = pageDao.getCount(counSql);
     }
     this.curr=getCurr();
     this.size = size;//设定页面显示数据大小
     this.count = (int) Math.ceil((double) this.rows / this.size);
     this.last=isLast();
    }
    public PageBean(String counSql,int curr,int size){
     if (this.rows == 0) {//获取所有的数据条数
        this.rows = pageDao.getCount(counSql);
     }
     this.curr=curr;
     this.size = size;//设定页面显示数据大小
     this.count = (int) Math.ceil((double) this.rows / this.size);
     this.last=isLast();
    }
    /**
     * 页面指令处理及返回相应的查询SQL语句
     */
    public String pageDeal(String pageDo) {
         String str = " limit ";
         //首页
         if (pageDo.equals("first")) {
            setCurr(1);
            str += "" + getSize();
         }
         //尾页
         if (pageDo.equals("end")) {
            setCurr(getCount());
            str += "" + ((getCount() - 1) * getSize());
            str += "," + (getRows() - (getCount() - 1) * getSize());
         }
         //下一页
         if (pageDo.equals("next")) {

            if(getCurr()<getCount()){
                str += "" + (getCurr() * getSize());
                str += "," + getSize();
                setCurr(getCurr() + 1);
            }else{
                setCurr(getCount());
                str += "" + ((getCount() - 1) * getSize());
                str += "," + (getRows() - (getCount() - 1) * getSize());
            }

         }
        //上一页
         if (pageDo.equals("prv")) {
            setCurr(getCurr() - 1);
            str += "" + (getCurr() * getSize() - getSize());
            str += "," + getSize();

         }
         return str;
    }public static void main(String[] args) { 
    }

    //返回总页数，总页最小也等于1
    public int getCount() {
         return (count == 0) ? 1 : count;
    }

    //设置总页数
    public void setCount(int count) {
         this.count = count;
    }

    //返回当前页,当前页最小也等于1
    public int getCurr() {
         return (curr == 0) ? 1 : curr;
    }
        //设置当前页
    public void setCurr(int curr) {
         this.curr = curr;
    }

    public int getRows() {
         return rows;
    }

    public void setRows(int rows) {
         this.rows = rows;
    }

    public int getSize() {
         return size;
    }

    public void setSize(int size) {
         this.size = size;
    }
    /**
     * 如果是最后一页的返回true
     * @return
     */
    public boolean isLast() {
         return (curr==count)?true:false;
    }
    public void setLast(boolean last) {
         this.last = last;
    }

}
