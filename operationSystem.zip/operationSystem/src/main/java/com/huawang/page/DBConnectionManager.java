package com.huawang.page;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class DBConnectionManager {
	static private DBConnectionManager instance; // 唯一实例

	static private int clients;

	private Vector drivers = new Vector();

	private PrintWriter log;

	private Vector pools = new Vector();

	/**
	 * 返回唯一实例.如果是第一次调用此方法,则创建实例
	 * 
	 * @return DBConnectionManager 唯一实例
	 */
	static synchronized public DBConnectionManager getInstance() {
		if (instance == null) {
			instance = new DBConnectionManager();
		}
		clients++;
		return instance;
		
	}

	/**
	 * 建构函数私有以防止其它对象创建本类实例
	 */
	private DBConnectionManager() {
		init();
	}



	/**
	 * 获得一个可用的(空闲的)连接.如果没有可用连接,且已有连接数小于最大连接数 限制,则创建并返回新连接
	 * 
	 * @param name
	 *            在属性文件中定义的连接池名字
	 * @return Connection 可用连接或null
	 */
//	public Connection getConnection(String name) {
//		DBConnection pool = (DBConnection) pools.get(name);
//		if (pool != null) {
//			return pool.getConnection();
//		} else {
//			return null;
//		}
//
//	}

	/**
	 * 获得一个可用连接.若没有可用连接,且已有连接数小于最大连接数限制, 则创建并返回新连接.否则,在指定的时间内等待其它线程释放连接.
	 * 
	 * @param name
	 *            连接池名字
	 * @param time
	 *            以毫秒计的等待时间
	 * @return Connection 可用连接或null
	 */
//	public Connection getConnection(String name, long time) {
//		DBConnectionManager pool = (DBConnectionManager) pools.get(name);
//		if (pool != null) {
//			return pool.getConnection(time);
//		}
//		return null;
//	}

	/**
	 * 关闭所有连接,撤销驱动程序的注册
	 */
	public synchronized void release() {
		// 等待直到最后一个客户程序调用
		if (--clients != 0) {
			return;
		}

		Enumeration allPools = pools.elements();
		while (allPools.hasMoreElements()) {
			DBConnectionManager pool = ( DBConnectionManager) allPools.nextElement();
			pool.release();
		}
		Enumeration allDrivers = drivers.elements();
		while (allDrivers.hasMoreElements()) {
			Driver driver = (Driver) allDrivers.nextElement();
			try {
				DriverManager.deregisterDriver(driver);
				System.out.println("撤销JDBC驱动程序 " + driver.getClass().getName()
						+ "的注册");
			} catch (SQLException e) {
				System.out.println("无法撤销下列JDBC驱动程序的注册: "
						+ driver.getClass().getName());
			}
		}
	}

	/**
	 * 根据指定属性 对各个属性设置值.
	 * 
	 * @param props
	 *            连接池属性
	 *            
	 */
	

	/**
	 * 根据指定属性创建连接池实例.
	 * 
	 * @param props
	 *            连接池属性
	 */
	private void createPools(Properties props) {
		Enumeration propNames = props.propertyNames();
		while (propNames.hasMoreElements()) {
			String name = (String) propNames.nextElement();
			if (name.endsWith(".url")) {
				 poolName = name.substring(0, name.lastIndexOf("."));
				 url = props.getProperty(poolName + ".url");
				if (url == null) {
					System.out.println("没有为连接池" + poolName + "指定URL");
					continue;
				}
				 user = props.getProperty(poolName + ".user");
				 password = props.getProperty(poolName + ".password");
				String maxconn = props.getProperty(poolName + ".maxConn", "5");
				int max;
				try {
					max = Integer.valueOf(maxconn).intValue();
			
					for ( int i=0 ;i<max;i++){
						Connection conn = DriverManager.getConnection( url,user, password);
						
						System.out.println("成功创建新的连接 Connection 对象");
						pools.add(i, conn);
						System.out.println(pools.size());
					}
					System.out.println("成功创建连接池" + poolName);
				} catch (NumberFormatException e) {
					System.out.println("错误的最大连接数限制: " + maxconn + " .连接池: "
							+ poolName);
					max = 0;
				} catch (SQLException e) {

					e.printStackTrace();
				}
				
			
			}
		}
	}

	/**
	 * 读取属性完成初始化
	 */
	private void init() {
		InputStream is = getClass().getResourceAsStream("/config.properties");
		Properties dbProps = new Properties();
		try {
			dbProps.load(is);
		} catch (Exception e) {
			System.err.println("不能读取属性文件. "
					+ "请确保db.properties在CLASSPATH指定的路径中");
			return;
		}
		String logFile = dbProps.getProperty("logfile", "newslog.txt");
		try {
			log = new PrintWriter(new FileWriter(logFile, true), true);
		} catch (IOException e) {
			System.err.println("无法打开日志文件: " + logFile);
			log = new PrintWriter(System.err);
		}
		loadDrivers(dbProps);
		createPools(dbProps);
	}

	/**
	 * 装载和注册所有JDBC驱动程序
	 * 
	 * @param props
	 *            属性
	 */
	private void loadDrivers(Properties props) {
		String driverClasses = props.getProperty("driver");
		StringTokenizer st = new StringTokenizer(driverClasses);
		while (st.hasMoreElements()) {
			String driverClassName = st.nextToken().trim();
			try {
				Driver driver = (Driver) Class.forName(driverClassName)
						.newInstance();
				DriverManager.registerDriver(driver);
				drivers.addElement(driver);
				System.out.println("成功注册数据库驱动程序" + driverClassName);
			} catch (Exception e) {
				System.out.println("无法注册数据库驱动程序: " + driverClassName
						+ ", 错误: " + e);
			}
		}
	}

	/**
	 * 将文本信息写入日志文件
	 */
	private void log(String msg) {
		log.println(new Date() + ": " + msg);
	}

	/**
	 * 将文本信息与异常写入日志文件
	 */
	private void log(Throwable e, String msg) {
		log.println(new Date() + ": " + msg);
		e.printStackTrace(log);
	}
	

	public DBConnectionManager(String name, String url, String user,
			String password, int maxConn) {
		this.name = name;
		this.url = url;
		this.user = user;
		this.password = password;
		this.maxConn = maxConn;
	}
	
	/**
	 * 将连接对象返回给由名字指定的连接池
	 * 
	 * @param name
	 *            在属性文件中定义的连接池名字
	 * @param con
	 *            连接对象
	 */

	public synchronized void freeConnection(Connection con) {
		// 将指定连接加入到向量末尾
		pools.addElement(con);
		checkedOut--;
		notifyAll();

	}

	/**
	 * 从连接池获得一个可用连接.如没有空闲的连接且当前连接数小于最大连接 数限制,则创建新连接.如原来登记为可用的连接不再有效,则从向量删除之,
	 * 然后递归调用自己以尝试新的可用连接.
	 * @return 
	 * 			返回一个可用的连接
	 */
	public synchronized Connection getConnection() {
		Connection con = null;
		System.out.println( "正在使用的"+ checkedOut);
		System.out.println( "空闲的连接数"+ pools.size());
		if (pools.size()> 0 ) {
			// 获取变量中第一个可用连接
			con = (Connection) pools.firstElement();
			
			pools.removeElementAt(0);

//			if (con == null) {
//				con = getConnection(); // 继续获得连接
//			}
			
			 try {
				 if (con.isClosed()) {
				 System.out.println("从连接池" + poolName + "删除一个无效连接");
				 // 递归调用自己,尝试再次获取可用连接
				 con = getConnection();
				 }
			 } catch (SQLException e) {
								
				 System.out.println("从连接池" + poolName + "删除一个无效连接");
				 // 递归调用自己,尝试再次获取可用连接
				 con = getConnection();							
			 }
			 
		} else if (pools.size() <= 0 || checkedOut < maxConn) {
			con = newConnection( );
		}
		
		if (con != null) {
			checkedOut++;

			System.out.println("有" + checkedOut + "个在使用");
		}
		return con;
	}

	/**
	 * 从连接池获取可用连接.可以指定客户程序能够等待的最长时间 参见前一个getConnection()方法.
	 * 
	 * @param timeout
	 *            以毫秒计的等待时间限制
	 */
	public synchronized Connection getConnection(long timeout) {
		long startTime = new Date().getTime();
		Connection con;
		while ((con = getConnection()) == null) {
			try {
				wait(timeout);
			} catch (InterruptedException e) {
			}
			if ((new Date().getTime() - startTime) >= timeout) {
				// wait()返回的原因是超时
				return null;
			}
		}
		return con;
	}

	/**
	 * 关闭所有连接
	 */
	public synchronized void releaseAll() {
		Enumeration allConnections = pools.elements();
		while (allConnections.hasMoreElements()) {
			Connection con = (Connection) allConnections.nextElement();
			try {
				con.close();
				System.out.println("关闭连接池" + name + "中的一个连接");
			} catch (SQLException e) {
				System.out.println("无法关闭连接池" + name + "中的连接");
			}
		}
		pools.removeAllElements();
	}

	/**
	 * 创建新的连接
	 */
	private Connection newConnection( ) {
	
		Connection con = null;
		try {
			if (user == null) {
				con = DriverManager.getConnection(url);
			} else {
				con = DriverManager.getConnection(url, user, password);
			}
			pools.addElement( con);
			System.out.println("***********创建一个新的连接 ***********");
			System.out.println("*****连接池"+poolName+"又增加了新的连接******");

		} catch (SQLException e) {
			System.out.println("************无法创建新的连接************ ");
			return null;
		}
		return con;
	}
	
	private static int checkedOut=0; //正在用的连接数

	private int maxConn; // 最大连接数

	private String name;

	private String password;

	private String url;

	private String user;
	
	private String poolName;
	/**
	 * 创建新的连接池
	 * 
	 * @param name
	 *            连接池名字
	 * @param URL
	 *            数据库的JDBC URL
	 * @param user
	 *            数据库帐号,或 null
	 * @param password
	 *            密码,或 null
	 * @param maxConn
	 *            此连接池允许建立的最大连接数
	 */
}
