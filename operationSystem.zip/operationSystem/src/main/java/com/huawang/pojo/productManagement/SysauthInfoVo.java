package com.huawang.pojo.productManagement;

public class SysauthInfoVo {
	
	/**
	 * 授权信息ID
	 */
	private Integer authIdd;
	
	/**
	 * 产品ID
	 */
	private Integer productId;
	
	/**
	 * 系统参数
	 */
	private String systemParameter;
	/**
	 * 显示名称
	 */
	private String displayName;
	
	/**
	 * 是否可编辑（0 可编辑 1 不可编辑）
	 */
	private String isEditable;
	
	/**
	 * 默认值
	 */
	private String defaultValue;
	
	/**
	 * 是否参数值（0 是 1 不是）
	 */
	private String isParaValue;
	
	/**
	 * @return the systemParameter
	 */
	public String getSystemParameter() {
		return systemParameter;
	}
	/**
	 * @param systemParameter the systemParameter to set
	 */
	public void setSystemParameter(String systemParameter) {
		this.systemParameter = systemParameter;
	}
	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}
	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	/**
	 * @return the isEditable
	 */
	public String getIsEditable() {
		return isEditable;
	}
	/**
	 * @param isEditable the isEditable to set
	 */
	public void setIsEditable(String isEditable) {
		this.isEditable = isEditable;
	}
	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue() {
		return defaultValue;
	}
	/**
	 * @param defaultValue the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	/**
	 * @return the isParaValue
	 */
	public String getIsParaValue() {
		return isParaValue;
	}
	/**
	 * @param isParaValue the isParaValue to set
	 */
	public void setIsParaValue(String isParaValue) {
		this.isParaValue = isParaValue;
	}
	public Integer getAuthIdd() {
		return authIdd;
	}
	public void setAuthIdd(Integer authIdd) {
		this.authIdd = authIdd;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	

}
