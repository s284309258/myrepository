package com.huawang.pojo.meetingRoom;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class TAdmininfo {

	public String codeno;
	public Integer adminId;
	public String adminName;
	public String adminPassword;
	public String adminTrueName;
	public String adminIsSuper;
	public Integer  parentId;
	public String email;
	public String sex;
	public String contact;
	public String createBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String createDate;
	public String updateBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String updateDate;
	
	public String dpId;
	public String dpName;
	
	public String role;
	public String fn;
	public List<String> list;
	
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getFn() {
		return fn;
	}
	public void setFn(String fn) {
		this.fn = fn;
	}
	/**
	 * @return the codeno
	 */
	public String getCodeno() {
		return codeno;
	}
	/**
	 * @param codeno the codeno to set
	 */
	public void setCodeno(String codeno) {
		this.codeno = codeno;
	}
	/**
	 * @return the adminId
	 */
	public Integer getAdminId() {
		return adminId;
	}
	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	/**
	 * @return the adminName
	 */
	public String getAdminName() {
		return adminName;
	}
	/**
	 * @param adminName the adminName to set
	 */
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	/**
	 * @return the adminPassword
	 */
	public String getAdminPassword() {
		return adminPassword;
	}
	/**
	 * @param adminPassword the adminPassword to set
	 */
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	/**
	 * @return the adminTrueName
	 */
	public String getAdminTrueName() {
		return adminTrueName;
	}
	/**
	 * @param adminTrueName the adminTrueName to set
	 */
	public void setAdminTrueName(String adminTrueName) {
		this.adminTrueName = adminTrueName;
	}
	/**
	 * @return the adminIsSuper
	 */
	public String getAdminIsSuper() {
		return adminIsSuper;
	}
	/**
	 * @param adminIsSuper the adminIsSuper to set
	 */
	public void setAdminIsSuper(String adminIsSuper) {
		this.adminIsSuper = adminIsSuper;
	}
	/**
	 * @return the parentId
	 */
	public Integer getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}
	/**
	 * @param contact the contact to set
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}
	/**
	 * @return the dpName
	 */
	public String getDpName() {
		return dpName;
	}
	/**
	 * @param dpName the dpName to set
	 */
	public void setDpName(String dpName) {
		this.dpName = dpName;
	}
	/**
	 * @return the dpId
	 */
	public String getDpId() {
		return dpId;
	}
	/**
	 * @param dpId the dpId to set
	 */
	public void setDpId(String dpId) {
		this.dpId = dpId;
	}
	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}
	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}
	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return the list
	 */
	public List<String> getList() {
		return list;
	}
	/**
	 * @param list the list to set
	 */
	public void setList(List<String> list) {
		this.list = list;
	}
	
	
}
