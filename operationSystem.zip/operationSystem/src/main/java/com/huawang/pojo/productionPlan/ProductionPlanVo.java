/**
 * 
 */
package com.huawang.pojo.productionPlan;

import org.springframework.format.annotation.DateTimeFormat;

public class ProductionPlanVo {

	/**
	 * 生产计划ID
	 */
	private Integer planId;
	
	/**
	 * 状态（0审核中、1已完成、2实施中、3已终止、4被驳回）
	 */
	private String status;
	
	/**
	 * 计划类型（0自产 1外购）
	 */
	private String planType;
	
	/**
	 * 计划周期（天）
	 */
	private String planningCycle;
	
	/**
	 * 计划开始时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String startTime;
	
	/**
	 * 计划结束时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String endTime;
	
	/**
	 * 需求产品
	 */
	private String demandProduct;
	
	/**
	 * 需求数量
	 */
	private String requiredQuantity;
	
	/**
	 * 完成数量
	 */
	private String amountCompleted;
	
	/**
	 * 报废数量
	 */
	private String retiredQuantity;
	
	/**
	 * 发起人
	 */
	private String createBy;
	
	/**
	 * 发起时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDate;
	
	/**
	 * 更新人
	 */
	private String updateBy;
	
	/**
	 * 更新时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String updateDate;
	
	/**
	 * 备注信息
	 */
	private String remarks;
	
	private String pstatus;
	
	/**
	 * 附件
	 */
	private String attachments;
	
	private BizRecordVo recordVo;
	
	private BizProcessVo processVo;
	
	/**
	 * 发起开始时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDateStart;
	
	/**
	 * 发起结束时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDateEnd;

	/**
	 * @return the planId
	 */
	public Integer getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the planType
	 */
	public String getPlanType() {
		return planType;
	}

	/**
	 * @param planType the planType to set
	 */
	public void setPlanType(String planType) {
		this.planType = planType;
	}

	/**
	 * @return the planningCycle
	 */
	public String getPlanningCycle() {
		return planningCycle;
	}

	/**
	 * @param planningCycle the planningCycle to set
	 */
	public void setPlanningCycle(String planningCycle) {
		this.planningCycle = planningCycle;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the demandProduct
	 */
	public String getDemandProduct() {
		return demandProduct;
	}

	/**
	 * @param demandProduct the demandProduct to set
	 */
	public void setDemandProduct(String demandProduct) {
		this.demandProduct = demandProduct;
	}

	/**
	 * @return the requiredQuantity
	 */
	public String getRequiredQuantity() {
		return requiredQuantity;
	}

	/**
	 * @param requiredQuantity the requiredQuantity to set
	 */
	public void setRequiredQuantity(String requiredQuantity) {
		this.requiredQuantity = requiredQuantity;
	}

	/**
	 * @return the amountCompleted
	 */
	public String getAmountCompleted() {
		return amountCompleted;
	}

	/**
	 * @param amountCompleted the amountCompleted to set
	 */
	public void setAmountCompleted(String amountCompleted) {
		this.amountCompleted = amountCompleted;
	}

	/**
	 * @return the retiredQuantity
	 */
	public String getRetiredQuantity() {
		return retiredQuantity;
	}

	/**
	 * @param retiredQuantity the retiredQuantity to set
	 */
	public void setRetiredQuantity(String retiredQuantity) {
		this.retiredQuantity = retiredQuantity;
	}

	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}

	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}

	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the attachments
	 */
	public String getAttachments() {
		return attachments;
	}

	/**
	 * @param attachments the attachments to set
	 */
	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public BizRecordVo getRecordVo() {
		return recordVo;
	}

	public void setRecordVo(BizRecordVo recordVo) {
		this.recordVo = recordVo;
	}

	/**
	 * @return the processVo
	 */
	public BizProcessVo getProcessVo() {
		return processVo;
	}

	/**
	 * @param processVo the processVo to set
	 */
	public void setProcessVo(BizProcessVo processVo) {
		this.processVo = processVo;
	}

	/**
	 * @return the createDateStart
	 */
	public String getCreateDateStart() {
		return createDateStart;
	}

	/**
	 * @param createDateStart the createDateStart to set
	 */
	public void setCreateDateStart(String createDateStart) {
		this.createDateStart = createDateStart;
	}

	/**
	 * @return the createDateEnd
	 */
	public String getCreateDateEnd() {
		return createDateEnd;
	}

	/**
	 * @param createDateEnd the createDateEnd to set
	 */
	public void setCreateDateEnd(String createDateEnd) {
		this.createDateEnd = createDateEnd;
	}

	/**
	 * @return the pstatus
	 */
	public String getPstatus() {
		return pstatus;
	}

	/**
	 * @param pstatus the pstatus to set
	 */
	public void setPstatus(String pstatus) {
		this.pstatus = pstatus;
	}
	
}
