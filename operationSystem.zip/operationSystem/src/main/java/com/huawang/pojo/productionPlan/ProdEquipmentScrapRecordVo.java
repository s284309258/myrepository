package com.huawang.pojo.productionPlan;

public class ProdEquipmentScrapRecordVo {

	private Integer recordId;
	private String listId;
	private String retiredQuantity;
	private String operator;
	private String discardedTime;
	private String discardedReason;
	
	/**
	 * @return the recordId
	 */
	public Integer getRecordId() {
		return recordId;
	}
	/**
	 * @param recordId the recordId to set
	 */
	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}
	/**
	 * @return the listId
	 */
	public String getListId() {
		return listId;
	}
	/**
	 * @param listId the listId to set
	 */
	public void setListId(String listId) {
		this.listId = listId;
	}
	/**
	 * @return the retiredQuantity
	 */
	public String getRetiredQuantity() {
		return retiredQuantity;
	}
	/**
	 * @param retiredQuantity the retiredQuantity to set
	 */
	public void setRetiredQuantity(String retiredQuantity) {
		this.retiredQuantity = retiredQuantity;
	}
	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * @param operator the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * @return the discardedTime
	 */
	public String getDiscardedTime() {
		return discardedTime;
	}
	/**
	 * @param discardedTime the discardedTime to set
	 */
	public void setDiscardedTime(String discardedTime) {
		this.discardedTime = discardedTime;
	}
	/**
	 * @return the discardedReason
	 */
	public String getDiscardedReason() {
		return discardedReason;
	}
	/**
	 * @param discardedReason the discardedReason to set
	 */
	public void setDiscardedReason(String discardedReason) {
		this.discardedReason = discardedReason;
	}
	
	
}
