package com.huawang.pojo.operation;

import java.util.List;

public class TServerGroupInfo {

	private Integer serverId;
	private String groupid;
	private Integer Level;
	private List<String> strList;
	
	private String mark;
	
	/**
	 * @return the serverId
	 */
	public Integer getServerId() {
		return serverId;
	}
	/**
	 * @param serverId the serverId to set
	 */
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}
	/**
	 * @return the groupid
	 */
	public String getGroupid() {
		return groupid;
	}
	/**
	 * @param groupid the groupid to set
	 */
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	/**
	 * @return the level
	 */
	public Integer getLevel() {
		return Level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(Integer level) {
		Level = level;
	}
	/**
	 * @return the strList
	 */
	public List<String> getStrList() {
		return strList;
	}
	/**
	 * @param strList the strList to set
	 */
	public void setStrList(List<String> strList) {
		this.strList = strList;
	}
	/**
	 * @return the mark
	 */
	public String getMark() {
		return mark;
	}
	/**
	 * @param mark the mark to set
	 */
	public void setMark(String mark) {
		this.mark = mark;
	}
}
