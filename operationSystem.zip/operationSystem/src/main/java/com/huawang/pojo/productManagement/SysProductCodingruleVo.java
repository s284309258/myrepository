package com.huawang.pojo.productManagement;

import org.springframework.format.annotation.DateTimeFormat;

public class SysProductCodingruleVo {
	
	/**
	 * 编码规则ID
	 */
	private Integer codingRuleId;
	
	/**
	 * 产品ID
	 */
	private Integer productId;
	
	/**
	 * 编码类型（0 按品类计算序号 1 按产品计算序号）
	 */
	private String codingType;
	
	/**
	 * 固定字符
	 */
	private String fixedCharacter;
	
	/**
	 * 品类标识
	 */
	private String categoryIdentification;
	
	/**
	 * 时间参数（0计算到年 1计算到月 2计算到日）
	 */
	private String timeParameter;
	
	/**
	 * 计数序号位数
	 */
	private String serialLength;
	
	/**
	 * 最大序号
	 */
	private String maximumNo;
	
	/**
	 * 时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDate;

	/**
	 * @return the codingType
	 */
	public String getCodingType() {
		return codingType;
	}

	/**
	 * @param codingType the codingType to set
	 */
	public void setCodingType(String codingType) {
		this.codingType = codingType;
	}

	/**
	 * @return the fixedCharacter
	 */
	public String getFixedCharacter() {
		return fixedCharacter;
	}

	/**
	 * @param fixedCharacter the fixedCharacter to set
	 */
	public void setFixedCharacter(String fixedCharacter) {
		this.fixedCharacter = fixedCharacter;
	}

	/**
	 * @return the categoryIdentification
	 */
	public String getCategoryIdentification() {
		return categoryIdentification;
	}

	/**
	 * @param categoryIdentification the categoryIdentification to set
	 */
	public void setCategoryIdentification(String categoryIdentification) {
		this.categoryIdentification = categoryIdentification;
	}

	/**
	 * @return the timeParameter
	 */
	public String getTimeParameter() {
		return timeParameter;
	}

	/**
	 * @param timeParameter the timeParameter to set
	 */
	public void setTimeParameter(String timeParameter) {
		this.timeParameter = timeParameter;
	}

	/**
	 * @return the serialLength
	 */
	public String getSerialLength() {
		return serialLength;
	}

	/**
	 * @param serialLength the serialLength to set
	 */
	public void setSerialLength(String serialLength) {
		this.serialLength = serialLength;
	}

	/**
	 * @return the maximumNo
	 */
	public String getMaximumNo() {
		return maximumNo;
	}

	/**
	 * @param maximumNo the maximumNo to set
	 */
	public void setMaximumNo(String maximumNo) {
		this.maximumNo = maximumNo;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public Integer getCodingRuleId() {
		return codingRuleId;
	}

	public void setCodingRuleId(Integer codingRuleId) {
		this.codingRuleId = codingRuleId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

}
