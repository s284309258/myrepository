package com.huawang.pojo.operation;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class TServerinfo {

	public Integer serverId;
	public String serverName;
	public String serverIp;
	public Integer serverPort;
	public String serverType;
	public Integer parentId;
	public String parentServerIp;
	public String isPad;
	public String vsersionNum;
	public String vsersionInfo;
	public String localIp;
	public String createBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String createDate;
	public String updateBy;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String updateDate;
	
	public List<String> strList;
	public TServerGroupInfo groupInfo;
	public TServerbitinfo serverbitinfo;
	
	public Integer userCount;
	public Integer upBit;
	public Integer clusterCounts;
	public String groupid;
	
	public String strServerIdS;
	
	public int serverIp_1;
	
	/**
	 * @return the serverI
	 */
	public Integer getServerId() {
		return serverId;
	}
	/**
	 * @param serverI the serverI to set
	 */
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}
	/**
	 * @return the serverName
	 */
	public String getServerName() {
		return serverName;
	}
	/**
	 * @param serverName the serverName to set
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	/**
	 * @return the serverIp
	 */
	public String getServerIp() {
		return serverIp;
	}
	/**
	 * @param serverIp the serverIp to set
	 */
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	/**
	 * @return the serverPort
	 */
	public Integer getServerPort() {
		return serverPort;
	}
	/**
	 * @param serverPort the serverPort to set
	 */
	public void setServerPort(Integer serverPort) {
		this.serverPort = serverPort;
	}
	/**
	 * @return the serverType
	 */
	public String getServerType() {
		return serverType;
	}
	/**
	 * @param serverType the serverType to set
	 */
	public void setServerType(String serverType) {
		this.serverType = serverType;
	}
	/**
	 * @return the parentId
	 */
	public Integer getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	/**
	 * @return the parentServerIp
	 */
	public String getParentServerIp() {
		return parentServerIp;
	}
	/**
	 * @param parentServerIp the parentServerIp to set
	 */
	public void setParentServerIp(String parentServerIp) {
		this.parentServerIp = parentServerIp;
	}
	/**
	 * @return the isPad
	 */
	public String getIsPad() {
		return isPad;
	}
	/**
	 * @param isPad the isPad to set
	 */
	public void setIsPad(String isPad) {
		this.isPad = isPad;
	}
	/**
	 * @return the vsersionNum
	 */
	public String getVsersionNum() {
		return vsersionNum;
	}
	/**
	 * @param vsersionNum the vsersionNum to set
	 */
	public void setVsersionNum(String vsersionNum) {
		this.vsersionNum = vsersionNum;
	}
	/**
	 * @return the vsersionInfo
	 */
	public String getVsersionInfo() {
		return vsersionInfo;
	}
	/**
	 * @param vsersionInfo the vsersionInfo to set
	 */
	public void setVsersionInfo(String vsersionInfo) {
		this.vsersionInfo = vsersionInfo;
	}
	/**
	 * @return the localIp
	 */
	public String getLocalIp() {
		return localIp;
	}
	/**
	 * @param localIp the localIp to set
	 */
	public void setLocalIp(String localIp) {
		this.localIp = localIp;
	}
	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}
	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}
	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return the groupInfo
	 */
	public TServerGroupInfo getGroupInfo() {
		return groupInfo;
	}
	/**
	 * @param groupInfo the groupInfo to set
	 */
	public void setGroupInfo(TServerGroupInfo groupInfo) {
		this.groupInfo = groupInfo;
	}
	/**
	 * @return the strList
	 */
	public List<String> getStrList() {
		return strList;
	}
	/**
	 * @param strList the strList to set
	 */
	public void setStrList(List<String> strList) {
		this.strList = strList;
	}
	/**
	 * @return the serverbitinfo
	 */
	public TServerbitinfo getServerbitinfo() {
		return serverbitinfo;
	}
	/**
	 * @param serverbitinfo the serverbitinfo to set
	 */
	public void setServerbitinfo(TServerbitinfo serverbitinfo) {
		this.serverbitinfo = serverbitinfo;
	}
	/**
	 * @return the userCount
	 */
	public Integer getUserCount() {
		return userCount;
	}
	/**
	 * @param userCount the userCount to set
	 */
	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}
	/**
	 * @return the upBit
	 */
	public Integer getUpBit() {
		return upBit;
	}
	/**
	 * @param upBit the upBit to set
	 */
	public void setUpBit(Integer upBit) {
		this.upBit = upBit;
	}
	/**
	 * @return the strServerIdS
	 */
	public String getStrServerIdS() {
		return strServerIdS;
	}
	/**
	 * @param strServerIdS the strServerIdS to set
	 */
	public void setStrServerIdS(String strServerIdS) {
		this.strServerIdS = strServerIdS;
	}
	/**
	 * @return the clusterCounts
	 */
	public Integer getClusterCounts() {
		return clusterCounts;
	}
	/**
	 * @param clusterCounts the clusterCounts to set
	 */
	public void setClusterCounts(Integer clusterCounts) {
		this.clusterCounts = clusterCounts;
	}
	/**
	 * @return the groupid
	 */
	public String getGroupid() {
		return groupid;
	}
	/**
	 * @param groupid the groupid to set
	 */
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	/**
	 * @return the serverIp_1
	 */
	public int getServerIp_1() {
		return serverIp_1;
	}
	/**
	 * @param serverIp_1 the serverIp_1 to set
	 */
	public void setServerIp_1(int serverIp_1) {
		this.serverIp_1 = serverIp_1;
	}
	
}
