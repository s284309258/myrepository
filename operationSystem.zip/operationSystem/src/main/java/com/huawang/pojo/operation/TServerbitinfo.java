package com.huawang.pojo.operation;

public class TServerbitinfo {

	private Integer serverId;
	private String serverType;
	private Integer userCount;
	private Integer upBit;
	private Integer downBit;
	private Integer actTime;
	
	/**
	 * @return the serverId
	 */
	public Integer getServerId() {
		return serverId;
	}
	/**
	 * @param serverId the serverId to set
	 */
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}
	/**
	 * @return the serverType
	 */
	public String getServerType() {
		return serverType;
	}
	/**
	 * @param serverType the serverType to set
	 */
	public void setServerType(String serverType) {
		this.serverType = serverType;
	}
	/**
	 * @return the userCount
	 */
	public Integer getUserCount() {
		return userCount;
	}
	/**
	 * @param userCount the userCount to set
	 */
	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}
	/**
	 * @return the upBit
	 */
	public Integer getUpBit() {
		return upBit;
	}
	/**
	 * @param upBit the upBit to set
	 */
	public void setUpBit(Integer upBit) {
		this.upBit = upBit;
	}
	/**
	 * @return the downBit
	 */
	public Integer getDownBit() {
		return downBit;
	}
	/**
	 * @param downBit the downBit to set
	 */
	public void setDownBit(Integer downBit) {
		this.downBit = downBit;
	}
	/**
	 * @return the actTime
	 */
	public Integer getActTime() {
		return actTime;
	}
	/**
	 * @param actTime the actTime to set
	 */
	public void setActTime(Integer actTime) {
		this.actTime = actTime;
	}
	
	
}
