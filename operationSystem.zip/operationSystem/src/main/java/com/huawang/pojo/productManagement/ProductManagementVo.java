package com.huawang.pojo.productManagement;

import org.springframework.format.annotation.DateTimeFormat;

public class ProductManagementVo {

	/**
	 * 产品ID
	 */
	private Integer productId;
	
	/**
	 * 产品名称
	 */
	private String productName;
	
	/**
	 * 产品品类（0并发点套餐、1硬件MCU、2终端设备、3加密锁、4外设）
	 */
	private String productCategory;
	
	/**
	 * 产品简介
	 */
	private String productIntroduction;
	
	/**
	 * 创建人
	 */
	private String createBy;
	
	/**
	 * 创建时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDate;
	
	/**
	 * 更新人
	 */
	private String updateBy;
	
	/**
	 * 更新时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String updateDate;
	
	/**
	 * 授权信息VO
	 */
	private SysauthInfoVo sysauthInfoVo;
	
	/**
	 * 产品编码规则VO
	 */
	private SysProductCodingruleVo sysProductCodingruleVo;
	
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	/**
	 * @return the productIntroduction
	 */
	public String getProductIntroduction() {
		return productIntroduction;
	}
	/**
	 * @param productIntroduction the productIntroduction to set
	 */
	public void setProductIntroduction(String productIntroduction) {
		this.productIntroduction = productIntroduction;
	}
	/**
	 * @return the createBy
	 */
	public String getCreateBy() {
		return createBy;
	}
	/**
	 * @param createBy the createBy to set
	 */
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the updateBy
	 */
	public String getUpdateBy() {
		return updateBy;
	}
	/**
	 * @param updateBy the updateBy to set
	 */
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return the sysauthInfoVo
	 */
	public SysauthInfoVo getSysauthInfoVo() {
		return sysauthInfoVo;
	}
	/**
	 * @param sysauthInfoVo the sysauthInfoVo to set
	 */
	public void setSysauthInfoVo(SysauthInfoVo sysauthInfoVo) {
		this.sysauthInfoVo = sysauthInfoVo;
	}
	/**
	 * @return the sysProductCodingruleVo
	 */
	public SysProductCodingruleVo getSysProductCodingruleVo() {
		return sysProductCodingruleVo;
	}
	/**
	 * @param sysProductCodingruleVo the sysProductCodingruleVo to set
	 */
	public void setSysProductCodingruleVo(SysProductCodingruleVo sysProductCodingruleVo) {
		this.sysProductCodingruleVo = sysProductCodingruleVo;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	
}
