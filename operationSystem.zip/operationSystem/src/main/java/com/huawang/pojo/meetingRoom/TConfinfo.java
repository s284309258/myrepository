package com.huawang.pojo.meetingRoom;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class TConfinfo {

	public String codeNo;
	public Integer confId;
	public Integer confIdstr;
	public String confName;
	public String confPwd;
	public String telConfName;
	public Integer curUserCount;
	public Integer confStatus;
	public String mCUIP;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String startTime;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	public String endTime;
	public String confDesc;
	public Integer adminId;
	public String broadCastIP;
	public Integer broadCastPort;
	public String isPublic;
	public Integer parentConfId;
	public String isOnOff;
	public Integer compId;
	public String chairPwd;
	public Integer productType;
	public String auditStatus;
	public String isPassword;
	public Integer serverId;
	public String isReservedConf;
	public String isAll;
	public String parentConfPassword;
	public String plan;
	public String beginTime;
	public String overTime;
	public String confMode;
	public String defaultUI;
	public String mainDisplayUI;
	public String autoRecvSelfVideo;
	public String clientRecord;
	public String chatP2P;
	public String chatP2All;
	public Integer curServerId;
	
	public String CompName;
	public String compTrueName;
	public String adminName;
	public String serverIp;
	public Integer maxUserCount;
	public String adminTrueName;
	public Integer logConfID;
	public String serverName;
	private String confUserCount;
	public Integer CompID;
	
	
	public Integer getCompID() {
		return CompID;
	}
	public void setCompID(Integer compID) {
		CompID = compID;
	}
	public String getCompName() {
		return CompName;
	}
	public void setCompName(String compName) {
		CompName = compName;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public Integer getLogConfID() {
		return logConfID;
	}
	public void setLogConfID(Integer logConfID) {
		this.logConfID = logConfID;
	}
	public TCompinfo compinfo;
	public TAdmininfo admininfo;
	
	public List<String> strings;
	
	public String getConfUserCount() {
		return confUserCount;
	}
	public void setConfUserCount(String confUserCount) {
		this.confUserCount = confUserCount;
	}
	/**
	 * @return the codeNo
	 */
	public String getCodeNo() {
		return codeNo;
	}
	/**
	 * @param codeNo the codeNo to set
	 */
	public void setCodeNo(String codeNo) {
		this.codeNo = codeNo;
	}
	/**
	 * @return the confId
	 */
	public Integer getConfId() {
		return confId;
	}
	/**
	 * @param confId the confId to set
	 */
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	/**
	 * @return the confName
	 */
	public String getConfName() {
		return confName;
	}
	/**
	 * @param confName the confName to set
	 */
	public void setConfName(String confName) {
		this.confName = confName;
	}
	/**
	 * @return the confPwd
	 */
	public String getConfPwd() {
		return confPwd;
	}
	/**
	 * @param confPwd the confPwd to set
	 */
	public void setConfPwd(String confPwd) {
		this.confPwd = confPwd;
	}
	/**
	 * @return the telConfName
	 */
	public String getTelConfName() {
		return telConfName;
	}
	/**
	 * @param telConfName the telConfName to set
	 */
	public void setTelConfName(String telConfName) {
		this.telConfName = telConfName;
	}
	/**
	 * @return the maxUserCount
	 */
	public Integer getMaxUserCount() {
		return maxUserCount;
	}
	/**
	 * @param maxUserCount the maxUserCount to set
	 */
	public void setMaxUserCount(Integer maxUserCount) {
		this.maxUserCount = maxUserCount;
	}
	public String getAdminTrueName() {
		return adminTrueName;
	}
	public void setAdminTrueName(String adminTrueName) {
		this.adminTrueName = adminTrueName;
	}
	/**
	 * @return the curUserCount
	 */
	public Integer getCurUserCount() {
		return curUserCount;
	}
	/**
	 * @param curUserCount the curUserCount to set
	 */
	public void setCurUserCount(Integer curUserCount) {
		this.curUserCount = curUserCount;
	}
	/**
	 * @return the confStatus
	 */
	public Integer getConfStatus() {
		return confStatus;
	}
	/**
	 * @param confStatus the confStatus to set
	 */
	public void setConfStatus(Integer confStatus) {
		this.confStatus = confStatus;
	}
	/**
	 * @return the mCUIP
	 */
	public String getmCUIP() {
		return mCUIP;
	}
	/**
	 * @param mCUIP the mCUIP to set
	 */
	public void setmCUIP(String mCUIP) {
		this.mCUIP = mCUIP;
	}
	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}
	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}
	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	/**
	 * @return the confDesc
	 */
	public String getConfDesc() {
		return confDesc;
	}
	/**
	 * @param confDesc the confDesc to set
	 */
	public void setConfDesc(String confDesc) {
		this.confDesc = confDesc;
	}
	/**
	 * @return the adminId
	 */
	public Integer getAdminId() {
		return adminId;
	}
	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	/**
	 * @return the broadCastIP
	 */
	public String getBroadCastIP() {
		return broadCastIP;
	}
	/**
	 * @param broadCastIP the broadCastIP to set
	 */
	public void setBroadCastIP(String broadCastIP) {
		this.broadCastIP = broadCastIP;
	}
	/**
	 * @return the broadCastPort
	 */
	public Integer getBroadCastPort() {
		return broadCastPort;
	}
	/**
	 * @param broadCastPort the broadCastPort to set
	 */
	public void setBroadCastPort(Integer broadCastPort) {
		this.broadCastPort = broadCastPort;
	}
	/**
	 * @return the isPublic
	 */
	public String getIsPublic() {
		return isPublic;
	}
	/**
	 * @param isPublic the isPublic to set
	 */
	public void setIsPublic(String isPublic) {
		this.isPublic = isPublic;
	}
	/**
	 * @return the parentConfId
	 */
	public Integer getParentConfId() {
		return parentConfId;
	}
	/**
	 * @param parentConfId the parentConfId to set
	 */
	public void setParentConfId(Integer parentConfId) {
		this.parentConfId = parentConfId;
	}
	/**
	 * @return the isOnOff
	 */
	public String getIsOnOff() {
		return isOnOff;
	}
	/**
	 * @param isOnOff the isOnOff to set
	 */
	public void setIsOnOff(String isOnOff) {
		this.isOnOff = isOnOff;
	}
	/**
	 * @return the compId
	 */
	public Integer getCompId() {
		return compId;
	}
	/**
	 * @param compId the compId to set
	 */
	public void setCompId(Integer compId) {
		this.compId = compId;
	}
	/**
	 * @return the chairPwd
	 */
	public String getChairPwd() {
		return chairPwd;
	}
	/**
	 * @param chairPwd the chairPwd to set
	 */
	public void setChairPwd(String chairPwd) {
		this.chairPwd = chairPwd;
	}
	/**
	 * @return the productType
	 */
	public Integer getProductType() {
		return productType;
	}
	/**
	 * @param productType the productType to set
	 */
	public void setProductType(Integer productType) {
		this.productType = productType;
	}
	/**
	 * @return the auditStatus
	 */
	public String getAuditStatus() {
		return auditStatus;
	}
	/**
	 * @param auditStatus the auditStatus to set
	 */
	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}
	/**
	 * @return the isPassword
	 */
	public String getIsPassword() {
		return isPassword;
	}
	/**
	 * @param isPassword the isPassword to set
	 */
	public void setIsPassword(String isPassword) {
		this.isPassword = isPassword;
	}
	/**
	 * @return the serverId
	 */
	public Integer getServerId() {
		return serverId;
	}
	/**
	 * @param serverId the serverId to set
	 */
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}
	/**
	 * @return the isReservedConf
	 */
	public String getIsReservedConf() {
		return isReservedConf;
	}
	/**
	 * @param isReservedConf the isReservedConf to set
	 */
	public void setIsReservedConf(String isReservedConf) {
		this.isReservedConf = isReservedConf;
	}
	/**
	 * @return the isAll
	 */
	public String getIsAll() {
		return isAll;
	}
	/**
	 * @param isAll the isAll to set
	 */
	public void setIsAll(String isAll) {
		this.isAll = isAll;
	}
	/**
	 * @return the parentConfPassword
	 */
	public String getParentConfPassword() {
		return parentConfPassword;
	}
	/**
	 * @param parentConfPassword the parentConfPassword to set
	 */
	public void setParentConfPassword(String parentConfPassword) {
		this.parentConfPassword = parentConfPassword;
	}
	/**
	 * @return the plan
	 */
	public String getPlan() {
		return plan;
	}
	/**
	 * @param plan the plan to set
	 */
	public void setPlan(String plan) {
		this.plan = plan;
	}
	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}
	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	/**
	 * @return the overTime
	 */
	public String getOverTime() {
		return overTime;
	}
	/**
	 * @param overTime the overTime to set
	 */
	public void setOverTime(String overTime) {
		this.overTime = overTime;
	}
	/**
	 * @return the confMode
	 */
	public String getConfMode() {
		return confMode;
	}
	/**
	 * @param confMode the confMode to set
	 */
	public void setConfMode(String confMode) {
		this.confMode = confMode;
	}
	/**
	 * @return the defaultUI
	 */
	public String getDefaultUI() {
		return defaultUI;
	}
	/**
	 * @param defaultUI the defaultUI to set
	 */
	public void setDefaultUI(String defaultUI) {
		this.defaultUI = defaultUI;
	}
	/**
	 * @return the mainDisplayUI
	 */
	public String getMainDisplayUI() {
		return mainDisplayUI;
	}
	/**
	 * @param mainDisplayUI the mainDisplayUI to set
	 */
	public void setMainDisplayUI(String mainDisplayUI) {
		this.mainDisplayUI = mainDisplayUI;
	}
	/**
	 * @return the autoRecvSelfVideo
	 */
	public String getAutoRecvSelfVideo() {
		return autoRecvSelfVideo;
	}
	/**
	 * @param autoRecvSelfVideo the autoRecvSelfVideo to set
	 */
	public void setAutoRecvSelfVideo(String autoRecvSelfVideo) {
		this.autoRecvSelfVideo = autoRecvSelfVideo;
	}
	/**
	 * @return the clientRecord
	 */
	public String getClientRecord() {
		return clientRecord;
	}
	/**
	 * @param clientRecord the clientRecord to set
	 */
	public void setClientRecord(String clientRecord) {
		this.clientRecord = clientRecord;
	}
	/**
	 * @return the chatP2P
	 */
	public String getChatP2P() {
		return chatP2P;
	}
	/**
	 * @param chatP2P the chatP2P to set
	 */
	public void setChatP2P(String chatP2P) {
		this.chatP2P = chatP2P;
	}
	/**
	 * @return the chatP2All
	 */
	public String getChatP2All() {
		return chatP2All;
	}
	/**
	 * @param chatP2All the chatP2All to set
	 */
	public void setChatP2All(String chatP2All) {
		this.chatP2All = chatP2All;
	}
	/**
	 * @return the curServerId
	 */
	public Integer getCurServerId() {
		return curServerId;
	}
	/**
	 * @param curServerId the curServerId to set
	 */
	public void setCurServerId(Integer curServerId) {
		this.curServerId = curServerId;
	}
	/**
	 * @return the serverIp
	 */
	public String getServerIp() {
		return serverIp;
	}
	/**
	 * @param serverIp the serverIp to set
	 */
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	/**
	 * @return the compTrueName
	 */
	public String getCompTrueName() {
		return compTrueName;
	}
	/**
	 * @param compTrueName the compTrueName to set
	 */
	public void setCompTrueName(String compTrueName) {
		this.compTrueName = compTrueName;
	}
	/**
	 * @return the compinfo
	 */
	public TCompinfo getCompinfo() {
		return compinfo;
	}
	/**
	 * @param compinfo the compinfo to set
	 */
	public void setCompinfo(TCompinfo compinfo) {
		this.compinfo = compinfo;
	}
	/**
	 * @return the admininfo
	 */
	public TAdmininfo getAdmininfo() {
		return admininfo;
	}
	/**
	 * @param admininfo the admininfo to set
	 */
	public void setAdmininfo(TAdmininfo admininfo) {
		this.admininfo = admininfo;
	}
	/**
	 * @return the adminName
	 */
	public String getAdminName() {
		return adminName;
	}
	/**
	 * @param adminName the adminName to set
	 */
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	/**
	 * @return the strings
	 */
	public List<String> getStrings() {
		return strings;
	}
	/**
	 * @param strings the strings to set
	 */
	public void setStrings(List<String> strings) {
		this.strings = strings;
	}
	/**
	 * @return the confIdstr
	 */
	public Integer getConfIdstr() {
		return confIdstr;
	}
	/**
	 * @param confIdstr the confIdstr to set
	 */
	public void setConfIdstr(Integer confIdstr) {
		this.confIdstr = confIdstr;
	}
	
	
}
