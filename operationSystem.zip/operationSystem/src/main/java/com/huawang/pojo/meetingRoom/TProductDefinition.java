package com.huawang.pojo.meetingRoom;

public class TProductDefinition {

	public String codeNo;
	public String productId;
	public String pid;
	public String productStruts;
	/**
	 * 产品名称
	 */
	public String productName;
	/**
	 * 标准布局
	 */
	public String wDefaultUI;
	/**
	 * 主显内容
	 */
	public String wMainDisplayUI;
	/**
	 * 支持显示屏数
	 */
	public String wScreenCount;
	/**
	 * 最大视频码流
	 */
	public String wMaxBitRate;
	/**
	 * 最大广播视频数
	 */
	public String bMaxBroadcastVideos;
	/**
	 * 非主席最大接收视频路数(不包括本地视频)
	 */
	public String bMaxDownVideos;
	/**
	 * 最大视频上行路数
	 */
	public String bMaxUpVideos;
	/**
	 * 主席最大可接视频路数(不包括本地视频)
	 */
	public String bMaxDownVideosOfChiar;
	/**
	 * 最大分辨率
	 */
	public String wMaxResolusionW;
	/**
	 * 最大分辨率
	 */
	public String wMaxResolusionH;
	/**
	 * 最大帧率
	 */
	public String bMaxFrameRate;
	/**
	 * 最大音频同时发言路数
	 */
	public String wMaxDownAudios;
	/**
	 * 共享文档
	 */
	public String  bDocShare;
	/**
	 * 文档同开最大数量
	 */
	public String bMaxOpenDocs;
	/**
	 * 支持白板页数
	 */
	public String bMaxWBPages;
	/**
	 * 屏幕共享
	 */
	public String  bScreenShare;
	/**
	 * 桌面共享
	 */
	public String bDesktopShare;
	/**
	 * 应用程序共享
	 */
	public String bAppShare;
	/**
	 * 远程协助
	 */
	public String bRemoteControl;
	public String bScreenLabel;
	/**
	 * 媒体共享
	 */
	public String bMediaShare;
	public String bWebShare;
	/**
	 * 文字私聊
	 */
	public String bChatP2P;
	/**
	 * 文字公聊
	 */
	public String bChatP2All;
	/**
	 * 支持客户端录制
	 */
	public String bClientRecord;
	public String bServerRecord;
	public String bPSTN;
	public String bH323GW;
	public String bTVWall;
	/**
	 * 支持硬件终端 
	 */
	public String bTerminal;
	/**
	 * 支持ios
	 */
	public String biOS;
	/**
	 * 支持Android
	 */
	public String bAndroid;
	public String bMultiServer;
	public String bVote;
	public String bFileTrans;
	public String bFileCabinet;
	/**
	 * 掌声
	 */
	public String bApplause;
	public String bRinging;
	/**
	 * 语音私聊
	 */
	public String bAudioP2P;
	public String bFreeSpeak;
	/**
	 * 入会自动申请发言
	 */
	public String bAutoSpeek;
	/**
	 * 入会自动观看自己的视频
	 */
	public String bAutoRecvSelfVideo;
	/**
	 * 入会自动广播自己的视频
	 */
	public String bAutoBroadcastSelfVideo;
	public String productDescription;
	/**
	 * 入会主席模式
	 */
	public String ConfMode;
	
	/**
	 * 创建时间
	 */
	public String createdate;
	
	/**
	 * 产品类别
	 */
	public String productCategory;
	
	/**
	 * 分钟计价
	 */
	public String perMinutesPrice;
	
	/**
	 * 天计价
	 */
	public String perDayPrice;
	
	/**
	 * 年计价
	 */
	public String perYearPrice;
	
	/**
	 * 每台计价
	 */
	public String perOnePrice;
	
	/**
	 * 产品线路,国内\国际
	 */
	public String productChannel;
	
	
	
	
	
	public String getProductChannel() {
		return productChannel;
	}
	public void setProductChannel(String productChannel) {
		this.productChannel = productChannel;
	}
	public String getPerYearPrice() {
		return perYearPrice;
	}
	public void setPerYearPrice(String perYearPrice) {
		this.perYearPrice = perYearPrice;
	}
	public String getPerMinutesPrice() {
		return perMinutesPrice;
	}
	public void setPerMinutesPrice(String perMinutesPrice) {
		this.perMinutesPrice = perMinutesPrice;
	}
	public String getPerDayPrice() {
		return perDayPrice;
	}
	public void setPerDayPrice(String perDayPrice) {
		this.perDayPrice = perDayPrice;
	}
	public String getPerOnePrice() {
		return perOnePrice;
	}
	public void setPerOnePrice(String perOnePrice) {
		this.perOnePrice = perOnePrice;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	/**
	 * @return the codeNo
	 */
	public String getCodeNo() {
		return codeNo;
	}
	/**
	 * @param codeNo the codeNo to set
	 */
	public void setCodeNo(String codeNo) {
		this.codeNo = codeNo;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the productStruts
	 */
	public String getProductStruts() {
		return productStruts;
	}
	/**
	 * @param productStruts the productStruts to set
	 */
	public void setProductStruts(String productStruts) {
		this.productStruts = productStruts;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the wDefaultUI
	 */
	public String getwDefaultUI() {
		return wDefaultUI;
	}
	/**
	 * @param wDefaultUI the wDefaultUI to set
	 */
	public void setwDefaultUI(String wDefaultUI) {
		this.wDefaultUI = wDefaultUI;
	}
	/**
	 * @return the wMainDisplayUI
	 */
	public String getwMainDisplayUI() {
		return wMainDisplayUI;
	}
	/**
	 * @param wMainDisplayUI the wMainDisplayUI to set
	 */
	public void setwMainDisplayUI(String wMainDisplayUI) {
		this.wMainDisplayUI = wMainDisplayUI;
	}
	/**
	 * @return the wScreenCount
	 */
	public String getwScreenCount() {
		return wScreenCount;
	}
	/**
	 * @param wScreenCount the wScreenCount to set
	 */
	public void setwScreenCount(String wScreenCount) {
		this.wScreenCount = wScreenCount;
	}
	/**
	 * @return the wMaxBitRate
	 */
	public String getwMaxBitRate() {
		return wMaxBitRate;
	}
	/**
	 * @param wMaxBitRate the wMaxBitRate to set
	 */
	public void setwMaxBitRate(String wMaxBitRate) {
		this.wMaxBitRate = wMaxBitRate;
	}
	/**
	 * @return the bMaxBroadcastVideos
	 */
	public String getbMaxBroadcastVideos() {
		return bMaxBroadcastVideos;
	}
	/**
	 * @param bMaxBroadcastVideos the bMaxBroadcastVideos to set
	 */
	public void setbMaxBroadcastVideos(String bMaxBroadcastVideos) {
		this.bMaxBroadcastVideos = bMaxBroadcastVideos;
	}
	/**
	 * @return the bMaxDownVideos
	 */
	public String getbMaxDownVideos() {
		return bMaxDownVideos;
	}
	/**
	 * @param bMaxDownVideos the bMaxDownVideos to set
	 */
	public void setbMaxDownVideos(String bMaxDownVideos) {
		this.bMaxDownVideos = bMaxDownVideos;
	}
	/**
	 * @return the bMaxUpVideos
	 */
	public String getbMaxUpVideos() {
		return bMaxUpVideos;
	}
	/**
	 * @param bMaxUpVideos the bMaxUpVideos to set
	 */
	public void setbMaxUpVideos(String bMaxUpVideos) {
		this.bMaxUpVideos = bMaxUpVideos;
	}
	/**
	 * @return the bMaxDownVideosOfChiar
	 */
	public String getbMaxDownVideosOfChiar() {
		return bMaxDownVideosOfChiar;
	}
	/**
	 * @param bMaxDownVideosOfChiar the bMaxDownVideosOfChiar to set
	 */
	public void setbMaxDownVideosOfChiar(String bMaxDownVideosOfChiar) {
		this.bMaxDownVideosOfChiar = bMaxDownVideosOfChiar;
	}
	/**
	 * @return the wMaxResolusionW
	 */
	public String getwMaxResolusionW() {
		return wMaxResolusionW;
	}
	/**
	 * @param wMaxResolusionW the wMaxResolusionW to set
	 */
	public void setwMaxResolusionW(String wMaxResolusionW) {
		this.wMaxResolusionW = wMaxResolusionW;
	}
	/**
	 * @return the wMaxResolusionH
	 */
	public String getwMaxResolusionH() {
		return wMaxResolusionH;
	}
	/**
	 * @param wMaxResolusionH the wMaxResolusionH to set
	 */
	public void setwMaxResolusionH(String wMaxResolusionH) {
		this.wMaxResolusionH = wMaxResolusionH;
	}
	/**
	 * @return the bMaxFrameRate
	 */
	public String getbMaxFrameRate() {
		return bMaxFrameRate;
	}
	/**
	 * @param bMaxFrameRate the bMaxFrameRate to set
	 */
	public void setbMaxFrameRate(String bMaxFrameRate) {
		this.bMaxFrameRate = bMaxFrameRate;
	}
	/**
	 * @return the wMaxDownAudios
	 */
	public String getwMaxDownAudios() {
		return wMaxDownAudios;
	}
	/**
	 * @param wMaxDownAudios the wMaxDownAudios to set
	 */
	public void setwMaxDownAudios(String wMaxDownAudios) {
		this.wMaxDownAudios = wMaxDownAudios;
	}
	/**
	 * @return the bDocShare
	 */
	public String getbDocShare() {
		return bDocShare;
	}
	/**
	 * @param bDocShare the bDocShare to set
	 */
	public void setbDocShare(String bDocShare) {
		this.bDocShare = bDocShare;
	}
	/**
	 * @return the bMaxOpenDocs
	 */
	public String getbMaxOpenDocs() {
		return bMaxOpenDocs;
	}
	/**
	 * @param bMaxOpenDocs the bMaxOpenDocs to set
	 */
	public void setbMaxOpenDocs(String bMaxOpenDocs) {
		this.bMaxOpenDocs = bMaxOpenDocs;
	}
	/**
	 * @return the bMaxWBPages
	 */
	public String getbMaxWBPages() {
		return bMaxWBPages;
	}
	/**
	 * @param bMaxWBPages the bMaxWBPages to set
	 */
	public void setbMaxWBPages(String bMaxWBPages) {
		this.bMaxWBPages = bMaxWBPages;
	}
	/**
	 * @return the bScreenShare
	 */
	public String getbScreenShare() {
		return bScreenShare;
	}
	/**
	 * @param bScreenShare the bScreenShare to set
	 */
	public void setbScreenShare(String bScreenShare) {
		this.bScreenShare = bScreenShare;
	}
	/**
	 * @return the bDesktopShare
	 */
	public String getbDesktopShare() {
		return bDesktopShare;
	}
	/**
	 * @param bDesktopShare the bDesktopShare to set
	 */
	public void setbDesktopShare(String bDesktopShare) {
		this.bDesktopShare = bDesktopShare;
	}
	/**
	 * @return the bAppShare
	 */
	public String getbAppShare() {
		return bAppShare;
	}
	/**
	 * @param bAppShare the bAppShare to set
	 */
	public void setbAppShare(String bAppShare) {
		this.bAppShare = bAppShare;
	}
	/**
	 * @return the bRemoteControl
	 */
	public String getbRemoteControl() {
		return bRemoteControl;
	}
	/**
	 * @param bRemoteControl the bRemoteControl to set
	 */
	public void setbRemoteControl(String bRemoteControl) {
		this.bRemoteControl = bRemoteControl;
	}
	/**
	 * @return the bScreenLabel
	 */
	public String getbScreenLabel() {
		return bScreenLabel;
	}
	/**
	 * @param bScreenLabel the bScreenLabel to set
	 */
	public void setbScreenLabel(String bScreenLabel) {
		this.bScreenLabel = bScreenLabel;
	}
	/**
	 * @return the bMediaShare
	 */
	public String getbMediaShare() {
		return bMediaShare;
	}
	/**
	 * @param bMediaShare the bMediaShare to set
	 */
	public void setbMediaShare(String bMediaShare) {
		this.bMediaShare = bMediaShare;
	}
	/**
	 * @return the bWebShare
	 */
	public String getbWebShare() {
		return bWebShare;
	}
	/**
	 * @param bWebShare the bWebShare to set
	 */
	public void setbWebShare(String bWebShare) {
		this.bWebShare = bWebShare;
	}
	/**
	 * @return the bChatP2P
	 */
	public String getbChatP2P() {
		return bChatP2P;
	}
	/**
	 * @param bChatP2P the bChatP2P to set
	 */
	public void setbChatP2P(String bChatP2P) {
		this.bChatP2P = bChatP2P;
	}
	/**
	 * @return the bChatP2All
	 */
	public String getbChatP2All() {
		return bChatP2All;
	}
	/**
	 * @param bChatP2All the bChatP2All to set
	 */
	public void setbChatP2All(String bChatP2All) {
		this.bChatP2All = bChatP2All;
	}
	/**
	 * @return the bClientRecord
	 */
	public String getbClientRecord() {
		return bClientRecord;
	}
	/**
	 * @param bClientRecord the bClientRecord to set
	 */
	public void setbClientRecord(String bClientRecord) {
		this.bClientRecord = bClientRecord;
	}
	/**
	 * @return the bServerRecord
	 */
	public String getbServerRecord() {
		return bServerRecord;
	}
	/**
	 * @param bServerRecord the bServerRecord to set
	 */
	public void setbServerRecord(String bServerRecord) {
		this.bServerRecord = bServerRecord;
	}
	/**
	 * @return the bPSTN
	 */
	public String getbPSTN() {
		return bPSTN;
	}
	/**
	 * @param bPSTN the bPSTN to set
	 */
	public void setbPSTN(String bPSTN) {
		this.bPSTN = bPSTN;
	}
	/**
	 * @return the bH323GW
	 */
	public String getbH323GW() {
		return bH323GW;
	}
	/**
	 * @param bH323GW the bH323GW to set
	 */
	public void setbH323GW(String bH323GW) {
		this.bH323GW = bH323GW;
	}
	/**
	 * @return the bTVWall
	 */
	public String getbTVWall() {
		return bTVWall;
	}
	/**
	 * @param bTVWall the bTVWall to set
	 */
	public void setbTVWall(String bTVWall) {
		this.bTVWall = bTVWall;
	}
	/**
	 * @return the bTerminal
	 */
	public String getbTerminal() {
		return bTerminal;
	}
	/**
	 * @param bTerminal the bTerminal to set
	 */
	public void setbTerminal(String bTerminal) {
		this.bTerminal = bTerminal;
	}
	/**
	 * @return the biOS
	 */
	public String getBiOS() {
		return biOS;
	}
	/**
	 * @param biOS the biOS to set
	 */
	public void setBiOS(String biOS) {
		this.biOS = biOS;
	}
	/**
	 * @return the bAndroid
	 */
	public String getbAndroid() {
		return bAndroid;
	}
	/**
	 * @param bAndroid the bAndroid to set
	 */
	public void setbAndroid(String bAndroid) {
		this.bAndroid = bAndroid;
	}
	/**
	 * @return the bMultiServer
	 */
	public String getbMultiServer() {
		return bMultiServer;
	}
	/**
	 * @param bMultiServer the bMultiServer to set
	 */
	public void setbMultiServer(String bMultiServer) {
		this.bMultiServer = bMultiServer;
	}
	/**
	 * @return the bVote
	 */
	public String getbVote() {
		return bVote;
	}
	/**
	 * @param bVote the bVote to set
	 */
	public void setbVote(String bVote) {
		this.bVote = bVote;
	}
	/**
	 * @return the bFileTrans
	 */
	public String getbFileTrans() {
		return bFileTrans;
	}
	/**
	 * @param bFileTrans the bFileTrans to set
	 */
	public void setbFileTrans(String bFileTrans) {
		this.bFileTrans = bFileTrans;
	}
	/**
	 * @return the bFileCabinet
	 */
	public String getbFileCabinet() {
		return bFileCabinet;
	}
	/**
	 * @param bFileCabinet the bFileCabinet to set
	 */
	public void setbFileCabinet(String bFileCabinet) {
		this.bFileCabinet = bFileCabinet;
	}
	/**
	 * @return the bApplause
	 */
	public String getbApplause() {
		return bApplause;
	}
	/**
	 * @param bApplause the bApplause to set
	 */
	public void setbApplause(String bApplause) {
		this.bApplause = bApplause;
	}
	/**
	 * @return the bRinging
	 */
	public String getbRinging() {
		return bRinging;
	}
	/**
	 * @param bRinging the bRinging to set
	 */
	public void setbRinging(String bRinging) {
		this.bRinging = bRinging;
	}
	/**
	 * @return the bAudioP2P
	 */
	public String getbAudioP2P() {
		return bAudioP2P;
	}
	/**
	 * @param bAudioP2P the bAudioP2P to set
	 */
	public void setbAudioP2P(String bAudioP2P) {
		this.bAudioP2P = bAudioP2P;
	}
	/**
	 * @return the bFreeSpeak
	 */
	public String getbFreeSpeak() {
		return bFreeSpeak;
	}
	/**
	 * @param bFreeSpeak the bFreeSpeak to set
	 */
	public void setbFreeSpeak(String bFreeSpeak) {
		this.bFreeSpeak = bFreeSpeak;
	}
	/**
	 * @return the bAutoSpeek
	 */
	public String getbAutoSpeek() {
		return bAutoSpeek;
	}
	/**
	 * @param bAutoSpeek the bAutoSpeek to set
	 */
	public void setbAutoSpeek(String bAutoSpeek) {
		this.bAutoSpeek = bAutoSpeek;
	}
	/**
	 * @return the bAutoRecvSelfVideo
	 */
	public String getbAutoRecvSelfVideo() {
		return bAutoRecvSelfVideo;
	}
	/**
	 * @param bAutoRecvSelfVideo the bAutoRecvSelfVideo to set
	 */
	public void setbAutoRecvSelfVideo(String bAutoRecvSelfVideo) {
		this.bAutoRecvSelfVideo = bAutoRecvSelfVideo;
	}
	/**
	 * @return the bAutoBroadcastSelfVideo
	 */
	public String getbAutoBroadcastSelfVideo() {
		return bAutoBroadcastSelfVideo;
	}
	/**
	 * @param bAutoBroadcastSelfVideo the bAutoBroadcastSelfVideo to set
	 */
	public void setbAutoBroadcastSelfVideo(String bAutoBroadcastSelfVideo) {
		this.bAutoBroadcastSelfVideo = bAutoBroadcastSelfVideo;
	}
	/**
	 * @return the productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}
	/**
	 * @param productDescription the productDescription to set
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	/**
	 * @return the confMode
	 */
	public String getConfMode() {
		return ConfMode;
	}
	/**
	 * @param confMode the confMode to set
	 */
	public void setConfMode(String confMode) {
		ConfMode = confMode;
	}
	
}
