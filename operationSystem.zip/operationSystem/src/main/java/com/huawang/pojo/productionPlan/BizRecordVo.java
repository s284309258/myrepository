package com.huawang.pojo.productionPlan;

import org.springframework.format.annotation.DateTimeFormat;

public class BizRecordVo {

	/**
	 * 业务记录ID
	 */
	private Integer bizRecordId;
	
	/**
	 * 业务类别（0软件合同 1临时授权 2软件授权 3产品提货 4生产计划 5设备退回 6生产工单 7入库 8出库）
	 */
	private String bizCategory;
	
	/**
	 * 关联ID
	 */
	private String correlationId;
	
	/**
	 * 业务名称
	 */
	private String bizName;
	
	/**
	 * 操作
	 */
	private String operation;
	
	/**
	 * 操作人
	 */
	private String operator;
	
	/**
	 * 操作时间
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String createDate;
	
	/**
	 * 备注信息
	 */
	private String remarks;
	

	public Integer getBizRecordId() {
		return bizRecordId;
	}
	public void setBizRecordId(Integer bizRecordId) {
		this.bizRecordId = bizRecordId;
	}
	public String getBizCategory() {
		return bizCategory;
	}
	public void setBizCategory(String bizCategory) {
		this.bizCategory = bizCategory;
	}
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	public String getBizName() {
		return bizName;
	}
	public void setBizName(String bizName) {
		this.bizName = bizName;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
