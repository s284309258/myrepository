package com.huawang.pojo.meetingRoom;

public class TLogConfDetail {

	public Integer detailId;
	public Integer  logConfId;
	public String  userName;
	public String startTime;
	public String  endTime;
	public Integer  times;
	public Integer confId;
	public String  confName;
	public String  loginIp;
	
	
	/**
	 * @return the detailId
	 */
	public Integer getDetailId() {
		return detailId;
	}
	/**
	 * @param detailId the detailId to set
	 */
	public void setDetailId(Integer detailId) {
		this.detailId = detailId;
	}
	/**
	 * @return the logConfId
	 */
	public Integer getLogConfId() {
		return logConfId;
	}
	/**
	 * @param logConfId the logConfId to set
	 */
	public void setLogConfId(Integer logConfId) {
		this.logConfId = logConfId;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}
	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}
	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	/**
	 * @return the times
	 */
	public Integer getTimes() {
		return times;
	}
	/**
	 * @param times the times to set
	 */
	public void setTimes(Integer times) {
		this.times = times;
	}
	/**
	 * @return the confId
	 */
	public Integer getConfId() {
		return confId;
	}
	/**
	 * @param confId the confId to set
	 */
	public void setConfId(Integer confId) {
		this.confId = confId;
	}
	/**
	 * @return the confName
	 */
	public String getConfName() {
		return confName;
	}
	/**
	 * @param confName the confName to set
	 */
	public void setConfName(String confName) {
		this.confName = confName;
	}
	/**
	 * @return the loginIp
	 */
	public String getLoginIp() {
		return loginIp;
	}
	/**
	 * @param loginIp the loginIp to set
	 */
	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}
	
	
}
