package com.huawang.pojo.productionPlan;

public class ProdProductionListVo {

	public ProdProductionListVo() {
		// TODO Auto-generated constructor stub
	}

	private Integer listId;
	private Integer planId;
	private String pStatus;
	private String remarks;
	
	private ProductionPlanVo productionPlanVo;
	
	/**
	 * @return the listId
	 */
	public Integer getListId() {
		return listId;
	}
	/**
	 * @param listId the listId to set
	 */
	public void setListId(Integer listId) {
		this.listId = listId;
	}
	/**
	 * @return the planId
	 */
	public Integer getPlanId() {
		return planId;
	}
	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	/**
	 * @return the pStatus
	 */
	public String getpStatus() {
		return pStatus;
	}
	/**
	 * @param pStatus the pStatus to set
	 */
	public void setpStatus(String pStatus) {
		this.pStatus = pStatus;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return the productionPlanVo
	 */
	public ProductionPlanVo getProductionPlanVo() {
		return productionPlanVo;
	}
	/**
	 * @param productionPlanVo the productionPlanVo to set
	 */
	public void setProductionPlanVo(ProductionPlanVo productionPlanVo) {
		this.productionPlanVo = productionPlanVo;
	}
		
}
