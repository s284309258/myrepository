package com.huawang.pojo.productionPlan;

import java.util.List;

public class BizProcessVo {

	private Integer processId;
	private Integer businessId;
	private String processReviewerNameOne;
	private String processReviewerNameTwo;
	private String processReviewerNameThree;
	private String processReviewerNamefour;
	private String processReviewerNameFive;
	private String struts;
	private String remakes;
	private List<String> stringlists;
	
	
	/**
	 * @return the processId
	 */
	public Integer getProcessId() {
		return processId;
	}
	/**
	 * @return the businessId
	 */
	public Integer getBusinessId() {
		return businessId;
	}
	/**
	 * @return the processReviewerNameOne
	 */
	public String getProcessReviewerNameOne() {
		return processReviewerNameOne;
	}
	/**
	 * @return the processReviewerNameTwo
	 */
	public String getProcessReviewerNameTwo() {
		return processReviewerNameTwo;
	}
	/**
	 * @return the processReviewerNameThree
	 */
	public String getProcessReviewerNameThree() {
		return processReviewerNameThree;
	}
	/**
	 * @return the processReviewerNamefour
	 */
	public String getProcessReviewerNamefour() {
		return processReviewerNamefour;
	}
	/**
	 * @return the processReviewerNameFive
	 */
	public String getProcessReviewerNameFive() {
		return processReviewerNameFive;
	}
	/**
	 * @return the stringlists
	 */
	public List<String> getStringlists() {
		return stringlists;
	}
	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(Integer processId) {
		this.processId = processId;
	}
	/**
	 * @param businessId the businessId to set
	 */
	public void setBusinessId(Integer businessId) {
		this.businessId = businessId;
	}
	/**
	 * @param processReviewerNameOne the processReviewerNameOne to set
	 */
	public void setProcessReviewerNameOne(String processReviewerNameOne) {
		this.processReviewerNameOne = processReviewerNameOne;
	}
	/**
	 * @param processReviewerNameTwo the processReviewerNameTwo to set
	 */
	public void setProcessReviewerNameTwo(String processReviewerNameTwo) {
		this.processReviewerNameTwo = processReviewerNameTwo;
	}
	/**
	 * @param processReviewerNameThree the processReviewerNameThree to set
	 */
	public void setProcessReviewerNameThree(String processReviewerNameThree) {
		this.processReviewerNameThree = processReviewerNameThree;
	}
	/**
	 * @param processReviewerNamefour the processReviewerNamefour to set
	 */
	public void setProcessReviewerNamefour(String processReviewerNamefour) {
		this.processReviewerNamefour = processReviewerNamefour;
	}
	/**
	 * @param processReviewerNameFive the processReviewerNameFive to set
	 */
	public void setProcessReviewerNameFive(String processReviewerNameFive) {
		this.processReviewerNameFive = processReviewerNameFive;
	}
	/**
	 * @param stringlists the stringlists to set
	 */
	public void setStringlists(List<String> stringlists) {
		this.stringlists = stringlists;
	}
	/**
	 * @return the struts
	 */
	public String getStruts() {
		return struts;
	}
	/**
	 * @param struts the struts to set
	 */
	public void setStruts(String struts) {
		this.struts = struts;
	}
	/**
	 * @return the remakes
	 */
	public String getRemakes() {
		return remakes;
	}
	/**
	 * @param remakes the remakes to set
	 */
	public void setRemakes(String remakes) {
		this.remakes = remakes;
	}
	
	
}
