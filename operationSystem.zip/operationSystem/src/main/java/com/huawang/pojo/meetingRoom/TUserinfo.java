package com.huawang.pojo.meetingRoom;

public class TUserinfo {

	private String codeno;
	private Integer userId;
	private String userName;
	private String userPassword;
	private String telUserName;
	private String telUserPassword;
	private String displayName;
	private Integer userSex;
	private String email;
	private String telephone;
	private Integer adminId;
	private Integer orderIndex;
	private Integer compId;
	private Integer dDpId;
	private String serverIp;
	private String userStatus;
	private String isSuper;
	private Integer csId;
	private Integer msId;
	private String createtime;
	private String endtime;
	private Integer comGrade;
	/**
	 * @return the codeno
	 */
	public String getCodeno() {
		return codeno;
	}
	/**
	 * @param codeno the codeno to set
	 */
	public void setCodeno(String codeno) {
		this.codeno = codeno;
	}
	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the userPassword
	 */
	public String getUserPassword() {
		return userPassword;
	}
	/**
	 * @param userPassword the userPassword to set
	 */
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	/**
	 * @return the telUserName
	 */
	public String getTelUserName() {
		return telUserName;
	}
	/**
	 * @param telUserName the telUserName to set
	 */
	public void setTelUserName(String telUserName) {
		this.telUserName = telUserName;
	}
	/**
	 * @return the telUserPassword
	 */
	public String getTelUserPassword() {
		return telUserPassword;
	}
	/**
	 * @param telUserPassword the telUserPassword to set
	 */
	public void setTelUserPassword(String telUserPassword) {
		this.telUserPassword = telUserPassword;
	}
	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}
	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	/**
	 * @return the userSex
	 */
	public Integer getUserSex() {
		return userSex;
	}
	/**
	 * @param userSex the userSex to set
	 */
	public void setUserSex(Integer userSex) {
		this.userSex = userSex;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}
	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	/**
	 * @return the adminId
	 */
	public Integer getAdminId() {
		return adminId;
	}
	/**
	 * @param adminId the adminId to set
	 */
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	/**
	 * @return the orderIndex
	 */
	public Integer getOrderIndex() {
		return orderIndex;
	}
	/**
	 * @param orderIndex the orderIndex to set
	 */
	public void setOrderIndex(Integer orderIndex) {
		this.orderIndex = orderIndex;
	}
	/**
	 * @return the compId
	 */
	public Integer getCompId() {
		return compId;
	}
	/**
	 * @param compId the compId to set
	 */
	public void setCompId(Integer compId) {
		this.compId = compId;
	}
	/**
	 * @return the dDpId
	 */
	public Integer getdDpId() {
		return dDpId;
	}
	/**
	 * @param dDpId the dDpId to set
	 */
	public void setdDpId(Integer dDpId) {
		this.dDpId = dDpId;
	}
	/**
	 * @return the serverIp
	 */
	public String getServerIp() {
		return serverIp;
	}
	/**
	 * @param serverIp the serverIp to set
	 */
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	/**
	 * @return the userStatus
	 */
	public String getUserStatus() {
		return userStatus;
	}
	/**
	 * @param userStatus the userStatus to set
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	/**
	 * @return the isSuper
	 */
	public String getIsSuper() {
		return isSuper;
	}
	/**
	 * @param isSuper the isSuper to set
	 */
	public void setIsSuper(String isSuper) {
		this.isSuper = isSuper;
	}
	/**
	 * @return the csId
	 */
	public Integer getCsId() {
		return csId;
	}
	/**
	 * @param csId the csId to set
	 */
	public void setCsId(Integer csId) {
		this.csId = csId;
	}
	/**
	 * @return the msId
	 */
	public Integer getMsId() {
		return msId;
	}
	/**
	 * @param msId the msId to set
	 */
	public void setMsId(Integer msId) {
		this.msId = msId;
	}
	/**
	 * @return the createtime
	 */
	public String getCreatetime() {
		return createtime;
	}
	/**
	 * @param createtime the createtime to set
	 */
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	/**
	 * @return the endtime
	 */
	public String getEndtime() {
		return endtime;
	}
	/**
	 * @param endtime the endtime to set
	 */
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	/**
	 * @return the comGrade
	 */
	public Integer getComGrade() {
		return comGrade;
	}
	/**
	 * @param comGrade the comGrade to set
	 */
	public void setComGrade(Integer comGrade) {
		this.comGrade = comGrade;
	}
	
	
}
