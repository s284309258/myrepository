package com.huawang.dao.organization;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.pojo.organization.TDepartment;

public interface OrganizationDao {
	
	public List<TDepartment> getByPidTree(TDepartment department);
	public List<TDepartment> getDepartmentDatas(@Param("department")TDepartment department,@Param("id")int id);
	public int getProductDataCounts(@Param("department")TDepartment department,@Param("id")int id);
	public List<String> getDpName();
	public int addOrganization(@Param("department")TDepartment department);
	public int delOrganization(@Param("department")TDepartment department);
	public int editOrganization(@Param("department")TDepartment department);
	
	public List<TAdmininfo> getDpAndUserDatas(@Param("admininfo")TAdmininfo admininfo);
	public int getDpAndUserDataCounts(@Param("admininfo")TAdmininfo admininfo);
	public int addUser(@Param("admininfo")TAdmininfo admininfo);
	public int editUser(@Param("admininfo")TAdmininfo admininfo);
	public int delUser(@Param("admininfo")TAdmininfo admininfo);
	
	public boolean login(@Param("admininfo")TAdmininfo admininfo);
	
}


