package com.huawang.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.productManagement.ProductManagementVo;
import com.huawang.pojo.productManagement.SysProductCodingruleVo;
import com.huawang.pojo.productManagement.SysauthInfoVo;
import com.huawang.pojo.system.SysField;

public interface SysProductManagementDao {
	
	public List<ProductManagementVo> queryProductmanagementList(@Param("managementVo")ProductManagementVo managementVo);
	public Integer counts();
	public String getSeq_productManagementId();
	public int addProductmanagementVo(@Param("managementVo")ProductManagementVo managementVo);
	public int addSysauthInfoVo(@Param("sysauthInfoVo")SysauthInfoVo sysauthInfoVo);
	public int addSysProductCodingruleVo(@Param("sysProductCodingruleVo")SysProductCodingruleVo sysProductCodingruleVo);
	public int deleteProductmanagementVo(String productId);
	public int deleteSysauthInfoVo(String productId);
	public int deleteSysProductCodingruleVo(String productId);
	public List<SysField> getSystemFieldParameter();
	public Integer getSystemFieldCounts();
	public ProductManagementVo detailsSearchByProductId(@Param("productId")String productId);
	public int editProductmanagement(@Param("managementVo")ProductManagementVo managementVo);
	public int editSysauthInfo(@Param("sysauthInfoVo")SysauthInfoVo sysauthInfoVo);
	public int editSysProductCodingrule(@Param("sysProductCodingruleVo")SysProductCodingruleVo sysProductCodingruleVo);
}
