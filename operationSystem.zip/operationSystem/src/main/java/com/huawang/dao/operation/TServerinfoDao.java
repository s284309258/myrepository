package com.huawang.dao.operation;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.operation.TServerGroupInfo;
import com.huawang.pojo.operation.TServerbitinfo;
import com.huawang.pojo.operation.TServerinfo;

public interface TServerinfoDao {

	public int getCSDataCounts(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark,@Param("serverId")String serverId);
	public List<TServerinfo> getCSData(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark,
			@Param("serverId")String serverId,@Param("i")int i,@Param("rows")int rows);
	public int addTServerinfo(@Param("serverinfo")TServerinfo serverinfo);
	public int editTServerinfo(@Param("serverinfo")TServerinfo serverinfo);
	//集群中添加CS服务器
	public int addTServerGroupInfo(@Param("groupInfo")TServerGroupInfo groupInfo);
	public int addTServerGroupSingle(@Param("groupInfo")TServerGroupInfo groupInfo);
	public int delTServerGroupInfoByServerId(@Param("serverId")Integer serverId,@Param("groupid")String groupid);
	//cs服务器管理中添加级联服务器
	public List<TServerinfo> selectByIdCs(@Param("serverinfo")TServerinfo serverinfo,@Param("serverMark")String serverMark,@Param("i")int i,@Param("rows")int rows);
	public int selectByIdCsCount(@Param("serverinfo")TServerinfo serverinfo,@Param("serverMark")String serverMark);
	
	//服务器集群 查询方法
	public List<TServerinfo>getClusterData(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark,@Param("i")int i,@Param("rows")int rows);
	public int getClusterDataCount(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark);
	//服务器集群中添加cs服务器
	public List<TServerinfo>selectByIdClusterCs(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark,@Param("i")int i,@Param("rows")int rows);
	public int selectByIdClusterCsCount(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark);
	
	//cs服务器管理查询方法 ||独立、级联服务查询
	public List<TServerinfo> getCSAndCluster(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId,@Param("i")int i,@Param("rows")int rows);
	public int getCSAndClusterCounts(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId);
	public String getServerNameList(@Param("serverId")String serverId);
	//服务器集群中管理查询方法
	public List<TServerinfo> getCSAndCluster02(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId,@Param("i")int i,@Param("rows")int rows);
	public int getCSAndClusterCounts02(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId);
	
	//根据id查询ms服务器人数和流量
	public List<TServerbitinfo> getStrList(@Param("serverId")int serverId);
	public int getParentIdCounts(@Param("parentId")String parentId);
	//服务端不同类别查询列表
	public List<TServerinfo> getServieData(@Param("serverinfo")TServerinfo serverinfo,@Param("mark")String mark);
	public int addServerData(@Param("serverinfo")TServerinfo serverinfo);
	//MS移交到级联服务器
	public int updateMSServerData(@Param("serverinfo")TServerinfo serverinfo);
	
	public int getMSDataCounts(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId);
	//MS子服务器查询列表
	public List<TServerinfo> getMSData(@Param("serverinfo")TServerinfo serverinfo,@Param("serverId")String serverId,@Param("i")int i,@Param("rows")int rows);
	//根据parentId查询下面的ms服务器
	public List<String> getTserverId(@Param("parentId")Integer integer);
	
	public int verificationServerName(@Param("serverinfo")TServerinfo serverinfo,@Param("serverMark")String serverMark) ;
	public int verificationServerIp(@Param("serverIp")String serverIp,@Param("serverMark")String serverMark);
	public int verificationLocalIp(@Param("localIp")String localIp,@Param("serverMark")String serverMark);
	public int verificationServerNameForCluster(@Param("clusterServerName")String clusterServerName,@Param("serverMark")String serverMark) ;
	public List<TServerinfo> getTserverGroupinfoData(@Param("serverId")String serverId, @Param("mark")String mark);
	
	
	public TServerinfo getAllDatas(@Param("serverinfo")TServerinfo serverinfo);
	
	public List<TServerinfo> getCounts(@Param("serverId")String serverId);
	
	
}


