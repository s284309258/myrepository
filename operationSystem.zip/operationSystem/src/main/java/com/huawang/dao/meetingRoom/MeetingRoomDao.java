package com.huawang.dao.meetingRoom;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.pojo.meetingRoom.TLogConfDetail;
import com.huawang.pojo.meetingRoom.TProductDefinition;
import com.huawang.pojo.operation.TServerinfo;

public interface MeetingRoomDao {

	public int getProductDataCounts(@Param("productDefinition")TProductDefinition productDefinition);
	public List<TProductDefinition> getProductDatas(@Param("productDefinition")TProductDefinition productDefinition,@Param("i")int i,@Param("rows")int rows);
	
	public int checkProductName(@Param("productDefinition")TProductDefinition productDefinition);
	public int addDatas(@Param("productDefinition")TProductDefinition productDefinition) ;
	public TProductDefinition getDataByProductId(@Param("productId")String productId);
	public int getMeetingRoomDataCounts(@Param("tConfinfo")TConfinfo tConfinfo);
	//会议查询 分页查询
	public List<TConfinfo> getMeetingRoomDatas(@Param("tConfinfo")TConfinfo tConfinfo,@Param("i")int i,@Param("rows")int rows);
	//会议查询管理员
	public List<TConfinfo> getMeetingRoomData(@Param("tConfinfo")TConfinfo tConfinfo);
	//查询服务器IP
	public List<TConfinfo>getServerIP(@Param("tConfinfo")TConfinfo tConfinfo,@Param("mark")String mark);
	public int updateServerIp(@Param("tConfinfo")TConfinfo tConfinfo);//会议查询中切换服务器
	public String getServerIp(@Param("serverId")String serverId);
	public String getCompTrueName(@Param("codeno")String codeno);
	public List<TAdmininfo> getUserName();
	public List<String> getStrConfId(@Param("confId")String confId);
	public int editProductDatas(@Param("productDefinition")TProductDefinition productDefinition);
	//会议统计
	public int getmeetingStatisticsDatasCounts(@Param("tCompinfo")TCompinfo tCompinfo);
	public List<TCompinfo> getmeetingStatisticsDatas(@Param("tCompinfo")TCompinfo tCompinfo,@Param("i")int i,@Param("rows")int rows);
	//企业会议详情
	public int getMeetingDetailDatasCounts(@Param("tConfinfo")TConfinfo tConfinfo);
	public List<TConfinfo> getMeetingDetailDatas(@Param("tConfinfo")TConfinfo tConfinfo,@Param("i")int i,@Param("rows")int rows);
	//具体会议信息
	public int getLOGDetailDatasCounts(@Param("logConfDetail")TLogConfDetail logConfDetail);
	public List<TLogConfDetail> getLOGDetailDatas(@Param("logConfDetail")TLogConfDetail logConfDetail,@Param("i")int i,@Param("rows")int rows);
	//查询客户信息
	public List<TCompinfo> getCustomerInfo(@Param("tCompinfo")TCompinfo tCompinfo,@Param("i")int i,@Param("rows")int rows);
	public int getCustomerInfoCount(@Param("tCompinfo")TCompinfo tCompinfo);
	//客户管理
	public int getCustomerDataCounts(@Param("tCompinfo")TCompinfo tCompinfo);
//=-------------
	public List<TCompinfo>getCustomerDatas(@Param("tCompinfo")TCompinfo tCompinfo,@Param("i")int i,@Param("rows")int rows);
	//查询客户管理员
	public List<TCompinfo>getAdminName(@Param("tCompinfo")TCompinfo tCompinfo);
	//分配客服管理员给客户
	public int updateCompManager(@Param("tCompinfo")TCompinfo tCompinfo);
	//新增下拉框 查询CS服务器
	public List<TServerinfo>getCsServerInfo();
	//新增客户账号
	public int addCustomerAccount(@Param("tCompinfo")TCompinfo tCompinfo);
	public TCompinfo selectGetKey(@Param("tCompinfo")TCompinfo tCompinfo);
	//新增客户关联产品类型
	public int addCustomerToProductId(@Param("tCompinfo")TCompinfo tCompinfo);
	public int addUserInfo(@Param("tCompinfo")TCompinfo tCompinfo,@Param("compId")int compId);//新增userinfo用户
	public int selectByName(@Param("tCompinfo")TCompinfo tCompinfo);//修改判断是否重名
	public int selectByName1(@Param("tCompinfo")TCompinfo tCompinfo);//新增判断是否重复
	//查看修改客户资料
	public TCompinfo selectEditCustomer(@Param("tCompinfo")TCompinfo tCompinfo);
	public int saveCustomerInfo(@Param("tCompinfo")TCompinfo tCompinfo);//保存修改客户信息
	
	
}













