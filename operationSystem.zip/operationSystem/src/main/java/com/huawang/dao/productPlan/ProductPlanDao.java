package com.huawang.dao.productPlan;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.productManagement.ProductManagementVo;
import com.huawang.pojo.productionPlan.BizProcessVo;
import com.huawang.pojo.productionPlan.BizRecordVo;
import com.huawang.pojo.productionPlan.ProdProductionListVo;
import com.huawang.pojo.productionPlan.ProductionPlanVo;

public interface ProductPlanDao {
	
	public Integer counts();
	public List<ProductionPlanVo> productionPlanList(@Param("planVo")ProductionPlanVo productionPlanVo);
	public int insertProductionPlanData(@Param("planVo")ProductionPlanVo planVo);
	public int insertBizRecordData(@Param("recordVo")BizRecordVo recordVo);
	public ProductionPlanVo queryProductionPlanDataByPlanId(String planId);
	public String getSeq_planId();
	public List<ProductManagementVo> getProductNameLList();
	public List<BizProcessVo> getBizProcessLists(String planId); 
	public int insertBizProcessVo(BizProcessVo bizProcessVo);  
	public int updateBizProcessStruts(BizProcessVo bizProcessVo);
	public int updateProductionPlanStruts(ProductionPlanVo planVo);
	public int insertProdProductionList(ProdProductionListVo productionListVo);  
	public List<BizRecordVo> queryBizRecordListByPlanId(@Param("planId")String planId,@Param("dataId")String dataId);

}
