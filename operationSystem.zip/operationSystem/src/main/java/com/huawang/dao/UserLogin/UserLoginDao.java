package com.huawang.dao.UserLogin;

import org.apache.ibatis.annotations.Param;

import com.huawang.pojo.meetingRoom.TAdmininfo;

public interface UserLoginDao {

	public boolean userLogin(@Param("admininfo")TAdmininfo admininfo);
}
