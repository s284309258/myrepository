package com.huawang.dao.system;

import java.util.List;

import com.huawang.pojo.system.SysDepartment;

public interface SysDepartmentDao {
	
	public SysDepartment findDepartmentInfoByDpId(Integer departmentId);
	
	public SysDepartment findDepartmentByDpId(Integer departmentId);
	
	public List<SysDepartment> findDepartmentListByDpId(Integer departmentId);
	
	public List<SysDepartment> findTotalDepartmentList();
	
	public Integer findTotalDepartmentCount();
	
	public Integer findCountByDpId(Integer parentId);
	
	public List<SysDepartment> findDepartmentByParentId( Integer parentId );
	
	public void addDepartment(SysDepartment sysDepartment);
	
	public void deleteDepartment(Integer departmentId);
	
	public void updateDepartment(SysDepartment sysDepartment);
	
	public List<SysDepartment> findDepartmentIdByDpId(Integer departmentId);
	
}
