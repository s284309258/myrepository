package com.huawang.dao.ProdProductionList;

import java.util.List;

import com.huawang.pojo.productionPlan.ProdEquipmentScrapRecordVo;
import com.huawang.pojo.productionPlan.ProdProductionListVo;
import com.huawang.pojo.productionPlan.ProductionPlanVo;

public interface ProdProductionListDao {

	public int getProductionPlanListCounts();
	public List<ProdProductionListVo> getProductionPlanLists(ProductionPlanVo productionPlanVo);
	public int eliminate(ProdEquipmentScrapRecordVo scrapRecordVo);
	
	public int getProdEquipmentScrapRecordCounts();
	public List<ProdEquipmentScrapRecordVo> queryProdEquipmentScrapRecordList(String planId);
}
