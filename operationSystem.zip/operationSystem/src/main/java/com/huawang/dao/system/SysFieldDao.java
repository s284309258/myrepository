package com.huawang.dao.system;

import java.util.List;

import com.huawang.pojo.system.SysField;

public interface SysFieldDao {

	//查询数据库
	public List<SysField> findField();
	
	//更新系统字段
	public void updateSysField(SysField sysField);
	
	//增加字段
	public void insertSysField(SysField sysField);
	
	//删除字段
	public void deleteSysField(int id);
	
	//查询单条语句
	public SysField findOneField(int id);
}
