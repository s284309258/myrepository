package com.huawang.controller.operationManage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.huawang.dao.operation.TServerinfoDao;
import com.huawang.pojo.operation.TServerGroupInfo;
import com.huawang.pojo.operation.TServerbitinfo;
import com.huawang.pojo.operation.TServerinfo;
import com.huawang.util.BasicDataUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/CS")
public class CSServerController {

	static Logger logger = LogManager.getLogger(CSServerController.class.getName());
	
			@Autowired
			private TServerinfoDao serverinfoDao;
			String message="";
			
			
			@RequestMapping(value="/csServerSelect",method= {RequestMethod.POST,RequestMethod.GET})
			public String csServerSelect(HttpServletRequest request, HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception{
				 
				return "operation/CSService";
			}
			
			/**
			 * CS服务器查询
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/csServerSelectMap",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public Map<String, Object> csServerSelectMap(HttpServletRequest request, HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception{
				
				String SortName = request.getParameter("sort");
				String SortValue =request.getParameter("order");
				
				String page = request.getParameter("page");
				String rows = request.getParameter("rows");
				int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				
				HashMap<String,Object> map = new HashMap<String,Object>();
				String total ="SELECT COUNT(1)  " + 
						"		       FROM " + 
						"			     t_serverinfo t  WHERE 1 = 1 ";
				total +="  AND ((t.ServerType = '0' AND t.IsPad = '0'" + 
						"				)" + 
						"				OR (" + 
						"					t.ServerType = '1' AND t.IsPad = '0'" + 
						"				))";
				
				String sql="SELECT " + 
						"			t.ServerID AS serverId," + 
						"			t.ServerName AS serverName," + 
						"			t.ServerIP AS serverIp," + 
						"			t.ServerPort AS serverPort," + 
						"			t.ServerType AS serverType," + 
						"			t.ParentId AS parentId," + 
						"			t.ParentServerIP AS parentServerIp," + 
						"			t.IsPad AS isPad," + 
						"			t.VsersionNum AS vsersionNum," + 
						"			t.VsersionInfo AS vsersionInfo," + 
						"			t.LocalIP AS localIp " + 
						"		FROM " + 
						"			t_serverinfo t   " + 
						"		WHERE " + 
						"			1 = 1";
				sql +=" AND ((t.ServerType = '0' AND t.IsPad = '0' " + 
						"				)" + 
						"				OR (" + 
						"					t.ServerType = '1' AND t.IsPad = '0'" + 
						"				))";
				
				if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
					sql +=" and t.ServerName like '%"+serverInfo.serverName+"%'";
					total+=" and t.ServerName like '%"+serverInfo.serverName+"%'";
				}
				if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
					sql +=" and t.ServerIP = '"+serverInfo.serverIp+"'";
					total +=" and t.ServerIP = '"+serverInfo.serverIp+"'";
				}
				if(serverInfo.serverType!=null && !"".equals(serverInfo.serverType)) {
					sql +=" and t.ServerType="+serverInfo.serverType;
					total +=" and t.ServerType="+serverInfo.serverType;
				}
				if(serverInfo.serverId!=null ) {
					sql +=" and t.ServerID="+ serverInfo.serverId;
					total +=" and t.ServerID="+serverInfo.serverId;
				}
				
				if(null!=SortName && !"".equals(SortName)) 
				{
					sql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
				}
				else
				{
					sql +=" limit "+i+","+rows;
				}
				
//				sql +=" ORDER BY t.ServerID  DESC limit "+i+","+rows;
				
				ArrayList<Object> serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				String cnt = Sqlca.getString(total);
				 
				for (Object tServerinfo : serverList) {
					//级联服务器
					extracted((TServerinfo) tServerinfo);
				}
				map.put("rows", serverList);
				map.put("total", cnt);
				return map;
			}
			
			
			private void extracted(TServerinfo tServerinfo) throws UnsupportedEncodingException {
				
				if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)
						&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)) {//如果是级联服务器 0.0
			
					List<String> strs = serverinfoDao.getTserverId(tServerinfo.getServerId());//根据 parentID查询下面  ms serverId
			
					if (!strs.isEmpty()) {
						int userCount = 0;
						int upBit = 0;
			
						for (String str : strs) {								 //根据id查询ms服务器人数和流量
							List<TServerbitinfo> tServerbitinfos = serverinfoDao.getStrList(Integer.parseInt(str));
							if (!tServerbitinfos.isEmpty()) {
								userCount += tServerbitinfos.get(0).getUserCount();
								upBit += tServerbitinfos.get(0).getUpBit();
							}
						}
						tServerinfo.setUserCount(userCount);
						tServerinfo.setUpBit(upBit);
					}
			
				} else if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ONE_NUMBER)
						&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)) {//是独立服务器 1.0
																		   //根据id查询ms服务器人数和流量
					List<TServerbitinfo> tServerbitinfos_1 = serverinfoDao.getStrList(tServerinfo.getServerId()); 
					if (!tServerbitinfos_1.isEmpty()) {
						tServerinfo.setUserCount(tServerbitinfos_1.get(0).getUserCount());
						tServerinfo.setUpBit(tServerbitinfos_1.get(0).getUpBit());
					}
				} else if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)
						&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ONE_NUMBER)) {  // 集群 0、1
					int userCount = 0;
					int upBit = 0;										    //如果是集群根据id查询CS服务器
					 List<TServerinfo> list = serverinfoDao.getCounts(tServerinfo.getServerId().toString());
					if (!list.isEmpty()) {
						for (TServerinfo tServerinfo2 : list) {//根据serverId与 parentID 拿到对应的serverId 多个 
							List<String> strs = serverinfoDao.getTserverId(tServerinfo2.getServerId());
							if (!strs.isEmpty()) {
								for (String str : strs) {
																						 //根据id查询ms服务器人数和流量
									List<TServerbitinfo> tServerbitinfos = serverinfoDao.getStrList(Integer.parseInt(str));
									/*if (!tServerbitinfos.isEmpty()) {*/
										userCount += tServerbitinfos.get(0).getUserCount();
										upBit += tServerbitinfos.get(0).getUpBit();
									/*}*/
								}
							}else if (strs.isEmpty()) {									//根据id查询ms服务器人数和流量
								List<TServerbitinfo> tServerbitinfos_1 = serverinfoDao.getStrList(tServerinfo2.getServerId());
								if (!tServerbitinfos_1.isEmpty()) {
									userCount += tServerbitinfos_1.get(0).getUserCount();
									upBit += tServerbitinfos_1.get(0).getUpBit();
								}
							}
						}
			
						tServerinfo.setClusterCounts(list.size());
						tServerinfo.setUserCount(userCount);
						tServerinfo.setUpBit(upBit);
					}
				}
				if (BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getServerType())
						&& BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getIsPad())) {
					tServerinfo.setServerType(BasicDataUtil.BIZ_STRING_SERVERTYPE01);
				} else if (BasicDataUtil.BIZ_STRING_ONE_NUMBER.equals(tServerinfo.getServerType())
						&& BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getIsPad())) {
					tServerinfo.setServerType(BasicDataUtil.BIZ_STRING_SERVERTYPE02);
				}
			}		
			
			/**
			 * 进入新增页面
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 */
			@RequestMapping(value="addToCSServer",method=RequestMethod.GET)
			public String addToCsServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) {
				return "operation/addCS";
			}
			
			
			/**
			 * 	添加数据
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/addCSDataServer",method= {RequestMethod.POST})
			@ResponseBody
			public String addCSDataServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
				 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		         String date =df.format(new Date()); 
				//serverType:0、级联，1、独立
				String serverType = request.getParameter("serverType");
				String isPad= "0";
				serverInfo.setIsPad(isPad);
				serverInfo.setServerType(serverType);
				
				String sqlcount ="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName ='"+serverInfo.serverName+"'";
				sqlcount +=" AND ((" + 
						"					t.ServerType = '0' AND t.IsPad = '0'" + 
						"				)" + 
						"				OR (" + 
						"					t.ServerType = '1' AND t.IsPad = '0'" + 
						"				))";
				String verCount =Sqlca.getString(sqlcount);
				 
				if(Integer.parseInt(verCount)>0) {
					message="rename";
					return message;
				}else {
					int addSql = Sqlca.updateObject("INSERT INTO t_serverinfo (ServerName,ServerIP,ServerType,IsPad,LocalIP,createDate)values(?,?,?,?,?,?)", new String[] {
							serverInfo.serverName,serverInfo.serverIp,serverInfo.serverType,serverInfo.isPad,serverInfo.localIp,date});
					
					if(addSql>0) {
						message="success";
					}else {
						message="fail";
					}
					return message;
				}
			}
			/**
			 * 查询cs下是否存在ms服务器
			 * @param request
			 * @param response
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/checkCsToMsServer")
			@ResponseBody
			public String checkCsToMsServer(HttpServletRequest request,HttpServletResponse response) throws Exception{
				String message="";
				String serverId = request.getParameter("serverId"); 
				String serverType =request.getParameter("serverType");
				
				String sql = "select count(1) from t_serverinfo where ServerType = 0 and ServerID ="+ serverId;
				String count =Sqlca.getString(sql);
				String sq = "select count(1) from t_serverinfo where ParentId ="+serverId;
				String cou =Sqlca.getString(sq);
				
				if(Integer.parseInt(count)>0 && Integer.parseInt(cou)>0 &&serverType.equals("1")) {
					message="out";
				}else {
					message="success";
				}
				JSONObject json = new JSONObject();
				json.put("message", message); 
				return json.toString();
			} 
			
			
			
			/**
			 * 编辑CS服务器信息
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/editeCSServer",method=RequestMethod.GET)
			public String editCSServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
			
				String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerType AS serverType,t.IsPad AS isPad,t.LocalIP AS localIp FROM " + 
						" t_serverinfo t   WHERE 1 = 1 AND t.ServerID = "+serverInfo.serverId;
			 
				List<Object> list = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				model.addAttribute("serverInfo", list);
				return "operation/editCS";
			}
			/**
			 * 保存cs服务信息
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception
			 */
			@RequestMapping(value="/saveCSServer",method = {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String saveCSServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
				 
				String serverName = request.getParameter("serverName");
				String serverId = serverInfo.getServerId().toString();
				
				
				String sql = "SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverName+"'"; 
				sql +=" AND ((" + 
						"					t.ServerType = '0' AND t.IsPad = '0'" + 
						"				)" + 
						"				OR (" + 
						"					t.ServerType = '1' AND t.IsPad = '0'" + 
						"				)) and  t.ServerID <>"+serverId;
				StringBuilder buder = new StringBuilder("UPDATE t_serverinfo T SET T.updateDate =  NOW() ,T.ServerName = ? ,T.ServerIP = ?,T.LocalIP =?,T.serverType = ?");
				buder.append("  WHERE T.ServerID =" +serverId);
				String count =Sqlca.getString(sql);
				if(Integer.parseInt(count)>0) {
					message="0";
				}else {
					Sqlca.updateObject(buder.toString(), new String[] {serverName,serverInfo.serverIp,serverInfo.localIp,serverInfo.serverType});
					message = serverId;
				}
				return message;
			}
			
			
			@RequestMapping(value="/cSManagerServer",method = {RequestMethod.POST,RequestMethod.GET})
			public String cSManagerServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
			
				String serverId = request.getParameter("serverId");
				String serverType= request.getParameter("serverType");
				
				
				model.addAttribute("serverType", serverType);
				model.addAttribute("serverId", serverId);
				return "operation/csDependentManager";
			}
			
			@RequestMapping(value="/cSManagerServerMap",method = {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public Map<String, Object> cSManagerServerMap(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model,String mark) throws Exception {
			
				String serverId = request.getParameter("serverId");
				String cnt ="";
				List<TServerinfo> tServerinfos = new ArrayList<TServerinfo>();
			 
				String page = request.getParameter("page");
				String rows = request.getParameter("rows");
				int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				 
				ArrayList<Object> serverList = null;
				
				if("cs".equals(mark)) {
					String sql ="SELECT t1.ServerID,t1.ServerName,t1.ServerIP,t1.ServerType,t1.IsPad FROM t_serverinfo t1 LEFT JOIN t_servergroupinfo t2 ON t1.ServerID = t2.groupid WHERE 1=1 ";
					String sqlCount ="SELECT COUNT(1)  FROM t_serverinfo t1 LEFT JOIN t_servergroupinfo t2 ON t1.ServerID = t2.groupid WHERE 1=1 AND t2.ServerID ="+serverId;
				
					sql +=" AND t2.ServerID ="+serverId;
					if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
						sql +=" AND t1.ServerName like '%"+serverInfo.serverName+"%'";
						sqlCount += " AND t1.ServerName like '%"+serverInfo.serverName+"%'";
					}
					sql +=" ORDER BY t1.createDate DESC limit "+i+","+rows;
					serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
					cnt = Sqlca.getString(sqlCount);
				}else if("cluster".equals(mark)) {
					
					String sql ="SELECT t1.ServerID,t2.ServerName,t2.ServerIP,t2.ServerType,t2.IsPad,t2.LocalIP FROM t_servergroupinfo t1 INNER JOIN t_serverinfo t2 ON t1.serverid = t2.ServerID" + 
							"WHERE 1 = 1 AND t1.groupid = "+serverId;
					String sqlCount="SELECT COUNT(1) FROM t_servergroupinfo t1 INNER JOIN t_serverinfo t2 ON t1.serverid = t2.ServerID WHERE 1 = 1 AND t1.groupid ="+serverId;
					if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
						sql +=" AND t2.ServerName like '%"+serverInfo.serverName+"%'";
						sqlCount+=" AND t2.ServerName like '%"+serverInfo.serverName+"%'";
					}
					if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
						sql +=" AND t2.ServerIP = '"+serverInfo.serverIp+"'";
						sqlCount+= " AND t2.ServerIP = '"+serverInfo.serverIp+"'";
					}
					sql +=" ORDER BY t2.createDate DESC limit "+i+","+rows;
					serverList =Sqlca.getArrayListFromObj(sql, TServerinfo.class);
					cnt = Sqlca.getString(sqlCount);
				}
				if(serverList!=null) {
					for (Object tServerinfo : serverList) {
						extracted((TServerinfo) tServerinfo);
						tServerinfos.add((TServerinfo) tServerinfo);
					}
				}
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("rows", tServerinfos);
				map.put("total", cnt);
				return map; 
			}
			 
			
			
			@RequestMapping(value="/addClusterAndCs",method= {RequestMethod.POST,RequestMethod.GET})
			public String addClusterAndCs(HttpServletRequest request,TServerinfo serverinfo,Model model) throws UnsupportedEncodingException {
				String serverId = request.getParameter("serverId");
				model.addAttribute("serverId", serverId);
				return "operation/addClusterServer";
			}
			
			/**
			 *  添加服务器集群组列表
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/addClusterAndCsMap",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public Map<String, Object> addClusterAndCsMap(HttpServletRequest request,TServerinfo serverinfo,Model model) throws Exception {
				
				String serverId = request.getParameter("serverId");
				String page = request.getParameter("page");
				String rows = request.getParameter("rows");
				int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				HashMap<String,Object> map = new HashMap<String,Object>();
				
				String total ="SELECT COUNT(1) FROM  t_serverinfo t WHERE 1 = 1  AND (t.ServerType = '0' AND t.IsPad = '1')";
				String tao =Sqlca.getString(total);
				String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerPort AS serverPort," + 
						"			t.ServerType AS serverType,t.ParentId AS parentId,t.ParentServerIP AS parentServerIp,t.IsPad AS isPad,t.VsersionNum AS vsersionNum,t.VsersionInfo AS vsersionInfo,t.LocalIP AS localIp " + 
						"		FROM t_serverinfo t  WHERE 1 = 1  AND (t.ServerType = '0' AND t.IsPad = '1')";
						sql +=" limit "+i+","+rows;
				ArrayList<Object> serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				 
				map.put("rows", serverList);
				map.put("total", tao);
				return map;
			}
			
			/**
			 * CS添加---进服务器集群管理
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 */
			@RequestMapping(value="/cSAddToClusterServer",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String cSAddToClusterServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) {
				
				String serverId = request.getParameter("serverId");//集群服务器id
				String groupId = request.getParameter("groupId");
				TServerGroupInfo groupInfo = new TServerGroupInfo();
				groupInfo.setServerId(Integer.parseInt(groupId));
				groupInfo.setGroupid(serverId);
				groupInfo.setLevel(Integer.parseInt(groupId));
				
				System.out.println("serverId:"+serverId+"groupId:"+groupId);
				String message = "";
				int count = serverinfoDao.addTServerGroupSingle(groupInfo);
				if(count>0) {
					message="success";
				}else {
					message="fail";
				}
				return message;
			}
			/**
			 * CS集群管理中---退出集群
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws IOException 
			 */
			@RequestMapping(value="/signOutCluster",method= {RequestMethod.POST,RequestMethod.GET})
			public String signOutCluster(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws IOException {
				
				int serverId = Integer.parseInt(request.getParameter("serverId"));
				String groupId  = request.getParameter("groupId");//组id
				int count = serverinfoDao.delTServerGroupInfoByServerId(serverId, groupId);
				if(count>0) {
					message="success";
				}else {
					message="fail";
				}
				response.getWriter().write(message);
				response.getWriter().flush();
				response.getWriter().close();
				return null;
			}
			
			@RequestMapping(value="/selectMsService",method= {RequestMethod.POST,RequestMethod.GET})
			public String selectMsService(HttpServletRequest request,TServerinfo serverinfo,Model model) throws UnsupportedEncodingException {
			
				String serverId = request.getParameter("serverId");
				String serverType= request.getParameter("serverType");
				serverinfo.setIsPad("0");
				
				model.addAttribute("serverType", serverType);
				model.addAttribute("serverId",serverId);
				return "operation/msService";
			}
			
			/**级联
			 * MS子服务器列表管理
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/selectMsServiceMap",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public Map<String, Object> selectMsServiceMap(HttpServletRequest request,TServerinfo serverinfo,Model model) throws Exception {
				 
				String serverId = request.getParameter("serverId");
				serverinfo.setIsPad("0");
			 
				String page = request.getParameter("page");
				String rows = request.getParameter("rows");
				int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				
				String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.LocalIP AS localIp," + 
						"			t.ServerType AS serverType,t2.UserCount AS userCount,t2.UpBit AS upBit" + 
						"		FROM t_serverinfo t LEFT JOIN t_serverbitinfo t2 ON t.ServerID = t2.ServerID WHERE 1 = 1 AND	t.ServerType = '2' AND t.IsPad = '0'";
			
				String total ="SELECT count(1) FROM t_serverinfo t LEFT JOIN t_serverbitinfo t2 ON t.ServerID = t2.ServerID WHERE 1 = 1 AND	t.ServerType = '2' AND t.IsPad = '0'";
				total+="  AND t.ParentId = "+serverId+" ";
				
				if(serverinfo.serverName!=null && !"".equals(serverinfo.serverName)) {
					sql +="and t.ServerName  like '%"+serverinfo.serverName+"%'";
					total+= "and t.ServerName  like '%"+serverinfo.serverName+"%'";
				}
				if(serverinfo.serverIp!=null && !"".equals(serverinfo.serverIp)) {
					sql +=" and t.ServerIP= '"+serverinfo.serverIp+"'";
					total +=" and t.ServerIP= '"+serverinfo.serverIp+"'";
				}
				sql +=" AND t.ParentId = "+serverId+" ORDER BY t.createDate desc limit "+i+","+rows;
				
				ArrayList<Object> msServiceList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				String cnt = Sqlca.getString(total);
				HashMap<String,Object> map = new HashMap<String,Object>();
				map.put("rows", msServiceList);
				map.put("total", cnt);
				return map;
			}
			
			/**
			 * 进入MS服务器新增页面传递serverID
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 * @throws UnsupportedEncodingException 
			 */
			@RequestMapping(value="/addMSServerice",method= {RequestMethod.POST,RequestMethod.GET})
			public String comInMSServerice(HttpServletRequest request,TServerinfo serverinfo,Model model) throws UnsupportedEncodingException {
				int serverId = serverinfo.getServerId();
				model.addAttribute("serverId",serverId);
				return "/operation/addMsService";
			}
			
			/**
			 * 新增MS服务器返回列表
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return 条数
			 * @throws Exception 
			 */
			@RequestMapping(value="/addMsService",method = {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String addMsService(HttpServletRequest request,TServerinfo serverinfo,Model model) throws Exception {
				 
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		        String date =df.format(new Date()); 
				String serverId = serverinfo.getServerId().toString();
				String message ="";

				String msCount="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverinfo.serverName+"' AND (t.ServerType = '2' AND t.IsPad = '0')";
				String count =Sqlca.getString(msCount);
				
				if(Integer.parseInt(count)>0) {
					message="rename";
					return message;
				}else {
					int addSql = Sqlca.updateObject("INSERT INTO t_serverinfo (ServerName,ServerIP,ParentId,ServerType,IsPad,LocalIP,createDate)values(?,?,?,?,?,?,?)", new String[] {
							serverinfo.serverName,serverinfo.serverIp,serverId,"2","0",serverinfo.localIp,date});
					if(addSql>0) {
						message= "1";
					}else {
						message = "fail";
					}
					return message;
				}
			}
	
			/**
			 * 查询修改数据
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 */
			@RequestMapping(value="/selectEditMS",method= {RequestMethod.GET})
			public String selectEditMS(HttpServletRequest request,TServerinfo serverinfo,Model model) {
				model.addAttribute("serverinfo", serverinfo);
				return "/operation/editMsService";
			}
			/**
			 * 保存MS修改数据
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/saveMSService",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String saveMSService(HttpServletRequest request,TServerinfo serverinfo,Model model) throws Exception {
				serverinfo.setServerName(Sqlca.switchLatin1Encoding(serverinfo.getServerName()));
				String serverId = serverinfo.getServerId().toString();
				String parentId = serverinfo.getParentId().toString();
				
				String sql = "SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverinfo.serverName+"'"; 
				sql +="  AND (t.ServerType = '2' AND t.IsPad = '0') and  t.ServerID <>"+serverId;
				String msSql =Sqlca.getString(sql);
				
				StringBuilder buder = new StringBuilder("UPDATE t_serverinfo T SET T.updateDate =  NOW()");
				if(serverinfo.serverName!=null && !"".equals(serverinfo.serverName)) {
					buder.append(" ,T.ServerName = '"+serverinfo.serverName+"'");
				}
				if(serverinfo.serverIp!=null && !"".equals(serverinfo.serverIp)) {
					buder.append(" ,T.ServerIP = '"+serverinfo.serverIp+"'");
				}
				if(serverinfo.localIp!=null && !"".equals(serverinfo.localIp)) {
					buder.append(" ,T.LocalIP = '"+serverinfo.localIp+"'");
				}
				if(serverinfo.serverType!=null && !"".equals(serverinfo.serverType)) {
					buder.append(" ,T.serverType ="+serverinfo.serverType);
				}
				buder.append("  WHERE T.ServerID =" +serverId);
				
				if(Integer.parseInt(msSql)>0) {
					message="0";
				}else {
					Sqlca.updateObject(buder.toString(), new String[] {});
					//serverinfoDao.editTServerinfo(serverinfo);
					message = parentId;
				} 
				return message;
			}
			
			@RequestMapping(value="/changeCascadeAndCs",method= {RequestMethod.POST,RequestMethod.GET})
			public String changeCascadeAndCs(HttpServletRequest request,TServerinfo serverinfo,Model model) throws UnsupportedEncodingException {
			
				String serverId = request.getParameter("serverId");
				model.addAttribute("serverId", serverId);
				return "operation/csCascadeServer";
			}
			
			/**
			 * MS移交级联服务器列表
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/changeCascadeAndCsMap",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public Map<String, Object> changeCascadeAndCsMap(HttpServletRequest request,TServerinfo serverinfo,Model model) throws Exception {
				
				String page = request.getParameter("page");
				String rows = request.getParameter("rows");
				int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
				
				String sqlTotal ="SELECT COUNT(1) FROM  t_serverinfo t WHERE 1 = 1 and t.ServerType = '0' AND t.IsPad = '0'";
				String total =Sqlca.getString(sqlTotal);
				
				String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerPort AS serverPort,t.ServerType AS serverType," + 
						"			t.ParentId AS parentId,t.ParentServerIP AS parentServerIp,t.IsPad AS isPad,t.VsersionNum AS vsersionNum,t.VsersionInfo AS vsersionInfo," + 
						"			t.LocalIP AS localIp FROM t_serverinfo t   WHERE 1 = 1  and  t.ServerType = '0' AND t.IsPad = '0'";
				sql +=" limit "+i+","+rows;
				ArrayList<Object> serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				 
				HashMap<String,Object> map = new HashMap<String,Object>();
				map.put("rows", serverList);
				map.put("total", total);
				return map;
			}
			
			/**
			 * ms子服务器移交到级联服务器
			 * @param request
			 * @param serverinfo
			 * @param model
			 * @return
			 */
			@RequestMapping(value="/MSTransferCascadeServer",method= {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String  MSTransferCascadeServer(HttpServletRequest request,TServerinfo serverinfo,Model model) {
				
				int serverId = Integer.parseInt(request.getParameter("serverId"));//将该id移交移交到，将要移交数据的parentID字段中
				int parentId = Integer.parseInt(request.getParameter("parentId"));
				serverinfo.setServerId(parentId);
				serverinfo.setParentId(serverId);
				String message="";
				
				if(parentId>0) {
					int count = serverinfoDao.updateMSServerData(serverinfo);
					if(count>0) {
						message="success";
					}
				}else {
					message="fail";
				}
				return message;
			}

			
			
	}














