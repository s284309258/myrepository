package com.huawang.controller.operationManage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.huawang.dao.operation.TServerinfoDao;
import com.huawang.pojo.operation.TServerGroupInfo;
import com.huawang.pojo.operation.TServerbitinfo;
import com.huawang.pojo.operation.TServerinfo;
import com.huawang.util.BasicDataUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/cluster")
public class ClusterController {

	@Autowired
	private TServerinfoDao serverinfoDao;
	 
	@RequestMapping(value="/clusterSelect",method= {RequestMethod.POST,RequestMethod.GET})
	public String clusterSelect(HttpServletRequest request, HttpServletResponse response){
		return "operation/clusterService";
	}
	/**
	 * 	查询服务器集群列表
	 * @param request
	 * @param respose
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/clusterSelectMap",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> clusterSelectMap(HttpServletRequest request, HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		String total ="SELECT count(*)FROM t_serverinfo t  WHERE 1 = 1 AND (t.ServerType = '0' AND t.IsPad = '1')";
		
		String sql="SELECT " + 
				"			t.ServerID AS serverId," + 
				"			t.ServerName AS serverName," + 
				"			t.ServerIP AS serverIp," + 
				"			t.ServerPort AS serverPort," + 
				"			t.ServerType AS serverType," + 
				"			t.ParentId AS parentId," + 
				"			t.ParentServerIP AS parentServerIp," + 
				"			t.IsPad AS isPad," + 
				"			t.VsersionNum AS vsersionNum," + 
				"			t.VsersionInfo AS vsersionInfo," + 
				"			t.LocalIP AS localIp " + 
				"		FROM " + 
				"			t_serverinfo t   " + 
				"		WHERE " + 
				"			1 = 1";
		sql +=" AND (t.ServerType = '0' AND t.IsPad = '1')";
		
		if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
			sql +=" and t.ServerName like '%"+serverInfo.serverName+"%'";
			total+=" and t.ServerName like '%"+serverInfo.serverName+"%'";
		}
		if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
			sql +=" and t.ServerIP = '"+serverInfo.serverIp+"'";
			total +=" and t.ServerIP = '"+serverInfo.serverIp+"'";
		}
		if(serverInfo.serverType!=null && !"".equals(serverInfo.serverType)) {
			sql +=" and t.ServerType="+serverInfo.serverType;
			total +=" and t.ServerType="+serverInfo.serverType;
		}
		if(serverInfo.serverId!=null ) {
			sql +=" and t.ServerID="+ serverInfo.serverId;
			total +=" and t.ServerID="+serverInfo.serverId;
		}
		sql +=" ORDER BY t.ServerID  DESC limit "+i+","+rows;
		ArrayList<Object> serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
		String cnt = Sqlca.getString(total);
		  
		if(serverList!=null) {
			for (Object tServerinfo : serverList) {
				//级联服务器
				extracted((TServerinfo) tServerinfo);
			}
		}
		map.put("rows", serverList);
		map.put("total", cnt);
		return map; 
	}

	private void extracted(TServerinfo tServerinfo) throws UnsupportedEncodingException {
		if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)
				&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)) {//如果是级联服务器 0.0
			List<String> strs = serverinfoDao.getTserverId(tServerinfo.getServerId());//根据 parentID查询下面  ms serverId
	
			if (!strs.isEmpty()) {
				int userCount = 0;
				int upBit = 0;
	
				for (String str : strs) {								 //根据id查询ms服务器人数和流量
					List<TServerbitinfo> tServerbitinfos = serverinfoDao.getStrList(Integer.parseInt(str));
					if (!tServerbitinfos.isEmpty()) {
						userCount += tServerbitinfos.get(0).getUserCount();
						upBit += tServerbitinfos.get(0).getUpBit();
					}
				}
				tServerinfo.setUserCount(userCount);
				tServerinfo.setUpBit(upBit);
			}
	
		} else if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ONE_NUMBER)
				&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)) {//是独立服务器 1.0
																   //根据id查询ms服务器人数和流量
			List<TServerbitinfo> tServerbitinfos_1 = serverinfoDao.getStrList(tServerinfo.getServerId()); 
			if (!tServerbitinfos_1.isEmpty()) {
				tServerinfo.setUserCount(tServerbitinfos_1.get(0).getUserCount());
				tServerinfo.setUpBit(tServerbitinfos_1.get(0).getUpBit());
			}
		} else if (tServerinfo.getServerType().equals(BasicDataUtil.BIZ_STRING_ZERO_NUMBER)
				&& tServerinfo.getIsPad().equals(BasicDataUtil.BIZ_STRING_ONE_NUMBER)) {  // 集群 0、1
			int userCount = 0;
			int upBit = 0;										    //如果是集群根据id查询CS服务器
			 List<TServerinfo> list = serverinfoDao.getCounts(tServerinfo.getServerId().toString());
			if (!list.isEmpty()) {
				for (TServerinfo tServerinfo2 : list) {//根据serverId与 parentID 拿到对应的serverId 多个 
					List<String> strs = serverinfoDao.getTserverId(tServerinfo2.getServerId());
					if (!strs.isEmpty()) {
						for (String str : strs) {
																				 //根据id查询ms服务器人数和流量
							List<TServerbitinfo> tServerbitinfos = serverinfoDao.getStrList(Integer.parseInt(str));
							if (!tServerbitinfos.isEmpty()) {
								userCount += tServerbitinfos.get(0).getUserCount();
								upBit += tServerbitinfos.get(0).getUpBit();
							}
						}
					}else if (strs.isEmpty()) {									//根据id查询ms服务器人数和流量
						List<TServerbitinfo> tServerbitinfos_1 = serverinfoDao.getStrList(tServerinfo2.getServerId());
						if (!tServerbitinfos_1.isEmpty()) {
							userCount += tServerbitinfos_1.get(0).getUserCount();
							upBit += tServerbitinfos_1.get(0).getUpBit();
						}
					}
				}
	
				tServerinfo.setClusterCounts(list.size());
				tServerinfo.setUserCount(userCount);
				tServerinfo.setUpBit(upBit);
			}
		}
		if (BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getServerType())
				&& BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getIsPad())) {
			tServerinfo.setServerType(BasicDataUtil.BIZ_STRING_SERVERTYPE01);
		} else if (BasicDataUtil.BIZ_STRING_ONE_NUMBER.equals(tServerinfo.getServerType())
				&& BasicDataUtil.BIZ_STRING_ZERO_NUMBER.equals(tServerinfo.getIsPad())) {
			tServerinfo.setServerType(BasicDataUtil.BIZ_STRING_SERVERTYPE02);
		}
	}		
	
	/**
	 * 	添加修改数据
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addClusterDataServer",method= {RequestMethod.POST})
	@ResponseBody
	public String addClusterDataServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        String date =df.format(new Date()); 
	 
        String isPad= "1";
		String serverType ="0";
		serverInfo.setIsPad(isPad);
		serverInfo.setServerType(serverType);
		String message="";
		
		String sql ="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverInfo.serverName+"' AND (t.ServerType = '0' AND t.IsPad = '1')";
		String addSql=Sqlca.getString(sql);
		  
		if(Integer.parseInt(addSql)>0) {
			message="rename";
			return message;
		}else {
			int sqlCount = Sqlca.updateObject("INSERT INTO t_serverinfo (ServerName,ServerType,IsPad,createDate,ServerIP)values(?,?,?,?,?)", new String[] {
					serverInfo.serverName,serverType,isPad,date, ""});
			if(sqlCount>0) {
				message="success";
			}else {
				message="fail";
			}
			return message;
		}
	}
	
	
	@RequestMapping(value="/addToClusterServer",method = {RequestMethod.POST,RequestMethod.GET})
	public String addToClusterServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) {
		return "operation/addCluster";
	}
	/**
	 * 修改服务器集群
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editCluster",method=RequestMethod.GET)
	public String editClusterServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		//serverInfo = serverinfoDao.getAllDatas(serverInfo);
		
		String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerType AS serverType,t.IsPad AS isPad,t.LocalIP AS localIp FROM " + 
				" t_serverinfo t   WHERE 1 = 1 AND t.ServerID = "+serverInfo.serverId;
	 
		List<Object> list = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
		model.addAttribute("serverInfo", list);
		return "operation/editCluster";
	}
	
	@RequestMapping(value="/saveClusterServer",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String saveClusterServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		String message="";
		String serverid= serverInfo.getServerId().toString();
		
		String sql ="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverInfo.serverName+"' AND (t.ServerType = '0' AND t.IsPad = '1') and t.serverId <>"+serverid;
		String addSql=Sqlca.getString(sql);
		serverInfo.setServerName(Sqlca.switchLatin1Encoding(serverInfo.getServerName()));
		
		StringBuilder buder = new StringBuilder("UPDATE t_serverinfo T SET T.updateDate =  NOW()");
		if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
			buder.append(" ,T.ServerName = '"+serverInfo.serverName+"'");
		}
		buder.append(",T.ServerIP ='' ");
		buder.append("  WHERE T.ServerID ="+serverid);
		if(Integer.parseInt(addSql)>0) {
			message="0";
		}else {
			Sqlca.updateObject(buder.toString(), new String[] {});
			message=serverid;
		} 
		return message;
	}
	
	@RequestMapping(value="/clusterServerManager",method = {RequestMethod.POST,RequestMethod.GET})
	public String clusterServerManager(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		String serverId = request.getParameter("serverId");
		model.addAttribute("serverId", serverId);
		return "operation/clusterManager";
	}
	
	/**
	 * 服务器集群管理
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/clusterServerManagerMap",method = {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> clusterServerManagerMap(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model,String mark) throws Exception {
	
		String serverId = request.getParameter("serverId");
		String cnt ="";
		List<TServerinfo> tServerinfos = new ArrayList<TServerinfo>();
	 
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		 
		ArrayList<Object> serverList = null;
		
		if("cs".equals(mark)) {
			String sql ="SELECT t1.ServerID,t1.ServerName,t1.ServerIP,t1.ServerType,t1.IsPad FROM t_serverinfo t1 LEFT JOIN t_servergroupinfo t2 ON t1.ServerID = t2.groupid WHERE 1=1 ";
			String sqlCount ="SELECT COUNT(1)  FROM t_serverinfo t1 LEFT JOIN t_servergroupinfo t2 ON t1.ServerID = t2.groupid WHERE 1=1 AND t2.ServerID ="+serverId;
			sql +=" AND t2.ServerID ="+serverId;
			if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
				sql +=" AND t1.ServerName like '%"+serverInfo.serverName+"%'";
				sqlCount += " AND t1.ServerName like '%"+serverInfo.serverName+"%'";
			}
			sql +=" ORDER BY t1.createDate DESC limit "+i+","+rows;
			serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
			cnt = Sqlca.getString(sqlCount);
		}else if("cluster".equals(mark)) {
			String sql ="SELECT t1.ServerID,t2.ServerName,t2.ServerIP,t2.ServerType,t2.IsPad,t2.LocalIP FROM t_servergroupinfo t1 INNER JOIN t_serverinfo t2 ON t1.serverid = t2.ServerID" + 
					" WHERE 1 = 1 AND t1.groupid = "+serverId;
			String sqlCount="SELECT COUNT(1) FROM t_servergroupinfo t1 INNER JOIN t_serverinfo t2 ON t1.serverid = t2.ServerID WHERE 1 = 1 AND t1.groupid ="+serverId;
			if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
				sql +=" AND t2.ServerName like '%"+serverInfo.serverName+"%'";
				sqlCount+=" AND t2.ServerName like '%"+serverInfo.serverName+"%'";
			}
			if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
				sql +=" AND t2.ServerIP = '"+serverInfo.serverIp+"'";
				sqlCount+= " AND t2.ServerIP = '"+serverInfo.serverIp+"'";
			}
			sql +=" ORDER BY t2.createDate DESC limit "+i+","+rows;
			serverList =Sqlca.getArrayListFromObj(sql, TServerinfo.class);
			cnt = Sqlca.getString(sqlCount);
		}
		if(serverList!=null) {
			for (Object tServerinfo : serverList) {
				extracted((TServerinfo) tServerinfo);
				tServerinfos.add((TServerinfo) tServerinfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("rows", tServerinfos);
		map.put("total", Integer.parseInt(cnt));
		return map; 
	}
	 
	/**移除服务器
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value="/removeService",method= {RequestMethod.POST,RequestMethod.GET})
	public String removeService(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws IOException {
		String message ="";
		String serverId = request.getParameter("serverId");
		int groupid = Integer.parseInt(request.getParameter("groupId"));
		
		int count = serverinfoDao.delTServerGroupInfoByServerId(groupid, serverId);
		if(count>0) {
			message="success";
		}else {
			message="fail";
		}
		response.getWriter().write(message);
		response.getWriter().flush();
		response.getWriter().close();
		return null;
	}
	
	@RequestMapping(value="/addCSService",method= {RequestMethod.POST,RequestMethod.GET})
	public String addCSService(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws UnsupportedEncodingException {
		int serverId = serverInfo.getServerId();//集群服务器id
		model.addAttribute("serverId",serverId);
		return "operation/addTServerGroup";
	}
	
	
	/**
	 * 跳转进入服务器集群中添加CS服务器界面
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addCSServiceMap",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> addCSServiceMap(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		
		//集群处
		int serverId = Integer.parseInt(request.getParameter("serverId"));//集群服务器id
		System.out.println("集群serverId"+serverId);
		TServerGroupInfo groupInfo = new TServerGroupInfo();
		groupInfo.setServerId(serverId);
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		List<TServerinfo>csList = new ArrayList<TServerinfo>();
		HashMap<String,Object> map = new HashMap<String,Object>();
		
		String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerPort AS serverPort,t.ServerType AS serverType," + 
				"			t.ParentId AS parentId,t.ParentServerIP AS parentServerIp,t.IsPad AS isPad,t.VsersionNum AS vsersionNum,t.VsersionInfo AS vsersionInfo," + 
				"			t.LocalIP AS localIp  FROM t_serverinfo t   WHERE 1 = 1  AND ((t.ServerType = '0' AND t.IsPad = '0'" + 
				"				)OR (t.ServerType = '1' AND t.IsPad = '0' ))";
		sql +=" limit "+i+","+rows;
		String total ="SELECT COUNT(1) FROM  t_serverinfo t WHERE 1 = 1  AND ((t.ServerType = '0' AND t.IsPad = '0')OR (t.ServerType = '1' AND t.IsPad = '0' ))";
		ArrayList<Object> serverList = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
		String cnt = Sqlca.getString(total);
		
		map.put("rows", serverList);
		map.put("total", cnt);
		return map;
	}
	
	/**
	 * 	服务器集群下添加cs服务器方法
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/clusterAddToCSServer",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String clusterAddToCSServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		int serverId = Integer.parseInt(request.getParameter("serverId"));//集群服务器id
		String groupId = request.getParameter("groupId");
		TServerGroupInfo groupInfo = new TServerGroupInfo();
		groupInfo.setServerId(serverId);
		groupInfo.setGroupid(groupId);
		groupInfo.setLevel(serverId);
		String count1 = Sqlca.getString(" SELECT count(1) FROM t_servergroupinfo WHERE groupid ="+groupInfo.getGroupid()+" AND serverid ="+groupInfo.getServerId()+" ");
		if(count1.equals("0")) {
			serverinfoDao.addTServerGroupSingle(groupInfo);
		} 
		JSONObject json = new JSONObject();
		json.put("message", "success");
		return json.toString();
	}
	
	
}
