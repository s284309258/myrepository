package com.huawang.controller.agentManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Agent")
public class AgentManagerController 
{
	
	@RequestMapping(value="/AgentManager.do")
	public ModelAndView AgentManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("agent/AgentList");
		
		return view;
	}
	
	@RequestMapping(value="/AddAgent.do")
	public ModelAndView AddAgent() throws Exception 
	{
		ModelAndView view = new ModelAndView("agent/AddAgent");
		
		return view;
	}
	
	@RequestMapping(value="/ModifyAgent.do")
	public ModelAndView ModifyAgent(@RequestParam("agentId") String agentid) throws Exception {
		String sql = "select agentId,agentName,creater,createTime from t_agent_info where agentId="+agentid;
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("agent/ModifyAgent");
		view.addObject("agent",list.get(0));
		return view ;
		
	}
	
	@RequestMapping(value="/ModifyAgentPage.do")
	public ModelAndView ModifyAgentPage(@RequestParam("agentId") String agentId) throws Exception {
		String sql = "select agentId,agentName,creater,createTime from t_agent_info where agentId="+agentId;
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("agent/ModifyAgentPage");
		view.addObject("agent",list.get(0));
		return view ;
		
	}
	
	@RequestMapping(value="/AddAgentSubmit.do")
	@ResponseBody
	public String AddAgent(HttpServletRequest request,HttpSession session) throws Exception
	{
		String createuser = "";
		String agentId = request.getParameter("agentId");
		String agentName = request.getParameter("agentName");
		String datetime = DateUtil.dateFormat();
		
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			createuser = a.getAdminName();
		}
		
		Sqlca.updateObject("insert into t_agent_info(agentName,creater,createTime) values(?,?,?)", new String[] {agentName,createuser,datetime});
		
		return "success";
	}
	
	@RequestMapping(value="/DelAgent.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String DelAgent(HttpServletRequest request) throws Exception
	{
		String agentid = request.getParameter("agentId");
		String cnt = Sqlca.getString("select CompID from t_compinfo where belongAgent="+agentid);
		if(cnt!=null)
		{
			return "该代理商已有关联的客户,不允许删除";
		}
		String sql = "delete from t_agent_info where agentId=?";
		Sqlca.updateObject(sql, new String[] {agentid});
		return "success";
	}
	
	@RequestMapping(value="/ModifyAgentSubmit.do")
	@ResponseBody
	public String ModifyAgentSubmit(HttpServletRequest request) throws Exception
	{
		String agentId = request.getParameter("agentId");
		String agentName = request.getParameter("agentName");
		
		String sql = "update t_agent_info set agentName=? where agentid=?";
		
		Sqlca.updateObject(sql, new String[] {agentName,agentId});
		
		return "success";
	}
	
	@RequestMapping(value="selectAgentList")
	@ResponseBody
	public Map<String,Object> selectAgentList(HttpServletRequest request) throws Exception
	{
		String agentName = request.getParameter("agentName");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select agentId,agentName,creater,createTime,agentId as agid from t_agent_info where 1=1 ";
		
		String sqlTotal = "select count(*) from t_agent_info where 1=1 ";
		
		if(!"".equals(agentName) && agentName!=null) {
			sql+= " and agentName like '%"+agentName+"%'";
			sqlTotal+= " and agentName like '%"+agentName+"%'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
