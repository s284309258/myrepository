package com.huawang.controller.systemManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;
 
@Controller
@RequestMapping(value="/User")
public class UserManagerController {
	
	
	@RequestMapping(value="UserManager.do")
	public ModelAndView UserManager() throws Exception {
		
		ArrayList<Map<String,Object>> arraylist = OrganManagerController.getOrganMenu();
		
		ModelAndView view = new ModelAndView("system/UserManager");
		view.addObject("organMenu", arraylist);
		return view;
	}
	
	@RequestMapping(value="/UserContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid) throws Exception {
		
//		ArrayList<Map<String,Object>> array = getOrganUserList(dpid);
		ModelAndView view = new ModelAndView("system/UserContent");
//		view.addObject("organUserList", array);
		view.addObject("dpid", dpid);
		return view;
	}
	
	@RequestMapping(value="/AddDepartMentUser.do")
	public ModelAndView AddDepartMent() {
		ModelAndView view = new ModelAndView("system/AddDepartMentUser");
		return view;
	}
	
	
	@RequestMapping(value="/AddDepartMentUserSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserName = request.getParameter("UserName");
		String PassWord = request.getParameter("PassWord");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String Roles = request.getParameter("Roles");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		String AdminIsSuper = request.getParameter("AdminIsSuper");
		String Sex = request.getParameter("Sex");
		String IsAgent = request.getParameter("IsAgent");
		
		String adminname = Sqlca.getString("select AdminName from t_admininfo where AdminName='"+UserName+"'");
		if(null!=adminname)
		{
			return "该账号已存在";
//			throw new Exception("该账号已存在");
		}
		
		PassWord = SecurityUtil.encryptMD5(PassWord);
		
		
		int cnt = Sqlca.updateObject("insert into t_admininfo(AdminName,AdminPassword,AdminTrueName,DpID,Roles,State,Contact,Email,AdminIsSuper,sex,IsAgent) " + 
				"value(?,?,?,?,?,?,?,?,?,?,?)", new String[] {UserName,PassWord,DisplayName,DpId,Roles,UserStatus,Telephone,Email,AdminIsSuper,Sex,IsAgent});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DelDepartMentUserSubmit.do")
	@ResponseBody
	public String DelDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserID = request.getParameter("UserID");
		int cnt = Sqlca.updateObject("delete from t_admininfo where AdminID=?", new String[] {UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	
	@RequestMapping(value="/ModifyDepartMentUserSubmit.do")
	@ResponseBody
	public String ModifyDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String UserID = request.getParameter("UserID");
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String Roles = request.getParameter("Roles");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		String Sex = request.getParameter("Sex");
		String AdminIsSuper = request.getParameter("AdminIsSuper");
		
		int cnt = Sqlca.updateObject("update t_admininfo set AdminName=?,AdminTrueName=?,DpID=?,Roles=?,State=?,Contact=?,Email=?,Sex=?,AdminIsSuper=? " + 
				"where AdminID=?", new String[] {UserName,DisplayName,DpId,Roles,UserStatus,Telephone,Email,Sex,AdminIsSuper,UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyDepartMentUser.do")
	public ModelAndView ModifyDepartMent(@RequestParam("UserID") String UserID) throws Exception {
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select AdminID as UserID,AdminName as UserName,Sex,AdminTrueName as DisplayName,DpId,Roles,State as UserStatus,Contact as Telephone,Email,AdminIsSuper from t_admininfo t where t.AdminID='"+UserID+"'");
		ModelAndView view = new ModelAndView("system/ModifyDepartMentUser");
		view.addObject("user", array.get(0));
		return view;
	}
	
	@RequestMapping(value="/ResetPwdSubmit.do")
	@ResponseBody
	public String ResetPwdSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		String UserName = request.getParameter("UserName");
		String pwd = SecurityUtil.encryptMD5("888888");
		int cnt = Sqlca.updateObject("update t_admininfo set AdminPassword=? where AdminName=?", new String[] {pwd,UserName});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DepartMentUserQuery.do")
	@ResponseBody
	public Map<String,Object> DepartMentUserQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String displayName = request.getParameter("displayName");
		String dpid = request.getParameter("dpid");
		String layout = request.getParameter("layout");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int beginrow = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		if(dpid!=null && layout==null)
		{
			String usql = getOrganUserList(dpid);
			ArrayList<Map<String,Object>> organUserTotal = Sqlca.getArrayListFromMap(usql);
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				usql +=" order by "+SortName+" "+SortValue+" limit "+beginrow+","+rows;
			}
			else
			{
				usql +=" limit "+beginrow+","+rows;
			}
			
//			usql += " LIMIT "+beginrow+","+rows;
			ArrayList<Map<String,Object>> organUserList = Sqlca.getArrayListFromMap(usql);
			Sqlca.getArrayListFromMap(usql);
			HashMap<String,Object> reMap = new HashMap<String,Object>();
			reMap.put("rows", organUserList);
			reMap.put("total", organUserTotal.size());
			return reMap;
		}
		else
		{
			String sql = " select t.AdminID as UserID,t.AdminName as UserName,t.AdminTrueName as DisplayName,           "+
					 " (select DpName from t_admin_group tt where tt.DpId=t.DpId) as DpId,                               "+
					 " (select role_name from t_roles where role_id=t.Roles) as Roles,                                 "+
					 " (select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+
					 " t.Contact as Telephone,t.Email,t.AdminID as Operation                                            "+
					 " from t_admininfo t where 1=1  ";
			
			String sqlTotal = " select count(*) from t_admininfo t where 1=1 ";
			
			if(!"".equals(displayName) && displayName!=null) {
				sql+= " and t.AdminTrueName like '%"+displayName+"%'";
				sqlTotal+= " and t.AdminTrueName like '%"+displayName+"%'";
			}
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				sql +=" order by "+SortName+" "+SortValue+" limit "+beginrow+","+rows;
			}
			else
			{
				sql +=" limit "+beginrow+","+rows;
			}
//			sql += " LIMIT "+beginrow+","+rows;
			
			ArrayList<Map<String,Object>> organUserList = Sqlca.getArrayListFromMap(sql);
			request.setAttribute("organList", organUserList);
			
			HashMap<String,Object> reMap = new HashMap<String,Object>();
			
			String dbtotal = Sqlca.getString(sqlTotal);
			reMap.put("rows", organUserList);
			reMap.put("total", dbtotal);
			
			return reMap;
		}
		
	}
	
	
	
	public String getOrganUserList(String dpid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
		if("99999".equals(dpid)) {dpid="-1";}
		if("-1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,'' as ParentDpName,t.Description from t_admin_group t where t.ParentDpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(where1+",");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.ParentDpId in("+where1+")";
//				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(where2+",");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.ParentDpId in("+where2+")";
//					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
//						sqlbf.append(" union ").append(menus3).append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.DpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.ParentDpId='"+dpid+"'";
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
//				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.ParentDpId in("+where1+")";
				sqlbf.append(where1+",");
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
//					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_admin_group tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_admin_group t where t.ParentDpId in("+where2+")";
					sqlbf.append(where2+",");
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
//						sqlbf.append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}
		
		String where = sqlbf.toString().substring(0, sqlbf.toString().length()-1);
		
		String sql = " select t.AdminID as UserID,t.AdminName as UserName,t.AdminTrueName as DisplayName,                "+
				"  t.DpId as Did,(select DpName from t_admin_group tt where tt.DpId=t.DpId) as DpId,                                "+
				"  t.Roles as Rid,(select role_name from t_roles where role_id=t.Roles) as Roles,                                 "+
				"  t.State as State,(select op_display from t_option where op_param='userStatus' and op_value=t.State) as UserStatus,"+ 
				"  t.contact as Telephone,t.Email,t.AdminID as Operation                                            "+
				"  from t_admininfo t where t.DpId in("+where+")                                                    ";
		
//		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		
		return sql;
		
		}
	
	
	
	
	/*@RequestMapping(value="UserManager.do")
	public ModelAndView UserManager() throws Exception {
		
		ArrayList<Map<String,Object>> arraylist = OrganManagerController.getOrganMenu();
		
		ModelAndView view = new ModelAndView("system/UserManager");
		view.addObject("organMenu", arraylist);
		return view;
	}
	
	@RequestMapping(value="/UserContent.do")
	public ModelAndView OrganContent(@RequestParam("dpid") String dpid) throws Exception {
		
		ArrayList<Map<String,Object>> array = getOrganUserList(dpid);
		ModelAndView view = new ModelAndView("system/UserContent");
		view.addObject("organUserList", array);
		return view;
	}
	
	@RequestMapping(value="/AddDepartMentUser.do")
	public ModelAndView AddDepartMent() {
		ModelAndView view = new ModelAndView("system/AddDepartMentUser");
		return view;
	}
	
	
	@RequestMapping(value="/AddDepartMentUserSubmit.do")
	@ResponseBody
	public String AddDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String CompID = request.getParameter("CompID");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		
		
		int cnt = Sqlca.updateObject("insert into t_userinfo(UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email,OrderIndex) " + 
				"value(?,?,?,?,?,?,?,'0')", new String[] {UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/DelDepartMentUserSubmit.do")
	@ResponseBody
	public String DelDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String UserID = request.getParameter("UserID");
		int cnt = Sqlca.updateObject("delete from t_userinfo where UserID=?", new String[] {UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	
	@RequestMapping(value="/ModifyDepartMentUserSubmit.do")
	@ResponseBody
	public String ModifyDepartMentUserSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String UserID = request.getParameter("UserID");
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String DpId = request.getParameter("DpId");
		String CompID = request.getParameter("CompID");
		String UserStatus = request.getParameter("UserStatus");
		String Telephone = request.getParameter("Telephone");
		String Email = request.getParameter("Email");
		
		int cnt = Sqlca.updateObject("update t_userinfo set UserName=?,DisplayName=?,DpId=?,CompID=?,UserStatus=?,Telephone=?,Email=? " + 
				"where UserID=?", new String[] {UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email,UserID});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyDepartMentUser.do")
	public ModelAndView ModifyDepartMent(@RequestParam("UserID") String UserID) throws Exception {
		ArrayList<Map<String, Object>> array = Sqlca.getArrayListFromMap("select UserID,UserName,DisplayName,DpId,CompID,UserStatus,Telephone,Email from t_userinfo t where t.UserID='"+UserID+"'");
		ModelAndView view = new ModelAndView("system/ModifyDepartMentUser");
		view.addObject("user", array.get(0));
		return view;
	}
	
	@RequestMapping(value="/DepartMentUserQuery.do")
	@ResponseBody
	public ArrayList<Map<String,Object>> DepartMentQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String displayName = request.getParameter("displayName");
		String sql = " select t.UserID,t.UserName,t.DisplayName,(select DpName from t_department tt where tt.DpId=t.DpId) as DpId," + 
				" (select rolename from t_sys_role where roleid=t.CompID) as CompID," + 
				" (select op_display from t_option where op_param='userStatus' and op_value=t.UserStatus) as UserStatus," + 
				" t.Telephone,t.Email,t.UserID as Operation "+
				" from t_userinfo t where t.DisplayName like '%"+displayName+"%'";
		ArrayList<Map<String,Object>> organList = Sqlca.getArrayListFromMap(sql);
		request.setAttribute("organList", organList);
//		request.getRequestDispatcher(request.getContextPath()+"\\system\\OrganContent").forward(request, response);
		return organList;
	}
	
	
	
	public ArrayList<Map<String,Object>> getOrganUserList(String dpid) throws Exception {
		
		StringBuffer sqlbf = new StringBuffer();
//		if("99999".equals(dpid)) {dpid="0";}
		if("1".equals(dpid)) {
			String menus1 = "select t.DpId,t.DpName,'' as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
				sqlbf.append(where1+",");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
//				sqlbf.append(menus2);
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
					sqlbf.append(where2+",");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
//					sqlbf.append(menus3);

					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
//						sqlbf.append(" union ").append(menus3).append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}else {
			String menus = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.DpId='"+dpid+"'";
			sqlbf.append("'"+dpid+"',");
			String menus1 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId='"+dpid+"'";
			StringBuffer buffer = Sqlca.getStringBuffer(menus1);
			if(null!=buffer && !"".equals(buffer.toString())) {
				String where1 = buffer.toString().substring(0, buffer.toString().length()-1);
				
//				sqlbf.append(" union ").append(menus1).append(" union ");
				String menus2 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where1+")";
				sqlbf.append(where1+",");
				
				StringBuffer buffer2 = Sqlca.getStringBuffer(menus2);
				if(null!=buffer2 && !"".equals(buffer2.toString())) {
					String where2 = buffer2.toString().substring(0, buffer2.toString().length()-1);
					
//					sqlbf.append(" union ");
					String menus3 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where2+")";
					sqlbf.append(where2+",");
					
					StringBuffer buffer3 = Sqlca.getStringBuffer(menus3);
					if(null!=buffer3 && !"".equals(buffer3.toString())) {
						String where3 = buffer3.toString().substring(0, buffer3.toString().length()-1);
						
//						sqlbf.append(" union ");
//						String menus4 = "select t.DpId,t.DpName,(select tt.DpName from t_department tt where tt.DpId=t.ParentDpId) as ParentDpName,t.Description from t_department t where t.ParentDpId in("+where3+")";
						sqlbf.append(where3+",");
					}
				}
				
			}
		}
		
		String where = sqlbf.toString().substring(0, sqlbf.toString().length()-1);
		
		String sql = " select t.UserID,t.UserName,t.DisplayName,(select DpName from t_department tt where tt.DpId=t.DpId) as DpId," + 
				" (select rolename from t_sys_role where roleid=t.CompID) as CompID," + 
				" (select op_display from t_option where op_param='userStatus' and op_value=t.UserStatus) as UserStatus," + 
				" t.Telephone,t.Email,t.UserID as Operation "+
				" from t_userinfo t where t.DpId in("+where+")";
		
		ArrayList<Map<String,Object>> array = Sqlca.getArrayListFromMap(sql);
		
		return array;
		
		}*/
}
