package com.huawang.controller.saleManage;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.operation.TServerinfo;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;
import com.huawang.util.CommonInterface;
import com.huawang.util.DateUtil;

@Controller
@RequestMapping(value="/customer")
public class customerManagerController {
	
	static Logger logger = LogManager.getLogger(customerManagerController.class.getName()); 
	@Autowired
	private MeetingRoomDao meetingDao;
	@RequestMapping(value="/selectCustomerManager.do")
	public ModelAndView selectCustomerManager(HttpServletRequest request,TCompinfo compInfo,Model model) throws Exception 
	{
		 String sql =" SELECT"+
		 " AdminName AS adminName,"+
		 " AdminID AS adminId,"+
		 " AdminTrueName AS adminTrueName"+
		 " FROM  t_admininfo  where 1=1";
		 List<Object> adminList =  Sqlca.getArrayListFromObj(sql, TCompinfo.class);
		 
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
		String date = df1.format(new Date());
		model.addAttribute("data", date);
		model.addAttribute("adminlist", adminList);
		ModelAndView view = new ModelAndView("sale/customer/customerList");
		return view ;
	}
	
	
	@RequestMapping(value="delaySerivce",method= {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView delaySerivce(HttpServletRequest request,HttpSession session) throws Exception
	{
		String compId = request.getParameter("compId");
		
		ArrayList<Map<String, Object>> customer = Sqlca.getArrayListFromMap("select CompID,CompName,CompTrueName,ProductID,(select ProductName from t_product_definition tt where tt.ProductId=t_compinfo.productID) as ProductName,MaxUserCount," + 
				" CreateDate,EndDate,ContractEndTime,AdminID,(select AdminTrueName from t_admininfo tt where tt.AdminID=t_compinfo.AdminID) as AdminTrueName,CompStatus," + 
				" (select op_display from t_option t where t.op_param='compOrderStatus' and op_value=CompStatus) as CompStatusName," + 
				" Createuser,CompStyle,Remark from t_compinfo where CompID="+compId);
		
		String CompMaxUserCount = Sqlca.getString("select CompMaxUserCount from t_validbill where CompID="+compId+" order by id desc limit 1");
		String MaxUserCount = (String)customer.get(0).get("MaxUserCount");
		if(CompMaxUserCount==null || "".equals(CompMaxUserCount))
		{
			CompMaxUserCount = MaxUserCount;
		}
		if(!"".equals(CompMaxUserCount) && !"".equals(MaxUserCount))
		{
			int cnt =Integer.parseInt(MaxUserCount)-Integer.parseInt(CompMaxUserCount);
			if(cnt>=0)
			{
				MaxUserCount = String.valueOf(cnt);
			}
		}
		ModelAndView view = new ModelAndView("sale/customer/delayCustomer");
		view.addObject("delay",customer);
		view.addObject("delaycount",MaxUserCount);
		return view;
	}
	
	@RequestMapping(value="customerDetail",method= {RequestMethod.POST,RequestMethod.GET}) 
	public ModelAndView customerDetail(HttpServletRequest request,HttpSession session) throws Exception
	{
		String compId = request.getParameter("compId");
		String sellType = request.getParameter("sellType");
		
		ArrayList<Map<String, Object>> customer = Sqlca.getArrayListFromMap("select CompID,CompName,CompTrueName,ProductID,(select ProductName from t_product_definition tt where tt.ProductId=t_compinfo.productID) as ProductName,MaxUserCount," + 
				" CreateDate,EndDate,ContractEndTime,AdminID,(select AdminTrueName from t_admininfo tt where tt.AdminID=t_compinfo.AdminID) as AdminTrueName,CompStatus," + 
				" (select op_display from t_option t where t.op_param='compOrderStatus' and op_value=CompStatus) as CompStatusName,CompStatus,SellType,VerifyDate,Email," + 
				" Createuser,CompStyle,Remark,Lianxrtel,Lianxr,(select agentName from t_agent_info where agentId=BelongAgent) as BelongAgent,(select ServerName from t_serverinfo where ServerID=McuipId) as ServerName,IsMeeting,MeetingCount,"+
				" IsVerified,IsJoinId,SellType,isJoinApprove,registerType,RegisterTime,TolTimes,TolUseTimes from t_compinfo where CompID="+compId);
		
		ArrayList<Map<String,Object>> user = Sqlca.getArrayListFromMap("select UserID,UserName,RegisterTime,Email from t_userinfo where CompID="+compId+" and IsSuper=1");
		
		
		String businessLicense = Sqlca.getString("select businessLicense from t_comp_certification_info where CompID="+compId);
		if(businessLicense==null) {businessLicense="";}
		
		
		if("1".equals(sellType)) 
		{
			ModelAndView view = new ModelAndView("sale/customer/customerDetailSellType1");
			view.addObject("detail",customer);
			view.addObject("user",user);
			view.addObject("license", businessLicense);
			return view;
		}
		else
		{
			ModelAndView view = new ModelAndView("sale/customer/customerDetail");
			view.addObject("detail",customer);
			view.addObject("user",user);
			view.addObject("license", businessLicense);
			return view;
		}
		
	}
	
	@RequestMapping(value="enlargePoint",method= {RequestMethod.POST,RequestMethod.GET}) 
	public ModelAndView enlargePoint(HttpServletRequest request,HttpSession session) throws Exception
	{
		String compId = request.getParameter("compId");
		
		ArrayList<Map<String, Object>> customer = Sqlca.getArrayListFromMap("select CompID,CompName,CompTrueName,ProductID,(select ProductName from t_product_definition tt where tt.ProductId=t_compinfo.productID) as ProductName,MaxUserCount," + 
				" CreateDate,EndDate,ContractEndTime,AdminID,(select AdminTrueName from t_admininfo tt where tt.AdminID=t_compinfo.AdminID) as AdminTrueName,CompStatus," + 
				" (select op_display from t_option t where t.op_param='compOrderStatus' and op_value=CompStatus) as CompStatusName," + 
				" Createuser,CompStyle,Remark from t_compinfo where CompID="+compId);
		
		ModelAndView view = new ModelAndView("sale/customer/enlargePoint");
		view.addObject("enlarge",customer);
		return view;
	}
	
	@RequestMapping(value="againSign",method= {RequestMethod.POST,RequestMethod.GET}) 
	public ModelAndView againSign(HttpServletRequest request,HttpSession session) throws Exception
	{
		String compId = request.getParameter("compId");
		
		ArrayList<Map<String, Object>> customer = Sqlca.getArrayListFromMap("select CompID,CompName,CompTrueName,ProductID,(select ProductName from t_product_definition tt where tt.ProductId=t_compinfo.productID) as ProductName,MaxUserCount," + 
				" CreateDate,EndDate,ContractEndTime,AdminID,(select AdminTrueName from t_admininfo tt where tt.AdminID=t_compinfo.AdminID) as AdminTrueName,CompStatus," + 
				" (select op_display from t_option t where t.op_param='compOrderStatus' and op_value=CompStatus) as CompStatusName," + 
				" Createuser,CompStyle,Remark from t_compinfo where CompID="+compId);
		
		ModelAndView view = new ModelAndView("sale/customer/againSign");
		view.addObject("sign",customer);
		return view;
	}
	
	
	
	@RequestMapping(value="/selectCustomerManagerMap",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String,Object> selectCustomerManagerMap(HttpServletRequest request,TCompinfo compInfo,Model model,HttpSession session) throws Exception {
		
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
		
			String startTime = request.getParameter("startTime");
			String endTime = request.getParameter("endTime");
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			Object obj = session.getAttribute("USER_SESSION");
			String roledata = "";
			String dpid = "";
			String createUser = "";
			int aid = 99999;
			if(obj!=null)
			{
				TAdmininfo a = (TAdmininfo)obj;
				aid = a.getAdminId();
				createUser = a.getAdminName();
				String roleid = a.getRole();
				roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
				dpid = a.getDpId();
			}
			
			
			String customerList = "select * from( select t1.CompID as compId,t1.CompID as compId1,t1.CompName as compName,t1.CompTrueName as compTrueName,t1.MaxCurUserCount,t1.MaxUserCount,"+
			" t1.EndDate as endDate,(select tt.AdminTrueName from t_admininfo tt where tt.AdminID=t1.AdminID) as adminTrueName,t1.AdminID,"+
			" (select tt.ProductName from t_product_definition tt where tt.ProductId=t1.productID) as productName,"+
			" t1.compStatus as compStatus,t1.productID,t1.sellType,t1.TolTimes,t1.TolUseTimes,"+
			" t1.allocatAdmin as allocatAdmin,t1.ContractEndTime"+
			" from t_compinfo t1 where 1=1 ";
			
			
			String customerListTotal = "select count(*) from( select t1.CompID,t1.CompTrueName,t1.compStatus,t1.EndDate,t1.AdminID from t_compinfo t1 where 1=1 ";
			
			
			if("1".equals(roledata))
			{
				
			}
			else if("2".equals(roledata))
			{
				customerList += " and t1.CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
				
				customerListTotal += " and t1.CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
				//String dporder = Sqlca.getString("");
			}
			else if("3".equals(roledata)) 
			{
				customerList += " and t1.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
			
				customerListTotal += " and t1.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
			}
			customerList +=") tb where 1=1 ";
			customerListTotal +=") tb where 1=1 ";
			
			
			
			if(!"".equals(compInfo.getCompTrueName()) && compInfo.getCompTrueName()!=null) {
				customerList+= " and tb.CompTrueName like '%"+compInfo.getCompTrueName()+"%'";
				customerListTotal+= " and tb.CompTrueName like '%"+compInfo.getCompTrueName()+"%'";
			}
			if(!"".equals(compInfo.getStatus()) && compInfo.getStatus()!=null) {
				customerList+= " and tb.compStatus='"+compInfo.getStatus()+"'";
				customerListTotal+= " and tb.compStatus like '%"+compInfo.getStatus()+"%'";
			}
			if((!"".equals(startTime) && null!=startTime) && (!"".equals(endTime) && null!=endTime))
			{
				customerList+= " and tb.EndDate between '"+startTime+" 00:00:00' and '"+endTime+" 23:59:59'";
				customerListTotal+= " and tb.EndDate between '"+startTime+" 00:00:00' and '"+endTime+" 23:59:59'";
			}
			else if(!"".equals(startTime) && null!=startTime)
			{
				customerList+= " and tb.EndDate <= '"+startTime+" 23:59:59'";
				customerListTotal+= " and tb.EndDate <= '"+startTime+" 23:59:59'";
			}
			else if(!"".equals(endTime) && null!=endTime)
			{
				customerList+= " and tb.EndDate >= '"+endTime+" 23:59:59'";
				customerListTotal+= " and tb.EndDate >= '"+endTime+" 23:59:59'";
			}
			if(!"".equals(compInfo.getAdminName()) && compInfo.getAdminName()!=null) {
				customerList+= " and tb.AdminID='"+compInfo.getAdminName()+"'";
				customerListTotal+= " and tb.AdminID='"+compInfo.getAdminName()+"'";
			}
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				customerList +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
			}
			else
			{
				customerList +=" limit "+i+","+rows;
			}
			
//			customerList += " LIMIT "+i+","+rows;
			
			ArrayList<Map<String, Object>> list  = Sqlca.getArrayListFromMap(customerList);
			
			String total  = Sqlca.getString(customerListTotal);
			
			HashMap<String,Object> map = new HashMap<String,Object>();

			map.put("rows", list);
			map.put("total", total); 
			return map;
			}
 
	/**
	 * 判断两个时间先后顺序
	 * @param date
	 * @return
	 * @throws java.text.ParseException
	 */
	public static int simpDateBy(String date) throws java.text.ParseException {
		//String date1="2017-07-19 13:02:58";
        //将字符串格式的日期格式化
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String date2 = sdf.format(new Date());//当前时间
        //将日期转成Date对象作比较
		Date fomatDate1=sdf.parse(date);
		Date fomatDate2=sdf.parse(date2);
		//比较两个日期
		int result=fomatDate2.compareTo(fomatDate1);
		//如果日期相等返回0
		if(result==0){
		    System.out.println("两个时间相等");
		}else if(result<0){
		    //小于0，参数date1就是在date2之后，未失效
		    System.out.println("date大于date2");
		}else{
		    //大于0，参数date1就是在date2之前，
		    System.out.println("date小于date2");
		}
	        return result;
	    }
	
	public static void main(String[] args) throws java.text.ParseException {
		int date = simpDateBy("2017-07-19 13:02:58");
		
		System.out.println("ddd"+date);
	}
	
	
	
	/**
	 * 给客户账户分配管理员
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/distriAdminAccount",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String distriAdminAccount(HttpServletRequest request,TCompinfo compInfo,Model model) throws Exception {
//		int count = meetingDao.updateCompManager(compInfo);
		String update1 = 
		" UPDATE t_compinfo "+
		" SET "+
		" AdminID = "+compInfo.adminId+
		" ,allocatAdmin = 1"+
		" where CompID= "+compInfo.compId;
		Sqlca.updateObject(update1, new String[] {});
		
		String update2 =
		" update t_order t set t.o_AdminID="  +compInfo.adminId+
		" where t.o_CompID="+compInfo.compId;
		int count = Sqlca.updateObject(update2, new String[] {});
		String message="";
		if(count>0) {
			message="success";
		}else {
			message="fail";
		}
		return message;
	}
	
	
	/**
	 * 给客户账户分配管理员
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/BatchdistriAdminAccount",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String BatchdistriAdminAccount(HttpServletRequest request) throws Exception {
		
		String[] comps = request.getParameterValues("comps[]");
		String adminid = request.getParameter("adminid");
		
		for(String comp :comps)
		{
			String update1 = 
			" UPDATE t_compinfo "+
			" SET "+
			" AdminID = "+adminid+
			" ,allocatAdmin = 1"+
			" where CompID= "+comp;
			Sqlca.updateObject(update1, new String[] {});
			
			String update2 =
					" update t_order t set t.o_AdminID="  +adminid+
					" where t.o_CompID="+comp;
			
			Sqlca.updateObject(update2, new String[] {});
		}
		
		return "success";
		
	}
	
	/**
	 * 	进入新增客户界面
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addCustomer",method=RequestMethod.GET)
	public String addCustomer(HttpServletRequest request,HttpSession session,TCompinfo compInfo,Model model) throws Exception {
		
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			adminid = String.valueOf(admin.getAdminId());
		}
		compInfo.setCreateuser(createUser);
		
//		List<TServerinfo> serverList = meetingDao.getCsServerInfo();
//		List list = new ArrayList();
//		for (TServerinfo tServerinfo : serverList) {
//			tServerinfo.setServerId(tServerinfo.getServerId());
//			tServerinfo.setServerName(Sqlca.switchLatin1Encoding(tServerinfo.getServerName()));
//			tServerinfo.setServerIp(tServerinfo.getServerIp());
//			list.add(tServerinfo);
//		}
		
		ArrayList<Object> serverList = Sqlca.getArrayListFromObj("SELECT t.ServerID AS serverId,concat(t.ServerName,'-',t.ServerIP) AS serverName,t.ServerIP AS serverIp	FROM	t_serverinfo t where 1=1 "
				+ " AND ((	t.ServerType = '0' AND t.IsPad = '0')	OR (t.ServerType = '1' AND t.IsPad = '0')OR (t.ServerType = '0' AND t.IsPad = '1'))", TServerinfo.class);
		
//		List<TCompinfo> getAdminName = meetingDao.getAdminName(compInfo);
//		
//		List lista = new ArrayList();
//		for (TCompinfo tCompinfo : getAdminName) {
//			tCompinfo.setAdminName(Sqlca.switchUtf8Encoding(tCompinfo.getAdminName()));
//			tCompinfo.setAdminId(tCompinfo.getAdminId());
//			tCompinfo.setAdminTrueName(Sqlca.switchUtf8Encoding(tCompinfo.getAdminTrueName()));
//			lista.add(tCompinfo);
//		}
		String AdminListSql = 
		 " SELECT "+
		 " AdminName AS adminName,"+
		 " AdminID AS adminId,"+
		 " AdminTrueName AS adminTrueName"+
		 " FROM  t_admininfo  where 1=1 ";
	 
		ArrayList<Object> getAdminList = Sqlca.getArrayListFromObj(AdminListSql, TCompinfo.class);
		model.addAttribute("adminList", getAdminList);
		model.addAttribute("serverList", serverList);
		return "sale/customer/insertCustomer";
	}
	
	 
	/**
	 * 	保存新增数据
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/saveAddCustomer",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String saveAddCustomer(HttpServletRequest request,HttpSession session,TCompinfo compInfo) throws Exception {
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			adminid = String.valueOf(admin.getAdminId());
		}
		compInfo.setCreateuser(createUser);
		String password = compInfo.getCompPassword();
		String compPassword = SecurityUtil.encryptMD5(password);
		compInfo.setCompPassword(compPassword);
//		int adminId = compInfo.getAdminId();
		compInfo.setAllocatAdmin("0");
//		if(adminId>0) {
//			compInfo.setAllocatAdmin("1");
//		}else {
//			compInfo.setAllocatAdmin("0");
//		}
//		compInfo.setAdminId(adminId);
		String message = "success";
		String compname = Sqlca.getString("select CompName from t_compinfo where CompName = '"+compInfo.compName+"'");
		if(compname!=null) {
			message="fail";
			return message;
		}else {
			Connection conn = Sqlca.getConnection();
			conn.setAutoCommit(false);
			try
			{
				String addCustomerAccount = " INSERT INTO t_compinfo(                                                                                             "+
						" CompName,                                                                                                                               "+
						" CompPassword,                                                                                                                           "+
						" CompTrueName,                                                                                                                           "+
						" Lianxr,                                                                                                                                 "+
						" Lianxrtel,                                                                                                                              "+
						" belongAgent,                                                                                                                            "+
						" compStyle,                                                                                                                              "+
						" MaxCurUserCount,                                                                                                                        "+
						" IsDate,                                                                                                                                 "+
						" IsAddUser,                                                                                                                              "+
						" IsConfLogin,                                                                                                                            "+
						" CreateDate,                                                                                                                             "+
						" AdminID,allocatAdmin,defualtServer,CompStatus,createuser,MaxConfCount,MaxUserCount,McuipId,sellType,registerType,registerTime,IsJoinId,isJoinApprove,IsVerified)          "+
						" VALUES(                                                                                                                                 "+
						" ?,                                                                                                 "+
						" ?,                                                                                             "+
						" ?,                                                                                             "+
						" ?,                                                                                                   "+
						" ?,                                                                                                "+
						" ?,                                                                                              "+
						compInfo.compStyle+
						" ,999,1,1,1,now(),  "+
						compInfo.adminId+
						" ,?,                "+
						" ?,8,?,999,null,?,2,'WEB','"+DateUtil.dateFormat("yyyy-MM-dd")+"',0,0,0  "+
						" )   ";
				
				Sqlca.updateObject(conn,addCustomerAccount, new String[] {compInfo.compName.trim(),compInfo.compPassword,compInfo.compTrueName.trim(),compInfo.lianxr,compInfo.lianxrtel,
						compInfo.belongAgent,compInfo.allocatAdmin,compInfo.serverName,compInfo.createuser,compInfo.serverName});
				
				
				String selectGetKey =
				" select compId from t_compinfo where "+
				" CompName ='"+compInfo.compName+"'";
				
				String compid = Sqlca.getString(conn,selectGetKey);
				
				
				String addUserInfo =
						" INSERT INTO t_userinfo (AdminID,DpId,"+
						" CompID,"+
						" UserName,"+
						" UserPassword,"+
						" DisplayName,Telephone,IsSuper,State)"+
						" VALUES("+
						compInfo.adminId+",1,"+
						compid+","+
						" ?,"+
						" ?,"+
						" ?,"+
						" ?,"+
						" '1','0')";
				Sqlca.updateObject(conn,addUserInfo, new String[] {compInfo.compName,compInfo.compPassword,compInfo.lianxr,compInfo.lianxrtel});
				conn.commit();
			}
			catch(Exception e)
			{
				conn.rollback();
				message="fail";
			}
			finally
			{
				Sqlca.closeAll(conn, null, null);
			}
			return message;
		}
	}
	/**
	 *     查看修改客户信息
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/editCustomerInfo",method=RequestMethod.GET)
	public String editCustomerInfo(HttpServletRequest request,TCompinfo compInfo,Model model) throws Exception {
		int compId = Integer.parseInt(request.getParameter("compId"));
		compInfo.setCompId(compId);
		
		String sql =
		" select t.CompID,t.CompTrueName as compTrueName,t.belongAgent,t.adminID as adminId,"+
		" (select adminTrueName from t_admininfo where t_admininfo.adminid=t.AdminID) as adminTrueName,"+
		" t.McuipId as McuipId,"+
		" t.Lianxr,t.Lianxrtel,t.CompName,t.CompPassword,t.IsMeeting,t.MeetingCount,isJoinApprove,isJoinId,sellType from t_compinfo t "+
		" where t.CompID ="+compId;
		
		ArrayList<Object> List = Sqlca.getArrayListFromObj(sql, TCompinfo.class);
		compInfo = (TCompinfo)List.get(0);
		
		model.addAttribute("compInfo", compInfo);
		return "sale/customer/editCustomer";
	}
	
	
	
	
	/**
	 * 保存客户修改信息
	 * @param request
	 * @param compInfo
	 * @param model
	 * @return 
	 * @throws Exception 
	 */
	@RequestMapping(value="/saveCustomerInfo",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String saveCustomerInfo(HttpServletRequest request,TCompinfo compInfo,Model model) throws Exception {
		
	  String isMeeting  = request.getParameter("isMeeting");
	  String isJoinApprove  = request.getParameter("isJoinApprove");
	  String isJoinId  = request.getParameter("isJoinId");
	  String adminId = request.getParameter("adminId");
	  String meet = request.getParameter("meet"); 
	  int meetingCount =  compInfo.getMeetingCount(); 
		  if(meetingCount==0) { 
			  meet =  String.valueOf(meetingCount); 
		  }else { 
			  	meet = meet; 
			  }
		  String message = "";
		    
			String compPass = compInfo.compPassword;
			String compPassdatabase = Sqlca.getString("select CompPassword from t_compinfo where CompID="+compInfo.getCompId());
			if(!compPass.equals(compPassdatabase))
			{
				compPass = SecurityUtil.encryptMD5(compInfo.compPassword);
			} 
			
			String uptcomp =" update  t_compinfo t1   "+
			" set                                "+
			" 	t1.CompTrueName =?,              "+
			" 	t1.belongAgent =?,               "+
			" 	t1.Lianxr =?,                    "+
			" 	t1.Lianxrtel =?,                 "+
			" 	t1.CompName =?,                 "+
			" 	t1.McuipId = ?,                  "+
			" 	t1.CompPassword = ? ,            "+
		    " 	t1.IsMeeting = ? ,             	 "+
		    " 	t1.MeetingCount = ?,t1.isJoinApprove=?,t1.isJoinId=?,t1.AdminID=?,t1.sellType='"+compInfo.sellType+"'              "+
			" where t1.CompID = "+compInfo.compId;
			Sqlca.updateObject(uptcomp, new String[] {compInfo.compTrueName,compInfo.belongAgent,compInfo.lianxr,compInfo.lianxrtel,
					compInfo.compName,compInfo.serverName,compPass,String.valueOf(isMeeting),meet,isJoinApprove,isJoinId,adminId});
			
			Sqlca.updateObject(" update t_order t set t.o_CompName=? "+
					" where t.o_CompID = "+compInfo.compId, new String[] {compInfo.compTrueName});
			
			Sqlca.updateObject(" update t_confinfo t set t.ServerId=?  "+
					" where t.CompID="+compInfo.compId, new String[] {compInfo.serverName});
			Sqlca.updateObject(" UPDATE t_userinfo SET UserPassword =?,DisplayName =?,Telephone=? WHERE UserName =?", new String[] {compPass,compInfo.lianxr,compInfo.lianxrtel,compInfo.compName});
			
		return "success";
	}
	
	@RequestMapping(value="/DelayProductTry",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String DelayProductTry(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		String role = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			role = admin.getRole();
		}
		String o_status = "1";
		String o_UseTimes = request.getParameter("UseTimes");
		String o_UseDays = request.getParameter("pDelayDays");
		String o_CompID = request.getParameter("CompID");
		String o_Product = request.getParameter("ProductID");
		String o_MaxUserCount = request.getParameter("pMaxUserCount");
		String o_CreateDate = request.getParameter("pCreateDate");
		String o_EndDate = request.getParameter("pEndDate");
		String o_Remark = request.getParameter("Remark");
		ArrayList<Map<String,Object>> list = Sqlca.getArrayListFromMap("select t.AdminID,t.ProductID from t_compinfo t where t.CompID='"+o_CompID+"'");
		Map<String,Object> map = list.get(0);
		adminid = (String)map.get("AdminID");
		String ProductID = (String)map.get("ProductID");
		if(o_CreateDate.compareTo(DateUtil.dateFormat("yyyy-MM-dd"))>0)
	    {
	    	o_status="8";
	    }
		int d = Integer.parseInt(o_UseDays);
		if(d>15)
		{
			o_status = "2";
		}
		int t = Integer.parseInt(o_UseTimes);
		if(t<=0)
		{
			o_status = "2";
		}
		
		o_CreateDate = DateUtil.getDateYMD(o_CreateDate, "00:00:00");
		o_EndDate = DateUtil.getDateYMD(o_EndDate, "23:59:59");
		if("1".equals(o_status))
		{
			String CompStatus = Sqlca.getString("select CompStatus from t_compinfo where CompID="+o_CompID);
			//1.生成单据(普通单据、叠加单据)
			if(o_Product.equals(ProductID))
			{
				if("10".equals(CompStatus))
				{
					String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
							" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
							" VALUES(?,'3',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
					
					Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
							o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
				}
				else
				{
					String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
							" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
							" VALUES(?,'1',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
					Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
							o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
				}
				String orderid = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
				//1.生成单据
				CommonInterface.GenerateBillRecord(orderid);
				//2单据生效
				CommonInterface.UpdateStatusUsing(orderid);
				//3更新客户状态
				CommonInterface.UpdateCompStatus(o_CompID);
			}
			else
			{
				Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
				
				String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
						" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
						" VALUES(?,'1',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
				Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
						o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
				
				String orderid = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
				//1.生成单据
				CommonInterface.GenerateBillRecord(orderid);
				//2单据生效
				CommonInterface.UpdateStatusUsing(orderid);
				//3更新客户状态
				CommonInterface.UpdateCompStatus(o_CompID);
			}
			
		}
		else
		{
			String CompStatus = Sqlca.getString("select CompStatus from t_compinfo where CompID="+o_CompID);
			if("10".equals(CompStatus))
			{
				String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
						" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
						" VALUES(?,'3',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
				
				Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
						o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
			}
			else
			{
				String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
						" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
						" VALUES(?,'1',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
				Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
						o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
			}
			if("8".equals(o_status))
			{
				Sqlca.updateObject("update t_compinfo set EndDate='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
			}
		}
		return "success";
	}
	
	
	
	
	@RequestMapping(value="/EnlargeProductPoint",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String EnlargeProductPoint(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		String role = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			role = admin.getRole();
		}
		String o_status = "1";
		String o_UseTimes = request.getParameter("UseTimes");
		String o_UseDays = request.getParameter("pDelayDays");
		String o_CompID = request.getParameter("CompID");
		String o_Product = request.getParameter("ProductID");
		String o_MaxUserCount = request.getParameter("pMaxUserCount");
		String o_CreateDate = request.getParameter("pCreateDate");
		String o_EndDate = request.getParameter("pEndDate");
		String o_Remark = request.getParameter("Remark");
		ArrayList<Map<String,Object>> list = Sqlca.getArrayListFromMap("select t.AdminID,t.ProductID from t_compinfo t where t.CompID='"+o_CompID+"'");
		Map<String,Object> map = list.get(0);
		adminid = (String)map.get("AdminID");
		String ProductID = (String)map.get("ProductID");
		if(o_CreateDate.compareTo(DateUtil.dateFormat("yyyy-MM-dd"))>0)
	    {
	    	o_status="8";
	    }
		int d = Integer.parseInt(o_UseDays);
		if(d>15)
		{
			o_status = "2";
		}
		int t = Integer.parseInt(o_UseTimes);
		if(t<=0)
		{
			o_status = "2";
		}
		
		o_CreateDate = DateUtil.getDateYMD(o_CreateDate, "00:00:00");
		o_EndDate = DateUtil.getDateYMD(o_EndDate, "23:59:59");
		String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
				" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
				" VALUES(?,'3',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
		Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
				o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
		if("1".equals(o_status))
		{
			//1.生成单据(普通单据、叠加单据)
			String orderid = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
			CommonInterface.GenerateBillRecord(orderid);
			//2单据生效
			CommonInterface.UpdateStatusUsing(orderid);
			//3更新客户状态
			CommonInterface.UpdateCompStatus(o_CompID,"10");
		}
		else
		{
			if("8".equals(o_status))
			{
				Sqlca.updateObject("update t_compinfo set EndDate='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
			}
		}
		return "success";
	}
	
	@RequestMapping(value="/AgainSign",method= {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AgainSign(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String CompID = request.getParameter("CompID");
		String pMaxUserCount = request.getParameter("pMaxUserCount");
		String pCreateDate = request.getParameter("pCreateDate");
		String pEndDate = request.getParameter("pEndDate");
		String pProductID = request.getParameter("pProductID");
		String pSignRadio = request.getParameter("pSignRadio");
		String Remark = request.getParameter("Remark");
		adminid = Sqlca.getString("select t.AdminID from t_compinfo t where t.CompID="+CompID);
//		String s1 = Sqlca.getString("select id from t_order where " + 
//				" o_Status in('2','3','4','6') and o_Type='2' and o_CompID='"+CompID+"' and o_Product='"+pProductID+"'");
//		if(s1!=null && !"".equals(s1))
//		{
//			return "已存在一个正在处理的签约订单,请先处理该订单";
//		}
 		
		pCreateDate = DateUtil.getDateYMD(pCreateDate, "00:00:00");
		pEndDate = DateUtil.getDateYMD(pEndDate, "23:59:59");
		String compStyle = Sqlca.getString("select compStyle from t_compinfo where CompID="+CompID);
		if(compStyle==null || "".equals(compStyle)) {compStyle="2";}
		String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount," + 
				" o_CreateDate,o_EndDate,o_Remark,o_createTime,o_createUser,o_AdminID,o_Style,o_SignRadio)" + 
				" VALUES('2','2',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,SYSDATE(),?,?,?,?)";
		Sqlca.updateObject(insertOrder, new String[] {CompID,CompID,pProductID,pMaxUserCount,
				pCreateDate,pEndDate,Remark,createUser,adminid,compStyle,pSignRadio});
		
		return "success";
	}
	
	@RequestMapping(value="DelCustomer",method= {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String DelCustomer(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String cid = request.getParameter("cid");
		String id = Sqlca.getString("select id from t_order where o_CompID="+cid);
		if(id!=null)
		{
			return "该客户已经产生了其他订单,不允许直接删除";
		}
		String sql = "delete from t_compinfo where compid=?";
		Sqlca.updateObject(sql, new String[] {cid});
		return "success";
	}
	
	
	@RequestMapping(value="VerifyComp",method= {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String VerifyComp(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String o_CompID = request.getParameter("CompID");
		String o_Remark = request.getParameter("o_Remark");
		String IsVerified = request.getParameter("IsVerified");
		String currDate = DateUtil.dateFormat();
		
		
		if("2".equals(IsVerified)) 
		{
			Sqlca.updateObject("update t_compinfo set IsVerified=2,remark='"+o_Remark+"' where CompID="+o_CompID,new String[] {});
			return "success";
		}
		
		ArrayList<Map<String, Object>> tcs = Sqlca.getArrayListFromMap("select productID,AdminID,CompTrueName from t_compinfo where CompID="+o_CompID);
		String productID = (String)tcs.get(0).get("productID");
		String AdminID = (String)tcs.get(0).get("AdminID");
		String CompTrueName = (String)tcs.get(0).get("CompTrueName");
		String otid = "";
		String oaCode = "";
		
//		ArrayList<Map<String, Object>> oas = Sqlca.getArrayListFromMap("select otid,oaCode from t_operation_activity where type=1 and now() BETWEEN startTime and endTime and action=2 and isuse=1 and ");
//		if(oas.size()>0)
//		{
//			otid = (String)oas.get(0).get("otid");
//			oaCode = (String)oas.get(0).get("oaCode");
//		}
		
		
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap("select freeProduct,freeMinute,freeTime,freeTimeUnit,freePoint,oa.otid,oa.oaCode from t_operation_activity oa, "
				+ " t_operation_template ot where oa.otid=ot.spid and oa.type=1 and now() BETWEEN oa.startTime and oa.endTime and oa.action=2 and oa.isuse=1 and ot.freeProduct="+productID);
		if(mm.size()>0)
		{
			String freeProduct = (String)mm.get(0).get("freeProduct");
			String freeMinute = (String)mm.get(0).get("freeMinute");
			 
			 String freeTime = (String)mm.get(0).get("freeTime");
			 String freeTimeUnit = (String)mm.get(0).get("freeTimeUnit");
			 String freePoint = (String)mm.get(0).get("freePoint");
			 String o_EndDate = "";
			 String o_CreateDate = "";
			 
			 if("日".equals(freeTimeUnit))
			 {
				 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime), 0);
			 }
			 else if("月".equals(freeTimeUnit))
			 {
				 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime));
			 }
			 else if("年".equals(freeTimeUnit))
			 {
				 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime)*12);
			 }
			 o_CreateDate = DateUtil.dateFormat(0, 0)+" 00:00:00";
			 o_EndDate = o_EndDate+" 23:59:59";
			 
			 String sellType = Sqlca.getString("select sellType from t_compinfo where CompID="+o_CompID+" and IsVerified=0");
			 if("2".equals(sellType))
			 {
//				 String o_Product = Sqlca.getString("select productID from t_compinfo where CompID="+o_CompID);
				 
				 String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount," + 
							" o_CreateDate,o_EndDate,o_Remark,o_createTime,o_createUser,o_AdminID,o_Style,o_SignRadio)" + 
							" VALUES('1','2',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,SYSDATE(),?,?,?,?)";
					int cnt = Sqlca.updateObject(insertOrder, new String[] {o_CompID,o_CompID,productID,freePoint,
							o_CreateDate,o_EndDate,"","1","1","2","2"});
					
					String id = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
					if(cnt>0) 
					{
						//Sqlca.updateObject("update t_compinfo set compStyle=? where CompID=?", new String[] {"2",o_CompID});
						//1.生成单据(普通单据、叠加单据)
						CommonInterface.GenerateBillRecord(id);
						//2单据生效
						CommonInterface.UpdateStatusUsing(id);
						//3更新客户状态
						CommonInterface.UpdateCompStatus(o_CompID);
						
						Sqlca.updateObject("update t_compinfo set VerifyDate='"+currDate+"',IsVerified=1 where CompID="+o_CompID,new String[] {});
						return "success";
					}
			 }
			 else if("1".equals(sellType))
			 {
				 String insertOrder="insert into t_timeorder(o_Type,o_MaxUserCount,o_Product,o_Status,o_AdminID,"
							+ " o_CreateTime,o_CreateUser,o_CompID,o_CompName,o_sellType,o_amount,createtype,oaid,spid,o_totalTime,o_Style,o_Remark)"
							+ " values(? ,? ,? ,? ,? ,? ,? ,? ,?,?,?,?,?,?,?,?,'"+o_Remark+"')";
					Sqlca.updateObject(insertOrder, new String[] {"5","99999",productID,"1",AdminID,o_CreateDate,"admin",o_CompID,CompTrueName,"1","0","1",oaCode,"",freeMinute,"2"});
					
				 Sqlca.updateObject("update t_compinfo set productID='"+freeProduct+"',TolTimes=(TolTimes+'"+freeMinute+"'),MaxUserCount=99999 where CompID=?", new String[] {o_CompID});
			 }
		}
		 
		 Sqlca.updateObject("update t_compinfo set VerifyDate='"+currDate+"',IsVerified=1,remark='"+o_Remark+"' where CompID="+o_CompID,new String[] {});
		
		return "success";
	}
	
	

}
