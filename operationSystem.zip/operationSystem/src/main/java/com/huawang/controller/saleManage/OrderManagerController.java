package com.huawang.controller.saleManage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.CommonInterface;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Order")
public class OrderManagerController {
	
	static Logger logger = LogManager.getLogger(OrderManagerController.class.getName()); 

	@RequestMapping(value="/AddTryOrder.do")
	public ModelAndView AddTryOrder(HttpServletRequest request) throws Exception 
	{
		String compName = request.getParameter("compName");
		String compid = Sqlca.getString("select CompID from t_compinfo where CompName='"+compName+"'");
		ModelAndView view = new ModelAndView("sale/order/TryOrder");
		view.addObject("cid", compid);
		return view ;
	}
	
	@RequestMapping(value="/AddSignOrder.do")
	public ModelAndView AddSignOrder(HttpServletRequest request) throws Exception
	{
		String compId = request.getParameter("compId");
		ArrayList<Map<String,Object>> customer = Sqlca.getArrayListFromMap("select CompID,CompName,ProductID,CompStyle from t_compinfo where CompID="+compId);
		ModelAndView view = new ModelAndView("sale/order/SignOrder");
		view.addObject("sign", customer);
		return view ;
	}
	
	@RequestMapping(value="/AddTempOrder.do")
	public ModelAndView AddTempOrder() 
	{
		ModelAndView view = new ModelAndView("sale/order/TempOrder");
		return view ;
	}
	@RequestMapping(value="/OrderManager.do")
	public ModelAndView OrderManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/order/OrderManager");
		return view ;
	}
	
	
	
	@RequestMapping(value="/OrderManagerQuery.do")
	@ResponseBody
	public Map<String,Object> OrderManagerQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String userName = request.getParameter("userName");
		String product = request.getParameter("product");
		String admin = request.getParameter("admin");
		String orderType = request.getParameter("orderType");
		String orderStatus = request.getParameter("orderStatus");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		
		String isQuery = request.getParameter("isQuery");
		if(!"yes".equals(isQuery)) 
		{
			orderStatus = request.getParameter("preApprove");
		}
		
		
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		Object obj = session.getAttribute("USER_SESSION");
		int aid = 99999;
		String roledata = "";
		String dpid = "";
		String createuser = "";
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			aid = a.getAdminId();
			String roleid = a.getRole();
			createuser = a.getAdminName();
			roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
			dpid = a.getDpId();
		}
		
		String sql="select * from ("+
				" select t.id,t.o_Product,t.o_MaxUserCount,t.o_CreateDate,o_CreateUser,t.o_EndDate,t.o_AdminID,          "+
				" t.o_Type,t.o_Status,t.o_CompID,(select CompName from t_compinfo  where CompID=t.o_CompID) as CompName,t.o_CompName, "+
				" (select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,                           "+
				" (select AdminTrueName from t_admininfo where AdminID=t.o_AdminID) as AdminName,                                        "+
				" (select op_display from t_option where op_param='orderType' and op_value=t.o_Type) as orderType,                      "+
				" (select AdminTrueName from t_admininfo where adminName=o_CreateUser) as CreateUser,"+
				" (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus from t_order t "+
				" where t.o_CreateUser='"+createuser+"' or 1=1  ";
				
		
		
		String sqlTotal="select count(*) from ( select t.o_CompID,t.o_CompName,t.o_Product,t.o_AdminID,t.o_Type,t.o_Status from t_order t where t.o_CreateUser='"+createuser+"' or 1=1 ";
		
		if("1".equals(roledata))
		{
			
		}
		else if("2".equals(roledata))
		{
			sql += " and t.o_CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
			
			sqlTotal += " and t.o_CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
		}
		else if("3".equals(roledata)) 
		{
			sql += " and t.o_CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		
			sqlTotal += " and t.o_CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		}
		sql+=") tb where 1=1 ";
		sqlTotal+=") tb where 1=1 ";
		
		
		if(!"".equals(userName) && userName!=null) 
		{
			sql+= " and tb.o_CompName like '%"+userName+"%'";
			sqlTotal += " and tb.o_CompName like '%"+userName+"%'";
		}
		
		if(!"".equals(product) && product!=null) 
		{
			sql+= " and tb.o_Product='"+product+"'";
			sqlTotal+= " and tb.o_Product='"+product+"'";
		}
		
		if(!"".equals(admin) && admin!=null) 
		{
			sql+= " and tb.o_AdminID='"+admin+"'";
			sqlTotal+= " and tb.o_AdminID='"+admin+"'";
			
		}
		
		if(!"".equals(orderType) && orderType!=null) 
		{
			sql+= " and tb.o_Type='"+orderType+"'";
			sqlTotal+= " and tb.o_Type='"+orderType+"'";
		}
		
		if(!"".equals(orderStatus) && orderStatus!=null) 
		{
			sql+= " and tb.o_Status='"+orderStatus+"'";
			sqlTotal+= " and tb.o_Status='"+orderStatus+"'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
//		sql += " LIMIT "+total+","+rows;
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	
	
	@RequestMapping(value="/OrderManagerQueryByCompID.do")
	@ResponseBody
	public Map<String,Object> OrderManagerQueryByCompID(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String userName = request.getParameter("userName");
		String product = request.getParameter("product");
		String admin = request.getParameter("admin");
		String orderType = request.getParameter("orderType");
		String orderStatus = request.getParameter("orderStatus");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		String o_CompID = request.getParameter("o_CompID");
		
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql="select * from ("+
				" select t.id,t.o_Product,t.o_MaxUserCount,t.o_CreateDate,o_CreateUser,t.o_EndDate,t.o_AdminID,          "+
				" t.o_Type,t.o_Status,t.o_CompID,(select CompName from t_compinfo  where CompID=t.o_CompID) as CompName,t.o_CompName, "+
				" (select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,                           "+
				" (select AdminTrueName from t_admininfo where AdminID=t.o_AdminID) as AdminName,                                        "+
				" (select op_display from t_option where op_param='orderType' and op_value=t.o_Type) as orderType,                      "+
				" (select AdminTrueName from t_admininfo where adminName=o_CreateUser) as CreateUser,"+
				" (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus from t_order t "+
				" where t.o_CompID='"+o_CompID+"' ";
				
		
		
		String sqlTotal="select count(*) from ( select t.o_CompID,t.o_CompName,t.o_Product,t.o_AdminID,t.o_Type,t.o_Status from t_order t where t.o_CompID='"+o_CompID+"' ";
		
		
		sql+=") tb where 1=1 ";
		sqlTotal+=") tb where 1=1 ";
		
		
		if(!"".equals(userName) && userName!=null) 
		{
			sql+= " and tb.o_CompName like '%"+userName+"%'";
			sqlTotal += " and tb.o_CompName like '%"+userName+"%'";
		}
		
		if(!"".equals(product) && product!=null) 
		{
			sql+= " and tb.o_Product='"+product+"'";
			sqlTotal+= " and tb.o_Product='"+product+"'";
		}
		
		if(!"".equals(admin) && admin!=null) 
		{
			sql+= " and tb.o_AdminID='"+admin+"'";
			sqlTotal+= " and tb.o_AdminID='"+admin+"'";
			
		}
		
		if(!"".equals(orderType) && orderType!=null) 
		{
			sql+= " and tb.o_Type='"+orderType+"'";
			sqlTotal+= " and tb.o_Type='"+orderType+"'";
		}
		
		if(!"".equals(orderStatus) && orderStatus!=null) 
		{
			sql+= " and tb.o_Status='"+orderStatus+"'";
			sqlTotal+= " and tb.o_Status='"+orderStatus+"'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	
	
	@RequestMapping(value="/OrderDetail.do")
	public ModelAndView OrderDetail(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		String id = request.getParameter("id");
		String sql = " select id,o_CompID,o_CompName,o_MaxUserCount,o_UseDays,o_UseTimes,o_CreateDate,o_EndDate,o_Remark,o_Opinion,o_Type,o_Status,o_AdminID,o_Product,o_Style, "+
				" (select op_display from t_option where op_param='orderType' and op_value=t.o_Type) as orderType,        "+
				" (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus, "+
				" (select AdminName from t_admininfo where AdminID=t.o_AdminID) as AdminName,                          "+
				" (select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,o_SignRadio              "+
				" from t_order t where id='"+id+"' ";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("sale/order/OrderDetail");
		view.addObject("orderList",list);
		return view;
	}
	
	
	@RequestMapping(value="/OrderApproveSubmit.do")
	public ModelAndView OrderApproveSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		String id = request.getParameter("id");
		String sql = " select id,o_CompID,o_CompName,o_MaxUserCount,o_CreateDate,o_EndDate,o_Remark,o_Opinion,o_Type,o_Status,o_AdminID,o_Product,o_Style, "+
				" (select op_display from t_option where op_param='orderType' and op_value=t.o_Type) as orderType,        "+
				" (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus, "+
				" (select AdminName from t_admininfo where AdminID=t.o_AdminID) as AdminName,                          "+
				" (select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,o_SignRadio              "+
				" from t_order t where id='"+id+"' ";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("sale/order/OrderApprove");
		view.addObject("orderList",list);
		return view;
	}
	
	
	@RequestMapping(value="/RevokeOrder.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String RevokeOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String id = request.getParameter("id");
		String o_Type = request.getParameter("o_Type");
		String o_Status = request.getParameter("o_Status");
		String o_AdminID = request.getParameter("o_AdminID");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Opinion = request.getParameter("o_Opinion");
		
//		if(!"2".equals(o_Status) && !"1".equals(o_Status))
//		{
//			return "只允许撤回待审核(使用中)状态的订单";
//			//throw new Exception("只允许撤回待审核状态的订单");
//		}
		if(!"2".equals(o_Status))
		{
			return "只允许撤回待审核状态的订单";
			//throw new Exception("只允许撤回待审核状态的订单");
		}
		if("1".equals(o_Status))
		{
			ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap("select RelateBillNo,CompMaxUserCount,BillNo from t_validbill where OrderID="+id);
			if(list.size()>0)
			{
				Map<String, Object> map = list.get(0);
				String RelateBillNo = (String)map.get("RelateBillNo");
				String CompMaxUserCount = (String)map.get("CompMaxUserCount");
				String BillNo = (String)map.get("BillNo");
				String ProductID = Sqlca.getString("select ProductID from t_validbill where BillNo='"+RelateBillNo+"'");
				Sqlca.updateObject("update t_compinfo set MaxUserCount="+CompMaxUserCount+",productID="+ProductID+",EndDate=(select MAX(EndDate)"
						+ " from t_validbill where BillNo='"+RelateBillNo+"') where CompID=?", new String[] {o_CompID});
				
				Sqlca.updateObject("update t_compinfo_product set productId="+ProductID+" where compId=?", new String[] {o_CompID});
				Sqlca.updateObject("update t_confinfo set ProductType="+ProductID+" where CompID=?", new String[] {o_CompID});
				
				String orid = Sqlca.getString("select OrderID from t_validbill where BillNo='"+RelateBillNo+"'");
				
				String sign =Sqlca.getString("select id from t_order where id in (select OrderID from t_validbill where CompID=0 and BillNo<'"+RelateBillNo+"') and o_Type=2");
				if(sign==null)
				{
					Sqlca.updateObject("update t_compinfo set ContractEndTime = null where CompID=?",new String[] {o_CompID});
				}
				String status = CommonInterface.UpdateCompStatus(o_CompID);
				if("5".equals(status) || "1".equals(status))
				{
					Sqlca.updateObject("update t_order set o_Status=1 where id=?", new String[] {orid});
				}
				if("6".equals(status) || "8".equals(status))
				{
					Sqlca.updateObject("update t_order set o_Status=5 where id=?", new String[] {orid});
				}
				Sqlca.updateObject("update t_validbill SET CreateDate='2099-01-01 00:00:00',EndDate='2099-01-01 23:59:59' where CompID="+o_CompID+" and BillNo>?", new String[] {RelateBillNo});
			}
		}
		
		Sqlca.updateObject("update t_order set o_Status='4',o_Remark=? where id=?", new String[] {o_Remark,id});
		
		
		return "success";
	}
	
	
	@RequestMapping(value="/ReplaySubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String ReplaySubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String id = request.getParameter("id");
		String o_Type = request.getParameter("o_Type");
		String o_Status = request.getParameter("o_Status");
		String o_AdminID = request.getParameter("o_AdminID");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Opinion = request.getParameter("o_Opinion");
		String o_UseDays = request.getParameter("o_UseDays");
		String o_SignRadio = request.getParameter("o_SignRadio");
		String o_status = "";
		if(null==o_UseDays) {o_UseDays="";}
		
		if(!"3".equals(o_Status) && !"4".equals(o_Status))
		{
			return "只允许重新发起被驳回和已撤回的订单";
			//throw new Exception("只允许重新发起被驳回和已撤回的订单");
		}
		
		if(null!=o_CreateDate && !"".equals(o_CreateDate)) 
		{
			o_CreateDate = o_CreateDate.substring(0, 10)+" 00:00:00";
		}
		
		int cnt = 0;
		if("".equals(o_UseDays)) 
		{
			cnt = Sqlca.updateObject("update t_order set o_Status='2',o_EndDate=?,o_CreateDate=?,o_Product=?,"
					+ " o_MaxUserCount=?,o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=?,o_SignRadio="+o_SignRadio
					+ " where id=?", 
					new String[] {o_EndDate,o_CreateDate,o_Product,o_MaxUserCount,createUser,o_Remark,id});
		}
		else
		{
			if("1".equals(o_Type))
			{
				String times = CalcTimes(request,response,session);
				int cs = Integer.parseInt(times);
				if(cs==0)
				{
					cnt = Sqlca.updateObject("update t_order set o_Status='2',o_EndDate=?,o_CreateDate=?,o_UseDays=?,o_Product=?,"
							+ " o_MaxUserCount=?,o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=?,o_SignRadio="+o_SignRadio
							+ " where id=?", 
							new String[] {o_EndDate,o_CreateDate,o_UseDays,o_Product,o_MaxUserCount,createUser,o_Remark,id});
				}
				else
				{
					int d = Integer.parseInt(o_UseDays);
					if(d<=15)
					{
//						String dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
						String dd = DateUtil.dateFormat("yyyy-MM-dd HH:mm:ss");
						if(o_CreateDate.compareTo(dd)<=0)
					    {
					    	o_status="1";
					    }
						else
						{
							o_status = "8";
						}
						
					}
					else
					{
						o_status = "2";
					}
					cnt = Sqlca.updateObject("update t_order set o_Status='"+o_status+"',o_EndDate=?,o_CreateDate=?,o_UseDays=?,o_Product=?,"
							+ " o_MaxUserCount=?,o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=?,o_SignRadio="+o_SignRadio
							+ " where id=?", 
							new String[] {o_EndDate,o_CreateDate,o_UseDays,o_Product,o_MaxUserCount,createUser,o_Remark,id});
				}
			}
			
			if("3".equals(o_Type))
			{
				String times = CalcTempTimes(request,response,session);
				int cs = Integer.parseInt(times);
				if(cs==0)
				{
					cnt = Sqlca.updateObject("update t_order set o_Status='2',o_EndDate=?,o_CreateDate=?,o_UseDays=?,o_Product=?,"
							+ " o_MaxUserCount=?,o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=?,o_SignRadio="+o_SignRadio
							+ " where id=?", 
							new String[] {o_EndDate,o_CreateDate,o_UseDays,o_Product,o_MaxUserCount,createUser,o_Remark,id});
				}
				else
				{
					int d = Integer.parseInt(o_UseDays);
					if(d<=15)
					{
//						String dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
						String dd = DateUtil.dateFormat("yyyy-MM-dd HH:mm:ss");
						
						if(o_CreateDate.compareTo(dd)<=0)
					    {
					    	o_status="1";
					    }
						else
						{
							o_status = "8";
						}
						
					}
					else
					{
						o_status = "2";
					}
					cnt = Sqlca.updateObject("update t_order set o_Status='"+o_status+"',o_EndDate=?,o_CreateDate=?,o_UseDays=?,o_Product=?,"
							+ " o_MaxUserCount=?,o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=?,o_SignRadio="+o_SignRadio
							+ " where id=?", 
							new String[] {o_EndDate,o_CreateDate,o_UseDays,o_Product,o_MaxUserCount,createUser,o_Remark,id});
				}
			}
			
		}
		
		//Sqlca.updateObject("update t_compinfo t set t.productId=? where t.CompID=?", new String[] {o_Product,o_CompID});
		
		return "success";
	}
	
	
	@RequestMapping(value="/OverOrder.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String OverOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String id = request.getParameter("id");
		String o_Type = request.getParameter("o_Type");
		String o_Status = request.getParameter("o_Status");
		String o_AdminID = request.getParameter("o_AdminID");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Opinion = request.getParameter("o_Opinion");
		String o_SignRadio = request.getParameter("o_SignRadio");
		
		if("2".equals(o_Status))
		{
			return "待审核订单不可结束,请先撤回或驳回该订单";
		}
		if("5".equals(o_Status))
		{
			return "该订单已是结束状态";
		}
		if("7".equals(o_Status))
		{
			return "该订单处于暂停状态,请先结束临时订单";
		}
		
		
		if("1".equals(o_Type))
		{
			String minenddate = Sqlca.getString("select min(o_EndDate) from t_order where o_CompID="+o_CompID+" and o_Status=1 and id<>"+id);
			if(minenddate==null) {minenddate="";}
			String current = DateUtil.getDateYMD(DateUtil.dateFormat(-1, 0) , "23:59:59");
			if("1".equals(o_Status))
			{
				Sqlca.updateObject("update t_compinfo t set t.EndDate=(CASE WHEN '"+minenddate+"' = '' THEN (CASE WHEN ContractEndTime IS NULL THEN '"+current+"' ELSE EndDate END) ELSE '"+minenddate+"' END) where t.CompID=?", new String[] {o_CompID});
			}
			if("8".equals(o_Status))
			{
//				String EndDate = Sqlca.getString("select EndDate from t_validbill where CompID="+o_CompID+" and BillType='single' ORDER BY ID DESC LIMIT 1");
//				if(null!=EndDate && !"".equals(EndDate))
//				{
					Sqlca.updateObject("update t_compinfo set EndDate=(CASE WHEN '"+minenddate+"' = '' THEN (CASE WHEN ContractEndTime IS NULL THEN '"+current+"' ELSE EndDate END) ELSE '"+minenddate+"' END) where CompID=?", new String[] {o_CompID});
//				}
			}
			CommonInterface.UpdateCompStatus(o_CompID);
		}
		if("2".equals(o_Type))
		{
			String minenddate = Sqlca.getString("select min(o_EndDate) from t_order where o_CompID="+o_CompID+" and o_Status=1 and id<>"+id);
			if(minenddate==null) {minenddate="";}
			String current = DateUtil.getDateYMD(DateUtil.dateFormat(-1, 0), "23:59:59");
			if("1".equals(o_Status))
			{
//				Sqlca.updateObject("update t_order set o_Status='5',"
//						+ "o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=? where id=?", 
//						new String[] {createUser,o_Remark,id});
				
				Sqlca.updateObject("update t_compinfo t set t.EndDate='"+current+"' where t.CompID=?", new String[] {o_CompID});
				
//				CommonInterface.OverSignOrderUsing(o_CompID, id);
//				CommonInterface.UpdateCompStatus(o_CompID);
				
			}
			if("8".equals(o_Status))
			{
				
//				String EndDate = Sqlca.getString("select EndDate from t_validbill where CompID="+o_CompID+" and BillType='single' ORDER BY ID DESC LIMIT 1");
//				if(null!=EndDate && !"".equals(EndDate))
//				{
					Sqlca.updateObject("update t_compinfo set EndDate=(CASE WHEN '"+minenddate+"' = '' THEN EndDate ELSE '"+minenddate+"' END) where CompID=?", new String[] {o_CompID});
//				}
			}
			CommonInterface.UpdateCompStatus(o_CompID);
		}
		if("3".equals(o_Type))
		{
			if("1".equals(o_Status))
			{
				String minenddate = Sqlca.getString("select min(o_EndDate) from t_order where o_CompID="+o_CompID+" and o_Status=1 and id<>"+id);
				if(minenddate==null) {minenddate="";}
				
				String sign2 = Sqlca.getString("select o_CompID from t_order where o_CompID="+o_CompID+" and o_Type=2 and o_Status=1 and o_SignRadio=2");
				String sign3 = Sqlca.getString("select id from t_order where id="+id+" and o_Type=3 and (select max(o_CreateDate)"
						+ " from t_order where o_CompID="+o_CompID+" and o_Status=1 and o_SignRadio=3) BETWEEN o_CreateDate and o_EndDate");
				
				if(null!=sign2)
				{
					Sqlca.updateObject("update t_compinfo t set MaxUserCount=MaxUserCount-"+o_MaxUserCount+",EndDate=(CASE WHEN '"+minenddate+"' = '' THEN ContractEndTime ELSE '"+minenddate+"' END) where t.CompID=?", new String[] {o_CompID});	
				}
				else if(null!=sign3) 
				{
					Sqlca.updateObject("update t_compinfo t set EndDate=(CASE WHEN '"+minenddate+"' = '' THEN ContractEndTime ELSE '"+minenddate+"' END) where t.CompID=?", new String[] {o_CompID});
				}
				else
				{
//					String MaxUserCount = Sqlca.getString("select max(MaxUserCount) from t_validbill where EndDate<>'2099-01-01 23:59:59' and OrderID="+id);
//					if(MaxUserCount!=null && !"".equals(MaxUserCount))
//					{
//						Sqlca.updateObject("update t_compinfo t set MaxUserCount=MaxUserCount-"+MaxUserCount+",t.EndDate=(CASE WHEN '"+minenddate+"' = '' THEN t.EndDate ELSE '"+minenddate+"' END) where t.CompID=?", new String[] {o_CompID});
//					}
					String current = DateUtil.getDateYMD(DateUtil.dateFormat(-1, 0), "23:59:59");
					String CompMaxUserCount = Sqlca.getString("select CompMaxUserCount from t_validbill where CompID="+o_CompID+" ORDER BY ID DESC LIMIT 1");
					if(CompMaxUserCount!=null && !"".equals(CompMaxUserCount))
					{
						Sqlca.updateObject("update t_compinfo t set MaxUserCount="+CompMaxUserCount+",t.EndDate=(CASE WHEN '"+minenddate+"' = '' THEN t.EndDate ELSE '"+minenddate+"' END) where t.CompID=?", new String[] {o_CompID});
					}
				}
				Sqlca.updateObject("update t_validbill set EndDate='2099-01-01 23:59:59' where OrderID=?", new String[] {id});
			}
			if("8".equals(o_Status))
			{
				String minenddate = Sqlca.getString("select min(o_EndDate) from t_order where o_CompID="+o_CompID+" and o_Status=1 and id<>"+id);
				if(minenddate==null) {minenddate="";}
				
//				String EndDate = Sqlca.getString("select EndDate from t_validbill where CompID="+o_CompID+" and BillType='single' ORDER BY ID DESC LIMIT 1");
//				if(null!=EndDate && !"".equals(EndDate))
//				{
					Sqlca.updateObject("update t_compinfo set EndDate=(CASE WHEN '"+minenddate+"' = '' THEN EndDate ELSE '"+minenddate+"' END) where CompID=?", new String[] {o_CompID});
//				}
			}
			CommonInterface.UpdateCompStatus(o_CompID,0);
		}
			
		Sqlca.updateObject("update t_order set o_Status='5',"
				+ "o_UpdateTime=SYSDATE(),o_UpdateUser=?,o_Remark=? where id=?", 
				new String[] {createUser,o_Remark,id});
		return "success";
	}
	
	@RequestMapping(value="/AddTryOrderSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddTryOrderSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		String role = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			role = admin.getRole();
		}
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_UseDays = request.getParameter("o_UseDays");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_UseTimes = request.getParameter("o_UseTimes");
		String o_Remark = request.getParameter("o_Remark");
		String o_status = "8";
		adminid = Sqlca.getString("select t.AdminID from t_compinfo t where t.CompID='"+o_CompID+"'");
		String dd = DateUtil.dateFormat("yyyy-MM-dd HH:mm:ss");
		if(null!=o_CreateDate && !"".equals(o_CreateDate)) 
		{
			o_CreateDate = o_CreateDate.substring(0, 10)+" 00:00:00";
		}
		if(null!=o_EndDate && !"".equals(o_EndDate))
		{
			o_EndDate = o_EndDate.substring(0, 10)+" 23:59:59";
		}
		
	    if(o_CreateDate.compareTo(dd)<=0)
	    {
	    	o_status="1";
	    }
		String s1 = Sqlca.getString("select id from t_order where " + 
				" o_Status in('2','3','4','8') and o_Type='1' and o_CompID='"+o_CompID+"'");
		if(s1!=null && !"".equals(s1))
		{
			return "已存在一个正在处理的试用订单,请先处理该订单";
		}
		
		String s2 = Sqlca.getString("select id from t_order where " + 
				" o_Type='1' and o_CompID='"+o_CompID+"'");
		if(s2!=null && !"".equals(s2))
		{
			return "该客户已在客户管理中维护,请在客户管理中处理(延期/更换产品等)";
		}
		
		int d = Integer.parseInt(o_UseDays);
		if(d>15)
		{
			o_status = "2";
		}
		int t = Integer.parseInt(o_UseTimes);
		if(t<=0)
		{
			o_status = "2";
		}
		//创建试用订单创建会议室 begin
		String comp = Sqlca.getString(" SELECT o_CompName FROM t_order WHERE o_CompID ='"+o_CompID+"'")==null?"":Sqlca.getString(" SELECT o_CompName FROM t_order WHERE o_CompID ='"+o_CompID+"'");
		String compTrueName = Sqlca.getString(" SELECT CompTrueName from t_compinfo WHERE compId = '"+o_CompID+"' ");
		String server = Sqlca.getString("select t.defualtServer from t_compinfo t where t.CompID='"+o_CompID+"'");
		
		String serverid ="";
		if(!server.equals(null)&&!server.equals("")) {
			serverid= server;
		}else {
			serverid="27";
		}
		String meetingName = compTrueName+"的会议室";
		String addmeetSql ="INSERT INTO t_confinfo(Codeno,ConfName,ConfPwd,IsReservedConf,IsOnOff,MaxUserCount,ProductType,IsPublic,CompID,IsAll,AdminID,ServerId) VALUES(0,?,?,?,?,?,?,?,?,?,0,?)";
		if(comp.equals("")) {
			Sqlca.updateObject(addmeetSql, new String[] {meetingName,"123456","0","1",o_MaxUserCount,o_Product,"1",o_CompID,"1",serverid});
		}
		//创建试用订单创建会议室 begin end
		
		
		String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount,o_UseDays," + 
				" o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_createTime,o_createUser,o_AdminID)" + 
				" VALUES(?,'1',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,?,?,SYSDATE(),?,?)";
		int cnt = Sqlca.updateObject(insertOrder, new String[] {o_status,o_CompID,o_CompID,o_Product,o_MaxUserCount,o_UseDays,
				o_CreateDate,o_EndDate,o_UseTimes,o_Remark,createUser,adminid});
		String orderid = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
	
		if(cnt>0) {
			if("1".equals(o_status))
			{
				//1.生成单据(普通单据、叠加单据)
				CommonInterface.GenerateBillRecord(orderid);
				//2单据生效
				CommonInterface.UpdateStatusUsing(orderid);
				//3更新客户状态
				CommonInterface.UpdateCompStatus(o_CompID);
			}
			
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/AddSignOrderSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddSignOrderSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		String adminid = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Style = request.getParameter("o_Style");
		
		String o_status = "2";
		adminid = Sqlca.getString("select t.AdminID from t_compinfo t where t.CompID='"+o_CompID+"'");
		if(null!=o_CreateDate && !"".equals(o_CreateDate)) 
		{
			o_CreateDate = o_CreateDate.substring(0, 10)+" 00:00:00";
		}
		if(null!=o_EndDate && !"".equals(o_EndDate))
		{
			o_EndDate = o_EndDate.substring(0, 10)+" 23:59:59";
		}
		
//		String s1 = Sqlca.getString("select id from t_order where " + 
//				" o_Status in('2','3','4','6') and o_Type='2' and o_CompID='"+o_CompID+"' and o_Product='"+o_Product+"'");
//		if(s1!=null && !"".equals(s1))
//		{
//			return "已存在一个正在处理的签约订单,请先处理该订单";
//		}
		
		String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount," + 
				" o_CreateDate,o_EndDate,o_Remark,o_createTime,o_createUser,o_AdminID,o_Style)" + 
				" VALUES('"+o_status+"','2',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,SYSDATE(),?,?,?)";
		int cnt = Sqlca.updateObject(insertOrder, new String[] {o_CompID,o_CompID,o_Product,o_MaxUserCount,
				o_CreateDate,o_EndDate,o_Remark,createUser,adminid,o_Style});
		if(cnt>0) 
		{
			Sqlca.updateObject("update t_compinfo set compStyle=? where CompID=?", new String[] {o_Style,o_CompID});
			
			return "success";
		}
		return "fail";
	}
	
	
	@RequestMapping(value="/AddSignOrderApp",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddSignOrderApp(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		String adminid = "";
		String o_CompID = request.getParameter("o_CompID");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String createUser = request.getParameter("o_createUser");
		String o_Amount = request.getParameter("o_Amount");
		if(createUser==null) {createUser="";}
		if(o_Amount==null) {o_Amount="0";}
		String o_Remark = "";
		
		String ra = request.getRemoteAddr();
		logger.info("AddSignOrderApp:RemoteAddr="+ra+"|CompID="+o_CompID+"|MaxUserCount="+o_MaxUserCount+"|createUser="+createUser);
		String allowip = Sqlca.getString("select opid from t_option where op_param='allowipaccessboss' and op_bak1='"+ra+"'");
		if(allowip==null) 
		{
			return "fail";
		}
		
		String payid = request.getParameter("payid");
		
		String pay_id = Sqlca.getString("select pay_id from t_payment_record where pay_id='"+payid+"' and orderState='0'");
		if(pay_id==null)
		{
			return "fail";
		}
		
		adminid = Sqlca.getString("select t.AdminID from t_compinfo t where t.CompID='"+o_CompID+"'");
		String o_CreateDate = DateUtil.dateFormat(0)+" 00:00:00";
		String o_EndDate = DateUtil.dateFormat(DateUtil.dateFormat(12), 1)+" 23:59:59";
		
		

		String o_Product = Sqlca.getString("select productID from t_compinfo where CompID="+o_CompID);
		
		String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount," + 
				" o_CreateDate,o_EndDate,o_Remark,o_createTime,o_createUser,o_AdminID,o_Style,o_SignRadio,o_Amount)" + 
				" VALUES('1','2',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,SYSDATE(),?,?,?,?,"+o_Amount+")";
		int cnt = Sqlca.updateObject(insertOrder, new String[] {o_CompID,o_CompID,o_Product,o_MaxUserCount,
				o_CreateDate,o_EndDate,o_Remark,"admin",adminid,"2","2"});
		
		Sqlca.updateObject("update t_payment_record set orderState=1 where pay_id=?", new String[] {payid});
		
		String id = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
		if(cnt>0) 
		{
			//Sqlca.updateObject("update t_compinfo set compStyle=? where CompID=?", new String[] {"2",o_CompID});
			//1.生成单据(普通单据、叠加单据)
			CommonInterface.GenerateBillRecord(id);
			//2单据生效
			CommonInterface.UpdateStatusUsing(id);
			//3更新客户状态
			CommonInterface.UpdateCompStatus(o_CompID);
			
			return "success";
		}
		return "fail";
	}
	
	
	
	@RequestMapping(value="/PassOrder.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String PassOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String id = request.getParameter("id");
		String o_Type = request.getParameter("o_Type");
		String o_Status = request.getParameter("o_Status");
		String o_AdminID = request.getParameter("o_AdminID");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Opinion = request.getParameter("o_Opinion");
		String o_Style = request.getParameter("o_Style");
		String o_SignRadio = request.getParameter("o_SignRadio");
		if(o_SignRadio==null) {o_SignRadio="";}
		
		if("5".equals(o_Status)) 
		{
			return "该订单已结束";
//			throw new Exception("该订单已结束");
		}
		
		if(!"2".equals(o_Status)) 
		{
			return "该订单非待审批状态,需先提交审批";
//			throw new Exception("该订单非待审批状态,需先提交审批");
		}
		
		if("2".equals(o_SignRadio))
		{
			String ContractEndTime = Sqlca.getString("select ContractEndTime from t_compinfo where CompID="+o_CompID);
			String currentdate = DateUtil.dateFormat("yyyy-MM-dd HH:mm:ss");
			if(currentdate.compareTo(ContractEndTime)>0)
			{
				return "该客户合约已过期,不能'扩点签约'请做'扩点变更'";
			}
		}
		
		
	    String dd=DateUtil.dateFormat("yyyy-MM-dd HH:mm:ss");
	    if(o_CreateDate.compareTo(dd)<=0)
	    {
	    	o_Status="1";
	    }
	    else
	    {
	    	o_Status="8";
	    }
		
		int cnt =Sqlca.updateObject("update t_order set o_Status=?,o_ApproveID=?,o_Opinion=? where id=?", new String[] {o_Status,createUser,o_Opinion,id});
		if(cnt>0) 
		{
			if("1".equals(o_Type))
			{
				if("1".equals(o_Status))
				{
					//1.生成单据(普通单据、叠加单据)
					CommonInterface.GenerateBillRecord(id);
					//2单据生效
					CommonInterface.UpdateStatusUsing(id);
					//3更新客户状态
					CommonInterface.UpdateCompStatus(o_CompID);
				}
			}
			if("2".equals(o_Type))
			{
				if("2".equals(o_Style)) 
				{
					Sqlca.updateObject("update t_compinfo set AdminID=0 where CompID=? and compStyle=2 and (allocatAdmin is null or allocatAdmin='0')", new String[] {o_CompID});
				}
				
				if("8".equals(o_Status) && "1".equals(o_SignRadio))
				{
					Sqlca.updateObject("update t_compinfo set ContractEndTime='"+o_EndDate+"' where CompID=?", new String[] {o_CompID});
				}
				
				if("1".equals(o_Status))
				{
					Sqlca.updateObject("update t_order set o_Status=5 where o_Type=1 and o_CompID=?", new String[] {o_CompID});
					//1.生成单据(普通单据、叠加单据)
					CommonInterface.GenerateBillRecord(id);
					//2单据生效
					CommonInterface.UpdateStatusUsing(id);
					//3更新客户状态
					CommonInterface.UpdateCompStatus(o_CompID);
				}
			}
			if("3".equals(o_Type))
			{
				if("1".equals(o_Status))
				{
					//1.生成单据(普通单据、叠加单据)
					CommonInterface.GenerateBillRecord(id);
					//2单据生效
					CommonInterface.UpdateStatusUsing(id);
					//3更新客户状态
					CommonInterface.UpdateCompStatus(o_CompID,"10");
				}
			}
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/TurnOrder.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String TurnOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
		}
		String id = request.getParameter("id");
		String o_Type = request.getParameter("o_Type");
		String o_Status = request.getParameter("o_Status");
		String o_AdminID = request.getParameter("o_AdminID");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_MaxUserCount = request.getParameter("o_MaxUserCount");
		String o_CreateDate = request.getParameter("o_CreateDate");
		String o_EndDate = request.getParameter("o_EndDate");
		String o_Remark = request.getParameter("o_Remark");
		String o_Opinion = request.getParameter("o_Opinion");
		
		if("5".equals(o_Status)) 
		{
			return "该订单已结束";
			//throw new Exception("该订单已结束");
		}
		if(!"2".equals(o_Status))
		{
			return "只允许驳回待审核的订单";
			//throw new Exception("只允许驳回待审核的订单");
		}
		
		int cnt =Sqlca.updateObject("update t_order set o_Status='3',o_ApproveID=?,o_Opinion=? where id=?", new String[] {createUser,o_Opinion,id});
	
		if(cnt>0) {
			Sqlca.updateObject(" insert into t_flow(flow,flowName,phaseNo,phaseName,createDate,oppinoin,createUser)"+
					" values (?,(select op_display from t_option where op_param='orderType' and op_value=?),"
					+ "?,(select op_display from t_option where op_param='approveStatus' and op_value=?),SYSDATE(),?,?)", 
					new String[] {id,o_Type,"3","3",o_Opinion,createUser});
			
			
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/CalcTimes.do")
	@ResponseBody
	public String CalcTimes(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String role = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			role = admin.getRole();
		}
		String o_Product = request.getParameter("o_Product");
		String o_CompID = request.getParameter("o_CompID");
		String o_Type = request.getParameter("o_Type");
		String times = "select count(*) as cnt from t_order where o_CompID='"+o_CompID+"' and o_Product='"+o_Product+"' and o_Type='1' " + 
				" and o_Status in('1','2','3','4','5','8','7')";
		String usetimes = Sqlca.getString("select usetimes from t_roles where role_id='"+role+"'");
		String currtimes = Sqlca.getString(times);
		int cs = Integer.parseInt(usetimes)-Integer.parseInt(currtimes);
		if(cs<0) {cs=0;}
		return String.valueOf(cs);
	}
	
	@RequestMapping(value="/CalcTempTimes.do")
	@ResponseBody
	public String CalcTempTimes(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		Object obj = session.getAttribute("USER_SESSION");
		String role = "";
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			role = admin.getRole();
		}
		String o_Product = request.getParameter("o_Product");
		String o_CompID = request.getParameter("o_CompID");
		String o_Type = request.getParameter("o_Type");
		String times = "select count(*) as cnt from t_order where o_CompID='"+o_CompID+"' and o_Product='"+o_Product+"' and o_Type='3' " + 
				" and o_Status in('1','2','3','4','5','8','7')";
		String usetimes = Sqlca.getString("select usetimestemp from t_roles where role_id='"+role+"'");
		String currtimes = Sqlca.getString(times);
		int cs = Integer.parseInt(usetimes)-Integer.parseInt(currtimes);
		if(cs<0) {cs=0;}
		return String.valueOf(cs);
	}
	
}
