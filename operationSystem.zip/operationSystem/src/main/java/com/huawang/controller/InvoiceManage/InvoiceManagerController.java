package com.huawang.controller.InvoiceManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Invoice")
public class InvoiceManagerController 
{
	
	@RequestMapping(value="/InvoiceManager")
	public ModelAndView DeviceManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("invoice/InvoiceList");
		
		return view;
	}
	
	@RequestMapping(value="ShowInvoice")
	@ResponseBody
	public ModelAndView ShowInvoice(HttpServletRequest request) throws Exception 
	{
		String otId = request.getParameter("otId");
		
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap("select otid,CompID,compName,compTrueName,money,state,createTime,ticketType,"
				+ " ticketName,taxNumber,displayName,userPhone,address,productName,applyTime,remark,handleUser from t_order_ticket where otId="+otId);
		
		ArrayList<Map<String, Object>> tax = Sqlca.getArrayListFromMap("select id,otid,ticketer,ticketStatus,taxNumber,createTime,remark from t_ticket_record where otId="+otId);
		ModelAndView view = new ModelAndView("invoice/InvoiceDetail");
		view.addObject("invoice", mm.get(0));
		if(tax.size()>0) 
		{
			view.addObject("tax", tax.get(0));
		}
		return view;
	}
	
	@RequestMapping(value="InvoiceUpSubmit")
	@ResponseBody
	public String InvoiceUpSubmit(HttpServletRequest request,HttpSession session) throws Exception
	{
		String adminname = "";
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			adminname = a.getAdminName();
		}
		String otId = request.getParameter("otId");
		String state = request.getParameter("state");
		String remark = request.getParameter("remark");
		
		String taxNumber = Sqlca.getString("select taxNumber from t_order_ticket where otId="+otId);
		String currdate = DateUtil.dateFormat();
		
		String sql = "insert into t_ticket_record(otid,ticketer,ticketStatus,taxNumber,createTime,remark)" + 
					 " values(?,?,?,?,?,?)";
		
		Sqlca.updateObject(sql, new String[] {otId,adminname,state,taxNumber,currdate,remark});
		
		Sqlca.updateObject("update t_order_ticket set state=? where otId=?", new String[] {state,otId});
		return "success";
	}
	
	@RequestMapping(value="getTimeOrderList")
	@ResponseBody
	public Map<String,Object> getTimeOrderList(HttpServletRequest request) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		
		String CompID = request.getParameter("CompID");
		String sellType = request.getParameter("sellType");
		
		
		String sql = "select prId,pay_id,payType,state,createTime,sellType,amount,packageCode,maxUserCount,oaCode,compid from t_payment_record where sellType=1 and compid="+CompID;
		
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		reMap.put("rows", list);
		return reMap;
	}
	
	@RequestMapping(value="selectInvoiceList")
	@ResponseBody
	public Map<String,Object> selectInvoiceList(HttpServletRequest request) throws Exception
	{
		String CompTrueName = request.getParameter("CompTrueName");
		String state = request.getParameter("state");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select otId,CompID,compName,compTrueName,money,state,createTime,otId as opid from t_order_ticket where 1=1 ";
		
		String sqlTotal = "select count(*) from t_order_ticket where 1=1 ";
		
		if(!"".equals(CompTrueName) && CompTrueName!=null) {
			sql+= " and CompTrueName like '%"+CompTrueName+"%'";
			sqlTotal+= " and CompTrueName like '%"+CompTrueName+"%'";
		}
		
		if(!"".equals(state) && state!=null) {
			sql+= " and state = '"+state+"'";
			sqlTotal+= " and state = '"+state+"'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
