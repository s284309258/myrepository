package com.huawang.controller.UserLogin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.huawang.dao.UserLogin.UserLoginDao;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;
 

@Controller
@RequestMapping(value="/loginhw")
public class LoginController{

	static Logger logger = LogManager.getLogger(LoginController.class.getName());
	HashMap<String, String> loginMap = new HashMap<String,String>();
	
	@Autowired
	private UserLoginDao userDao;
	
	@RequestMapping(value="/checkUserLogin",method=RequestMethod.POST)
	public ModelAndView checkUserLogin(TAdmininfo admininfo,HttpServletRequest request, HttpServletResponse response) throws Exception{
		String pwd = SecurityUtil.encryptMD5(admininfo.getAdminPassword());
		admininfo.setAdminPassword(pwd);
		boolean flag  = userDao.userLogin(admininfo);
		String pyzm = (String)request.getSession().getAttribute("ccode");
		String checkcode = request.getParameter("checkcode");
		System.out.println("验证码："+pyzm);
		String message ="";
		if(flag==false) {
			 message="1";
		}else if(!pyzm.equals(checkcode)){
			 message="2";
		}else {
			message="3";
		}
		JSONObject json = new JSONObject();
		json.put("message", message);
		response.getWriter().write(json.toString());
		response.getWriter().flush();
		response.getWriter().close();
		return null;
	} 
	
	@RequestMapping(value="/userLogin",method=RequestMethod.POST)
	public String userLogin(TAdmininfo admininfo,HttpSession session,HttpServletRequest request, HttpServletResponse response,Model model) throws Exception {
		
		ArrayList<Map<String, Object>> arraylist  = queryUserRight(admininfo);
		logger.info("LoginController: arraylist->"+arraylist);
		
		model.addAttribute("menuList", arraylist);
		/***单点登录用application控制，功能跳转用aop实现 begin***/
		loginMap.put(admininfo.getAdminName(), session.getId());
		session.getServletContext().setAttribute("loginMap", loginMap);
		session.setAttribute("USER_SESSION",admininfo);
		session.setAttribute("user_funs",admininfo.getFn());
		/***单点登录用application控制，功能跳转用aop实现 end***/
		return "index/index";
	}
	
	public ArrayList<Map<String, Object>> queryUserRight(TAdmininfo admininfo) throws Exception {
		
		if(admininfo.getAdminName()!=null && admininfo.getAdminPassword()!=null) {
			//MD5加密和其他系统加密方式保持一致
			String pwd = SecurityUtil.encryptMD5(admininfo.getAdminPassword());
			admininfo.setAdminPassword(pwd);
			logger.info("LoginController: pwd->"+pwd);
			ArrayList<Map<String, Object>> userArray = Sqlca.getArrayListFromMap("select AdminID,roles,dpid,admintruename,adminisSuper,email,sex,contact,parentid from t_admininfo "
					+ "where AdminName='"+admininfo.getAdminName()+"' and AdminPassword='"+admininfo.getAdminPassword()+"'");
			logger.info("LoginController: userArray->"+userArray);
			
			ArrayList<Map<String,Object>> arraylist = null;
			
			if(userArray!=null && userArray.size()>0) {
				
				String sql = "select t_menus.menu_id as mid,t_menus.menu_name as title,t_menus.menu_icon as icon,t_menus.menu_url as href " + 
						"					from t_menus,t_role_menu,t_admininfo " + 
						"					 where t_menus.menu_id=t_role_menu.menu_id " + 
						"					 and t_role_menu.role_id=t_admininfo.roles " + 
						"					 and t_menus.menu_parent_id='0' " + 
						"					 and t_admininfo.AdminName='"+admininfo.getAdminName()+"' and t_role_menu.isuse='1' order by t_menus.mid";
				arraylist = Sqlca.getArrayListFromMap(sql);
				for (Map<String,Object> m : arraylist) {
					String id = (String)m.get("mid");
					String menuSql = " select t1.mid,t1.title,t1.icon,t1.href from                                                        "+
							" (                                                                                                           "+
							" select tm.menu_id as mid,tm.menu_name as title,tm.menu_icon as icon,tm.menu_url as href,tm.mid as omid                     "+
							" 						 from t_menus tm,t_role_menu trm where tm.menu_parent_id=trm.menu_id                  "+
							" 						 and trm.menu_id='"+id+"' and trm.role_id='"+userArray.get(0).get("roles")+"'         "+
							" ) t1,t_role_menu where t1.mid=t_role_menu.menu_id and t_role_menu.isuse='1' and t_role_menu.role_id='"+userArray.get(0).get("roles")+"'  order by t1.omid asc";
					ArrayList<Map<String, Object>> arr = Sqlca.getArrayListFromMap(menuSql);
					m.put("children", arr);
				}
				StringBuffer bf = new StringBuffer();
				ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap("select role_id,menu_id,bak1 from t_role_menu where role_id='"+userArray.get(0).get("roles")+"'");
				for(Map<String,Object> m : list) {
					if(m.get("bak1")!=null && !"".equals(m.get("bak1"))) 
					{
						bf.append((String)m.get("bak1")).append("_");
					}
					
				}
				admininfo.setAdminId(Integer.parseInt((String)userArray.get(0).get("AdminID")));
				admininfo.setAdminTrueName((String)userArray.get(0).get("admintruename"));
				admininfo.setAdminIsSuper((String)userArray.get(0).get("adminisSuper"));
				admininfo.setEmail((String)userArray.get(0).get("email"));
				admininfo.setSex((String)userArray.get(0).get("sex"));
				admininfo.setContact((String)userArray.get(0).get("contact"));
				admininfo.setRole((String)userArray.get(0).get("roles"));
				admininfo.setDpId((String)userArray.get(0).get("dpid"));
				admininfo.setFn(bf.toString());
			}
			
			
			logger.info("LoginController: arraylist->"+arraylist);
			return arraylist;
		}
		return null;
		
	}
	
	@RequestMapping(value="/userLoginOut")
	public void userLoginOut(HttpServletRequest request, HttpServletResponse response,HttpSession session,Model model) throws Exception {
		Object obj = session.getAttribute("USER_SESSION");
		TAdmininfo user = null;
        if(obj!=null) {
      	   user = (TAdmininfo)obj;
      	   String userName = user.getAdminName();
      	   ServletContext application = session.getServletContext();
           Map<String,String> loginMap = (Map<String,String>)application.getAttribute("loginMap");
           loginMap.remove(userName);
        }
        session.invalidate();
        logger.info("userLoginOut->redirect:"+request.getContextPath());
        response.sendRedirect("/");
	}
 
}
