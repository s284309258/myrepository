package com.huawang.controller.deviceManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.controller.saleManage.TimeOrderManagerController;
import com.huawang.util.CommonInterface;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Device")
public class DeviceManagerController 
{
	static Logger logger = LogManager.getLogger(DeviceManagerController.class.getName()); 
	
	@RequestMapping(value="/DeviceManager.do")
	public ModelAndView DeviceManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("device/DeviceList");
		
		return view;
	}
	
	
	@RequestMapping(value="/ModifyDeviceSubmit.do")
	@ResponseBody
	public String ModifyDeviceSubmit(HttpServletRequest request) throws Exception
	{
		String CompID = request.getParameter("CompID");
		String state = request.getParameter("state");
		String remark = request.getParameter("remark");
		String deviceId = request.getParameter("deviceId");
		
		String currDate = DateUtil.dateFormat();
		
		Sqlca.updateObject("update t_device_definition set CompID=?,state=?,CompTrueName=(select CompTrueName from t_compinfo where CompID=?),remark=?,updateTime=? where id=?", 
				new String[] {CompID,state,CompID,remark,currDate,deviceId});
		
		return "success";
	}
	
	@RequestMapping(value="/ModifyDeviceSubmit2.do")
	@ResponseBody
	public String ModifyDeviceSubmit2(HttpServletRequest request) throws Exception
	{
		String remark = request.getParameter("remark2");
		String deviceId = request.getParameter("deviceId");
		String deviceId2 = request.getParameter("deviceId2");
		
		String currDate = DateUtil.dateFormat();
		
		/*String str = Sqlca.getString("select deviceId from t_device_definition where deviceId='"+deviceId2+"'");
		
		if(str==null)
		{
			return "更换的设备不存在";
		}*/
		
		Sqlca.updateObject("update t_device_definition set deviceId=?,remark=?,updateTime=?,state=3 where id=?", 
				new String[] {deviceId2,remark,currDate,deviceId});
		
		return "success";
	}
	
	@RequestMapping(value="/ShowDevice.do")
	public ModelAndView ShowDevice(HttpServletRequest request) throws Exception
	{
		String deviceId = request.getParameter("deviceId");
		String id = request.getParameter("id");
		
		String sql = "select id,deviceId,deviceName,CompID,deviceModel,pinCode,CompTrueName,state,"
				+ " (select op_display from t_option where op_param='deviceStatus' and op_value=state) as deviceStatus,"
				+ " createTime,updateTime,price,createrId,createrName,deviceId as opid from t_device_definition where id="+id;
		
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap(sql);
		
		
		
		String historysql = "select createTime,createrId,state,remark,deviceModel,id,CompID,CompTrueName,deviceName from t_device_record where deviceId='"+deviceId+"'";
		
		ArrayList<Map<String, Object>> his = Sqlca.getArrayListFromMap(historysql);
		ModelAndView view = new ModelAndView("device/DeviceDetail");
		view.addObject("device", mm.get(0));
		view.addObject("his", his);
		return view;
	}
	
	
	@RequestMapping(value="/BindDevice")
	@ResponseBody
	public String BindDeivce(HttpServletRequest request) throws Exception
	{
		String CompID = request.getParameter("CompID");
		String Model = request.getParameter("Model");
		String DeviceName = request.getParameter("DeviceName");
		String pinCode = request.getParameter("PinCode");
		String deviceId = request.getParameter("DeviceId");
		
		
		String ra = request.getRemoteAddr();
		logger.info("BindDeivce:RemoteAddr="+ra+"|CompID="+CompID+"|Model="+Model+"|pinCode="+pinCode);
		String allowip = Sqlca.getString("select opid from t_option where op_param='allowipaccessboss' and op_bak1='"+ra+"'");
		if(allowip==null) 
		{
			return "fail";
		}
		
		
		String perOnePrice = Sqlca.getString("select perOnePrice from t_product_definition where ProductName='"+DeviceName+"'");
		
		if(perOnePrice==null || "".equals(perOnePrice)) {perOnePrice="0";}
		ArrayList<Map<String, Object>> pp =Sqlca.getArrayListFromMap("select productID,sellType,AdminID,CompTrueName from t_compinfo where CompID="+CompID);
		if(pp.size()>0) 
		{
			String productID = (String)pp.get(0).get("productID");
			String sellType = (String)pp.get(0).get("sellType");
			String AdminID = (String)pp.get(0).get("AdminID");
			String CompTrueName = (String)pp.get(0).get("CompTrueName");
			
			String sql = "";
			if("".equals(productID))
			{
				sql = "select freeProduct,freeMinute,freeTime,freeTimeUnit,freePoint,oa.otid,oa.oaCode from t_operation_activity oa, "
						+ " t_operation_template ot where oa.otid=ot.spid and oa.type=1 and now() BETWEEN oa.startTime and oa.endTime and oa.isuse=1 and oa.payProduct='"+Model+"'"
						+ " and freeProduct='"+productID+"'";
			}
			else
			{
				sql = "select freeProduct,freeMinute,freeTime,freeTimeUnit,freePoint,oa.otid,oa.oaCode from t_operation_activity oa, "
						+ " t_operation_template ot where oa.otid=ot.spid and oa.type=1 and now() BETWEEN oa.startTime and oa.endTime and oa.isuse=1 and oa.payProduct='"+Model+"'";
			}
			
			
			ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap(sql);
			if(mm.size()>0)
			{
				if("2".equals(sellType))
				 {
					 String freeTime = (String)mm.get(0).get("freeTime");
					 String freeTimeUnit = (String)mm.get(0).get("freeTimeUnit");
					 String freePoint = (String)mm.get(0).get("freePoint");
					 String o_EndDate = "";
					 String o_CreateDate = "";
					 
					 if("日".equals(freeTimeUnit))
					 {
						 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime), 0);
					 }
					 else if("月".equals(freeTimeUnit))
					 {
						 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime));
					 }
					 else if("年".equals(freeTimeUnit))
					 {
						 o_EndDate = DateUtil.dateFormat(Integer.parseInt(freeTime)*12);
					 }
					 o_CreateDate = DateUtil.dateFormat(0, 0)+" 00:00:00";
					 o_EndDate = o_EndDate+" 23:59:59";
					 String insertOrder="insert into t_order(o_Status,o_Type,o_CompID,o_CompName,o_Product,o_MaxUserCount," + 
								" o_CreateDate,o_EndDate,o_Remark,o_createTime,o_createUser,o_AdminID,o_Style,o_SignRadio)" + 
								" VALUES('1','2',?,(select CompTrueName from t_compinfo where CompID=?),?,?,?,?,?,SYSDATE(),?,?,?,?)";
						int cnt = Sqlca.updateObject(insertOrder, new String[] {CompID,CompID,productID,freePoint,
								o_CreateDate,o_EndDate,"","1","1","2","2"});
						
						String id = Sqlca.getString("select LAST_INSERT_ID() from t_order limit 1");
						if(cnt>0) 
						{
							//Sqlca.updateObject("update t_compinfo set compStyle=? where CompID=?", new String[] {"2",o_CompID});
							//1.生成单据(普通单据、叠加单据)
							CommonInterface.GenerateBillRecord(id);
							//2单据生效
							CommonInterface.UpdateStatusUsing(id);
							//3更新客户状态
							CommonInterface.UpdateCompStatus(CompID);
							
						}
				 }
				 else if("1".equals(sellType))
				 {
					 String oaCode = (String)mm.get(0).get("oaCode");
					 String freeMinute = (String)mm.get(0).get("freeMinute");
					 String insertOrder="insert into t_timeorder(o_Type,o_MaxUserCount,o_Product,o_Status,o_AdminID,"
								+ " o_CreateTime,o_CreateUser,o_CompID,o_CompName,o_sellType,o_amount,createtype,oaid,spid,o_totalTime,o_Style,o_Remark)"
								+ " values(? ,? ,? ,? ,? ,? ,? ,? ,?,?,?,?,?,?,?,?,'硬件设备激活')";
						Sqlca.updateObject(insertOrder, new String[] {"5","99999",productID,"1",AdminID,DateUtil.dateFormat(),"admin",CompID,CompTrueName,"1","0","1",oaCode,"",freeMinute,"2"});
						
					 Sqlca.updateObject("update t_compinfo set productID='"+productID+"',TolTimes=(TolTimes+'"+freeMinute+"'),MaxUserCount=99999 where CompID=?", new String[] {CompID});
				 }
			}
			
			String insertdevice = "insert into t_device_definition(deviceId,deviceName,state,pinCode,createTime,updateTime,compId,compTrueName,price,deviceModel,createrId,createrName,remark)" + 
					" values('"+deviceId+"','"+DeviceName+"',3,'"+pinCode+"',now(),now(),"+CompID+",'"+CompTrueName+"',"+perOnePrice+",'"+Model+"','1',?,?)";

			Sqlca.updateObject(insertdevice, new String[] {"超级管理员","终端设备激活"});

			String insertdevicerecord = "insert into t_device_record(deviceId,deviceName,comptruename,compid,createtime,createrid,creatername,state,remark,devicemodel) " + 
					" values('"+deviceId+"',"+DeviceName+"','"+CompTrueName+"',"+CompID+",now(),1,?,?,?,'"+Model+"')";

			Sqlca.updateObject(insertdevicerecord, new String[] {"超级管理员","新增","设备被激活"});
			
			return "success";
		}
		
		return "fail";
	}
	
	
	@RequestMapping(value="selectDeviceList")
	@ResponseBody
	public Map<String,Object> selectDeviceList(HttpServletRequest request) throws Exception
	{
		String CompTrueName = request.getParameter("CompTrueName");
		String state = request.getParameter("state");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select deviceId,deviceName,CompID,deviceModel,pinCode,CompTrueName,state,"
				+ " (select op_display from t_option where op_param='deviceStatus' and op_value=state) as deviceStatus,"
				+ " createTime,updateTime,price,createrId,createrName,id as opid from t_device_definition where 1=1 ";
		
		String sqlTotal = "select count(*) from t_device_definition where 1=1 ";
		
		if(!"".equals(CompTrueName) && CompTrueName!=null) {
			sql+= " and CompTrueName like '%"+CompTrueName+"%'";
			sqlTotal+= " and CompTrueName like '%"+CompTrueName+"%'";
		}
		
		if(!"".equals(state) && state!=null) {
			sql+= " and state = '"+state+"'";
			sqlTotal+= " and state = '"+state+"'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
