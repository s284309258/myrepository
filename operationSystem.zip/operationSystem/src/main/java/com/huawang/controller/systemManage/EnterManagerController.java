package com.huawang.controller.systemManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;
 
@Controller
@RequestMapping(value="/Enter")
public class EnterManagerController {

	@RequestMapping(value="EnterManager.do")
	public ModelAndView EnterManager()
	{
		ModelAndView view = new ModelAndView("system/EnterManager");
		return view;
	}
	
	@RequestMapping(value="EnterManagerQuery.do")
	@ResponseBody
	public Map<String,Object> EnterManagerQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		if("UserID".equals(SortName)) {SortName="CompID";}
		
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		Object obj = session.getAttribute("USER_SESSION");
		int aid = 99999;
		String roledata = "";
		String dpid = "";
		String createuser = "";
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			aid = a.getAdminId();
			String roleid = a.getRole();
			createuser = a.getAdminName();
			roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
			dpid = a.getDpId();
		}
		
		String sql = " select CompID as UserID,CompName as UserName,CompTrueName as DisplayName,isuse,"
				+ " compStyle,belongAgent,CreateDate as createtime from t_compinfo where 1=1 ";
		
		String sqlTotal = "select count(*) from t_compinfo where 1=1 ";
		
		if(!"".equals(UserName) && UserName!=null) {
			sql+= " and CompName like '%"+UserName+"%'";
			sqlTotal+= " and CompName like '%"+UserName+"%'";
		}
		if(!"".equals(DisplayName) && DisplayName!=null) {
			sql+= " and CompTrueName like '%"+DisplayName+"%'";
			sqlTotal+= " and CompTrueName like '%"+DisplayName+"%'";
		}
		
		if("1".equals(roledata))
		{
			
		}
		else if("2".equals(roledata))
		{
			sql += " and CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
			
			sqlTotal += " and CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
		}
		else if("3".equals(roledata)) 
		{
			sql += " and CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		
			sqlTotal += " and CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
//		sql += " LIMIT "+total+","+rows;

		HashMap<String,Object> reMap = new HashMap<String,Object>();
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	@RequestMapping(value="RestEnterPwd.do")
	@ResponseBody
	public String RestEnterPwd(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		String UserName = request.getParameter("UserName");
		String pwd = SecurityUtil.encryptMD5("888888");
		int cnt = Sqlca.updateObject("update t_userinfo set UserPassword=? where UserName=?", new String[] {pwd,UserName});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="MakeInvalid.do")
	@ResponseBody
	public String MakeInvalid(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		String UserName = request.getParameter("UserName");
		Sqlca.updateObject("update t_compinfo set isuse='0' where CompName=?", new String[] {UserName});
		int cnt = Sqlca.updateObject("update t_userinfo set isuse='0' where UserName=?", new String[] {UserName});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
}
