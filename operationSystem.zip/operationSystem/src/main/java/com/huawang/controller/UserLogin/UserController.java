package com.huawang.controller.UserLogin;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class UserController {

	static Logger logger = LogManager.getLogger(LoginController.class.getName());
	
	@RequestMapping(value="/searchUser")
	public ModelAndView searchUser() {
		ModelAndView view = new ModelAndView("UserManager");
		
		
		
		return view;
	}
}
