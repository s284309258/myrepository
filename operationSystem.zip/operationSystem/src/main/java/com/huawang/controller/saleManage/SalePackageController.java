package com.huawang.controller.saleManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Sale")
public class SalePackageController 
{
	@RequestMapping(value="/SalePackageManager.do")
	public ModelAndView SalePackManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/SalePackageList");
		
		return view;
	}
	
	@RequestMapping(value="/AddSalePackage.do")
	public ModelAndView AddSalePackage() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/AddSalePackage");
		
		return view;
	}
	
	@RequestMapping(value="/SalePackageShow.do")
	public ModelAndView SalePackageShow(@RequestParam("spid") String spid) throws Exception 
	{
		String spps = "";
		
		String sql = "select packageCode as spid,packageName,minuteCount,productId,packagePrice,remark,packageStatus,createrName,createTime,spid as pid from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String sql1 = "select productId from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap(sql1);
		for(Map<String,Object> ss : mm)
		{
			spps+=ss.get("productId")+"#";
		}
		spps = spps.substring(0, spps.length()-1);
		
		ModelAndView view = new ModelAndView("sale/SalePackageShow");
		view.addObject("sale",list.get(0));
		view.addObject("spps",spps);
		
		return view;
	}
	
	@RequestMapping(value="/ModifySalePackage.do")
	public ModelAndView ModifySalePackage(@RequestParam("spid") String spid) throws Exception {
		String spps = "";
		String sql = "select packageCode as spid,packageName,minuteCount,productId,packagePrice,remark,packageStatus,createTime,spid as pid from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String sql1 = "select productId from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap(sql1);
		for(Map<String,Object> ss : mm)
		{
			spps+=ss.get("productId")+"#";
		}
		spps = spps.substring(0, spps.length()-1);
		
		ModelAndView view = new ModelAndView("sale/ModifySalePackage");
		view.addObject("sale",list.get(0));
		view.addObject("spps",spps);
		
		return view ;
		
	}
	
	@RequestMapping(value="/ModifySalePackagePage.do")
	public ModelAndView ModifySalePackagePage(@RequestParam("spid") String spid) throws Exception 
	{
		
		String spps = "";
		String sql = "select packageCode as spid,packageName,minuteCount,productId,packagePrice,remark,packageStatus,createTime,spid as pid from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String sql1 = "select productId from t_sale_package where packageCode='"+spid+"'";
		ArrayList<Map<String, Object>> mm = Sqlca.getArrayListFromMap(sql1);
		for(Map<String,Object> ss : mm)
		{
			spps+=ss.get("productId")+"#";
		}
		spps = spps.substring(0, spps.length()-1);
		
		
		ModelAndView view = new ModelAndView("sale/ModifySalePackagePage");
		view.addObject("sale",list.get(0));
		view.addObject("spps",spps);
		
		return view ;
		
	}
	
	@RequestMapping(value="/AddSalePackageSubmit.do")
	@ResponseBody
	public String AddSalePackageSubmit(HttpServletRequest request,HttpSession session) throws Exception
	{
		String createrId = "";
		String createrName = "";
		String packageName = request.getParameter("packageName");
		String[] productIds = request.getParameterValues("productId");
		String remark = request.getParameter("remark");
		String minuteCount = request.getParameter("minuteCount");
		String packagePrice = request.getParameter("packagePrice");
		String datetime = DateUtil.dateFormat("yyyy-MM-dd HH:mm")+":00";
		
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			createrId = String.valueOf(a.getAdminId());
			createrName = a.getAdminTrueName();
		}
		
		String packageCode = "TC"+DateUtil.dateFormat("yyyyMMdd")+DateUtil.getRandombit3();
		
		for(String productId : productIds)
		{
			Sqlca.updateObject("insert into t_sale_package(packageCode,packageName,productId,remark,minuteCount,packagePrice,createrId,createrName,createTime,isuse) values(?,?,?,?,?,?,?,?,?,?)", 
					new String[] {packageCode,packageName,productId,remark,minuteCount,packagePrice,createrId,createrName,datetime,"1"});
		}
		
		return "success";
	}
	
	@RequestMapping(value="/DelSalePackage.do")
	@ResponseBody
	public String DelSalePackage(HttpServletRequest request) throws Exception
	{
		String spid = request.getParameter("spid");
		String sql = "update t_sale_package set isuse=0 where packageCode=?";
		Sqlca.updateObject(sql, new String[] {spid});
		return "success";
	}
	
	@RequestMapping(value="/ModifySalePackageSubmit.do")
	@ResponseBody
	public String ModifySalePackageSubmit(HttpServletRequest request) throws Exception
	{
		String packageName = request.getParameter("packageName");
		String[] productIds = request.getParameterValues("productId");
		String remark = request.getParameter("remark");
		String minuteCount = request.getParameter("minuteCount");
		String packagePrice = request.getParameter("packagePrice");
		String spid = request.getParameter("spid");
		
		String spsql = "select spid,packageCode,packageName,saleType,productId,minuteCount,packagePrice,packageStatus,createrId,createrName,createTime,remark,isuse "
				+ " from t_sale_package where packageCode='"+spid+"'";
		
		ArrayList<Map<String, Object>> spmp = Sqlca.getArrayListFromMap(spsql);
		String saleType = (String)spmp.get(0).get("saleType");
		String packageStatus = (String)spmp.get(0).get("packageStatus");
		String createrId = (String)spmp.get(0).get("createrId");
		String createrName = (String)spmp.get(0).get("createrName");
		String createTime = (String)spmp.get(0).get("createTime");
		String isuse = (String)spmp.get(0).get("isuse");
		
		Sqlca.updateObject("delete from t_sale_package where packageCode=?", new String[] {spid});
		
		for(String pp : productIds)
		{
			Sqlca.updateObject("insert into t_sale_package(packageCode,packageName,saleType,productId,minuteCount,packagePrice,packageStatus,createrId,createrName,createTime,remark,isuse) "
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?)", new String[] {spid,packageName,saleType,pp,minuteCount,packagePrice,packageStatus,createrId,createrName,createTime,remark,isuse});
		}
		
//		String sql = "update t_sale_package set packageName=?,productId=?,remark=?,minuteCount=?,packagePrice=? where packageCode=?";
		
//		Sqlca.updateObject(sql, new String[] {packageName,productId,remark,minuteCount,packagePrice,spid});
		
		return "success";
	}
	
	@RequestMapping(value="/UpDown.do")
	@ResponseBody
	public String UpDown(HttpServletRequest request) throws Exception
	{
		String spid = request.getParameter("spid");
		String sql = "update t_sale_package set packageStatus=(case when packageStatus='0' then '1' else '0' end) where packageCode=?";
		
		Sqlca.updateObject(sql, new String[] {spid});
		
		return "success";
	}
	
	@RequestMapping(value="/SelectSalePackageList")
	@ResponseBody
	public Map<String,Object> SelectSalePackageList(HttpServletRequest request) throws Exception
	{
		String spid = request.getParameter("spid");
		String packageName = request.getParameter("packageName");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select distinct packageCode as spid,packageName,minuteCount,packagePrice,createTime,packageStatus,packageCode as pid from t_sale_package where isuse=1";
		
		String sqlTotal = "select count(*) from (" + 
				" select distinct packageCode as spid,packageName,minuteCount,packagePrice,createTime,packageStatus,packageCode as pid from t_sale_package where isuse=1 ) tt";
		
		if(!"".equals(spid) && spid!=null) {
			sql+= " and packageCode like '%"+spid+"%'";
			sqlTotal+= " and packageCode  like '%"+spid+"%'";
		}
		
		if(!"".equals(packageName) && packageName!=null) {
			sql+= " and packageName like '%"+packageName+"%'";
			sqlTotal+= " and packageName like '%"+packageName+"%'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
