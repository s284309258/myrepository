package com.huawang.controller.systemManage;

 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Role")
public class RoleManagerController {

	@RequestMapping(value="/RoleManager.do")
	public ModelAndView OrganManager() throws Exception 
	{
		
		ModelAndView view = new ModelAndView("system/RoleManager");
		return view ;
	}
	
	
	@RequestMapping(value="/RoleManagerQuery.do")
	@ResponseBody
	public Map<String,Object> RoleManagerQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String roleid = request.getParameter("roleid");
		String rolename = request.getParameter("rolename");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select rid,role_id,role_name,role_desc,createtime,role_id as operation,usetimes,usetimestemp"+
				" from t_roles where 1=1 ";
				
		
		String sqlTotal = "select count(*) from t_roles where 1=1 ";
		
		if(!"".equals(roleid) && roleid!=null) {
			sql+= " and role_id='"+roleid+"'";
			sqlTotal+= " and role_id='"+roleid+"'";
		}
		if(!"".equals(rolename) && rolename!=null) {
			sql+= " and role_name like '%"+rolename+"%'";
			sqlTotal+= " and role_name like '%"+rolename+"%'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
//		sql += " LIMIT "+total+","+rows;
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	@RequestMapping(value="/AddRole.do")
	@ResponseBody
	public ModelAndView AddRole(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ModelAndView view = new ModelAndView("system/AddRole");
		return view ;
	}
	
	
	@RequestMapping(value="/DelRoleSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String DelRoleSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String role_id = request.getParameter("role_id");
		String obj = Sqlca.getString("select AdminID from t_admininfo t where t.roles='"+role_id+"'");
		if(obj!=null) {
			return "已有用户关联此角色,不能删除";
//			throw new Exception("已有用户关联此角色,不能删除");
		}
		String sql="delete from t_roles where role_id=?";
		int cnt = Sqlca.updateObject(sql, new String[] {role_id});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/AddRoleSubmit.do",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddRoleSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String role_id = request.getParameter("role_id");
		String role_name = request.getParameter("role_name");
		String usetimes = request.getParameter("usetimes");
		String usetimestemp = request.getParameter("usetimestemp");
		String role_desc = request.getParameter("role_desc");
		String role_data = request.getParameter("role_data");
		String datetime = DateUtil.dateFormat();
		String obj = Sqlca.getString("SELECT role_id FROM t_roles where role_id='"+role_id+"'");
		if(obj!=null) {
			return "角色编号已存在";
//			throw new Exception("角色编号已存在");
		}
		String sql="insert into t_roles(role_id,role_name,usetimes,usetimestemp,role_desc,role_data,createtime) values(?,?,?,?,?,?,?)";
		int cnt = Sqlca.updateObject(sql, new String[] {role_id,role_name,usetimes,usetimestemp,role_desc,role_data,datetime});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyRoleSubmit.do")
	@ResponseBody
	public String ModifyRoleSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String role_id = request.getParameter("role_id");
		String role_name = request.getParameter("role_name");
		String usetimes = request.getParameter("usetimes");
		String usetimestemp = request.getParameter("usetimestemp");
		String role_desc = request.getParameter("role_desc");
		String role_data = request.getParameter("role_data");
		String sql="update t_roles set role_id=?,role_name=?,usetimes=?,usetimestemp=?,role_desc=?,role_data=? where role_id=?";
		int cnt = Sqlca.updateObject(sql, new String[] {role_id,role_name,usetimes,usetimestemp,role_desc,role_data,role_id});
		if(cnt>0) {
			return "success";
		}
		return "fail";
	}
	
	@RequestMapping(value="/ModifyRole.do")
	@ResponseBody
	public ModelAndView ModifyRole(@RequestParam("role_id") String role_id) throws Exception {
		String sql = "select role_id,role_name,usetimes,usetimestemp,role_desc,role_data from t_roles where role_id='"+role_id+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		ModelAndView view = new ModelAndView("system/ModifyRole");
		view.addObject("role",list.get(0));
		return view ;
		
	}
	
	@RequestMapping(value="/RoleRight.do")
	@ResponseBody
	public ModelAndView RoleRight(HttpServletRequest request,HttpSession session) throws Exception 
	{
		String rid = request.getParameter("role_id");
		String sql = "select tt.menu_name as parent_menu_name,tt.menu_id as parent_menu_id,t.menu_name,t.menu_id,t.bak1,t.mid from t_menus t RIGHT JOIN t_menus tt " + 
				" ON t.menu_parent_id=tt.menu_id where t.menu_id is not null";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		
		ModelAndView view = new ModelAndView("system/RoleRight");
		view.addObject("rightList",list);
		
//		if(session.getAttribute("USER_SESSION")!=null) {
//			TAdmininfo admin = (TAdmininfo)session.getAttribute("USER_SESSION");
//			String role = admin.getRole();
		String role_menu_sql = "select role_id,menu_id,bak1 from t_role_menu where role_id='"+rid+"'";
		ArrayList<Map<String, Object>> currlist = Sqlca.getArrayListFromMap(role_menu_sql);
		String str = "";
		if(currlist!=null) {
			
			for(Map<String, Object> map : currlist) {
				String bak1 = (String)map.get("bak1");
				if(!"".equals(bak1)) 
				{
					str+=bak1+"_";
				}
			}
		}
		view.addObject("currrole",rid);
		view.addObject("currList",currlist);
		view.addObject("currfn",str);
		
//		}
		
		return view ;
	}
	
	@RequestMapping(value="RoleUserPage.do")
	public ModelAndView RoleUserPage(HttpServletRequest request)
	{
		String role_id = request.getParameter("role_id");
		ModelAndView view = new ModelAndView("system/RoleUserList");
		view.addObject("rid",role_id);
		return view;
	}
	
	@RequestMapping(value="RoleUserList.do")
	@ResponseBody
	public Map<String,Object> RoleUserList(HttpServletRequest request) throws Exception 
	{
		String role_id = request.getParameter("role_id");
		
		String sql="select AdminID as UserID,AdminName as UserName,AdminTrueName as DisplayName,"
				+ " (select op_display from t_option where op_param='flag' and op_value=AdminIsSuper) as AdminIsSuper,"
				+ " Email,(select op_display from t_option where op_param='sex' and op_value=Sex) as Sex,"
				+ " Contact as Telephone,(select role_name from t_roles where role_id=Roles)as Roles,"
				+ " (select DpName from t_admin_group where t_admin_group.DpId=tt.DpID) as DpID,"
				+ " (select op_display from t_option where op_param='userStatus' and op_value=State) as UserStatus" + 
				" from t_admininfo tt where roles='"+role_id+"'";
		
		ArrayList<Map<String, Object>> total = Sqlca.getArrayListFromMap(sql);
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int beginrow = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		sql += " LIMIT "+beginrow+","+rows;
		ArrayList<Map<String, Object>> roleuserlist = Sqlca.getArrayListFromMap(sql);
//		ModelAndView view = new ModelAndView("system/RoleUserList");
//		view.addObject("userList",roleuserlist);
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		reMap.put("rows", roleuserlist);
		reMap.put("total", total.size());
		return reMap;
	}
	
	@RequestMapping(value="SaveRoleRight.do")
	@ResponseBody
	public String SaveRoleRight(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String rid = (String)request.getParameter("roleid");
		String s10011 = request.getParameter("1001查询");
		String s10012 = request.getParameter("1001新增服务器");
		String s10013 = request.getParameter("1001修改");
		String s10014 = request.getParameter("1001管理");
		String s10015 = request.getParameter("1001查看集群组数据");
		String s10016 = request.getParameter("1001添加至集群组");
		String s10017 = request.getParameter("1001退出集群组");
		String s10018 = request.getParameter("1001查看MS服务器数据");
		String s10019 = request.getParameter("1001新增MS服务器");
		String s100110 = request.getParameter("1001移交至指定级联服务器");
		String s100111 = request.getParameter("1001修改MS服务器");
		String s100112 = request.getParameter("1001停用启用MS服务器");
		
		String s10021 = request.getParameter("1002查询");
		String s10022 = request.getParameter("1002新增");
		String s10023 = request.getParameter("1002修改");
		String s10024 = request.getParameter("1002管理");
		String s10025 = request.getParameter("1002查看下属服务器数据");
		String s10026 = request.getParameter("1002添加下属服务器");
		String s10027 = request.getParameter("1002移除下属服务器");
		
		String s10031 = request.getParameter("1003查询");
		String s10032 = request.getParameter("1003新增");
		String s10033 = request.getParameter("1003修改");
		
		String s50051 = request.getParameter("5005查询");
		String s50052 = request.getParameter("5005新增");
		String s50053 = request.getParameter("5005修改");
		String s50054 = request.getParameter("5005删除");
		
		String s60041 = request.getParameter("6004查询");
		String s60042 = request.getParameter("6004新增");
		String s60043 = request.getParameter("6004修改");
		String s60044 = request.getParameter("6004分配");
		String s60045 = request.getParameter("6004删除");
		String s60046 = request.getParameter("6004查看权限");
		
		String s60051 = request.getParameter("6005查询");
		String s60052 = request.getParameter("6005新增");
		String s60053 = request.getParameter("6005重置密码");
		String s60054 = request.getParameter("6005删除");
		String s60055 = request.getParameter("6005查看权限");
		String s60056 = request.getParameter("6005修改");
		
		String s20011 = request.getParameter("2001查询");
		String s20012 = request.getParameter("2001切换服务器");
		String s20013 = request.getParameter("2001进入后台");
		
		String s20021 = request.getParameter("2002查询");
		String s20022 = request.getParameter("2002导出Excel");
		
		String s20031 = request.getParameter("2003查询");
		String s20032 = request.getParameter("2003进入后台");
		
		String s30011 = request.getParameter("3001查询");
		String s30012 = request.getParameter("3001新增");
		String s30013 = request.getParameter("3001查看");
		String s30014 = request.getParameter("3001审核");
		String s30015 = request.getParameter("3001编辑");
		String s30016 = request.getParameter("3001上架");
		String s30017 = request.getParameter("3001下架");
		String s30018 = request.getParameter("3001撤回");
		String s30019 = request.getParameter("3001删除");
		
		String s40011 = request.getParameter("4001查询");
		String s40012 = request.getParameter("4001清空");
		String s40013 = request.getParameter("4001审核");
		String s40014 = request.getParameter("4001查看");
		String s40015 = request.getParameter("4001新增试用订单");
		String s40016 = request.getParameter("4001新增签约订单");
		String s40017 = request.getParameter("4001新增临时订单");
		String s40018 = request.getParameter("4001撤回");
		String s40019 = request.getParameter("4001重新发起");
		String s400110 = request.getParameter("4001结束订单");
		String s400111 = request.getParameter("4001通过");
		String s400112 = request.getParameter("4001驳回");
		String s400113 = request.getParameter("4001进入后台");
		
		String s40021 = request.getParameter("4002查询");
		String s40022 = request.getParameter("4002新增");
		String s40023 = request.getParameter("4002分配");
		String s40024 = request.getParameter("4002查看");
		String s40025 = request.getParameter("4002进入后台");
		String s40026 = request.getParameter("4002延期");
		String s40027 = request.getParameter("4002扩点试用");
		String s40028 = request.getParameter("4002合约续期");
		String s40029 = request.getParameter("4002签约");
		String s400210 = request.getParameter("4002删除");
		String s400211 = request.getParameter("4002修改");
		String s400212 = request.getParameter("4002批量分配客服");
		String s400213 = request.getParameter("4002批量切换服务器");
		String s400214 = request.getParameter("4002赠送");
		String s400215 = request.getParameter("4002调整");
		String s400216 = request.getParameter("4002签约充值");
		
		String s40031 = request.getParameter("4003查询");
		
		String s60061 = request.getParameter("6006查询");
		String s60062 = request.getParameter("6006重置密码");
		String s60063 = request.getParameter("6006作废");
		
		String s40131 = request.getParameter("4013查询");
		String s40132 = request.getParameter("4013查看");
		String s40133 = request.getParameter("4013进入后台");
		
		String s40141 = request.getParameter("4014查询");
		String s40142 = request.getParameter("4014新增");
		String s40143 = request.getParameter("4014删除");
		String s40144 = request.getParameter("4014修改");
		String s40145 = request.getParameter("4014查看");
		String s40146 = request.getParameter("4014上下架");
		
		String s40151 = request.getParameter("4015查询");
		String s40152 = request.getParameter("4015新增");
		String s40153 = request.getParameter("4015启用");
		String s40154 = request.getParameter("4015修改");
		String s40155 = request.getParameter("4015查看");
		
		String s50131 = request.getParameter("5013查询");
		String s50132 = request.getParameter("5013新增");
		String s50133 = request.getParameter("5013删除");
		String s50134 = request.getParameter("5013查看");
		
		String s80131 = request.getParameter("8013查询");
		String s80132 = request.getParameter("8013查看");
		
		String s90131 = request.getParameter("9013查询");
		String s90132 = request.getParameter("9013查看");
		String s90133 = request.getParameter("9013开票");
		
		String s70141 = request.getParameter("7014查询");
		String s70142 = request.getParameter("7014查看");
		String s70143 = request.getParameter("7014删除");
		String s70144 = request.getParameter("7014修改");
		String s70145 = request.getParameter("7014审核");
		String s70146 = request.getParameter("7014新增充值订单");
		String s70147 = request.getParameter("7014撤回");
		String s70148 = request.getParameter("7014提交");
		String s70149 = request.getParameter("7014通过");
		String s701410 = request.getParameter("7014驳回");
	/////1001
		boolean b1001 = ((null!=s10011 && !"".equals(s10011))|| (null!=s10012 && !"".equals(s10012))|| (null!=s10013 && !"".equals(s10013))|| (null!=s10014 && !"".equals(s10014))||
				(null!=s10015 && !"".equals(s10015))|| (null!=s10016 && !"".equals(s10016))|| (null!=s10017 && !"".equals(s10017))|| (null!=s10018 && !"".equals(s10018))||
				(null!=s10019 && !"".equals(s10019))|| (null!=s100110 && !"".equals(s100110))|| (null!=s100111 && !"".equals(s100111))|| (null!=s100112 && !"".equals(s100112)));
		if(b1001)
		{
			String s1001e = Sqlca.getString("select menu_id from t_role_menu where menu_id='1001' and role_id='"+rid+"'");
			if(s1001e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='10' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'10','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'1001',?)", 
						new String[] {rid,
								s10011+"_"+s10012+"_"+s10013+"_"+s10014+"_"+s10015+"_"+
								s10016+"_"+s10017+"_"+s10018+"_"+s10019+"_"+s100110+"_"+
								s100111+"_"+s100112
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='1001'",
						new String[] {s10011+"_"+s10012+"_"+s10013+"_"+s10014+"_"+s10015+"_"+
								s10016+"_"+s10017+"_"+s10018+"_"+s10019+"_"+s100110+"_"+
								s100111+"_"+s100112,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='1001'", new String[] {rid});
			
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('1001','1002','1003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='10'", new String[] {rid});
			}
		}
		
	/////1002
		boolean b1002 = ((null!=s10021 && !"".equals(s10021)) || (null!=s10022 && !"".equals(s10022))|| (null!=s10023 && !"".equals(s10023))
				|| (null!=s10024 && !"".equals(s10024))|| (null!=s10025 && !"".equals(s10025))|| (null!=s10026 && !"".equals(s10026))
				|| (null!=s10027 && !"".equals(s10027)));
		if(b1002)
		{
			String s1002e = Sqlca.getString("select menu_id from t_role_menu where menu_id='1002' and role_id='"+rid+"'");
			if(s1002e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='10' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'10','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'1002',?)", 
						new String[] {rid,
								s10021+"_"+s10022+"_"+s10023+"_"+s10024+"_"+s10025+"_"+
								s10026+"_"+s10027
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='1002'",
						new String[] {
								s10021+"_"+s10022+"_"+s10023+"_"+s10024+"_"+s10025+"_"+
								s10026+"_"+s10027
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='1002'", new String[] {rid});
			
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('1001','1002','1003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='10'", new String[] {rid});
			}
		}
		
		
		/////1003
		boolean b1003 = ((null!=s10031 && !"".equals(s10031))|| (null!=s10032 && !"".equals(s10032))
				|| (null!=s10033 && !"".equals(s10033)));
		if(b1003)
		{
			String s1003e = Sqlca.getString("select menu_id from t_role_menu where menu_id='1003' and role_id='"+rid+"'");
			if(s1003e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='10' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'10','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'1003',?)", 
						new String[] {rid,
								s10031+"_"+s10032+"_"+s10033});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='1003'",
						new String[] {
								s10031+"_"+s10032+"_"+s10033
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='1003'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('1001','1002','1003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='10'", new String[] {rid});
			}
		}
		
		/////5005
		boolean b5005 = ((null!=s50051 && !"".equals(s50051))|| (null!=s50052 && !"".equals(s50052))|| (null!=s50053 && !"".equals(s50053))
				|| (null!=s50054 && !"".equals(s50054)));
		if(b5005)
		{
			String s5005e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5005' and role_id='"+rid+"'");
			if(s5005e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5005',?)", 
						new String[] {rid,
								s50051+"_"+s50052+"_"+s50053+"_"+s50054});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5005'",
						new String[] {
								s50051+"_"+s50052+"_"+s50053+"_"+s50054
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5005'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5004','5005','5006','5007','5009','5013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		////6004
		boolean b6004 = ((null!=s60041 && !"".equals(s60041))|| (null!=s60042 && !"".equals(s60042))
				|| (null!=s60043 && !"".equals(s60043)) || (null!=s60044 && !"".equals(s60044))
				|| (null!=s60045 && !"".equals(s60045)) || (null!=s60046 && !"".equals(s60046)));
		if(b6004)
		{
			String s6004e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5004' and role_id='"+rid+"'");
			if(s6004e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5004',?)", 
						new String[] {rid,
								s60041+"_"+s60042+"_"+s60043+"_"+s60044+"_"+s60045+"_"+s60046
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5004'",
						new String[] {
								s60041+"_"+s60042+"_"+s60043+"_"+s60044+"_"+s60045+"_"+s60046
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5004'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5004','5005','5006','5007','5009','5013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		////6005
		boolean b6005 = ((null!=s60051 && !"".equals(s60051))|| (null!=s60052 && !"".equals(s60052))
				|| (null!=s60053 && !"".equals(s60053))|| (null!=s60054 && !"".equals(s60054))
				|| (null!=s60055 && !"".equals(s60055)) || (null!=s60056 && !"".equals(s60056)));
		if(b6005)
		{
			String s6005e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5006' and role_id='"+rid+"'");
			if(s6005e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5006',?)", 
						new String[] {rid,
								s60051+"_"+s60052+"_"+s60053+"_"+s60054+"_"+s60055+"_"+s60056
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5006'",
						new String[] {
								s60051+"_"+s60052+"_"+s60053+"_"+s60054+"_"+s60055+"_"+s60056
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5006'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5004','5005','5006','5007','5009','5013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		
		////2001
		boolean b2001 = ((null!=s20011 && !"".equals(s20011))|| (null!=s20012 && !"".equals(s20012)) || (null!=s20013 && !"".equals(s20013)));
		if(b2001)
		{
			String s2001e = Sqlca.getString("select menu_id from t_role_menu where menu_id='2001' and role_id='"+rid+"'");
			if(s2001e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='20' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'20','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'2001',?)", 
						new String[] {rid,
								s20011+"_"+s20012+"_"+s20013
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='2001'",
						new String[] {
								s20011+"_"+s20012+"_"+s20013
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='2001'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('2001','2002','2003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='20'", new String[] {rid});
			}
		}
		
		
		
		////2002
		boolean b2002 = ((null!=s20021 && !"".equals(s20021))|| (null!=s20022 && !"".equals(s20022)));
		if(b2002)
		{
			String s2002e = Sqlca.getString("select menu_id from t_role_menu where menu_id='2002' and role_id='"+rid+"'");
			if(s2002e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='20' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'20','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'2002',?)", 
						new String[] {rid,
								s20021+"_"+s20022
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='2002'",
						new String[] {
								s20021+"_"+s20022
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='2002'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('2001','2002','2003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='20'", new String[] {rid});
			}
		}
		
		
		
		////2003
		boolean b2003 = ((null!=s20031 && !"".equals(s20031)) || (null!=s20032 && !"".equals(s20032)));
		if(b2003)
		{
			String s2003e = Sqlca.getString("select menu_id from t_role_menu where menu_id='2003' and role_id='"+rid+"'");
			if(s2003e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='20' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'20','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'2003',?)", 
						new String[] {rid,
								s20031+"_"+s20032
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='2003'",
						new String[] {
								s20031+"_"+s20032
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='2003'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('2001','2002','2003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='20'", new String[] {rid});
			}
		}
		
		
		////3001
		boolean b3001 = ((null!=s30011 && !"".equals(s30011))|| (null!=s30012 && !"".equals(s30012))
				|| (null!=s30013 && !"".equals(s30013)) || (null!=s30014 && !"".equals(s30014))
				|| (null!=s30015 && !"".equals(s30015)) || (null!=s30016 && !"".equals(s30016))
				|| (null!=s30017 && !"".equals(s30017)) || (null!=s30018 && !"".equals(s30018))
				|| (null!=s30019 && !"".equals(s30019)));
		if(b3001)
		{
			String s3001e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5007' and role_id='"+rid+"'");
			if(s3001e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5007',?)", 
						new String[] {rid,
								s30011+"_"+s30012+"_"+s30013+"_"+s30014+"_"+s30015+"_"+s30016+"_"+s30017+"_"+s30018+"_"+s30019
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5007'",
						new String[] {
								s30011+"_"+s30012+"_"+s30013+"_"+s30014+"_"+s30015+"_"+s30016+"_"+s30017+"_"+s30018+"_"+s30019
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5007'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5007','5004','5005','5006','5013','5009') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		
		////4001
		boolean b4001 = ((null!=s40011 && !"".equals(s40011))|| (null!=s40012 && !"".equals(s40012))
				|| (null!=s40013 && !"".equals(s40013)) || (null!=s40014 && !"".equals(s40014))
				|| (null!=s40015 && !"".equals(s40015)) || (null!=s40016 && !"".equals(s40016))
				|| (null!=s40017 && !"".equals(s40017)) || (null!=s40018 && !"".equals(s40018))
				|| (null!=s40019 && !"".equals(s40019)) || (null!=s400110 && !"".equals(s400110))
				|| (null!=s400111 && !"".equals(s400111)) || (null!=s400112 && !"".equals(s400112))
				|| (null!=s400113 && !"".equals(s400113)));
		if(b4001)
		{
			String s4001e = Sqlca.getString("select menu_id from t_role_menu where menu_id='7013' and role_id='"+rid+"'");
			if(s4001e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='70' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'70','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'7013',?)", 
						new String[] {rid,
								s40011+"_"+s40012+"_"+s40013+"_"+s40014+"_"+s40015+"_"+s40016+"_"+s40017+"_"+s40018+
								s40019+"_"+s400110+"_"+s400111+"_"+s400112+"_"+s400113
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='7013'",
						new String[] {
								s40011+"_"+s40012+"_"+s40013+"_"+s40014+"_"+s40015+"_"+s40016+"_"+s40017+"_"+s40018+
								s40019+"_"+s400110+"_"+s400111+"_"+s400112+"_"+s400113
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='7013'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('7013','7014') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='70'", new String[] {rid});
			}
		}
		
		
		
		////4002
		boolean b4002 = ((null!=s40021 && !"".equals(s40021))|| (null!=s40022 && !"".equals(s40022))
				|| (null!=s40023 && !"".equals(s40023)) || (null!=s40024 && !"".equals(s40024))
				|| (null!=s40025 && !"".equals(s40025)) || (null!=s40026 && !"".equals(s40026)) 
				|| (null!=s40027 && !"".equals(s40027)) || (null!=s40028 && !"".equals(s40028)) 
				|| (null!=s40029 && !"".equals(s40029)) || (null!=s400210 && !"".equals(s400210))
				|| (null!=s400211 && !"".equals(s400211)) || (null!=s400212 && !"".equals(s400212))
				|| (null!=s400213 && !"".equals(s400213)) || (null!=s400214 && !"".equals(s400214))
				|| (null!=s400215 && !"".equals(s400215)) || (null!=s400216 && !"".equals(s400216)));
		if(b4002)
		{
			String s4002e = Sqlca.getString("select menu_id from t_role_menu where menu_id='4002' and role_id='"+rid+"'");
			if(s4002e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='40' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'40','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'4002',?)", 
						new String[] {rid,
								s40021+"_"+s40022+"_"+s40023+"_"+s40024+"_"+s40025+"_"+s40026+"_"+s40027+"_"+s40028+"_"+s40029+"_"+s400210+"_"+s400211+"_"+s400212+"_"+s400213
								+"_"+s400214+"_"+s400215+"_"+s400216
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='4002'",
						new String[] {
								s40021+"_"+s40022+"_"+s40023+"_"+s40024+"_"+s40025+"_"+s40026+"_"+s40027+"_"+s40028+"_"+s40029+"_"+s400210+"_"+s400211+"_"+s400212+"_"+s400213
								+"_"+s400214+"_"+s400215+"_"+s400216
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='4002'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('4013','4002','4014','4015','4003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='40'", new String[] {rid});
			}
		}
		
		
		////4003
		boolean b4003 = (null!=s40031 && !"".equals(s40031));
		if(b4003)
		{
			String s4003e = Sqlca.getString("select menu_id from t_role_menu where menu_id='4003' and role_id='"+rid+"'");
			if(s4003e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='40' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'40','')", 
							new String[] {rid});
				}
				
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'4003',?)", 
						new String[] {rid,
								s40031
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='4003'",
						new String[] {
								s40031
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='4003'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('4013','4002','4014','4015','4003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='40'", new String[] {rid});
			}
		}
		
		
		/////6006
		boolean b6006 = ((null!=s60061 && !"".equals(s60061))|| (null!=s60062 && !"".equals(s60062))
				|| (null!=s60063 && !"".equals(s60063)));
		if(b6006)
		{
			String s6006e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5009' and role_id='"+rid+"'");
			if(s6006e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5009',?)", 
						new String[] {rid,
								s60061+"_"+s60062+"_"+s60063
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5009'",
						new String[] {
								s60061+"_"+s60062+"_"+s60063
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5009'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5004','5005','5006','5007','5009','5013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		/////4013
		boolean b4013 = ((null!=s40131 && !"".equals(s40131)) || (null!=s40132 && !"".equals(s40132)) || (null!=s40133 && !"".equals(s40133)));
		if(b4013)
		{
			String s4013e = Sqlca.getString("select menu_id from t_role_menu where menu_id='4013' and role_id='"+rid+"'");
			if(s4013e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='40' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'40','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'4013',?)", 
						new String[] {rid,
								s40131+"_"+s40132+"_"+s40133
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='4013'",
						new String[] {
								s40131+"_"+s40132+"_"+s40133
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='4013'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('4013','4002','4014','4015','4003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='40'", new String[] {rid});
			}
		}
		
		
		
		/////4014
		boolean b4014 = ((null!=s40141 && !"".equals(s40141)) || (null!=s40142 && !"".equals(s40142)) || (null!=s40143 && !"".equals(s40143)) 
				|| (null!=s40144 && !"".equals(s40144)) || (null!=s40145 && !"".equals(s40145)) || (null!=s40146 && !"".equals(s40146)));
		if(b4014)
		{
			String s4014e = Sqlca.getString("select menu_id from t_role_menu where menu_id='4014' and role_id='"+rid+"'");
			if(s4014e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='40' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'40','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'4014',?)", 
						new String[] {rid,
								s40141+"_"+s40142+"_"+s40143+"_"+s40144+"_"+s40145+"_"+s40146
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='4014'",
						new String[] {
								s40141+"_"+s40142+"_"+s40143+"_"+s40144+"_"+s40145+"_"+s40146
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='4014'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('4013','4002','4014','4015','4003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='40'", new String[] {rid});
			}
		}
		
		
		
		/////4015
		boolean b4015 = ((null!=s40151 && !"".equals(s40151)) || (null!=s40152 && !"".equals(s40152)) || (null!=s40153 && !"".equals(s40153))
				|| (null!=s40154 && !"".equals(s40154)) || (null!=s40155 && !"".equals(s40155)));
		if(b4015)
		{
			String s4015e = Sqlca.getString("select menu_id from t_role_menu where menu_id='4015' and role_id='"+rid+"'");
			if(s4015e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='40' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'40','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'4015',?)", 
						new String[] {rid,
								s40151+"_"+s40152+"_"+s40153+"_"+s40154+"_"+s40155
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='4015'",
						new String[] {
								s40151+"_"+s40152+"_"+s40153+"_"+s40154+"_"+s40155
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='4015'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('4013','4002','4014','4015','4003') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='40'", new String[] {rid});
			}
		}
		
		
		
		/////5013
		boolean b5013 = ((null!=s50131 && !"".equals(s50131)) || (null!=s50132 && !"".equals(s50132)) || (null!=s50133 && !"".equals(s50133))
				|| (null!=s50134 && !"".equals(s50134)));
		if(b5013)
		{
			String s5013e = Sqlca.getString("select menu_id from t_role_menu where menu_id='5013' and role_id='"+rid+"'");
			if(s5013e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='50' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'50','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'5013',?)", 
						new String[] {rid,
								s50131+"_"+s50132+"_"+s50133+"_"+s50134
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='5013'",
						new String[] {
								s50131+"_"+s50132+"_"+s50133+"_"+s50134
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='5013'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('5013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='50'", new String[] {rid});
			}
		}
		
		
		
		
		/////8013
		boolean b8013 = ((null!=s80131 && !"".equals(s80131)) || (null!=s80132 && !"".equals(s80132)));
		if(b8013)
		{
			String s8013e = Sqlca.getString("select menu_id from t_role_menu where menu_id='8013' and role_id='"+rid+"'");
			if(s8013e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='80' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'80','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'8013',?)", 
						new String[] {rid,
								s80131+"_"+s80132
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='8013'",
						new String[] {
								s80131+"_"+s80132
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='8013'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('8013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='80'", new String[] {rid});
			}
		}
		
		
		
		
		/////9013
		boolean b9013 = ((null!=s90131 && !"".equals(s90131)) || (null!=s90132 && !"".equals(s90132)) || (null!=s90133 && !"".equals(s90133)));
		if(b9013)
		{
			String s9013e = Sqlca.getString("select menu_id from t_role_menu where menu_id='9013' and role_id='"+rid+"'");
			if(s9013e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='90' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'90','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'9013',?)", 
						new String[] {rid,
								s90131+"_"+s90132+"_"+s90133
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='9013'",
						new String[] {
								s90131+"_"+s90132+"_"+s90133
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='9013'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('9013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='90'", new String[] {rid});
			}
		}
		
		
		
		
		/////7014
		boolean b7014 = ((null!=s70141 && !"".equals(s70141)) || (null!=s70142 && !"".equals(s70142)) || (null!=s70143 && !"".equals(s70143))
				|| (null!=s70144 && !"".equals(s70144)) || (null!=s70145 && !"".equals(s70145)) || (null!=s70146 && !"".equals(s70146)));
		if(b7014)
		{
			String s7014e = Sqlca.getString("select menu_id from t_role_menu where menu_id='7014' and role_id='"+rid+"'");
			if(s7014e==null) 
			{
				if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id='70' and role_id='"+rid+"'"))
				{
					Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'70','')", 
							new String[] {rid});
				}
				Sqlca.updateObject("insert into t_role_menu(role_id,menu_id,bak1) values(?,'7014',?)", 
						new String[] {rid,
								s70141+"_"+s70142+"_"+s70143+"_"+s70144+"_"+s70145+"_"+s70146+"_"+s70147+"_"+s70148+"_"+s70149+"_"+s701410
								});
			}
			else
			{
				Sqlca.updateObject("update t_role_menu set bak1=? where role_id=? and menu_id='7014'",
						new String[] {
								s70141+"_"+s70142+"_"+s70143+"_"+s70144+"_"+s70145+"_"+s70146+"_"+s70147+"_"+s70148+"_"+s70149+"_"+s701410
								,rid});
			}
		}
		else
		{
			Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='7014'", new String[] {rid});
		
			if(null==Sqlca.getString("select menu_id from t_role_menu where menu_id in('7014','7013') and role_id='"+rid+"'"))
			{
				Sqlca.updateObject("delete from t_role_menu where role_id=? and menu_id='70'", new String[] {rid});
			}
		}
		
		
		return "success";
	}
	
//	@RequestMapping(value="/RoleRightQuery.do")
//	@ResponseBody
//	public ArrayList<Map<String, Object>> RoleRightQuery(HttpServletRequest request, HttpServletResponse response) throws Exception 
//	{
//		String sql = "select tt.menu_name as parent_menu_name,tt.menu_id as parent_menu_id,t.menu_name,t.menu_id,t.bak1,t.mid from t_menus t RIGHT JOIN t_menus tt " + 
//				" ON t.menu_parent_id=tt.menu_id where t.menu_id is not null";
//		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
//		return list ;
//	}
	
}
