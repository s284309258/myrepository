package com.huawang.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.Sqlca;

@Controller
public class CommonController {

	@RequestMapping(params = "Option_UserStatus")
	@ResponseBody
	public String OptionCommon(HttpServletRequest request) throws Exception 
	{
//		String us = request.getParameter("userStatus");
		String sql = "select op_value,op_display from t_option where op_param='userStatus'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_DepartMent")
	@ResponseBody
	public String DepartMentCommon(HttpServletRequest request) throws Exception 
	{
//		String us = request.getParameter("userStatus");
//		String sql = "select dpid as op_value,dpname as op_display from t_department";
		String sql = "select dpid as op_value,dpname as op_display from t_admin_group";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_UserRole")
	@ResponseBody
	public String UserRoleCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select role_id as op_value,role_name as op_display from t_roles";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	
	@RequestMapping(params = "Option_Sex")
	@ResponseBody
	public String SexCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='sex'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Flag")
	@ResponseBody
	public String FlagCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='flag'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Product")
	@ResponseBody
	public String ProductCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select ProductId as op_value,ProductName as op_display from t_product_definition";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Admin")
	@ResponseBody
	public String AdminCommon(HttpServletRequest request,HttpSession session) throws Exception 
	{
		String roledata = "";
		String dpid = "";
		Integer aid = 0;
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			aid = a.getAdminId();
			String roleid = a.getRole();
			roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
			dpid = a.getDpId();
		}
		
		String sql="select AdminID as op_value,AdminTrueName as op_display from t_admininfo where 1=1 ";
		
		if("1".equals(roledata))
		{
			
		}
		else if("2".equals(roledata))
		{
			sql += " and adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"')";
		}
		else if("3".equals(roledata)) 
		{
			sql += " and adminID="+aid;
		}
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_AdminAll")
	@ResponseBody
	public String AdminAllCommon(HttpServletRequest request,HttpSession session) throws Exception 
	{
		String sql="select AdminID as op_value,AdminTrueName as op_display from t_admininfo where 1=1 ";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_OrderType")
	@ResponseBody
	public String OrderTypeCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='orderType'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_ApproveStatus")
	@ResponseBody
	public String ApproveStatuCommon(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='approveStatus'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_CompanyName")
	@ResponseBody
	public String CompanyNameCommon(HttpServletRequest request,HttpSession session) throws Exception 
	{
		String roledata = "";
		String dpid = "";
		Integer aid = 0;
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			aid = a.getAdminId();
			String roleid = a.getRole();
			roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
			dpid = a.getDpId();
		}
		String sql="select CompID as op_value,CompTrueName as op_display from t_compinfo where 1=1 ";
		
		if("1".equals(roledata))
		{
			
		}
		else if("2".equals(roledata))
		{
			sql += " and CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
		}
		else if("3".equals(roledata)) 
		{
			sql += " and CompID in(select tt.compID from t_compinfo tt where tt.adminID="+aid+") ";
		}
		
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	
	@RequestMapping(params = "Option_ServerName")
	@ResponseBody
	public String Option_ServerName(HttpServletRequest request) throws Exception 
	{
		String sql="select ServerID as op_value,concat(ServerName,'-',ServerIP) as op_display from t_serverinfo "+
				" where ((ServerType = '0' AND IsPad = '0') OR (ServerType = '1' AND IsPad = '0') OR (ServerType = '0' AND IsPad = '1'))";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Agent")
	@ResponseBody
	public String Option_Agent(HttpServletRequest request) throws Exception 
	{
		String sql="select agentId as op_value,agentName as op_display from t_agent_info";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Allocat")
	@ResponseBody
	public String Option_Allocat(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='Allocat'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Promotiontype")
	@ResponseBody
	public String Option_Promotiontype(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='Promotiontype'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_CompTrueName")
	@ResponseBody
	public String Option_CompTrueName(HttpServletRequest request,HttpSession session) throws Exception 
	{
		String sql="select CompID as op_value,CompTrueName as op_display from t_compinfo";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Promotiontemp")
	@ResponseBody
	public String Promotiontemp(HttpServletRequest request) throws Exception 
	{
		String tpid = request.getParameter("tpid");
		String json = "";
		if(tpid==null || "".equals(tpid))
		{
			String sql="select otid as op_value,templateName as op_display from t_operation_template where isTemplate=0";
			json = Sqlca.getJsonFromArrayMap(sql);
		}
		else
		{
			if("1".equals(tpid))
			{
				String sql="select otid as op_value,templateName as op_display from t_operation_template where isTemplate=0 and otid in(1,2)";
				json = Sqlca.getJsonFromArrayMap(sql);
			}
			if("2".equals(tpid))
			{
				String sql="select otid as op_value,templateName as op_display from t_operation_template where isTemplate=0 and otid in(3,4)";
				json = Sqlca.getJsonFromArrayMap(sql);
			}
		}
		
		return json;
	}
	
	@RequestMapping(params = "Option_AdeviceProduct")
	@ResponseBody
	public String Option_AdeviceProduct(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='adeviceProduct'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_TimeUnitYMD")
	@ResponseBody
	public String Option_TimeUnitYMD(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='TimeUnitYMD'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_SalePackage")
	@ResponseBody
	public String Option_SalePackage(HttpServletRequest request) throws Exception 
	{
		String sql="select DISTINCT packageCode as op_value,packageName as op_display from t_sale_package where isuse=1";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_SellType")
	@ResponseBody
	public String Option_SellType(HttpServletRequest request) throws Exception 
	{
		String sql="select op_value,op_display from t_option where op_param='sellType'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_TorderType")
	@ResponseBody
	public String Option_TorderType(HttpServletRequest request) throws Exception
	{
		String sql = "select op_value,op_display from t_option where op_param='TorderType'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
	@RequestMapping(params = "Option_Param")
	@ResponseBody
	public String Option_Param(HttpServletRequest request) throws Exception 
	{
		String param = request.getParameter("args");
		String sql="select op_value,op_display from t_option where op_param='"+param+"'";
		String json = Sqlca.getJsonFromArrayMap(sql);
		return json;
	}
	
}
