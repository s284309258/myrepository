package com.huawang.controller.saleManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.util.Sqlca;

@Controller
public class AllotManagerController 
{
	@RequestMapping(value="AllotManager.do")
	public ModelAndView AllotManager()
	{
		ModelAndView view = new ModelAndView("sale/AllotNewCustomer");
		return view;
	}
	
	@RequestMapping(value="AllotManagerQuery.do")
	@ResponseBody
	public Map<String,Object> AllotManagerQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
//		if("IsAllot".equals(SortName)) 
//		{
//			SortName = "AdminID"; 
//		}
		
		String CompTrueName = request.getParameter("CompTrueName");
		String CompName = request.getParameter("CompName");
//		String Allocat = request.getParameter("Allocat");
		String admin = request.getParameter("Admin");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		
		String sql = "select CompID,CompName,CompTrueName,ProductID,(select tt.ProductName from t_product_definition tt "
				+ " where tt.ProductId=t.ProductID) as ProductName,MaxUserCount,AdminID,(CASE WHEN t.AdminID>0 THEN '已分配' ELSE '未分配' END) AS IsAllot,"
				+ " (select tt.AdminTrueName from t_admininfo tt where tt.AdminID=t.adminid) as AdminName,"
				+ " CompID as CompIDopr from t_compinfo t where compStyle='2' and (AdminID<1 or AdminID is null) ";
		
		String sqlTotal = "select count(*) from t_compinfo t where compStyle='2' and (AdminID<1 or AdminID is null) ";
		
		if(!"".equals(CompTrueName) && CompTrueName!=null) {
			sql += " and CompTrueName like '%"+CompTrueName+"%'";
			sqlTotal += " and CompTrueName like '%"+CompTrueName+"%'";
		}
		
		if(!"".equals(CompName) && CompName!=null) {
			sql += " and CompName like '%"+CompName+"%'";
			sqlTotal += " and CompName like '%"+CompName+"%'";
		}
		
//		if(!"".equals(Allocat) && Allocat!=null) {
//			if("0".equals(Allocat)) 
//			{
//				sql += " and (AdminID<1 or AdminID is null)";
//				sqlTotal += " and (AdminID<1 or AdminID is null)";
//			}
//			else if("1".equals(Allocat))
//			{
//				sql += " and AdminID>0";
//				sqlTotal += " and AdminID>0";
//			}
//		}

		if(!"".equals(admin) && admin!=null) 
		{
			sql += " and AdminID="+admin;
			sqlTotal += " and AdminID="+admin;
		}
		
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	@RequestMapping(value="AllotCustomer.do")
	@ResponseBody
	public String AllotCustomer(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String AdminID = request.getParameter("AdminID");
		String CompID = request.getParameter("CompID");
		int cnt =Sqlca.updateObject("update t_compinfo set AdminID=?,allocatAdmin=1 where CompID=?", new String[] {AdminID,CompID});
		if(cnt>0)
		{
			Sqlca.updateObject("update t_order set o_AdminID=? where o_CompID=?", new String[] {AdminID,CompID});
			return "success";
		}
		return "fail";
	}
}
