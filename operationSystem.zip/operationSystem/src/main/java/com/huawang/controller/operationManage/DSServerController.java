package com.huawang.controller.operationManage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huawang.dao.operation.TServerinfoDao;
import com.huawang.pojo.operation.TServerinfo;
import com.huawang.util.Sqlca;


@Controller
@RequestMapping(value="/DS")
public class DSServerController {

	static Logger logger = LogManager.getLogger(DSServerController.class.getName());
	@Autowired
	private TServerinfoDao serverinfoDao;
	 
	
	@RequestMapping(value="/dsServerSelect")
	public String selectDSserver(HttpServletRequest request, HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		return "operation/DSService";
	}
	
	/**
	 * 	查询DS服务器列表数据及根据条件查询
	 * @param request
	 * @param response
	 * @param serverInfo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/dsServerSelectMap")
	@ResponseBody
	public Map<String, Object> selectDSserverMap(HttpServletRequest request, HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
		 
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sqlCount ="SELECT COUNT(1)  FROM t_serverinfo t  LEFT JOIN  t_serverbitinfo t1 ON t.ServerID = t1.ServerID WHERE 1 = 1  AND (t.ServerType = '3' AND t.IsPad = '0')";
		
		String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp," + 
				"			t.ServerPort AS serverPort,t.ServerType AS serverType,t.ParentId AS parentId,t.ParentServerIP AS parentServerIp,\r\n" + 
				"			t.IsPad AS isPad,t.VsersionNum AS vsersionNum,t.VsersionInfo AS vsersionInfo,t.LocalIP AS localIp FROM " + 
				"			t_serverinfo t   WHERE  1 = 1  AND (t.ServerType = '3' AND t.IsPad = '0')";
		
		if(serverInfo.serverName!=null &&!"".equals(serverInfo.serverName)) {
			sql +=" and t.ServerName like  '%"+serverInfo.serverName+"%'";
			sqlCount += " and t.ServerName like  '%"+serverInfo.serverName+"%'";
		}
		if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
			sql +=" and t.ServerIP='"+serverInfo.serverIp+"'";
			sqlCount +=" and t.ServerIP='"+serverInfo.serverIp+"'";
		}
		ArrayList<Object> addList =Sqlca.getArrayListFromObj(sql, TServerinfo.class);
		String cnt = Sqlca.getString(sqlCount);
		HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("rows", addList);
			map.put("total", cnt);
			return map;
		}
	
		@RequestMapping(value="/addToServer",method = {RequestMethod.POST,RequestMethod.GET})
		public String addToDSserver(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) {
			return "operation/addDS";
		}
	
	
	
			/**
			 * 	保存新增数据
			 * @param request
			 * @param response
			 * @param serverInfo
			 * @param model
			 * @return
			 * @throws Exception 
			 */
			@RequestMapping(value="/addDSDataServer",method= {RequestMethod.POST})
			@ResponseBody
			public String addDSDataServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		        String date =df.format(new Date()); 
				
				String serverType ="3";
				String isPad= "0";
				serverInfo.setServerType(serverType);
				serverInfo.setIsPad(isPad);
				String message="";
				
				String sql ="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverInfo.serverName+"' AND (t.ServerType = '3' AND t.IsPad = '1')";
				String addSql=Sqlca.getString(sql);
				
				if(Integer.parseInt(addSql)>0) {
					message="reName";
					return message;
				}else {
					int sqlCount = Sqlca.updateObject("INSERT INTO t_serverinfo (ServerName,ServerType,IsPad,ServerIP,LocalIP,createDate)values(?,?,?,?,?,?)", new String[] {
							serverInfo.serverName,serverType,isPad,serverInfo.serverIp,serverInfo.localIp,date});
					if(sqlCount>0) {
						message="success";
					}else {
						message="fail";
					}
					return message;
				}
			}
		
			@RequestMapping(value="/editDSServer",method = {RequestMethod.POST,RequestMethod.GET})
			public String editDSServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
				 
				String sql ="SELECT t.ServerID AS serverId,t.ServerName AS serverName,t.ServerIP AS serverIp,t.ServerType AS serverType,t.IsPad AS isPad,t.LocalIP AS localIp FROM " + 
						" t_serverinfo t   WHERE 1 = 1 AND t.ServerID = "+serverInfo.serverId;
				List<Object> list = Sqlca.getArrayListFromObj(sql, TServerinfo.class);
				model.addAttribute("serverInfo", list);
				return "operation/editDS";
			}
	
			/**
			 * 保存修改后的数据
			 */
			String message ="";
			@RequestMapping(value="/saveDSServer",method = {RequestMethod.POST,RequestMethod.GET})
			@ResponseBody
			public String saveDSServer(HttpServletRequest request,HttpServletResponse response,TServerinfo serverInfo,Model model) throws Exception {
				
				serverInfo.setServerName(Sqlca.switchLatin1Encoding(serverInfo.getServerName()));
				String serverId = serverInfo.getServerId().toString();
				String sql ="SELECT COUNT(1) FROM t_serverinfo t WHERE t.ServerName = '"+serverInfo.getServerName()+"' AND (t.ServerType = '3' AND t.IsPad = '1') and t.serverId <> "+serverId;
				String addSql=Sqlca.getString(sql);
				
				StringBuilder buder = new StringBuilder("UPDATE t_serverinfo T SET T.updateDate =  NOW()");
				if(serverInfo.serverName!=null && !"".equals(serverInfo.serverName)) {
					buder.append(" ,T.ServerName = '"+serverInfo.serverName+"'");
				}
				if(serverInfo.serverIp!=null && !"".equals(serverInfo.serverIp)) {
					buder.append(" ,T.ServerIP = '"+serverInfo.serverIp+"'");
				}
				if(serverInfo.localIp!=null && !"".equals(serverInfo.localIp)) {
					buder.append(" ,T.LocalIP = '"+serverInfo.localIp+"'");
				}
				if(serverInfo.serverType!=null && !"".equals(serverInfo.serverType)) {
					buder.append(" ,T.serverType ="+serverInfo.serverType);
				}
				buder.append("  WHERE T.ServerID =" +serverId);
				if(Integer.parseInt(addSql)>0) {
					serverId="0";
				}else {
					Sqlca.updateObject(buder.toString(), new String[] {});
					message=serverId;
				}
				return message;
			}
			
	
}

















