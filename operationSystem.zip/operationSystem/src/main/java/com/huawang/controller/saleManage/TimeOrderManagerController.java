package com.huawang.controller.saleManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.CommonInterface;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/TimeOrder")
public class TimeOrderManagerController 
{
	static Logger logger = LogManager.getLogger(TimeOrderManagerController.class.getName()); 
	
	@RequestMapping(value="/TOrderManager.do")
	public ModelAndView OrderManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/order/TimeOrderManager");
		return view ;
	}
	
	@RequestMapping(value="/AddTimeOrder.do")
	public ModelAndView AddTimeOrder(HttpServletRequest request) 
	{
		String o_Type = request.getParameter("o_Type");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		
		ModelAndView view = new ModelAndView("sale/order/AddTimeOrder");
		view.addObject("o_Type", o_Type);
		view.addObject("o_CompID", o_CompID);
		view.addObject("o_Product", o_Product);
		return view ;
	}
	
	@RequestMapping(value="/AddTimeOrderSubmit.do")
	@ResponseBody
	public String AddTimeOrderSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		Object obj = session.getAttribute("USER_SESSION");
		String createUser = "";
		int adminid = 0;
		if(obj!=null)
		{
			TAdmininfo admin = (TAdmininfo)obj;
			createUser = admin.getAdminName();
			adminid = admin.getAdminId();
		}
		String currdate = DateUtil.dateFormat();
		String o_Type = request.getParameter("o_Type");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		String o_totalTime = request.getParameter("o_totalTime");
		String o_amount = request.getParameter("o_amount");
		String o_Remark = request.getParameter("o_Remark");
		String o_status = "1";
		String minfreetime = Sqlca.getString("select op_bak1 from t_option where op_param='TorderType' and op_value=5");
		
		if("4".equals(o_Type))
		{
			o_status="2";
		}
		
		if("5".equals(o_Type))
		{
			if(Integer.parseInt(o_totalTime)>Integer.parseInt(minfreetime)) 
			{
				o_status="2";
			}
		}
		
		String CompTrueName = Sqlca.getString("select CompTrueName from t_compinfo where CompID="+o_CompID);
		
		String sql = "insert into t_timeorder(o_Type,o_CompID,o_Product,o_totalTime,o_amount,o_Remark,o_MaxUserCount,o_status,"
				+ " o_adminid,o_createuser,o_createtime,o_compname,o_selltype,o_Style,createType) values(?,?,?,?,?,?,99999,?,"+adminid+",'"+createUser+"',"
				+ " '"+currdate+"','"+CompTrueName+"',1,2,2)";
		
		Sqlca.updateObject(sql, new String[] {o_Type,o_CompID,o_Product,o_totalTime,o_amount,o_Remark,o_status});
		
		if("1".equals(o_status))
		{
			String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+o_CompID+" and productId="+o_Product);
			if(exsits==null)
			{
				Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+o_CompID+","+o_Product+",0,2)", new String[] {});
			}
			Sqlca.updateObject("update t_compinfo set productID='"+o_Product+"',TolTimes=(TolTimes+'"+o_totalTime+"'),MaxUserCount=99999,CompStatus=1,sellType=1 where CompID=?", new String[] {o_CompID});
		}
		
		return "success";
		
	}
	
	
	@RequestMapping(value="/ShowTimerOrder.do")
	public ModelAndView ShowTimerOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		
		String sql = "select id,o_Type,o_MaxUserCount,o_Product,o_UseDays,o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_Status,o_AdminID,o_CreateUser,"
				+ " o_CreateTime,o_UpdateUser,o_UpdateTime,o_CompID,o_Opinion,o_bak1,o_bak2,o_CompName,o_SignRadio,o_Style,o_sellType,o_amount,createType,oaid,o_totalTime,spid"
				+ " from t_timeorder where id="+id;
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		ModelAndView view = new ModelAndView("sale/order/ModifyTimeOrder");
		view.addObject("torder",list.get(0));
		
		return view;
	}
	
	@RequestMapping(value="/ApproveTimerOrder.do")
	public ModelAndView ApproveTimerOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		
		String sql = "select id,o_Type,o_MaxUserCount,o_Product,o_UseDays,o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_Status,o_AdminID,o_CreateUser,"
				+ " o_CreateTime,o_UpdateUser,o_UpdateTime,o_CompID,o_Opinion,o_bak1,o_bak2,o_CompName,o_SignRadio,o_Style,o_sellType,o_amount,createType,oaid,o_totalTime,spid"
				+ " from t_timeorder where id="+id;
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		ModelAndView view = new ModelAndView("sale/order/ApproveTimeOrder");
		view.addObject("torder",list.get(0));
		
		return view;
	}
	
	
	@RequestMapping(value="/ShowTimerOrderDetail.do")
	public ModelAndView ShowTimerOrderDetail(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		
		String sql = "select id,o_Type,(select op_display from t_option where op_param='TorderType' and op_value=o_Type) as orderType,o_MaxUserCount," + 
				" (select ProductName from t_product_definition where ProductId=o_Product) as ProductName,o_Product,o_UseDays,o_CreateDate,o_EndDate,o_UseTimes,o_Remark,o_Status,o_AdminID," + 
				" (select op_display from t_option where op_param='approveStatus' and op_value=o_Status) as approveStatus,"+
				" (select admintruename from t_admininfo where adminid=o_AdminID) as adminName,o_CreateUser," + 
				" (select admintruename from t_admininfo where adminName=o_CreateUser) as CreateUser,o_CreateTime,o_UpdateUser,o_UpdateTime,o_CompID,o_Opinion,o_bak1,o_bak2,o_CompName," + 
				" (select CompTrueName from t_compinfo where CompID=o_CompID) as CompTrueName,"+
				" (select admintruename from t_admininfo where adminName=o_ApproveID) as ApproveName," + 
				" (select DISTINCT activate from t_operation_activity where oaCode=t.oaid) as activate,oaid,o_totalTime,spid," + 
				" (select DISTINCT packageName from t_sale_package where packageCode=spid) as packageName," + 
				" o_SignRadio,o_Style,o_sellType,o_amount,createType,o_ApproveID" + 
				" from t_timeorder t where id="+id;
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		ModelAndView view = new ModelAndView("sale/order/TimeOrderDetail");
		view.addObject("torder",list.get(0));
		
		return view;
	}
	
	@RequestMapping(value="/ApproveTimeOrderSubmit.do")
	@ResponseBody
	public String ApproveTimeOrderSubmit(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		String o_status = request.getParameter("o_Status");
		String o_opinion = request.getParameter("o_Opinion");
		String o_totalTime = request.getParameter("o_totalTime");
		String o_CompID = request.getParameter("o_CompID");
		String o_Product = request.getParameter("o_Product");
		
		String o_UpdateTime = DateUtil.dateFormat();
		String adminName = "";
		
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			adminName = a.getAdminName();
			
		}
		
		Sqlca.updateObject("update t_timeorder set o_ApproveID=?,o_Opinion=?,o_Status=?,o_UpdateTime=? where id=?", 
				new String[] {adminName,o_opinion,o_status,o_UpdateTime,id});
		
		if("1".equals(o_status))
		{
			String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+o_CompID+" and productId="+o_Product);
			if(exsits==null)
			{
				Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+o_CompID+","+o_Product+",0,2)", new String[] {});
			}
			Sqlca.updateObject("update t_compinfo set productID='"+o_Product+"',TolTimes=(TolTimes+'"+o_totalTime+"'),MaxUserCount=99999,CompStatus=1,sellType=1 where CompID=?", new String[] {o_CompID});
		}
		
		return "success";
	}
	
	@RequestMapping(value="/RevokeTimeOrder.do")
	@ResponseBody
	public String RevokeTimeOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		String o_status = request.getParameter("o_Status");
		
		Sqlca.updateObject("update t_timeorder set o_Status=? where id=?", 
				new String[] {o_status,id});
		
		return "success";
	}
	
	@RequestMapping(value="/ReplayTimeOrder.do")
	@ResponseBody
	public String ReplayTimeOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		String o_totalTime = request.getParameter("o_totalTime");
		String o_CompID = request.getParameter("o_CompID");
		String o_Type = request.getParameter("o_Type");
		String o_Product = request.getParameter("o_Product");
		String o_status = "1";
		
		if("4".equals(o_Type))
		{
			Sqlca.updateObject("update t_timeorder set o_Status=? where id=?", 
					new String[] {"2",id});
			
			return "success";
		}
		
		if("5".equals(o_Type))
		{
			String minfreetime = Sqlca.getString("select op_bak1 from t_option where op_param='TorderType' and op_value=5");
			
			if(Integer.parseInt(o_totalTime)>Integer.parseInt(minfreetime)) 
			{
				o_status="2";
			}
			
			Sqlca.updateObject("update t_timeorder set o_Status=? where id=?", 
					new String[] {o_status,id});
			
			if("1".equals(o_status))
			{
				String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+o_CompID+" and productId="+o_Product);
				if(exsits==null)
				{
					Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+o_CompID+","+o_Product+",0,2)", new String[] {});
				}
				Sqlca.updateObject("update t_compinfo set productID='"+o_Product+"',TolTimes=(TolTimes+'"+o_totalTime+"'),MaxUserCount=99999,CompStatus=1,sellType=1 where CompID=?", new String[] {o_CompID});
			}
		}
		
		if("6".equals(o_Type))
		{
			Sqlca.updateObject("update t_timeorder set o_Status=? where id=?", 
					new String[] {o_status,id});
			
			if("1".equals(o_status))
			{
				String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+o_CompID+" and productId="+o_Product);
				if(exsits==null)
				{
					Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+o_CompID+","+o_Product+",0,2)", new String[] {});
				}
				Sqlca.updateObject("update t_compinfo set productID='"+o_Product+"',TolTimes=(TolTimes+'"+o_totalTime+"'),MaxUserCount=99999,CompStatus=1,sellType=1 where CompID=?", new String[] {o_CompID});
			}
		}
		
		return "success";
	}
	
	@RequestMapping(value="/ModifyTimerOrder.do")
	@ResponseBody
	public String ModifyTimerOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		String o_Product = request.getParameter("o_Product");
		String o_totalTime = request.getParameter("o_totalTime");
		String o_amount = request.getParameter("o_amount");
		String o_Remark = request.getParameter("o_Remark");
		
		String sql = "update t_timeorder set o_Product=?,o_totalTime=?,o_amount=?,o_Remark=? where id=?";
		
		Sqlca.updateObject(sql, new String[] {o_Product,o_totalTime,o_amount,o_Remark,id});
		
		return "success";
	}
	
	@RequestMapping(value="/DelTimerOrder.do")
	public ModelAndView DelTimerOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String id = request.getParameter("id");
		
		String sql = "delete from t_timeorder where id="+id;
		
		Sqlca.updateObject(sql, new String[] {});
		
		ModelAndView view = new ModelAndView("sale/order/TimeOrderManager");
		
		return view ;
	}
	
	@RequestMapping(value="/ConfLogDetail.do")
	@ResponseBody
	public Map<String,Object> ConfLogDetail(HttpServletRequest request) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String CompID = request.getParameter("o_CompID");
		
		String sql = "select t.ConfID,t.ConfName,tt.MaxCount,(tt.EndTime-tt.StartTime) as useTime,tt.SettlingTime,tt.StartTime,tt.EndTime from t_confinfo t,t_log_conf tt where t.ConfID=tt.ConfID and t.CompID="+CompID;
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		int dbtotal = list.size();
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	
	@RequestMapping(value="/TOrderManagerQuery.do")
	@ResponseBody
	public Map<String,Object> TimeOrderManagerQuery(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String userName = request.getParameter("userName");
		String product = request.getParameter("product");
		String admin = request.getParameter("admin");
		String orderType = request.getParameter("orderType");
		String orderStatus = request.getParameter("orderStatus");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		
		String isQuery = request.getParameter("isQuery");
		if(!"yes".equals(isQuery)) 
		{
			orderStatus = request.getParameter("preApprove");
		}
		
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		Object obj = session.getAttribute("USER_SESSION");
		int aid = 99999;
		String roledata = "";
		String dpid = "";
		String createuser = "";
		
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			aid = a.getAdminId();
			String roleid = a.getRole();
			createuser = a.getAdminName();
			roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
			dpid = a.getDpId();
		}
		
		String sql = "select * from (select id,(select CompName from t_compinfo where CompID=o_CompID) as compname,o_CompName,o_sellType,"
				+ " o_Product,(select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,"
				+ " (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus,"
				+ " (select AdminTrueName from t_admininfo where AdminID=t.o_AdminID) as AdminName,"
				+ " (select AdminTrueName from t_admininfo where adminName=o_CreateUser) as CreateUser,"
				+ " (select op_display from t_option where op_param='TorderType' and op_value=t.o_Type) as orderType,"
				+ " o_totalTime,o_Status,o_AdminID,o_CreateUser,o_CreateTime,id as opid,o_Type,o_amount "
				+ " from t_timeorder t where t.o_CreateUser='"+createuser+"' or 1=1  ";
		
		String sqlTotal = "select count(*) from (select id,o_CompName,o_sellType,o_Product,o_totalTime,o_Status,o_AdminID,"
				+ " o_CreateUser,o_CreateTime from t_timeorder t where t.o_CreateUser='"+createuser+"' or 1=1 ";
		
		if("1".equals(roledata))
		{
			
		}
		else if("2".equals(roledata))
		{
			sql += " and t.o_CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
			
			sqlTotal += " and t.o_CompID in(select tt.compID from t_compinfo tt "
					+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
		}
		else if("3".equals(roledata)) 
		{
			sql += " and t.o_CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		
			sqlTotal += " and t.o_CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
		}
		sql+=") tb where 1=1 ";
		sqlTotal+=") tb where 1=1 ";
		
		
		if(!"".equals(userName) && userName!=null) 
		{
			sql+= " and tb.o_CompName like '%"+userName+"%'";
			sqlTotal += " and tb.o_CompName like '%"+userName+"%'";
		}
		
		if(!"".equals(product) && product!=null) 
		{
			sql+= " and tb.o_Product='"+product+"'";
			sqlTotal+= " and tb.o_Product='"+product+"'";
		}
		
		if(!"".equals(admin) && admin!=null) 
		{
			sql+= " and tb.o_AdminID='"+admin+"'";
			sqlTotal+= " and tb.o_AdminID='"+admin+"'";
			
		}
		
		if(!"".equals(orderType) && orderType!=null) 
		{
			sql+= " and tb.o_Type='"+orderType+"'";
			sqlTotal+= " and tb.o_Type='"+orderType+"'";
		}
		
		if(!"".equals(orderStatus) && orderStatus!=null) 
		{
			sql+= " and tb.o_Status='"+orderStatus+"'";
			sqlTotal+= " and tb.o_Status='"+orderStatus+"'";
		}
		
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	@RequestMapping(value="/AddSignTimeOrderApp",produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String AddSignTimeOrderApp(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception 
	{
		String ua = request.getHeader("User-Agent");
		System.out.println("ua:"+ua);
		String ra = request.getRemoteAddr();
		System.out.println("ra:"+ra);
		String xff = request.getHeader("x-forwarded-for");
		System.out.println("xff:"+xff);
		
		
		String allowip = Sqlca.getString("select opid from t_option where op_param='allowipaccessboss' and op_bak1='"+ra+"'");
		if(allowip==null) 
		{
			return "fail";
		}
		String o_CompID = request.getParameter("o_CompID");
		String o_amount = request.getParameter("o_Amount");
		String o_totalTime = request.getParameter("o_totalTime");
		String payid = request.getParameter("payid");
		String createUser = request.getParameter("o_createUser");
		if(createUser==null) {createUser="";}
		
		logger.info("AddSignTimeOrderApp:RemoteAddr="+ra+"|CompID="+o_CompID+"|totalTime="+o_totalTime+"|createUser="+createUser);
		
		String pay_id = Sqlca.getString("select pay_id from t_payment_record where pay_id='"+payid+"' and orderState='0'");
		if(pay_id==null)
		{
			return "fail";
		}
		
		String o_CreateDate = DateUtil.dateFormat();
		

		ArrayList<Map<String, Object>> mm= Sqlca.getArrayListFromMap("select productID,AdminID,CompTrueName,CompName from t_compinfo where CompID="+o_CompID);
		String productID = (String)mm.get(0).get("productID");
		String AdminID = (String)mm.get(0).get("AdminID");
		String CompTrueName = (String)mm.get(0).get("CompTrueName");
		
		String oaCode = Sqlca.getString("select oaCode from t_operation_activity where payProduct='"+productID+"' and isuse=1");
		String spCode = Sqlca.getString("select packageCode from t_sale_package where productId='"+productID+"' and packageCode=1 and isuse=1");
		
		if(oaCode==null) {oaCode="";}
		if(spCode==null) {spCode="";}
		
		String insertOrder="insert into t_timeorder(o_Type,o_MaxUserCount,o_Product,o_Status,o_AdminID,"
				+ " o_CreateTime,o_CreateUser,o_CompID,o_CompName,o_sellType,o_amount,createtype,oaid,spid,o_totalTime,o_Style)"
				+ " values(? ,? ,? ,? ,? ,? ,? ,? ,?,?,?,?,?,?,?,?)";
		Sqlca.updateObject(insertOrder, new String[] {"4","99999",productID,"1",AdminID,o_CreateDate,createUser,o_CompID,CompTrueName,"1",o_amount,"1",oaCode,spCode,o_totalTime,"2"});
		
		String exsits = Sqlca.getString("select compId from t_compinfo_product where compId="+o_CompID+" and productId="+productID);
		if(exsits==null)
		{
			Sqlca.updateObject("insert into t_compinfo_product(compId,productId,productCount,productProperty) values("+o_CompID+","+productID+",0,2)", new String[] {});
		}
		Sqlca.updateObject("update t_compinfo set productID='"+productID+"',TolTimes=(TolTimes+'"+o_totalTime+"'),MaxUserCount=99999 where CompID=?", new String[] {o_CompID});
		
		Sqlca.updateObject("update t_payment_record set orderState=1 where pay_id=?", new String[] {pay_id});
		
		return "success";
	}
	
	
	@RequestMapping(value="/TOrderManagerQueryByCompID.do")
	@ResponseBody
	public Map<String,Object> TOrderManagerQueryByCompID(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws Exception
	{
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String userName = request.getParameter("userName");
		String product = request.getParameter("product");
		String admin = request.getParameter("admin");
		String orderType = request.getParameter("orderType");
		String orderStatus = request.getParameter("orderStatus");
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		
		String o_CompID = request.getParameter("o_CompID");
		
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select * from (select id,(select CompName from t_compinfo where CompID=o_CompID) as compname,o_CompName,o_sellType,"
				+ " o_Product,(select ProductName from t_product_definition where ProductId=t.o_Product) as ProductName,"
				+ " (select op_display from t_option where op_param='approveStatus' and op_value=t.o_Status) as approveStatus,"
				+ " (select AdminTrueName from t_admininfo where AdminID=t.o_AdminID) as AdminName,"
				+ " (select AdminTrueName from t_admininfo where adminName=o_CreateUser) as CreateUser,"
				+ " (select op_display from t_option where op_param='TorderType' and op_value=t.o_Type) as orderType,"
				+ " o_totalTime,o_Status,o_AdminID,o_CreateUser,o_CreateTime,id as opid,o_Type,o_amount "
				+ " from t_timeorder t where t.o_CompID='"+o_CompID+"' ";
		
		String sqlTotal = "select count(*) from (select id,o_CompName,o_sellType,o_Product,o_totalTime,o_Status,o_AdminID,"
				+ " o_CreateUser,o_CreateTime from t_timeorder t where t.o_CompID='"+o_CompID+"' ";
		
		sql+=") tb where 1=1 ";
		sqlTotal+=") tb where 1=1 ";
		
		
		if(!"".equals(userName) && userName!=null) 
		{
			sql+= " and tb.o_CompName like '%"+userName+"%'";
			sqlTotal += " and tb.o_CompName like '%"+userName+"%'";
		}
		
		if(!"".equals(product) && product!=null) 
		{
			sql+= " and tb.o_Product='"+product+"'";
			sqlTotal+= " and tb.o_Product='"+product+"'";
		}
		
		if(!"".equals(admin) && admin!=null) 
		{
			sql+= " and tb.o_AdminID='"+admin+"'";
			sqlTotal+= " and tb.o_AdminID='"+admin+"'";
			
		}
		
		if(!"".equals(orderType) && orderType!=null) 
		{
			sql+= " and tb.o_Type='"+orderType+"'";
			sqlTotal+= " and tb.o_Type='"+orderType+"'";
		}
		
		if(!"".equals(orderStatus) && orderStatus!=null) 
		{
			sql+= " and tb.o_Status='"+orderStatus+"'";
			sqlTotal+= " and tb.o_Status='"+orderStatus+"'";
		}
		
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
