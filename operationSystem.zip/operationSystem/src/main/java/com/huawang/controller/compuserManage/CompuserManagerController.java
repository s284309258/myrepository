package com.huawang.controller.compuserManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Compuser")
public class CompuserManagerController 
{
	@RequestMapping(value="/CompuserManager.do")
	public ModelAndView CompuserManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("compuser/CompuserList");
		
		return view;
	}
	
	@RequestMapping(value="/CompuserDetail.do")
	public ModelAndView CompuserDetail(HttpServletRequest request) throws Exception
	{
		String UserID = request.getParameter("UserID");
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap("select UserID,DisplayName,IsSuper,UserName,Telephone,"
				+ " (select CompTrueName from t_compinfo where CompID=t.CompID) as CompTrueName,createtime from  t_userinfo t where UserID="+UserID);
		
		String StartTime = Sqlca.getString("select max(StartTime) as StartTime from t_log_conf_detail where UserID="+UserID);
		ModelAndView view = new ModelAndView("compuser/CompuserDetail");
		view.addObject("detail", list);
		view.addObject("starttime", StartTime);
		return view;
	}
	
	@RequestMapping(value="/SelectHistoryConferenceRecord")
	@ResponseBody
	public Map<String,Object> SelectHistoryConferenceRecord(HttpServletRequest request) throws Exception
	{
		String UserID = request.getParameter("UserID");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select ConfName,Times,StartTime,EndTime,LoginIp from t_log_conf_detail where UserID="+UserID;
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		reMap.put("rows", list);
		reMap.put("total", list.size());
		
		return reMap;
	}
	
	@RequestMapping(value="/SelectCompuserList")
	@ResponseBody
	public Map<String,Object> SelectCompuserList(HttpServletRequest request) throws Exception
	{
		String UserName = request.getParameter("UserName");
		String DisplayName = request.getParameter("DisplayName");
		String Telephone = request.getParameter("Telephone");
		String nobelong = request.getParameter("nobelong");
		String CompID = request.getParameter("CompID");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String params = "";
		
		String sql = "select t.CompID,UserID,UserName,DisplayName,Telephone,(select CompTrueName from t_compinfo where CompID=t.CompID) as CompTrueName,IsSuper,createtime,UserID as uid"
				+ " from t_userinfo t where 1=1 ";
		
		String sqlTotal = "select count(*) from t_userinfo t where 1=1 ";
		
		
		if(!"".equals(UserName) && UserName!=null) 
		{
			params += " and UserName like '%"+UserName+"%'";
			sqlTotal += " and UserName like '%"+UserName+"%'";
		}
		
		if(!"".equals(DisplayName) && DisplayName!=null) 
		{
			params += " and DisplayName like '%"+DisplayName+"%'";
			sqlTotal += " and DisplayName like '%"+DisplayName+"%'";
		}
		
		if(!"".equals(Telephone) && Telephone!=null) 
		{
			params += " and Telephone like '%"+Telephone+"%'";
			sqlTotal += " and Telephone like '%"+Telephone+"%'";
		}
		
		if(!"".equals(CompID) && CompID!=null) 
		{
			params += " and CompID ="+CompID;
			sqlTotal += " and CompID ="+CompID;
		}
		
		if("".equals(params))
		{
			params += " and 1=2 ";
		}
		sql = sql+params;
		
		if("1".equals(nobelong))
		{
			params = "";
			
			sql = "select userId as UserID,'' as UserName,displayName as DisplayName,userPhone as Telephone,'' as CompTrueName,'' as IsSuper,applyTime as createtime,userId as uid"
					+ " from t_user_request where userStatus<>2 ";
			
			sqlTotal = "select count(*) from t_user_request where userStatus<>2 ";
			
			if(!"".equals(DisplayName) && DisplayName!=null) 
			{
				params += " and displayName like '%"+DisplayName+"%'";
				sqlTotal += " and displayName like '%"+DisplayName+"%'";
			}
			
			if(!"".equals(Telephone) && Telephone!=null) 
			{
				params += " and userPhone like '%"+Telephone+"%'";
				sqlTotal += " and userPhone like '%"+Telephone+"%'";
			}
			
			sql = sql+params;
		}
		
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
}
