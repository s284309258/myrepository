package com.huawang.controller.productManage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.pojo.meetingRoom.TProductDefinition;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/productManager")
public class ProductManagerController {
	
	@Autowired
	private MeetingRoomDao productDao;
	static Logger logger = LogManager.getLogger(ProductManagerController.class.getName());
	
	@RequestMapping(value="/selectProduct",method= {RequestMethod.POST,RequestMethod.GET})
	public String selectProductManager(HttpServletRequest request,TProductDefinition productDefinition,Model model) {
		return "product/productList";
	}
	/**
	 * 	产品管理 列表查询
	 * @param request
	 * @param response
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectProductMap",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> selectProductMap(HttpServletRequest request,TProductDefinition productDefinition,Model model) throws Exception{
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String productListSqlCount="SELECT COUNT(1) as cnt FROM t_product_definition t WHERE 1 = 1 ";
		
		String productListSql =
		" SELECT                                                "+
		" t.ProductId AS productId,                             "+
		" t.ProductName AS productName,                         "+
		" t.wDefaultUI AS wDefaultUI,                           "+
		" t.wMainDisplayUI AS wMainDisplayUI,                   "+
		" t.wScreenCount AS wScreenCount,                       "+
		" t.wMaxBitRate AS wMaxBitRate,                         "+
		" t.bMaxBroadcastVideos AS bMaxBroadcastVideos,         "+
		" t.bMaxDownVideos AS bMaxDownVideos,                   "+
		" t.bMaxDownVideosOfChiar AS bMaxDownVideosOfChiar,     "+
		" t.Codeno AS codeNo,                                    "+
		" t.bMaxUpVideos AS bMaxUpVideos,                       "+
		" t.wMaxResolusionW AS wMaxResolusionW,                 "+
		" t.wMaxResolusionH AS wMaxResolusionH,                 "+
		" t.bMaxFrameRate AS bMaxFrameRate,                     "+
		" t.wMaxDownAudios AS wMaxDownAudios,                   "+
		" t.bDocShare AS bDocShare,                             "+
		" t.bMaxOpenDocs AS bMaxOpenDocs,                       "+
		" t.bMaxWBPages AS bMaxWBPages,                         "+
		" t.bScreenShare AS bScreenShare,                       "+
		" t.bDesktopShare AS bDesktopShare,                     "+
		" t.bAppShare AS bAppShare,                             "+
		" t.bRemoteControl AS bRemoteControl,                   "+
		" t.bScreenLabel AS bScreenLabel,                       "+
		" t.bMediaShare AS bMediaShare,                         "+
		" t.bWebShare AS bWebShare,                             "+
		" t.bChatP2P AS bChatP2P,                               "+
		" t.bChatP2All AS bChatP2All,                           "+
		" t.bClientRecord AS bClientRecord,                     "+
		" t.bServerRecord AS bServerRecord,                     "+
		" t.bPSTN AS bPSTN,                                     "+
		" t.bH323GW AS bH323GW,                                 "+
		" t.bTVWall AS bTVWall,                                 "+
		" t.bTerminal AS bTerminal,                             "+
		" t.biOS AS biOS,                                       "+
		" t.bAndroid AS bAndroid,                               "+
		" t.bMultiServer AS bMultiServer,                       "+
		" t.bVote AS bVote,                                     "+
		" t.bFileTrans AS bFileTrans,                           "+
		" t.bFileCabinet AS bFileCabinet,                       "+
		" t.bApplause AS bApplause,                             "+
		" t.bRinging AS bRinging,                               "+
		" t.bAudioP2P AS bAudioP2P,                             "+
		" t.bFreeSpeak AS bFreeSpeak,                           "+
		" t.bAutoSpeek AS bAutoSpeek,                           "+
		" t.bAutoRecvSelfVideo AS bAutoRecvSelfVideo,           "+
		" t.bAutoBroadcastSelfVideo AS bAutoBroadcastSelfVideo, "+
		" t.productDescription AS productDescription,           "+
		" t.ConfMode AS ConfMode,                               "+
		" t.productStruts AS productStruts,                     "+
		" t.productCategory,t.createdate,t.ProductId as pid     "+
		" FROM                                                  "+
		" t_product_definition t                                "+
		" WHERE                                                 "+
		" 1 = 1                                                 ";
		
		
		if(productDefinition.productName!=null && !"".equals(productDefinition.productName))
		{
			productListSql +=" and t.ProductName LIKE '%"+productDefinition.productName+"%'";
			productListSqlCount +=" and t.ProductName LIKE '%"+productDefinition.productName+"%'";
		}
		if(productDefinition.productStruts!=null && !"".equals(productDefinition.productStruts))
		{
			productListSql +=" and t.productStruts='"+productDefinition.productStruts+"'";
			productListSqlCount +=" and t.productStruts='"+productDefinition.productStruts+"'";
		}
		if(productDefinition.productId!=null)
		{
			productListSql +=" and t.ProductId="+productDefinition.productId;
			productListSqlCount +=" and t.ProductId="+productDefinition.productId;
		}
		if(productDefinition.wMaxBitRate!=null && !"".equals(productDefinition.wMaxBitRate))
		{
			if("0".equals(productDefinition.wMaxBitRate))
			{
				productListSql +=" and t.wMaxBitRate <10";
				productListSqlCount +=" and t.wMaxBitRate <10";
			}
			if("1".equals(productDefinition.wMaxBitRate))
			{
				productListSql +=" and t.wMaxBitRate between 10 and 50";
				productListSqlCount +=" and t.wMaxBitRate between 10 and 50";
			}
			if("2".equals(productDefinition.wMaxBitRate))
			{
				productListSql +=" and t.wMaxBitRate between 50 and 100";
				productListSqlCount +=" and t.wMaxBitRate between 50 and 100";
			}
			if("3".equals(productDefinition.wMaxBitRate))
			{
				productListSql +=" and t.wMaxBitRate >100";
				productListSqlCount +=" and t.wMaxBitRate >100";
			}
		}
		if(productDefinition.bMaxBroadcastVideos!=null && !"".equals(productDefinition.bMaxBroadcastVideos))
		{
			if("0".equals(productDefinition.bMaxBroadcastVideos))
			{
				productListSql +=" and t.bMaxBroadcastVideos <10";
				productListSqlCount +=" and t.bMaxBroadcastVideos <10";
			}
			if("1".equals(productDefinition.bMaxBroadcastVideos))
			{
				productListSql +=" and t.bMaxBroadcastVideos between 10 and 50";
				productListSqlCount +=" and t.bMaxBroadcastVideos between 10 and 50";
			}
			if("2".equals(productDefinition.bMaxBroadcastVideos))
			{
				productListSql +=" and t.bMaxBroadcastVideos between 50 and 100";
				productListSqlCount +=" and t.bMaxBroadcastVideos between 50 and 100";
			}
			if("3".equals(productDefinition.bMaxBroadcastVideos))
			{
				productListSql +=" and t.bMaxBroadcastVideos >100";
				productListSqlCount +=" and t.bMaxBroadcastVideos >100";
			}
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			productListSql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
		}
		else
		{
			productListSql +=" limit "+i+","+rows;
		}
		
//		productListSql+=" ORDER BY productId ASC limit "+i+","+rows;
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		ArrayList<Object> productList = Sqlca.getArrayListFromObjStr(productListSql, TProductDefinition.class);
		String total=Sqlca.getString(productListSqlCount);
		for (Object tProductDefinition : productList) {
			TProductDefinition tpd = (TProductDefinition)tProductDefinition;
			String productStruts = tpd.getProductStruts()==null?"":tpd.getProductStruts();
			if(productStruts.equals("0")) {
				productStruts="未上架";
			}else if(productStruts.equals("1")) {
				productStruts="待审核";
			}else {
				productStruts="已上架";
			}
			tpd.setProductStruts(productStruts);
			String wMaxResolusionW = tpd.getwMaxResolusionW();
			String wMaxResolusionH = tpd.getwMaxResolusionH();
			tpd.setwMaxResolusionW(wMaxResolusionW+"*"+wMaxResolusionH);
		}
		map.put("rows", productList);
		map.put("total", total);
		return map;
	}
	
	/***
	 * 删除产品
	 * @return
	 */
	@RequestMapping(value="delProduct")
	@ResponseBody
	public String delProduct(HttpServletRequest request) throws Exception
	{
		String productId = request.getParameter("productId");
		String delsql = "delete from t_product_definition where ProductId=?";
		int cnt = Sqlca.updateObject(delsql, new String[] {productId});
		if(cnt>0) 
		{
			return "success";
		}
		else
		{
			return "fail";
		}
	}
	 
	/**
	 * 	查看产品
	 * @param request
	 * @param productDefinition
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectProductOne",method= {RequestMethod.POST,RequestMethod.GET})
	public String selectProductOne(HttpServletRequest request,TProductDefinition productDefinition,Model model,String type) throws Exception{
			
			//1、查看进入方法 2、编辑进入方法
			type = request.getParameter("type");
			//获取产品ID
			String productId = productDefinition.getProductId(); 
			productDefinition = productDao.getDataByProductId(productId);	//根据ID查询产品信息
			
			String productDefinitionSql =
			" SELECT                                                  "+
			" t.ProductId AS productId,                               "+
			" t.ProductName AS productName,                           "+
			" t.wDefaultUI AS wDefaultUI,                             "+
			" t.wMainDisplayUI AS wMainDisplayUI,                     "+
			" t.wScreenCount AS wScreenCount,                         "+
			" t.wMaxBitRate AS wMaxBitRate,                           "+
			" t.bMaxBroadcastVideos AS bMaxBroadcastVideos,           "+
			" t.bMaxDownVideos AS bMaxDownVideos,                     "+
			" t.bMaxDownVideosOfChiar AS bMaxDownVideosOfChiar,       "+
			" t.Codeno AS codeNo,                                     "+
			" t.bMaxUpVideos AS bMaxUpVideos,                         "+
			" t.wMaxResolusionW AS wMaxResolusionW,                   "+
			" t.wMaxResolusionH AS wMaxResolusionH,                   "+
			" t.bMaxFrameRate AS bMaxFrameRate,                       "+
			" t.wMaxDownAudios AS wMaxDownAudios,                     "+
			" t.bDocShare AS bDocShare,                               "+
			" t.bMaxOpenDocs AS bMaxOpenDocs,                         "+
			" t.bMaxWBPages AS bMaxWBPages,                           "+
			" t.bScreenShare AS bScreenShare,                         "+
			" t.bDesktopShare AS bDesktopShare,                       "+
			" t.bAppShare AS bAppShare,                               "+
			" t.bRemoteControl AS bRemoteControl,                     "+
			" t.bScreenLabel AS bScreenLabel,                         "+
			" t.bMediaShare AS bMediaShare,                           "+
			" t.bWebShare AS bWebShare,                               "+
			" t.bChatP2P AS bChatP2P,                                 "+
			" t.bChatP2All AS bChatP2All,                             "+
			" t.bClientRecord AS bClientRecord,                       "+
			" t.bServerRecord AS bServerRecord,                       "+
			" t.bPSTN AS bPSTN,                                       "+
			" t.bH323GW AS bH323GW,                                   "+
			" t.bTVWall AS bTVWall,                                   "+
			" t.bTerminal AS bTerminal,                               "+
			" t.biOS AS biOS,                                         "+
			" t.bAndroid AS bAndroid,                                 "+
			" t.bMultiServer AS bMultiServer,                         "+
			" t.bVote AS bVote,                                       "+
			" t.bFileTrans AS bFileTrans,                             "+
			" t.bFileCabinet AS bFileCabinet,                         "+
			" t.bApplause AS bApplause,                               "+
			" t.bRinging AS bRinging,                                 "+
			" t.bAudioP2P AS bAudioP2P,                               "+
			" t.bFreeSpeak AS bFreeSpeak,                             "+
			" t.bAutoSpeek AS bAutoSpeek,                             "+
			" t.bAutoRecvSelfVideo AS bAutoRecvSelfVideo,             "+
			" t.bAutoBroadcastSelfVideo AS bAutoBroadcastSelfVideo,   "+
			" t.productDescription AS productDescription,             "+
			" t.ConfMode AS ConfMode,                                 "+
			" t.productStruts AS productStruts,t.productCategory,      "+
			" t.perMinutesPrice,t.perDayPrice,t.perYearPrice,t.perOnePrice,t.productChannel "+
			" FROM                                                    "+
			" t_product_definition t                                  "+
			" WHERE                                                   "+
			" 1 = 1                                                   "+
			" and t.ProductId= '"+productId+"'";
			
			ArrayList<Object> list = Sqlca.getArrayListFromObjStr(productDefinitionSql, TProductDefinition.class);
			productDefinition = (TProductDefinition)list.get(0);
		
			if(type.equals("1")) {
				String wMaxResolusionW = productDefinition.getwMaxResolusionW();
				String wMaxResolusionH = productDefinition.getwMaxResolusionH();
				productDefinition.setwMaxResolusionW(wMaxResolusionW+"*"+wMaxResolusionH);
				model.addAttribute("productDefinition", productDefinition);
				return "product/productInfomation";
			}else {
				String wDefaultUId = productDefinition.getwDefaultUI()==null?"":productDefinition.getwDefaultUI();
				String wMainDisplayUI = productDefinition.getwMainDisplayUI()==null?"":productDefinition.getwMainDisplayUI();
				String wDefaultUI = productDefaultValue(wDefaultUId, wMainDisplayUI);
				if(wDefaultUI.equals("10")) {//代表其他类型
				}
				model.addAttribute("wDefaultUI", wDefaultUI);
				model.addAttribute("productDefinition", productDefinition);
				return "product/updateProduct";
			}
		}
	
	
	
	
	/**
	 * 	保存产品修改信息
	 * @param request
	 * @param productDefinition
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/saveProductOne",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public String saveProduct(HttpServletRequest request,HttpServletResponse response,TProductDefinition productDefinition,Model model) throws Exception{
	
		int  count =0;
		String productId = productDefinition.getProductId(); 
		productDefinition.setProductName(Sqlca.switchLatin1Encoding(productDefinition.getProductName()));
		
		if(null!=productId) {
			//如果默认布局值等于10 则表示其他参数布局
			String uId = productDefinition.getwDefaultUI();
			String wDefaultUId="";String wMainDisplayUI="";
			if(uId.equals("10")) {
				productDefinition.setwDefaultUI("");
				productDefinition.setwMainDisplayUI("");
			}else {
				String DW[] = productDefaultUi(uId);
				wDefaultUId = DW[0];
				wMainDisplayUI= DW[1];
				System.out.println("获取到默认布局："+wDefaultUId+"页面布局："+wMainDisplayUI);
				productDefinition.setwDefaultUI(wDefaultUId);
				productDefinition.setwMainDisplayUI(Sqlca.switchLatin1Encoding(wMainDisplayUI));
			}
			int count1= productDao.checkProductName(productDefinition);
			
			if(count1>0) {
				productId="0";
			}else {
				String wMaxResolusionH = productDefinition.getwMaxResolusionH();
				if(!wMaxResolusionH.equals("")) {
					String str[] = getWMaxResoleusion(wMaxResolusionH);
					productDefinition.setwMaxResolusionH(wMaxResolusionH);
					productDefinition.setwMaxResolusionW(str[1]);
				}
				
				count = productDao.editProductDatas(productDefinition);//执行修改方法
				productDefinition = productDao.getDataByProductId(productId);	//根据ID查询产品信息
				productDefinition.setProductName(Sqlca.switchLatin1Encoding(productDefinition.getProductName()));
				model.addAttribute("productDefinition", productDefinition);
			}
		}
			return productId; 
	}
		/**
		 * 修改产品分辨率宽 高
		 * @param wMaxResolusionH
		 * @return
		 */
		public String[]getWMaxResoleusion(String wMaxResolusionH){
			String wMaxResolusionW ="";
			if(wMaxResolusionH.equals("1080")) {
				wMaxResolusionH="1080";
				wMaxResolusionW ="1920";
			}else if(wMaxResolusionH.equals("720")) {
				wMaxResolusionH="720";
				wMaxResolusionW ="1280";
			}else if(wMaxResolusionH.equals("480")) {
				wMaxResolusionH="480";
				wMaxResolusionW ="640";
			}else if(wMaxResolusionH.equals("360")) {
				wMaxResolusionH="360";
				wMaxResolusionW ="480";
			}else if(wMaxResolusionH.equals("240")) {
				wMaxResolusionH="240";
				wMaxResolusionW ="320";
			}else if(wMaxResolusionH.equals("144")) {
				wMaxResolusionH="144";
				wMaxResolusionW ="192";
			}
			String []str = {wMaxResolusionH,wMaxResolusionW};
			return str;
		}
	
	
	
		/**
		 * 产品默认布局组合
		 * @param status
		 * @return
		 */
		public String[] productDefaultUi(String productStatus) {
			String wDefaultUId = "";
			String wMainDisplayUI="";
			
			if(productStatus.equals("1")) {
				wDefaultUId="13";
				wMainDisplayUI="0";
			}else if(productStatus.equals("2")) {
				wDefaultUId="0";
				wMainDisplayUI="0";
			}else if(productStatus.equals("3")) {
				wDefaultUId="1";
				wMainDisplayUI="0";
			}else if(productStatus.equals("4")) {
				wDefaultUId="8";
				wMainDisplayUI="0";
			}else if(productStatus.equals("5")) {
				wDefaultUId="9";
				wMainDisplayUI="0";
			}else if(productStatus.equals("6")) {
				wDefaultUId="16";
				wMainDisplayUI="0";
			}else if(productStatus.equals("7")) {
				wDefaultUId="0";
				wMainDisplayUI="1";
			}else if(productStatus.equals("8")) {
				wDefaultUId="7";
				wMainDisplayUI="1";
			}else if(productStatus.equals("9")){
				wDefaultUId="2";
				wMainDisplayUI="1";
			}else {
				wDefaultUId = "";
			}
			String[] str = {wDefaultUId+"",wMainDisplayUI};
			return str;
		}
		
		public String productDefaultValue(String wDefaultUId,String wMainDisplayUI) {
			 String uiValue="";
			if(wDefaultUId.equals("13")&&wMainDisplayUI.equals("0")) {
					uiValue="1";
			}else if(wDefaultUId.equals("0")&&wMainDisplayUI.equals("0")) {
					uiValue="2";
			}else if(wDefaultUId.equals("1")&&wMainDisplayUI.equals("0")) {
					uiValue="3";
			}else if(wDefaultUId.equals("8")&&wMainDisplayUI.equals("0")) {
					uiValue ="4";
			}else if(wDefaultUId.equals("9")&&wMainDisplayUI.equals("0")) {
					uiValue="5";
			}else if(wDefaultUId.equals("16")&&wMainDisplayUI.equals("0")) {
					uiValue="6";
			}else if(wDefaultUId.equals("0")&&wMainDisplayUI.equals("1")) {
					uiValue="7";
			}else if(wDefaultUId.equals("7")&&wMainDisplayUI.equals("1")) {
					uiValue="8";
			}else if(wDefaultUId.equals("2")&&wMainDisplayUI.equals("1")){
					uiValue="9";
			}else {
					uiValue = "10";
			}
			return uiValue;
		}
		
	
		
	/**
	 * 	新增产品
	 * @param request
	 * @param productDefinition
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/addProductOne",method= {RequestMethod.POST,RequestMethod.GET},produces = "text/html;charset=UTF-8")
	public String addProduct(HttpServletRequest request,HttpServletResponse response,TProductDefinition productDefinition,Model model) throws Exception{
		
		ModelAndView view = new ModelAndView();
		
		String productCategory = request.getParameter("productCategory");
		if("1".equals(productCategory))
		{
				if(productDefinition.getProductName()!=null) 
				{
					String uId = productDefinition.getwDefaultUI();
					String DW[] = productDefaultUi(uId);
					String wDefaultUId = DW[0];
					String wMainDisplayUI= DW[1];
					System.out.println("获取到默认布局："+wDefaultUId+"页面布局："+wMainDisplayUI);
					productDefinition.setProductName(Sqlca.switchLatin1Encoding(productDefinition.getProductName()));
					productDefinition.setwDefaultUI(wDefaultUId);
					productDefinition.setwMainDisplayUI(wMainDisplayUI);
					productDefinition.setProductStruts("2");			//状态
					productDefinition.setbMaxDownVideosOfChiar(productDefinition.getbMaxDownVideosOfChiar()==null?"36":productDefinition.getbMaxDownVideosOfChiar());	//非主席最大接收视频路数
					productDefinition.setwScreenCount("5");				//支持显示屏数
					productDefinition.setbMaxUpVideos("5");				//最大视频上行路数
					productDefinition.setbAutoRecvSelfVideo("0");			//入会自动观看自己的视频
					productDefinition.setwMaxDownAudios("50");			//最大音频同时发言数
					productDefinition.setbAudioP2P("1"); 				//语音私聊
					
					//productDefinition.setbAutoBroadcastSelfVideo("0");	//入会自动播放自己的视频  0表示否、1 表示 是
					//productDefinition.setbAutoSpeek("0");					//入会自动申请发言
					
					productDefinition.setConfMode("0");					//入会主席模式
					productDefinition.setbMaxWBPages("1000");				//支持白板页数
					productDefinition.setbMaxOpenDocs("3");			//支持同开最大数量
					productDefinition.setbClientRecord("1");				//支持客户端录制
					productDefinition.setbMediaShare("1");				//媒体共享
					productDefinition.setbRemoteControl("1");				//远程协助
					productDefinition.setbDocShare("1");					//文档共享
					productDefinition.setbDesktopShare("1");				//桌面共享 
					productDefinition.setbAppShare("1");					//应用程序共享
					productDefinition.setbScreenShare("1");				//屏幕共享
					productDefinition.setbChatP2P("1");					//文字私聊
					productDefinition.setbChatP2All("1"); 					//文字公聊
					productDefinition.setbTerminal("1"); 					//支持硬件终端
					productDefinition.setbApplause("1");					//掌声
					productDefinition.setBiOS("1");						//支持IOS
					productDefinition.setbAndroid("1");					//支持安卓
					
					int count1= productDao.checkProductName(productDefinition);
					if(count1>0) {
						return "fali";
					}else {
						String str[] = getWMaxResoleusion(productDefinition.getwMaxResolusionH());
						productDefinition.setwMaxResolusionH(productDefinition.getwMaxResolusionH());
						productDefinition.setwMaxResolusionW(str[1]);
						productDao.addDatas(productDefinition);//添加产品
						return "success";
					}
				}
			return null;
		}
		else if("2".equals(productCategory))
		{
			String productName = request.getParameter("productName");
			String perOnePrice = request.getParameter("perOnePrice");
			String productDescription = request.getParameter("productDescription");
			String sql = "insert into t_product_definition(Codeno,productCategory,productname,perOnePrice,productDescription) values(1,?,?,?,?)";
			
			Sqlca.updateObject(sql, new String[] {productCategory,productName,perOnePrice,productDescription});
			return "success";
		}
		else {
			System.out.println("没有数据进入新增页");
			return "product/addProduct";
		}
	}
	
	/**
	 * 	产品上架
	 * @param request
	 * @param productDefinition
	 * @param model
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value="/upperFrame",method={RequestMethod.POST,RequestMethod.GET})
	public String upperFrame(HttpServletResponse response,TProductDefinition productDefinition,Model model) throws IOException {
		
		String productStruts ="2";
		String mess ="";
		productDefinition.setProductStruts(productStruts);
		int count = productDao.editProductDatas(productDefinition);
		if(count>0) {
			mess ="上架成功";
		}else {
			mess="上架失败！";
		}
		response.getWriter().write(mess);
		response.getWriter().flush();
		response.getWriter().close();
		return null;
	}
	
	
	
	@RequestMapping(value="/checkProduct",method={RequestMethod.POST,RequestMethod.GET})
	public String checkProduct(HttpServletRequest request,HttpServletResponse response,TProductDefinition productDefinition,Model model) throws Exception { 
		
		String productId =null;
		productId = request.getParameter("productId");
		productId =new String(productId.getBytes("ISO8859_1"),"GB2312");
		productDefinition = productDao.getDataByProductId(productId);	//根据ID查询产品信息
		productDefinition.setProductName(Sqlca.switchLatin1Encoding(productDefinition.getProductName()));
		model.addAttribute("productDefinition", productDefinition);
		return "product/checkProduct";
	}
	
	
	

	}

















