package com.huawang.controller.meetingManage;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huawang.dao.meetingRoom.MeetingRoomDao;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.pojo.meetingRoom.TCompinfo;
import com.huawang.pojo.meetingRoom.TConfinfo;
import com.huawang.pojo.meetingRoom.TLogConfDetail;
import com.huawang.util.Sqlca;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

@Controller
@RequestMapping(value="/meeting")
public class MeetingManagerController {
	
	static Logger logger = LogManager.getLogger(MeetingManagerController.class.getName());
	@Autowired
	private MeetingRoomDao meetingDao; 
	
	@RequestMapping(value="/selectMeetingManager",method= {RequestMethod.POST,RequestMethod.GET})
	public String selectMeetingManager(HttpServletRequest request,TConfinfo confinfo,Model model) throws Exception{
 
		List<Object> li = Sqlca.getArrayListFromObj("select  AdminTrueName from t_admininfo where 1=1 ", TConfinfo.class);
		String sql = " select  ServerId,concat(ServerName,'-',ServerIp) as ServerIP from t_serverinfo where 1=1 "+
		" AND (( ServerType = '0' AND IsPad = '0' ) OR ( ServerType = '1' AND IsPad = '0')OR (ServerType = '0' AND IsPad = '1'))";
		List<Object> getServerIPList = Sqlca.getArrayListFromObj(sql, TConfinfo.class);
		model.addAttribute("getServerIPList", getServerIPList);
		model.addAttribute("serverlist", li);
		return "meeting/meetingRoom";
	}
	
	/**
	 * 	会议查询列表
	 * @param request
	 * @param confinfo
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/selectMeetingManagerMap",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public Map<String, Object> selectMeetingManagerMap(HttpServletRequest request,TConfinfo confinfo,HttpSession session) throws Exception {
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
		
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			
			Object obj = session.getAttribute("USER_SESSION");
			int aid = 99999;
			String roledata = "";
			String dpid = "";
			String createuser = "";
			if(obj!=null)
			{
				TAdmininfo a = (TAdmininfo)obj;
				aid = a.getAdminId();
				String roleid = a.getRole();
				createuser = a.getAdminName();
				roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
				dpid = a.getDpId();
			}
			
			String meetingdatasCount = " SELECT                               "+
					 " 	COUNT(1) as cnt                                       "+
					 " FROM                                                   "+
					 " 	t_confinfo t1                                         "+
					 " LEFT JOIN t_compinfo t2 ON t1.CompID = t2.CompID       "+
					 " LEFT JOIN t_admininfo t3 ON t2.AdminID = t3.AdminID    "+
					 " LEFT JOIN t_serverinfo t4 ON t1.ServerId=t4.ServerID   "+
					 " WHERE                                                  "+
					 " 	1 = 1                                                 ";
			
			
			String meetingdatas =
			" SELECT                                                "+
			" 	t1.Codeno AS codeNo,                                "+
			" 	t1.ConfID AS confId,                                "+
			" 	t1.ConfName AS confName,                            "+
			" 	t1.CurUserCount AS curUserCount,                    "+
			" 	t1.IsOnOff AS isOnOff,                              "+
			" 	t1.ServerId AS serverId,                            "+
			" 	t2.CompTrueName AS compTrueName,                    "+
			" 	t2.CompName,                    "+
			" 	t3.AdminName AS adminName,                          "+
			" 	t3.AdminTrueName AS adminTrueName,t1.CompID,t1.maxUserCount,                  "+
			" 	concat(t4.ServerName,'-',t4.ServerIP) AS serverIp   "+
			" 	                                                    "+
			" FROM                                                  "+
			" 	t_confinfo t1                                       "+
			" LEFT JOIN t_compinfo t2 ON t1.CompID = t2.CompID     "+
			" LEFT JOIN t_admininfo t3 ON t2.AdminID = t3.AdminID   "+
			" LEFT JOIN t_serverinfo t4 ON t1.ServerId=t4.ServerID  "+
			" WHERE                                                 "+
			" 	1 = 1                                               ";
			
			if("1".equals(roledata))
			{
				
			}
			else if("2".equals(roledata))
			{
				meetingdatas += " and t2.CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
				
				meetingdatasCount += " and t2.CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
			}
			else if("3".equals(roledata)) 
			{
				meetingdatas += " and t2.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
			
				meetingdatasCount += " and t2.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
			}
			
			
			if(null!=confinfo.confName && !"".equals(confinfo.confName))
			{
				meetingdatas +=" and t1.ConfName LIKE '%"+ confinfo.confName +"%'";
				meetingdatasCount += " and t1.ConfName LIKE '%"+ confinfo.confName +"%'";
			}
			if(null!=confinfo.curUserCount)
			{
				if(confinfo.curUserCount==1)
				{
					meetingdatas +=" and t1.curUserCount <50";
					meetingdatasCount +=" and t1.curUserCount <50";
				}
				if(confinfo.curUserCount==2)
				{
					meetingdatas +=" and t1.curUserCount between 50 and 100";
					meetingdatasCount +=" and t1.curUserCount between 50 and 100";
				}
				if(confinfo.curUserCount==3)
				{
					meetingdatas +=" and t1.curUserCount >100";
					meetingdatasCount +=" and t1.curUserCount >100";
				}
			}
			if(confinfo.serverId!=null)
			{
				meetingdatas +=" and t4.ServerId="+confinfo.serverId;
				meetingdatasCount +=" and t4.ServerId="+confinfo.serverId;
			}
			if(confinfo.confId!=null)
			{
				meetingdatas +=" and t1.ConfID="+confinfo.confId;
				meetingdatasCount +=" and t1.ConfID="+confinfo.confId;
			}
			if(confinfo.compTrueName!=null && !"".equals(confinfo.compTrueName))
			{
				meetingdatas +=" and t2.CompTrueName LIKE '%"+ confinfo.compTrueName +"%'";
				meetingdatasCount +=" and t2.CompTrueName LIKE '%"+ confinfo.compTrueName +"%'";
			}
			if(confinfo.adminId!=null)
			{
				meetingdatas +=" and t3.AdminID = '"+confinfo.adminId+"'";
				meetingdatasCount +=" and t3.AdminID = '"+confinfo.adminId+"'";
			}
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				meetingdatas +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
			}
			else
			{
				meetingdatas +=" limit "+i+","+rows;
			}
			
//			meetingdatas +=" ORDER BY t1.ConfID DESC limit "+i+","+rows;
			
			HashMap<String,Object> map = new HashMap<String,Object>();
			ArrayList<Object> meetList = Sqlca.getArrayListFromObj(meetingdatas, TConfinfo.class);
			String cnt = Sqlca.getString(meetingdatasCount);
			
			for (Object tConfinfo : meetList) 
			{
				TConfinfo tc = (TConfinfo)tConfinfo;
				String isOnOff = tc.getIsOnOff();
				if(isOnOff.equals("0")) {
					isOnOff="停止";
				}else {
					isOnOff="启用";
				}
				tc.setIsOnOff(isOnOff);
				tc.setServerId(tc.getServerId());//需交互的id
			}
			map.put("rows", meetList);
			map.put("total", cnt); 
			return map;
		}
	
		/**
		 * 切换服务器
		 * @param request
		 * @param confinfo
		 * @param model
		 * @return
		 * @throws IOException 
		 */
		@RequestMapping(value="/confIdToServerId",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String confIdToServerId(HttpServletRequest request,HttpServletResponse response,TConfinfo confinfo,Model model) throws Exception {
			
			int confid  = confinfo.getConfId();
			int serverId = confinfo.getServerId();
			System.out.println("获取到confid:"+confid);
//			int coun = meetingDao.updateServerIp(confinfo);
			Sqlca.updateObject("UPDATE t_confinfo set ServerId = "+serverId+" where ConfID = "+confid, new String[] {});
			return "success";
		}
		
		
		/**
		 * 批量切换服务器
		 * @param request
		 * @param confinfo
		 * @param model
		 * @return
		 * @throws IOException 
		 */
		@RequestMapping(value="/BatchTransformServerId",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public String BatchTransformServerId(HttpServletRequest request,HttpServletResponse response) throws Exception 
		{
			String[] compids = request.getParameterValues("compid[]");
			String servierid = request.getParameter("serverid");
			if(servierid==null) {servierid="";}
			
			if(!"".equals(servierid) && compids.length>0) 
			{
				for(String compid : compids)
				{
					Sqlca.updateObject("UPDATE t_confinfo set ServerId = "+servierid+" where CompID = "+compid, new String[] {});
				}
			}
			return "success";
		}
	
		@RequestMapping(value="/selectMeetStatistics",method= {RequestMethod.POST,RequestMethod.GET})
		public String selectMeetStatistics(HttpServletRequest request,TCompinfo tCompinfo,Model model) throws UnsupportedEncodingException {
			return "meeting/meetStatistics";
		}
		
		/**
		 * 会议统计查询
		 * @param request
		 * @param response
		 * @param tCompinfo
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/selectMeetStatisticsMap",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public Map<String, Object> selectMeetStatisticsMap(HttpServletRequest request,TCompinfo tCompinfo,HttpSession session) throws Exception {
			
			String roledata = "";
			String dpid = "";
			Integer aid = 0;
			Object obj = session.getAttribute("USER_SESSION");
			if(obj!=null)
			{
				TAdmininfo a = (TAdmininfo)obj;
				aid = a.getAdminId();
				String roleid = a.getRole();
				roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
				dpid = a.getDpId();
			}
			
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
			
			String startTime = tCompinfo.getStartTime();
			if(startTime==null || "".equals(startTime)) 
			{
				startTime="99";
			}
			tCompinfo.setStartTime(startTime);
//			if(tCompinfo.getCompTrueName()!=null&&tCompinfo.getCompTrueName()!="") {
//				String compTrueName = (Sqlca.switchLatin1Encoding(tCompinfo.getCompTrueName()));
//				tCompinfo.setCompTrueName(compTrueName);
//			}
			
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			
//			int total=meetingDao.getmeetingStatisticsDatasCounts(tCompinfo);
//			 
//			List<TCompinfo>statisList = new ArrayList<TCompinfo>();
//			
//			statisList =meetingDao.getmeetingStatisticsDatas(tCompinfo,i,Integer.parseInt(rows));
			
			String statisListSqlCount = 
			" select count(*) as cnt "+ 
			" FROM t_meeting_statistical where 1=1 " ;
			
			String statisListSql ="select "+
			" 	compId,                   "+
			"   compName,"+
			" 	compTrueName,             "+
			" 	sumUser,                  "+
			" 	sumTime,                  "+
			" 	avgTime,                  "+
			" 	meetNum,                  "+
			" 	startTime,                "+
			" 	endTime                   "+
			" FROM t_meeting_statistical  "+
			" WHERE                       "+
			" 	1 = 1                     ";
			
			if("1".equals(roledata))
			{
				
			}
			else if("2".equals(roledata))
			{
				statisListSql += " and CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
				
				statisListSqlCount += " and CompID in(select tt.compID from t_compinfo tt "
						+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
			}
			else if("3".equals(roledata)) 
			{
				statisListSql += " and CompID in(select tt.compID from t_compinfo tt where tt.adminID="+aid+") ";
				
				statisListSqlCount += " and CompID in(select tt.compID from t_compinfo tt where tt.adminID="+aid+") ";
			}
			
			if(tCompinfo.compTrueName!=null && !"".equals(tCompinfo.compTrueName))
			{
				statisListSql +=" and CompTrueName like '%" +tCompinfo.compTrueName+ "%'";
				statisListSqlCount +=" and CompTrueName like '%" +tCompinfo.compTrueName+ "%'";
			}
			
			if(tCompinfo.startTime!=null && !"".equals(tCompinfo.startTime))
			{
				statisListSql +=" and Datetype = '"+tCompinfo.startTime+"'";
				statisListSqlCount +=" and Datetype = '"+tCompinfo.startTime+"'";
			}
			
			if(null!=SortName && !"".equals(SortName)) 
			{
				statisListSql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
			}
			else
			{
				statisListSql +=" limit "+i+","+rows;
			}
			
			HashMap<String,Object> map = new HashMap<String,Object>();
			ArrayList<Object> statisList = Sqlca.getArrayListFromObj(statisListSql, TCompinfo.class);
			String total = Sqlca.getString(statisListSqlCount);
//			for (TCompinfo tCompinfo2 : statisList) {
//				tCompinfo2.setCompTrueName(Sqlca.switchUtf8Encoding(tCompinfo2.getCompTrueName()==null?"".getBytes():tCompinfo2.getCompTrueName().getBytes()));
//			}
			map.put("rows", statisList);
			map.put("total", total); 
			return map;
		}
		
		
		@RequestMapping(value="/selectCompanyDetail",method= {RequestMethod.POST,RequestMethod.GET})
		public String selectCompanyDetail(HttpServletRequest request,TConfinfo tConfinfo,Model model) throws Exception {
		
			String compame = Sqlca.getString("select CompTrueName from t_compinfo t where t.CompID='"+tConfinfo.getCompId()+"'");
			model.addAttribute("compId", tConfinfo.getCompId());
			model.addAttribute("confName1", compame);
			return "meeting/MeetingDetailCompany";
		}
		
		/**
		 * 企业会议详情查询
		 * @param request
		 * @param tConfinfo
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/selectCompanyDetailMap",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public Map<String, Object> selectCompanyDetailMap(HttpServletRequest request,TConfinfo tConfinfo,Model model) throws Exception {
			
//			if(tConfinfo.getConfName()!=null && tConfinfo.getConfName()!="") {
//				String confName = Sqlca.switchLatin1Encoding(tConfinfo.getConfName());
//				tConfinfo.setConfName(confName);
//			}
			
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
//			int total = meetingDao.getMeetingDetailDatasCounts(tConfinfo);
			
//			List<TConfinfo>companyList = new ArrayList<TConfinfo>();
//			HashMap<String,Object> map = new HashMap<String,Object>();
//			companyList =meetingDao.getMeetingDetailDatas(tConfinfo,i,Integer.parseInt(rows));
			
			String companyListSqlCount = 
					" select count(*) as cnt " +
							" from (                                                                                                " +
							" select t1.CompID,t1.AdminID,t2.ConfID,t2.CurUserCount,t2.ConfName                                     " +
							" from t_compinfo t1,t_confinfo t2 where t1.CompID=t2.CompID) tt,                                       " +
							" t_log_conf t3 where t3.ConfID=tt.ConfID                                                               " ;
			
			String companyListSql=
			" select (SELECT maxUserCount FROM t_confinfo WHERE tt.ConfID =ConfID) AS maxUserCount,"
			+ "tt.CompID,tt.ConfID as confId,t3.logConfID,t3.MaxCount as curUserCount,tt.ConfName as confName," +
			" StartTime as startTime,EndTime as endTime                                                             " +
			" from (                                                                                                " +
			" select t1.CompID,t1.AdminID,t2.ConfID,t2.CurUserCount,t2.ConfName                                     " +
			" from t_compinfo t1,t_confinfo t2 where t1.CompID=t2.CompID) tt,                                       " +
			" t_log_conf t3 where t3.ConfID=tt.ConfID                                                               " ;
			
			if(tConfinfo.confName!=null && !"".equals(tConfinfo.confName))
			{
				companyListSql+= " and tt.ConfName LIKE '%"+tConfinfo.confName+"%'";
				companyListSqlCount+= " and tt.ConfName LIKE '%"+tConfinfo.confName+"%'";
			}
			if(tConfinfo.curUserCount!=null)
			{
				if(tConfinfo.curUserCount==0)
				{
					companyListSql += " and t3.MaxCount < 10";
					companyListSqlCount += " and t3.MaxCount < 10";
				}
				if(tConfinfo.curUserCount==1)
				{
					companyListSql += " and t3.MaxCount between 10 and 50";
					companyListSqlCount += " and t3.MaxCount < 10";
				}
				if(tConfinfo.curUserCount==2)
				{
					companyListSql += " and t3.MaxCount between 50 and 100";
					companyListSqlCount += " and t3.MaxCount < 10";
				}
				if(tConfinfo.curUserCount==3)
				{
					companyListSql += " and t3.MaxCount >100";
					companyListSqlCount += " and t3.MaxCount < 10";
				}
			}
			if(tConfinfo.startTime!=null && !"".equals(tConfinfo.startTime))
			{
				if("7".equals(tConfinfo.startTime))
				{
					companyListSql +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
					companyListSqlCount +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
				}
				if("30".equals(tConfinfo.startTime))
				{
					companyListSql +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 month)) and NOW()";
					companyListSqlCount +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
				}
				if("180".equals(tConfinfo.startTime))
				{
					companyListSql +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 2 quarter)) and NOW()";
					companyListSqlCount +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
				}
				if("365".equals(tConfinfo.startTime))
				{
					companyListSql +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 year)) and NOW()";
					companyListSqlCount +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
				}
			}
			if(tConfinfo.confId!=null)
			{
				companyListSql +=" and tt.confId= "+tConfinfo.confId;
				companyListSqlCount +=" and tt.confId= "+tConfinfo.confId;
			}
			if(tConfinfo.compId!=null)
			{
				companyListSql +=" and tt.CompID="+tConfinfo.compId;
				companyListSqlCount +=" and tt.CompID="+tConfinfo.compId;
			}
			companyListSql +=" ORDER BY StartTime desc ";
			companyListSql += " limit "+i+","+rows;
			HashMap<String,Object> map = new HashMap<String,Object>();
			ArrayList<Object> companyList = Sqlca.getArrayListFromObj(companyListSql, TConfinfo.class);
			String total = Sqlca.getString(companyListSqlCount);
			map.put("rows", companyList);
			map.put("total", total);
			return map;
		}
		
		@RequestMapping(value="/selectSpecificDetail",method= {RequestMethod.POST,RequestMethod.GET})
		public String selectSpecificDetail(HttpServletRequest request,TLogConfDetail tLogConfDetail,Model model) throws Exception {
			String confName1=null;int logConfId=0;
//			List<TLogConfDetail> logDetailList = meetingDao.getLOGDetailDatas(tLogConfDetail,0,5);
//			for (TLogConfDetail tLogConfDetail2 : logDetailList) {
//				confName1=Sqlca.switchUtf8Encoding(tLogConfDetail2.getConfName().getBytes());
//			}
			confName1 =Sqlca.getString("select ConfName from t_log_conf_detail t where t.LogConfID="+tLogConfDetail.logConfId);
			logConfId= tLogConfDetail.getLogConfId();
			model.addAttribute("logConfId", logConfId);
			model.addAttribute("confName1", confName1);
			return "meeting/meetingDetailSpecific";
		}
		
		
		/**
		 * 具体会议详情查询
		 * @param request
		 * @param tConfinfo
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/selectSpecificDetailMap",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public Map<String, Object> selectSpecificDetailMap(HttpServletRequest request,TLogConfDetail tLogConfDetail,Model model) throws Exception {
			
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows); 
			
			String logDetailListSqlCount=
					" SELECT  count(*) as cnt "+
							" FROM                                                   "+
							" t_log_conf_detail t                                    "+
							" WHERE                                                  "+
							" t.logConfID="+tLogConfDetail.logConfId;
			
			String logDetailListSql =
			" SELECT                                                 "+
			" t.detailId AS detailId,                                "+
			" t.LogConfID AS logConfId,                              "+
			" t.UserName AS userName,                                "+
			" t.StartTime AS startTime,                              "+
			" t.EndTime AS endTime,                                  "+
			" t.Times AS times,                                      "+
			" t.ConfID AS confId,                                    "+
			" t.ConfName AS confName,                                "+
			" CONCAT(t.LoginIp,region) as loginIp                    "+
			" FROM                                                   "+
			" t_log_conf_detail t                                    "+
			" WHERE                                                  "+
			" t.logConfID="+tLogConfDetail.logConfId;
			
			if(tLogConfDetail.userName!=null && !"".equals(tLogConfDetail.userName))
			{
				logDetailListSql+=" and t.UserName LIKE '%"+tLogConfDetail.userName+"%'";
				logDetailListSqlCount+=" and t.UserName LIKE '%"+tLogConfDetail.userName+"%'";
			}
			if(tLogConfDetail.confName!=null && !"".equals(tLogConfDetail.confName))
			{
				logDetailListSql+=" and t.ConfName LIKE '%"+tLogConfDetail.confName+"%'";
				logDetailListSqlCount+=" and t.ConfName LIKE '%"+tLogConfDetail.confName+"%'";
			}
			if(tLogConfDetail.confId!=null)
			{
				logDetailListSql+="and t.ConfID = "+tLogConfDetail.confId;
				logDetailListSqlCount+="and t.ConfID = "+tLogConfDetail.confId;
			}
			logDetailListSql+=" limit "+i+","+rows;
			
			HashMap<String,Object> map = new HashMap<String,Object>();
			ArrayList<Object> logDetailList = Sqlca.getArrayListFromObj(logDetailListSql, TLogConfDetail.class);
			String total = Sqlca.getString(logDetailListSqlCount);
			map.put("rows", logDetailList);
			map.put("total", total);
			return map;
		}
		
		
		
		
		@RequestMapping(value="/selectCustomerInfo",method= {RequestMethod.POST,RequestMethod.GET})
		public String selectCustomerInfo(HttpServletRequest request,TCompinfo tCompinfo,Model model) {
		
			return "meeting/customerQueryList";
		}
		
		
		/**
		 *	 统计查询--客户查询
		 * @param request
		 * @param tCompinfo
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/selectCustomerInfoMap",method= {RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public Map<String, Object> selectCustomerInfoMap(HttpServletRequest request,HttpSession session,TCompinfo tCompinfo,Model model) throws Exception{
			
			String SortName = request.getParameter("sort");
			String SortValue =request.getParameter("order");
			
			if(null!=tCompinfo.getCompTrueName() && !"".equals(tCompinfo.getCompTrueName())) {
				model.addAttribute("compTrueName", tCompinfo.getCompTrueName());
				//tCompinfo.setCompTrueName(Sqlca.switchLatin1Encoding(tCompinfo.getCompTrueName()));
			}else if(null!=tCompinfo.getCompName() && "".equals(tCompinfo.getCompName())) {
				model.addAttribute("compName", tCompinfo.getCompName());
				//tCompinfo.setCompName(Sqlca.switchLatin1Encoding(tCompinfo.getCompName()));
			}else if(null!=tCompinfo.getConfId()) {
				model.addAttribute("confId", tCompinfo.getConfId());
				//tCompinfo.setConfId(tCompinfo.getConfId());
			}
			String page = request.getParameter("page");
			String rows = request.getParameter("rows");
			int i = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
			
			Object obj = session.getAttribute("USER_SESSION");
			int aid = 99999;
			String roledata = "";
			String dpid = "";
			String createuser = "";
			if(obj!=null)
			{
				TAdmininfo a = (TAdmininfo)obj;
				aid = a.getAdminId();
				String roleid = a.getRole();
				createuser = a.getAdminName();
				roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
				dpid = a.getDpId();
			}
			
			String customerListCount = "";
			
			String customerListSql="";
			
			if(tCompinfo.confId!=null)
			{
				customerListSql =" select compId,compId as compId1,compTrueName,(select t.AdminTrueName from t_admininfo t where t.AdminID=tt.AdminID) as adminTrueName,"+
						" compStatus,compName,lianxr,lianxrtel from t_compinfo tt where tt.CompID                                            "+
						" in(select tc.CompID from t_confinfo tc where tc.confid="+tCompinfo.confId+")                       ";
				
				customerListCount = " select count(*) from t_compinfo tt where tt.CompID "+
						" in(select tc.CompID from t_confinfo tc where tc.confid="+tCompinfo.confId+")";
				
				if("1".equals(roledata))
				{
					
				}
				else if("2".equals(roledata))
				{
					customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt "
							+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
					
					customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt "
							+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
				}
				else if("3".equals(roledata)) 
				{
					customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
				
					customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
				}
				
				if(null!=SortName && !"".equals(SortName)) 
				{
					customerListSql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
				}
				else
				{
					customerListSql +=" limit "+i+","+rows;
				}
				
			}
			else
			{
				if(tCompinfo.compName!=null && !"".equals(tCompinfo.compName))
				{
					customerListSql =
					" select compId,compId as compId1,compTrueName,                                                                        "+
							" (select t.AdminTrueName from t_admininfo t where t.AdminID=tt.AdminID) as adminTrueName,           "+
							" compStatus,compName,lianxr,lianxrtel from t_compinfo tt                                            "+
							" WHERE CompID IN(select CompID from t_userinfo where UserName='"+tCompinfo.compName+"') ";
					
					customerListCount =
							" select count(*) from t_compinfo tt                                            "+
									" WHERE CompID IN(select CompID from t_userinfo where UserName='"+tCompinfo.compName+"')";
					
					if("1".equals(roledata))
					{
						
					}
					else if("2".equals(roledata))
					{
						customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt "
								+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
						
						customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt "
								+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
					}
					else if("3".equals(roledata)) 
					{
						customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
					
						customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
					}
					
					if(null!=SortName && !"".equals(SortName)) 
					{
						customerListSql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
					}
					else
					{
						customerListSql +=" limit "+i+","+rows;
					}
					
				}
				else
				{
					customerListSql =
					" select compId,compId as compId1,compTrueName,                                                              "+
							" (select t.AdminTrueName from t_admininfo t where t.AdminID=tt.AdminID) as adminTrueName, "+
							" compStatus,compName,lianxr,lianxrtel from t_compinfo tt                                  "+
							" WHERE 1 = 1                                                                              ";
					
					customerListCount =
							" select count(*) as cnt from t_compinfo tt                                  "+
									" WHERE 1 = 1                                                        ";
					if(tCompinfo.compTrueName!=null && !"".equals(tCompinfo.compTrueName))
					{
						customerListSql += " and tt.CompTrueName  LIKE '%"+tCompinfo.compTrueName+"%'"; 
						customerListCount += " and tt.CompTrueName  LIKE '%"+tCompinfo.compTrueName+"%'"; 
					}
					
					if("1".equals(roledata))
					{
						
					}
					else if("2".equals(roledata))
					{
						customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt "
								+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
						
						customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt "
								+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
					}
					else if("3".equals(roledata)) 
					{
						customerListSql += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
					
						customerListCount += " and tt.CompID in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
					}
					
					if(null!=SortName && !"".equals(SortName)) 
					{
						customerListSql +=" order by "+SortName+" "+SortValue+" limit "+i+","+rows;
					}
					else
					{
						customerListSql +=" limit "+i+","+rows;
					}
//					customerListSql += "limit "+i+","+rows;
					
				}
				
			}
			
			HashMap<String,Object> map = new HashMap<String,Object>();
			
			ArrayList<Object> customerList = Sqlca.getArrayListFromObj(customerListSql, TCompinfo.class);
			String total = Sqlca.getString(customerListCount);
			
			map.put("rows", customerList);
			map.put("total", total); 
			return map;
		}
		/**
		 * 会议统计导出数据 公共方法
		 * @param request
		 * @param response
		 * @param tCompinfo
		 * @param model
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(value="/statisticsExport",method= {RequestMethod.POST,RequestMethod.GET})
		public String statisticsExport(HttpServletRequest request,HttpServletResponse response,TCompinfo tCompinfo,HttpSession session) throws Exception {
			
			Object obj = session.getAttribute("USER_SESSION");
			int aid = 99999;
			String roledata = "";
			String dpid = "";
			String createuser = "";
			if(obj!=null)
			{
				TAdmininfo a = (TAdmininfo)obj;
				aid = a.getAdminId();
				String roleid = a.getRole();
				createuser = a.getAdminName();
				roledata = Sqlca.getString("select role_data from t_roles where role_id='"+roleid+"'");
				dpid = a.getDpId();
			}
			
			SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
			String date = df1.format(new Date());
			String type = request.getParameter("type");
			String fileName ="";
			String tmptitle ="";
				try 
				{ 
					if(type.equals("1")) {
						fileName= "会议统计"+date+".xls";
						tmptitle = "会议统计"; // 标题   
					}else if(type.equals("2")) {
						String confName1 = request.getParameter("confName1");
						fileName= confName1 +date+".xls";
						tmptitle = confName1; // 标题   
					}else {
						String confName = request.getParameter("confName");
						fileName= confName+date+".xls";
						tmptitle = confName; // 标题   
					}
					OutputStream os = response.getOutputStream();// 取得输出流   
					response.reset();// 清空输出流   
					response.setContentType("application/vnd.ms-excel;charset=utf-8");
					response.setHeader("Content-Disposition", "attachment;filename="+ new String((fileName).getBytes(), "iso-8859-1")); 
					response.setContentType("application/msexcel");// 定义输出类型 
					WritableWorkbook wbook = Workbook.createWorkbook(os); // 建立excel文件   
					WritableSheet wsheet = wbook.createSheet(tmptitle, 0); // sheet名称  
					// 设置excel标题   
					WritableFont wfont = new WritableFont(WritableFont.ARIAL, 16,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
					WritableCellFormat wcfFC = new WritableCellFormat(wfont); 
					wsheet.addCell(new Label(0, 0, tmptitle, wcfFC));   
					wfont = new jxl.write.WritableFont(WritableFont.ARIAL, 14,WritableFont.BOLD,false, UnderlineStyle.NO_UNDERLINE,Colour.BLACK);   
					wcfFC = new WritableCellFormat(wfont);  
					
					if(type.equals("1")) {
						String startTime = tCompinfo.getStartTime();
						if(startTime==null || "".equals(startTime)) 
						{
							startTime="99";
						}
						tCompinfo.setStartTime(startTime);
						String compTrueName = request.getParameter("compTrueName");
						if(compTrueName!=null && compTrueName!="") {
//							tCompinfo.setCompTrueName(Sqlca.switchLatin1Encoding(compTrueName));
							tCompinfo.setCompTrueName(compTrueName);
						}
						
//						int total=meetingDao.getmeetingStatisticsDatasCounts(tCompinfo);
						String getmeetingStatisticsDatasCounts = " select count(*) as cnt "+
							" FROM t_meeting_statistical where 1=1 ";
						String total = Sqlca.getString(getmeetingStatisticsDatasCounts);
						
						
//						List<TCompinfo> tomList =meetingDao.getmeetingStatisticsDatas(tCompinfo,0,total);
						String getmeetingStatisticsDatas = " SELECT compId,compTrueName,sumUser,sumTime,avgTime,meetNum,startTime,endTime FROM t_meeting_statistical WHERE 1 = 1 ";
						if(tCompinfo.compTrueName!=null && !"".equals(tCompinfo.compTrueName))
						{
							getmeetingStatisticsDatas += " and CompTrueName like '%"+tCompinfo.compTrueName+"%'";
						}
						if(tCompinfo.startTime!=null && !"".equals(tCompinfo.startTime))
						{
							getmeetingStatisticsDatas += " and Datetype = '"+tCompinfo.startTime+"'";
						}
						
						if("1".equals(roledata))
						{
							
						}
						else if("2".equals(roledata))
						{
							getmeetingStatisticsDatas += " and compId in(select tt.compID from t_compinfo tt "
									+ " where tt.adminID in(select AdminID from t_admininfo t where t.DpID='"+dpid+"'))";
						}
						else if("3".equals(roledata)) 
						{
							getmeetingStatisticsDatas += " and compId in(select tt.compID from t_compinfo tt where tt.adminID='"+aid+"') ";
						}
						
						getmeetingStatisticsDatas += " limit "+0+","+total;
						
						ArrayList<Object> tomList = Sqlca.getArrayListFromObj(getmeetingStatisticsDatas, TCompinfo.class);
						// 开始生成主体内容                    
						wsheet.addCell(new Label(0, 1, "客户ID"));
						wsheet.addCell(new Label(1, 1, "客户名称"));
						wsheet.addCell(new Label(2, 1, "会议总人次"));
						wsheet.addCell(new Label(3, 1, "总时长/min"));  
						wsheet.addCell(new Label(4, 1, "人均时长(单次)/min"));  
						wsheet.addCell(new Label(5, 1, "开会总数/场"));  
						int i=0;
						for(Object mt: tomList)   {   
							TCompinfo m = (TCompinfo)mt;
							wsheet.addCell(new Label(0, i+2, m.getCompId().toString()==null?"0":m.getCompId().toString()));   
							//wsheet.addCell(new Label(1, i+2, Sqlca.switchUtf8Encoding(m.getCompTrueName().getBytes())));  
							wsheet.addCell(new Label(1, i+2,  m.getCompTrueName()));  
							wsheet.addCell(new Label(2, i+2,  m.getSumUser()+""));  
							wsheet.addCell(new Label(3, i+2,  m.getSumTime()+""));  
							wsheet.addCell(new Label(4, i+2,  m.getAvgTime()+""));  
							wsheet.addCell(new Label(5, i+2,  m.getMeetNum()+""));  
							i++;
						}   
					}else if(type.equals("2")) {
						
						TConfinfo tConfifo1 = new TConfinfo();
						int compId = Integer.parseInt(request.getParameter("compId"));
						tConfifo1.setCompId(compId);
						String confName = request.getParameter("confName")==null?"":request.getParameter("confName");
						if(confName!=null && confName!="") {
//							tConfifo1.setConfName(Sqlca.switchLatin1Encoding(confName));
							tConfifo1.setConfName(confName);
						}
						
//						int total = meetingDao.getMeetingDetailDatasCounts(tConfifo1);
						String getMeetingDetailDatasCounts = " select count(*)"+
						" from ("+
						" select t1.CompID,t1.AdminID,t2.ConfID,t2.CurUserCount,t2.ConfName "+
						" from t_compinfo t1,t_confinfo t2 where t1.CompID=t2.CompID) tt,"+
						" t_log_conf t3 where t3.ConfID=tt.ConfID  and tt.CompID= "+tConfifo1.compId;
						String total = Sqlca.getString(getMeetingDetailDatasCounts);
						
						String getMeetingDetailDatas = " select (SELECT maxUserCount FROM t_confinfo WHERE tt.ConfID =ConfID) AS maxUserCount,tt.CompID,tt.ConfID as confId,t3.logConfID,t3.MaxCount as curUserCount,tt.ConfName as confName,"+
						" StartTime as startTime,EndTime as endTime "+
						" from ("+
						" select t1.CompID,t1.AdminID,t2.ConfID,t2.CurUserCount,t2.ConfName "+
						" from t_compinfo t1,t_confinfo t2 where t1.CompID=t2.CompID) tt,"+
						" t_log_conf t3 where t3.ConfID=tt.ConfID ";
						
						if(tConfifo1.confName!=null && !"".equals(tConfifo1.confName))
						{
							getMeetingDetailDatas +=" and tt.ConfName LIKE '%" +tConfifo1.confName+ "%'";
							//getMeetingDetailDatasCounts +=" and tt.ConfName LIKE '%" +tConfifo1.confName+ "%'";
						}
						if(tConfifo1.curUserCount!=null)
						{
							if(tConfifo1.curUserCount==0)
							{
								getMeetingDetailDatas +=" and t3.MaxCount <10";
								//getMeetingDetailDatasCounts +=" and t3.MaxCount <10";
							}
							if(tConfifo1.curUserCount==1)
							{
								getMeetingDetailDatas +=" and t3.MaxCount between 10 and 50";
								//getMeetingDetailDatasCounts +=" and t3.MaxCount between 10 and 50";
							}
							if(tConfifo1.curUserCount==2)
							{
								getMeetingDetailDatas +=" and t3.MaxCount between 50 and 100";
								//getMeetingDetailDatasCounts +="and t3.MaxCount between 50 and 100";
							}
							if(tConfifo1.curUserCount==3)
							{
								getMeetingDetailDatas +=" and t3.MaxCount >100";
								//getMeetingDetailDatasCounts +="and t3.MaxCount >100";
							}
						}
						if(tConfifo1.startTime!=null && !"".equals(tConfifo1.startTime))
						{
							if("7".equals(tConfifo1.startTime))
							{
								getMeetingDetailDatas +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
								//getMeetingDetailDatasCounts +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 week)) and NOW()";
							}
							if("30".equals(tConfifo1.startTime))
							{
								getMeetingDetailDatas +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 month)) and NOW()";
								//getMeetingDetailDatasCounts +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 month)) and NOW()";
							}
							if("180".equals(tConfifo1.startTime))
							{
								getMeetingDetailDatas +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 2 quarter)) and NOW()";
								//getMeetingDetailDatasCounts +="and t3.StartTime BETWEEN (select date_sub(now(), interval 2 quarter)) and NOW()";
							}
							if("365".equals(tConfifo1.startTime))
							{
								getMeetingDetailDatas +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 year)) and NOW()";
								//getMeetingDetailDatasCounts +=" and t3.StartTime BETWEEN (select date_sub(now(), interval 1 year)) and NOW()";
							}
						}
						if(tConfifo1.compId!=null)
						{
							getMeetingDetailDatas +=" and tt.CompID= "+tConfifo1.compId;
							//getMeetingDetailDatasCounts +=" and tt.confId= "+tConfifo1.confId;
						}
						
						getMeetingDetailDatas += " limit "+0+","+total;
						
						List<Object> companyList =Sqlca.getArrayListFromObj(getMeetingDetailDatas, TConfinfo.class);
						
//						List<TConfinfo>companyList =meetingDao.getMeetingDetailDatas(tConfifo1,0,total);
						// 开始生成主体内容                   
						wsheet.addCell(new Label(0, 1, "会议ID"));
						wsheet.addCell(new Label(1, 1, "会议名称"));
						wsheet.addCell(new Label(2, 1, "最大在线人数"));
						wsheet.addCell(new Label(3, 1, "最大用户数"));
						wsheet.addCell(new Label(4, 1, "开始时间"));  
						wsheet.addCell(new Label(5, 1, "结束时间"));  
						int i=0;
						for(Object mt: companyList)   {   
							TConfinfo m =(TConfinfo)mt;
							wsheet.addCell(new Label(0, i+2, m.getConfId().toString()==null?"0":m.getConfId().toString()));   
//							wsheet.addCell(new Label(1, i+2, Sqlca.switchUtf8Encoding(m.getConfName().getBytes())));  
							wsheet.addCell(new Label(1, i+2,  m.getConfName()));  
							wsheet.addCell(new Label(2, i+2,  m.getCurUserCount().toString()==null?"0":m.getCurUserCount().toString()));  
							wsheet.addCell(new Label(3, i+2,  m.getMaxUserCount().toString()==null?"0":m.getMaxUserCount().toString()));  
							wsheet.addCell(new Label(4, i+2,  m.getStartTime()));  
							wsheet.addCell(new Label(5, i+2,  m.getEndTime()));  
							i++;
						}   
					}else {
						TLogConfDetail tLogConfDetail = new TLogConfDetail();
						int logConfId= Integer.parseInt(request.getParameter("logConfId"));
							tLogConfDetail.setLogConfId(logConfId);
					   String confName = request.getParameter("confName")==null?"":request.getParameter("confName");
					   String userName = request.getParameter("userName")==null?"":request.getParameter("userName");
							
						if(tLogConfDetail.getConfName()!=null && tLogConfDetail.getConfName()!="") {
//							tLogConfDetail.setConfName(Sqlca.switchLatin1Encoding(confName));
							tLogConfDetail.setConfName(confName);
						}else if(tLogConfDetail.getUserName()!=null && tLogConfDetail.getUserName()!="") {
//							tLogConfDetail.setUserName(Sqlca.switchLatin1Encoding(userName));
							tLogConfDetail.setUserName(userName);
						}
						
						String getLOGDetailDatasCounts = " SELECT COUNT(1) FROM t_log_conf_detail t WHERE"+ 
						" t.logConfID="+tLogConfDetail.logConfId;
						String total = Sqlca.getString(getLOGDetailDatasCounts);
//						int total  = meetingDao.getLOGDetailDatasCounts(tLogConfDetail);
						String getLOGDetailDatas =
						" SELECT"+
						" t.detailId AS detailId,"+
						" t.LogConfID AS logConfId,"+
						" t.UserName AS userName,"+
						" t.StartTime AS startTime,"+
						" t.EndTime AS endTime,"+
						" t.Times AS times,"+
						" t.ConfID AS confId,"+
						" t.ConfName AS confName,"+
						" t.LoginIp AS loginIp"+
						" FROM"+
						" t_log_conf_detail t"+
						" WHERE"+
						" t.logConfID="+tLogConfDetail.logConfId;
						
						if(tLogConfDetail.userName!=null && !"".equals(tLogConfDetail.userName))
						{
							getLOGDetailDatas +=" and t.UserName LIKE '%" +tLogConfDetail.userName+ "%'";
						}
						if(tLogConfDetail.confName!=null && !"".equals(tLogConfDetail.confName))
						{
							getLOGDetailDatas += " and t.ConfName LIKE '%" +tLogConfDetail.confName+ "%'";
						}
						if(tLogConfDetail.confId!=null)
						{
							getLOGDetailDatas += " and t.ConfID = "+tLogConfDetail.confId;
						}
						getLOGDetailDatas += " limit "+0+","+total;
						
						List<Object> tLogConfDetailList = Sqlca.getArrayListFromObj(getLOGDetailDatas, TLogConfDetail.class);
						
//						List<TLogConfDetail> tLogConfDetailList = meetingDao.getLOGDetailDatas(tLogConfDetail,0,total);
							// 开始生成主体内容                   
							wsheet.addCell(new Label(0, 1, "会议名称"));
							wsheet.addCell(new Label(1, 1, "显示名称"));
							wsheet.addCell(new Label(2, 1, "登录服务器IP"));
							wsheet.addCell(new Label(3, 1, "参会时长/min"));  
							wsheet.addCell(new Label(4, 1, "开始时间"));  
							wsheet.addCell(new Label(5, 1, "结束时间"));  
							int i=0;
						for(Object mt: tLogConfDetailList)   {   
							TLogConfDetail m = (TLogConfDetail)mt;
							
							wsheet.addCell(new Label(0, i+2,  m.getConfName()));
							wsheet.addCell(new Label(1, i+2,  m.getUserName())); 
							wsheet.addCell(new Label(2, i+2,  m.getLoginIp())); 
							wsheet.addCell(new Label(3, i+2,  m.getTimes().toString()));  
							wsheet.addCell(new Label(4, i+2,  m.getStartTime()));  
							wsheet.addCell(new Label(5, i+2,  m.getEndTime()));  
							i++;
						}   
					}
					// 主体内容生成结束           
					wbook.write(); // 写入文件   
					wbook.close();  
					os.close(); // 关闭流
					} 
				catch(Exception ex) 
				{ 
				ex.printStackTrace(); 
				}
			return null;
		}
		

	}










