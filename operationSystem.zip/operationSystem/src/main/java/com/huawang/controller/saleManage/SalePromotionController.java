package com.huawang.controller.saleManage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.huawang.pojo.meetingRoom.TAdmininfo;
import com.huawang.util.DateUtil;
import com.huawang.util.Sqlca;

@Controller
@RequestMapping(value="/Sale")
public class SalePromotionController 
{
	@RequestMapping(value="/SalePromotionManager.do")
	public ModelAndView SalePromotionManager() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/promotion/SalePromotionList");
		
		return view;
	}
	
	@RequestMapping(value="/AddSalePromotion.do")
	public ModelAndView AddSalePackage() throws Exception 
	{
		ModelAndView view = new ModelAndView("sale/promotion/AddSalePromotion");
		
		return view;
	}
	
	@RequestMapping(value="/ShowSalePromotion.do")
	public ModelAndView ShowSalePromotion(HttpServletRequest request) throws Exception 
	{
		String oaid = request.getParameter("oaid");
		String otid = request.getParameter("otid");
		String spid = request.getParameter("spid");
		
		String sqloa = "select oaid,activate,otid,startTime,endTime,createTime,type,remark,action,isuse,payProduct,oaCode from t_operation_activity where oaCode='"+oaid+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sqloa);
		
		String sqlot = "select otid,templateName,spid,state,createrId,createrName,createTime,remark,startTime,endTime,freeProduct,freeMinute,freePoint,freeTimeUnit,freeTime,amount,discount,payPoint,isTemplate from t_operation_template where spid='"+otid+"'";
		ArrayList<Map<String, Object>> listot = Sqlca.getArrayListFromMap(sqlot);
		
		if(otid.startsWith("A001"))
		{
			ModelAndView view = new ModelAndView("sale/promotion/ShowSalePromotionA001");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			
			String oaps = "";
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			return view;
		}
		if(otid.startsWith("A002"))
		{
			String oaps = "";
			ModelAndView view = new ModelAndView("sale/promotion/ShowSalePromotionA002");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			return view;
		}
		if(otid.startsWith("B001"))
		{
			ModelAndView view = new ModelAndView("sale/promotion/ShowSalePromotionB001");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			return view;
		}
		if(otid.startsWith("B002"))
		{
			String oaps = "";
			ModelAndView view = new ModelAndView("sale/promotion/ShowSalePromotionB002");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			
			return view;
		}
		
		return new ModelAndView("sale/promotion/ShowSalePromotionA001");
	}
	
	
	@RequestMapping(value="/OverSalePromotionSubmit.do")
	@ResponseBody
	public String OverSalePromotionSubmit(HttpServletRequest request) throws Exception
	{
		String oaid = request.getParameter("oaid");
		String otid = request.getParameter("otid");
		String spid = request.getParameter("spid");
		
		String sql = "update t_operation_activity set isuse=0 where oaCode=?";
		
		Sqlca.updateObject(sql, new String[] {oaid});
		
		return "success";
	}
	
	@RequestMapping(value="/StartSalePromotionSubmit.do")
	@ResponseBody
	public String StartSalePromotionSubmit(HttpServletRequest request) throws Exception
	{
		String oaid = request.getParameter("oaid");
		String otid = request.getParameter("otid");
		String spid = request.getParameter("spid");
		
		String sql = "update t_operation_activity set isuse=1 where oaCode=?";
		
		Sqlca.updateObject(sql, new String[] {oaid});
		
		return "success";
	}
	
	
	@RequestMapping(value="/ModifySalePromotion.do")
	public ModelAndView ModifySalePromotion(HttpServletRequest request) throws Exception 
	{
		String oaid = request.getParameter("oaid");
		String otid = request.getParameter("otid");
		
		String sqloa = "select oaCode as oaid,activate,otid,startTime,endTime,createTime,type,remark,action,isuse,payProduct,oaCode from t_operation_activity where oaCode='"+oaid+"'";
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sqloa);
		
		String sqlot = "select otid,templateName,spid,state,createrId,createrName,createTime,remark,startTime,endTime,freeProduct,freeMinute,freePoint,freeTimeUnit,freeTime,amount,discount,payPoint,isTemplate from t_operation_template where spid='"+otid+"'";
		ArrayList<Map<String, Object>> listot = Sqlca.getArrayListFromMap(sqlot);
		
		
		if(otid.startsWith("A001"))
		{
			ModelAndView view = new ModelAndView("sale/promotion/ModifySalePromotionA001");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			String oaps = "";
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			return view;
		}
		if(otid.startsWith("A002"))
		{
			String oaps = "";
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			ModelAndView view = new ModelAndView("sale/promotion/ModifySalePromotionA002");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			return view;
		}
		if(otid.startsWith("B001"))
		{
			ModelAndView view = new ModelAndView("sale/promotion/ModifySalePromotionB001");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			return view;
		}
		if(otid.startsWith("B002"))
		{
			String oaps = "";
			String sql="select payProduct from t_operation_activity where oaCode='"+oaid+"'";
			ArrayList<Map<String, Object>> oaproducts = Sqlca.getArrayListFromMap(sql);
			ModelAndView view = new ModelAndView("sale/promotion/ModifySalePromotionB002");
			view.addObject("oa",list);
			view.addObject("ot", listot);
			for(Map<String, Object> ss : oaproducts)
			{
				oaps+=ss.get("payProduct")+"#";
			}
			oaps = oaps.substring(0, oaps.length()-1);
			view.addObject("oaps", oaps);
			return view;
		}
		
		return new ModelAndView("sale/promotion/ModifySalePromotionA001");
	}
	
	
	@RequestMapping(value="/AddSalePromotionSubmit.do")
	@ResponseBody
	public String AddSalePromotionSubmit(HttpServletRequest request,HttpSession session) throws Exception
	{
		String createrId="";
		String createrName="";
		String activate = request.getParameter("activate");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String type = request.getParameter("type");
		String otid = request.getParameter("otid");
		String remark = request.getParameter("remark");
		String action = request.getParameter("action");
		String freeProduct = request.getParameter("freeProduct");
		String freeMinute = request.getParameter("freeMinute");
		String freeTime = request.getParameter("freeTime");
		String freeTimeUnit = request.getParameter("freeTimeUnit");
		String freePoint = request.getParameter("freePoint");
		String payProduct = request.getParameter("payProduct");
		String amount = request.getParameter("amount");
		String discount = request.getParameter("discount");
		String myjson = request.getParameter("myjson");
		
		if(freeProduct==null) {freeProduct="";}
		if(freeMinute==null || "".equals(freeMinute)) {freeMinute="0";}
		if(freeTime==null || "".equals(freeTime)) {freeTime="0";}
		if(freeTimeUnit==null || "".equals(freeTimeUnit)) {freeTimeUnit="";}
		if(freePoint==null || "".equals(freePoint)) {freePoint="0";}
		if(payProduct==null) {payProduct="";}
		if(amount==null || "".equals(amount)) {amount="0";}
		if(discount==null || "".equals(discount)) {discount="0";}
		if(action==null) {action="";}
		if(startTime==null) {startTime="";}
		if(endTime==null) {endTime="";}
		if(remark==null) {remark="";}
		if(myjson==null) {myjson="";}
		
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			createrName = a.getAdminTrueName();
			createrId = String.valueOf(a.getAdminId());
		}
		
		String spid = "";
		String pre = Sqlca.getString("select remark from t_operation_template where otid="+otid);
		spid = pre+DateUtil.dateFormat("yyyyMMddHHmmss");
		String oaCode = "AC"+DateUtil.dateFormat("yyyyMMdd")+DateUtil.getRandombit3();
		String datetime = DateUtil.dateFormat("yyyy-MM-dd HH:mm")+":00";
		
		if("1".equals(otid)) 
		{
			String[] payProducts = request.getParameterValues("freeProduct1");
			String templateName = Sqlca.getString("select templateName from t_operation_template where otid="+otid);
			String sqlA001="insert into t_operation_template(spid,templateName,state,createrId,createrName,createTime,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark,isTemplate) " + 
					"values(?,?,1,?,?,SYSDATE(),?,?,?,?,?,?,?,?,?,?,1)";
			
			int cnt = Sqlca.updateObject(sqlA001, new String[] {spid,templateName,createrId,createrName,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark});
			
			if(cnt>0) 
			{
				for(String pp : payProducts)
				{
					String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,createrId,createrName,payProduct) " + 
							"values('"+oaCode+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,'"+pp+"')";
					Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,createrId,createrName});
				}
				
			}
			
		}
		else if("2".equals(otid)) 
		{
			String[] payProducts = request.getParameterValues("payProduct2");
			
			String templateName = Sqlca.getString("select templateName from t_operation_template where otid="+otid);
			String sqlA001="insert into t_operation_template(spid,templateName,state,createrId,createrName,createTime,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark,isTemplate) " + 
					"values(?,?,1,?,?,'"+datetime+"',?,?,?,?,?,?,?,?,?,?,2)";
			
			int cnt = Sqlca.updateObject(sqlA001, new String[] {spid,templateName,createrId,createrName,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark});
			
			if(cnt>0)
			{
				for(String pp : payProducts)
				{
					String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,payProduct,createrId,createrName) " + 
							"values('"+oaCode+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,?)";
					Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,pp,createrId,createrName});
				}
			}
			
		}
		else if("3".equals(otid)) 
		{
			JSONArray jsonarray = JSON.parseArray(myjson);
			for(Object objj : jsonarray) 
			{
				JSONArray oj = (JSONArray)objj;
				String amount3 = oj.getString(0);
				String freeTime3 = oj.getString(1);
				String freeTimeUnit3 = oj.getString(2);
				String discount3 = oj.getString(3);
				
				String templateName = Sqlca.getString("select templateName from t_operation_template where otid="+otid);
				String sqlA001="insert into t_operation_template(spid,templateName,state,createrId,createrName,createTime,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark,isTemplate) " + 
						"values(?,?,1,?,?,'"+datetime+"',?,?,?,?,?,?,?,?,?,?,3)";
				
				Sqlca.updateObject(sqlA001, new String[] {spid,templateName,createrId,createrName,freeProduct,freeMinute,freeTime3,freeTimeUnit3,startTime,endTime,freePoint,amount3,discount3,remark});
			}
			
//			String insertotid = Sqlca.getString("select LAST_INSERT_ID() from t_operation_template limit 1");
			String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,payProduct,createrId,createrName) " + 
					"values('"+oaCode+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,?)";
			Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,payProduct,createrId,createrName});
		}
		else if("4".equals(otid)) 
		{
			String[] payProducts = request.getParameterValues("payProduct4");
			
			String templateName = Sqlca.getString("select templateName from t_operation_template where otid="+otid);
			String sqlA001="insert into t_operation_template(spid,templateName,state,createrId,createrName,createTime,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark,isTemplate) " + 
					"values(?,?,1,?,?,'"+datetime+"',?,?,?,?,?,?,?,?,?,?,4)";
			
			int cnt = Sqlca.updateObject(sqlA001, new String[] {spid,templateName,createrId,createrName,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,remark});
			
			if(cnt>0)
			{
				for(String pp : payProducts)
				{
					String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,payProduct,createrId,createrName) " + 
							"values('"+oaCode+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,?)";
					Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,pp,createrId,createrName});
				}
			}
		}
			
		return "success";
	}
	
	@RequestMapping(value="/ModifySalePromotionSubmitA001")
	@ResponseBody
	public String ModifySalePromotionSubmitA001(HttpServletRequest request) throws Exception
	{
		String otid = request.getParameter("otid");
		String oaid = request.getParameter("oaid");
		String spid = request.getParameter("spid");
		String activate = request.getParameter("activate");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String action = request.getParameter("action");
		String freeProduct = request.getParameter("freeProduct");
		String freeMinute = request.getParameter("freeMinute");
		String freePoint = request.getParameter("freePoint");
		String freeTime = request.getParameter("freeTime");
		String freeTimeUnit = request.getParameter("freeTimeUnit");
		String remark = request.getParameter("remark");
		String[] payProducts = request.getParameterValues("freeProduct1");
		
		
		
		ArrayList<Map<String, Object>> oas = Sqlca.getArrayListFromMap("select oaCode,createTime,type,createrId,createrName from t_operation_activity where oaCode='"+oaid+"'");
		String oaCode = (String)oas.get(0).get("oaCode");
		String createTime = (String)oas.get(0).get("createTime");
		String type = (String)oas.get(0).get("type");
		String createrId = (String)oas.get(0).get("createrId");
		String createrName = (String)oas.get(0).get("createrName");
		
		Sqlca.updateObject("delete from t_operation_activity where oaCode=?", new String[] {oaid});
		
		for(String pp : payProducts)
		{
			String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,createrId,createrName,payProduct) " + 
					"values('"+oaCode+"',?,?,?,?,?,2,?,?,'"+createTime+"',?,?,'"+pp+"')";
			Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,createrId,createrName});
		}
		
		
		
		String sqloa = "update t_operation_activity set activate=?,startTime=?,endTime=?,action=?,remark=? where oaCode='"+oaid+"'";
		
		Sqlca.updateObject(sqloa, new String[] {activate,startTime,endTime,action,remark});
		
		String sqlot = "update t_operation_template set freeProduct=?,freeMinute=?,freePoint=?,freeTime=?,freeTimeUnit=? where spid='"+spid+"'";
		
		Sqlca.updateObject(sqlot, new String[] {freeProduct,freeMinute,freePoint,freeTime,freeTimeUnit});
		
		return "success";
	}
	
	
	@RequestMapping(value="/ModifySalePromotionSubmitA002")
	@ResponseBody
	public String ModifySalePromotionSubmitA002(HttpServletRequest request) throws Exception
	{
		String otid = request.getParameter("otid");
		String oaid = request.getParameter("oaid");
		String spid = request.getParameter("spid");
		String activate = request.getParameter("activate");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String freeProduct = request.getParameter("freeProduct");
		String freeMinute = request.getParameter("freeMinute");
		String freePoint = request.getParameter("freePoint");
		String freeTime = request.getParameter("freeTime");
		String[] payProducts = request.getParameterValues("payProduct");
		String freeTimeUnit = request.getParameter("freeTimeUnit");
		String remark = request.getParameter("remark");
		
		
		
		ArrayList<Map<String, Object>> oas = Sqlca.getArrayListFromMap("select oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,createrId,createrName "
				+ " from t_operation_activity where oaCode='"+oaid+"'");
		
		String type = (String)oas.get(0).get("type");
		String action = (String)oas.get(0).get("action");
		String datetime = (String)oas.get(0).get("createTime");
		String createrId = (String)oas.get(0).get("createrId");
		String createrName = (String)oas.get(0).get("createrName");
		
		Sqlca.updateObject("delete from t_operation_activity where oaCode=?", new String[] {oaid});
		
		for(String pp : payProducts)
		{
			String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,payProduct,createrId,createrName) " + 
					"values('"+oaid+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,?)";
			Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,pp,createrId,createrName});
		}
		
		String sqlot = "update t_operation_template set freeProduct=?,freeMinute=?,freePoint=?,freeTime=?,freeTimeUnit=? where spid='"+spid+"'";
		
		Sqlca.updateObject(sqlot, new String[] {freeProduct,freeMinute,freePoint,freeTime,freeTimeUnit});
		
		return "success";
	}
	
	@RequestMapping(value="/ModifySalePromotionSubmitB001")
	@ResponseBody
	public String ModifySalePromotionSubmitB001(HttpServletRequest request,HttpSession session) throws Exception
	{
		String createrName="";
		String createrId="";
		Object obj = session.getAttribute("USER_SESSION");
		if(obj!=null)
		{
			TAdmininfo a = (TAdmininfo)obj;
			createrName = a.getAdminTrueName();
			createrId = String.valueOf(a.getAdminId());
		}
		String otid = request.getParameter("otid");
		String oaid = request.getParameter("oaid");
		String spid = request.getParameter("spid");
		String activate = request.getParameter("activate");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		
		String freeProduct = request.getParameter("freeProduct");
		String freeMinute = request.getParameter("freeMinute");
		String freePoint = request.getParameter("freePoint");
		String freeTime = request.getParameter("freeTime");
		String payProduct = request.getParameter("payProduct");
		String freeTimeUnit = request.getParameter("freeTimeUnit");
		String myjson = request.getParameter("myjson");
		String remark = request.getParameter("remark");
		
		if(freeProduct==null) {freeProduct="";}
		if(freeMinute==null || "".equals(freeMinute)) {freeMinute="0";}
		if(freeTime==null || "".equals(freeTime)) {freeTime="0";}
		if(freeTimeUnit==null || "".equals(freeTimeUnit)) {freeTimeUnit="";}
		if(freePoint==null || "".equals(freePoint)) {freePoint="0";}
		if(payProduct==null) {payProduct="";}
		if(startTime==null) {startTime="";}
		if(endTime==null) {endTime="";}
		if(myjson==null) {myjson="";}
		
		String templateName = Sqlca.getString("select templateName from t_operation_template where spid='"+spid+"'");
		Sqlca.updateObject("delete from t_operation_template where spid=?", new String[] {spid});
		JSONArray jsonarray = JSON.parseArray(myjson);
		for(Object objj : jsonarray) 
		{
			JSONArray oj = (JSONArray)objj;
			String amount3 = oj.getString(0);
			String freeTime3 = oj.getString(1);
			String freeTimeUnit3 = oj.getString(2);
			String discount3 = oj.getString(3);
			
			String sqlA001="insert into t_operation_template(spid,templateName,state,createrId,createrName,createTime,freeProduct,freeMinute,freeTime,freeTimeUnit,startTime,endTime,freePoint,amount,discount,isTemplate) " + 
					"values(?,?,1,?,?,SYSDATE(),?,?,?,?,?,?,?,?,?,3)";
			
			Sqlca.updateObject(sqlA001, new String[] {spid,templateName,createrId,createrName,freeProduct,freeMinute,freeTime3,freeTimeUnit3,startTime,endTime,freePoint,amount3,discount3});
		}
		
		String sqloa = "update t_operation_activity set activate=?,startTime=?,endTime=?,payProduct=?,remark=? where oaCode='"+oaid+"'";
		
		Sqlca.updateObject(sqloa, new String[] {activate,startTime,endTime,payProduct,remark});
		
		return "success";
	}
	
	
	@RequestMapping(value="/ModifySalePromotionSubmitB002")
	@ResponseBody
	public String ModifySalePromotionSubmitB002(HttpServletRequest request,HttpSession session) throws Exception
	{
//		String createrName="";
//		String createrId="";
//		Object obj = session.getAttribute("USER_SESSION");
//		if(obj!=null)
//		{
//			TAdmininfo a = (TAdmininfo)obj;
//			createrName = a.getAdminTrueName();
//			createrId = String.valueOf(a.getAdminId());
//		}
		String otid = request.getParameter("otid");
		String oaid = request.getParameter("oaid");
		String spid = request.getParameter("spid");
		String activate = request.getParameter("activate");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		
		String freeProduct = request.getParameter("freeProduct");
		String freeMinute = request.getParameter("freeMinute");
		String freePoint = request.getParameter("freePoint");
		String freeTime = request.getParameter("freeTime");
		String[] payProducts = request.getParameterValues("payProduct");
		String freeTimeUnit = request.getParameter("freeTimeUnit");
		String discount = request.getParameter("discount");
		String remark = request.getParameter("remark");
		
		if(freeProduct==null) {freeProduct="";}
		if(freeMinute==null || "".equals(freeMinute)) {freeMinute="0";}
		if(freeTime==null || "".equals(freeTime)) {freeTime="0";}
		if(freeTimeUnit==null || "".equals(freeTimeUnit)) {freeTimeUnit="";}
		if(freePoint==null || "".equals(freePoint)) {freePoint="0";}
		if(discount==null || "".equals(discount)) {discount="0";}
		if(startTime==null) {startTime="";}
		if(endTime==null) {endTime="";}
		
		String sqlot = "update t_operation_template set discount=? where spid='"+spid+"'";
		
		Sqlca.updateObject(sqlot, new String[] {discount});
		
		
		ArrayList<Map<String, Object>> oas = Sqlca.getArrayListFromMap("select oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,createrId,createrName "
				+ " from t_operation_activity where oaCode='"+oaid+"'");
		
		Sqlca.updateObject("delete from t_operation_activity where oaCode=?", new String[] {oaid});
		
		String type = (String)oas.get(0).get("type");
		String action = (String)oas.get(0).get("action");
		String datetime = (String)oas.get(0).get("createTime");
		String createrId = (String)oas.get(0).get("createrId");
		String createrName = (String)oas.get(0).get("createrName");
		
		
		for(String pp : payProducts)
		{
			String sql = "insert into t_operation_activity(oaCode,activate,otid,type,remark,action,isuse,startTime,endTime,createTime,payProduct,createrId,createrName) " + 
					"values('"+oaid+"',?,?,?,?,?,2,?,?,'"+datetime+"',?,?,?)";
			Sqlca.updateObject(sql, new String[] {activate,spid,type,remark,action,startTime,endTime,pp,createrId,createrName});
		}
		
//		String sqloa = "update t_operation_activity set activate=?,startTime=?,endTime=?,payProduct=?,remark=? where oaCode='"+oaid+"'";
		
//		Sqlca.updateObject(sqloa, new String[] {activate,startTime,endTime,payProduct,remark});
		
		return "success";
	}
	
	
	@RequestMapping(value="/SelectPromotionList")
	@ResponseBody
	public Map<String,Object> SelectPromotionList(HttpServletRequest request) throws Exception
	{
		String activate = request.getParameter("activate");
		String type = request.getParameter("type");
		
		String SortName = request.getParameter("sort");
		String SortValue =request.getParameter("order");
		
		String page = request.getParameter("page");
		String rows = request.getParameter("rows");
		int total = (Integer.parseInt(page)-1)*Integer.parseInt(rows);
		
		String sql = "select distinct oaCode as oaid,activate,otid,otid as template,startTime,endTime,createTime,type,remark,isuse,createrName,oaCode as oaid1 from t_operation_activity where 1=1 ";
		
		String sqlTotal = "select count(*) from t_operation_activity where 1=1 ";
		
		if(!"".equals(type) && type!=null) {
			sql+= " and type ="+type;
			sqlTotal+= " and type ="+type;
		}
		
		if(!"".equals(activate) && activate!=null) {
			sql+= " and activate like '%"+activate+"%'";
			sqlTotal+= " and activate like '%"+activate+"%'";
		}
		
		if(null!=SortName && !"".equals(SortName)) 
		{
			sql +=" order by "+SortName+" "+SortValue+" limit "+total+","+rows;
		}
		else
		{
			sql +=" limit "+total+","+rows;
		}
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		String dbtotal = Sqlca.getString(sqlTotal);
		reMap.put("rows", list);
		reMap.put("total", dbtotal);
		
		return reMap;
	}
	
	
	@RequestMapping(value="/SelectPromotionDiscount")
	@ResponseBody
	public Map<String,Object> SelectPromotionDiscount(HttpServletRequest request) throws Exception
	{
		String spid = request.getParameter("spid");
		
		String sql = "select otid,templateName,spid,state,createrId,createrName,createTime,remark,startTime,endTime,"
				+ " freeProduct,freeMinute,freePoint,freeTimeUnit,freeTime,amount,discount,payPoint,isTemplate from t_operation_template where spid='"+spid+"'";
		
		HashMap<String,Object> reMap = new HashMap<String,Object>();
		
		ArrayList<Map<String, Object>> list = Sqlca.getArrayListFromMap(sql);
		
		reMap.put("rows", list);
		
		return reMap;
	}
}
