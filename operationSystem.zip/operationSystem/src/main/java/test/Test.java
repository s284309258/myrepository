package test;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.huawang.util.BasicDataUtil;
import com.huawang.util.DateUtil;
import com.huawang.util.SecurityUtil;
import com.huawang.util.Sqlca;

public class Test {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public static Connection getConnection() throws SQLException {
//		return DriverManager.getConnection("jdbc:mysql://192.168.5.196:3369/webtest2018?characterEncoding=latin1", "haohuiyi", "pwd!@#haohuiyi");
//		return DriverManager.getConnection("jdbc:mysql://rm-bp17g6424ddlqq000so.mysql.rds.aliyuncs.com/wchtest?characterEncoding=utf8", "wch", "WCH123@123a");
		return DriverManager.getConnection("jdbc:mysql://192.168.35.198:3369/webtest2019?characterEncoding=utf8", "haohuiyi", "pwd!@#haohuiyi");
	}
	
	public static void main(String[] args) throws Exception {
		try {
			
			
			
			Connection conn = getConnection();
			Statement sts = conn.createStatement();
			ResultSet rs = sts.executeQuery("select comptruename from t_compinfo where compid=1");
			rs.next();
			System.out.println(rs.getString("comptruename"));
			//Sqlca.updateObject(conn, "update t_compinfo set compStyle=null where CompID='4'", new String[] {});
//			PreparedStatement pp =conn.prepareStatement("update t_compinfo set compStyle=null where CompID='4'");
//			pp.execute();
//			
//			String sql = "select t_menus.menu_id as mid,t_menus.menu_name as title,t_menus.menu_icon as icon,t_menus.menu_url as href " + 
//					"					from t_menus,t_role_menu,t_admininfo " + 
//					"					 where t_menus.menu_id=t_role_menu.menu_id " + 
//					"					 and t_role_menu.role_id=t_admininfo.roles " + 
//					"					 and t_menus.menu_parent_id='0' " + 
//					"					 and t_admininfo.AdminName='admin' and t_role_menu.isuse='1' order by t_menus.mid";
//			ArrayList<Map<String,Object>> arraylist = Sqlca.getArrayListFromMap(sql,conn);
//			for (Map<String,Object> m : arraylist) {
//				String id = (String)m.get("mid");
//				String menuSql = " select t1.mid,t1.title,t1.icon,t1.href from                                                        "+
//						" (                                                                                                           "+
//						" select tm.menu_id as mid,tm.menu_name as title,tm.menu_icon as icon,tm.menu_url as href                     "+
//						" 						 from t_menus tm,t_role_menu trm where tm.menu_parent_id=trm.menu_id                  "+
//						" 						 and trm.menu_id='"+id+"' and trm.role_id='admin' order by tm.mid asc                 "+
//						" ) t1,t_role_menu where t1.mid=t_role_menu.menu_id and t_role_menu.isuse='1' and t_role_menu.role_id='admin'";
//				ArrayList<Map<String, Object>> arr = Sqlca.getArrayListFromMap(menuSql, conn);
//				m.put("children", arr);
//			}
//			
//			String jsonmenu = JSON.toJSONString(arraylist);
//			System.out.println(jsonmenu);
//			
//			
//			
//			
//			
//			ArrayList<?> array = Sqlca.getArrayListFromObj("select * from t_option", Option.class,conn);
//			for(Object o : array) {
//				System.out.println(o);
//			}
			
//			String pwd = SecurityUtil.passWordEncrypt("qweasd");
//			System.out.println(pwd);
//			String pwd1  = SecurityUtil.passWordDecrypt("d+5vOzuh00RXsaSH1eudoPVRn8qT4a2r5NVlkOdPGVLS9WyBmo8b0XBLkSCrC29HfiWqkHWhcs+7BQGRQ+GLpxsDshqYm7GIInmS0vpU3gOgzshMw5ToN4SV/eyuTRiGCmRZS/Eq0EJb+Eu5I4FCAmJyX80euuwsS4ndjHVHR4U=");
//			System.out.println(pwd1);
//			
//			String s = SecurityUtil.encryptSHA("admin");
//			System.out.println(s);
			
//			String s1 = SecurityUtil.encryptMD5("admin");
//			System.out.println(s1); 
			
//			System.out.println("aaabbbcccc123123123rrrr".contains("12zz3"));
//			
//			String [] strs = new String[]{"123","2333","2222"};//Sqlca.switchEncoding(null, new String[]{"123","2333","2222"});
//			
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		    String dd=sdf.format(new Date()); 
//		    if("2018-11-23 16:42:40".compareTo(dd)<=0) {
//		    	System.out.println(123123);
//		    }
		    
		    System.out.println(DateUtil.dateFormat(0));
		    
		    
		    Calendar c = Calendar.getInstance();//可以对每个时间域单独修改   

		    int year = c.get(Calendar.YEAR);

		    int month = c.get(Calendar.MONTH);

		    int date = c.get(Calendar.DATE);
		    int hour = c.get(Calendar.HOUR_OF_DAY);

		    int minute = c.get(Calendar.MINUTE);

		    int second = c.get(Calendar.SECOND); 

		    String adf = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
		    String cc = "2018-11-24 10:10:10";
		    System.out.println(cc.substring(0, 10));
		    if("2018-11-24".compareTo(adf)<=0) {
		    	System.out.println("aaaaaaaaaaaaa");
		    }
		    System.out.println(adf);
		    
		    System.out.println("======md5======"+SecurityUtil.encryptMD5("abcd1234*"));
		    System.out.println(DateUtil.dateFormat());
		    
		    int i = (int)(Math.random()*900 + 100);
		    String myStr = Integer.toString(i);
		    System.out.println(myStr);
		    
		    System.out.println("myStr=="+myStr);

	    	 try {
	    	 // 生成一个MD5加密计算摘要
	    	 MessageDigest md = MessageDigest.getInstance("MD5");
	    	 // 计算md5函数
	    	 md.update("abcd12345".getBytes());
	    	 // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
	    	 // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
//	    	 return new BigInteger(1, md.digest()).toString(16);
	    	 System.out.println("=mmmmmmmm======"+new BigInteger(1, md.digest()).toString(16));
	    	 
	    	 System.out.println("*******************"+SecurityUtil.encryptMD5("zm20150708"));
	    	 } catch (Exception e) {
	    		 throw new Exception("MD5加密出现错误");
	    	 }
	    
		    
		    
//		    String dd = new String(new String("è¶çº§ç®¡çå".getBytes("ISO-8859-1"), "GBK").getBytes(), "UTF-8");
		    String dd =new String("è¶çº§ç®¡çå".getBytes("gb2312"),"ISO8859_1");
//		    new String("è¶çº§ç®¡çå".getBytes("ISO-8859-1"),"GBK").getBytes("utf-8");
		    System.out.println(dd);
//		    ,"utf-8"
//			if(str!=null) 
//			{
//				String[] ss = new String[1];
//				ss[0] = new String(str.getBytes("GB2312"),"ISO8859_1");
//				return ss;
//			}
//			if(strs!=null)
//			{
//				String[] ss = new String[strs.length];
//				for(int i=0;i<strs.length;i++) {
//					
//					ss[i] = new String(strs[i].getBytes("GB2312"),"ISO8859_1");
//					System.out.println(ss[i]);
//					
//				}
//			}
			
		    System.out.println("2023-05-04 12:13:12".compareTo("2023-05-04 12:12:12")>0);
		    
		    
		    System.out.println("2019-10-10".substring(0, 10));
		    
		    
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Calendar cl = Calendar.getInstance();
			
			cl.add(Calendar.DAY_OF_MONTH, 1);
			String strdate = sdf.format(cl.getTime());
			System.out.println(strdate);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
