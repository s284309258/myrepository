package test;
import com.amarsoft.Task.*;

/**
 * ��������
 * */
public class RunTaskTest {
    static
    {
//    	��ʼ�������б�
    	if(TaskFactory.getTaskInfo()==null)
			try {
				TaskFactory.initTask();
			} catch (Exception e) {
				e.printStackTrace();
			}
    } 
    
    public static void main(String args[])
    {
    	try {
    		if(TaskFactory.getTaskInfo()==null)
    		{
    			System.out.println("�����ʼ��ʧ��!");
    			System.exit(1);
    		}
    		
    		TaskFactory.RunTask("HoldTask");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
   
}
 