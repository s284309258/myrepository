package test;

import java.sql.SQLException;

import com.amarsoft.Log.logger;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.Image.Image;

public class StopTaskTest {

    public static void main(String args[])
    {
    	DBConnection db = new DBConnection("D:/Workspace/TaskProject/sys-config-int/DataBase.xml");
    	java.sql.ResultSet rs = null;
		java.sql.Statement stat = null;
		String sSql = "select * from user_info ";
		java.sql.Connection Loan = null;
		try {
			Loan = db.getConn("Loan");
			stat  = Loan.createStatement();
			rs = stat.executeQuery(sSql);  
			if(rs.next()){
			sSql = "update  User_info set attribute1='ssd'  where userid = 'admin'";
			stat.executeUpdate(sSql);
			}
			rs.close();
			stat.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
    }

}
