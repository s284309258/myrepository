package com.amarsoft.tools;

import java.sql.SQLException;

import com.amarsoft.log.Log;
import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.biz.bizlet.Bizlet;
import com.amarsoft.impl.bank.bizlets.GetFlowPool;

public class FlowTools {
	public String SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,PhaseNo,PhaseType,ApplyType,UserID,OrgID,BeginTime,EndTime,PhaseAction;
	public String FlowName,UserName,OrgName,PhaseName,PhaseChoice,PhaseOpinion,PhaseOpinion1,PhaseOpinion2,PhaseOpinion3,PhaseOpinion4;
	//������׼��ʱ
	private Log logger = null;
	public String FMStandardTime1="7200",FMStandardTime2="7200",FMCOSTLOB="0";
	java.sql.Connection Loan=null;
	public FlowTools(Log log){
		this.logger = log;
	}
	public FlowTools(java.sql.Connection db,String sSerialNo,Log log) throws Exception 
	{
		this.SerialNo = sSerialNo;
		this.logger = log;
		java.sql.ResultSet rsFlowTask = null;
		java.sql.ResultSet rsFlowModel = null;
		java.sql.Statement stat = null;
		this.Loan = db;
		String sSql = "";
		
		stat  = Loan.createStatement();
		//��õ�ǰ��������ĸ�������
		logger.info("��ʼ�����̽׶���Ϣ");
		sSql="select FLOW_TASK.* from FLOW_TASK where SerialNo='"+sSerialNo+"'";
		logger.debug(sSql);
		rsFlowTask=stat.executeQuery(sSql);
		if (rsFlowTask.next())
		{
			this.RelativeSerialNo = rsFlowTask.getString("RelativeSerialNo");
			this.ObjectType = rsFlowTask.getString("ObjectType");
			this.ObjectNo = rsFlowTask.getString("ObjectNo");
			this.FlowNo = rsFlowTask.getString("FlowNo");
			this.FlowName = rsFlowTask.getString("FlowName");
			this.PhaseNo = rsFlowTask.getString("PhaseNo");
			this.PhaseName = rsFlowTask.getString("PhaseName");
			this.PhaseType = rsFlowTask.getString("PhaseType");
			this.ApplyType = rsFlowTask.getString("ApplyType");
			this.UserID = rsFlowTask.getString("UserID");
			this.UserName = rsFlowTask.getString("UserName");
			this.OrgID = rsFlowTask.getString("OrgID");
			this.OrgName = rsFlowTask.getString("OrgName");
			this.BeginTime = rsFlowTask.getString("BeginTime");
			this.EndTime = rsFlowTask.getString("EndTime");
			this.PhaseChoice = rsFlowTask.getString("PhaseChoice");
			this.PhaseAction = rsFlowTask.getString("PhaseAction");
			this.PhaseOpinion = rsFlowTask.getString("PhaseOpinion");
			this.PhaseOpinion1 = rsFlowTask.getString("PhaseOpinion1");
			this.PhaseOpinion2 = rsFlowTask.getString("PhaseOpinion2");
			this.PhaseOpinion3 = rsFlowTask.getString("PhaseOpinion3");
			this.PhaseOpinion4 = rsFlowTask.getString("PhaseOpinion4");
			
		}else
		{
			throw new Exception("FlowTask:SerialNo:'"+sSerialNo+"' not Exist");	
		}	
		rsFlowTask.close();
		
		rsFlowModel=stat.executeQuery("select FLOW_MODEL.* from FLOW_MODEL where FLOWNO='"+this.FlowNo+"'");
		if (rsFlowModel.next())
		{
			this.FMStandardTime1=rsFlowModel.getString("StandardTime1");
			this.FMStandardTime2=rsFlowModel.getString("StandardTime2");
		}
		rsFlowModel.close();
		stat.close();
		if(FMStandardTime1==null)FMStandardTime1="";
		if(FMStandardTime2==null)FMStandardTime2="";
		
	}
/**
 * 
 * @param flag 0 �������ʿ�  1 ���������׶�
 */
	public boolean fireFlow(String flag,String serialNo)
	{
		java.sql.Statement stat = null;
		boolean bReturnValue=true;
		String sSql = "",sFTSerialNo = "";
		
		try {
			stat  = Loan.createStatement();
			sFTSerialNo = DBFunction.getSerialNo("FLOW_TASK","SERIALNO","yyyyMMdd","000000",new java.util.Date(),"RL",Loan);
			
		} catch (Exception e) {
			logger.debug("��������ˮ������ʧ�ܣ�"+e.getMessage());
		}
		logger.debug("��������ˮ�ţ�"+sFTSerialNo);
		try {
				//----�ر�ԭ��������
			
				sSql =  " UPDATE FLOW_TASK SET  ENDTIME=to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),StandardTime1='"+this.FMStandardTime1+"',StandardTime2='"+this.FMStandardTime2+"' where SERIALNO = '"+serialNo+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
			logger.info("�������ͱ�־��"+flag);
			if(flag.equals("0")){
				//----���� FLOW_OBJECT
				sSql =  " UPDATE FLOW_OBJECT SET (PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,PhaseName, "+
						" OrgID,OrgName,UserID,UserName,InputDate) = "+
						" (select '1020','"+this.ApplyType+"','"+this.FlowNo+"','"+this.FlowName+"','0030','�ʿظ���', "+
						" '','','OPS','',to_char(sysdate,'YYYY/MM/DD') from dual) where OBJECTNO = '"+this.ObjectNo+"' and OBJECTTYPE = '"+this.ObjectType+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----�½�FLOW_TASK
				sSql =  " insert into FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,FlowName,PhaseNo,PhaseName, "+
				" PhaseType,ApplyType,BeginTime,UserID,StandardTime1,StandardTime2 ) values "+
				" ('"+sFTSerialNo+"','"+serialNo+"','"+this.ObjectType+"','"+this.ObjectNo+"','"+this.FlowNo+"','"+this.FlowName+"','0030','�ʿظ���', "+
				" '1020','"+this.ApplyType+"',to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),'OPS','"+this.FMStandardTime1+"','"+this.FMStandardTime2+"') ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
			}else { //if(flag.equals("1")){
				//---���� FLOW_OBJECT
				sSql =  " UPDATE FLOW_OBJECT SET (PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,PhaseName, "+
						" OrgID,OrgName,UserID,UserName,InputDate ) = "+
						" (select '"+this.PhaseType+"','"+this.ApplyType+"','"+this.FlowNo+"','"+this.FlowName+"','"+this.PhaseNo+"','"+this.PhaseName+"', "+
						" '"+this.OrgID+"','"+this.OrgName+"','"+this.UserID+"','"+this.UserName+"',to_char(sysdate,'YYYY/MM/DD') from dual ) where OBJECTNO = '"+this.ObjectNo+"' and OBJECTTYPE = '"+this.ObjectType+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----�½�FLOW_TASK
				sSql =  " insert into FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,FlowName,PhaseNo,PhaseName, "+
				" PhaseType,ApplyType,BeginTime,UserID,UserName,OrgID,OrgName,StandardTime1,StandardTime2) values "+
				" ('"+sFTSerialNo+"','"+serialNo+"','"+this.ObjectType+"','"+this.ObjectNo+"','"+this.FlowNo+"','"+this.FlowName+"','"+this.PhaseNo+"','"+this.PhaseName+"', "+
				" '"+this.PhaseType+"','"+this.ApplyType+"',to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),'"+this.UserID+"','"+this.UserName+"','"+this.OrgID+"','"+this.OrgName+"','"+this.FMStandardTime1+"','"+this.FMStandardTime2+"') ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
			}
			
			
		} catch (Exception e) {
			logger.warn("������Ϣ "+e.getMessage());
			bReturnValue=false;
			e.printStackTrace();
		}
		finally
		{
			try {
				stat.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		return bReturnValue;
	}
	/**
	 * ���������Ž׶�
	 * ������Ȩ
	 * @param sqlca
	 * @param serialNo
	 * @return
	 */
	public boolean fireFlow2(Transaction sqlca,String serialNo)
	{
		java.sql.Statement stat = null;
		boolean bReturnValue=true;
		String sSql = "",sFTSerialNo = "";
		try {
			stat  = Loan.createStatement();
			sFTSerialNo = DBFunction.getSerialNo("FLOW_TASK","SERIALNO",sqlca);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
				//----�ر�ԭ��������
				sSql =  " UPDATE FLOW_TASK SET  ENDTIME=to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),StandardTime1='"+this.FMStandardTime1+"',StandardTime2='"+this.FMStandardTime2+"' where SERIALNO = '"+serialNo+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
			
				//---���� FLOW_OBJECT
				sSql =  " UPDATE FLOW_OBJECT SET (PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,PhaseName, "+
						" OrgID,OrgName,UserID,UserName,InputDate) = "+
						" (select '0030','"+this.ApplyType+"','"+this.FlowNo+"','"+this.FlowName+"','0040','���ŵ���', "+
						" '','','OPS','',to_char(sysdate,'YYYY/MM/DD') from dual) where OBJECTNO = '"+this.ObjectNo+"' and OBJECTTYPE = '"+this.ObjectType+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----�½�FLOW_TASK
				sSql =  " insert into FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,FlowName,PhaseNo,PhaseName, "+
				" PhaseType,ApplyType,BeginTime,UserID) values "+
				" ('"+sFTSerialNo+"','"+serialNo+"','"+this.ObjectType+"','"+this.ObjectNo+"','"+this.FlowNo+"','"+this.FlowName+"','0040','���ŵ���', "+
				" '0300','"+this.ApplyType+"',to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),'OPS') ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----������Ȩ����
				Bizlet toPa = new GetFlowPool();
				toPa.setAttribute("ObjectType","CBCreditApply"); 
				toPa.setAttribute("ObjectNo",this.ObjectNo);
				toPa.setAttribute("SerialNo",sFTSerialNo);
				toPa.setAttribute("Role","A02");
				toPa.run(sqlca);
				
		} catch (Exception e) {
			logger.warn("������Ϣ "+e.getMessage());
			bReturnValue=false;
			e.printStackTrace();
		}
		finally
		{
			try {
				stat.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		return bReturnValue;
	}
	
	
	/**
	 * ��������������
	 * ������Ȩ
	 * @param sqlca
	 * @param serialNo
	 * @return
	 */
	
	public boolean fireFlow3(Transaction sqlca,String serialNo){

		java.sql.Statement stat = null;
		boolean bReturnValue=true;
		String sSql = "",sFTSerialNo = "";
		try {
			stat  = Loan.createStatement();
			sFTSerialNo = DBFunction.getSerialNo("FLOW_TASK","SERIALNO",sqlca);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
				//----�ر�ԭ��������
				sSql =  " UPDATE FLOW_TASK SET  ENDTIME=to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),StandardTime1='"+this.FMStandardTime1+"',StandardTime2='"+this.FMStandardTime2+"' where SERIALNO = '"+serialNo+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
			
				//---���� FLOW_OBJECT
				sSql =  " UPDATE FLOW_OBJECT SET (PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,PhaseName, "+
						" OrgID,OrgName,UserID,UserName,InputDate) = "+
						" (select '0030','"+this.ApplyType+"','"+this.FlowNo+"','"+this.FlowName+"','0050','��������', "+
						" '','','OPS','',to_char(sysdate,'YYYY/MM/DD') from dual) where OBJECTNO = '"+this.ObjectNo+"' and OBJECTTYPE = '"+this.ObjectType+"' ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----�½�FLOW_TASK
				sSql =  " insert into FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,FlowName,PhaseNo,PhaseName, "+
				" PhaseType,ApplyType,BeginTime,UserID) values "+
				" ('"+sFTSerialNo+"','"+serialNo+"','"+this.ObjectType+"','"+this.ObjectNo+"','"+this.FlowNo+"','"+this.FlowName+"','0050','��������', "+
				" '0300','"+this.ApplyType+"',to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),'OPS') ";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				//----������Ȩ����
				Bizlet toPa = new GetFlowPool();
				toPa.setAttribute("ObjectType","CBCreditApply"); 
				toPa.setAttribute("ObjectNo",this.ObjectNo);
				toPa.setAttribute("SerialNo",sFTSerialNo);
				toPa.setAttribute("Role","A03");
				toPa.run(sqlca);
				
		} catch (Exception e) {
			logger.warn("������Ϣ "+e.getMessage());
			bReturnValue=false;
			e.printStackTrace();
		}
		finally
		{
			try {
				stat.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		return bReturnValue;
	
		
	}
	
	
	
	
	/**
	 * ��ʼ��С��������Ϣ
	 * @param sqlca
	 * @param sSerialNoBA
	 * @return
	 * @throws Exception 
	 */
	public String initFlow(Transaction sqlca,String sSerialNoBA) throws Exception{
		String sSql = "",sSerialnoFT = "";
		try{
		sSerialnoFT = DBFunction.getSerialNo("FLOW_TASK", "SERIALNO", sqlca);
		logger.debug("���������ţ�"+sSerialnoFT);
		
		sSql = "insert into flow_object(OBJECTTYPE,OBJECTNO, PHASETYPE,APPLYTYPE,FLOWNO,FLOWNAME,PHASENO,"
    		+"PHASENAME,ORGID,ORGNAME,USERID,USERNAME,INPUTDATE) values('CBCreditApply','"+sSerialNoBA
    		+"','1010','IndApply','CB0020','�Զ���������','0020','�Զ�¼��','','','admin','','"+StringFunction.getToday()+"')";
		logger.debug(sSql); 
		sqlca.executeSQL(sSql);
		
		sSql = "insert into flow_task( SERIALNO, OBJECTNO, OBJECTTYPE,FLOWNO,FLOWNAME, PHASENO,PHASENAME,"
    		+"PHASETYPE,APPLYTYPE,ORGID,ORGNAME,USERID,USERNAME,BEGINTIME) values('"
    		+sSerialnoFT+"','"+sSerialNoBA+"','CBCreditApply','CB0020','�Զ���������','0010','�Զ�¼��','1010','IndApply','','','admin','','"+StringFunction.getTodayNow()+"')";
		logger.debug(sSql);
		sqlca.executeSQL(sSql);
		}catch(Exception e){
			logger.error(e.getMessage());
			throw  e;
				
		}
		return sSerialnoFT;
	}
}
