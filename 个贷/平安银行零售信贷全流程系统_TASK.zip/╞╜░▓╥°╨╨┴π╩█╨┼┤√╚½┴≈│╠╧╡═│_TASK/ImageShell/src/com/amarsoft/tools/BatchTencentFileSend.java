 package com.amarsoft.tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Properties;
  
import sun.misc.BASE64Encoder;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.bis.middle.MD5WithRSA;

import filetrans.BankFileHandleServiceImp;
import filetrans.ResultBean;

public class BatchTencentFileSend
{
    int icount = 0;
    private static String sLocalFileUrl;// ��������·��
    private static String sXslFileNameOffer;// ƽ��ͨ������CSV�ļ�����
    private static String sXslFileNameReject;// ƽ���ܾ�����CSV�ļ�����
    private static String sBISFrontIp;// ǰ�û�IP
    private static String sBISFrontPort;// ǰ�ö˿�
    private static String NASUrl;//NAS�ռ��ַ
    private static String KEYALIAS;// ���ܴ�
    private static String KEYPASSWORD;// ������Կ
    private static String KEYSTOREPATH;// ֤���ַ
    
    public Object run(String sDate) throws Exception {
    	/** ��ʼ����Ա���� */
    	InputStream in = BatchTencentFileSend.class.getResourceAsStream("/SZPAB_EI_ENV.properties");
    	Properties property = new Properties();
    	try {
    	    property.load(in);
    	    sDate = sDate.replaceAll("/", "");
    	    NASUrl = property.getProperty("NASUrl");
    	    sLocalFileUrl = NASUrl + property.getProperty("LocalFileUrl");
    	    sXslFileNameOffer = StringFunction.replace(property.getProperty("XslFileNameOffer"), "{$CurrentDate}", sDate);
    	    sXslFileNameReject = StringFunction.replace(property.getProperty("XslFileNameReject"), "{$CurrentDate}", sDate);
    	    sBISFrontIp = property.getProperty("BISFrontIp");
    	    sBISFrontPort = property.getProperty("BISFrontPort");
    	    KEYALIAS = property.getProperty("KeyAlias");
    	    KEYPASSWORD = property.getProperty("KeyPassword");
    	    KEYSTOREPATH = NASUrl + property.getProperty("KeyStorePath");
    	} catch (IOException e) {
    	    e.printStackTrace();
    	}
    	// ��ʼ�����ļ�
    	String status = sendTencentFile();
    	return status;
        }

    /**
     * ���ļ�����
     * @param fullFileName
     * @throws Exception
     */
    public void appendToFile(String fullFileName) throws Exception {
	BufferedReader reader = new BufferedReader(new FileReader(fullFileName));
	String line = "";
	while ((line = reader.readLine()) != null) {
	    if (line.startsWith("sign,")) {
		return;
	    }
	}
	MD5WithRSA md5 = new MD5WithRSA();
	byte[] t = md5.sigFile(fullFileName, KEYALIAS, KEYPASSWORD, KEYSTOREPATH);
	BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fullFileName, true)));
	out.write("sign," + new BASE64Encoder().encode(t));
	out.close();
    }

    /**
     * ��Ѷ���������ļ�
     * 
     * @throws Exception
     */
    public String sendTencentFile() throws Exception {
	String PA_RSLT_CODE = "";
	String PA_RSLT_MESG = "�ڲ�����";
	try {
	    File file1 = new File(sLocalFileUrl + sXslFileNameOffer);
	    File file2 = new File(sLocalFileUrl + sXslFileNameReject);
	    File file3 = new File(sLocalFileUrl);

	    if (!file1.exists() || !file2.exists()) {
		System.out.println(sLocalFileUrl + sXslFileNameOffer+"/"+sXslFileNameReject + "�ļ������ڣ����ʵ��");
		return "��Ҫ���͵��ļ���" + sXslFileNameOffer+"/"+sXslFileNameReject + " �ļ������ڣ����ʵ��";
	    }
	    if (!file3.isDirectory()) {
		System.out.println("����ϵͳ����sLocalFileUrl��" + sLocalFileUrl + "����Ŀ¼��");
		return "����ϵͳ����sLocalFileUrl��" + sLocalFileUrl + "����Ŀ¼��";
	    }
	    appendToFile(sLocalFileUrl + sXslFileNameOffer);//�Է����ļ�����
	    appendToFile(sLocalFileUrl + sXslFileNameReject);
	    BankFileHandleServiceImp send = new BankFileHandleServiceImp();
	    ResultBean bean = send.sendBankFile(sLocalFileUrl + sXslFileNameOffer, sXslFileNameOffer, sBISFrontIp, Integer.parseInt(sBISFrontPort),"in");
	    PA_RSLT_CODE = bean.getPA_RSLT_CODE();
	    PA_RSLT_MESG = bean.getPA_RSLT_MESG();
	    if ("999999".equals(PA_RSLT_CODE)) {
		System.out.println("�ļ���" + sXslFileNameOffer + "���ͳɹ���");
	    } else {
		System.out.println("�ļ���" + sXslFileNameOffer + "����ʧ��:"+PA_RSLT_MESG);
		return PA_RSLT_CODE;
	    }
	    bean = send.sendBankFile(sLocalFileUrl + sXslFileNameReject, sXslFileNameReject, sBISFrontIp, Integer.parseInt(sBISFrontPort), "in");
	    PA_RSLT_CODE = bean.getPA_RSLT_CODE();
	    PA_RSLT_MESG = bean.getPA_RSLT_MESG();
	    if ("999999".equals(PA_RSLT_CODE)) {
		System.out.println("�ļ���" + sXslFileNameReject + "���ͳɹ���");
	    } else {
		System.out.println("�ļ���" + sXslFileNameReject + "����ʧ��:"+PA_RSLT_MESG);
		return PA_RSLT_CODE;
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return PA_RSLT_CODE;
    }

}
