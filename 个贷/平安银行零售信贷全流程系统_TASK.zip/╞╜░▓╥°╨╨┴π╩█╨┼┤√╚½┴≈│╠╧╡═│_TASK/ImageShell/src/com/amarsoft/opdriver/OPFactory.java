package com.amarsoft.opdriver;

public class OPFactory {

	public static String CreateOP(String sClassName,java.sql.Connection conn){
		String sReturn = "";
		try
	  	   {
			OP P = (OP)Class.forName(sClassName).newInstance();
			sReturn=P.runOP(conn);
	  	 }
	  	 catch(Exception ex)
	  	{
	  		   ex.printStackTrace();
	  		   return "";
	  	 }
		return sReturn;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
	}

}
