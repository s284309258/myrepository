package com.amarsoft.opdriver;

import java.text.DecimalFormat;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.log.Log;
/**
 * ��Ӫ�����Ŀ�ӿ�����ͳ��
 * @author yyduan 2009-11-05
 *  
 */
public class OPDriver  extends com.amarsoft.Task.ExecProgram.ExecAbstract {
	private java.sql.Connection Loan = null;
	private Log logger = new Log("OPDriver");
	
	private boolean showConsoleInfo = true;
	
	public synchronized void run() {
		String sStartTime = StringFunction.getTodayNow();
		logger.info("--------��Ӫ��ؿ�ʼ����-------,����ʱ��:"+sStartTime);
		if(showConsoleInfo) System.out.println("--------��Ӫ��ؿ�ʼ����-------,����ʱ��:"+sStartTime);		
		DBConnection dc = new DBConnection();
		double firstTime = System.currentTimeMillis();
		
		
		java.sql.ResultSet rs = null;
		java.sql.ResultSet rs2 = null;
		java.sql.Statement queryCL = null;
		java.sql.Statement querySub = null;
		java.sql.Statement updateStmt = null;
		String sKpiCode = "",sKpiName = "",sSource = "",sSourceType = "";
		
		try {
			Loan = dc.getConn("Loan");
			boolean autoCommit = Loan.getAutoCommit();
			Loan.setAutoCommit(false);
			queryCL = Loan.createStatement();
			querySub =Loan.createStatement();
			updateStmt = Loan.createStatement();
			rs = queryCL.executeQuery(" select * from code_library where codeno = 'W03Index' and isinuse='1' order by sortno ");
			while(rs.next()){
				sKpiCode = rs.getString("itemno");
				sKpiName = rs.getString("itemname");
				sSourceType = rs.getString("itemdescribe");
				sSource = rs.getString("itemattribute");
				String kpiValue = "";
				
				// ���ִ��sql
				if(sSourceType.equals("sql")){
					long startTime = System.currentTimeMillis();
					rs2 = querySub.executeQuery(sSource);
					long endTime = System.currentTimeMillis();
					double timeCost = endTime-startTime ;
					if(rs2.next()){
						kpiValue = rs2.getString(1);
						String updateSql = "update rcpm_bbam_kpi set kpi_value = "+kpiValue+"  where kpi_code = '"+sKpiCode+"'";
						updateStmt.executeUpdate(updateSql);
						
						
						logger.info("��ָ�����ƣ�"+sKpiName+",ָ����룺"+sKpiCode+",ָ��ֵ��"+kpiValue+"  ��ѯ��ʱ��"+(timeCost/1000)+"�� ---	"+sSource+"---");
						logger.info("������----"+updateSql+"---��");
						if(showConsoleInfo) System.out.println("��ָ�����ƣ�"+sKpiName+",ָ����룺"+sKpiCode+",ָ��ֵ��"+kpiValue+"  ��ѯ��ʱ��"+(timeCost/1000)+"�� ---	"+sSource+"---");
						if(showConsoleInfo) System.out.println("������----"+updateSql+"---��");
					}

				}else if(sSourceType.equals("java")){
					kpiValue = OPFactory.CreateOP(sSource,Loan);
					
				}
				else {
					logger.info("��Ҳû��");
					if(showConsoleInfo) System.out.println("��Ҳû��");
				}
				
			}
			String updateTable = "update rcpm_bbam_kpi set update_time=to_date('"+sStartTime+"','yyyy/mm/dd hh24:mi:ss') ";
			updateStmt.execute(updateTable);
			logger.info("--------����ȫ��ʱ��-------"+updateTable);
			if(showConsoleInfo) System.out.println("--------����ȫ��ʱ��-------"+updateTable);
			
			Loan.commit();
			Loan.setAutoCommit(autoCommit);
			long lastTime = System.currentTimeMillis();
			double allCost = ((Double)(lastTime - firstTime)) / 1000 / 60;
			DecimalFormat format = new DecimalFormat("#0.00");
			logger.info("--------��Ӫ�����������-------��ʱ "+format.format(allCost)+" ����");
			logger.info("");
			
			if(showConsoleInfo) System.out.println("--------��Ӫ�����������-------��ʱ "+format.format(allCost)+" ����");
		} catch (Exception e) {
			logger.warn("����ָ�꡾"+sKpiName+"��ʱ��������"+e.getMessage());
			e.printStackTrace();
		}
		finally{
			try {
				if(rs != null )rs.close();
				if(rs2 != null )rs2.close();
				if(queryCL != null )queryCL.close();
				if(querySub != null )querySub.close();
				if(Loan != null )Loan.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
