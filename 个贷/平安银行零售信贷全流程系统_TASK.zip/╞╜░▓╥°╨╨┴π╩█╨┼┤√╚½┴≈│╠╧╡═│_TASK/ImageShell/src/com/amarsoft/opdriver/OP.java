package com.amarsoft.opdriver;

import com.amarsoft.log.Log;

public abstract class OP {
	 protected java.sql.Connection conn = null; 
	 public abstract String runOP(java.sql.Connection conn);
	 protected Log logger = new Log("OPDriver");
	 
}
