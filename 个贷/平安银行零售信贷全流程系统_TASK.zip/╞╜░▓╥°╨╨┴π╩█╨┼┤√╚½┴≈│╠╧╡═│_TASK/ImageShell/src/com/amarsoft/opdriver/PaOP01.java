package com.amarsoft.opdriver;

import java.sql.Connection;

public class PaOP01 extends OP {

	@Override
	public String runOP(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

}
