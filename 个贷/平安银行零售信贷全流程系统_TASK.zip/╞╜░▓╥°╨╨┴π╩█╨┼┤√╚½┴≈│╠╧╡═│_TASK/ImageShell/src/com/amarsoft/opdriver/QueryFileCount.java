package com.amarsoft.opdriver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class QueryFileCount extends OP {

	private boolean showConsoleInfo = true;
	@Override
	public String runOP(Connection conn) {
		
		Statement queryStmt = null ;
		Statement updateStmt = null ;
		ResultSet rs = null;
		try {
			
			updateStmt = conn.createStatement();
			queryStmt = conn.createStatement();
			String querySql = " select total_uploaded,total_finished,wait_process_today,time_out_tasks,wait_process_yester,normal_user " +
						" from des_entry_monitor_info where business_type = '09' order by seq_id desc";
			rs = queryStmt.executeQuery(querySql);
			if( rs.next()){
				for(int i = 1 ; i < 7 ; i ++){
					String skpi_value = rs.getString(i);
					if( null == skpi_value ) continue;
					// �����6�Ļ�,��ֵΪ7
					if( i == 6 ) i = 7;
					String updateSql = " update rcpm_bbam_kpi set kpi_value ="+skpi_value+" where kpi_code='W03C03N302K10"+i+"' ";
					logger.info("�ĵ�¼����Ϣ������䡾"+updateSql+"��");
					if(showConsoleInfo) System.out.println("�ĵ�¼����Ϣ������䡾"+updateSql+"��");
					updateStmt.execute(updateSql);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("�ĵ�¼����Ϣ����ʧ��");
		}finally {
			try {
				if(rs != null ) rs.close();
				if(updateStmt != null ) updateStmt.close();
				if(queryStmt != null ) queryStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return "";
	}
	
}
