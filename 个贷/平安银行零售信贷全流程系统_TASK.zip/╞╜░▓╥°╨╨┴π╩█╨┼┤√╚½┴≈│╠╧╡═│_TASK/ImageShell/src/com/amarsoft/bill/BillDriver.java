package com.amarsoft.bill;

import java.sql.PreparedStatement;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.Transaction;

/**
 * Ʊ����ѯ����
 * @author XIATIAN020
 * @since 2012-05-23
 */
public class BillDriver extends ExecAbstract {
	
	public  synchronized void run() {
		
		try {
			DBConnection tl = new DBConnection();
			Transaction Sqlca = new Transaction(tl.getConn("Loan"));
			
			String SortNo1 = "";
			String SortNo2 = "";
			String sqlBL1 = " select bl.sortno from batch_lock bl where bl.lockno='CD' and bl.itemno='01' and bl.isinuse = '1' ";
			String sqlBL2 = " select bl.sortno from batch_lock bl where bl.lockno='TX' and bl.itemno='01' and bl.isinuse = '1' ";
			boolean flag = true;
			
			do{
				
			    ASResultSet rs1 = Sqlca.getASResultSet(sqlBL1);
			    ASResultSet rs2 = Sqlca.getASResultSet(sqlBL2);
				
				if(rs1.next()){
					SortNo1 = rs1.getString("sortno");
				}
				rs1.close();
				if(rs2.next()){
					SortNo2 = rs2.getString("sortno");
				}
				rs2.close();
				
				System.out.println("��ʼ����Ʊ����ѭ......");
				
				if("1".equals(SortNo2) && "1".equals(SortNo1)){
					flag = false;
				}else{
					System.out.println("�ȴ�Ʊ����ѭ.......");
					Thread.sleep(60000);
					System.out.println("�ȴ�Ʊ����ѭ���....");
				}	
			} while (flag);
			
			if("1".equals(SortNo2) && "1".equals(SortNo1)){
				
				AcceptanceDeal ad = new AcceptanceDeal();
				ad.prepare(Sqlca.conn);
				ad.processRow(Sqlca.conn);
				ad.postProcess(Sqlca.conn);
				
				DiscountedBill db = new DiscountedBill();
				db.prepare(Sqlca.conn);
				db.processRow(Sqlca.conn);
				db.postProcess(Sqlca.conn);
				
				String updateSql = "update batch_lock set sortno = '0' where lockno in('CD','TX') and itemno='01' and isinuse = '1'";
				PreparedStatement ps = Sqlca.conn.prepareStatement(updateSql);
				ps.execute();
				Sqlca.conn.commit();
				ps.close();
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}	
