package com.amarsoft.bill;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.are.util.DataConvert;


/**
 * ���ִ�����
 * @author XIATIAN020
 * @since 2012-05-23
 *
 */
public class DiscountedBill {

	private int recordCount = 0;
	private boolean duebillExists = false;
	
	/* 1.--------------�����ʱ������  start---------*/
	//�����ݱ�����SQL���
	private String sqlInsertBusiness_Duebill_Tmp = null;	//������
	private String sqlUpdateBusiness_Duebill_Tmp = null;	//���½��
	private String sqlSelectBusiness_Duebill_Tmp = null;	//������Ƿ����
	
	//��������ʱ�����ݿ����
	private PreparedStatement psInsertBusiness_Duebill_Tmp = null;
	private PreparedStatement psUpdateBusiness_Duebill_Tmp = null;
	private PreparedStatement psSelectBusiness_Duebill_Tmp = null;
	private PreparedStatement psBC = null;
	private PreparedStatement psBP = null;
	
	//�����������¼�����
	private int NumInsertBusiness_Duebill_Tmp = 0;
	private int NumUpdateBusiness_Duebill_Tmp = 0;
	private int commitRecord = 500;
	/* 1.--------------�����ʱ������  end-----------*/
	
	/* 2.--------------��ͬ������  start--------- */
	//�����ͬ������SQL���
	private String sqlUpdateBusiness_Contract = null;//���º�ͬ(��ȡ��������Ϣ)
	
	//�����������¼�����
	private int NumInsertBusiness_Contract = 0;
	/* 2.--------------��ͬ������  end----------- */
	
	/* 3.--------------���˱�����  start--------- */
	//������˱�����SQL���
	private String sqlUpdateBusiness_PutOut = null;	//���º�ͬ(��ȡ��������Ϣ)
	
	//�����������¼�����
	private int NumInsertBusiness_PutOut = 0;
	/* 3.--------------���˱�����  end----------- */
	
	
	/**
	 * ��һ�� ����׼��
	 * @throws Exception
	 */
	public void prepare(Connection Conn) throws Exception{
			
		    System.out.println("��һ��,����׼����ʼ...�����ļ�");
			//����SQL
			sqlInsertBusiness_Duebill_Tmp = "INSERT INTO BUSINESS_DUEBILL_TMP ( "
										 + "SERIALNO, "
										 + "RELATIVESERIALNO1, "
										 + "RELATIVESERIALNO2, "
										 + "SUBJECTNO, "
										 + "MFCUSTOMERID, "
										 + "CUSTOMERID, "
										 + "CUSTOMERNAME, "       
										 + "BUSINESSTYPE, "       
										 + "BUSINESSSUBTYPE, "    
										 + "BUSINESSSTATUS, "     
										 + "BUSINESSCURRENCY, "   
										 + "BUSINESSSUM, "        
										 + "PUTOUTDATE, "         
										 + "MATURITY, "           
										 + "ACTUALMATURITY, "     
										 + "BUSINESSRATE, "
										 + "ACTUALBUSINESSRATE, " 
										 + "BALANCE, "           
										 + "NORMALBALANCE, "      
										 + "OVERDUEBALANCE, "    
										 + "INTERESTBALANCE1, "   
										 + "INTERESTBALANCE2, "   
										 + "PAYACCOUNT, "         
										 + "PUTOUTACCOUNT, "      
										 + "PAYBACKACCOUNT, "     
										 + "PAYINTERESTACCOUNT, " 
										 + "TABALANCE, "          
										 + "TAINTERESTBALANCE, "  
										 + "OVERDUEDAYS, "        
										 + "TATIMES, "            
										 + "LCATIMES, "           
										 + "MFAREAID, "           
										 + "MFORGID, "            
										 + "MFUSERID, "           
										 + "OPERATEORGID, "       
										 + "OPERATEUSERID, "      
										 + "INPUTORGID, "         
										 + "INPUTUSERID, "        
										 + "TIMSFLAG, "           
										 + "ACTUALARTIFICIALNO, " 
										 + "ACCOUNTNO, "          
										 + "LOANACCOUNTNO, "      
										 + "OVERDUEDATE, "        
										 + "OWEINTERESTDATE, "    
										 + "LOANTYPE, "           
										 + "RETURNTYPE, "         
										 + "FINISHDATE, "         
										 + "SALEDATE, "           
										 + "CANCELFLAG, "         
										 + "ACCOUNTORGID "
										 + ") VALUES( "
										 + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
										 + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
										 + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
										 + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
										 + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?"
										 + ") ";
			
			// ����SQL
			sqlUpdateBusiness_Duebill_Tmp = "UPDATE BUSINESS_DUEBILL_TMP SET "
										 + "RELATIVESERIALNO1 = ? , "
										 + "RELATIVESERIALNO2 = ? , "
										 + "SUBJECTNO = ? , "
										 + "BUSINESSSTATUS = ? , "     
										 + "MATURITY = ? , "           
										 + "ACTUALMATURITY = ? , "     
										 + "BUSINESSRATE = ? , "
										 + "ACTUALBUSINESSRATE = ? , " 
										 + "BALANCE = ? , "           
										 + "NORMALBALANCE = ? , "      
										 + "OVERDUEBALANCE = ? , "    
										 + "INTERESTBALANCE1 = ? , "   
										 + "INTERESTBALANCE2 = ? , "   
										 + "PAYACCOUNT = ? , "         
										 + "PUTOUTACCOUNT = ? , "      
										 + "PAYBACKACCOUNT = ? , "     
										 + "PAYINTERESTACCOUNT = ? , " 
										 + "TABALANCE = ? , "          
										 + "TAINTERESTBALANCE = ? , "  
										 + "OVERDUEDAYS = ? , "        
										 + "MFAREAID = ? , "           
										 + "MFORGID = ? , "            
										 + "MFUSERID = ? , "           
										 + "OPERATEORGID = ? , "       
										 + "OPERATEUSERID = ? , "      
										 + "INPUTORGID = ? , "         
										 + "INPUTUSERID = ? , "        
										 + "TIMSFLAG = ? , "           
										 + "ACTUALARTIFICIALNO = ? , " 
										 + "ACCOUNTNO = ? , "          
										 + "LOANACCOUNTNO = ? , "      
										 + "OVERDUEDATE = ? , "        
										 + "OWEINTERESTDATE = ? , "    
										 + "LOANTYPE = ? , "           
										 + "RETURNTYPE = ? , "         
										 + "FINISHDATE = ? , "         
										 + "ACCOUNTORGID = ? "
										 + "WHERE SERIALNO = ? ";
			
			//��ȡ�����Ϣ
			sqlSelectBusiness_Duebill_Tmp = "select count(1) as count from BUSINESS_DUEBILL_TMP where SerialNo = ?";
			
			try {
				// ��ݱ�PreparedStatement��ֵ
				psInsertBusiness_Duebill_Tmp = Conn.prepareStatement(sqlInsertBusiness_Duebill_Tmp);
				psUpdateBusiness_Duebill_Tmp = Conn.prepareStatement(sqlUpdateBusiness_Duebill_Tmp);
				psSelectBusiness_Duebill_Tmp = Conn.prepareStatement(sqlSelectBusiness_Duebill_Tmp);
			} catch (SQLException e) {
				releaseResource();
				throw new Exception("��statement����",e);
			}
			System.out.println("��һ��,����׼������...");
	}
			
	// ���к�ͬ��		
	public void updateBusiness_Contract(String relativeSerialNo1, String relativeSerialNo2,Connection Conn) throws Exception {
		
		double balance = calBalance(relativeSerialNo1, relativeSerialNo2, Conn);
		//��Ҫȷ����Ҫ������Щ�ֶΣ����¸�SQL
		sqlUpdateBusiness_Contract = 
			" UPDATE BUSINESS_CONTRACT SET " +
			" Balance = ? " +
			" WHERE serialno = '"+relativeSerialNo2+"'";
		
		psBC = Conn.prepareStatement(sqlUpdateBusiness_Contract);
		psBC.setDouble(1, balance);
		psBC.addBatch();
		
		NumInsertBusiness_Contract++;
		
		if (NumInsertBusiness_Contract >= commitRecord) {
			psBC.executeBatch();
			NumInsertBusiness_Contract = 0;
			System.out.println("NumInsertBusiness_Contract...commit..."+recordCount);
		}
		psBC.executeBatch();
		Conn.commit();
		
	}
	
	//�����ͬ���
	public double  calBalance(String relativeSerialNo1, String relativeSerialNo2,Connection Conn) throws Exception{
		double sum  = 0d;
		String sql = "select lb.normalBalance+lb.overdueBalance as balance from loan_Balance lb  where lb.ContractserialNo = '"+relativeSerialNo2+"'";
		PreparedStatement psSql = Conn.prepareStatement(sql);
		ResultSet rsSql = psSql.executeQuery();
		String sql1 = "select lbo.normalBalance from loan_Balance_Off lbo where lbo.ContractSerialNo = '"+relativeSerialNo2+"'";
		PreparedStatement psSql1 = Conn.prepareStatement(sql1);
		ResultSet rsSql1 = psSql1.executeQuery();
		String sql2 = "select bdt.balance from BUSINESS_DUEBILL_TMP bdt where bdt.RELATIVESERIALNO1 = '"+relativeSerialNo1+"'";
		PreparedStatement psSql2 = Conn.prepareStatement(sql2);
		ResultSet rsSql2 = psSql2.executeQuery();
		while(rsSql.next()){
			sum+=rsSql.getDouble("balance");
		}
		while(rsSql1.next()){
			sum+=rsSql1.getDouble("normalBalance");
		}
		while(rsSql2.next()){
			sum+=rsSql2.getDouble("balance");
		}
		rsSql.close();
		rsSql1.close();
		rsSql2.close();
		psSql.close();
		psSql1.close();
		psSql2.close();
		return sum;
	}
	
	//���³��˱�
	public void updateBusiness_PutOut(String relativeSerialNo1,Connection Conn) throws Exception {
		
		sqlUpdateBusiness_PutOut = "update Business_PutOut set PutOutStatus = '1' where SerialNo = ?";
		psBP = Conn.prepareStatement(sqlUpdateBusiness_PutOut);
		psBP.setString(1, relativeSerialNo1);
		psBP.addBatch();
		
		NumInsertBusiness_PutOut++;
		
		if (NumInsertBusiness_PutOut >= commitRecord) {
			psBP.executeBatch();
			NumInsertBusiness_PutOut = 0;
			System.out.println("NumInsertBusiness_PutOut...commit..."+recordCount);
		}
		psBP.executeBatch();
		Conn.commit();

	}
			
			
	
	/**
	 * �ڶ��� ���ݲ���
	 */
	
	protected void processRow(Connection Conn) throws Exception {
		
		System.out.println("�ڶ���,���ݲ�����ʼ...�����ļ�");
		recordCount++;
		String deductDate = SystemConfig.getBusinessDate(Conn);
		String lastDate = DateTools.getRelativeDate(deductDate, AccountConstants.TERM_UNIT_DAY, -1);
		String sql ="select * from Discounted_Bill where InputDate = '"+lastDate+"'";
		PreparedStatement psSql = Conn.prepareStatement(sql);
		ResultSet rs = psSql.executeQuery();
		try{
			while(rs.next()){
				//�����д�����������ÿһ������
				//��ȡ������
				String serialNo = rs.getString("SerialNo");
				String relativeSerialNo1 =	rs.getString("RelativeSerialNo1");
				String relativeSerialNo2 = "";
				
				String sqlBP = "select CONTRACTSERIALNO from business_putout where serialno = '"+relativeSerialNo1+"'";
				PreparedStatement psBP = Conn.prepareStatement(sqlBP);
				ResultSet rsBP = psBP.executeQuery();
				if(rsBP.next()){
					relativeSerialNo2 = rsBP.getString("CONTRACTSERIALNO");
				}
				rsBP.close();
				psBP.close();
				System.out.println(relativeSerialNo1+"����Ƿ����");
				int sum = existBP(relativeSerialNo1,Conn);
				
				if(sum>0){
					//�ж��Ƿ���ڽ�ݣ���ȡ�������������Ͷ�����Ϣ��
					System.out.println("��ʼ�ж�Business_duebill_tmp�Ƿ����...");
					isduebillExists(serialNo,relativeSerialNo1,Conn);
                    
				}else{
                    System.out.println("�˽�ݲ����ڴ�����һ��");
					continue;
				}
				
				//��ݴ��ڶԽ�ݱ���ʱ������update������
				if (duebillExists) {
					System.out.println("Business_duebill_tmp���ڸ���");
					updateDuebill(serialNo, Conn);
					
				}else{ 
					//��ݲ����ڶԽ�ݱ���ʱ��insert������
					System.out.println("Business_duebill_tmp�����ڲ���");
					insertDuebill(serialNo,Conn);
				    
				}
				//�Գ��˱�����update��������ͬ������insert������
                System.out.println("��ʼ�Գ��˱����²���...");
				updateBusiness_PutOut(relativeSerialNo1, Conn);	
				System.out.println("���˱����²������...");
				
                System.out.println("��ʼ�Ժ�ͬ�����²���...");
				updateBusiness_Contract(relativeSerialNo1, relativeSerialNo2, Conn);
				System.out.println("��ͬ�����²������...");
                System.out.println(relativeSerialNo1+"�Ѵ������");
			}
			rs.close();
			psSql.close();
		} catch (SQLException e) {
			    releaseResource();
			    throw new Exception("Ʊ��ҵ������"+recordCount+"�����ݳ���",e);
		}
		System.out.println("�ڶ���,���ݲ�������...");
	}
		
 
	
	/**
	 * ������ �������һ�θ��¡�
	 */
	protected void postProcess(Connection Conn) throws Exception {
		
		System.out.println("������,�������һ�θ��¿�ʼ...�����ļ�");
		
		try {
			
			if (psInsertBusiness_Duebill_Tmp != null)
				
				psInsertBusiness_Duebill_Tmp.executeBatch();
				
			if (psUpdateBusiness_Duebill_Tmp != null)
				
				psUpdateBusiness_Duebill_Tmp.executeBatch();
			if(psBC!=null){
				psBC.executeBatch();
			}
			if(psBP!=null){
				psBP.executeBatch();
			}
			Conn.commit();

		} catch (SQLException e) {
			Conn.rollback();
			throw new Exception("������Ʊ��ҵ���ݱ�ʧ��");
		}
		
		releaseResource();
		
		System.out.println("�������һ�θ��½���...");
	}
	
	
	/**
	 * ����һ�������Ϣ
	 */
	public void insertDuebill(String serialNo,Connection Conn) throws SQLException {
		
		String insertSQL = " select DB.RELATIVESERIALNO1,DB.RELATIVESERIALNO2,DB.SUBJECTNO,DB.MAINCUSTOMERID,BP.CUSTOMERID," +
				           " DB.CUSTOMERNAME,BP.BUSINESSTYPE,BP.BUSINESSSUBTYPE,DB.BUSINESSSTATUS,DB.BUSINESSCURRENCY,DB.BUSINESSSUM,BP.PUTOUTDATE,BP.MATURITYDATE," +
				           " nvl(DB.ACTUALMATURITY,'') as MATURITY,DB.BUSINESSRATE,DB.BALANCE,nvl(DB.NORMALBALANCE,'0') as NORMALBALANCE,nvl(DB.OVERDUEBALANCE,'0') as OVERDUEBALANCE," +
				           " nvl(DB.DULLBALANCE,'0') as DULLBALANCE,nvl(DB.BADBALANCE,'0') as BADBALANCE,nvl(DB.INTERESTBALANCE1,'0') as INTERESTBALANCE1," +
				           " nvl(DB.INTERESTBALANCE2,'0') as INTERESTBALANCE2,nvl(DB.FINEBALANCE1,0) as FINEBALANCE1,nvl(DB.FINEBALANCE2,'0') as FINEBALANCE2," +
				           " DB.PUTOUTACCOUNT,DB.PAYBACKACCOUNT,DB.PAYINTERESTACCOUNT,DB.TABALANCE,DB.TAINTERESTBALANCE,DB.TATIMES," +
				           " DB.LCATIMES,DB.MAINORGID,BP.INPUTUSERID,BP.OPERATEORGID,BP.OPERATEUSERID,BP.INPUTORGID,BP.RETURNTYPE,DB.FINISHDATE" +
				           " from Discounted_Bill DB,Business_PutOut BP where " +
				           " DB.RELATIVESERIALNO1 = BP.serialno and DB.serialNo = '"+serialNo+"'";
		PreparedStatement ps = Conn.prepareStatement(insertSQL);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			
			// ������
			psInsertBusiness_Duebill_Tmp.setString(1, serialNo);
			psInsertBusiness_Duebill_Tmp.setString(2, DataConvert.toString(rs.getString("RELATIVESERIALNO1")));
			psInsertBusiness_Duebill_Tmp.setString(3, DataConvert.toString(rs.getString("RELATIVESERIALNO2")));
			psInsertBusiness_Duebill_Tmp.setString(4, DataConvert.toString(rs.getString("SUBJECTNO")));
			psInsertBusiness_Duebill_Tmp.setString(5, DataConvert.toString(rs.getString("MAINCUSTOMERID")));
			
			psInsertBusiness_Duebill_Tmp.setString(6, DataConvert.toString(rs.getString("CUSTOMERID")));
			psInsertBusiness_Duebill_Tmp.setString(7, DataConvert.toString(rs.getString("CUSTOMERNAME")));
			psInsertBusiness_Duebill_Tmp.setString(8, DataConvert.toString(rs.getString("BUSINESSTYPE")));
			psInsertBusiness_Duebill_Tmp.setString(9, DataConvert.toString(rs.getString("BUSINESSSUBTYPE")));
			psInsertBusiness_Duebill_Tmp.setString(10, DataConvert.toString(rs.getString("BUSINESSSTATUS")));
			
			psInsertBusiness_Duebill_Tmp.setString(11, DataConvert.toString(rs.getString("BUSINESSCURRENCY")));
			psInsertBusiness_Duebill_Tmp.setDouble(12, rs.getDouble("BUSINESSSUM"));
			psInsertBusiness_Duebill_Tmp.setString(13, DataConvert.toString(rs.getString("PUTOUTDATE")));
			psInsertBusiness_Duebill_Tmp.setString(14, DataConvert.toString(rs.getString("MATURITY")));
			psInsertBusiness_Duebill_Tmp.setString(15, DataConvert.toString(rs.getString("MATURITY")));
			psInsertBusiness_Duebill_Tmp.setDouble(16, rs.getDouble("BUSINESSRATE"));
			psInsertBusiness_Duebill_Tmp.setDouble(17, rs.getDouble("BUSINESSRATE"));
			psInsertBusiness_Duebill_Tmp.setDouble(18, rs.getDouble("BALANCE"));
			psInsertBusiness_Duebill_Tmp.setDouble(19, rs.getDouble("NORMALBALANCE"));
			psInsertBusiness_Duebill_Tmp.setDouble(20, rs.getDouble("OVERDUEBALANCE"));
			psInsertBusiness_Duebill_Tmp.setDouble(21, rs.getDouble("INTERESTBALANCE1"));
			psInsertBusiness_Duebill_Tmp.setDouble(22, rs.getDouble("INTERESTBALANCE2"));
			psInsertBusiness_Duebill_Tmp.setString(23, DataConvert.toString(rs.getString("PAYBACKACCOUNT")));
			psInsertBusiness_Duebill_Tmp.setString(24, DataConvert.toString(rs.getString("PUTOUTACCOUNT")));
			psInsertBusiness_Duebill_Tmp.setString(25, DataConvert.toString(rs.getString("PAYBACKACCOUNT")));
			psInsertBusiness_Duebill_Tmp.setString(26, DataConvert.toString(rs.getString("PAYINTERESTACCOUNT")));
			psInsertBusiness_Duebill_Tmp.setDouble(27, rs.getDouble("TABALANCE"));
			psInsertBusiness_Duebill_Tmp.setDouble(28, rs.getDouble("TAINTERESTBALANCE"));
			psInsertBusiness_Duebill_Tmp.setInt(29, 0);
			psInsertBusiness_Duebill_Tmp.setInt(30, rs.getInt("TATIMES"));
			psInsertBusiness_Duebill_Tmp.setInt(31, rs.getInt("LCATIMES"));
			psInsertBusiness_Duebill_Tmp.setString(32, ""); //����������
			psInsertBusiness_Duebill_Tmp.setString(33, DataConvert.toString(rs.getString("MAINORGID")));
			psInsertBusiness_Duebill_Tmp.setString(34, DataConvert.toString(rs.getString("INPUTUSERID")));
			psInsertBusiness_Duebill_Tmp.setString(35, DataConvert.toString(rs.getString("OPERATEORGID")));
			psInsertBusiness_Duebill_Tmp.setString(36, DataConvert.toString(rs.getString("OPERATEUSERID")));
			psInsertBusiness_Duebill_Tmp.setString(37, DataConvert.toString(rs.getString("INPUTORGID")));
			psInsertBusiness_Duebill_Tmp.setString(38, DataConvert.toString(rs.getString("INPUTUSERID")));
			psInsertBusiness_Duebill_Tmp.setString(39, "");//����ҵ���־
			psInsertBusiness_Duebill_Tmp.setString(40, DataConvert.toString(rs.getString("PUTOUTACCOUNT")));
			psInsertBusiness_Duebill_Tmp.setString(41, "");//�����˺�
			psInsertBusiness_Duebill_Tmp.setString(42, "");//���������ʺ�
			psInsertBusiness_Duebill_Tmp.setString(43, "");//��������
			psInsertBusiness_Duebill_Tmp.setString(44, "");//ǷϢ����
			psInsertBusiness_Duebill_Tmp.setString(45, "");//��������
			psInsertBusiness_Duebill_Tmp.setString(46, DataConvert.toString(rs.getString("RETURNTYPE")));
			psInsertBusiness_Duebill_Tmp.setString(47, DataConvert.toString(rs.getString("FINISHDATE")));
			psInsertBusiness_Duebill_Tmp.setString(48, "");
			psInsertBusiness_Duebill_Tmp.setString(49, "");
			psInsertBusiness_Duebill_Tmp.setString(50, DataConvert.toString(rs.getString("INPUTORGID")));

			
			psInsertBusiness_Duebill_Tmp.addBatch();
			
			NumInsertBusiness_Duebill_Tmp++;
			
			if (NumInsertBusiness_Duebill_Tmp >= commitRecord) {
				psInsertBusiness_Duebill_Tmp.executeBatch();
				NumInsertBusiness_Duebill_Tmp = 0;
				System.out.println("NumInsertBusiness_Duebill_Tmp...commit..."+recordCount);
			}
			psInsertBusiness_Duebill_Tmp.executeBatch();
			Conn.commit();
		}
            rs.close();
            ps.close();
	}
	
	
	/**
	 * ����һ�������Ϣ
	 */
	private void updateDuebill(String serialNo,Connection Conn) throws SQLException {
		
		String selectsql = " select DB.RELATIVESERIALNO1,DB.RELATIVESERIALNO2,DB.SUBJECTNO,DB.MAINCUSTOMERID,BP.CUSTOMERID," +
				           " DB.CUSTOMERNAME,BP.BUSINESSTYPE,BP.BUSINESSSUBTYPE,DB.BUSINESSSTATUS,DB.BUSINESSSUM,BP.PUTOUTDATE,BP.MATURITYDATE," +
				           " nvl(DB.ACTUALMATURITY,'') as ACTUALMATURITY,DB.BUSINESSRATE,DB.BALANCE,nvl(DB.NORMALBALANCE,'0') as NORMALBALANCE,nvl(DB.OVERDUEBALANCE,'0') as OVERDUEBALANCE," +
				           " nvl(DB.DULLBALANCE,'0') as DULLBALANCE,nvl(DB.BADBALANCE,'0') as BADBALANCE,nvl(DB.INTERESTBALANCE1,'0') as INTERESTBALANCE1," +
				           " nvl(DB.INTERESTBALANCE2,'0') as INTERESTBALANCE2,nvl(DB.FINEBALANCE1,0) as FINEBALANCE1,nvl(DB.FINEBALANCE2,'0') as FINEBALANCE2," +
				           " DB.PUTOUTACCOUNT,DB.PAYBACKACCOUNT,DB.PAYINTERESTACCOUNT,DB.TABALANCE,DB.TAINTERESTBALANCE,BP.OPERATEORGID,DB.TATIMES," +
				           " DB.LCATIMES,DB.MAINORGID,BP.INPUTUSERID,BP.INPUTORGID,BP.RETURNTYPE,DB.FINISHDATE" +
				           " from Discounted_Bill DB,Business_PutOut BP where " +
				           " DB.RELATIVESERIALNO1 = BP.serialno and DB.serialNo = '"+serialNo+"'";
		PreparedStatement ps = Conn.prepareStatement(selectsql);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			
		//��������
		psUpdateBusiness_Duebill_Tmp.setString(1, DataConvert.toString(rs.getString("RELATIVESERIALNO1")));
		psUpdateBusiness_Duebill_Tmp.setString(2, DataConvert.toString(rs.getString("RELATIVESERIALNO2")));
		psUpdateBusiness_Duebill_Tmp.setString(3, DataConvert.toString(rs.getString("SUBJECTNO")));
		psUpdateBusiness_Duebill_Tmp.setString(4, DataConvert.toString(rs.getString("BUSINESSSTATUS")));
		psUpdateBusiness_Duebill_Tmp.setString(5, DataConvert.toString(rs.getString("MATURITYDATE")));
		psUpdateBusiness_Duebill_Tmp.setString(6, DataConvert.toString(rs.getString("ACTUALMATURITY")));
		psUpdateBusiness_Duebill_Tmp.setDouble(7, rs.getDouble("BUSINESSRATE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(8, rs.getDouble("BUSINESSRATE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(9, rs.getDouble("BALANCE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(10, rs.getDouble("NORMALBALANCE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(11, rs.getDouble("OVERDUEBALANCE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(12, rs.getDouble("INTERESTBALANCE1"));
		psUpdateBusiness_Duebill_Tmp.setDouble(13, rs.getDouble("INTERESTBALANCE2"));
		psUpdateBusiness_Duebill_Tmp.setString(14, DataConvert.toString(rs.getString("PAYBACKACCOUNT")));
		psUpdateBusiness_Duebill_Tmp.setString(15, DataConvert.toString(rs.getString("PUTOUTACCOUNT")));
		psUpdateBusiness_Duebill_Tmp.setString(16, DataConvert.toString(rs.getString("PAYBACKACCOUNT")));
		psUpdateBusiness_Duebill_Tmp.setString(17, DataConvert.toString(rs.getString("PAYINTERESTACCOUNT")));
		psUpdateBusiness_Duebill_Tmp.setDouble(18, rs.getDouble("TABALANCE"));
		psUpdateBusiness_Duebill_Tmp.setDouble(19, rs.getDouble("TAINTERESTBALANCE"));
		psUpdateBusiness_Duebill_Tmp.setInt(20, 0);//��������
		psUpdateBusiness_Duebill_Tmp.setString(21, "");//����������
		psUpdateBusiness_Duebill_Tmp.setString(22, DataConvert.toString(rs.getString("MAINORGID")));//����������
		psUpdateBusiness_Duebill_Tmp.setString(23, DataConvert.toString(rs.getString("INPUTUSERID")));//������Ա��
		psUpdateBusiness_Duebill_Tmp.setString(24, DataConvert.toString(rs.getString("OPERATEORGID")));
		psUpdateBusiness_Duebill_Tmp.setString(25, DataConvert.toString(rs.getString("INPUTUSERID")));//������
		psUpdateBusiness_Duebill_Tmp.setString(26, DataConvert.toString(rs.getString("INPUTORGID")));//�Ǽǻ���
		psUpdateBusiness_Duebill_Tmp.setString(27, DataConvert.toString(rs.getString("INPUTUSERID")));
		psUpdateBusiness_Duebill_Tmp.setString(28, "");//����ҵ���ʶ
		psUpdateBusiness_Duebill_Tmp.setString(29, "");//ʵ�ʺ�ͬ��
		psUpdateBusiness_Duebill_Tmp.setString(30, DataConvert.toString(rs.getString("PUTOUTACCOUNT")));//�����˺�
		psUpdateBusiness_Duebill_Tmp.setString(31, DataConvert.toString(rs.getString("PUTOUTACCOUNT")));//���������˺�
		psUpdateBusiness_Duebill_Tmp.setString(32, "");//��������
		psUpdateBusiness_Duebill_Tmp.setString(33, "");//ǷϢ����
		psUpdateBusiness_Duebill_Tmp.setString(34, DataConvert.toString(rs.getString("BUSINESSTYPE")));
		psUpdateBusiness_Duebill_Tmp.setString(35, DataConvert.toString(rs.getString("RETURNTYPE")));
		psUpdateBusiness_Duebill_Tmp.setString(36, DataConvert.toString(rs.getString("FINISHDATE")));
		psUpdateBusiness_Duebill_Tmp.setString(37, DataConvert.toString(rs.getString("INPUTORGID")));
		psUpdateBusiness_Duebill_Tmp.setString(38, serialNo);

		psUpdateBusiness_Duebill_Tmp.addBatch();
		NumUpdateBusiness_Duebill_Tmp++;

		if (NumUpdateBusiness_Duebill_Tmp >= commitRecord) {
			psUpdateBusiness_Duebill_Tmp.executeBatch();
			NumUpdateBusiness_Duebill_Tmp = 0;
			System.out.println("����Ʊ��ҵ����Ϣ����..."+recordCount);
		}
		psUpdateBusiness_Duebill_Tmp.executeBatch();
		Conn.commit();
	 }
        rs.close();		
        ps.close();
	}
	
	/**
	 * �жϽ���Ƿ����
	 * @throws SQLException
	 */
	protected void isduebillExists(String duebillNo, String relativeSerialNo1,Connection Conn) throws SQLException {
		
		//��ȡ��ݱ�����Ϣ
		psSelectBusiness_Duebill_Tmp.setString(1, duebillNo);
		ResultSet rs = psSelectBusiness_Duebill_Tmp.executeQuery();
		while(rs.next()) {
			int sum = rs.getInt("count");
			if(sum>0){
				duebillExists = true;
			}
		}
		rs.close();
	}
	
	
	/**
	 * �ͷ����ݿ���Դ
	 *
	 */
	public void releaseResource(){
		
		if (psInsertBusiness_Duebill_Tmp != null) {
			try{
				psInsertBusiness_Duebill_Tmp.close();
			}catch(SQLException e){e.printStackTrace();}
		}

		if (psUpdateBusiness_Duebill_Tmp != null) {
			try{
				psUpdateBusiness_Duebill_Tmp.close();
			}catch(SQLException e){e.printStackTrace();}
		}

		if (psSelectBusiness_Duebill_Tmp != null) {
			try{
				psSelectBusiness_Duebill_Tmp.close();
			}catch(SQLException e){e.printStackTrace();}
		}
		if(psBC!=null){
			try{
				psBC.close();
			}catch(SQLException e){e.printStackTrace();}
		}
		if(psBP!=null){
			try{
				psBP.close();
			}catch(SQLException e){e.printStackTrace();}
		}
	}
	
	public int existBP(String serialNo,Connection Conn) throws Exception{
		
		String sql1 = " select count(*) as counts from business_putout where serialno = '"+serialNo+"' ";
		PreparedStatement ps = Conn.prepareStatement(sql1);
		ResultSet rsPs = ps.executeQuery();
		int sum = 0;
		if(rsPs.next()){
			sum = rsPs.getInt("counts");
		}
		rsPs.close();
		ps.close();
		return sum;
	}
	
	public static String getStringDateShort() {
		
	    Date currentTime = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
	    String dateString = formatter.format(currentTime);
	    return dateString;
		  
	}
}
