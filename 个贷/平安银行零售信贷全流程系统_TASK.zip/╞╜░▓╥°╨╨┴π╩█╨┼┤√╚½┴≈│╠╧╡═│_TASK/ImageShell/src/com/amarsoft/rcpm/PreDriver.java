package com.amarsoft.rcpm;

//import com.amarsoft.XBLoan.XBRule;
import com.amarsoft.AppTools;
import com.amarsoft.are.sql.*;
//import com.amarsoft.are.util.DataConvert;
//import com.amarsoft.scen.config.ASConfigure;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.log.Log;
/**
 * ����ԤԼ�����������
 * @author yyduan
 *
 */
public class PreDriver  extends com.amarsoft.Task.ExecProgram.ExecAbstract {
	private java.sql.Connection Loan = null;
	private Transaction Sqlca = null;
	private Log logger = null;
	public synchronized void run() {
		DBConnection dc = new DBConnection();
		this.logger = new Log("PreDriver");
		System.out.println("����ʼ"+AppTools.getNowTime());
		try {
				Loan = dc.getConn("Loan");
				java.sql.ResultSet rs = null;
				java.sql.Statement stat = null;
				//Sqlca = new Transaction(Loan);
				//InitPara.loadConfig(Sqlca);
				String sSql = "",sSerialNo = "";
				//---------------����ԤԼ����--------------------------------
				//120������������
				sSql = "select ObjectNo"+
					" from flow_pre where objecttype = 'FlowApply' and status='0' and PreType = '0' and (to_date(pretime, 'yyyy/MM/dd hh24:mi:ss')- sysdate)*60*60*24 < 120";
				logger.debug(sSql);
				logger.info("ԤԼ��������ʼ");
				stat=Loan.createStatement();
				rs=stat.executeQuery(sSql);
				while(rs.next()){
					sSerialNo = rs.getString("ObjectNo");
					Loan.setAutoCommit(false);
					sSql = "update flow_pre set status='1' where objecttype = 'FlowApply' and ObjectNo = '"+sSerialNo+"'";
					logger.debug(sSql);
					stat.executeUpdate(sSql);
					sSql = "update flow_task set UNTREADFLAG='1' where SerialNo = '"+sSerialNo+"'";
					logger.debug(sSql);
					stat.executeUpdate(sSql);
					sSql = "update flow_pre set status='1' where objectno = '"+sSerialNo+"' and objecttype = 'FlowApply'";
					logger.debug(sSql);
					stat.executeUpdate(sSql);
					
					Loan.commit();
					Loan.setAutoCommit(true);
				}
				rs.close();
				stat.close();
				/**
				//----------------�Զ����Ŵ���-------------------------------
				Sqlca.conn.setAutoCommit(false);
				sSql = "select ft.serialno,ft.objectno from flow_pre fp,flow_task ft " +
				"where fp.objectno=ft.serialno and  fp.pretype = '1' and fp.status='0' and fp.objecttype = 'FlowApply'";
				
				logger.debug(sSql);
				ASResultSet rsLoan = Sqlca.getASResultSet(sSql);
				
				String sFTSerialNo = "",sBASerialNo = "";
				while(rsLoan.next()){
					sFTSerialNo=DataConvert.toString(rsLoan.getString("serialno"));
					sBASerialNo = DataConvert.toString(rsLoan.getString("objectno"));
					logger.info("�ҵ�����ʼִ���Զ�����"+sFTSerialNo);
					new XBRule().runRule(sFTSerialNo,sBASerialNo,Sqlca);
					sSql = "update flow_pre set status='1' where objectno = '"+sFTSerialNo+"' and objecttype = 'FlowApply'";
					logger.debug(sSql);
					Sqlca.executeSQL(sSql);
				}
				rsLoan.getStatement().close();
				Sqlca.conn.commit();
				//------------------------------------------------------------
				Sqlca.disConnect();
				**/
				Loan.close();
		} catch (Exception e) {
			logger.warn("��ʼ�����д���,������Ϣ "+e.getMessage());
			e.printStackTrace();
		}
		finally{
			try {
			Sqlca.disConnect();
			Loan.close();
			} catch (Exception e) {
				
			}
		}
	}

}
