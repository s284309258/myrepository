package com.amarsoft.rcpm;

import com.amarsoft.Log.logger;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.scen.config.ASConfigure;

public class InitPara {
//	 װ�ػ������ڴ�
    public static void loadConfig(Transaction Sqlca)
    {
        try
        {
        	
        	logger.info("��ʼ������ʼ");
        	
        	ASConfigure.getSysConfig("ASCodeSet", Sqlca);
        	logger.info("3 "+"ASCodeSet");
            ASConfigure.getSysConfig("SYSCONF_BO_TYPE", Sqlca);
            logger.info("4 "+"SYSCONF_BO_TYPE");
            ASConfigure.getSysConfig("SYSCONF_DTREE", Sqlca);
            logger.info("5 "+"SYSCONF_DTREE");
            ASConfigure.getSysConfig("SYSCONF_RULESET", Sqlca);
            logger.info("6 "+"SYSCONF_RULESET");
            ASConfigure.getSysConfig("SYSCONF_POLICY", Sqlca);
            logger.info("7 "+"SYSCONF_POLICY");
            
            logger.info("��ʼ�����������ʼ");
            
        	OCIConfig.loadOCIConfig(true);
			OCIConfig.setEnvironment("Cycle");
    		OCIConfig.setDataSourceName("Loan");
    		OCIConfig.setImageDataSourceName("IMS");
			SystemConfig.loadSystemConfig(true, Sqlca.conn);
			
            logger.info("��ʼ����Ϣ����");
           
        } catch (Exception e)
        {
            e.printStackTrace();
            logger.error("loadConfig()]����ϵͳ����ʱ������" + e);
            System.out.println(e.getMessage());
            throw new RuntimeException("loadConfig()]����ϵͳ����ʱ������" + e);
        }
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
