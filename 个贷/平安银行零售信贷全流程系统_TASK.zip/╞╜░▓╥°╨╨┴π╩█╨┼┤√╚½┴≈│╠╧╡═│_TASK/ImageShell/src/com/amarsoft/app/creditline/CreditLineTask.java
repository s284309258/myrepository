package com.amarsoft.app.creditline;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.amarsoft.AppTools;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.ASValuePool;
import com.amarsoft.log.Log;
import com.amarsoft.rcpm.InitPara;

public class CreditLineTask extends com.amarsoft.Task.ExecProgram.ExecAbstract {
	private java.sql.Connection Loan = null;
	private Log logger = null;
	public synchronized void run() {
		System.out.println("��ȸ�����ѭ��ʼ��"+AppTools.getDateTime(new Date(),"yyyy-MM-dd HH:mm:ss"));
		DBConnection dc = new DBConnection();
		Transaction Sqlca = null;
		String sLogin = "";//ϵͳ���ű�ʾ���Ƿ�������½��0 ���Ե�¼��1���ܵ�¼��
		String sSql = "";
		PreparedStatement ps = null;
		ResultSet rs = null;
		this.logger = new Log("CreditLine");
		try {
			while(true)
			{
				Loan = dc.getConn("Loan");
				Sqlca= new Transaction(Loan);
				InitPara.loadConfig(Sqlca);
				//��鵱�������Ƿ����
				sSql = "select Login from PLOAN_SETUP";
				try
				{
					ps = Loan.prepareStatement(sSql);
					rs = ps.executeQuery();
					if(rs.next())
					{
						sLogin = rs.getString("Login");
					}
					rs.close();
					ps.close();
					rs = null;
					ps = null;
				}catch(SQLException ex)
				{
					ex.printStackTrace();
					throw ex;
				}
				finally
				{
					if(ps != null) ps.close();
					if(rs != null) rs.close();
				}
				if(!"0".equals(sLogin))
				{
					Loan.rollback();
					Loan.close();
					Loan = null;
					System.out.println("˯��10����");
					Thread.sleep(600000);
				}
				else
				{
					break;
				}
			}
			
			
			if("0".equals(sLogin)) //ϵͳ����ʱ���д���
			{
				//��ѯ��Ҫ���µĺ�ͬ
				sSql = "select SerialNo from BUSINESS_CONTRACT where PutOutType in('010','050') and FinishDate is null and BusinessKind = 'SWPM' ";
				PreparedStatement bcUpdate = null,creditSelect = null,putSelect = null,loanSelect = null,loanOffSelect = null,billSelect = null,bailSelect = null,guarantySelect = null;
				try
				{
					ps = Loan.prepareStatement(sSql);
					bcUpdate = Loan.prepareStatement("update BUSINESS_CONTRACT set UseSum = ?,UseBalance = ? where SerialNo = ? ");
					creditSelect = Loan.prepareStatement("select SerialNo,CycleFlag,BusinessSum,Currency,FreezeFlag,MaturityDate,BailRatio,RelativeCreditNo,RelativeAggreement from BUSINESS_CONTRACT where SerialNo = ? ");
					putSelect = Loan.prepareStatement("select SerialNo as PutOutNo,BusinessSum,Currency,PutOutStatus,BusinessSubType from BUSINESS_PUTOUT where ContractSerialNo = ? ");
					loanSelect = Loan.prepareStatement("select PutOutNo,BusinessSum,Currency,NormalBalance,OverdueBalance from LOAN_BALANCE where ContractSerialNo = ? ");
					loanOffSelect = Loan.prepareStatement("select PutOutNo,BusinessSum,Currency,NormalBalance from LOAN_BALANCE_OFF where ContractSerialNo = ? ");
					billSelect = Loan.prepareStatement("select RelativeSerialNo1 as PutOutNo,BusinessSum,BusinessCurrency as Currency,Balance from ACCEPTANCE_BILL where RelativeSerialNo2 = ? ");
					bailSelect = Loan.prepareStatement("select ObjectNo as PutOutNo,ChangeSum as BailSum,BailCurrency as Currency from BAIL_INFO where ObjectType = 'SWPutOutApply' and exists(select 'X' from BUSINESS_PUTOUT where ContractSerialNo = ? and SerialNo = BAIL_INFO.ObjectNo)");
					guarantySelect = Loan.prepareStatement("select GuarantyType,Currency,ConfirmValue from GUARANTY_INFO where GuarantyID in(select GuarantyID from GUARANTY_RELATIVE where ObjectNo = ? and ObjectType = 'SWContractApply')");
					rs = ps.executeQuery();
					int icount = 0;
					while(rs.next())
					{
						String sSerialNo = rs.getString("SerialNo");
						try
						{
							CreditSingleObject cso = new CreditSingleObject();
							cso.load(this.createDataPool(creditSelect, sSerialNo),
									this.createDataSet(putSelect, sSerialNo),
									this.createDataSet(loanSelect, sSerialNo),
									this.createDataSet(loanOffSelect, sSerialNo),
									this.createDataSet(billSelect, sSerialNo),
									this.createDataSetMap(bailSelect, sSerialNo,"PutOutNo"),
									this.createDataSet(guarantySelect, sSerialNo));
							cso.calcBalance();
							bcUpdate.setDouble(1, cso.useSum);
							bcUpdate.setDouble(2, cso.useBalance);
							bcUpdate.setString(3, sSerialNo); 
							bcUpdate.addBatch();
							icount ++;
							if(icount >=1000)
							{
								icount=0;
								bcUpdate.executeBatch();
								Loan.commit();
							}
						}catch(Exception ex)
						{
							System.out.println("��ͬ���"+sSerialNo+"�������쳣��");
							ex.printStackTrace();
							throw ex;
						}
					}
					rs.close();
					bcUpdate.executeBatch();
				}catch(SQLException ex)
				{
					ex.printStackTrace();
					throw ex;
				}
				catch(Exception e)
				{
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(ps != null) ps.close();
					if(rs != null) rs.close();
					if(bcUpdate != null) bcUpdate.close();
					if(creditSelect != null) creditSelect.close();
					if(putSelect != null) putSelect.close();
					if(loanSelect != null) loanSelect.close();
					if(loanOffSelect != null) loanOffSelect.close();
					if(billSelect != null) billSelect.close();
					if(bailSelect != null) bailSelect.close();
					if(guarantySelect != null) guarantySelect.close();
				}
			}	
		}catch (Exception e) {
			try
			{
				Loan.rollback();
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			logger.warn("��ʼ�����д���,������Ϣ "+e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(Sqlca!=null)
				{
					Sqlca.conn.commit();
					Sqlca.disConnect();
				}
				Sqlca = null;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		System.out.println("��ȸ�����ѭ������"+AppTools.getDateTime(new Date(),"yyyy-MM-dd HH:mm:ss"));
	}
	
	
	/* 
	 * ͨ��SQL�������ݼ���
	 * @param Sql,connection
	 * @return	���ؽ����ASValuePool			 
	 * @throws Exception
	 */
	public ASValuePool createDataPool(PreparedStatement ps,String sSerialNo) throws Exception{
		ASValuePool dataPool = null;
		ResultSet rs = null;
		try{
			ps.setString(1, sSerialNo);
			rs = ps.executeQuery();
			if(rs.next()){
				dataPool = new ASValuePool();
	    		ResultSetMetaData rsmd = rs.getMetaData();
	    		for(int i=1;i<=rsmd.getColumnCount();i++){
	    			dataPool.setAttribute(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
	    		}
			}
			rs.close();
			rs = null;
		}
		catch(Exception ex)
		{
			throw ex;
		}finally
		{
			if(rs!=null) rs.close();
		}
		return dataPool;
	}
	
	/* 
	 * ͨ��SQL�������ݼ���
	 * @param Sql,connection
	 * @return	���ؽ����ArrayList<ASValuePool>	 
	 * @throws Exception
	 */
	public ArrayList<ASValuePool> createDataSet(PreparedStatement ps,String sSerialNo) throws Exception{
		ArrayList<ASValuePool> dataSet = new ArrayList<ASValuePool>();
		ResultSet rs = null;
		try{
			ps.setString(1, sSerialNo);
			rs = ps.executeQuery();
			while(rs.next()){
				ASValuePool dataPool = new ASValuePool();
	    		ResultSetMetaData rsmd = rs.getMetaData();
	    		for(int i=1;i<=rsmd.getColumnCount();i++){
	    			dataPool.setAttribute(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
	    		}
	    		dataSet.add(dataPool);
			}
			rs.close();
			rs = null;
		}
		catch(Exception ex)
		{
			throw ex;
		}finally
		{
			if(rs!=null) rs.close();
		}
		return dataSet;
	}
	
	
	/* 
	 * ͨ��SQL�������ݼ���
	 * @param Sql,connection
	 * @return	���ؽ����ArrayList<ASValuePool>	 
	 * @throws Exception
	 */
	public HashMap<String,ArrayList<ASValuePool>> createDataSetMap(PreparedStatement ps,String sSerialNo,String mapKey) throws Exception{
		HashMap<String,ArrayList<ASValuePool>> dataSetMap = new HashMap<String,ArrayList<ASValuePool>>();
		ResultSet rs = null;
		try{
			ps.setString(1, sSerialNo);
			rs = ps.executeQuery();
			while(rs.next()){
				ASValuePool dataPool = new ASValuePool();
	    		ResultSetMetaData rsmd = rs.getMetaData();
	    		for(int i=1;i<=rsmd.getColumnCount();i++){
	    			dataPool.setAttribute(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
	    		}
	    		
	    		//��������
	    		String mapKeyValue = dataPool.getString(mapKey);
				ArrayList<ASValuePool> dataSet = dataSetMap.get(mapKeyValue);
				if(dataSet == null)
				{
					dataSet = new ArrayList<ASValuePool>();
					dataSetMap.put(mapKeyValue, dataSet);
				}
	    		dataSet.add(dataPool);
			}
			rs.close();
			rs = null;
		}
		catch(Exception ex)
		{
			throw ex;
		}finally
		{
			if(rs!=null) rs.close();
		}
		return dataSetMap;
	}
}

 