package com.amarsoft.Image;
public class DriverTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
