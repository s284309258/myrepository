package com.amarsoft.Image.Driver;

import java.sql.SQLException;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.Image.Image;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.account.sysconfig.SystemConfig;
/**
 * ���̵Ĳ�������
 * @author 
 *
 */
public class PutDriver extends RunDriver {
	
	public PutDriver(Image image){
		try{
			DBConnection dc = new DBConnection();
			this.Loan=image.getConnection();
			this.IMS = dc.getConn("IMS");
			this.img=image;
			this.startDriver();
			this.IMS.close();
		}catch(Exception e){
			try
			{
				if(this.IMS != null) this.IMS.close();
			}
			catch(Exception ex)
			{
				logger.error(""+ex.getMessage());
			}
			
			logger.error(""+e.getMessage());
		}
	}
	/**
	 * ʵ���Լ����߼�
	 */
	public boolean startDriver(){
		logger.info("����������ʼ");
		logger.info("���ʹ�����������ˮ�ţ�"+this.img.getObjectNo());
		java.sql.ResultSet rs = null;
		java.sql.Statement stat = null;
		java.sql.Statement stat1 = null;
		java.sql.Statement statIMS = null;
		java.sql.ResultSet rsIMS = null;
		java.sql.ResultSet rsTemp = null;
		String sSql = "";
		try {
			stat  = this.Loan.createStatement();
			stat1  = this.Loan.createStatement();
			statIMS = this.IMS.createStatement();
			String sTime = SystemConfig.getBusinessDate(this.Loan) + " " + StringFunction.getNow();
			if(img.getObjectType().equals(("CBPutOutApply"))|| img.getObjectType().equals(("CBCreditApply")) || img.getObjectType().equals(("SWCreditApply")) || img.getObjectType().equals(("SWPutOutApply"))){
			//CBPutOutApply	 ���������飨��ȣ�������(BUSINESS_PUTOUT.SerialNo)
				sSql = "select FlowNo from FLOW_TASK where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType = '"+this.img.getObjectType()+"' and UserID = 'RCPM' and EndTime is null";
				logger.debug(sSql);
				rs = stat.executeQuery(sSql);  
				if(rs.next()){
					String sFlowNo = rs.getString(1);
					if(sFlowNo.equals("CBCarPutOutFlow"))
					{
						sSql = "select BAR_CODE_NO from DOCUMENT_KB where DOCUMENT_CODE = 'KB80' and BAR_CODE_NO = '"+this.img.getRelativeBarCode()+"' and SCAN_SEQNO ='99'  ";
						System.out.println(sSql);
						logger.debug(sSql);
						rsIMS = statIMS.executeQuery(sSql);
						if(rsIMS.next())
						{
							/*
							sSql = " select UserID,UserName,OrgID,OrgName from FLOW_TASK where ObjectType = 'CBCreditApply' and ObjectNo = (select bc.relativeserialno from business_contract bc,business_putout bp where bc.serialno = bp.contractserialno and bp.serialno = '"+this.img.getObjectNo()+"') and PhaseNo = '0040' ";
							logger.debug(sSql);
							rsTemp = stat1.executeQuery(sSql);
							if(rsTemp.next());
							{
								String UserID = rsTemp.getString("UserID");
								String UserName = rsTemp.getString("UserName");
								String OrgID = rsTemp.getString("OrgID");
								String OrgName = rsTemp.getString("OrgName");
								
								
								sSql = "update FLOW_TASK set UserID = '"+UserID+"',UserName = '"+UserName+"',OrgID='"+OrgID+"',OrgName = '"+OrgName+"',BeginTime = '"+sTime+"',ActualBeginTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType = '"+this.img.getObjectType()+"' and UserID = 'RCPM' and EndTime is null";
								logger.debug(sSql);
								stat.executeUpdate(sSql);
								endDriver();
							}
							rsTemp.close();
							*/
							
							sSql = "update FLOW_TASK set UserID = 'OPS',BeginTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType = '"+this.img.getObjectType()+"' and UserID = 'RCPM' and EndTime is null";
							logger.debug(sSql);
							stat.executeUpdate(sSql);
							endDriver();
						}
						else bReturnValue=false;
						rsIMS.close();
						
					}
					else
					{
						sSql = "update FLOW_TASK set UserID = 'OPS',BeginTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType = '"+this.img.getObjectType()+"' and UserID = 'RCPM' and EndTime is null";
						logger.debug(sSql);
						stat.executeUpdate(sSql);
						endDriver();
					}
				} else bReturnValue=false;
				rs.close();
				
			}else if(img.getObjectType().equals(("CBPutOutFill2"))){
			//CBPutOutFill2	 �������ҵ�񲹼�֪ͨ��(BUSINESS_PUTOUT.SerialNo)  
				sSql = "update CHECKUP_INFO set TaskStatus = '03',EndTime = '"+sTime+"' where TaskNo||EventType1 = '"+this.img.getObjectNo()+"' and TaskStatus = '02' and EventType = '02' and EventType1 = '020'";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				endDriver();
			}else if(img.getObjectType().equals(("CBPutOutFill1"))){
			//CBPutOutFill1	 �������ѺƷ����֪ͨ��(BUSINESS_PUTOUT.SerialNo) 
				sSql = "update CHECKUP_INFO set TaskStatus = '03',EndTime = '"+sTime+"' where TaskNo||EventType1 = '"+this.img.getObjectNo()+"' and TaskStatus = '02' and EventType = '02' and EventType1 = '010'";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				endDriver();
			}else if(img.getObjectType().equals(("GuarantyReport"))){
			//GuarantyReport   �������油����(BUSINESS_CONTRACT.SerialNo)
				sSql = "update CHECKUP_INFO set TaskStatus = '03',EndTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType in('CBContractApply','SWContractApply') and TaskStatus = '02' and EventType= '03' and EventType1 = '020'";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				endDriver();
			}else if(img.getObjectType().equals(("GuarantyPolicy"))){
			//GuarantyPolicy   ����������(BUSINESS_CONTRACT.SerialNo)
				sSql = "update CHECKUP_INFO set TaskStatus = '03',EndTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType in('CBContractApply','SWContractApply') and TaskStatus = '02' and EventType= '03' and EventType1 = '030'";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				endDriver();
			}else if(img.getObjectType().equals(("GuarantyContract"))){
			//GuarantyContract ������ͬ������(BUSINESS_CONTRACT.SerialNo)
				sSql = "update CHECKUP_INFO set TaskStatus = '03',EndTime = '"+sTime+"' where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType in('CBContractApply','SWContractApply') and TaskStatus = '02' and EventType= '03' and EventType1 = '010'";
				logger.debug(sSql);
				stat.executeUpdate(sSql);
				endDriver();
			}
		} catch (Exception e) {
			logger.info("��������ʧ��:FLOW_TASK.SERIALNO��"+img.getObjectNo()+"��"+e.getMessage());
			e.printStackTrace();
			 bReturnValue=false;
		}
		finally
		{
			try {
				if( stat != null ) stat.close();
				if( stat1 != null ) stat1.close();
				if( statIMS != null ) statIMS.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		
		return true;
	}
	/**
	 * ����������һ������
	 */
	public boolean endDriver(){
		java.sql.Statement stat = null;
		String sSql = "";
		try {
			sSql ="update barcode_relative set status='1' where barcode='"+img.getBarCodeNo()+"' and objectno = '"+img.getObjectNo()+"' and objecttype = '"+img.getObjectType()+"'";
			logger.info(sSql);
			stat=this.Loan.prepareStatement(sSql);
			stat.executeUpdate(sSql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.warn("��ʼ�����д���,������Ϣ "+e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try {
				stat.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		
		return true;
	}
	
}