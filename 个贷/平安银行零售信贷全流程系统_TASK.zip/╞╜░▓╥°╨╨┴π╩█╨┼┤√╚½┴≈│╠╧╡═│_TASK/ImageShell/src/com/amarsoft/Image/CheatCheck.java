package com.amarsoft.Image;


import java.sql.SQLException;

import com.amarsoft.AppTools;

import com.amarsoft.DBConnection.DBConnection;


import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.log.Log;

import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.are.sql.ConnectionManager;
import com.amarsoft.are.sql.Transaction;
import com.dc.eai.data.CompositeData;

public class CheatCheck extends com.amarsoft.Task.ExecProgram.ExecAbstract{

	private java.sql.Connection LoanConn = null;
	private java.sql.Connection LoanRptConn = null;
	private Log logger =null;
	private static Transaction Sqlca = null;
	private static Transaction SqlcaRpt =null;
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		this.logger = new Log("CheatCheck");
		System.out.println("��թ�����������ʼ..."+AppTools.getNowTime());
		this.logger.info("��թ�����������ʼ..."+AppTools.getNowTime());
		DBConnection dc = new DBConnection();
		try{
			//��ȡ����
			this.LoanConn = dc.getConn("Loan");
			this.LoanRptConn = dc.getConn("LoanRpt");
			Sqlca = new Transaction(this.LoanConn);
			SqlcaRpt = new Transaction(this.LoanRptConn);
			String sSql="";
			String sUpdateSql ="";
			java.sql.ResultSet mainRs = null;
			java.sql.PreparedStatement psSelectSql = null;
			java.sql.PreparedStatement psUpdateSql = null;
			java.sql.PreparedStatement psUpdateSql2 = null;
			try{
				//��һ���ǵ���ҵ��
				sSql = "SELECT FT.OBJECTNO FROM BUSINESS_APPLY BA, FLOW_TASK FT WHERE BA.SERIALNO=FT.OBJECTNO AND (BA.ISCHEATCHECK<>'0' OR BA.ISCHEATCHECK IS NULL) AND FT.OBJECTTYPE='CBCreditApply' AND FT.FLOWNO='CB0050' AND FT.PHASENO='0040'   AND FT.ENDTIME IS NULL ";
				psSelectSql = LoanConn.prepareStatement(sSql);
				//�������ͼ��־
				psUpdateSql = LoanConn.prepareStatement("UPDATE BUSINESS_APPLY SET ISCHEATCHECK='1' WHERE SERIALNO=? ");
				//���ϼ������־
				psUpdateSql2 = LoanConn.prepareStatement("UPDATE BUSINESS_APPLY SET ISCHEATCHECK='0' WHERE SERIALNO=? ");
				mainRs = psSelectSql.executeQuery();
				while(mainRs.next()){
					String sApplySerialNo = mainRs.getString("OBJECTNO");
					psUpdateSql.setString(1, sApplySerialNo);
					psUpdateSql.executeUpdate();
					com.amarsoft.app.logicCheck.AntiFraudCheckModel afc = new com.amarsoft.app.logicCheck.AntiFraudCheckModel(Sqlca,sApplySerialNo,"CBCreditApply","","0");
					Object iCount = (Object)afc.run(Sqlca,SqlcaRpt);
					System.out.println("�ǵ�����թ�����:"+sApplySerialNo+"--iCount:"+iCount.toString());
					this.logger.info("�ǵ�����թ�����:"+sApplySerialNo+"--iCount:"+iCount.toString());
					psUpdateSql2.setString(1, sApplySerialNo);
					psUpdateSql2.executeUpdate();
					LoanConn.commit();
				}
				mainRs.close();
				psSelectSql.close();
				psUpdateSql.close();
				psUpdateSql2.close();
				
				//��һ������ҵ��
				sSql = "SELECT FT.OBJECTNO FROM BUSINESS_APPLY BA, FLOW_TASK FT WHERE BA.SERIALNO=FT.OBJECTNO AND (BA.ISCHEATCHECK<>'0' OR BA.ISCHEATCHECK IS NULL) AND BA.BAR_CODE_NO LIKE 'KB0008%' AND FT.OBJECTTYPE='CBCreditApply' AND FT.FLOWNO='CB0055' AND FT.PHASENO='0044' AND FT.ENDTIME IS NULL ";
				psSelectSql = LoanConn.prepareStatement(sSql);
				//�������ͼ��־
				psUpdateSql = LoanConn.prepareStatement("UPDATE BUSINESS_APPLY SET ISCHEATCHECK='1' WHERE SERIALNO=? ");
				//���ϼ������־
				psUpdateSql2 = LoanConn.prepareStatement("UPDATE BUSINESS_APPLY SET ISCHEATCHECK='0' WHERE SERIALNO=? ");
				mainRs = psSelectSql.executeQuery();
				while(mainRs.next()){
					String sApplySerialNo = mainRs.getString("OBJECTNO");
					psUpdateSql.setString(1, sApplySerialNo);
					psUpdateSql.executeUpdate();
					com.amarsoft.app.logicCheck.AntiFraudCheckModel afc = new com.amarsoft.app.logicCheck.AntiFraudCheckModel(Sqlca,sApplySerialNo,"CBCreditApply","","0");
					Object iCount = (Object)afc.run(Sqlca,SqlcaRpt);
					System.out.println("������թ�����:"+sApplySerialNo+"--iCount:"+iCount.toString());
					this.logger.info("������թ�����:"+sApplySerialNo+"--iCount:"+iCount.toString());
					psUpdateSql2.setString(1, sApplySerialNo);
					psUpdateSql2.executeUpdate();
					LoanConn.commit();
				}
				mainRs.close();
				psSelectSql.close();
				psUpdateSql.close();
				psUpdateSql2.close();
				
			}catch(SQLException e){
				e.printStackTrace();
				this.logger.warn("��թ�����������������ݿ��쳣:"+e.toString());
			}finally{
				try{
					if(mainRs!=null){
						mainRs.close();
					}
					if(SqlcaRpt!=null){
						SqlcaRpt.disConnect();
						SqlcaRpt =null;
					}
					if(Sqlca!=null){
						Sqlca.disConnect();
						Sqlca=null;
					}
				}catch(Exception e){
					e.printStackTrace();
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
			this.logger.warn("��թ���������������쳣��"+e.toString());
		}
		System.out.println("��թ��������������..."+AppTools.getNowTime());
		this.logger.info("��թ��������������..."+AppTools.getNowTime());
	}
}
