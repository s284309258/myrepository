package com.amarsoft.Image.Driver;

import com.amarsoft.Image.Image;
import com.amarsoft.log.Log;

/**
 * 
 * @author yyduan
 *
 */
public abstract class RunDriver {
	Image img = null;
	public final Log logger = new Log("ImageDriver");
	boolean bReturnValue=true;
	java.sql.Connection Loan = null;
	java.sql.Connection IMS = null;
	public abstract boolean startDriver() throws Exception;
	public abstract boolean endDriver();
}