package com.amarsoft.Image.Driver;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.Image.Image;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.app.lending.bizlets.GuarantyPigenoholeNo;
import com.amarsoft.app.lending.bizlets.DecontrolCapital;
import java.sql.SQLException;

import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.sql.ASResultSet;
/**
 * 3��	��������ϵͳ�鵵��ŵĲ���ʱ�㣬�ɳ���������ΪѺƷɨ���ϴ�ʱ����������������
 * @author EX-CHENWEILIN001
 *
 */
public class GenSnoAddDriver extends RunDriver {

	public GenSnoAddDriver(Image image){
		try{
			this.Loan=image.getConnection();
			this.img=image;
			this.startDriver();
		}catch(Exception e){
			logger.error(""+e.getMessage());
		}
	}
	
	//@Override
	public boolean startDriver() {
		logger.info("������ʼ");
		logger.info("������������ˮ�ţ�"+this.img.getObjectNo());
		
		Transaction Sqlca = null;
		String sSql = "";
		try {
			String sTime = SystemConfig.getBusinessDate(this.Loan) + " " + StringFunction.getNow();
			OCIConfig.loadOCIConfig(true);
			OCIConfig.setEnvironment("Cycle");
			OCIConfig.setDataSourceName("Loan");
			OCIConfig.setImageDataSourceName("IMS");
			Sqlca = com.amarsoft.account.util.StringTools.getSqlca();
		  //sSql = "select 1 from FLOW_TASK where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType = '"+this.img.getObjectType()+"' and UserID = 'RCPM' and EndTime is null";
		    sSql = "select GuarantyID,GuarantyType,ManStatus,GuarantySubType,InputOrgID,PigeonholeNo from guaranty_info where GuarantyID in(select guarantyid from GUARANTY_RELATIVE where ObjectNo = '"+this.img.getObjectNo()+"' and ObjectType in('CBContractApply','SWContractApply')) and GuarantyType like '020%' ";	
		    ASResultSet rs = Sqlca.getASResultSet(sSql);  
			int icount = 0;
			
			while(rs.next()){
				//��Ѻ�������Ϣ����
				String sGuarantyID = DataConvert.toString(rs.getString("GuarantyID"));
				String sManStatus = DataConvert.toString(rs.getString("ManStatus"));
				String sGuarantyType = DataConvert.toString(rs.getString("GuarantyType"));
				String sGuarantySubType = DataConvert.toString(rs.getString("GuarantySubType"));
				String sInputOrgID = DataConvert.toString(rs.getString("InputOrgID"));
				String sPigeonholeNo = DataConvert.toString(rs.getString("PigeonholeNo"));
				
				//ѺƷ��������   	�����鵵���
				String sType = "";
				String sFix = "PAGY";//�������������Ź̶�ֵ
				if((img.getDocumentCode().equals("KB43") || img.getDocumentCode().equals("KB45")) && sManStatus.equals("03"))
				{
					//��ȡѺƷ����
					if(sGuarantyType.equals("020010")) //��Ѻ--����
					{
						if(sGuarantySubType.equals("10")) //�ַ�
						{
							sType = "02";
						}
						else if(sGuarantySubType.equals("20")) //�ڷ�
						{
							sType = "01";
						}
					}
					else if(sGuarantyType.equals("020030"))//��Ѻ--����
					{
						sType = "03";
					}
					else if(sGuarantyType.equals("030010")) //��Ѻ--�浥
					{
						sType = "04";
					}
					else
					{
						sType = "05";
					}
					
					//��ȡѺƷ�Ǽǻ������ڷ���
					sSql = " select OrgID from ORG_INFO where OrgID in(select OrgID from ORG_BELONG where BelongOrgID = '"+sInputOrgID+"') and OrgLevel = '3' ";
					String sOrgID = Sqlca.getString(sSql);
					if(sOrgID == null || sOrgID.equals("")) sOrgID = sInputOrgID;
					
					//��ѯ
					String sSerialNo = DBFunction.getSerialNo("GUARANTY_INFO","PigeonholeNo","yyyyMMdd","000000",new java.util.Date(),"",Sqlca.conn);
					//�鵵��� 
					/**
					 * BEGIN
					 * EX-HENRY001
					 * ��Ѻ�Ǽ���ҵʱ��㣺�������ʱ�䣨ɨ���Ѻ�������Ѻ��ִ��ʱ�䣬����ȡ�ĸ�ʱ������ݳ���������Ҫ��
					 */
					sPigeonholeNo = sFix+sOrgID+sType+sSerialNo;
					sSql = " Update GUARANTY_INFO set PigeonholeNo = '"+sPigeonholeNo+"',ManStatus = '04',taskendtime = '"+sTime+"' where GuarantyID = '"+sGuarantyID+"' ";
					Sqlca.executeSQL(sSql);
					icount++;
				}
				else if(img.getDocumentCode().equals("KB44") && sManStatus.equals("02"))
				{
					sSql = "update GUARANTY_INFO set ManStatus = '03',taskendtime = '"+sTime+"' where GuarantyID = '"+sGuarantyID+"'";
					Sqlca.executeSQL(sSql);
					icount++;
				}
				/**
				 * END
				 * EX-HENRY001
				 */
			} 
			rs.close();
			
			if(icount > 0) 
				endDriver();
			Sqlca.conn.commit();
			
		} catch (Exception e) {
			try
			{
				Sqlca.conn.rollback();
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
			e.printStackTrace();
			logger.info("����ʧ�ܡ�"+img.getObjectNo()+"��"+e.getMessage());
			 bReturnValue=false;
		}
		
		finally {
			try {
				if(Sqlca != null)  Sqlca.disConnect();
			} catch (Exception e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		
		return true;
	}

	//@Override
	public boolean endDriver() {
		java.sql.Statement stat = null;
		String sSql = "";
		try {
			sSql ="update barcode_relative set status='1' where barcode='"+img.getBarCodeNo()+"' and objectno = '"+img.getObjectNo()+"' and objecttype = '"+img.getObjectType()+"'";
			logger.info(sSql);
			stat=this.Loan.prepareStatement(sSql);
			stat.executeUpdate(sSql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.warn("��ʼ�����д���,������Ϣ "+e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try {
				stat.close();
			} catch (SQLException e) {
				logger.warn("������Ϣ "+e.getMessage());
				e.getMessage();
			}
		}
		
		return true;
	}


}
