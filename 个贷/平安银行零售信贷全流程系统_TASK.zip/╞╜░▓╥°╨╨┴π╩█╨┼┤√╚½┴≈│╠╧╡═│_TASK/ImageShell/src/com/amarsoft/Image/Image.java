package com.amarsoft.Image;

import java.sql.SQLException;
import com.amarsoft.log.Log;
/**
 * 
 * @author 
 *
 */
public class Image {
	private Log logger = null;
	public Image(String BarCodeNo,String sObjectNo,String sObjectType,java.sql.Connection Loan){
		java.sql.ResultSet rs = null;
		java.sql.Statement stat = null;
		this.logger = new Log("ImageDriver");
		try {
			stat  = Loan.createStatement();
			rs  = stat.executeQuery("select * from barcode_relative where BarCode = '"+BarCodeNo+"' and ObjectNo = '"+sObjectNo+"' and ObjectType = '"+sObjectType+"'");
			if(rs.next()){
				this.setBarCodeNo(BarCodeNo);
				this.setDocumentCode(rs.getString("DOCUMENTCODE"));
				this.setDocumentType(rs.getString("DOCUMENTTYPE"));
				this.setObjectNo(rs.getString("OBJECTNO"));
				this.setObjectType(rs.getString("OBJECTTYPE"));
				this.setRelativeBarCode(rs.getString("RELATIVEBARCODE"));
				this.setStatus(rs.getString("STATUS"));
				this.setConnection(Loan);
				this.setLog(logger);
			}
			rs.close();
			stat.close();
		} catch (SQLException e) {
			logger.warn("��ʼ��Image���ִ���"+e.getMessage());
		}  
	}
	public String getObjectNo() {
		return ObjectNo;
	}
	public Log getLog() {
		return this.logger;
	}
	public void setLog(Log log) {
		this.logger=log;
	}
	
	public void setObjectNo(String objectNo) {
		ObjectNo = objectNo;
	}

	public String getObjectType() {
		return ObjectType;
	}

	public void setObjectType(String objectType) {
		ObjectType = objectType;
	}

	public String getBarCodeNo() {
		return BarCodeNo;
	}

	public void setBarCodeNo(String barCodeNo) {
		BarCodeNo = barCodeNo;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getDocumentType() {
		return DocumentType;
	}
	public void setDocumentType(String documentType) {
		DocumentType = documentType;
	}

	public String getDocumentCode() {
		return DocumentCode;
	}

	public void setDocumentCode(String documentCode) {
		DocumentCode = documentCode;
	}
	public void setConnection(java.sql.Connection conn) {
		this.loan=conn;
	}
	public java.sql.Connection getConnection() {
		return this.loan;
	}
	public String getRelativeBarCode() {
		return RelativeBarCode;
	}

	public void setRelativeBarCode(String relativeBarCode) {
		RelativeBarCode = relativeBarCode;
	}
	public String getRemark() {
		return "ObjectNo="+ObjectNo+";ObjectType="+ObjectType+";DocumentType="+DocumentType+";DocumentCode="+DocumentCode+";RelativeBarCode="+RelativeBarCode+";Status="+Status;
	}
	protected java.sql.Connection loan = null; 
	
	private String ObjectNo = "";

	private String ObjectType = "";

	private String BarCodeNo = "";

	private String Status = "";
	
	private String DocumentType = "";
	
	private String DocumentCode = "";
	
	private String RelativeBarCode = "";
	
}
