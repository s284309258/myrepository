package com.amarsoft.XBLoan;

import java.sql.Statement;

import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.sql.Transaction;

public class XBCheck {
	private Transaction Sqlca = null;
	public XBCheck(Transaction sqlca){
		Sqlca = sqlca;
	}
//	����У��
	public void DoCheck() throws Exception {
		String sSql = "";	        
		String sNowTime = "";
		Sqlca.conn.setAutoCommit(false);
		// ��������ԱҪ�Ϸ�
		sSql = "update  xb_customer set flag='12',updatetime='"+ sNowTime+ 
			"' where flag='00' and (orgid not in "+ 
			" (select channelcode from sale_channel where INUSED='1' ) or userid not in "+ 
			" (select serialno from sale_manager ))";
		Sqlca.executeSQL(sSql);
		
		//����֤���ȼ��
		sSql = "update  xb_business set flag='12',updatetime='"+ sNowTime +
			"' where guarantyid in ("+
			"  select guarantyid from xb_customer " +
			"  where certtype = 'Ind01'  and length(customerid) <> 18   and length(customerid) <> 15   and flag = '00' )";
		Sqlca.executeSQL(sSql);
		
		sSql = "update  xb_insurance set flag='12',updatetime='"
			+ sNowTime +"' where guarantyid in ("
			+"  select guarantyid from xb_customer where certtype = 'Ind01'  and length(customerid) <> 18   and length(customerid) <> 15   and flag = '00' )";
		Sqlca.executeSQL(sSql);
		
		sSql = "update  xb_customer set flag='12',updatetime='"+ sNowTime+ 
			"' where certtype = 'Ind01'  and length(customerid) <> 18   and length(customerid) <> 15   and flag = '00' ";
		Sqlca.executeSQL(sSql);
		
		// ��������ԱҪ�Ϸ�
		sSql = "update  xb_business set flag='12' ,updatetime='"+ sNowTime+ 
			"' where flag='00' and ( orgid not in "+ 
			" (select channelcode from sale_channel where INUSED='1' ) or userid not in "+ 
			" (select serialno from sale_manager ))";
		Sqlca.executeSQL(sSql);
		
		// ��������ԱҪ�Ϸ�
		sSql = "update  xb_insurance set flag='12' ,updatetime='"+ sNowTime+ "' where flag='00' and ( orgid not in "+ 
			" (select channelcode from sale_channel where INUSED='1' ) or userid not in "+ " (select serialno from sale_manager ))";
		Sqlca.executeSQL(sSql);
		Sqlca.conn.commit();
		
	}
	/**
	 * ����У�� ��¼���
	 * @param sGuarantyID
	 * @return
	 * @throws Exception 
	 */
	public boolean DoCheckLone(String sGuarantyID,String sSerialNoFT,String sSerialNoBA) throws Exception{
		String sSql = "",sCHECKNO = "",sTime = "";	 
		//���ɶ�Ӧ��CHECKLIST
		sCHECKNO =  DBFunction.getSerialNo("Check_DATA","CHECKNO",Sqlca);
		sSql = "insert into Check_DATA(CHECKNO,OBJECTTYPE,OBJECTNO,taskno,INPUTUSER,CHECKCONTENT,INPUTTIME,FROMTYPE) " +
				" values('"+sCHECKNO+"','CBCreditApply','"+sSerialNoBA+"','"+sSerialNoFT+"','admin','���ڴ�����Ϣ','"+sTime+"','0')";
		Sqlca.executeSQL(sSql);
		
		return true;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
