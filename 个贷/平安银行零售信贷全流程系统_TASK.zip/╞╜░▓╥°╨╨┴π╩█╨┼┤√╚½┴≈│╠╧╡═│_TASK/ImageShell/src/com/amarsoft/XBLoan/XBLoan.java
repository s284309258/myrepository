package com.amarsoft.XBLoan;

import com.amarsoft.DBConnection.DBConnection;

import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.log.Log;
import com.amarsoft.rcpm.InitPara;
public class XBLoan extends ExecAbstract{
	private Log logger = null;
	public  synchronized void run() {
		Transaction Sqlca = null;
		this.logger = new Log("XBLoan");
		try {
			DBConnection dc = new DBConnection();
			Sqlca= new Transaction(dc.getConn("Loan"));
			InitPara.loadConfig(Sqlca);
			Sqlca.disConnect();
			//����С��ҵ����
			DealXBLoan dealXBLoan = new DealXBLoan(logger);
			dealXBLoan.doDealXBLoan();
			
		} 
		catch (Exception e) {
			logger.error("������" + e);
			e.printStackTrace();
		}
	}
	
}
