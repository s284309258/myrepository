package com.amarsoft.log;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

public class Log
{
	private Logger logger = null;
	private static Log log = null;

	/**
	 * @return ����ʵ��
	 */
	static public Log getInstance()
	{
		if(log == null)
			log = new Log();
		return log;
	}

	/**
	 * ����log4j�����ļ�
	 * @param conFileName log4j.properties�ļ���(ȫ·��)
	 */
	public void setCfgFile(String conFileName)
	{
		if(conFileName != null)
		{
			if(conFileName.indexOf(".xml") > 0)
				DOMConfigurator.configure(conFileName);
			else
				PropertyConfigurator.configure(conFileName);
		}
	}

	/**
	 * ����logʵ��������
	 * @param className logʵ��������
	 */
	public void setClassName(String className)
	{
		if(className != null)
			logger = Logger.getLogger(className);
		else
			logger = Logger.getLogger(getClass().getName());
	}

	/**
	 * ���캯��
	 * @param className logʵ��������
	 * @param conFileName log4j.properties�ļ���(ȫ·��)
	 */
	public Log(String className, String conFileName)
	{
		if(conFileName != null)
		{
			if(conFileName.indexOf(".xml") > 0)
				DOMConfigurator.configure(conFileName);
			else
				PropertyConfigurator.configure(conFileName);
		}
		if(className != null)
			logger = Logger.getLogger(className);
		else
			logger = Logger.getLogger(getClass().getName());
	}

	/**
	 * ���캯��
	 * @param className logʵ��������
	 */
	public Log(String className)
	{
		this(className, null);
	}

	/**
	 * ���캯��
	 */
	public Log()
	{
		this(null, null);
	}

	/**
	 * @param msg ��־��Ϣ
	 */
	public void debug(String msg)
	{
		if(logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(msg);
		}
	}

	/**
	 * @param msg ��־��Ϣ
	 */
	public void info(String msg)
	{
		if(logger.isEnabledFor(Level.INFO))
		{
			logger.info(msg);
		}
	}

	/**
	 * @param msg ��־��Ϣ
	 */
	public void warn(String msg)
	{
		if(logger.isEnabledFor(Level.WARN))
		{
			logger.warn(msg);
		}
	}

	/**
	 * @param msg ��־��Ϣ
	 */
	public void error(String msg)
	{
		if(logger.isEnabledFor(Level.ERROR))
		{
			logger.error(msg);
		}
	}

	/**
	 * @param msg ��־��Ϣ
	 * @param e ������Ϣ
	 */
	public void error(String msg, Exception e)
	{
		if(logger.isEnabledFor(Level.ERROR))
		{
			logger.error(msg, e);
		}
	}
	public static void main(String[] args) {
		
	
	}
}