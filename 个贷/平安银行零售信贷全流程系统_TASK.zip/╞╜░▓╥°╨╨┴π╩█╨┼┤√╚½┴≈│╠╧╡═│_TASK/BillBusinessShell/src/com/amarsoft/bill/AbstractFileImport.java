package com.amarsoft.bill;


import com.amarsoft.app.datax.gci.GCIException;
import com.amarsoft.app.datax.gci.units.ColumnMap;
import com.amarsoft.app.datax.gci.units.ValueGetter;
import com.amarsoft.are.ARE;
import com.amarsoft.are.log.Log;
import com.amarsoft.are.sql.DataSourceURI;
import com.amarsoft.are.sql.TabularReader;
import com.amarsoft.are.task.ExecuteUnit;
import com.amarsoft.are.task.Target;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

public abstract class AbstractFileImport extends ExecuteUnit
{
  protected String database;
  protected DataSourceURI dataSource;
  protected ResultSet fileResultSet;
  protected int bufferSize;
  protected Connection connection;
  protected HashMap codeTable;
  protected int commitRecord;
  protected Log logger;
  protected HashMap valueGetters = new HashMap();
  public static final String PROPERTY_DATABASE = "database";
  public static final String PROPERTY_DATASOURCE = "dataSource";
  public static final String PROPERTY_BUFFER_SIZE = "bufferSize";
  public static final String PROPERTY_TARGET_TABLE_DEFINE = "targetTableDefine";
  public static final String PROPERTY_CODE_TABLE_PREFIX = "CODE_TABLE_";
  public static final String PROPERTY_COMMIT_RECORD = "commitRecord";

  protected void init()
    throws GCIException
  {
    this.logger = ARE.getLog();

    this.database = getProperty("database");
    if ((this.database == null) || (this.database.equals("")))
      this.database = getTarget().getProperty("database");
    try
    {
      this.connection = ARE.getDBConnection(this.database);
    } catch (SQLException e) {
      this.logger.debug("���ݿ����ӳ�ʼ��ʧ�ܣ�", e);
      throw new GCIException("���ݿ����ӳ�ʼ��ʧ�ܣ�", e);
    }

    String buff = getProperty("bufferSize");
    if ((buff == null) || (buff.equals(""))) {
      buff = getTarget().getProperty("bufferSize");
      try {
        this.bufferSize = Integer.parseInt(buff);
      } catch (Exception ex) {
        this.bufferSize = 0;
        this.logger.warn("��ȡbufferSizeʧ�ܣ�", ex);
      }
    }

    String s = getProperty("dataSource");
    try {
      this.dataSource = new DataSourceURI(s);
    } catch (URISyntaxException e) {
      this.logger.debug("����DataSourceURIʧ�ܣ�", e);
      throw new GCIException("����DataSourceURIʧ�ܣ�", e);
    }
    try {
      TabularReader reader = new TabularReader(this.dataSource);
      if (this.bufferSize > 0)
        reader.setBufferSize(this.bufferSize);
      this.fileResultSet = reader.getResultSet();
    } catch (SQLException e1) {
      this.logger.debug("ͨ�ý��������ʧ�ܣ��޷��������ļ�������Դ���ӣ�", e1);
      throw new GCIException("ͨ�ý��������ʧ�ܣ��޷��������ļ�������Դ���ӣ�", e1);
    }

    String record = getProperty("commitRecord");
    if ((record == null) || (record.equals(""))) {
      record = getTarget().getProperty("commitRecord");
      try {
        this.commitRecord = Integer.parseInt(record);
      } catch (Exception ex) {
        this.commitRecord = 1;
        this.logger.warn("��ȡcommitRecordʧ�ܣ�", ex);
      }

    }

    initCodeTable();
  }

  protected abstract void prepare()
    throws GCIException;

  protected abstract void postProcess()
    throws GCIException;

  protected abstract void processRow()
    throws GCIException;

  public int execute()
  {
    try
    {
      init();
    } catch (GCIException e) {
      this.logger.fatal("��ʼ��ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    try
    {
      prepare();
    } catch (GCIException e) {
      this.logger.fatal("׼������ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    int currentRow = 0;
    try {
      while (this.fileResultSet.next())
      {
        currentRow = this.fileResultSet.getRow();
        processRow();
      }
    } catch (SQLException e) {
      this.logger.fatal("��������ʧ�ܣ���ǰ�� = [" + currentRow + "] (Caused by: " + e.getMessage() + ")");
      clearResource();
      return 2;
    } catch (GCIException e) {
      this.logger.fatal("��������ʧ�ܣ���ǰ�� = [" + currentRow + "] (Caused by: " + e.getMessage() + ")");
      clearResource();
      return 2;
    }

    try
    {
      postProcess();
    } catch (GCIException e) {
      this.logger.fatal("��������ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    clearResource();
    return 1;
  }

  private void clearResource()
  {
    if (this.connection != null) {
      try {
        this.connection.close();
      } catch (SQLException e) {
        this.logger.warn("�ر����ݿ�ʧ�ܣ�" + e);
      }
      this.connection = null;
    }

    if (this.fileResultSet != null) {
      try {
        this.fileResultSet.close();
      } catch (SQLException e) {
        this.logger.warn("�ر�ͳһ���ݽ����ʧ�ܣ�" + e);
      }
      this.fileResultSet = null;
    }

    this.codeTable = null;
  }

  protected void initValueGetter(String initFile)
    throws SQLException
  {
    String colName = null;
    String getterClass = null;
    String referenceColumn = null;
    String initParameter = null;

    ValueGetter g = null;
    try
    {
      Class c = Class.forName(getterClass);
      g = (ValueGetter)c.newInstance();
    } catch (Exception e) {
      g = null;
    }
    if (g == null)
      g = new ColumnMap();
    g.init(this, referenceColumn, initParameter);
    this.valueGetters.put(colName, g);
  }

  public ValueGetter getValueGetter(String colName) {
    return (ValueGetter)this.valueGetters.get(colName);
  }

  private void initCodeTable()
  {
    this.codeTable = new HashMap();
    Enumeration e = this.extendProperties.keys();
    while (e.hasMoreElements()) {
      String prop = (String)e.nextElement();
      if (prop.startsWith("CODE_TABLE_")) {
        TabularReader t = null;
        try {
          t = new TabularReader(new DataSourceURI(this.extendProperties.getProperty(prop)));

          Properties p = t.getProperties(1, 2);
          String col = prop.substring("CODE_TABLE_".length());

          this.codeTable.put(col.toUpperCase(), p);
        } catch (URISyntaxException e1) {
          this.logger.warn("��ʼ��������ձ�[" + prop + "],URI����", e1);
        } catch (SQLException e1) {
          this.logger.warn("��ʼ��������ձ�[" + prop + "],���ݿ����", e1);
        } finally {
          if (t != null) t.close();
        }
      }
    }
  }

  public Properties getCodeMap(String colName)
  {
    return (Properties)this.codeTable.get(colName);
  }

  public String getMappedValue(String colName, String originalValue)
  {
    return getMappedValue(colName, originalValue, originalValue);
  }

  public String getMappedValue(String colName, String originalValue, String otherValue)
  {
    if ((colName == null) || (originalValue == null))
      return null;
    Properties p = (Properties)this.codeTable.get(colName.toUpperCase());
    if (p == null) {
      this.logger.debug("δ�ҵ�[" + colName + "]���ձ���");
      return otherValue;
    }
    return p.getProperty(originalValue, otherValue);
  }
}
