/***********************************************************************
 * Module:  BizInfo.java
 * Author:  tzhai
 * Modified by xxiao 2005/05/26
 * Purpose: Defines the Class BizInfo
 ***********************************************************************/

package com.amarsoft.bill;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.app.datax.gci.GCIException;
import com.amarsoft.app.datax.gci.common.Tools;
import com.amarsoft.app.datax.gci.units.*;
//import com.amarsoft.are.sql.DBFunction;

/**
 * BizInfo��ʵ����unit�ӿڣ�Ŀ���ǵ������ݵ���ݱ��С����ӿ�������ݵ����һ���Թ�����
 * ���ڲ����ڵĽ�ݣ�����һ���½�ݣ��Դ��ڵĸ������ڲ����½�ݵ�ʱ�򣬴ӳ��ʱ���ȡ
 * ��ͬ�š��ͻ��ź�ҵ�����͸��½�ݱ���Ӧ���ֶΡ����ں�ͬ�ţ�������һ�ַ�����ȡ����֤
 * ����Ľ�ݱ����ݣ���ݺźͺ�ͬ�����Ǵ��ڵġ�
 * ���ڸ��½�ݣ�Ҳͬ����ÿ���ó��ʱ�����Ϣ���½�ݱ���ҵ�����͡��ͻ�ID�ͺ�ͬID,
 * �Բ����ڳ��ʱ��е���Ϣ���ٴθ��»ص���ݱ���
 * @author TZhai
 *
 */

public class BizInfoCSPSEx extends AbstractFileImport {
	//�ⲿ���Զ���
	public static final String PROPERTY_INIT_CUSTOMERID_WITH_MFCUSTOMERID = "initCustomerIdWithMFCustomerId";
	public static final String PROPERTY_SET_FINISHDATE_ON_ZERO_BALANCE = "setFinishDateOnZeroBalance";
	private boolean initCustomerIdWithMFCustomerId = false;
	private boolean setFinishDateOnZeroBalance = false;

	//================================================================================
	//�����ļ���������
	//����ҵ��ϵͳҵ���ʶ��
	private String serialNo = "";
	//���ʺ� 
	private String relativeSerialNo1 = "";
	//��ͬ��ˮ�ţ��Ŵ�ϵͳ��ʶ�ţ�
	private String relativeSerialNo2 = "";
	//��������
	private String inputDate = "";
	//�����ͻ���
	private String mainCustomerID = "";
	//�ͻ�����
	private String customerName = "";
	//��ƿ�Ŀ
	private String subjectNo = "";
	//���Ž��
	private double businessSum = 0.00;
	//����
	private String businessCurrency = "";
	//��������
	private double businessRate = 0.00;
	//���������
	private double balance = 0.00;
	//�������
	private double normalBalance = 0.00;
	//�������
	private double overdueBalance = 0.00;
	//�������
	private double dullBalance = 0.00;
	//�������
	private double badBalance = 0.00;
	//����ǷϢ���
	private double interestBalance1 = 0.00;
	//����ǷϢ���
	private double interestBalance2 = 0.00;
	//���ڷ�Ϣ���
	private double fineBalance1 = 0.00;
	//��Ϣ���
	private double fineBalance2 = 0.00;
	//��������
	private String actualPutoutDate = "";
	//��������
	private String actualMaturity = "";
	//�ս�����
	private String finishDate = "";
	//�ս�����
	private String finishType = "";
	//չ�ڴ���
	private int extendTimes = 0;
	//����־
	private String advanceFlag = "";
	//��������
	private int overDueDays = 0;
	//�����˺�
	private String payBackAccount = "";
	//�����˺�
	private String payInterestAccount = "";
	//��֤���ʺ�
	private String bailAccount = "";
	//�ſ��ʺ�
	private String putOutAccount = "";
	//������
	private String mfOrgID = "";
	//4������
	private String classify4 = "";
	//����Ƶ��
	private String termsFreq = "";
	//ҵ��״̬
	private String businessStatus = "";
	//����ҵ���־
	private String timsFlag = "";
	//������ȱ��
	private String creditAggreement = "";
	//�򷽿ͻ���
	private String vendeeCustomerID = "";
	//�򷽿ͻ�����
	private String vendeeCustomerName = "";
	//����ҵ�����
	private String cspsBusinessType = "";

	private String accountOrgID = "";	//����������ת�Ŵ�ϵͳ��
	private String businessType = "";	//ҵ������

	//��ͬ��Ϣ
	private int termMonth = 0;				//��������(��)
	private String direction = "";			//�������Ͷ��
	private String interestPayMethod = "";	//���������Ϣ֧����ʽ
	private String adjustRateType = "";		//����������ʵ�����ʽ
	private String customerLevel = "";		//������ȿͻ�����
	private String businessLevel = "";		//�������ծ������
	private String classLevel = "";			//������ȵ�������
	private String manageOrgID = "";		//������ȹܻ�����
	private String manageUserID = "";		//������ȹܻ���
	private String businessForm = "";		//ҵ����̬

	private int recordCount = 0;
	private boolean duebillExists = false;

	//��ݱ�����SQL���
	private String sqlInsertBusiness_Duebill = null;	//�������
	private String sqlInsertBusiness_Contract = null;	//������ͬ
	private String sqlUpdateBusiness_Duebill = null;	//���½��
	private String sqlSelectBusiness_Duebill = null;	//������Ƿ����
	private String sqlSelectBusiness_Contract = null;	//��ȡ���������Ϣ

	//��ݱ����ݿ������Ա
	private PreparedStatement psInsertBusiness_Duebill = null;
	private PreparedStatement psInsertBusiness_Contract = null;
	private PreparedStatement psUpdateBusiness_Duebill = null;
	private PreparedStatement psSelectBusiness_Duebill = null;
	private PreparedStatement psSelectBusiness_Contract = null;

	//�������¼�����
	private int insertBusiness_Duebill = 0;
	private int updateBusiness_Duebill = 0;
	
	/**
	 * ������AbstractFileImport������
	 * 
 	
 	init();
 	prepare();
 	processRow();
 	postProcess();
 	
 	
	public int execute()
  {
    try
    {
      init();
    } catch (GCIException e) {
      this.logger.fatal("��ʼ��ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    try
    {
      prepare();
    } catch (GCIException e) {
      this.logger.fatal("׼������ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    int currentRow = 0;
    try {
      while (this.fileResultSet.next())
      {
        currentRow = this.fileResultSet.getRow();
        processRow();
      }
    } catch (SQLException e) {
      this.logger.fatal("��������ʧ�ܣ���ǰ�� = [" + currentRow + "] (Caused by: " + e.getMessage() + ")");
      clearResource();
      return 2;
    } catch (GCIException e) {
      this.logger.fatal("��������ʧ�ܣ���ǰ�� = [" + currentRow + "] (Caused by: " + e.getMessage() + ")");
      clearResource();
      return 2;
    }

    try
    {
      postProcess();
    } catch (GCIException e) {
      this.logger.fatal("��������ʧ��:" + e.getMessage());
      clearResource();
      return 2;
    }

    clearResource();
    return 1;
  }	
	 */
	

	//�����Ŵ������ˮ��
	protected String getSerialNo(String sTableName, String sColumnName,String sPrefix) throws SQLException
	{
		if(sPrefix==null || sPrefix.equals(""))
			sPrefix = "";
		else
			sPrefix = "'"+sPrefix+"'";

		return getSerialNo(sTableName, sColumnName,sPrefix + "yyyyMMdd", "000000", new java.util.Date());
	}
	protected String getSerialNo(String sTableName, String sColumnName,String sDateFormat, String sNoFormat, Date dateToday) throws SQLException
	{
		int iMaxNo = 0;
		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
		String sDate = simpledateformat.format(dateToday);
		int iDateLen = sDate.length();
		String sNewSerialNo = "";

		sTableName = sTableName.toUpperCase();
		sColumnName = sColumnName.toUpperCase();

		PreparedStatement psTemp = null;
		ResultSet rsTemp = null;

		String sSql = "select MaxSerialNo from OBJECT_MAXSN "
				+ " where TableName='" + sTableName + "' and ColumnName='"+ sColumnName + "' ";
		String sTemp = "";

		psTemp = connection.prepareStatement(sSql);
		rsTemp = psTemp.executeQuery();
		if (rsTemp.next())
		{
			// �����ˮ�Ŵ��ڣ���������ˮ�š�
			String sMaxSerialNo = rsTemp.getString(1);

			// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
			iMaxNo = 0;
			if (sMaxSerialNo != null && sMaxSerialNo.indexOf(sDate, 0) != -1)
			{
				iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen)).intValue();
				sNewSerialNo = sDate + decimalformat.format(iMaxNo + 1);
			}
			else
				sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName,"", sDateFormat, sNoFormat, dateToday);

			// ��������ˮ��
			sTemp = "update OBJECT_MAXSN set MaxSerialNo ='"+ sNewSerialNo + "' " +
					" where TableName='"+ sTableName + "' and ColumnName='" + sColumnName+ "' ";
		}
		else
		{
			// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
			sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName, "",sDateFormat, sNoFormat, dateToday);
			sTemp = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
					+ " values( '"+ sTableName+ "','"+ sColumnName+ "','" + sNewSerialNo + "')";
		}

		if(rsTemp!=null) rsTemp.close();
		rsTemp = null;
		if(psTemp!=null) psTemp.close();
		psTemp = null;

		psTemp = connection.prepareStatement(sTemp);
		psTemp.executeUpdate();

		if(psTemp!=null) psTemp.close();
		psTemp = null;

		return sNewSerialNo;
	}
	// ��ͳ��ȡ���������ˮ��
	// �÷���ֱ�Ӵ����ݱ���ȡ�������ˮ�ţ�Ч�ʽϵͣ��ڲ�����������¿��ܻᷢ���غţ������Ƽ�ʹ��
	protected String getSerialNoFromDB(String sTableName,String sColumnName, String sWhereClause,
			String sDateFormat,String sNoFormat, java.util.Date dateToday) throws SQLException
	{
		System.out.println("**********�������ȡ��ˮ�ŵķ�ʽ(getSerialNoFromDB)**********");

		int iDateLen, iMaxNo = 0;
		String sSql, sMaxSerialNo, sDate, sNewSerialNo;
		SimpleDateFormat sdfTemp = new SimpleDateFormat(sDateFormat);
		DecimalFormat dfTemp = new DecimalFormat(sNoFormat);

		sDate = sdfTemp.format(dateToday);
		iDateLen = sDate.length();

		sSql = "select max(" + sColumnName + ") from " + sTableName + " where "
				+ sColumnName + " like '" + sDate + "%' ";
		if (sWhereClause.length() > 0)
			sSql += " and " + sWhereClause;

		PreparedStatement psTemp = null;
		ResultSet rsTemp = null;

		psTemp = connection.prepareStatement(sSql);
		rsTemp = psTemp.executeQuery();
		if (rsTemp.next())
		{
			sMaxSerialNo = rsTemp.getString(1);
			if (sMaxSerialNo != null)
				iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen)).intValue();
		}
		if(rsTemp!=null) rsTemp.close();
		rsTemp = null;
		if(psTemp!=null) psTemp.close();
		psTemp = null;

		sNewSerialNo = sDate + dfTemp.format(iMaxNo + 1);
		System.out.println("..." + sNewSerialNo + "...");
		return sNewSerialNo;
	}

	
	/**
	 * ��һ��
	 */
	protected void prepare() throws GCIException {
		//��ȡ�ⲿ����
		initCustomerIdWithMFCustomerId = getProperty(PROPERTY_INIT_CUSTOMERID_WITH_MFCUSTOMERID,false);
		setFinishDateOnZeroBalance = getProperty(PROPERTY_SET_FINISHDATE_ON_ZERO_BALANCE,false);
		recordCount = 0;

		//�����ݱ�
		sqlInsertBusiness_Duebill = "INSERT INTO BUSINESS_DUEBILL ( "
									+ "SerialNo, "
									+ "RelativeSerialNo1, "
									+ "RelativeSerialNo2, "
									+ "CustomerID, "
									+ "BusinessType, "
									+ "MFCustomerID, "
									+ "CustomerName, "
									+ "SubjectNo, "
									+ "BusinessSum, "
									+ "BusinessCurrency, "
									+ "ActualBusinessRate, "
									+ "Balance, "
									+ "NormalBalance, "
									+ "OverdueBalance, "
									+ "DullBalance, "
									+ "BadBalance, "
									+ "InterestBalance1, "
									+ "InterestBalance2, "
									+ "FineBalance1, "
									+ "FineBalance2, "
									+ "PutOutDate, "
									+ "Maturity, "
									+ "ActualMaturity, "
									+ "FinishDate, "
									+ "FinishType, "
									+ "ExtendTimes, "
									+ "AdvanceFlag, "
									+ "OverDueDays, "
									+ "PayBackAccount, "
									+ "PayInterestAccount, "
									+ "BailAccount, "
									+ "PutOutAccount, "
									+ "MFOrgID, "
									+ "Classify4, "
									+ "TermsFreq, "
									+ "BusinessStatus, "
									+ "TimsFlag, "
									+ "OperateOrgID, "
									+ "OperateUserID, "
									+ "InputOrgID, "
									+ "InputUserID, "
									+ "AccountOrgID, "
									+ "InputDate, "
									+ "UpdateDate "
									+ ") VALUES( "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ? "
									+ ") ";

		//�����ͬ��
		sqlInsertBusiness_Contract = "INSERT INTO BUSINESS_CONTRACT ( "
									+ "SerialNo, "
									+ "OccurDate, "
									+ "CustomerID, "
									+ "CustomerName, "
									+ "OccurType, "
									+ "BusinessType, "
									+ "PutOutOrgID, "
									+ "CycleFlag, "
									+ "ContractFlag, "
									+ "CreditAggreement, "
									+ "ThirdPartyID1, "
									+ "ThirdParty1, "
									+ "BusinessSubType, "
									+ "BusinessCurrency, "
									+ "BusinessSum, "
									+ "Direction, "
									+ "TermMonth, "
									+ "BusinessRate, "
									+ "InterestPayMethod, "
									+ "AdjustRateType, "
									+ "VouchType, "
									+ "VouchType1, "
									+ "VouchFlag, "
									+ "PutOutDate, "
									+ "Maturity, "
									+ "LowRisk, "
									+ "Balance, "
									+ "NormalBalance, "
									+ "OverdueBalance, "
									+ "DullBalance, "
									+ "BadBalance, "
									+ "InterestBalance1, "
									+ "InterestBalance2, "
									+ "FineBalance1, "
									+ "FineBalance2, "
									+ "FinishType, "
									+ "FinishDate, "
									+ "ActualPutoutSum, "
									+ "ApplyType, "
									+ "BusinessForm, "
									+ "CustomerLevel, "
									+ "BusinessLevel, "
									+ "ClassLevel, "
									+ "ManageOrgID, "
									+ "ManageUserID, "
									+ "OperateOrgID, "
									+ "OperateUserID, "
									+ "InputOrgID, "
									+ "InputUserID, "
									+ "OperateDate, "
									+ "InputDate, "
									+ "UpdateDate, "
									+ "PigeonholeDate, "
									+ "TempSaveFlag "
									+ ") VALUES( "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
									+ "?, ?, ?, ? "
									+ ") ";

		// ���½�ݱ�
		sqlUpdateBusiness_Duebill = "UPDATE BUSINESS_DUEBILL SET "
									+ "CustomerID = ? , "
									+ "BusinessType = ? , "
									+ "MFCustomerID = ? , "
									+ "CustomerName = ? , "
									+ "SubjectNo = ? , "
									+ "BusinessSum = ? , "
									+ "BusinessCurrency = ? , "
									+ "ActualBusinessRate = ? , "
									+ "Balance = ? , "
									+ "NormalBalance = ? , "
									+ "OverdueBalance = ? , "
									+ "DullBalance = ? , "
									+ "BadBalance = ? , "
									+ "InterestBalance1 = ? , "
									+ "InterestBalance2 = ? , "
									+ "FineBalance1 = ? , "
									+ "FineBalance2 = ? , "
									+ "PutOutDate = ? , "
									+ "ActualMaturity = ? , "
									+ "FinishDate = ? , "
									+ "FinishType = ? , "
									+ "ExtendTimes = ? , "
									+ "AdvanceFlag = ? , "
									+ "OverDueDays = ? , "
									+ "PayBackAccount = ? , "
									+ "PayInterestAccount = ? , "
									+ "BailAccount = ? , "
									+ "PutOutAccount = ? , "
									+ "MFOrgID = ? , "
									+ "Classify4 = ? , "
									+ "TermsFreq = ? , "
									+ "BusinessStatus = ? , "
									+ "TimsFlag = ? , "
									+ "AccountOrgID = ? , "
									+ "UpdateDate = ? "
									+ "WHERE SerialNo = ? ";
		//��ȡ�����Ϣ
		sqlSelectBusiness_Duebill = "SELECT SerialNo FROM BUSINESS_DUEBILL WHERE SerialNo = ?";

		//��ȡ���������Ϣ
		sqlSelectBusiness_Contract = "SELECT SerialNo,Direction,InterestPayMethod,AdjustRateType,CustomerLevel,BusinessLevel,ClassLevel,ManageOrgID,ManageUserID,BusinessForm FROM BUSINESS_CONTRACT WHERE ArtificialNo = ?";

		try {
			// ��ݱ�PreparedStatement��ֵ
			psInsertBusiness_Duebill = connection.prepareStatement(sqlInsertBusiness_Duebill);
			psInsertBusiness_Contract = connection.prepareStatement(sqlInsertBusiness_Contract);
			psUpdateBusiness_Duebill = connection.prepareStatement(sqlUpdateBusiness_Duebill);
			psSelectBusiness_Duebill = connection.prepareStatement(sqlSelectBusiness_Duebill);
			psSelectBusiness_Contract = connection.prepareStatement(sqlSelectBusiness_Contract);
		} catch (SQLException e) {
			releaseResource();
			throw new GCIException("��statement����",e);
		}
	}
	
	/**
	 * �ڶ���
	 */
	protected void processRow() throws GCIException {
		recordCount++;

		try{
		    //�����д�����������ÿһ������
			//��ȡ������
			serialNo			=	fileResultSet.getString("SerialNo");
			relativeSerialNo1		=	fileResultSet.getString("SerialNo");
			inputDate			=	Tools.formatDate(fileResultSet.getDate("InputDate"));
			mainCustomerID		=	fileResultSet.getString("MainCustomerID");
			customerName		=	fileResultSet.getString("CustomerName");
			subjectNo			=	fileResultSet.getString("SubjectNo");
			businessSum			=	fileResultSet.getDouble("BusinessSum");
			businessCurrency	=	fileResultSet.getString("BusinessCurrency");
			if(businessCurrency!=null && businessCurrency.equals("RMB")) businessCurrency="CNY";
			businessRate		=	fileResultSet.getDouble("BusinessRate")*100;
			balance				=	fileResultSet.getDouble("Balance");
			normalBalance		=	fileResultSet.getDouble("NormalBalance");
			overdueBalance		=	fileResultSet.getDouble("OverdueBalance");
			dullBalance			=	fileResultSet.getDouble("DullBalance");
			badBalance			=	fileResultSet.getDouble("BadBalance");
			interestBalance1	=	fileResultSet.getDouble("InterestBalance1");
			interestBalance2	=	fileResultSet.getDouble("InterestBalance2");
			fineBalance1		=	fileResultSet.getDouble("FineBalance1");
			fineBalance2		=	fileResultSet.getDouble("FineBalance2");
			actualPutoutDate	=	Tools.formatDate(fileResultSet.getDate("ActualPutoutDate"));
			actualMaturity		=	Tools.formatDate(fileResultSet.getDate("ActualMaturity"));
			finishDate			=	Tools.formatDate(fileResultSet.getDate("FinishDate"));
			finishType			=	fileResultSet.getString("FinishType");
			extendTimes			=	fileResultSet.getInt("ExtendTimes");
			advanceFlag			=	fileResultSet.getString("AdvanceFlag");
			overDueDays			=	fileResultSet.getInt("OverDueDays");
			payBackAccount		=	fileResultSet.getString("PaybackAccount");
			payInterestAccount	=	fileResultSet.getString("PayInterestAccount");
			bailAccount			=	fileResultSet.getString("BailAccount");
			putOutAccount		=	fileResultSet.getString("PutOutAccount");
			mfOrgID				=	fileResultSet.getString("MFOrgID");
			classify4			=	fileResultSet.getString("Classify4");
			termsFreq			=	"99";
			businessStatus		=	fileResultSet.getString("BusinessStatus");
			timsFlag			=	"1";
			creditAggreement	=	fileResultSet.getString("CreditAggreement");
			vendeeCustomerID	=	fileResultSet.getString("VendeeCustomerID");
			vendeeCustomerName	=	fileResultSet.getString("VendeeCustomerName");
			cspsBusinessType	=	fileResultSet.getString("CSPSBusinessType");

			accountOrgID		=	getMappedValue("OrgMap",mfOrgID);
			businessType		=	"1090010";
			termMonth			=	Tools.betweenMonths(actualPutoutDate,actualMaturity);

			//�ж��Ƿ���ڽ�ݣ���ȡ�������������Ͷ�����Ϣ��
			preprocess(serialNo, creditAggreement);

			//��ݴ��ڶԽ�ݱ�����update����
			if (duebillExists) {
	 			updateDuebill(serialNo);
			}else { //��ݲ����ڶԽ�ݡ���ͬ����insert����
	 			insertDuebill();
			}

		} catch (SQLException e) {
			releaseResource();
			throw new GCIException("����ҵ������"+recordCount+"�����ݳ���",e);
		}
	}
	
	/**
	 * ������
	 */
	protected void postProcess() throws GCIException {
		GCIException ex = null;
		//�������µ����һ�θ���
		try {
			if (psInsertBusiness_Duebill != null)
				psInsertBusiness_Duebill.executeBatch();

			if (psInsertBusiness_Contract != null)
				psInsertBusiness_Contract.executeBatch();

			if (psUpdateBusiness_Duebill != null)
				psUpdateBusiness_Duebill.executeBatch();

			logger.info("����ҵ����Ϣ����..."+recordCount);

		} catch (SQLException e) {
			ex =  new GCIException("�����±���ҵ���ݱ�ʧ��",e);
		}
		releaseResource();
		if(ex!=null) throw ex;
	}

	/**
	 * �ͷ����ݿ���Դ
	 *
	 */
	private void releaseResource(){
		// �ر����ݿ���Դ
		if (psInsertBusiness_Duebill != null) {
			try{
				psInsertBusiness_Duebill.close();
			}catch(SQLException e){logger.warn("psInsertBusiness_Duebill.close()",e);}
		}

		if (psInsertBusiness_Contract != null) {
			try{
				psInsertBusiness_Contract.close();
			}catch(SQLException e){logger.warn("psInsertBusiness_Contract.close()",e);}
		}

		if (psUpdateBusiness_Duebill != null) {
			try{
				psUpdateBusiness_Duebill.close();
			}catch(SQLException e){logger.warn("psUpdateBusiness_Duebill.close()",e);}
		}

		if (psSelectBusiness_Duebill != null) {
			try{
				psSelectBusiness_Duebill.close();
			}catch(SQLException e){logger.warn("psSelectBusiness_Duebill.close()",e);}
		}

		if (psSelectBusiness_Contract != null) {
			try{
				psSelectBusiness_Contract.close();
			}catch(SQLException e){logger.warn("psSelectBusiness_Contract.close()",e);}
		}

		psInsertBusiness_Duebill = null;
		psInsertBusiness_Contract = null;
		psUpdateBusiness_Duebill = null;
		psSelectBusiness_Duebill = null;
		psSelectBusiness_Contract = null;
	}

	/**
	 * ����һ�������Ϣ
	 */
	private void insertDuebill() throws SQLException {
		// ������
		psInsertBusiness_Duebill.setString(1, serialNo);
		psInsertBusiness_Duebill.setString(2, relativeSerialNo1);
		psInsertBusiness_Duebill.setString(3, relativeSerialNo2);
		psInsertBusiness_Duebill.setString(4, mainCustomerID);
		psInsertBusiness_Duebill.setString(5, businessType);
		psInsertBusiness_Duebill.setString(6, mainCustomerID);
		psInsertBusiness_Duebill.setString(7, customerName);
		psInsertBusiness_Duebill.setString(8, subjectNo);
		psInsertBusiness_Duebill.setDouble(9, businessSum);
		psInsertBusiness_Duebill.setString(10, getMappedValue("CurrencyMap", businessCurrency));
		psInsertBusiness_Duebill.setDouble(11, businessRate);
		psInsertBusiness_Duebill.setDouble(12, balance);
		psInsertBusiness_Duebill.setDouble(13, normalBalance);
		psInsertBusiness_Duebill.setDouble(14, overdueBalance);
		psInsertBusiness_Duebill.setDouble(15, dullBalance);
		psInsertBusiness_Duebill.setDouble(16, badBalance);
		psInsertBusiness_Duebill.setDouble(17, interestBalance1);
		psInsertBusiness_Duebill.setDouble(18, interestBalance2);
		psInsertBusiness_Duebill.setDouble(19, fineBalance1);
		psInsertBusiness_Duebill.setDouble(20, fineBalance2);
		psInsertBusiness_Duebill.setString(21, actualPutoutDate);
		psInsertBusiness_Duebill.setString(22, actualMaturity);
		psInsertBusiness_Duebill.setString(23, actualMaturity);
		psInsertBusiness_Duebill.setString(24, finishDate);
		psInsertBusiness_Duebill.setString(25, finishType);
		psInsertBusiness_Duebill.setInt(26, extendTimes);
		psInsertBusiness_Duebill.setString(27, advanceFlag);
		psInsertBusiness_Duebill.setInt(28, overDueDays);
		psInsertBusiness_Duebill.setString(29, payBackAccount);
		psInsertBusiness_Duebill.setString(30, payInterestAccount);
		psInsertBusiness_Duebill.setString(31, bailAccount);
		psInsertBusiness_Duebill.setString(32, putOutAccount);
		psInsertBusiness_Duebill.setString(33, mfOrgID);
		psInsertBusiness_Duebill.setString(34, classify4);
		psInsertBusiness_Duebill.setString(35, termsFreq);
		psInsertBusiness_Duebill.setString(36, businessStatus);
		psInsertBusiness_Duebill.setString(37, timsFlag);
		psInsertBusiness_Duebill.setString(38, manageOrgID);
		psInsertBusiness_Duebill.setString(39, manageUserID);
		psInsertBusiness_Duebill.setString(40, manageOrgID);
		psInsertBusiness_Duebill.setString(41, manageUserID);
		psInsertBusiness_Duebill.setString(42, accountOrgID);
		psInsertBusiness_Duebill.setString(43, inputDate);
		psInsertBusiness_Duebill.setString(44, inputDate);

		psInsertBusiness_Duebill.addBatch();

		psInsertBusiness_Contract.setString(1, relativeSerialNo2);
		psInsertBusiness_Contract.setString(2, inputDate);
		psInsertBusiness_Contract.setString(3, mainCustomerID);
		psInsertBusiness_Contract.setString(4, customerName);
		psInsertBusiness_Contract.setString(5, "010");
		psInsertBusiness_Contract.setString(6, businessType);
		psInsertBusiness_Contract.setString(7, accountOrgID);
		psInsertBusiness_Contract.setString(8, "2");
		psInsertBusiness_Contract.setString(9, "1");
		psInsertBusiness_Contract.setString(10, creditAggreement);
		psInsertBusiness_Contract.setString(11, vendeeCustomerID);
		psInsertBusiness_Contract.setString(12, vendeeCustomerName);
		psInsertBusiness_Contract.setString(13, getMappedValue("CSPSBusinessType", cspsBusinessType));
		psInsertBusiness_Contract.setString(14, getMappedValue("CurrencyMap", businessCurrency));
		psInsertBusiness_Contract.setDouble(15, businessSum);
		psInsertBusiness_Contract.setString(16, direction);
		psInsertBusiness_Contract.setInt(17, termMonth);
		psInsertBusiness_Contract.setDouble(18, businessRate);
		psInsertBusiness_Contract.setString(19, interestPayMethod);
		psInsertBusiness_Contract.setString(20, adjustRateType);
		psInsertBusiness_Contract.setString(21, "070");
		psInsertBusiness_Contract.setString(22, "010");
		psInsertBusiness_Contract.setString(23, "2");
		psInsertBusiness_Contract.setString(24, actualPutoutDate);
		psInsertBusiness_Contract.setString(25, actualMaturity);
		psInsertBusiness_Contract.setString(26, "99");
		psInsertBusiness_Contract.setDouble(27, balance);
		psInsertBusiness_Contract.setDouble(28, normalBalance);
		psInsertBusiness_Contract.setDouble(29, overdueBalance);
		psInsertBusiness_Contract.setDouble(30, dullBalance);
		psInsertBusiness_Contract.setDouble(31, badBalance);
		psInsertBusiness_Contract.setDouble(32, interestBalance1);
		psInsertBusiness_Contract.setDouble(33, interestBalance2);
		psInsertBusiness_Contract.setDouble(34, fineBalance1);
		psInsertBusiness_Contract.setDouble(35, fineBalance2);
		psInsertBusiness_Contract.setString(36, finishType);
		psInsertBusiness_Contract.setString(37, finishDate);
		psInsertBusiness_Contract.setDouble(38, businessSum);
		psInsertBusiness_Contract.setString(39, "DependentApply");
		psInsertBusiness_Contract.setString(40, businessForm);
		psInsertBusiness_Contract.setString(41, customerLevel);
		psInsertBusiness_Contract.setString(42, businessLevel);
		psInsertBusiness_Contract.setString(43, classLevel);
		psInsertBusiness_Contract.setString(44, manageOrgID);
		psInsertBusiness_Contract.setString(45, manageUserID);
		psInsertBusiness_Contract.setString(46, manageOrgID);
		psInsertBusiness_Contract.setString(47, manageUserID);
		psInsertBusiness_Contract.setString(48, manageOrgID);
		psInsertBusiness_Contract.setString(49, manageUserID);
		psInsertBusiness_Contract.setString(50, inputDate);
		psInsertBusiness_Contract.setString(51, inputDate);
		psInsertBusiness_Contract.setString(52, inputDate);
		psInsertBusiness_Contract.setString(53, inputDate);
		psInsertBusiness_Contract.setString(54, "2");

		psInsertBusiness_Contract.addBatch();

		insertBusiness_Duebill++;

		if (insertBusiness_Duebill >= commitRecord) {
			psInsertBusiness_Duebill.executeBatch();
			psInsertBusiness_Contract.executeBatch();
			insertBusiness_Duebill = 0;
			logger.info("insertBusiness_Duebill...commit..."+recordCount);
			logger.info("insertBusiness_Contract...commit..."+recordCount);
		}
	}

	/**
	 * ����һ�������Ϣ
	 */
	private void updateDuebill(String duebillNo) throws SQLException {
		psUpdateBusiness_Duebill.setString(1, mainCustomerID);
		psUpdateBusiness_Duebill.setString(2, businessType);
		psUpdateBusiness_Duebill.setString(3, mainCustomerID);
		psUpdateBusiness_Duebill.setString(4, customerName);
		psUpdateBusiness_Duebill.setString(5, subjectNo);
		psUpdateBusiness_Duebill.setDouble(6, businessSum);
		psUpdateBusiness_Duebill.setString(7, getMappedValue("CurrencyMap",businessCurrency));
		psUpdateBusiness_Duebill.setDouble(8, businessRate);
		psUpdateBusiness_Duebill.setDouble(9, balance);
		psUpdateBusiness_Duebill.setDouble(10, normalBalance);
		psUpdateBusiness_Duebill.setDouble(11, overdueBalance);
		psUpdateBusiness_Duebill.setDouble(12, dullBalance);
		psUpdateBusiness_Duebill.setDouble(13, badBalance);
		psUpdateBusiness_Duebill.setDouble(14, interestBalance1);
		psUpdateBusiness_Duebill.setDouble(15, interestBalance2);
		psUpdateBusiness_Duebill.setDouble(16, fineBalance1);
		psUpdateBusiness_Duebill.setDouble(17, fineBalance2);
		psUpdateBusiness_Duebill.setString(18, actualPutoutDate);
		psUpdateBusiness_Duebill.setString(19, actualMaturity);
		psUpdateBusiness_Duebill.setString(20, finishDate);
		psUpdateBusiness_Duebill.setString(21, finishType);
		psUpdateBusiness_Duebill.setInt(22, extendTimes);
		psUpdateBusiness_Duebill.setString(23, advanceFlag);
		psUpdateBusiness_Duebill.setInt(24, overDueDays);
		psUpdateBusiness_Duebill.setString(25, payBackAccount);
		psUpdateBusiness_Duebill.setString(26, payInterestAccount);
		psUpdateBusiness_Duebill.setString(27, bailAccount);
		psUpdateBusiness_Duebill.setString(28, putOutAccount);
		psUpdateBusiness_Duebill.setString(29, mfOrgID);
		psUpdateBusiness_Duebill.setString(30, classify4);
		psUpdateBusiness_Duebill.setString(31, termsFreq);
		psUpdateBusiness_Duebill.setString(32, businessStatus);
		psUpdateBusiness_Duebill.setString(33, timsFlag);
		psUpdateBusiness_Duebill.setString(34, accountOrgID);
		psUpdateBusiness_Duebill.setString(35, inputDate);
		psUpdateBusiness_Duebill.setString(36, duebillNo);

		psUpdateBusiness_Duebill.addBatch();
		updateBusiness_Duebill++;

		if (updateBusiness_Duebill >= commitRecord) {
			psUpdateBusiness_Duebill.executeBatch();
			updateBusiness_Duebill = 0;
			logger.info("���±���ҵ����Ϣ����..."+recordCount);
		}
	}

	/**
	 * Ԥ���������ݴ��ļ��л�ȡ�Ľ�ݺã����˺źͺ�ͬ�Ž���Ԥ����.
	 * <ol>Ԥ���������ݰ�����
	 * <li>�жϽ���Ƿ���ڣ������������dubillExists�У��Ա���������ȷ����update����innsert
	 * <li>���ݽ�ݡ�������ȱ�ţ���ȡ�������������Ͷ�����Ϣ��
	 * <li>
	 * @param duebillNo �����ļ��еĽ�ݺ�
	 * @param creditAggreement �����ļ��е�������ȱ��
	 * @throws SQLException
	 */
	protected void preprocess(String duebillNo, String creditAggreement)
	throws SQLException {
		duebillExists = false;
		String conBusinessForm = null;

		//��ȡ��ݱ�����Ϣ
		psSelectBusiness_Duebill.setString(1, duebillNo);
		ResultSet rs = psSelectBusiness_Duebill.executeQuery();
		if(rs.next()) {
			duebillExists = true;

		}
		rs.close();

		//�Զ�����������ͬ�Ŵ�ϵͳ
		if(!duebillExists)
			relativeSerialNo2 = getSerialNo("BUSINESS_CONTRACT", "SerialNo", "ht");

		//��ȡ�������������Ͷ�����Ϣ
		psSelectBusiness_Contract.setString(1, creditAggreement);
		rs = psSelectBusiness_Contract.executeQuery();
		if(rs.next()) {
			direction = rs.getString("Direction");
			interestPayMethod = rs.getString("InterestPayMethod");
			adjustRateType = rs.getString("AdjustRateType");
			customerLevel = rs.getString("CustomerLevel");
			businessLevel = rs.getString("BusinessLevel");
			classLevel = rs.getString("ClassLevel");
			manageOrgID = rs.getString("ManageOrgID");
			manageUserID = rs.getString("ManageUserID");
			conBusinessForm = rs.getString("BusinessForm");
			if(conBusinessForm.equals("010"))
				businessForm = "011";
			else if(conBusinessForm.equals("015"))
				businessForm = "016";
			else if(conBusinessForm.equals("020"))
				businessForm = "021";
			else
				businessForm = "011";
		}
		rs.close();
	}
}