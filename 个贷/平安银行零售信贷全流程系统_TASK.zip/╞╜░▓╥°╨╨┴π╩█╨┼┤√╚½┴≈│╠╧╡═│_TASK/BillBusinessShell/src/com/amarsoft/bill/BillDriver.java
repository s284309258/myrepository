package com.amarsoft.bill;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.Log.logger;
import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.log.Log;

public class BillDriver extends com.amarsoft.Task.ExecProgram.ExecAbstract {
	private Log logger = null;
	private Transaction Sqlca = null;

	@Override
	public void run() {
		String fileName = "D:\\bill\\BusinessXdYhcdhpPJ_20101013.dat";
		DBFunction tl = new DBFunction();
		String name = "";
		String startTime=getStringDateShort();
		System.out.println("===��ʼʱ��==" +startTime );
		// File file=new File(fileName);
		try {
			Sqlca = tl.getSqlca();
			String delSql="delete  from ACCEPTANCE_BILL ab where ab.inputdate='2010-10-13' ";
			PreparedStatement sp = null;
			sp = Sqlca.conn.prepareStatement(delSql);
			sp.execute();
			String endTime1=getStringDateShort();
			
			String sqls = " insert into ACCEPTANCE_BILL ("
					+ "SERIALNO ,"
					+ "RELATIVESERIALNO1 ,"
					+ "RELATIVESERIALNO2 ,"
					+ "INPUTDATE ,"
					+ "MAINCUSTOMERID ,"
					+ "CUSTOMERNAME ,"
					+ "SUBJECTNO ,"
					+ "BUSINESSSUM ,"
					+ "BUSINESSCURRENCY ,"
					+ "BUSINESSRATE ,"
					+ "BALANCE ,"
					+ "NORMALBALANCE ,"
					+ "OVERDUEBALANCE ,"
					+ "DULLBALANCE ,"
					+ "BADBALANCE ,"
					+ "INTERESTBALANCE1 ,"
					+ "INTERESTBALANCE2 ,"
					+ "FINEBALANCE1 ,"
					+ "FINEBALANCE2 ,"
					+ "ACTUALPUTOUTDATE ,"
					+ "ACTUALMATURITY ,"
					+ "FINISHDATE ,"
					+ "TABALANCE ,"
					+ "TAINTERESTBALANCE ,"
					+ "TATIMES ,"
					+ "LCATIMES ,"
					+ "EXTENDTIMES ,"
					+ "ADVANCEFLAG ,"
					+ "PAYBACKACCOUNT ,"
					+ "PAYINTERESTACCOUNT ,"
					+ "PUTOUTACCOUNT ,"
					+ "MAINORGID ,"
					+ "CREDITLINENO ,"
					+ "BUSINESSSTATUS ) "
					+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
			
			sp = Sqlca.conn.prepareStatement(sqls);

			BufferedReader reader;
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName), "GBK"));
			String tmp = "";
			String[] str;
			int i = 0;
			int j=0;
			boolean flage = false;

			while ((tmp = reader.readLine()) != null) {
				str = tmp.split("\t");
				i++;
				j++;
				System.out.println("==="+j);
				// if(str.length!=34){
				// System.out.println("==="+i+"=="+str.length+"===="+tmp);
			//	for (int j = 0; j < str.length; j++) {
			//	System.out.println("==|" + str[32] + "===" + str[32].length());
					sp.setString(1, str[0]);
					sp.setString(2, str[1]);
					sp.setString(3, str[2]);
					sp.setString(4, str[3]);
					sp.setString(5, str[4]);
					sp.setString(6, str[5]);
					sp.setString(7, str[6]);
					sp.setDouble(8, Double.parseDouble(str[7]));
					sp.setString(9, str[8]);
					sp.setDouble(10, Double.parseDouble(str[9]));
					sp.setDouble(11, Double.parseDouble(str[10]));
					sp.setDouble(12, Double.parseDouble(str[11]));
					sp.setDouble(13, Double.parseDouble(str[12]));
					sp.setDouble(14, Double.parseDouble(str[13]));
					sp.setDouble(15, Double.parseDouble(str[14]));
					sp.setDouble(16, Double.parseDouble(str[15]));
					sp.setDouble(17, Double.parseDouble(str[16]));
					sp.setDouble(18, Double.parseDouble(str[17]));
					sp.setDouble(19, Double.parseDouble(str[18]));
					sp.setString(20, str[19]);
					sp.setString(21, str[20]);
					sp.setString(22, str[21]);
					sp.setDouble(23, Double.parseDouble(str[22]));
					sp.setDouble(24, Double.parseDouble(str[23]));
					if("".equals(str[24])|| null==str[24]){
						sp.setInt(25, 0);
					}else{
						sp.setInt(25, Integer.parseInt(str[24]));
					}
					
					if("".equals(str[25])|| null==str[25]){
						sp.setInt(26, 0);
					}else{
						sp.setInt(26, Integer.parseInt(str[25]));
					}
					
					if("".equals(str[26])|| null==str[26]){
						sp.setInt(27, 0);
					}else{
						sp.setInt(27, Integer.parseInt(str[26]));
					}
					
					sp.setString(28, str[27]);
					sp.setString(29, str[28]);
					sp.setString(30, str[29]);
					sp.setString(31, str[30]);
					sp.setString(32, str[31]);
					sp.setString(33, str[32]);
					sp.setString(34, str[33]);
					
					sp.addBatch();

			//	}
				if (i == 1000) {
					sp.executeBatch();
					Sqlca.conn.commit();
					i = 0;
				}
			}
			System.out.println("=====" + i);
			sp.executeBatch();
			Sqlca.conn.commit();
			sp.close();
			reader.close();
			System.out.println("===��ʼʱ��==" +startTime );
			System.out.println("===����ʱ��==" +endTime1 );
			String endTime=getStringDateShort();
			System.out.println("===����ʱ��==" +endTime );
			System.out.println("=====" + i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static String getStringDateShort() {
		  Date currentTime = new Date();
		  SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
		  String dateString = formatter.format(currentTime);
		  return dateString;
		 } 
}
