package com.amarsoft.bill;

import com.amarsoft.log.Log;



/**
 * 
 * @author shshi
 *
 */
public abstract class RunDriver {
	Bill bill = null;
	public final Log logger = new Log("BillBusiness");
	boolean bReturnValue=true;
	java.sql.Connection Loan = null;
	public abstract boolean startDriver() throws Exception;
	public abstract boolean endDriver();
}