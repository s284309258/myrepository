package com.amarsoft.bill;

import java.sql.SQLException;

import com.amarsoft.log.Log;


/**
 * 
 * @author shshi
 *
 */
public class Bill {
	private Log logger = null;
//	public Bill(String BarCodeNo,String sObjectNo,String sObjectType,java.sql.Connection Loan){
//		
//	}
	protected java.sql.Connection loan = null; 
	
}
