#!/bin/sh

CLASSPATH=./etc:$CLASSPATH

for LL in `ls ./lib/*.jar`
do
CLASSPATH=$LL:$CLASSPATH
export CLASSPATH
done

if [ $# -ne 1 ];then
  echo "USAGE StopTask.sh ����"
  exit
fi

${JAVA_RUN} -classpath ${CLASSPATH} StopTask $1
