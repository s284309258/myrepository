#!/bin/sh

for LL in `ls ./lib/*.jar`
do
CLASSPATH=$LL:$CLASSPATH
export CLASSPATH
done

echo $CLASSPATH

${JAVA_RUN} -classpath ${CLASSPATH} RunTaskMain $1