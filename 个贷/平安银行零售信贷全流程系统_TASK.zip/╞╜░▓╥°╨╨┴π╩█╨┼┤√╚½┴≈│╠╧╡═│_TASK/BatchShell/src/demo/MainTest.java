package demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import com.amarsoft.are.ARE;
import com.amarsoft.task.Task;
import com.amarsoft.task.TaskBuilder;
import com.amarsoft.task.ui.MainWindow;
	
	
public class MainTest {
    public static final String PROPERTY_TASK_FILE = "gciTaskFile";
    public static final String DEFAULT_ARE_FILE = "BatchShell/etc/are.xml";

	    public static void main(String args[]) throws Exception
	    {
	        if(args.length > 0)
	            ARE.init(args[0]);
	        else
	            ARE.init(DEFAULT_ARE_FILE);
	        String taskFile = ARE.getProperty(PROPERTY_TASK_FILE);
	        if(taskFile == null)
	        {
	            ARE.getLog().fatal("\u6CA1\u6709\u5B9A\u4E49\u4EFB\u52A1\u914D\u7F6E\u6587\u4EF6\uFF01");
	            System.exit(-1);
	        }
	        
	        File file = new File(taskFile);
	    	
			BufferedReader reader = 
					new BufferedReader(
							new InputStreamReader(
											new FileInputStream(file)));
			String sLine;
			while((sLine = reader.readLine())!= null)
			{
				System.out.println(sLine);
			}
	        
	        Task task = TaskBuilder.buildTaskFromXML(taskFile);
	        if(task != null)
	        {
	            if(task.getProperty("runGUIMode", false))
	            {
	                MainWindow mw = new MainWindow();
	                mw.setTask(task);
	                mw.setVisible(true);
	            } else
	            {
	                task.start();
	                ARE.getLog().info("\u4EFB\u52A1\u8FD0\u884C\u5B8C\u6210\uFF01");
	            }
	        } else
	        {
	            ARE.getLog().fatal("\u521B\u5EFA\u4EFB\u52A1\u5931\u8D25\uFF01");
	            System.exit(-1);
	        }
	    }


	
	
}
