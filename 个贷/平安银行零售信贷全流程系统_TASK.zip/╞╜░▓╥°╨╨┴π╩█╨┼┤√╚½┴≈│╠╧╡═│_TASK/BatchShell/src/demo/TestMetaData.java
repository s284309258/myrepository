package demo;

import java.sql.SQLException;

import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.DataSourceMetaData;
import com.amarsoft.are.metadata.TableMetaData;

public class TestMetaData {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		ARE.init("etc/are.xml");
		DataSourceMetaData md = ARE.getMetaData("SHGJJ");
		TableMetaData t=md.getTable("����֧ȡ�������ݽṹ");
		ColumnMetaData temp[] =t.getColumns();
		for(int i=0;i<temp.length;i++){
			System.out.println(temp[i].getLabel()+temp[i].getTypeName());
		}
	}

}
