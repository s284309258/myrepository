/**
 * 
 */
package demo;

import com.amarsoft.task.Target;
import com.amarsoft.task.TaskEvent;
import com.amarsoft.task.util.TaskAdapter;

/**
 * @author tzhai
 *
 */
public class Pager extends TaskAdapter {

	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetExit(com.amarsoft.task.TaskEvent)
	 */
	public void targetExit(TaskEvent e) {
		Target t = e.getTarget();
		System.out.println("Ŀ�����н�����"+e.getTask().getName());
		StringBuffer sb = new StringBuffer("Ŀ��");
		sb.append(t.getName()).append("[").append(t.getDescribe()).append("]")
		.append("���н�����������еĵ�Ԫ��").append(t.getLastUnit().getName());
		System.out.println(sb);
	}

	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetStart(com.amarsoft.task.TaskEvent)
	 */
	public void targetStart(TaskEvent e) {
		Target t = e.getTarget();
		System.out.println("Ŀ�����п�ʼ��"+e.getTask().getName());
		StringBuffer sb = new StringBuffer("Ŀ��");
		sb.append(t.getName()).append("[").append(t.getDescribe()).append("]")
		.append("���п�ʼ��");
		System.out.println(sb);
	}

	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#taskExit(com.amarsoft.task.TaskEvent)
	 */
	public void taskExit(TaskEvent e) {
		System.out.println("�������н�����"+e.getTask().getName());
	}

	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#taskStart(com.amarsoft.task.TaskEvent)
	 */
	public void taskStart(TaskEvent e) {
		System.out.println("�������п�ʼ��"+e.getTask().getName());
	}
	
}
