package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;

public class YZInsertData {
	private static String lcSerialNo = "YZLC",lcrSerialNo = "YZLCR",lfSerialNo = "YZLF",lbSerialNo="YZLB",lgSerialNo ="YZLG",ldSerialNo="YZLD",grSerialNo="YZGR";
	private static int yzLcSerialNo = 1,yzLcrSerialNo=1,yzLFSerialNo=1,yzLBSerialNo=1,yzLGSerialNo=1,yzLDSerialNo=1,yzGRSerialNo=1;
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		
//		 select * from law_case where SerialNo like 'YZLC%' for update ;
//		 select * from  lawcase_relative where  SerialNo like 'YZLCR%' for update;
//		  select * from legalfare where  SerialNo like 'YZLF%' for update;
//		   select * from loan_bill legalfare where  billno like 'YZLB%' for update;
//		    select * from general_relative where general_relative.generalaccountno in( select serialNo from ledger_general legalfare where  SerialNo like 'YZLG%') for update;
//		    select * from ledger_general legalfare where  SerialNo like 'YZLG%' for update;
//		  select * from ledger_detail legalfare where  SerialNo like 'YZLD%' for update;
		  
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    String url = "jdbc:oracle:thin:@10.25.17.102:1521:PAMS";
	    Connection connBlaon_Test = DriverManager.getConnection(url, "bloan_test", "paic1234");
	    
//	    delete from law_case where SerialNo like 'YZLC%'  ;
//		delete from  lawcase_relative where  SerialNo like 'YZLCR%';
//		delete from  legalfare where  SerialNo like 'YZLF%';
//	delete from loan_bill legalfare where  billno like 'YZLB%';
//   delete from general_relative where general_relative.generalaccountno in( select serialNo from ledger_general legalfare where  SerialNo like 'YZLG%');
//		delete ledger_general legalfare where  SerialNo like 'YZLG%';
//   delete from ledger_detail legalfare where  SerialNo like 'YZLD%';
	   String sql1 = " delete from law_case where SerialNo like 'YZLC%'";
	   String sql2 = " delete from  lawcase_relative where  SerialNo like 'YZLCR%'";
	   String sql3 = " delete from  legalfare where  SerialNo like 'YZLF%'";
	   String sql4 = " delete from loan_bill  where  billno like 'YZLB%'";
	   String sql5 = " delete from general_relative where general_relative.generalaccountno in( select serialNo from ledger_general legalfare where  SerialNo like 'YZLG%')";
	   String sql6 = " delete ledger_general  where  SerialNo like 'YZLG%'";
	   String sql7 = " delete from ledger_detail where  SerialNo like 'YZLD%'";
	   String sql8 = " delete from account_receivable legalfare where  SerialNo like 'YZ%'";
	   
	    PreparedStatement psInsert1 = connBlaon_Test.prepareStatement(sql1);
	    PreparedStatement psInsert2 = connBlaon_Test.prepareStatement(sql2);
	    PreparedStatement psInsert3 = connBlaon_Test.prepareStatement(sql3);
	    PreparedStatement psInsert4 = connBlaon_Test.prepareStatement(sql4);
	    PreparedStatement psInsert5 = connBlaon_Test.prepareStatement(sql5);
	    PreparedStatement psInsert6 = connBlaon_Test.prepareStatement(sql6);
	    PreparedStatement psInsert7 = connBlaon_Test.prepareStatement(sql7);
	    PreparedStatement psInsert8 = connBlaon_Test.prepareStatement(sql8);
	    
	    psInsert1.execute();
	    psInsert2.execute();
	    psInsert3.execute();
	    psInsert4.execute();
	    psInsert5.execute();
	    psInsert6.execute();
	    psInsert7.execute();
	    psInsert8.execute();
	    connBlaon_Test.commit();
	    
	    
	    insertInto(connBlaon_Test);
	}

	
	
	private static void insertInto(Connection connBlaon_Test) throws Exception {
		//�������Ϸ��ñ�
		String insertAR = " insert into account_receivable (SERIALNO, OBJECTNO, OBJECTTYPE, AMOUNT, CURRENCY, " +
				" DEDUCTACCNO, INPUTDATE, INPUTUSER, ORGID, " +
				" STATUS, CHECKSTATUS, CHANNEL, " +
				" DEVALUEAMOUNT, FARETYPE, OPERATEORGID, " +
				" LOANSTATUS, CLASSIFY)" +
				" values (?,?,?,?,?," +
				" ?,?,?,?," +
				" ?,?,?," +
				" ?,?,?," +
				" ?,?)";
		PreparedStatement psInsertAR = connBlaon_Test.prepareStatement(insertAR);
		//Ȩ��ȷ�ϱ�
		String insertLGF = " insert into legalfare (SERIALNO, OBJECTNO, OBJECTTYPE, PAYAMOUNT, ACTUALAMOUNT, " +
				" INPUTDATE, CURRENCY, PAYOFFFLAG, USERID, ORGID, " +
				"  CHANNEL, DEDUCTACCNO, RETURNSOURCE, " +
				" OPERATEORGID, FARETYPE)values (?,?,?,?,?," +
				" ?,?,?,?,?," +
				" ?,?,?," +
				" ?,?)";
		
		PreparedStatement psInsertLGF = connBlaon_Test.prepareStatement(insertLGF);
		//������ˮ��
		String insertLB = " insert into loan_bill (BILLNO, TRANSID, PAYDATE, CURRENCY, " +
				" PAYBALANCE, ACTBALANCE,  " +
				"  BILLSTATUS, OPERATEUSERID, ORGID," +
				"   OBJECTNO, OBJECTTYPE, BILLTYPE)" +
				" values (?,?,?,?," +
				" ?,?," +
				" ?,?,?," +
				" ?,?,?)";
		PreparedStatement psinsertLB = connBlaon_Test.prepareStatement(insertLB);
		
		//������Ϣ��
		String insertLC = " insert into law_case (SERIALNO, REMARK, CHANNEL, INPUTUSER, INPUTDATE, " +
				" ORGID)" +
				" values (?,?,?,?,?," +
				" ?)";
		PreparedStatement psinsertLC = connBlaon_Test.prepareStatement(insertLC);
		
		//����������
		String insertLCR = " insert into lawcase_relative (SERIALNO, OBJECTTYPE, OBJECTNO, RELATIVESERIALNO)" +
				" values (?,?,?,?)";
		PreparedStatement psinsertLCR = connBlaon_Test.prepareStatement(insertLCR);
		
		//���˹�����
		String insertGR = " insert into general_relative (OBJECTTYPE, OBJECTNO, GENERALACCOUNTNO)" +
				"  values (?,?,?)";
		PreparedStatement psinsertGR = connBlaon_Test.prepareStatement(insertGR);
		//������˱�
		String insertLG = " insert into ledger_general (PUTOUTNO, SUBJECTNO, ORGID, CURRENCY, CREDITBALANCE, " +
				" DEBITBALANCE, ACCOUNTNO, SERIALNO, DIRECTION)" +
				" values (?,?,?,?,?," +
				" ?,?,?,?)";
		PreparedStatement psinsertLG = connBlaon_Test.prepareStatement(insertLG);
		
		//���뵱����ˮ
		String insertLD = " insert into ledger_detail (PUTOUTNO, BILLNO, TRANSID, SORTID, OCCURTIME," +
				"  OCCURDATE, CURRENCY, SUBJECTNO, CREDITAMT, DEBITAMT, " +
				" HANDSTATUS, ORGID, SERIALNO)" +
				" values (?,?,?,?,?," +
				" ?,?,?,?,?," +
				" ?,?,?)";
		PreparedStatement psinsertLD = connBlaon_Test.prepareStatement(insertLD);
		
		String querySql = "select * from business_contract where serialNo = ?";
		PreparedStatement psquerySql = connBlaon_Test.prepareStatement(querySql);
		
			
		//��lc��ˮ��
		String insertLcSerialNo = "";
		//��lrc��ˮ��
		String insertLrcSerialNo = "";
		String lastContractSerialNo = "";
		String sql = " SELECT * FROM YZ ORDER BY Contractserialno";
		PreparedStatement psSql = connBlaon_Test.prepareStatement(sql);
		ResultSet rs = psSql.executeQuery();
		while(rs.next()){
			
			String occurDate = "2010/12/04";
			//��AR����ˮ��
			String arSerialNo = "YZ"+rs.getString("SERIALNO").trim();
			//���������͡�
			String fareType = rs.getString("FARETYPE");
			if("���Ϸ�".equalsIgnoreCase(fareType.trim())){
				fareType = "01";
			}else if("��ȫ��".equalsIgnoreCase(fareType.trim())){
				fareType = "02";
			}else if("�����".equalsIgnoreCase(fareType.trim())){
				fareType = "03010";
			}else if("���߷�".equalsIgnoreCase(fareType.trim())){
				fareType = "03020";
			}else if("ִ�з�".equalsIgnoreCase(fareType.trim())){
				fareType = "03030";
			}else if("������".equalsIgnoreCase(fareType.trim())){
				fareType = "03040";
			}else if("������".equalsIgnoreCase(fareType.trim())){
				fareType = "03050";
			}else if("��������".equalsIgnoreCase(fareType.trim())){
				fareType = "03060";
			}
			//�����������
			String orgid = rs.getString("ORGID").trim();
			if("049".equalsIgnoreCase(orgid)){
				orgid = "100033";
			}else if("���ں���֧��".equalsIgnoreCase(orgid)){
				orgid = "100110117";
			}else if("�Ϻ�����Ӫҵ��".equalsIgnoreCase(orgid)){
				orgid = "100120101";
			}else if("�Ϻ�����Ӫҵ��".equalsIgnoreCase(orgid)){
				orgid = "100130101";
			}
			//���������͡�
			String transType = rs.getString("TRANSTYPE").trim();
			//���������ڡ�
			String inputdate = rs.getString("INPUTDATE").trim().replaceAll("-","/");
			//�����׽�
			double amount = rs.getDouble("AMOUNT");
			//���ۿ�š�
			String deducctAccNo = rs.getString("DEDUCTACCNO").trim();
			//����ֵ�����
			double devAmount = rs.getDouble("DEVALAMOUNT");
			//���Ƿ��Ѿ�Ȩ��ȷ�ϡ�
			String isYes = rs.getString("ISYES").trim();
			
			String date1 = "",date2 = "",date3 = "",dr1="",dr2="",dr3="";
			double drAmount1 = 0.0,drAmount2 = 0.0,drAmount3 = 0.0;
			if("P".equalsIgnoreCase(isYes)){
				 dr1 = "1";
				//����
				 drAmount1 = rs.getDouble("DIRECTIONAMOUNT1");
				//����
				 date1 = rs.getString("DIRCTIONDATE1").trim().replaceAll("-","/");
				//�����ˡ�
				 dr2 = "2";
				//����
				 drAmount2 = rs.getDouble("DIRECTIONAMOUNT2");
				//����
				 date2 = rs.getString("DIRCTIONDATE2").trim().replaceAll("-","/");
				//����Ժ��
				 dr3 = "3";
				//����
				 drAmount3 = rs.getDouble("DIRECTIONAMOUNT3");
				//����
				 date3 = rs.getString("DIRCTIONDATE3").trim().replaceAll("-","/");
			}
			//�����С�
			
			//����ͬ�š�CONTRACTSERIALNO
			String contractSerialNo = rs.getString("CONTRACTSERIALNO").trim();
			psquerySql.setString(1, contractSerialNo);
			ResultSet rsContrct = psquerySql.executeQuery();
			if(!rsContrct.next()) throw new Exception("û���ҵ���ͬ:::"+rsContrct);
			if(!lastContractSerialNo.equals(contractSerialNo)){
				//lc��ˮ
				insertLcSerialNo = createSerialNo(lcSerialNo,yzLcSerialNo++,occurDate);
				//lrc��ˮ
				insertLrcSerialNo = createSerialNo(lcrSerialNo,yzLcrSerialNo++,occurDate);
				//loan_bill��ˮ
				String billNo = createSerialNo(lbSerialNo,yzLBSerialNo++,occurDate);
				String billNodev = "";
				//����LC
				insertIntoLC(psinsertLC,insertLcSerialNo,orgid,occurDate);
				//����LRC
				insertIntoLRC(psinsertLCR,insertLrcSerialNo,"BusinessContract",contractSerialNo,insertLcSerialNo);
				String status = "";
				if("P".equalsIgnoreCase(isYes)){
					status = "2";
				}else{
					status = "1";
				}
				//����AR��
				insertIntoAR(psInsertAR,arSerialNo,insertLcSerialNo,"Law_Case",amount,"RMB",deducctAccNo,inputdate,"YZ",orgid,status,"2","1",devAmount,fareType,"YZ","","");
				if("P".equalsIgnoreCase(isYes)){
					insertIntoLF(psInsertLGF,arSerialNo,"Account_Receivable",dr1,drAmount1,date1,dr2,drAmount2,date2,dr3,drAmount3,date3,"RMB","0","YZ",orgid,"1",deducctAccNo,fareType,occurDate);
				}
				insertIntoLB(psinsertLB,billNo,"AR1010",inputdate,"RMB",amount,amount,"1","YZ",orgid,arSerialNo,"Account_Receivable","20",occurDate);
				//����в�����Ҳ���뵥�ݱ�
				if(devAmount>0){
					billNodev = createSerialNo(lbSerialNo,yzLBSerialNo++,occurDate);
					insertIntoLB(psinsertLB,billNodev,"AR1020",inputdate,"RMB",devAmount,devAmount,"1","YZ",orgid,arSerialNo,"Account_Receivable","20",occurDate);
				}
				//������ر��Ĳ���
				insertIntoLG(psinsertLG,psinsertGR,psinsertLD,arSerialNo,orgid,amount,billNo,occurDate,devAmount,billNodev,fareType);
				
				lastContractSerialNo =contractSerialNo;
			}else if(lastContractSerialNo.equals(contractSerialNo)){
				//loan_bill��ˮ
				String billNo = createSerialNo(lbSerialNo,yzLBSerialNo++,occurDate);
				String billNodev = "";
				String status = "";
				if("P".equalsIgnoreCase(isYes)){
					status = "2";
				}else{
					status = "1";
				}
				//����AR��
				insertIntoAR(psInsertAR,arSerialNo,insertLcSerialNo,"Law_Case",amount,"RMB",deducctAccNo,inputdate,"YZ",orgid,status,"2","1",devAmount,fareType,"YZ","","");
				if("P".equalsIgnoreCase(isYes)){
					insertIntoLF(psInsertLGF,arSerialNo,"Account_Receivable",dr1,drAmount1,date1,dr2,drAmount2,date2,dr3,drAmount3,date3,"RMB","0","YZ",orgid,"1",deducctAccNo,fareType,occurDate);
				}
				insertIntoLB(psinsertLB,billNo,"AR1010",inputdate,"RMB",amount,amount,"1","YZ",orgid,arSerialNo,"Account_Receivable","20",occurDate);
				if(devAmount>0){
					billNodev = createSerialNo(lbSerialNo,yzLBSerialNo++,occurDate);
					insertIntoLB(psinsertLB,billNodev,"AR1020",inputdate,"RMB",devAmount,devAmount,"1","YZ",orgid,arSerialNo,"Account_Receivable","20",occurDate);
				}
				//������ر��Ĳ���
				insertIntoLG(psinsertLG,psinsertGR,psinsertLD,arSerialNo,orgid,amount,billNo,occurDate,devAmount,billNodev,fareType);
				lastContractSerialNo =contractSerialNo;
			}
			
			
		}
		rs.close();
		psSql.close();
		
		psinsertLD.executeBatch();
		psinsertLG.executeBatch();
		psinsertGR.executeBatch();
		psinsertLCR.executeBatch();
		psinsertLC.executeBatch();
		psinsertLB.executeBatch();
		psInsertLGF.executeBatch();
		psInsertAR.executeBatch();
		
		psinsertLD.close();
		psinsertLG.close();
		psinsertGR.close();
		psinsertLCR.close();
		psinsertLC.close();
		psinsertLB.close();
		psInsertLGF.close();
		psInsertAR.close();
	}

	//������
	private static void insertIntoLG(PreparedStatement psinsertLG,
			PreparedStatement psinsertGR, PreparedStatement psinsertLD,
			String arSerialNo, String orgid, double amount, String billNo,
			String occurDate,double devAmount,String billNodev,String fareType) throws Exception {
		
		if(amount>0){
			//400�м��Ŀ��ˮ
			String lgSerilaNo1 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
			//������ˮ
			String lgSerilaNo2 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
			//����geneerl_relative
			GRInsert(psinsertGR,arSerialNo,lgSerilaNo1);
			GRInsert(psinsertGR,arSerialNo,lgSerilaNo2);
			//��Ŀ��
			String subjectNo = "";
			if("01".equalsIgnoreCase(fareType)){
				subjectNo = "13910401";
			}else if("02".equalsIgnoreCase(fareType)){
				subjectNo = "13910402";
			}else{
				subjectNo = "13910499";
			}
			//�����049�ģ����400����������of�ļ�of����
			if(arSerialNo.startsWith("YZ1")){
				LGInsert(psinsertLG,arSerialNo,"40310203",orgid,"RMB",amount,0,"N010403102",lgSerilaNo1,"B");
				LGInsert(psinsertLG,arSerialNo,subjectNo,orgid,"RMB",0,amount,"N010139104",lgSerilaNo2,"D");
				//��ʱ���в���
				if(devAmount>0){
					//40310204��of�м��Ŀ
					String lgSerilaNo3 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
					//13111401������Ӧ�տ��׼��
					String lgSerilaNo4 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
					//����geneerl_relative
					GRInsert(psinsertGR,arSerialNo,lgSerilaNo3);
					GRInsert(psinsertGR,arSerialNo,lgSerilaNo4);
					
					LGInsert(psinsertLG,arSerialNo,"40310204",orgid,"RMB",0,devAmount,"N010403104",lgSerilaNo3,"D");
					LGInsert(psinsertLG,arSerialNo,"13111401",orgid,"RMB",devAmount,0,"N010131114",lgSerilaNo4,"C");
					
					LDInsert(psinsertLD,lgSerilaNo3,billNodev,"AR1020","AR1020001","20:00:01",occurDate,"RMB","40310204",0.0,devAmount,"1",orgid);
					LDInsert(psinsertLD,lgSerilaNo4,billNodev,"AR1020","AR1020002","20:00:01",occurDate,"RMB","13111401",devAmount,0.0,"1",orgid);
				}
			}else{
				//����в��������ϷѼ��ڷ��еģ�of�м��Ŀֻ�ü��ܶ������
				if(devAmount>0){
					LGInsert(psinsertLG,arSerialNo,"40310204",orgid,"RMB",amount+devAmount,0,"N010403104",lgSerilaNo1,"B");
					LGInsert(psinsertLG,arSerialNo,subjectNo,orgid,"RMB",0,amount,"N010139104",lgSerilaNo2,"D");
					//13111401������Ӧ�տ��׼��
					String lgSerilaNo4 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
					LGInsert(psinsertLG,arSerialNo,"13111401",orgid,"RMB",devAmount,0,"N010131114",lgSerilaNo4,"C");
					
					LDInsert(psinsertLD,lgSerilaNo1,billNodev,"AR1020","AR1020001","20:00:01",occurDate,"RMB","40310204",0.0,devAmount,"1",orgid);
					LDInsert(psinsertLD,lgSerilaNo4,billNodev,"AR1020","AR1020002","20:00:01",occurDate,"RMB","13111401",devAmount,0.0,"1",orgid);
				}else{
					LGInsert(psinsertLG,arSerialNo,"40310204",orgid,"RMB",amount,0,"N010403104",lgSerilaNo1,"B");
					LGInsert(psinsertLG,arSerialNo,subjectNo,orgid,"RMB",0,amount,"N010139104",lgSerilaNo2,"D");
				}
				
			}
			//�����049�ģ����400����������of�ļ�of����
			if(arSerialNo.startsWith("YZ1")){
				LDInsert(psinsertLD,lgSerilaNo1,billNo,"AR1010","AR1010001","20:00:01",occurDate,"RMB","40310203",amount,0.0,"1",orgid);
				LDInsert(psinsertLD,lgSerilaNo2,billNo,"AR1010","AR1010002","20:00:01",occurDate,"RMB",subjectNo,0.0,amount,"1",orgid);
			}else{
				LDInsert(psinsertLD,lgSerilaNo1,billNo,"AR1010","AR1010001","20:00:01",occurDate,"RMB","40310204",amount,0.0,"1",orgid);
				LDInsert(psinsertLD,lgSerilaNo2,billNo,"AR1010","AR1010002","20:00:01",occurDate,"RMB",subjectNo,0.0,amount,"1",orgid);
			}
			
//			if(devAmount>0){
//				//40310204��of�м��Ŀ
//				String lgSerilaNo3 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
//				//13111401������Ӧ�տ��׼��
//				String lgSerilaNo4 = createSerialNo(lgSerialNo,yzLGSerialNo++,occurDate);
//				//����geneerl_relative
//				GRInsert(psinsertGR,arSerialNo,lgSerilaNo3);
//				GRInsert(psinsertGR,arSerialNo,lgSerilaNo4);
//				
//				LGInsert(psinsertLG,arSerialNo,"40310204",orgid,"RMB",0,devAmount,"N010403104",lgSerilaNo3,"D");
//				LGInsert(psinsertLG,arSerialNo,"13111401",orgid,"RMB",devAmount,0,"N010131114",lgSerilaNo4,"C");
//				
//				LDInsert(psinsertLD,lgSerilaNo3,billNodev,"AR1020","AR1020001","20:00:01",occurDate,"RMB","40310204",0.0,devAmount,"1",orgid);
//				LDInsert(psinsertLD,lgSerilaNo4,billNodev,"AR1020","AR1020002","20:00:01",occurDate,"RMB","13111401",devAmount,0.0,"1",orgid);
//			}
		}
		
		
	}

	private static void LDInsert(PreparedStatement psinsertLD,
			String lgSerilaNo1, String billNo, String transID, String sortId,
			String occurTime, String occurDate, String currency, String subjectNo,
			double creditAmount, double debitAmount, String handStatus, String orgid) throws Exception {
		
		psinsertLD.setString(1, lgSerilaNo1);
		psinsertLD.setString(2, billNo);
		psinsertLD.setString(3, transID);
		psinsertLD.setString(4, sortId);
		psinsertLD.setString(5, occurTime);
		psinsertLD.setString(6, occurDate);
		psinsertLD.setString(7, currency);
		psinsertLD.setString(8, subjectNo);
		psinsertLD.setDouble(9, creditAmount);
		psinsertLD.setDouble(10, debitAmount);
		psinsertLD.setString(11, handStatus);
		psinsertLD.setString(12, orgid);
		psinsertLD.setString(13, createSerialNo(ldSerialNo,yzLDSerialNo++,occurDate));
		psinsertLD.addBatch();
		
	}

	private static void LGInsert(PreparedStatement psinsertLG,
			String arSerialNo, String subjectNo, String orgid, String currency,
			double creditAmount, double debitAmount, String accountNo, String lgSerilaNo1,
			String direction) throws SQLException {
		psinsertLG.setString(1, arSerialNo);
		psinsertLG.setString(2, subjectNo);
		psinsertLG.setString(3, orgid);
		psinsertLG.setString(4, currency);
		psinsertLG.setDouble(5, creditAmount);
		psinsertLG.setDouble(6, debitAmount);
		psinsertLG.setString(7, accountNo);
		psinsertLG.setString(8, lgSerilaNo1);
		psinsertLG.setString(9, direction);
		psinsertLG.addBatch();
	}

	private static void GRInsert(PreparedStatement psinsertGR,
			String arSerialNo, String lgSerilaNo1) throws SQLException {
		psinsertGR.setString(1, "Account_Receivable");
		psinsertGR.setString(2, arSerialNo);
		psinsertGR.setString(3, lgSerilaNo1);
		psinsertGR.addBatch();
		
	}

	//lb��
	private static void insertIntoLB(PreparedStatement psinsertLB,String billNo,
			String transID, String inputdate, String currency, double amount,
			double amount2, String billStatus, String operateuserid, String orgid,
			String objectno, String objecttype, String billtype,String occurDate) throws SQLException, Exception {
		//loan_bill billno,transid(AR1010),paydate,currency,paybalance,actbalance,billstatus,operateuserid,orgid,objectno,objecttype,billtype(20)
		//insertLbSerialNo = createSerialNo(lbSerialNo,yzLBSerialNo,occurDate);
		psinsertLB.setString(1, billNo);
		psinsertLB.setString(2, transID);
		psinsertLB.setString(3, inputdate);
		psinsertLB.setString(4, currency);
		psinsertLB.setDouble(5, amount);
		psinsertLB.setDouble(6, amount2);
		psinsertLB.setString(7, billStatus);
		psinsertLB.setString(8, operateuserid);
		psinsertLB.setString(9, orgid);
		psinsertLB.setString(10, objectno);
		psinsertLB.setString(11, objecttype);
		psinsertLB.setString(12, billtype);
		psinsertLB.addBatch();
	}

	//legalfare��
	private static void insertIntoLF(PreparedStatement psInsertLGF,
			String arSerialNo, String objectType, String dr1, double drAmount1,
			String date1, String dr2, double drAmount2, String date2,
			String dr3, double drAmount3, String date3, String currency,
			String offflag, String userid, String orgid, String channel,
			String deducctAccNo, String fareType,String occurDate) throws Exception {
//		String insertLGF = " insert into legalfare (SERIALNO, OBJECTNO, OBJECTTYPE, PAYAMOUNT, ACTUALAMOUNT, " +
//		" INPUTDATE, CURRENCY, PAYOFFFLAG, USERID, ORGID, " +
//		"  CHANNEL, DEDUCTACCNO, RETURNSOURCE, " +
//		" OPERATEORGID, FARETYPE)values (?,?,?,?,?," +
//		" ?,?,?,?,?," +
//		" ?,?,?," +
//		" ?,?)";
//		private static String lcSerialNo = "YZLC",lcrSerialNo = "YZLCR",lfSerialNo = "YZLF";
//		private static int yzLcSerialNo = 0,yzLcrSerialNo=0,yzLFSerialNo=0;
		if(drAmount1>0){
			String serialno = createSerialNo(lfSerialNo,yzLFSerialNo++,occurDate);
			psInsertLGF.setString(1, serialno);
			psInsertLGF.setString(2, arSerialNo);
			psInsertLGF.setString(3, objectType);
			psInsertLGF.setDouble(4, drAmount1);
			psInsertLGF.setDouble(5, 0);
			psInsertLGF.setString(6, date1);
			psInsertLGF.setString(7, currency);
			psInsertLGF.setString(8, offflag);
			psInsertLGF.setString(9, userid);
			psInsertLGF.setString(10, orgid);
			psInsertLGF.setString(11, channel);
			psInsertLGF.setString(12, deducctAccNo);
			psInsertLGF.setString(13, dr1);
			psInsertLGF.setString(14, "YZ");
			psInsertLGF.setString(15, fareType);
			psInsertLGF.addBatch();
		}
		
		if(drAmount2>0){
			String serialno = createSerialNo(lfSerialNo,yzLFSerialNo++,occurDate);
			psInsertLGF.setString(1, serialno);
			psInsertLGF.setString(2, arSerialNo);
			psInsertLGF.setString(3, objectType);
			psInsertLGF.setDouble(4, drAmount2);
			psInsertLGF.setDouble(5, 0);
			psInsertLGF.setString(6, date2);
			psInsertLGF.setString(7, currency);
			psInsertLGF.setString(8, offflag);
			psInsertLGF.setString(9, userid);
			psInsertLGF.setString(10, orgid);
			psInsertLGF.setString(11, channel);
			psInsertLGF.setString(12, deducctAccNo);
			psInsertLGF.setString(13, dr2);
			psInsertLGF.setString(14, "YZ");
			psInsertLGF.setString(15, fareType);
			psInsertLGF.addBatch();
		}
		
		if(drAmount3>0){
			String serialno = createSerialNo(lfSerialNo,yzLFSerialNo++,occurDate);
			psInsertLGF.setString(1, serialno);
			psInsertLGF.setString(2, arSerialNo);
			psInsertLGF.setString(3, objectType);
			psInsertLGF.setDouble(4, drAmount3);
			psInsertLGF.setDouble(5, 0);
			psInsertLGF.setString(6, date3);
			psInsertLGF.setString(7, currency);
			psInsertLGF.setString(8, offflag);
			psInsertLGF.setString(9, userid);
			psInsertLGF.setString(10, orgid);
			psInsertLGF.setString(11, channel);
			psInsertLGF.setString(12, deducctAccNo);
			psInsertLGF.setString(13, dr3);
			psInsertLGF.setString(14, "YZ");
			psInsertLGF.setString(15, fareType);
			psInsertLGF.addBatch();
		}
		
	}

	//ar
	private static void insertIntoAR(PreparedStatement psInsertAR,
			String arSerialNo, String insertLcSerialNo, String objectType,
			double amount, String currency, String deducctAccNo,
			String inputdate, String inputUser, String orgid, String status,
			String checkStatus, String channel, double devAmount, String fareType,
			String operateOrgID, String LoanStatus, String classify) throws SQLException {
//		String insertAR = " insert into account_receivable (SERIALNO, OBJECTNO, OBJECTTYPE, AMOUNT, CURRENCY, " +
//		" DEDUCTACCNO, INPUTDATE, INPUTUSER, ORGID, " +
//		"  STATUS, CHECKSTATUS, CHANNEL, " +
//		"  DEVALUEAMOUNT, FARETYPE, OPERATEORGID, " +
//		" LOANSTATUS, CLASSIFY)
		psInsertAR.setString(1, arSerialNo);
		psInsertAR.setString(2, insertLcSerialNo);
		psInsertAR.setString(3, objectType);
		psInsertAR.setDouble(4, amount);
		psInsertAR.setString(5, currency);
		psInsertAR.setString(6, deducctAccNo);
		psInsertAR.setString(7, inputdate);
		psInsertAR.setString(8, inputUser);
		psInsertAR.setString(9, orgid);
		psInsertAR.setString(10, status);
		psInsertAR.setString(11, checkStatus);
		psInsertAR.setString(12, channel);
		psInsertAR.setDouble(13, devAmount);
		psInsertAR.setString(14, fareType);
		psInsertAR.setString(15, operateOrgID);
		psInsertAR.setString(16, LoanStatus);
		psInsertAR.setString(17, classify);
		psInsertAR.addBatch();
	}


	//LRC������
	private static void insertIntoLRC(PreparedStatement psinsertLCR,
			String insertLrcSerialNo, String objectType, String contractSerialNo,
			String insertLcSerialNo) throws SQLException {
//		String insertLCR = " insert into lawcase_relative (SERIALNO, OBJECTTYPE, OBJECTNO, RELATIVESERIALNO)" +
//		" values (?,?,?,?)";
		psinsertLCR.setString(1, insertLrcSerialNo);
		psinsertLCR.setString(2, objectType);
		psinsertLCR.setString(3, contractSerialNo);
		psinsertLCR.setString(4, insertLcSerialNo);
		psinsertLCR.addBatch();
	}

	//LC������
	private static void insertIntoLC(PreparedStatement psinsertLC,
			String insertLcSerialNo, String orgid,String occurDate) throws SQLException {
//		String insertLC = " insert into law_case (SERIALNO, REMARK, CHANNEL, INPUTUSER, INPUTDATE, " +
//		" ORGID, UPDATEUSER, UPDATEDATE, RELATIVESERIALNO, OPERATEORGID)" +
//		" values (?,?,?,?,?," +
//		" ?,?,?,?,?)";
		psinsertLC.setString(1, insertLcSerialNo);
		psinsertLC.setString(2, "YZ");
		psinsertLC.setString(3, "1");
		psinsertLC.setString(4, "YZ");
		psinsertLC.setString(5, occurDate);
		psinsertLC.setString(6, orgid);
		psinsertLC.addBatch();
	}


	/*
	 * ����MASSAGE_INFO��ˮ��
	 * ���� "B"+����+��λ��ˮ
	 * */
	private static String createSerialNo(String table,int iSerialCount,String date ) throws Exception
	{
		String sDate = DateTools.getStringDate(date);
		String sSortNo = NumberTools.lPad(iSerialCount,8,'0');
		return table+sDate+sSortNo;
	}
	
}
