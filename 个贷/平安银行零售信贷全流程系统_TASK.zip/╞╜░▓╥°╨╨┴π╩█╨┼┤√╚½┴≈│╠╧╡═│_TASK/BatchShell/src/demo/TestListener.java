/**
 * 
 */
package demo;

import com.amarsoft.task.ExecuteUnit;
import com.amarsoft.task.Route;
import com.amarsoft.task.Target;
import com.amarsoft.task.Task;
import com.amarsoft.task.TaskEvent;
import com.amarsoft.task.util.TaskAdapter;

/**
 * @author tzhai
 *
 */
public class TestListener extends TaskAdapter {

	private boolean taskEventEnabled = false;
	private boolean targetEventEnabled = false;
	private boolean unitEventEnabled = false;
	private boolean routeEventEnabled = false;
	/**
	 * @return the routeEventEnabled
	 */
	public final boolean isRouteEventEnabled() {
		return routeEventEnabled;
	}
	/**
	 * @param routeEventEnabled the routeEventEnabled to set
	 */
	public final void setRouteEventEnabled(boolean routeEventEnabled) {
		this.routeEventEnabled = routeEventEnabled;
	}
	/**
	 * @return the targetEventEnabled
	 */
	public final boolean isTargetEventEnabled() {
		return targetEventEnabled;
	}
	/**
	 * @param targetEventEnabled the targetEventEnabled to set
	 */
	public final void setTargetEventEnabled(boolean targetEventEnabled) {
		this.targetEventEnabled = targetEventEnabled;
	}
	/**
	 * @return the taskEventEnabled
	 */
	public final boolean isTaskEventEnabled() {
		return taskEventEnabled;
	}
	/**
	 * @param taskEventEnabled the taskEventEnabled to set
	 */
	public final void setTaskEventEnabled(boolean taskEventEnabled) {
		this.taskEventEnabled = taskEventEnabled;
	}
	/**
	 * @return the unitEventEnabled
	 */
	public final boolean isUnitEventEnabled() {
		return unitEventEnabled;
	}
	/**
	 * @param unitEventEnabled the unitEventEnabled to set
	 */
	public final void setUnitEventEnabled(boolean unitEventEnabled) {
		this.unitEventEnabled = unitEventEnabled;
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#routeAdded(com.amarsoft.task.TaskEvent)
	 */
	public void routeAdded(TaskEvent e) {
		if(isRouteEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#routeRemoved(com.amarsoft.task.TaskEvent)
	 */
	public void routeRemoved(TaskEvent e) {
		if(isRouteEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetAdded(com.amarsoft.task.TaskEvent)
	 */
	public void targetAdded(TaskEvent e) {
		if(isTargetEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetExit(com.amarsoft.task.TaskEvent)
	 */
	public void targetExit(TaskEvent e) {
		if(isTargetEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetRemoved(com.amarsoft.task.TaskEvent)
	 */
	public void targetRemoved(TaskEvent e) {
		if(isTargetEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#targetStart(com.amarsoft.task.TaskEvent)
	 */
	public void targetStart(TaskEvent e) {
		if(isTargetEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#taskExit(com.amarsoft.task.TaskEvent)
	 */
	public void taskExit(TaskEvent e) {
		if(isTaskEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#taskStart(com.amarsoft.task.TaskEvent)
	 */
	public void taskStart(TaskEvent e) {
		if(isTaskEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#unitAdded(com.amarsoft.task.TaskEvent)
	 */
	public void unitAdded(TaskEvent e) {
		if(isUnitEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#unitExit(com.amarsoft.task.TaskEvent)
	 */
	public void unitExit(TaskEvent e) {
		if(isUnitEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#unitRemoved(com.amarsoft.task.TaskEvent)
	 */
	public void unitRemoved(TaskEvent e) {
		if(isUnitEventEnabled()) printEvent(e);
	}
	/* (non-Javadoc)
	 * @see com.amarsoft.task.TaskAdapter#unitStart(com.amarsoft.task.TaskEvent)
	 */
	public void unitStart(TaskEvent e) {
		if(isUnitEventEnabled()) printEvent(e);
	}
	
	private void printEvent(TaskEvent e){
		System.out.println("============================");
		System.out.println("EventType="+e.getType());
		Task task = e.getTask();
		Target target = e.getTarget();
		ExecuteUnit unit= e.getUnit();
		Route route = e.getRoute();
		System.out.println("Task="+task.getName()+"["+task.getDescribe()+"]");
		if(target!=null) System.out.println("Target="+target.getName()+"["+target.getDescribe()+"]");
		if(unit!=null) System.out.println("Unit="+unit.getName()+"["+unit.getDescribe()+"]");
		if(route!=null) System.out.println("Route="+route.executeStatus()+"["+route.nextUnit()==null?"null":route.nextUnit().getName()+"]");
			
	}
	
}
