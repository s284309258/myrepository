/**
 * 
 */
package demo;

import com.amarsoft.task.ExecuteUnit;
import com.amarsoft.task.Route;
import com.amarsoft.task.Target;
import com.amarsoft.task.Task;

/**
 * @author tzhai
 * չʾ��ǰ��Ԫִ�л�����������ڲ���Ϣ
 */
public class TaskExplorer extends ExecuteUnit {

	/* (non-Javadoc)
	 * @see com.amarsoft.task.ExecuteUnit#execute()
	 */
	public int execute() {
		Task task = getTarget().getTask();
		printTask(task);
		return 0;
	}
	
	private void printTask(Task task){
		System.out.println("Task: " + task.getName() + "("+task.getDescribe()+")");
		Target targets[] = task.getTargets();
		for(int i=0;i<targets.length;i++){
			printTarget(targets[i]);
		}
	}
	
	private void printTarget(Target target){
		System.out.println("\tTarget: " + target.getName() + "("+target.getDescribe()+")");
		ExecuteUnit units[] = target.getUnits();
		for(int i=0;i<units.length;i++){
			printUnit(units[i]);
		}
	}
	
	private void printUnit(ExecuteUnit unit){
		System.out.println("\t\tUnit: " + unit.getName() + "("+unit.getDescribe()+")");
		Route routes[] = unit.getRouteTable();
		for(int i=0;i<routes.length;i++){
			printRoute(routes[i]);
		}
	}
	
	private void printRoute(Route route){
		System.out.println("\t\t\tRoute: On " + route.executeStatus() + " To "+route.nextUnit().getName());
	}

}
