/**
 * 
 */
package demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.are.ARE;

/**
 * @author wyg
 *
 */
public class ExportDBToXML {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ARE.init("etc/are.xml");
			Connection connection=ARE.getDBConnection("ploan");
			String sql=" select case when trim(ii.certtype)='Ind01' then 'A'"+
            "  when trim(ii.certtype)='Ind10' then 'D'"+
            "  when trim(ii.certtype)='Ind04' then 'B'"+ 
            "  when trim(ii.certtype)='Ind03' then 'I'"+ 
            "  when trim(ii.certtype)='Ind02' then 'F'"+ 
            "  when trim(ii.certtype)='Ind05' then 'E'"+ 
            "  when trim(ii.certtype)='Ind06' then 'H'"+
            "  when trim(ii.certtype)='Ind07' then 'H'"+ 
            "  when trim(ii.certtype)='Ind08' then 'G'"+ 
            "  when trim(ii.certtype)='Ind09' then 'H'"+ 
            "  when trim(ii.certtype)='Ind11' then 'H'"+
            "  else 'A' end as IDENTIFICATION, "+
            " ii.customerid as CUSTOMER_CODE,"+
            " '' as STUDENT_CODE,  "+
            " ii.fullname as CUSTOMER_NAME,"+
            " ii.FAMILYADD as CUSTOMER_AREA,"+
            " getshb(ii.FAMILYADD) as REGION,  "+
            " ci.enterprisename as SCHOOL_NAME ,"+
            " ci.REGISTERADD as school_area, "+
            " nvl(ci.regioncode,getshb(ci.REGISTERADD)) as school_code, "+
            " cp.normalbalance+cp.waitoverduebalance+cp.overduebalance as fund_code, "+
            " case when cp.orgid like '31%' then 'F019B101310000001' else 'F019B101110000001' end as bank_code,"+
            " to_char(to_date(cp.releasedate,'yyyy/mm/dd'),'yyyymmdd') as send_time,"+
            " case when cp.businesstype='2020050' then '2' else '1' end as loan_type,"+
            " cp.overduedays as break_time "+
            " from ind_info ii,preport3.class_pay cp,Ent_Info ci    "+          
            " where cp.customerid=ii.customerid "+                          
            " and cp.licenceid=ci.CUSTOMERID  "+                  
            " and cp.occurdate=(select substr(to_char(to_date(CurDeductDate,'yyyy/mm/dd')-20,'yyyy/mm/dd'),0,7) from Ploan_Setup where SerialNo='0000001') "+
            " and overduedays>90  "+             
            " and cp.businesstype in ('91','2020050')";
			String fileName="d:\\��ѧ����200908.xml";
			ExportDBToXML exp=new ExportDBToXML();
			exp.export(connection, sql, fileName);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void export(Connection connection,String sql,String fileName) throws SQLException, IOException{
		ResultSet rs = connection.createStatement().executeQuery(sql);
		OutputStreamWriter outputstreamwriter = new OutputStreamWriter(new FileOutputStream(new File(fileName)), "GBK");	
		
		outputstreamwriter.write("<?xml version=\"1.0\" encoding=\"GBK\"?>\n");
		outputstreamwriter.write("<cbrc-ml>\n");
		outputstreamwriter.write("<gather type=\"loan-break-student\" name=\"��ѧ����ΥԼ�ͻ�ͳ�Ʊ�\" version=\"20060712\" no=\"����ͳ��[2006] 008 ��\" dept=\"�����ͳ�Ʋ�\" currency=\"\" currency-unit=\"\">\n");
		outputstreamwriter.write("<report org=\"C001B101210100001\" year=\"2008\" month=\"03\" fill=\"����\" phone=\"01051527500\" verify=\"����\">\n");
		outputstreamwriter.write("<table type=\"many\" code=\"retail-break-personal\" desc=\"��ѧ����ΥԼ�ͻ�ͳ�Ʊ�\">\n");
		
		while(rs.next()){
			outputstreamwriter.write("<record>\n");
			outputstreamwriter.write("<cell name=\"identification-type\">"+rs.getString("IDENTIFICATION")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"customer-code\">"+rs.getString("CUSTOMER_CODE")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"student-code\">"+rs.getString("STUDENT_CODE")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"customer-name\">"+rs.getString("CUSTOMER_NAME")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"customer-area\">"+rs.getString("CUSTOMER_AREA")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"region-code\">"+rs.getString("REGION")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"school-name\">"+rs.getString("SCHOOL_NAME")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"school-area\">"+rs.getString("school_area")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"school-code\">"+rs.getString("school_code")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"fund-code\">"+rs.getString("fund_code")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"bank-code\">"+rs.getString("bank_code")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"send-time\">"+rs.getString("send_time")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"loan-type\">"+rs.getString("loan_type")+"</cell>\n");
			outputstreamwriter.write("<cell name=\"break-time\">"+rs.getString("break_time")+"</cell>\n");

			outputstreamwriter.write("</record>\n");
		}
		rs.getStatement().close();

		outputstreamwriter.write("</table>\n");
		outputstreamwriter.write("</report>\n");
		outputstreamwriter.write("</gather>\n");
		outputstreamwriter.write("</cbrc-ml>\n");
	
		outputstreamwriter.close();
	}

}
