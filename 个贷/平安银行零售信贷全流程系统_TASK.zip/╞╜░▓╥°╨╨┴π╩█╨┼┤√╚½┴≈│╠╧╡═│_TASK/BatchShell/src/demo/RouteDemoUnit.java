package demo;

import com.amarsoft.task.ExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class RouteDemoUnit extends ExecuteUnit {

	private int returnValue = TaskConstants.ES_UNKNOWN;
	@SuppressWarnings("deprecation")
	public int execute() {
		transferProperties();
		logger.info("Return Value is: " + getReturnValue());
		return returnValue;
	}
	/**
	 * @return Returns the returnValue.
	 */
	public final int getReturnValue() {
		return returnValue;
	}
	/**
	 * @param returnValue The returnValue to set.
	 */
	public final void setReturnValue(int returnValue) {
		this.returnValue = returnValue;
	}

}
