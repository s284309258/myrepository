package demo;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;

public class BarCode {

	private static int begin = 0;
	public static void main(String[] args) throws Exception {
//		private String createSerialNo() throws Exception
//		{
//			iSerialCount++;
//			String sDate = DateTools.getStringDate(nextDate);
//			String sSortNo = NumberTools.lPad(iSerialCount,8,'0');
//			return "B"+sDate+sSortNo;
//		}
		for(int i=1;i<652;i++){
			createBarCode(i);
		}
		
	}

	private static void createBarCode(int i) throws Exception {
		begin++;
		String pre = "KB0001049";
		String barCode = NumberTools.lPad(begin,5,'0');
		System.out.println(pre+barCode);
	}

}
