package com.amarsoft.app.datax.gci.deductacc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.amarsoft.account.Deal.TransDayInte;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.repay.jbo.IRepayScheduleEngine;
import com.amarsoft.account.repay.jbo.RepaymentSchedule;
import com.amarsoft.account.repay.jbo.RepaymentType;
import com.amarsoft.account.sysconfig.RepayTypeConfig;

public class BatchPreDeductData extends CommonExecuteUnit{

	private int commitNum ;
	private int preDays ;
	private int dealNum = 0;

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql="  call dbmgr.truncate_table ('RCPMDATA','PreDeduct_Data') ";
				logger.info("��� PreDeduct_Data:sql="+delSql);
				PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
				psDeleteDeductData.execute();
				psDeleteDeductData.close();
				logger.info("���PreDeduct_Data������� ");
				
				logger.info("����Ԥ��������......");
				CreateBatchPreDeductData();
			
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	
	public void CreateBatchPreDeductData() throws Exception
	{
		preDays=Integer.parseInt(getProperty("preDays", "1"));
		
		//�õ�����״̬��������
		logger.info("��ʼ���뵱ǰ����״̬��...");
		BatchQainPlan();
		initFareInfo();
		logger.info("���뵱ǰ����״̬�����!");
		
		//��ʼѭ������
			for(int i=1;i<preDays;i++)
			{
				logger.info("��ʼ���ɵ�"+i+"���Ԥ��������...");
				String CreateDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY, i);
				//ȡ�ƻ�
				BatchLastPlan(CreateDate);
				//���ɵ��ջ�������
				BatchCreatePlan(CreateDate);
				//���¼���
				BatchUpdatePlan(CreateDate);
				//�˻�������
				updateFareInfo(CreateDate);
			}
	}
	
	//�õ�����״̬��������
	public void BatchQainPlan() throws SQLException
	{
		String insertSql = "insert into PreDeduct_Data(PreDeductDate,PutOutNo,Sterm,AheadNum,PayDate," 
				  + "PayCorp,PayInte,PayFine,WaitInte,GracePeriod,OrgID,LoanAccNo,Balance) " 
				  + "(select '"+deductDate+"',ls.PutOutNo,ls.Sterm,ls.AheadNum,ls.PayDate," 
				  + "ls.PayCurrentCorp+ls.PayDefaultCorp+ls.PayOverdueCorp-" 
				  +	"ls.ActualCurrentCorp-ls.ActualDefaultCorp-ls.ActualOverdueCorp," 
				  + "ls.PayInte+ls.PayInnerInte+ls.PayOutInte-ls.ActualInte-ls.ActualInnerInte-ls.ActualOutInte-ls.PAYOVERDUECORPINTE+" 
				  +	"decode(ls.PayOverDueCorpInte,0,0,ls.OVERDUECORPINTEBASE/10000),"
				  + "decode(ls.PayInnerInteFine+ls.PayOutInteFine,0,0,ls.INTEFINEBASE/10000)-ls.ActualInnerInteFine-ls.ActualOutInteFine,"
				  +	"ls.WaitOverdueCorpInte,ls.GracePeriod,ls.OrgID,lb.LoanAccNo,lb.Normalbalance+lb.OverdueBalance" 
				  + " from Loanback_Status ls,Loan_Balance lb Where lb.PutOutNo=ls.PutOutNo and ls.PayOffFlag='0' and ls.paydate<'"+deductDate+"')";

		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		psInsertSql.addBatch();
		psInsertSql.executeBatch();
		psInsertSql.close();
	}
	
	/*
	 * ȡ�üƻ�
	 */
	public void BatchLastPlan(String CreateDate) throws Exception{
		String LastCreateDate = DateTools.getRelativeDate(CreateDate,AccountConstants.TERM_UNIT_DAY, -1);
		String insertSql = "insert into PreDeduct_Data(PreDeductDate,PutOutNo,Sterm,AheadNum,PayDate," +
				"PayCorp,PayInte,PayFine,WaitInte,GracePeriod,OrgID,LoanAccNo,Balance,PayFare) " +
				"(select '"+CreateDate+"',PutOutNo,Sterm,AheadNum,PayDate," +
				"PayCorp,PayInte,PayFine,WaitInte,GracePeriod,OrgID,LoanAccNo,Balance,PayFare" +
				" from PreDeduct_Data Where PreDeductDate='"+LastCreateDate+"')";

		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		psInsertSql.addBatch();
		psInsertSql.executeBatch();
		psInsertSql.close();
	}
	/*
	 * ���������Ļ���ƻ�
	 */
	public void BatchCreatePlan(String CreateDate) throws Exception{
		int dealNum = 0;
		
		String insertSql = "insert into PreDeduct_Data(PreDeductDate,PutOutNo,Sterm,AheadNum,PayDate," +
				"PayCorp,PayInte,PayFine,GracePeriod,OrgID,LoanAccNo,Balance) " +
				"Values(?,?,?,?,?," +
				"?,?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = "Select PutOutNo,MainReturnType,ReturnType,ReturnPeriod,GainAmount," 
				  + "MaturityDate,BeginDate,MonthEndFlag,LastInteDate,NextPayDate," 
				  + "CTerm,SCTerm,STerm,AheadNum,LastTerm," 
				  + "GainCyc,MonthPay,RateCode,BaseDays,ExecuteRate," 
				  + "NormalBalance,HoldBalance,CalcMaturityDate,GracePeriod,OrgID," 
				  +	"RateAlterDate,LoanAccNo,OverdueBalance,"
				  +	"PayInte+PayInnerInte+PayOutInte+PayInnerInteFine+PayOutInteFine+OverdueBalance as PayMoney " 
				  + " From Loan_Balance Where NextPayDate = '"+CreateDate+"' And LoanStatus in('0','1','4','5') And NormalBalance>0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();		
		while(rs.next()){
			LoanBalance loanBalance = new LoanBalance();
			loanBalance.setPutOutNo(rs.getString("PutOutNo"));
			loanBalance.setMainReturnType(rs.getString("MainReturnType"));
			loanBalance.setReturnType(rs.getString("ReturnType"));
			loanBalance.setReturnPeriod(rs.getString("ReturnPeriod"));
			loanBalance.setGainAmount(rs.getDouble("GainAmount"));
			loanBalance.setMaturityDate(rs.getString("MaturityDate"));
			loanBalance.setBeginDate(rs.getString("BeginDate"));
			loanBalance.setMonthEndFlag(rs.getString("MonthEndFlag"));
			loanBalance.setLastInteDate(rs.getString("LastInteDate"));
			loanBalance.setNextPayDate(rs.getString("NextPayDate"));
			loanBalance.setSTerm(rs.getInt("STerm"));
			loanBalance.setCTerm(rs.getInt("CTerm"));
			loanBalance.setSCTerm(rs.getInt("SCTerm"));
			loanBalance.setAheadNum(rs.getInt("AheadNum"));
			loanBalance.setLastTerm(rs.getInt("LastTerm"));
			loanBalance.setGainCyc(rs.getInt("GainCyc"));
			loanBalance.setMonthPay(rs.getDouble("MonthPay"));
			loanBalance.setRateCode(rs.getString("RateCode"));
			loanBalance.setBaseDays(rs.getInt("BaseDays"));
			loanBalance.setExecuteRate(rs.getDouble("ExecuteRate"));
			loanBalance.setNormalBalance(rs.getDouble("NormalBalance"));
			loanBalance.setHoldBalance(rs.getDouble("HoldBalance"));
			loanBalance.setCalcMaturityDate(rs.getString("CalcMaturityDate"));
			loanBalance.setGracePeriod(rs.getInt("GracePeriod"));
			loanBalance.setOrgID(rs.getString("OrgID"));
			loanBalance.setRateAlterDate(rs.getString("RateAlterDate"));
			loanBalance.setLoanAccNo(rs.getString("LoanAccNo"));
			loanBalance.setOverDueBalance(rs.getDouble("OverdueBalance"));
			
			double PayMoney = rs.getDouble("PayMoney");
			RepaymentSchedule repaymentSchedule = new RepaymentSchedule();			
			loanBalance.initLoanRateAlter(connection);
			if("22".equals(loanBalance.getMainReturnType())){
				repaymentSchedule=setPreDeductData(loanBalance,CreateDate,connection);
			}else{
				RepaymentType repaymentType = RepayTypeConfig.getRepaymentType(loanBalance.getReturnType());
				repaymentSchedule = repaymentType.getRepayScheduleEngine().getRepaymentSchedule(loanBalance);
			}
			psInsertSql.setString(1, CreateDate);
			psInsertSql.setString(2, loanBalance.getPutOutNo());
			psInsertSql.setInt(3, repaymentSchedule.getSeqID());
			psInsertSql.setInt(4, 0);
			psInsertSql.setString(5, CreateDate); 
			psInsertSql.setDouble(6, repaymentSchedule.getRepayCorpus());
			psInsertSql.setDouble(7, repaymentSchedule.getRepayInterest());
			psInsertSql.setDouble(8, 0.0);
			
			if(PayMoney>0) psInsertSql.setInt(9, 0);
			else psInsertSql.setInt(9, loanBalance.getGracePeriod());
			
			psInsertSql.setString(10, loanBalance.getOrgID());
			psInsertSql.setString(11, loanBalance.getLoanAccNo());
			psInsertSql.setDouble(12, NumberTools.round(loanBalance.getNormalBalance()+loanBalance.getOverDueBalance(),AccountConstants.MONEY_PRECISION));
			psInsertSql.addBatch();
			dealNum++;
						
			if (dealNum>=commitNum){
				dealNum=0;
				psInsertSql.executeBatch();		
			}
		}
		rs.getStatement().close();
		psInsertSql.executeBatch();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}
	//������㵱��Ԥ���۵�����
	public RepaymentSchedule setPreDeductData(LoanBalance loanBalance,String sDeductDate,Connection Conn) throws Exception{
		RepaymentSchedule repaymentSchedule = new RepaymentSchedule();
		String sReturnMethod="",sEndDate="",sReturnPeriod="",realMaturityDate="";
		double dsum=0d;
		double monthPay = 0d;
		realMaturityDate=loanBalance.getMaturityDate();//��ʵ������
		//�����������״̬	
		String sql="select returnmethod,EndDate,ReturnPeriod,BusinessSum,MonthPay,BeginDate from LOAN_RPT_PLAN where ObjectNo='"+loanBalance.getPutOutNo()+"' " +
				   " and EndDate>='"+sDeductDate+"' and status='20' order by EndDate";
		
		PreparedStatement psSql = Conn.prepareStatement(sql);
		ResultSet rs = psSql.executeQuery();
		if(rs.next()){
			sReturnMethod=DataConvert.toString(rs.getString("returnmethod"));
			sEndDate=DataConvert.toString(rs.getString("EndDate"));
			sReturnPeriod=DataConvert.toString(rs.getString("ReturnPeriod"));
			dsum= rs.getDouble("BusinessSum");
			monthPay = rs.getDouble("MonthPay");
			
			loanBalance.setReturnType(sReturnMethod);
			IRepayScheduleEngine repayScheduleEngine = RepayTypeConfig.getRepaymentType(loanBalance.getReturnType()).getRepayScheduleEngine();
			loanBalance.setMonthPay(monthPay);
			
			loanBalance.setEndDate(sEndDate);
			loanBalance.setCurDate(sDeductDate);
			
			if(sDeductDate.equals(sEndDate)){
				String sql3 = "select BusinessSum from LOAN_RPT_PLAN where ObjectNo='"+loanBalance.getPutOutNo()+"'" +
						" and EndDate>'"+sEndDate+"' and status='20' order by EndDate";
				PreparedStatement psSql3 = Conn.prepareStatement(sql3);
				ResultSet rsSql3 = psSql3.executeQuery();
				double sum = 0d;
				while(rsSql3.next()){
					double businessSum = rsSql3.getDouble("BusinessSum");
					sum+=businessSum;
				}
				loanBalance.setHoldBalance(sum);
				rsSql3.close();
				psSql3.close();
			}
			
			repaymentSchedule=repayScheduleEngine.getRepaymentSchedule(loanBalance);
			
		}
		rs.close();
		
		return repaymentSchedule;
	}
	
	/*
	 * �㷣Ϣ��ֵ  DeductDate ��������  CreateDate ��������
	 */
	public void BatchUpdatePlan(String CreateDate) throws Exception{
		double PayCorp = 0.0;
		double PayInte = 0.0;
		double WaitInte = 0.0;
		double PayInteAdd = 0.0;
		double PayFineAdd = 0.0;
		
		double FineRate = 0.0;
		String PutOutNo;
		String CorpFineFlag;
		String InteFineFlag;
		String LoanAccNo,NextPayDate,LastInteDate,MaturityDate,BeginDate;
		String MonthEndFlag,ReturnType,ReturnPeriod,PayDate;
		int GracePeriod=0;;
		
		ArrayList<String> fundList = new ArrayList<String>();
		fundList = TransDayInte.getFundList(CreateDate,connection);

		int Sterm = 0;
		int AheadNum = 0;
		
		String selectSql = "select a.PutOutNo as PutOutNo,a.Sterm as Sterm,a.AheadNum as AheadNum," +
				"a.PayCorp as PayCorp,a.PayInte as PayInte,a.WaitInte as WaitInte," +
				"a.PayDate as PayDate,a.GracePeriod as GracePeriod," +
				"lb.FineRate as FineRate,lb.CorpFineFlag as CorpFineFlag," +
				"lb.NextPayDate as NextPayDate,lb.LastInteDate as LastInteDate," +
				"lb.MaturityDate as MaturityDate,lb.BeginDate as BeginDate,lb.MonthEndFlag as MonthEndFlag," +
				"lb.ReturnType as ReturnType,lb.ReturnPeriod as ReturnPeriod," +
				"lb.InteFineFlag as InteFineFlag,lb.LoanAccNo as LoanAccNo from loan_balance lb," +
				"(select PutOutNo,Sterm,AheadNum,max(PayDate) as PayDate,min(GracePeriod) as GracePeriod," +
				"Sum(PayCorp) as PayCorp,Sum(PayInte) as PayInte," +
				"sum(WaitInte) as WaitInte " +
				"from PreDeduct_Data where PreDeductDate = '"+CreateDate+"' " +
				"And to_date('"+CreateDate+"','yyyy/mm/dd')-to_date(Paydate,'yyyy/mm/dd')>GracePeriod " +				
				"group by PutOutNo,Sterm,AheadNum) a where lb.putoutno=a.putoutno";
		
		String updateSql = "Update PreDeduct_Data Set PayInte=PayInte+?,PayFine=PayFine+?,WaitInte=WaitInte+? " +
				" Where PreDeductDate=? And PutOutNo=? And STerm=? And AheadNum=?";
		String updateSql1 = "Update PreDeduct_Data Set PayInte=PayInte+?,PayFine=PayFine+?,WaitInte=0 " +
		" Where PreDeductDate=? And PutOutNo=? And STerm=? And AheadNum=?";

		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		PreparedStatement psUpdateSql1 = connection.prepareStatement(updateSql1);
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			PutOutNo = rs.getString("PutOutNo");
			Sterm = rs.getInt("Sterm");
			AheadNum = rs.getInt("AheadNum");
			PayCorp = rs.getDouble("PayCorp");
			PayInte = rs.getDouble("PayInte");
			WaitInte = rs.getDouble("WaitInte"); 
			FineRate = rs.getDouble("FineRate");
			CorpFineFlag = rs.getString("CorpFineFlag");
			InteFineFlag = rs.getString("InteFineFlag");
			NextPayDate = rs.getString("NextPayDate");
			LastInteDate = rs.getString("LastInteDate");
			MaturityDate = rs.getString("MaturityDate");
			BeginDate = rs.getString("BeginDate");
			MonthEndFlag = rs.getString("MonthEndFlag");
			ReturnType = rs.getString("ReturnType");
			ReturnPeriod = rs.getString("ReturnPeriod");
			LoanAccNo = rs.getString("LoanAccNo");
			PayDate = rs.getString("PayDate");
			GracePeriod = rs.getInt("GracePeriod");
			
			if(fundList.indexOf(LoanAccNo)>=0) continue;//���������ļ�1��֮�󲻼Ʒ�Ϣ
			
			PayInte = NumberTools.round(PayInte,AccountConstants.MONEY_PRECISION);
			WaitInte = NumberTools.round(WaitInte,AccountConstants.MONEY_PRECISION);
			
			double days= 0.0;
			if(GracePeriod==DateTools.getDays(PayDate, CreateDate))  days=GracePeriod;
			else days=1.0;
			
			PayInteAdd = 0.00;
			PayFineAdd = 0.00;
			if(CorpFineFlag.equals(AccountConstants.YES))
				PayInteAdd = NumberTools.round(PayCorp * FineRate*days/10000,6);
			
			if(InteFineFlag.equals(AccountConstants.YES))
				PayFineAdd = NumberTools.round((PayInte-WaitInte) * FineRate*days/10000 ,6);
			
			//�жϽ�ת������Ϣ
			//�жϽ�ת������Ϣ				
			if(NextPayDate.equals(CreateDate)){
				psUpdateSql1.setDouble(1, PayInteAdd);
				psUpdateSql1.setDouble(2, PayFineAdd);
				psUpdateSql1.setString(3, CreateDate);
				psUpdateSql1.setString(4, PutOutNo);
				psUpdateSql1.setInt(5, Sterm);
				psUpdateSql1.setInt(6, AheadNum);		
				psUpdateSql1.addBatch();
			}else if(MaturityDate.compareTo(CreateDate)<0){
				RepaymentType repaymentType = RepayTypeConfig.getRepaymentType(ReturnType);
				IRepayScheduleEngine repayScheduleEngine=repaymentType.getRepayScheduleEngine();
				LoanBalance loanBalance = new LoanBalance();
				loanBalance.setLastInteDate(LastInteDate);
				loanBalance.setReturnType(ReturnType);
				loanBalance.setReturnPeriod(ReturnPeriod);
				loanBalance.setBeginDate(BeginDate);
				loanBalance.setMaturityDate("2999/12/31");
				loanBalance.setMonthEndFlag(MonthEndFlag);
								
				if(CreateDate.equals(repayScheduleEngine.calNextPayDate(loanBalance))){
					psUpdateSql1.setDouble(1, PayInteAdd);
					psUpdateSql1.setDouble(2, PayFineAdd);
					psUpdateSql1.setString(3, CreateDate);
					psUpdateSql1.setString(4, PutOutNo);
					psUpdateSql1.setInt(5, Sterm);
					psUpdateSql1.setInt(6, AheadNum);		
					psUpdateSql1.addBatch();
				}
			}else{
				psUpdateSql.setDouble(1, PayInteAdd);
				psUpdateSql.setDouble(2, PayFineAdd);
				psUpdateSql.setDouble(3, PayInteAdd);
				psUpdateSql.setString(4, CreateDate);
				psUpdateSql.setString(5, PutOutNo);
				psUpdateSql.setInt(6, Sterm);
				psUpdateSql.setInt(7, AheadNum);		
				psUpdateSql.addBatch();
			}
			dealNum++;
			if (dealNum>=commitNum){
				dealNum = 0;
				psUpdateSql1.executeBatch();
				psUpdateSql.executeBatch();			
			}
		}
		psUpdateSql1.executeBatch();
		psUpdateSql.executeBatch();	
		rs.getStatement().close();
		psUpdateSql1.close();
		psUpdateSql.close();
		psSelectSql.close();
	}
	
	/*
	 * add by 2010/03/02
	 * �˻����������Ԥ���۴���
	 * */
	
	//���뵱ǰ��Ƿ�˻���������Ϣ
	private void initFareInfo() throws SQLException
	{
		dealNum = 0;
		String sUpdateFareAmountSql = " Update PreDeduct_Data Set PayFare = ? " +
				" Where PreDeductDate=? And PutOutNo=? And PayDate=? And AheadNum=0 ";
		PreparedStatement psUpdateFareAmountSql = connection.prepareStatement(sUpdateFareAmountSql);
		
		String sSelectFareSql = " select PutOutNo,PayDate,PayMoney-ActualMoney as FareAmount from fare_detail where OffFlag = '0' ";
		PreparedStatement psSelectFare = connection.prepareStatement(sSelectFareSql);
		ResultSet rs = psSelectFare.executeQuery();
		while(rs.next())
		{
			psUpdateFareAmountSql.setDouble(1,rs.getDouble("FareAmount"));
			psUpdateFareAmountSql.setString(2,deductDate);
			psUpdateFareAmountSql.setString(3,rs.getString("PutOutNo"));
			psUpdateFareAmountSql.setString(4,rs.getString("PayDate"));
			psUpdateFareAmountSql.addBatch();
			dealNum++;
			
			if (dealNum>=commitNum){
				dealNum = 0;
				psUpdateFareAmountSql.executeBatch();	
			}
		}
		psUpdateFareAmountSql.executeBatch();
		psUpdateFareAmountSql.close();
		rs.close();		
	}
	
	//���µ��յ��˻���������Ϣ
	private void updateFareInfo(String CreateDate) throws SQLException
	{
		dealNum = 0;
		String sUpdateFareAmountSql = " Update PreDeduct_Data Set PayFare = ? " +
				" Where PreDeductDate=? And PutOutNo=? And PayDate=? And AheadNum=0 ";
		PreparedStatement psUpdateFareAmountSql = connection.prepareStatement(sUpdateFareAmountSql);
		
		String sSelectFareSql = " select lb.putoutno,lr.amount from loan_balance lb,loanbalance_relative lr " +
				" where  lb.putoutno = lr.putoutno  and lb.nextpaydate = '"+CreateDate+"' and lb.loanStatus in ('0','1','4','5') and lr.amount > 0 ";
		PreparedStatement psSelectFare = connection.prepareStatement(sSelectFareSql);
		ResultSet rs = psSelectFare.executeQuery();
		while(rs.next())
		{
			psUpdateFareAmountSql.setDouble(1,rs.getDouble("amount"));
			psUpdateFareAmountSql.setString(2,CreateDate);
			psUpdateFareAmountSql.setString(3,rs.getString("putoutno"));
			psUpdateFareAmountSql.setString(4,CreateDate);
			psUpdateFareAmountSql.addBatch();
			dealNum++;
			
			if (dealNum>=commitNum){
				dealNum = 0;
				psUpdateFareAmountSql.executeBatch();	
			}
		}
		psUpdateFareAmountSql.executeBatch();
		psUpdateFareAmountSql.close();
		rs.close();	
	}
	
	/*
	 * add end 
	 * */
}
