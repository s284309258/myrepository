package com.amarsoft.app.datax.gci.deductacc;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.ledger.UpdateLedgerGeneral;

public class ConsultInte extends CommonExecuteUnit{

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ���������Ϣ����Ϣ......");
				calcThreadNum(); 
				multiThread("com.amarsoft.app.datax.gci.deductacc.thread.ConsultInteThread");
				if(errorThreadNumber > 0)
				{
					throw new Exception("����"+errorThreadNumber+"���̳߳����쳣��������־��");
				}
				
				//���·���˫���Ŀ�����ֵ
				UpdateLedgerGeneral.BatchLedgerGeneral(connection);
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
