package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchUpdateBillStatus extends CommonExecuteUnit {

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				
				logger.info("ɾ��δ���˵���.....");
				updateBillStatus();
				logger.info("ɾ��δ���˵�����ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void updateBillStatus() throws SQLException
	{
		String updateSql = " delete from Back_Bill where  BillStatus = '0' ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		psUpdateSql.execute();
		psUpdateSql.close();
		
		String deleteSql = " DELETE FROM loanrepay_info WHERE status = '0' ";
		PreparedStatement psDeleteSql = connection.prepareStatement(deleteSql);
		psDeleteSql.execute();
		psDeleteSql.close();
		//ɾ����������Ϊ���˵�����
		String deleteAcctFeeDetailSql = " DELETE FROM Acct_Fee_Detail WHERE status = '0' and ObjectType = 'SWRushFeePayApply'";
		PreparedStatement psDeleteAcctFeeDetail = connection.prepareStatement(deleteAcctFeeDetailSql);
		psDeleteAcctFeeDetail.execute();
		psDeleteAcctFeeDetail.close();
	}
	
}
