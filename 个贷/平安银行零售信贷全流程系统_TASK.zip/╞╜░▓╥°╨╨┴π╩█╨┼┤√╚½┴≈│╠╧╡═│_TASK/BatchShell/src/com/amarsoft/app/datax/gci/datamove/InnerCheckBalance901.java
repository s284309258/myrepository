package com.amarsoft.app.datax.gci.datamove;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class InnerCheckBalance901 extends CommonExecuteUnit{
	
	private int dealnum;
	private int icount;
	private int commitNum;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("...............У��901����Ƿ�ƽ��.............");
					CheckInTableData();
					logger.info("...............У��901����Ƿ�ƽ�����.............");
				}else{
					logger.info("...............���첻��Ҫ����.............");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			
			clearResource();
			return unitStatus;
		} 
	}
	
	/**
	 * У����������Ƿ���ƽ��
	 * @throws SQLException 
	 */
	public  void CheckInTableData() throws SQLException{
		String al="select dd.putoutno,dd.C as newCbalance,dd.D as newDbalance,ff.c as oldCbalance,ff.d as oldDbalance "
				+"	from (select lg.putoutno,"
				+"	 sum(lg.creditbalance) as C,"
				+"	 sum(lg.debitbalance) as D "
				+"	 from ledger_general lg "
				+"	 where lg.subjectno not like '6%' "
				+"	 group by lg.putoutno) dd,        "
				+"	 (select lg.putoutno, "
				+"	 sum(lg.creditbalance) as C, "
				+"	 sum(lg.debitbalance) as D "
				+"	  from qy_ledger_general_bak901 lg "
				+"	  where  lg.subjectno not like '7%' "
				+"	 group by lg.putoutno) ff "
				+"	 where dd.putoutno=ff.putoutno "
				+"	 and (dd.C<>ff.C or dd.D<>ff.D) ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			logger.info("..���"+rs.getString("putoutno")+" ���ڽ����ƽ���´������"+rs.getString("newCbalance")+" �½跽��� "+rs.getString("newDbalance")+" �ɴ������"+rs.getString("oldCbalance")+" �ɽ跽���"+rs.getString("oldDbalance")+" ");
		}
		rs.close();
	}
	
}
