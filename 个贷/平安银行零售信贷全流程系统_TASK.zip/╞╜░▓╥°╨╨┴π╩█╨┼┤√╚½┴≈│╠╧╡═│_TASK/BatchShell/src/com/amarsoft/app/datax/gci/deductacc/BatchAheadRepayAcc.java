package com.amarsoft.app.datax.gci.deductacc;


import com.amarsoft.account.Deal.TransScheduler;
import com.amarsoft.account.ledger.UpdateLedgerGeneral;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchAheadRepayAcc extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				TransScheduler transScheduler = new TransScheduler(connection);
				logger.info("��ʼ������ǰ�������......");
				transScheduler.BatchTransScheduler("2002",deductDate);
				logger.info("������ǰ���������ɣ�");
				
				//���·���˫���Ŀ�����ֵ
				UpdateLedgerGeneral.BatchLedgerGeneral(connection);
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
		/*finally{
			clearResource();
			return unitStatus;
		}*/
	}
}
