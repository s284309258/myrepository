package com.amarsoft.app.datax.gci;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.ledger.CreateLedger;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.LedgerGeneral;

public class BatchTransProvider {

	ArrayList<LedgerDetail> LedgerDetailList = new ArrayList<LedgerDetail>();
	LedgerDetail Ld = new LedgerDetail();
	
	public void LedgerDeal(LedgerDetail ledgerDetail,LedgerGeneral ledgerGeneral,
			HashMap<String,AttributeField> inputPara,HashMap<String,String> LedgerSubjectHashMap) throws Exception{
		LedgerDetailList = CreateLedger.getLedgerList(inputPara,LedgerSubjectHashMap);			
		for(int k=0;k<LedgerDetailList.size();k++){
			Ld = LedgerDetailList.get(k);
			ledgerDetail.setSerialNo(Ld.getSerialNo());
			ledgerDetail.setPutOutNo(Ld.getPutOutNo());
			ledgerDetail.setBillNo(Ld.getBillNo());
			ledgerDetail.setHandStatus(Ld.getHandStatus());
			ledgerDetail.setOccurDate(Ld.getOccurDate());
			ledgerDetail.setOccurTime(Ld.getOccurTime());
			ledgerDetail.setOrgID(Ld.getOrgID());
			ledgerDetail.setCurrency(Ld.getCurrency());					
			ledgerDetail.setTransID(Ld.getTransID());
			ledgerDetail.setSortID(Ld.getSortID());
			ledgerDetail.setSubjectNo(Ld.getSubjectNo());			
			ledgerDetail.setDebitAmt(Ld.getDebitAmt());
			ledgerDetail.setCreditAmt(Ld.getCreditAmt());
			ledgerDetail.InsertLedgerDetail();
			
			ledgerGeneral.setPutOutNo(Ld.getPutOutNo());
			ledgerGeneral.setAccountNo(Ld.getAccountNo());
			ledgerGeneral.setDebitBalance(Ld.getDebitAmt());
			ledgerGeneral.setCreditBalance(Ld.getCreditAmt());
			ledgerGeneral.UpdateLedgerGeneral();
		}
	}
	
	public void LedgerDeal(String RelativeBillNo,LedgerDetail ledgerDetail,LedgerGeneral ledgerGeneral,
			HashMap<String,AttributeField> inputPara,HashMap<String,String> LedgerSubjectHashMap) throws Exception{
		ledgerDetail.setBillNo(RelativeBillNo);
		ledgerDetail.setHandStatus("0");
		ledgerDetail.UpdateLedgerDetail();
		
		LedgerDetailList = CreateLedger.getLedgerList(inputPara,LedgerSubjectHashMap);			
		for(int k=0;k<LedgerDetailList.size();k++){
			Ld = LedgerDetailList.get(k);			
			ledgerGeneral.setPutOutNo(Ld.getPutOutNo());
			ledgerGeneral.setAccountNo(Ld.getAccountNo());
			ledgerGeneral.setDebitBalance(Ld.getDebitAmt());
			ledgerGeneral.setCreditBalance(Ld.getCreditAmt());
			ledgerGeneral.UpdateLedgerGeneral();
		}
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,String stringValue){
		AttributeField attributeField = new AttributeField(fieldName,stringValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,double doubleValue){
		AttributeField attributeField = new AttributeField(fieldName,doubleValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,int intValue){
		AttributeField attributeField = new AttributeField(fieldName,intValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,String stringValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,stringValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,double doubleValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,doubleValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,int intValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,intValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static double getDoubleInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return 0;
		else return inputPara.get(fieldName.toUpperCase()).getFieldDoubleValue();
	}
	
	public static String getStringInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return "";
		else return inputPara.get(fieldName.toUpperCase()).getFieldStringValue();
	}
	 
	public static int getIntInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return 0;
		else return inputPara.get(fieldName.toUpperCase()).getFieldIntegerValue();
	}
	
	public static boolean getSubjectPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return true;
		else return inputPara.get(fieldName.toUpperCase()).isFieldStatus();
	}
}
