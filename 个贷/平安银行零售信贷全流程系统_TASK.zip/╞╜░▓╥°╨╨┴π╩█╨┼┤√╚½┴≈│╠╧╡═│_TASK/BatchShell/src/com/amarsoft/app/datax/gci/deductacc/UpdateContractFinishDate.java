package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class UpdateContractFinishDate extends CommonExecuteUnit{
	
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				updateFinishDate();
				logger.info("�����Ⱥ�ͬ");
				updateFreezeFlagDJ();
				logger.info("�����Ⱥ�ͬ���");
				
				logger.info("�����Ⱥ�ͬ");
				updateFreezeFlagJD();
				logger.info("�����Ⱥ�ͬ���");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}

	public void updateFinishDate() throws SQLException
	{
		String updateSql = " update Business_Contract set FinishDate = ? where SerialNo = ? and FinishDate is null ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectTempSql = " select count(PutOutNo) as icount from Loan_Balance where ContractSerialNo = ? and FinishDate is null ";
		PreparedStatement psSelectTempSql = connection.prepareStatement(selectTempSql);
		
		String selectSql = " select lb.contractserialno, bc.BusinessType from Loan_Balance lb, Business_Contract bc where lb.ContractSerialNo = bc.SerialNo "+
							" AND (((bc.putouttype <> '040' OR (BC.PUTOUTTYPE = '040' AND BC.CYCLEFLAG = '0') or bc.putouttype is null) AND LB.FINISHDATE = '"+deductDate+"' and "+
							" ((BC.Businesstype not in ('1110080', '1160050','1160060')) OR (BC.FinishDate IS NULL and ((BC.Businesstype in ('1110080', '1160050','1160060') AND "+
							" BC.Maturitydate <= '"+deductDate+"') OR (BC.Businesstype in ('1160050','1160060') AND (BC.CycleFlag = '0' OR BC.CYCLERATIO = 0)))))) OR "+
							" (bc.putouttype = '040' AND BC.CYCLEFLAG = '1' AND BC.Maturitydate <= '"+deductDate+"' AND BC.FinishDate IS NULL)) ";
		
		//����sql��������sql�����Ż����Ӷ�����
		
		/*
		String selectSql = " select lb.ContractSerialNo, bc.BusinessType from Loan_Balance lb, Business_Contract bc where lb.ContractSerialNo = bc.SerialNo AND " +
			" (((bc.putouttype <>'040' OR (BC.PUTOUTTYPE='040' AND BC.CYCLEFLAG='0')) and BC.Businesstype not in ('1110080', '1160050') AND LB.FINISHDATE = '"+deductDate+"') " +
			" OR ((bc.putouttype <>'040' OR (BC.PUTOUTTYPE='040' AND BC.CYCLEFLAG='0')) and BC.Businesstype in ('1110080', '1160050') AND BC.Maturitydate <= '"+deductDate+"' AND LB.FINISHDATE <= '"+deductDate+"' AND BC.FinishDate IS NULL) " +
			" OR ((bc.putouttype <>'040' OR (BC.PUTOUTTYPE='040' AND BC.CYCLEFLAG='0')) and BC.Businesstype = '1160050' AND (BC.CycleFlag = '0' OR BC.CYCLERATIO = 0) AND  LB.FINISHDATE <= '"+deductDate+"' AND BC.FinishDate IS NULL) " +
			" OR (bc.putouttype ='040' AND BC.CYCLEFLAG='1' AND BC.Maturitydate <= '"+deductDate+"' AND BC.FinishDate IS NULL))";
		*/
		
		/*
		String selectSql = " select lb.ContractSerialNo,bc.BusinessType from Loan_Balance lb,Business_Contract bc " +
		   " where  lb.ContractSerialNo = bc.SerialNo  AND ((BC.Businesstype not in('1110080','1160050') AND  LB.FINISHDATE = '"+deductDate+"') " +
		   " OR (BC.Businesstype in('1110080','1160050') AND  BC.Maturitydate <= '"+deductDate+"' AND  LB.FINISHDATE <= '"+deductDate+"' AND BC.FinishDate IS NULL) " +
		   " OR (BC.Businesstype = '1160050' AND  (BC.CycleFlag='0' OR BC.CYCLERATIO=0) AND  LB.FINISHDATE <= '"+deductDate+"' AND BC.FinishDate IS NULL)) ";
		*/
		
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			int icount = 0;
			
			psSelectTempSql.setString(1,rs.getString("ContractSerialNo"));
			ResultSet rsTemp = psSelectTempSql.executeQuery();
			if(rsTemp.next())
			{
				icount = rsTemp.getInt("icount");
			}
			rsTemp.close();
			
			if(icount>0||rs.getString("BusinessType").equals("1160010"))
			{
				continue;
			}
			
			psUpdateSql.setString(1,deductDate);
			psUpdateSql.setString(2,rs.getString("ContractSerialNo"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"������!");
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		rs.close();
		psSelectTempSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"������!");
	}
	//��һ�ʴ���������Ҹÿͻ��й����Ķ�Ⱥ�ͬ����ÿͻ��������ж���Զ�����
	public void updateFreezeFlagDJ() throws SQLException
	{
		String updateSql = " update Business_Contract set FreezeFlag ='2'  where serialno in " +
				"(select serialno from business_contract where CustomerID = ? and putouttype='030' ) and FreezeFlag='1' ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		
		String selectSql = " select distinct lb.CustomerID as CustomerID from loan_balance lb where lb.maturitydate<='"+lastDate+"' and  "+
				 " lb.loanstatus in('0','1','4','5') and exists(select '1' from business_contract bc where bc.customerid = lb.customerid and bc.putouttype='030' )";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String customerID = DataConvert.toString(rs.getString("CustomerID"));
			
			psUpdateSql.setString(1,customerID);
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"������!");
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		rs.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"������!");
	}
	
	//�ÿͻ��������д���������ڣ���ÿͻ��������ж�Ȼָ�����
	public void updateFreezeFlagJD() throws SQLException
	{
		String updateSql = " update Business_Contract set FreezeFlag ='1'  where serialno in " +
				"(select serialno from business_contract where CustomerID = ? and putouttype='030' and maturitydate>='"+deductDate+"' )  ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		//���������һ��Ļ���ƻ�����������������
		String selectSql = " select count(*) as sum from loan_balance lb where  " +
				" lb.customerid = ? and exists (select '1' from loanback_status ls where " +
				" ls.putoutno = lb.putoutno and ls.payoffflag ='0' and ls.paydate<='"+deductDate+"')";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		//δ���ڵĶ�ȲŴ���
		String sql = "select distinct bc.CustomerID as CustomerID from business_contract bc where  bc.putouttype ='030' and bc.FreezeFlag ='2'  and bc.maturitydate>='"+deductDate+"'";
		PreparedStatement psSql = connection.prepareStatement(sql);
		int sum = 0;
		ResultSet rs = psSql.executeQuery();
		while(rs.next())
		{
			String customerID = DataConvert.toString(rs.getString("CustomerID"));
			
			psSelectSql.setString(1,customerID);
			ResultSet rsSelect = psSelectSql.executeQuery();
			while(rsSelect.next()){
				sum = rsSelect.getInt("sum");
			}
			rsSelect.close();
			if(sum>0) continue;//������������ڵģ��򲻴���
			psUpdateSql.setString(1,customerID);
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"������!");
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		rs.close();
		psSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"������!");
	}
	
}
