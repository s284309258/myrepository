package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Vector;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class VSettleFileChange extends CommonExecuteUnit{

	private String s = "";
    private String s2 = "";
    private int intCountNo = 0;
	private String path;
	private String sCheckLine;
	private String NASUrl;
	private String sInputFileUrl;
	private String sInputFileName;
	
	@Override
	public int execute() {
		try
		{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("����V+�����ļ�����.......");
				deleteFirstLine();
				logger.info("V+�����ļ�������ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}
		catch(Exception e){
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void deleteFirstLine() throws Exception
	{
		NASUrl = ARE.getProperty("NASUrl");
		sInputFileUrl = getProperty("InputFileUrl");
		sInputFileName = getProperty("InputFileName");
		String sDate = StringFunction.replace(deductDate,"/","");
		sInputFileUrl = StringFunction.replace(sInputFileUrl,"{$CurrentDate}",sDate);
		
		path = NASUrl+sInputFileUrl+sInputFileName;
		
		File file = new File(path);
		if(!file.exists())
		{
			throw new Exception("�ļ������ڣ�");
		}
		
		if(checkFileIsNull(file))
		{
			logger.info("���ļ�Ϊ���ļ�");
		}
		else
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String sLine;
			
			try{
		        
		        
		        Vector<String> vector = new Vector<String>();
		        Vector<String> vector2 = new Vector<String>();
		        
		        while((sLine=br.readLine())!= null) {
		            vector.add(sLine);
		        }
		        for (int i = 0; i < vector.size(); i++) {
		        	sLine = (String)vector.get(i);
		            if (i == 0) {
		               continue;
		            } else {
		                vector2.add(sLine);
		            }
		            
		        }
		        PrintWriter pw = new PrintWriter(new FileWriter(path));
		        for (int i = 0; i < vector2.size(); i++) {
		            s2 = (String)vector2.get(i);
		            intCountNo++;
		            pw.println(s2);
		            pw.flush();
		        }
		        
		        System.out.println("OutPath is :"+path);
		        br.close();
		    }catch(IOException e){
		        System.out.println("File Create Error!");
		        e.printStackTrace();
		    }
		}
	}
	
	private boolean checkFileIsNull(File file) throws IOException
	{
		String sLine;
		BufferedReader reader = null;
		try
		{
			 reader = 
				new BufferedReader(
						new InputStreamReader(
										new FileInputStream(file)));
			if((sLine = reader.readLine())!= null)
			{
				if(reader.readLine()!= null)
				{
					return false;
				}
				else
				{
					sCheckLine = sLine;
					return true;
				}
			}
			else
			{
				return true;
			}
		}
		catch(IOException ex)
		{
			throw new IOException();
		}
		finally
		{
			if(reader!=null)
				reader.close();
		}
	}
}
