package com.amarsoft.app.datax.gci;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.amarsoft.task.TaskConstants;


/**
 * �������ݣ����з��͸�����,����������ݺ͵������ݣ�
 * ���ֱ�־ΪsFlag = this.getProperty("Flag")
 * "B2C"��ʾ�����и����ĵ�������ݣ���2���ļ������ݣ�
 * "UPDATE"��ʾ:���и����ĵĵ������ݣ���4���ļ������ݣ�
 * @author EX-ZHONGBING001
 *
 */
public class UpdateFBIT extends CommonExecuteUnit {

	
	private String sFlag ;
	private ArrayList putOutNoList;
	private int icount= 0;
	private int commitNum ;
	private int deductDataNum = 0;
	
	@Override
	public int execute() {
		
		
		try{
			String sInit = super.init();
			sFlag = this.getProperty("Flag");
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				if(!isTodayEx(sFlag))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
			else
			{
				putOutNoList = new ArrayList();
				preData();
				//�������з��͸����ĵ�����ļ�����
				if(sFlag.equals("B2C"))
					updateB2C();
				else
					//���и��������ṩ�Ŀɿ۽����ɵ�������
					if(sFlag.equals("UPDATE"))
					updateUp();
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void updateB2C() throws SQLException{
		
		//���·��Ա�����ۿ���Ϊ׼
		String sSql = "select lb.putoutno,"+
				      " (nvl(lb.normalbalance,0) + nvl(lb.overduebalance,0)) as Fund_Batch_Balance,"+
				      " (nvl((select repaycorpus from repay_plan where putoutno = lb.putoutno and repaydate = lb.nextpaydate),0) " +
				      "+ nvl(lb.overduebalance,0) + nvl(lb.payinte,0) +nvl(lb.payinnerinte,0) + nvl(lb.payoutinte,0) +nvl(lb.payinnerintefine,0) + nvl(lb.payoutintefine,0)+" +
				      "(nvl((select repayinterest from repay_plan where putoutno = lb.putoutno and repaydate = lb.nextpaydate),0)))as Fund_Batch_BusinessSum,"+
					  "( nvl((select repaycorpus from repay_plan where putoutno = lb.putoutno and repaydate = lb.nextpaydate),0)+ nvl(lb.overduebalance,0)) as Fund_Batch_Money,"+
				      "(nvl(lb.payinte,0) + nvl(lb.payinnerinte,0) + nvl(lb.payoutinte,0) -(nvl((select sum(payInteFine) " +
				      " from loanback_status ls where ls.payoffflag = '0' and ls.putoutno = lb.putoutno),0)) +"+
				      " (nvl((select repayinterest from repay_plan where putoutno = lb.putoutno and repaydate = lb.nextpaydate),0))) as Fund_Batch_Inte,"+
				      " (nvl((select sum(payInteFine) from loanback_status ls where ls.payoffflag = '0'and ls.putoutno = lb.putoutno),0) + lb.payinnerintefine + lb.payoutintefine) as Fund_Batch_Fine,"+
				      " '"+deductDate+"' as Fund_Batch_SendDate "+
				      " from loan_balance lb where lb.PutOutNo = ? and lb.LoanStatus in ('0', '1')";
		//ͣ�������·���һ���Ի���ı��οۿ����Դ�����������Ϣ����ϢΪ׼
		String sSql1 = "select lb.putoutno,"+
				       "(nvl(lb.normalbalance,0) + nvl(lb.overduebalance,0)) as Fund_Batch_Balance,"+
				       "(nvl(lb.normalbalance,0) + nvl(lb.overduebalance,0)  + nvl(lb.payinte,0) +"+
				       " nvl(lb.payinnerinte,0) + nvl(lb.payoutinte,0) +"+
				       " nvl(lb.payinnerintefine,0) + nvl(lb.payoutintefine,0)+(nvl((select sum(repayinterest)"+
				       " from repay_plan where putoutno = lb.putoutno and repaydate >= lb.nextpaydate),0)))as Fund_Batch_BusinessSum,"+
				       " (nvl(lb.normalbalance,0) + nvl(lb.overduebalance,0)) as Fund_Batch_Money,"+
				       " (nvl(lb.payinte,0) + nvl(lb.payinnerinte,0) + nvl(lb.payoutinte,0) -"+
				       " (nvl((select sum(payInteFine) from loanback_status ls where ls.payoffflag = '0' and ls.putoutno = lb.putoutno),0)) +"+
				       " (nvl((select sum(repayinterest) from repay_plan where putoutno = lb.putoutno and repaydate >= lb.nextpaydate),0))) as Fund_Batch_Inte,"+
				       " (nvl((select sum(payInteFine)from loanback_status ls where ls.payoffflag = '0'and ls.putoutno = lb.putoutno), 0) + lb.payinnerintefine + lb.payoutintefine) as Fund_Batch_Fine,"+
				       "'"+deductDate+"' as Fund_Batch_SendDate"+
					   "  from loan_balance lb where lb.PutOutNo = ? and lb.LoanStatus in ('0', '1')";
		//���¹�����廹�����ݱ�
		String upsSql =" update Fund_Batch_Info_Temp Ft set Ft.Fund_Batch_Balance = ?,Ft.Fund_Batch_Paysum = ?,"+
				       " Ft.Fund_Batch_Paybalance = ?, Ft.Fund_Batch_Payinte = ?, Ft.Fund_Batch_Payfine = ?, Ft.Fund_Batch_Senddate = ? "+
				       " where Ft.Fund_Batch_Putoutno = ? and Ft.Fund_Batch_Handdate = (select max(Fund_Batch_Handdate) from Fund_Batch_Info_Temp)";
		//��ȡ�廹����ʽ��1������2��ͣ�������£�3��һ����
		String checkSql = "select Fb.Fund_Batch_Returntype from Fund_Batch_Info_Temp Fb where Fb.Fund_Batch_Putoutno=? and Fb.Fund_Batch_Handdate = (select max(Fund_Batch_Handdate) from Fund_Batch_Info_Temp)";
		PreparedStatement psSelData = null;
		PreparedStatement psUpData = connection.prepareStatement(upsSql);
		PreparedStatement psCheckData = connection.prepareStatement(checkSql);
		ResultSet rs = null;
		for(int i = 0;i<putOutNoList.size();i++){
			String sPutOutNo = (String)putOutNoList.get(i);
			psCheckData.setString(1, sPutOutNo);
			ResultSet checkRs = psCheckData.executeQuery();
			while(checkRs.next()){
				String returnType = checkRs.getString("Fund_Batch_Returntype");
				if("1".equals(returnType)){
					//���»����ȡ������ۿ���
					psSelData = connection.prepareStatement(sSql);
				}
				else
					//�������ʽ��ȡ������ۿ���
					psSelData = connection.prepareStatement(sSql1);
			}
			checkRs.close();
			psSelData.setString(1, sPutOutNo);
			rs = psSelData.executeQuery();
			
			while (rs.next()){
				psUpData.setDouble(1, rs.getDouble("Fund_Batch_Balance"));
				psUpData.setDouble(2, rs.getDouble("Fund_Batch_BusinessSum"));
				psUpData.setDouble(3, rs.getDouble("Fund_Batch_Money"));
				psUpData.setDouble(4, rs.getDouble("Fund_Batch_Inte"));
				psUpData.setDouble(5, rs.getDouble("Fund_Batch_Fine"));
				psUpData.setString(6, rs.getString("Fund_Batch_SendDate"));
				psUpData.setString(7, sPutOutNo);
				
				psUpData.addBatch();
				   icount++;
		            deductDataNum++;
					if(deductDataNum>=commitNum){
						psUpData.executeBatch();
						deductDataNum=0;
					    logger.info("��ִ��"+icount+"����");
					}
			    }
					
			}
		psUpData.executeBatch();
		deductDataNum=0;		
		if(rs!=null) rs.close();
		if(psSelData!=null)psSelData.close();
		psUpData.close();
		
		
	}
	
	
	
	
	public void  updateUp()throws Exception{
		//���Ҹ����廹�����ʽ������
		String sSql = " select (select nvl(lb.normalbalance,0)+nvl(lb.overduebalance,0 )from loan_balance lb where lb.putoutno = ?)as Balance," +
				     " (nvl(bb.actualcurrentcorp, 0) + +nvl(bb.actualoverduecorp, 0)+ nvl(bb.actualinte,0) + nvl(bb.actualinnerinte,0) + nvl(bb.actualoutinte,0)+nvl(bb.actualinnerintefine,0)+nvl(bb.actualinnerintefine,0)) as ActualBusinessSum,"+
				     " (nvl(bb.actualcurrentcorp, 0) + +nvl(bb.actualoverduecorp, 0)) as ActualCorp,"+
				     " (nvl(bb.actualinte,0) + nvl(bb.actualinnerinte,0) + nvl(bb.actualoutinte,0) -nvl(bb.actualintefine,0)) as ActualInte,"+
				     " nvl(bb.actualintefine,0)+nvl(bb.actualinnerintefine,0)+nvl(bb.actualinnerintefine,0) as ActualInteFine,bb.accdate as AccDate "+
				     " from back_bill bb where bb.billtype = '90' and bb.putoutno = ?";
		//���±�
		String upsSql = " update Fund_Batch_Info_Temp Fb set Fb.Fund_Batch_Actualsum = ?,Fb.Fund_Batch_Actualbalance = ?,Fb.Fund_Batch_Actualinte    = ?,"+
				        " Fb.Fund_Batch_Actualfine  = ?,Fb.Fund_Batch_Piaaccdate    = ?, Fb.Fund_Batch_Balance = ? "+
				        " where Fb.Fund_Batch_Handdate = (select max(Fund_Batch_Handdate) from Fund_Batch_Info_Temp) and Fb.Fund_Batch_Putoutno = ?";
		PreparedStatement psSelData = connection.prepareStatement(sSql);
		PreparedStatement psUpData = connection.prepareStatement(upsSql);
		ResultSet rs = null;
		
		for(int i = 0 ;i < putOutNoList.size();i++){

			String sPutOutNo = (String)putOutNoList.get(i);
			psSelData.setString(1, sPutOutNo);
			psSelData.setString(2, sPutOutNo);
			rs = psSelData.executeQuery();
			
			while (rs.next()){
				psUpData.setDouble(1, rs.getDouble("ActualBusinessSum"));
				psUpData.setDouble(2, rs.getDouble("ActualCorp"));
				psUpData.setDouble(3, rs.getDouble("ActualInte"));
				psUpData.setDouble(4, rs.getDouble("ActualInteFine"));
				psUpData.setDouble(5, rs.getDouble("Balance"));
				psUpData.setString(6, rs.getString("AccDate"));
				psUpData.setString(7, sPutOutNo);
				
				psUpData.addBatch();
				   icount++;
		            deductDataNum++;
					if(deductDataNum>=commitNum){
						psUpData.executeBatch();
						deductDataNum=0;
					    logger.info("��ִ��"+icount+"����");
					}
			    }
		}
		
		psUpData.executeBatch();
		deductDataNum=0;
		if(rs!=null) rs.close();
		psSelData.close();
		psUpData.close();
						
	}
	
	//׼�����ݣ���Ҫ�ǲ��ҳ������˺�
	public ArrayList preData() throws SQLException{
		
		String sSql = "select Fund_Batch_PutOutNo from Fund_Batch_Info_Temp where Fund_Batch_HandDate = (select max(Fund_Batch_HandDate) from Fund_Batch_Info_Temp)";
		
		PreparedStatement psDeductData = connection.prepareStatement(sSql);
		ResultSet rs = psDeductData.executeQuery();
		
		while(rs.next()){
			
			putOutNoList.add(rs.getString("Fund_Batch_PutOutNo"));
		}
		
		rs.close();
		psDeductData.close();
		return null;
	}
	
	
	//�жϵ���Ӧ������ʲô�ļ�����Ϊ����ļ��͵����ļ�������ͬһ�࣬�����Ҫ�жϣ��жϱ�־�Ǳ�������ļ�����״̬��
	private boolean isTodayEx(String sFlag) throws SQLException
	{
		int dStatus = 0;
		String sql  = "select distinct(Fund_Batch_Status) from Fund_Batch_Info_Temp where Fund_Batch_HandDate = (select max(Fund_Batch_HandDate) from Fund_Batch_Info_Temp)";
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(sql);
		if(rs.next()){
			dStatus = rs.getInt("Fund_Batch_Status");
		}
		rs.close();
		st.close();
		if(sFlag.equals("BtoC"))
		{
			if(dStatus >=1)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sFlag.equals("UPDATE")){
			if(dStatus >=3)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
			return true;
	}
	
	

}
