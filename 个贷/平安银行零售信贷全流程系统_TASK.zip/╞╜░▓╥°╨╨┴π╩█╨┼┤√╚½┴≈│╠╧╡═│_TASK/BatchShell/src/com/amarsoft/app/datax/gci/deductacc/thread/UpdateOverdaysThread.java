package com.amarsoft.app.datax.gci.deductacc.thread;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.task.TaskConstants;

public class UpdateOverdaysThread extends BatchThread{

	
	int icount = 0;
	private int commitNum ;
	int dealNum = 0;
	
	public void run() {
		try {
			batchUpateOverdays();
			this.connection.commit();
			//�ɹ�ע���߳�
			mainProcess.threadLogOff( this, TaskConstants.ES_SUCCESSFUL);//���̳߳ɹ�ִ��
		} catch (Exception e) {
			e.printStackTrace();
			try {
				this.connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			// �̱߳����쳣���������ȱ����������󣬲�ע���߳�
			this.logger.error("�������������̡߳�" + this.getName() + "�������쳣��������������ʧ�ܣ���������ȳ��򱨸����...");
			mainProcess.threadLogOff(this, TaskConstants.ES_FAILED);//��ʧ�ܷ�ʽ�����߳�״̬
		} finally {
			this.close();
		}
		return;
	}
	
	
	public void batchUpateOverdays() throws SQLException, ParseException
	{
		commitNum=Integer.parseInt(this.mainProcess.getProperty("commitNum", "1"));
		int iOverDays = 0;  //��ǰ��������

		String updateSql = " update loanBalance_relative set OverDays=? where PutOutNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select LB.PutOutNo from Loan_Balance LB,LOANBALANCE_RELATIVE LR where LR.PutOutNo = LB.PutOutNo and (LB.FinishDate is null or subStr(LB.FinishDate,1,7) = '"+this.currentMonth+"') " +
						   " and MOD(Dbms_Rowid.Rowid_Relative_Fno(LR.ROWID)||Dbms_Rowid.Rowid_Block_Number(LR.ROWID),?) = ? ";
		
		String selectLoanBackStatusSql = "select PutOutNo,PayDate from LOANBACK_STATUS where PutOutNo = ? and aheadnum = 0 and PayOffFlag = '"+BatchConstant.PAYOFFFLAG_FALSE+"' and PayDate <= ? order by PayDate asc ";
		PreparedStatement psSelectLoanBackStatusSql = connection.prepareStatement(selectLoanBackStatusSql);
		
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		psSelectSql.setInt(1, this.mod);
		psSelectSql.setInt(2, this.modvalue);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//��ʼ���ñʴ�����������
			iOverDays = 0;
			psSelectLoanBackStatusSql.setString(1, rs.getString("PutOutNo"));
			psSelectLoanBackStatusSql.setString(2, this.deductDate);
			
			ResultSet rsLBS = psSelectLoanBackStatusSql.executeQuery();
			if(rsLBS.next())
			{
				int days = DateTools.getDays(rsLBS.getString("PayDate"),deductDate);
				if(iOverDays < days)
					iOverDays = days;
			}
			rsLBS.close();
			
			
			psUpdateSql.setInt(1,iOverDays);
			psUpdateSql.setString(2,rs.getString("PutOutNo"));
			psUpdateSql.addBatch();
			
			icount ++ ;
			dealNum ++;
			if(dealNum >= this.commitNum)
			{
				try
				{
					psUpdateSql.executeBatch();
					dealNum = 0;
					logger.info(this.getName()+"�Ѹ�����������"+icount+"����");
				}catch(SQLException ex)
				{
					logger.info(rs.getString("PutOutNo"));
					throw ex;
				}
			}
		}
		rs.close();
		
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		psSelectSql.close();
		psSelectLoanBackStatusSql.close();
		logger.info(this.getName()+"�ܹ�������������"+icount+"����");
	}
	
}
