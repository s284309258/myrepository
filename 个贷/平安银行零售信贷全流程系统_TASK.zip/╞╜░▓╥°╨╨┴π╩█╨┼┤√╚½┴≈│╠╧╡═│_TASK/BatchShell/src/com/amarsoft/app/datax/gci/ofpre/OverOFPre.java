package com.amarsoft.app.datax.gci.ofpre;

import java.sql.Statement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class OverOFPre extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				Statement stmt=connection.createStatement();
				stmt.execute("update Ploan_Setup set OFPreFlag='0' ");
				stmt.execute("update BATCHTASK_STATUS set DateFlag='1' where TargetName = 'Of_pre' ");
				stmt.close();
				logger.info("Ԥ����������ϣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
			
		}
		catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
