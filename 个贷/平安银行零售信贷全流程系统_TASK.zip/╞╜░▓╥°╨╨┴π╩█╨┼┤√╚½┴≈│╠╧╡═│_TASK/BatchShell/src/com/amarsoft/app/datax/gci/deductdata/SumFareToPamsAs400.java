package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;

public class SumFareToPamsAs400 extends CommonExecuteUnit {

	private int commitNum ;
	private int deductDateNum = 0;
	private int iSerialNo=0;

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initSerialNo();
				
				logger.info("���ۻ��������м����˻�������......");
				addSumFare();
				logger.info("���ۻ��������м����˻�������ִ����ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void addSumFare() throws SQLException, ParseException
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		String updateSql =" update PAMS_AS400 set PayAmount = PayAmount+? where PutOutNo = ? and AmountAttribute = '"+BatchConstant.AMOUNTATTRIBUTE_CUR+"' ";
		PreparedStatement psUpdateSql=connection.prepareStatement(updateSql);
		
		String updateSumFare = " update SumFare set DealFlag = ? where PutOutNo = ?  ";
		PreparedStatement psUpdateSumFare=connection.prepareStatement(updateSumFare);
		
		String sqlTemp="select count(*) as ncount from Pams_As400 where PutOutNo=? and AmountAttribute = '"+BatchConstant.AMOUNTATTRIBUTE_CUR+"' ";
		PreparedStatement psTemp = connection.prepareStatement(sqlTemp);
		
		
		String selectSql =" select lb.PutOutNo,sf.PayMoney,lb.OrgID,lb.Currency,lb.Deductaccno "
				  +" from SumFare sf,loan_balance lb  "
				  +" where sf.PutOutNo = lb.PutOutNo and DealFlag is null ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql); 
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psTemp.setString(1,rs.getString("PutOutNo"));
			if(isPutOutNoInPamsAs400(psTemp))
			{
				psUpdateSql.setDouble(1,rs.getDouble("PayMoney"));
				psUpdateSql.setString(2,rs.getString("PutOutNo"));
				psUpdateSql.addBatch();
			}
			
			
			psUpdateSumFare.setString(1,"0");
			psUpdateSumFare.setString(2,rs.getString("PutOutNo"));
			psUpdateSumFare.addBatch();
			
			deductDateNum++;
			if(deductDateNum>commitNum)
			{
				psUpdateSql.executeBatch();
				psUpdateSumFare.executeBatch();
				deductDateNum=0;
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSumFare.executeBatch();
		rs.getStatement().close();
		psUpdateSql.close();
		psUpdateSumFare.close();
		psSelectSql.close();
		psTemp.close();
	}
	
	public void initSerialNo() throws SQLException
	{
		String initSql = " select max(SerialNo) as SerialNo from PAMS_AS400 ";
		PreparedStatement psInitSql = connection.prepareStatement(initSql);
		ResultSet initRs = psInitSql.executeQuery();
		if(initRs.next())
		{
			iSerialNo = initRs.getInt("SerialNo");
		}
		initRs.close();
	}
	
	public String createNewSerialNo()
	{
		++iSerialNo;
		return String.valueOf(iSerialNo);
	}
	
	//�ж�PAMS_AS400���Ƿ���ڸ�PutOutNo����Ϣ ������ ����true  �����ڷ���false
	public boolean isPutOutNoInPamsAs400(PreparedStatement psTemp) throws SQLException
	{
		
		ResultSet rsTemp = psTemp.executeQuery();
		int ncount = 0;
		if(rsTemp.next())
		{
			ncount=rsTemp.getInt("ncount");
		}
		rsTemp.close();
		
		if(ncount>0)
			return true;
		else
			return false;
	}
	

}
