package com.amarsoft.app.datax.gci;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.*;

import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.task.TaskConstants;
/**
 * ICS�����ļ�
 * @author EX-SHENGXIAOPAN001
 *
 */
public class ExpFileSDB extends CommonExecuteUnit{
	
	private String sql;
	private String fileName;
	private PrintWriter outputstreamwriter;
	private String separator;
	private String NASUrl;
	private String fileUrl;
	private String FejrnNo;//ǰ�û���ˮ��
	ESBTransaction transaction =null;
	
	public String getFieldValue(ColumnMetaData columnMetaData,String s){
		String sType = columnMetaData.getTypeName();
		String sName = columnMetaData.getName();
		int iLength=s.getBytes().length;
		int iDisplaySize = columnMetaData.getDisplaySize();
		//int iPrecision = columnMetaData.getPrecision();
		int iScale = columnMetaData.getScale();
		if(sType.equals("CHAR")){
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=s + " ";
	    	}
		}
		
		if(sType.equals("INT")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s="0"+s;
	    	}
		}
		if(sType.equals("DATE")){
			s = StringFunction.replace(s,"/","");
			iLength=s.getBytes().length;
	        for(int i=0;i<iDisplaySize-iLength;i++){
	        	s=s + " ";
	    	}
		}
		
		if(sType.equals("TIME")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=s+"0";
	    	}
		}
		if(sType.equals("DOUBLE")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
			String temp=s;
			if(s.indexOf(".")>0) temp=s.substring(0,s.indexOf("."));
			s=NumberTools.numberFormat(Double.parseDouble(s),temp.length(), iScale);
			iLength=s.length();
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s="0"+s;
	    	}
	        s = "0"+s.substring(0,s.indexOf("."))+s.substring(s.indexOf(".")+1,iDisplaySize);
	        
		}
		return s;
	}
	
	public void exportResultSet(String sql,TableMetaData tableMetaData,PrintWriter outputstreamwriter) throws Exception{
		separator = this.getProperty("separator");
		Statement stm = connection.createStatement();
		ResultSet rs=stm.executeQuery(sql);
		transaction= new ESBTransaction();
		int rowNum=0;
		String rsString="";
		while(rs.next()){
			String s="";
			rowNum++;
			for(int i=1;i<=tableMetaData.getColumnCount();i++){
				ColumnMetaData columnMetaData= tableMetaData.getColumn(i);
				//logger.info(columnMetaData.getName());
				
				rsString=rs.getString(columnMetaData.getName());
				//if("403102031".equals(rsString)){
				//	rsString="99"+"4031401"+"00000";
				//}
			
				if("CARD_NO_1_D".equals(columnMetaData.getName())){
					rsString=rs.getString(columnMetaData.getName());
					if(rsString.length()==16){
						rsString=rsString+"00000000000000";
					}
					if(rsString.length()==7){
						if("4031503".equals(rsString)){
							rsString="0000000000000000"+"99"+rsString+"00000";
						}else{
							rsString="0000000000000000"+"99"+rsString+"00010";
						}
					}
				}
				if("CARD_NO_1_C".equals(columnMetaData.getName())){
					rsString=rs.getString(columnMetaData.getName());
					if(rsString.length()==16){
						rsString=rsString+"00000000000000";
					}
					if(rsString.length()==7){
						if("4031503".equals(rsString)){
							rsString="0000000000000000"+"99"+rsString+"00000";
						}else{
							rsString="0000000000000000"+"99"+rsString+"00010";
						}
					}
				}  
				
				
				if("{$RowNum}".equals(rsString)) rsString=String.valueOf(rowNum);
				
				if("AMTX_H_FILE_SEQ".equals(rsString)) rsString=String.valueOf(1);
				if(rsString==null)rsString="";
				s+=getFieldValue(columnMetaData,rsString)+separator;
			}
			
			FejrnNo=transaction.getSDBSerialNo(connection);
			s=StringFunction.replace(s,"{$FEJRNNO}", FejrnNo);
			s+="\n";
			outputstreamwriter.write(s);
		}
		rs.close();
		stm.close();
	}
	@SuppressWarnings({ "finally", "static-access" })
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				unitStatus= TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				fileName =  this.getProperty("unit.fileName");
				
				if(!isTodayEx(fileName))
				{
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					NASUrl = ARE.getProperty("NASUrl");
					fileUrl= this.getProperty("unit.fileUrl"); 
					
					String sDate = StringFunction.replace(deductDate,"/","");
					String sMonth = StringFunction.replace(currentMonth,"/","");
					fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
					fileName=StringFunction.replace(fileName,"{$CurrentMonth}",sMonth);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentMonth}",sMonth);
					
					fileUrl = NASUrl+fileUrl;
					File file = new File(fileUrl);
					if(!file.exists())
					{
						file.mkdirs();
					}
					
					updateFileName(fileName);
					fileName = fileUrl+fileName;
					outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName))),true);
					for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty(
							"unit.recordSet" + i).trim().equals("")); i++) {
						
						sql=this.getProperty("unit.recordSet"+i);
						sql=StringFunction.replace(sql,"{$CurrentDate}", deductDate);
						sql=StringFunction.replace(sql,"{$CurrentMonth}", currentMonth);
						
						sql=StringFunction.replace(sql,"{$CurrentDateNoSplit}", StringFunction.replace(deductDate, "/",""));
						sql=StringFunction.replace(sql,"{$CurrentMonthNoSplit}", StringFunction.replace(currentMonth, "/",""));
						
						String[] s=sql.split(":");
						sql=sql.substring(sql.indexOf(s[1])+s[1].length()+1);
						logger.info("��ǰ������sql="+sql);
						System.out.println(ARE.getMetaData(s[0]).getTable(s[1]));
						exportResultSet(sql,ARE.getMetaData(s[0]).getTable(s[1]),outputstreamwriter);
					}
				
					outputstreamwriter.close();
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					
				}
			}
		}
		catch(Exception e){
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
		}
		finally{
			clearResource();
			return unitStatus;
		}
	}
	
	private boolean isTodayEx(String sFileName)
	{
		if(sFileName.equalsIgnoreCase("BIFMFBAJUP"))
		{
			if(deductDate.substring(8,10).equals("05"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
			return true;
	}
	//���µ��������ļ�����
	@SuppressWarnings("unused")
	private void updateFileName(String fileName) throws SQLException{
		
		String sSql = " update code_library cl set cl.itemname=? ,itemattribute=? where codeno='SDBDateFile' and isinuse='1' and itemno='10'";
		PreparedStatement ps = connection.prepareStatement(sSql);
		ps.setString(1, fileName);
		ps.setString(2, deductDate);
		ResultSet rs = ps.executeQuery();
		ps.close();
		rs.close();
	}
}
