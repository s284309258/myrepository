package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import com.amarsoft.account.sysconfig.BusinessTypeConfig;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class VipRateInit extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	
	public int execute() {
			
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					
					logger.info("�Խ��շſ���Ϣ��VIP������ݳ�ʼ��.....");
					initVip();
					logger.info("VIP��Ϣ��ʼ����ɣ�");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
	}
	
	public void initVip() throws Exception
	{
		String updateSql = " update Loan_Balance set RateFloatFlag = ? where PutoutNo=? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select lb.PutOutNo,ba.BetterRateFlag,lb.BusinessType,lb.OrgID" +
				" from Business_Apply ba,Business_Contract bc,Loan_Balance lb" +
				" where ba.SerialNo = bc.RelativeSerialNo and bc.serialno = lb.ContractSerialNo and lb.PutOutDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sRateFloatFlag;
			String sIsFloatAsQ = getIsFloatAsQ(rs.getString("BusinessType"),rs.getString("OrgID"));
			String sIsVip = rs.getString("BetterRateFlag");
			if(sIsVip==null || sIsVip.length()==0)
				sIsVip = "0";
			if(sIsFloatAsQ==null || sIsFloatAsQ.length()==0)
				sIsFloatAsQ = "0";
			
			if(sIsFloatAsQ.equals("1")&&sIsVip.equals("0"))
				sRateFloatFlag="0";
			else if(sIsFloatAsQ.equals("0")&&sIsVip.equals("1"))
				sRateFloatFlag="1";
			else if(sIsFloatAsQ.equals("1")&&sIsVip.equals("1"))
				sRateFloatFlag="2";
			else
				sRateFloatFlag="3";
			
			psUpdateSql.setString(1,sRateFloatFlag);
			psUpdateSql.setString(2,rs.getString("PutOutNo"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"�����ݣ�");
			}
			
		}
		psUpdateSql.executeBatch();
		rs.close();
		psUpdateSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
	
	/*
	 * ���ݲ�Ʒ���壬��ô����Ƿ��������������
	 * */
	private String getIsFloatAsQ(String sBusinessType,String sOrgID) throws Exception
	{
		String sReturn = "0";
		HashMap businessDefineHash = BusinessTypeConfig.getBusinessDefineHashMap(sBusinessType,sOrgID);
		if(businessDefineHash==null)
		{
			logger.error("��Ʒ����Ϊ��"+sBusinessType+"  ������Ϊ:"+sOrgID+" �Ĳ�Ʒ�����Ϣδ���壡");
		}
		else
		{
			String sFlostFlag = (String) businessDefineHash.get("RateFloatFlag".toUpperCase());
			if(sFlostFlag!=null && sFlostFlag.length()!=0)
			{
				if(sFlostFlag.equals("1"))
					sReturn = "1";
			}
		}
		return sReturn;
	}
}
