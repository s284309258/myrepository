package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.LoanVIPInfo;
import com.amarsoft.app.datax.gci.QRateFloatCode;
import com.amarsoft.app.datax.gci.VipRate;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.account.entity.OrgInfo;
import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;

public class BatchInsertFloatRateChange extends CommonExecuteUnit{
	
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int serialCount = 0;
	private ArrayList<VipRate> vipRateConfigList1 = new ArrayList<VipRate>();
	private ArrayList<VipRate> vipRateConfigList2 = new ArrayList<VipRate>();
	private ArrayList<QRateFloatCode> qRateFloatCodeList = new ArrayList<QRateFloatCode>();
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String sChangeType = BatchConstant.CHANGE_TYPE_RATEFLOAT;
				String sDate = DateTools.getStringDate(deductDate);
				String sChangeSerialNoHead = "B"+sDate+sChangeType;
				
				String delSql=" delete from Loan_Change where ChangeSerialNo like '"+sChangeSerialNoHead+"%' ";
				logger.info("��ʼ���loan_change�н��������������ʸ������ȱ������.....");
				PreparedStatement psDeleteData = connection.prepareStatement(delSql);
				psDeleteData.execute();
				logger.info("���loan_change�н��������������ʸ������ȱ���������! ");
				psDeleteData.close();
				
				logger.info("����������������ʸ������ȱ������......");
				InsertFloatRateChange1();
				logger.info("�������ʸ���������������������ɣ�");
				logger.info("����Vip���ʸ������ȱ�����ݿ�ʼ......");
				InsertFloatRateChange2();
				logger.info("����Vip���ʸ������ȱ��������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//���ʷ��ȴ�����������
	public void InsertFloatRateChange1() throws Exception
	{
		loanQRateConfig();
		
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		String insertLoanChange = " insert into Loan_Change(ObjectType,ObjectNo,ChangeDate,Status,ChangeType,OldValue,NewValue,ColName,ChangeSerialNo,RelativeSerialNo)"
			                    + " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertLC = connection.prepareStatement(insertLoanChange);
		
		String updateSql = " update LoanBalance_Relative set TurnNormalSerialTerms = ?,IsFloatAsQRate=? where PutOutNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
			
		
		String selectSql = " select lb.PutOutNo,lb.RateFloat,lr.OriRateFloat,lr.OverDays,nvl(lr.SeriesFloatNorTerm,0) as SeriesFloatNorTerm,lb.BusinessType,lb.OrgID,nvl(lr.TurnNormalSerialTerms,0) as TurnNormalSerialTerms,nvl(lr.isFloatAsQRate,'0') as isFloatAsQRate "
			      + " from loan_balance lb,LoanBalance_Relative lr "
			      + " where lr.PutOutNo = lb.PutOutNo and RateMode ='"+BatchConstant.RATEMODE_FLOAT+"' and (lb.RateFloatFlag = '0' or lb.RateFloatFlag='2')"
			      + " and RateFloatType = '"+BatchConstant.RATEFLOATTYPE_PROPORTION+"' and  lb.LastInteDate = '"+deductDate+"' and lb.PutOutDate <> '"+deductDate+"' and lb.LoanStatus in ('0','1','4','5') ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		//�˴�������?����ȥ����һ��֧�еģ����û�в�ִ�з���
		while(rs.next())
		{
			//ѭ�����Ҵ������  ֧�� -- ���� -- ����  �ֱ�����Ƿ��з���������������Ϣ
			String sOrgID = rs.getString("OrgID");
			QRateFloatCode qRateFloat = null;
			for(int i = 0;i<2;i++)
			{
				OrgInfo orgInfo = OrgInfoConfig.getOrgInfo(sOrgID);
				sOrgID = orgInfo.getRelativeOrgID();
				qRateFloat = returnIsQChange(rs.getString("BusinessType"),sOrgID,rs.getInt("OverDays"),rs.getDouble("RateFloat"));
				if(qRateFloat!=null)
					break;
			}
			
			if(qRateFloat==null)
			{
				//���������ɴ������������������ӣ��������������������������Ҫ��
				if(rs.getString("isFloatAsQRate").equals("1") && rs.getInt("SeriesFloatNorTerm")>= rs.getInt("TurnNormalSerialTerms") && rs.getDouble("OriRateFloat")!= rs.getDouble("RateFloat"))
				{
					insertFloatRateChange(psInsertLC,rs.getString("PutOutNo"),rs.getDouble("RateFloat"),rs.getDouble("OriRateFloat"),deductDate);
					psUpdateSql.setInt(1,0);
					psUpdateSql.setString(2,"0");
					psUpdateSql.setString(3,rs.getString("PutOutNo"));
					psUpdateSql.addBatch();
				}
				else
				{
					continue;
				}
			}
			//����׼���ʸ������������ʱ����
			else if(qRateFloat.getSRateFloatType().equals("1"))
			{
				double changeRateFloat = qRateFloat.getDRateFloatValue();
				if(changeRateFloat==rs.getDouble("RateFloat"))
					continue;
				else
				{
					insertFloatRateChange(psInsertLC,rs.getString("PutOutNo"),rs.getDouble("RateFloat"),changeRateFloat,deductDate);
					
					psUpdateSql.setInt(1,qRateFloat.getDNomalRepayNum());
					psUpdateSql.setString(2,"1");
					psUpdateSql.setString(3,rs.getString("PutOutNo"));
					psUpdateSql.addBatch();
				}
			}
			//��ִ�����ʸ�������
			else if(qRateFloat.getSRateFloatType().equals("2")&& !rs.getString("isFloatAsQRate").equals("1"))
			{
				double changeRateFloat = ((1+rs.getDouble("RateFloat")*0.01)*(1+ qRateFloat.getDRateFloatValue()*0.01)-1)*100;
				insertFloatRateChange(psInsertLC,rs.getString("PutOutNo"),rs.getDouble("RateFloat"),changeRateFloat,deductDate);
				
				psUpdateSql.setInt(1,qRateFloat.getDNomalRepayNum());
				psUpdateSql.setString(2,"1");
				psUpdateSql.setString(3,rs.getString("PutOutNo"));
				psUpdateSql.addBatch();
			}
			
			if(dealNum>=commitNum)
			{
				psInsertLC.executeBatch();
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ����븡�����ʱ��"+icount+"��!");
			}
		}
		psInsertLC.executeBatch();
		psUpdateSql.executeBatch();
		rs.getStatement().close();
		psInsertLC.close();
		psUpdateSql.close();
		psSelectSql.close();
		dealNum=0;
	}
	
	//���ʷ��Ȱ�����ȣ�VIP������
	public void InsertFloatRateChange2() throws Exception
	{
		loanVIPRateConfig();
		
		String sDate = currentMonth+"/01";
		if(deductDate.substring(8,10).equals("01"))
		{
			sDate = lastMonth+"/01";
		}
		
		
		String insertLoanChange = " insert into Loan_Change(ObjectType,ObjectNo,ChangeDate,Status,ChangeType,OldValue,NewValue,ColName,ChangeSerialNo,RelativeSerialNo)"
            + " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertLC = connection.prepareStatement(insertLoanChange);

		//��ȡ��ͬ����
		String sqlQueryBCRate = " SELECT nvl(lb.baserate,0) as baserate ,lb.executerate,nvl(bc.businessrate,0) as businessrate FROM business_contract bc,loan_balance lb WHERE lb.contractserialno = bc.serialno AND lb.putoutno = ? ";
		PreparedStatement psQueryBCRate = connection.prepareStatement(sqlQueryBCRate);
		
		//��ȡ�ÿͻ������ܽ��
		String selectLoanAmtSql = "  select nvl(sum(getERateAmount(lb.NormalBalance+lb.DefaultBalance+lb.OverdueBalance+lb.CurrentBalance,lb.currency,'RMB')),0) as sumLoanAmouont " +
				" from Loan_Balance lb " +
				" where lb.CustomerID = ? and (lb.RateFloatFlag = '2' or lb.RateFloatFlag = '1')";
		PreparedStatement psLoanAmt = connection.prepareStatement(selectLoanAmtSql);
		
		//��ȡ�ÿͻ����ڴ���ܽ��
		String selectSavingAmtSql = " select nvl(sum(getERateAmount(sr.Balance,sr.currency,'RMB')),0) as sumSavingAmount " +
				" from Saving_Record_Month sr " +
				" where sr.ecifcustomerid = ? and sr.InputDate = '"+sDate+"' and sr.balanceway = '0'  ";
		PreparedStatement psSavingAmt = connection.prepareStatement(selectSavingAmtSql);
		
		//��ȡ�ÿͻ����ڴ���ܽ��
		String selectFixedSavingAmtSql = " select sum(getERateAmount(sr.Balance,sr.currency,'RMB')) as sumFixedSavingAmount " +
				" from Fixedsaving_Record_Month sr " +
				" where sr.ecifcustomerid = ? and sr.InputDate = '"+sDate+"' ";
		PreparedStatement psFixedSavingAmt = connection.prepareStatement(selectFixedSavingAmtSql);	
		
		String selectSql = " select  nvl(lr.openvipdate,'2009/10/10') as openvipdate,lb.PutoutRate as bpRate,lb.PutOutNo,lb.putoutdate,lb.Customerid,ci.mfcustomerid  as ECIFCustomerID,lb.BusinessType,lb.RateFloat,lb.OrgID,lr.OrirateFloat " +
			" from loan_balance lb,Customer_info ci,loanbalance_relative lr " +
			" where lb.Customerid = ci.Customerid and lb.putoutno=lr.putoutno and (lb.RateFloatFlag = '2' or lb.RateFloatFlag = '1')" +
			" and lb.loanStatus in ('0', '1','4','5') and  lb.LastInteDate = '"+deductDate+"' and lb.PutoutDate <> '"+deductDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double sumLoanBalance = 0.0d;//������
			double sumSavingBalance = 0.0d;//���ڴ����
			double sumFixedSavingBalance = 0.0d; //���ڴ����
			String openvipdate = rs.getString("openvipdate");;
			String putoutdate = rs.getString("putoutdate");
			psLoanAmt.setString(1,rs.getString("Customerid"));
			ResultSet LoanRs = psLoanAmt.executeQuery();
			if(LoanRs.next())
			{
				sumLoanBalance = LoanRs.getDouble("sumLoanAmouont");
			}
			LoanRs.close();
			
			psSavingAmt.setString(1,rs.getString("ECIFCustomerID"));
			ResultSet SavingRs = psSavingAmt.executeQuery();
			if(SavingRs.next())
			{
				sumSavingBalance = SavingRs.getDouble("sumSavingAmount");
			}
			SavingRs.close();
			
			psFixedSavingAmt.setString(1,rs.getString("ECIFCustomerID"));
			ResultSet FixedSavingRs = psFixedSavingAmt.executeQuery();
			if(FixedSavingRs.next())
			{
				sumFixedSavingBalance = FixedSavingRs.getDouble("sumFixedSavingAmount");
			}
			FixedSavingRs.close();
			
			LoanVIPInfo loanVIPInfo = new LoanVIPInfo();
			loanVIPInfo.setPutOutNo(rs.getString("PutOutNo"));
			loanVIPInfo.setBusinessType(rs.getString("BusinessType"));
			loanVIPInfo.setOrgID(rs.getString("OrgID"));
			loanVIPInfo.setCustomerID(rs.getString("Customerid"));
			loanVIPInfo.setEcifCustomerID(rs.getString("ECIFCustomerID"));
			loanVIPInfo.setSumLoanBalance(sumLoanBalance);
			loanVIPInfo.setSumSavingBalance(sumSavingBalance);
			loanVIPInfo.setSumFixedSavingBalance(sumFixedSavingBalance);
			loanVIPInfo.setOldRateFloat(rs.getDouble("RateFloat"));
			loanVIPInfo.setOrirateFloat(rs.getDouble("OrirateFloat"));
			
			//��ʱд��
			ArrayList<VipRate> vipRateConfigListUse = new  ArrayList<VipRate>();
			
			if(putoutdate.compareTo("2011/02/27") <0 && openvipdate.compareTo("2011/02/27") <0){//������ϴ��ִ���ϵĹ���
				vipRateConfigListUse = vipRateConfigList1;
			}else{//���28���Ժ�Ĵ��ִ���µĹ���
				vipRateConfigListUse = vipRateConfigList2;
			}
			//�Ƿ�VIP���ʱ���ж�
			loanVIPInfo = formatLoanVIPInfo(loanVIPInfo,vipRateConfigListUse);
			
			if(loanVIPInfo.isRateFloatChange())
			{
				insertFloatRateChange(psInsertLC,loanVIPInfo.getPutOutNo(),loanVIPInfo.getOldRateFloat(),loanVIPInfo.getNewRateFloat(),deductDate);
				dealNum++;
				icount++;
			}
//				if(loanVIPInfo.isRateFloatChange()){
//					//2011-02-28�����󣬰���ͬ�����¸�
//					psQueryBCRate.setString(1, loanVIPInfo.getPutOutNo());
//					ResultSet rsBCRate = psQueryBCRate.executeQuery();
//					if(rsBCRate.next()){
//						bcRate = rsBCRate.getDouble("businessrate");
//						lbBaseRate = rsBCRate.getDouble("baserate");
//						lbExceuRate = rsBCRate.getDouble("executerate");
//						if(bcRate == 0){//�����ͬ����Ϊ�գ���ȡ��������
//							bcRate= rs.getDouble("bpRate");
//							if(bcRate==0) bcRate=lbBaseRate;
//						}
//						if(1+loanVIPInfo.getNewRateFloat()==0) {
//							logger.info(("ִ������Ϊ��:" + loanVIPInfo.getPutOutNo()));
//							continue;
//						}else{
//							//�µ�ִ������
//							double newExcuteRate = bcRate*(1+loanVIPInfo.getNewRateFloat()/100);
//							//����������Ŀǰִ��������ȣ�������
//							if(lbExceuRate==NumberTools.round(newExcuteRate,7)) continue;
//							//��������Ҫ�¸�
//							double newPro = NumberTools.round((newExcuteRate-lbBaseRate)*100/lbBaseRate,15);
//							
//							loanVIPInfo.setNewRateFloat(newPro);
//						}
//						
//					}
//					rsBCRate.close();
//					
//					insertFloatRateChange(psInsertLC,loanVIPInfo.getPutOutNo(),loanVIPInfo.getOldRateFloat(),loanVIPInfo.getNewRateFloat(),deductDate);
//					dealNum++;
//					icount++;
//				}else {//2011-02-28����������������������ָ��ɺ�ͬ����
//					boolean isBusinessType = getBusinessType(rs.getString("BusinessType"));
//					double newVipRate = 0.0;
//					if(isBusinessType){
//						psQueryBCRate.setString(1, loanVIPInfo.getPutOutNo());
//						ResultSet rsBCRate = psQueryBCRate.executeQuery();
//						if(rsBCRate.next()){
//							bcRate = rsBCRate.getDouble("businessrate");
//							lbBaseRate = rsBCRate.getDouble("baserate");
//							lbExceuRate = rsBCRate.getDouble("executerate");
//							if(bcRate == 0){//�����ͬ����Ϊ�գ���ȡ��������
//								bcRate= rs.getDouble("bpRate");
//								if(bcRate==0) bcRate=lbBaseRate;
//							}
//							//��������,��ΪҪ�ָ��ɺ�ͬ���ʣ����������ֳ��������������������������
//							newVipRate =  NumberTools.round((bcRate - lbBaseRate)*100/lbBaseRate,15);
//							//����������Ŀǰִ��������ȣ�������
//							if(NumberTools.round(lbBaseRate*(1+newVipRate)/100,7)==lbExceuRate)continue;
//						}
//						rsBCRate.close();
//						insertFloatRateChange(psInsertLC,loanVIPInfo.getPutOutNo(),loanVIPInfo.getOldRateFloat(),newVipRate,deductDate);
//						dealNum++;
//						icount++;
//					}
//					
//				}
//				
//			}
			
			
			if(dealNum>=commitNum)
			{
				psInsertLC.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����VIP�������ʱ��"+icount+"��!");
			}
			
		}
		rs.close();
		psInsertLC.executeBatch();
		psSelectSql.close();
		psFixedSavingAmt.close();
		psSavingAmt.close();
		psLoanAmt.close();
		psInsertLC.close();
		psQueryBCRate.close();
	}
	

	public void insertFloatRateChange(PreparedStatement psInsert,String sPutOutNo,double oldRateFloat,double newRateFloat,String sChangeDate) throws Exception
	{
		String sChangeSerialNo1 = createSerialNo();
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,String.valueOf(oldRateFloat));
		psInsert.setString(7,String.valueOf(newRateFloat));
		psInsert.setString(8,"RateFloat");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,BatchConstant.RATEFLOATTYPE_PROPORTION);
		psInsert.setString(7,BatchConstant.RATEFLOATTYPE_PROPORTION);
		psInsert.setString(8,"RateFloatType");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,BatchConstant.RATEMODE_FLOAT);
		psInsert.setString(7,BatchConstant.RATEMODE_FLOAT);
		psInsert.setString(8,"RateMode");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
	}
	
	public String createSerialNo() throws Exception
	{
		serialCount++;
		String sChangeType = BatchConstant.CHANGE_TYPE_RATEFLOAT;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(serialCount,8,'0');
		return "B"+sDate+sChangeType+sSortNo;
	}
	
	/*
	 * ��ʼ����������������������Ϣ
	 * */
	public void loanQRateConfig() throws SQLException
	{
		String selectSql = " select ItemAttribute as BusinessType,RelativeCode as OrgID, " +
				" Attribute1 as MinOverDays,Attribute2 as MaxOverDays, " +
				" Attribute3 as MinOldRateFloat,Attribute4 as MaxOldRateFloat, " +
				" Attribute5 as RateFloatType,Attribute6 as RateFloatValue,Attribute7 as NomalRepayNum " +
				" from code_library " +
				" where CodeNo = 'QRateFloat' and IsInUse = '1' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			QRateFloatCode qRateFloatCode = new QRateFloatCode();
			qRateFloatCode.setSBusinessType(rs.getString("BusinessType"));
			qRateFloatCode.setSOrgID(rs.getString("OrgID"));
			qRateFloatCode.setIMinOverDays(rs.getInt("MinOverDays"));
			qRateFloatCode.setIMaxOverDays(rs.getInt("MaxOverDays"));
			qRateFloatCode.setDMinOldRateFloat(rs.getDouble("MinOldRateFloat"));
			qRateFloatCode.setDMaxOldRateFloat(rs.getDouble("MaxOldRateFloat"));
			qRateFloatCode.setSRateFloatType(rs.getString("RateFloatType"));
			qRateFloatCode.setDRateFloatValue(rs.getDouble("RateFloatValue"));
			qRateFloatCode.setDNomalRepayNum(rs.getInt("NomalRepayNum"));
			
			qRateFloatCodeList.add(qRateFloatCode);
		}
		rs.close();
		psSelectSql.close();
	}
	
	/*
	 * ��ʼ��VIP����������Ϣ
	 * */
	public void loanVIPRateConfig() throws SQLException
	{
		//����ʱ��ܽ�����ʱ������д����2011-02-28����ǰ������׼�����¸����Ժ�Ķ�����ͬ�����¸�
		String selectSql = " select SerialNo,OrgID,BusinessType,LimAmt,SavingLowerLim,SavingUpperLim,RateFloat,FavRateFloat,VipComFlag,BeginDate,VIPRateType "
			             + " from VIP_RATE "
			             + " where Status = '1' and BeginDate <= '"+deductDate+"' and BeginDate>='2010/05/01' and vipRateType in ('010','020')"
			             + " order by BusinessType,OrgID desc";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			VipRate vipRate = new VipRate();
			vipRate.setSerialNo(rs.getString("SerialNo"));
			vipRate.setOrgID(rs.getString("OrgID"));
			vipRate.setBusinessType(rs.getString("BusinessType"));
			vipRate.setLimAmt(rs.getDouble("LimAmt"));
			vipRate.setSavingLowerLim(rs.getDouble("SavingLowerLim"));
			vipRate.setSavingUpperLim(rs.getDouble("SavingUpperLim"));
			vipRate.setUseDate(rs.getString("BeginDate"));
			vipRate.setRateFloat(rs.getDouble("RateFloat"));
			vipRate.setFavRateFloat(rs.getDouble("FavRateFloat"));
			vipRate.setVipComFlag(rs.getString("VipComFlag"));
			vipRate.setVIPRateType(rs.getString("VIPRateType"));
			
			vipRateConfigList2.add(vipRate);	
		}
		rs.close();
		psSelectSql.close();
		
		
		//����ʱ��ܽ�����ʱ������д����2011-02-28����ǰ������׼�����¸����Ժ�Ķ�����ͬ�����¸�
		String selectSql2 = " select SerialNo,OrgID,BusinessType,LimAmt,SavingLowerLim,SavingUpperLim,RateFloat,FavRateFloat,VipComFlag,BeginDate,VIPRateType "
			             + " from VIP_RATE "
			             + " where Status = '1' and  BeginDate<'2010/05/01' and vipRateType in ('010','020')"
			             + " order by BusinessType,OrgID desc";
		PreparedStatement psSelectSql2 = connection.prepareStatement(selectSql2);
		ResultSet rs2 = psSelectSql2.executeQuery();
		while(rs2.next())
		{
			VipRate vipRate = new VipRate();
			vipRate.setSerialNo(rs2.getString("SerialNo"));
			vipRate.setOrgID(rs2.getString("OrgID"));
			vipRate.setBusinessType(rs2.getString("BusinessType"));
			vipRate.setLimAmt(rs2.getDouble("LimAmt"));
			vipRate.setSavingLowerLim(rs2.getDouble("SavingLowerLim"));
			vipRate.setSavingUpperLim(rs2.getDouble("SavingUpperLim"));
			vipRate.setUseDate(rs2.getString("BeginDate"));
			vipRate.setRateFloat(rs2.getDouble("RateFloat"));
			vipRate.setFavRateFloat(rs2.getDouble("FavRateFloat"));
			vipRate.setVipComFlag(rs2.getString("VipComFlag"));
			vipRate.setVIPRateType(rs2.getString("VIPRateType"));
			
			vipRateConfigList1.add(vipRate);	
		}
		rs2.close();
		psSelectSql2.close();
	}
	

	/*
	 * ��������������仯���������ں󸡶������ϸ�׼���ж�
	 * */
	public QRateFloatCode returnIsQChange(String sBusinessType,String sOrgID,int iOverDays,double dOldRateFloat)
	{
		QRateFloatCode returnObject = null;
		
		for(int i=0;i<qRateFloatCodeList.size();i++)
		{
			QRateFloatCode qRateFloatCode = qRateFloatCodeList.get(i);
			//ҵ��Ʒ���ж�
			if(!qRateFloatCode.getSBusinessType().equals(sBusinessType))
				continue;
			//�����ж�
			if(!qRateFloatCode.getSOrgID().equals(sOrgID))
				continue;
			//���������ж�
			if(iOverDays<qRateFloatCode.getIMinOverDays() || iOverDays>qRateFloatCode.getIMaxOverDays())
				continue;
			//ԭ���ʸ��������ж�
			if(dOldRateFloat<qRateFloatCode.getDMinOldRateFloat() || dOldRateFloat>qRateFloatCode.getDMaxOldRateFloat())
				continue;
			returnObject = qRateFloatCode;	
			if(returnObject!= null)
				break;
		}
		
		return returnObject;
	}
	
	/*
	 * ����������Ϣ���жϸô����Ƿ����VIP���ʱ��
	 * */
	private LoanVIPInfo formatLoanVIPInfo(LoanVIPInfo loanVIPInfo,ArrayList<VipRate> vipRateConfigListUse) throws LoanException
	{
		double newRateFloat1 = 9999.9;//���ڸ�������
		double newRateFloat2 = 9999.9;//����+���� ��������
		
		for(int i=0;i<vipRateConfigListUse.size();i++)
		{	
			VipRate vRate = vipRateConfigListUse.get(i);
			//��������
			if(vRate.getVIPRateType().equalsIgnoreCase("010"))
			{
				String sOrgID = loanVIPInfo.getOrgID();
				for(int j = 0;j<2;j++)
				{
					OrgInfo orgInfo = OrgInfoConfig.getOrgInfo(sOrgID);
					sOrgID = orgInfo.getRelativeOrgID();
					//-10%
					if(Math.abs(newRateFloat1-9999.9)>0.001)
						break;
					newRateFloat1 = getVIPRateFloat(vRate,loanVIPInfo.getBusinessType(),sOrgID,loanVIPInfo.getSumSavingBalance(),NumberTools.round((loanVIPInfo.getSumSavingBalance()/loanVIPInfo.getSumLoanBalance()),2),loanVIPInfo.getOrirateFloat());
					if(Math.abs(newRateFloat1-9999.9)>0.001)
						break;
				}
			}
			//��������
			else if(vRate.getVIPRateType().equalsIgnoreCase("020"))
			{
				String sOrgID = loanVIPInfo.getOrgID();
				for(int j = 0;j<2;j++)
				{
					OrgInfo orgInfo = OrgInfoConfig.getOrgInfo(sOrgID);
					sOrgID = orgInfo.getRelativeOrgID();
					if(Math.abs(newRateFloat2-9999.9)>0.001)
						break;
					newRateFloat2 = getVIPRateFloat(vRate,loanVIPInfo.getBusinessType(),sOrgID,(loanVIPInfo.getSumSavingBalance()+loanVIPInfo.getSumFixedSavingBalance()),NumberTools.round(((loanVIPInfo.getSumSavingBalance()+loanVIPInfo.getSumFixedSavingBalance())/loanVIPInfo.getSumLoanBalance()),2),loanVIPInfo.getOrirateFloat());
					if(Math.abs(newRateFloat2-9999.9)>0.001)
						break;
				}
			}
			
		}
		//��һ��rateFloatType��Type�������Ǻ�ͬ�ϸ������ǻ�׼�����ϸ���
		double newRateFloat = returnChangeFloat(newRateFloat1,newRateFloat2,loanVIPInfo.getOldRateFloat(),loanVIPInfo.getOrirateFloat());
		
		if(Math.abs(newRateFloat-9999.9)<0.001)
		{
			loanVIPInfo.setRateFloatChange(false);
		}	
		else
		{
			loanVIPInfo.setRateFloatChange(true);
			loanVIPInfo.setNewRateFloat(newRateFloat);
		}
		
		return loanVIPInfo;
		
	}
	
	private double getVIPRateFloat(VipRate vRate,String sBusinessType,String sOrgID,double dSavingAmt,double dSavingLoanProport,double dOrirateFloat)
	{
		if(!vRate.getBusinessType().equals(sBusinessType))
			return 9999.9;
		if(!vRate.getOrgID().equals(sOrgID))
			return 9999.9;
		if(dSavingAmt<vRate.getLimAmt())
			return 9999.9;
		if(dSavingLoanProport<(vRate.getSavingLowerLim()*0.01) || dSavingLoanProport>=(vRate.getSavingUpperLim()*0.01))
			return 9999.9;
		return returnRateFloat(vRate,dOrirateFloat);
	}
	
	/*
	 * VIP���ʸ����ж�
	 * */
//	public VipRate returnIsVIPChange(String sBusinessType,String sOrgID,double dSavingAmt,double dSavingLoanProport)
//	{
//		VipRate vipRate = null;
//		for(int i=0;i<vipRateConfigList.size();i++)
//		{
//			VipRate vRate = vipRateConfigList.get(i);
//			//ҵ��Ʒ���ж�
//			if(!vRate.getBusinessType().equals(sBusinessType))
//				continue;
//			if(!vRate.getOrgID().equals(sOrgID))
//				continue;
//			if(dSavingAmt<vRate.getLimAmt())
//				continue;
//			if(dSavingLoanProport<(vRate.getSavingLowerLim()*0.01) || dSavingLoanProport>(vRate.getSavingUpperLim()*0.01))
//				continue;
//			vipRate = vRate;
//			if(vipRate != null)
//				break;
//			
//		}
//		
//		return vipRate;
//	}
	
	//���ݴ���2�������ʺ�1���������ж� �����Ƿ�Ӧ�÷����仯
	private double returnChangeFloat(double rateFloat1,double rateFloat2,double oldRateFloat,double OrirateFloat)
	{
		double returnFloat = 0.0d;
		//����������������
		if(Math.abs(rateFloat1-9999.9)<0.001 && Math.abs(rateFloat2-9999.9)>0.01)
			returnFloat = rateFloat2;
		else if(Math.abs(rateFloat1-9999.9)>0.001 && Math.abs(rateFloat2-9999.9)<0.01)
			returnFloat = rateFloat1;
		else if(Math.abs(rateFloat1-9999.9)>0.001 && Math.abs(rateFloat2-9999.9)>0.01)
		{
			if(rateFloat1<rateFloat2)
				returnFloat = rateFloat1;
			else
				returnFloat = rateFloat2;
		}
		else if(Math.abs(rateFloat1-9999.9)<0.001 && Math.abs(rateFloat2-9999.9)<0.01)
		{
			if(oldRateFloat<OrirateFloat)
				returnFloat = OrirateFloat;
			else
				returnFloat = 9999.9;
		}
		else
			returnFloat = rateFloat1;
		//��׼�����ϸ�����ȥ�ж�
		if(Math.abs(returnFloat-oldRateFloat)<0.001)
			returnFloat = 9999.9;
		
		
		return returnFloat;		
	}
	
	//����Vip�仯������ʸ�������
	public double returnRateFloat(VipRate vipRate,double dOrirateFloat)
	{
		double dReturn=9999.9;
		//���Żݸ������ȼ���
		if(vipRate.getVipComFlag().equals("010"))
		{
			if(vipRate.getFavRateFloat()>0)
			{
				dReturn = dOrirateFloat-vipRate.getFavRateFloat();
				if(dReturn<vipRate.getRateFloat())
					dReturn=vipRate.getRateFloat();
			}
			
		}
		//���̶����ʷ���
		else if(vipRate.getVipComFlag().equals("020"))
		{
			dReturn = vipRate.getRateFloat();
		}
		return dReturn;
	}
	
}
