package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.app.datax.gci.BatchConstant;

public class RepayDataSplit1 extends BasicRepayDataSplit {
	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
			//���޸�ȡ��ݺŷ�ʽ�����ֻ�з��ã�deductDateListû�����ݣ�������modify dxu1 2010-11-27
			String sPutOutNo = "";
			if(deductDateList.size()==0 ){
				if(acctFeeInfoList!=null && acctFeeInfoList.size()!=0){
					sPutOutNo = acctFeeInfoList.get(0).getObjectNo();
				}
				else{
					return false;
				}
			}else{
				sPutOutNo = deductDateList.get(0).getPutOutNo();
			}
			
			boolean dReturn = true;
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			if(DeductAccNo == null||DeductAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
				dReturn = false;
			}
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			if(RelativeAccNo==null||RelativeAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
				dReturn = false;
			}
			return dReturn;
		
	}


	public ArrayList<PamsAs400> executeSplit(
			ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String, DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		if(!preCheck(deductDateList,aheadDeductdataList,fareDetailList,acctFeeInfoList,accountMap))
			return pamsAs400ArrayList;
		else
		{
				
			double amount = 0;
			//String sDeductSerialNo = createDeductSerialNo();
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			String DeductAccNo1 = accountMap.get("DeductAccNo1") == null ? "" : accountMap.get("DeductAccNo1").getAccountNo();
			String DeductAccNo2 = accountMap.get("DeductAccNo2") == null ? "" : accountMap.get("DeductAccNo2").getAccountNo();
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			double fareAmount = 0;
			String putoutno="";
			String currency1="";
			for(int i=0;i<deductDateList.size();i++)
			{
				DeductData deductData = deductDateList.get(i);
				putoutno=deductData.getPutOutNo();
				currency1=deductData.getCurrency();
				//ÿ�ڻ�����
				amount = amount+returnCorp(deductData)
						+ returnInte(deductData) + returnFine(deductData);
			}
			for(int j=0;j<acctFeeInfoList.size();j++){
				
				AcctFeeInfoBatch acctFeeInfo = acctFeeInfoList.get(j);
				fareAmount += acctFeeInfo.getPayMoney()-acctFeeInfo.getActualMoney();
			}
			
			if(fareAmount>0&&amount > 0){
				PamsAs400 pamsAs400 = new PamsAs400(putoutno,currency1,amount+fareAmount,
						DeductAccNo,RelativeAccNo,createDeductSerialNo(),
						BatchConstant.AMOUNTATTRIBUTE_SW,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"",DeductAccNo1,DeductAccNo2);
				pamsAs400ArrayList.add(pamsAs400);
			}
			if (fareAmount<=0&&amount > 0) {
				PamsAs400 pamsAs400 = new PamsAs400(putoutno,currency1,amount,
						DeductAccNo,RelativeAccNo,createDeductSerialNo(),
						BatchConstant.AMOUNTATTRIBUTE_CUR,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"",DeductAccNo1,DeductAccNo2);
				pamsAs400ArrayList.add(pamsAs400);
			}
			return pamsAs400ArrayList;
		}
	}

}
