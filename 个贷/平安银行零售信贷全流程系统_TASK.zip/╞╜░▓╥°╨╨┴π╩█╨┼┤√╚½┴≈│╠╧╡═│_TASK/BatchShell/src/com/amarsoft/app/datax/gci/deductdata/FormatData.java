package com.amarsoft.app.datax.gci.deductdata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.entity.AcctFeeInfo;
import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.LoanAccount;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.app.datax.gci.RepayDataSplit.IRepayDataSplit;
import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.impl.szpab.esb.ESBTransaction;

public class FormatData extends CommonExecuteUnit{

	private int commitNum ;
	private int deductDateNum = 0;
	private int icount = 0;
	HashMap<String ,IRepayDataSplit> repayDataSplitMap;
	private PreparedStatement psSelectSql1;
	private PreparedStatement psSelectSql2;
	private PreparedStatement psSelectSql3;
	private PreparedStatement psSelectSql4;
	private PreparedStatement psSelectSql5;
	private PreparedStatement psSelectSql6;//��ʼ�����õ��ڴ�
	private PreparedStatement psSelectSql7;//��ʼ��С΢����
	
	
	
	
	public int execute() {
		
		try{
			String sInit = super.init();

			//��̬���������������Ŵ���ˮ��
			BatchConstant.DEDUCT_SERIAL_NO = 0;

			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String delSql="call dbmgr.truncate_table ('RCPMDATA','PAMS_AS400') ";
//			String delSql="delete from PAMS_AS400";
				logger.info("��� PAMS_AS400:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("���PAMS_AS400������� ");
				psDelSql.close();
				
				/*logger.info("���ܿͻ����Ϸ���......");
				insertLegalFare();
				logger.info("���ܿͻ����Ϸ������......");*/
				logger.info("����С΢�������......");
				BatchFeeBW();
				logger.info("����С΢����������......");
				initPs();
				logger.info("����һ�㻹����������......");
				initFormatPara();
				formatDeductData();
				logger.info("������һ�㻹����������"+icount+"����");
				logger.info("����һ�㻹������������ɣ�");
				
				logger.info("������ǰ������������......");
				formatAheadDeductData();
				logger.info("������ǰ��������������ɣ�"); 
				

				closePs();
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//С΢���ô������ۿ��ʻ�������˺Ų�һ�£�
	private void BatchFeeBW() throws Exception{
		
		String putoutno = "",Currency = "",PayType="",DudectAccNo="",RelativeAccNo="",DeductSerialNo="",AmountAttribute="",orgid="",sBankFlag="";
		double Amount = 0;
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,BusinessSerialno,TransSerialno,BankFlag,DeductAccno1,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		String sql = "select afi.SerialNo,afi.FeeAccountNo,afi.ObjectNo,fd.PayDate,afi.FeeType,fd.PayMoney,fd.ActualMoney,fd.AccDate,fd.Currency,afi.BankFlag,bp.operateOrgId " +
				" from Fare_Detail fd,Acct_Fee_Info afi,Business_PutOut bp where fd.PutOutNo = afi.SerialNo and bp.serialNo = afi.objectNo" +
				" and fd.offFlag = '0' and afi.AccountFlag = '0'";
		PreparedStatement psQuerySql = connection.prepareStatement(sql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			putoutno = rs.getString("SerialNo");
			Currency = rs.getString("Currency");
			sBankFlag = rs.getString("BankFlag");
			PayType = "1";
			DudectAccNo = rs.getString("FeeAccountNo");
			orgid  = OrgInfoConfig.getMainFrameOrgId(rs.getString("operateOrgId"));
			String  businessSerialno=ESBTransaction.getBZSerialNo(connection);
			String  transSerialno=businessSerialno;
			Amount = rs.getDouble("PayMoney") - rs.getDouble("ActualMoney");
			if(rs.getString("operateOrgId")==null ||rs.getString("operateOrgId").length() ==0||rs.getString("Currency")==null ||rs.getString("Currency").length()==0) continue;
			RelativeAccNo = OrgInfoConfig.getAccountNo(rs.getString("operateOrgId"),AccountConstants.Ahead_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type);
			DeductSerialNo = String.valueOf(++BatchConstant.DEDUCT_SERIAL_NO);
			AmountAttribute = BatchConstant.AMOUNTATTRIBUTE_SW_DF_FEE;
			psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,putoutno,Currency,PayType,Amount,
					DudectAccNo,RelativeAccNo,DeductSerialNo,AmountAttribute,1,"",orgid,businessSerialno,transSerialno,sBankFlag,"","");
			psInsertPamsAs400.executeBatch();
		}
		psQuerySql.close();
		psInsertPamsAs400.close();
		rs.close();
		
	}
	//���ܿͻ����Ϸѻ���
	private void insertLegalFare() throws Exception {
		String putoutno = "",Currency = "",PayType="",DudectAccNo="",RelativeAccNo="",DeductSerialNo="",AheadSerialNo="",AmountAttribute="",Sterm="",orgid="",sBankFlag="",sObjectNo="";
		double Amount = 0;
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,BusinessSerialno,TransSerialno,BankFlag,DeductAccno1,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		String sql = " SELECT * FROM legalfare WHERE PayOffflag = '0' AND ReturnSource = '2'";
		PreparedStatement psQuerySql = connection.prepareStatement(sql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			putoutno = rs.getString("SERIALNO");
			Currency = rs.getString("CURRENCY");
			putoutno = rs.getString("SERIALNO");
			sObjectNo = rs.getString("OBJECTNO");
			sBankFlag = selectBankFlag(sObjectNo);//����PAB��SDB�����ֱ�־  modify by jxie  2011-09-27
			//System.out.println("sBankFlag-----------------"+sBankFlag);
			PayType = "1";
			DudectAccNo = rs.getString("DEDUCTACCNO");
			orgid  = OrgInfoConfig.getMainFrameOrgId(rs.getString("orgid"));
			String  businessSerialno=ESBTransaction.getBZSerialNo(connection);
			String  transSerialno=businessSerialno;
			Amount = rs.getDouble("PAYAMOUNT") - rs.getDouble("ACTUALAMOUNT");
			if(rs.getString("OrgID")==null ||rs.getString("OrgID").length() ==0||rs.getString("Currency")==null ||rs.getString("Currency").length()==0) continue;
			RelativeAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),AccountConstants.Ahead_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type);
			DeductSerialNo = String.valueOf(++BatchConstant.DEDUCT_SERIAL_NO);
			AmountAttribute = BatchConstant.AMOUNTATTRIBUTE_LEEGALFARE;
			psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,putoutno,Currency,PayType,Amount,
					DudectAccNo,RelativeAccNo,DeductSerialNo,AmountAttribute,1,"",orgid,businessSerialno,transSerialno,sBankFlag,"","");
			psInsertPamsAs400.executeBatch();
		}
		psQuerySql.close();
		psInsertPamsAs400.close();
		rs.close();
	}

	public void initFormatPara() throws Exception{
		
		repayDataSplitMap=new HashMap<String ,IRepayDataSplit>();
		Statement stmt=connection.createStatement();
		ResultSet rs=stmt.executeQuery("select codeNo,ItemNo,ItemName,SortNo,IsInUse,ItemAttribute " +
				" from Code_Library where CodeNo = 'SplitData' and IsInuse='1' ");
		while(rs.next()){
			String className = rs.getString("ItemAttribute");//������
			String transType= rs.getString("ItemNo");//������������
			className = className.trim();
			Class c=Class.forName(className);
			repayDataSplitMap.put(transType,(IRepayDataSplit)c.newInstance());
		}
		rs.close();
		stmt.close();
	}
	
	private void formatDeductData() throws Exception
	{
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,BusinessSerialno,TransSerialno,BankFlag,DeductAccno1,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		
		String selectSql = " select /*+ PARALLEL(lb, DEFAULT) */lb.putoutno,lb.orgid,lb.businesstype,nvl(bc.PayType,'0') as PayType,nvl(lb.disdate,'2009/10/10') as disdate,nvl(lb.bankflag,'PAB') as bankflag  " +
				" from loan_balance lb,business_contract bc,business_type bt " +
				" where lb.contractserialno=bc.serialno " +
				"  and lb.businesstype = bt.typeno and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) " +
				//modify by dxu��2010-11-24����������״������Ѻ��Ѻ�����ȣ�����������������.�Լ�������δ����(��������ǰ�����ǰ����ķ����ڴ˲�����ǰ�Ѿ�����)��Ҳ�������۱�
				"  and( exists (select 1 from deduct_data dd where lb.putoutno = dd.putoutno) or lb.businesstype = '1120030' or exists (SELECT 1 FROM fare_detail fd WHERE lb.putoutno = fd.putoutno  AND FD.OFFFLAG = '0' AND fd.paydate <='"+deductDate+"'))" +
				"  order by CASE WHEN bc.businesstype='1160050' THEN  bt.decisionscript2 " +
				" ELSE   bt.decisionscript5  END ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//���Ϊί�д�����ڴ˴�����ֱ�ӵ�ʵʱ�ӿڴ���
			if("1190030".equals(rs.getString("businesstype"))||"2170100".equalsIgnoreCase(rs.getString("businesstype"))) continue;
			String sPutOutNo = rs.getString("putoutno");			
			String sOrgid = rs.getString("orgid");	
			String sBankFlag = rs.getString("bankflag");
			LoanAccount loanAccount = new LoanAccount();	
			loanAccount.setSPutOutNo(sPutOutNo);
			loanAccount.setOrgID(OrgInfoConfig.getMainFrameOrgId(sOrgid));


			initAllDeductList(loanAccount);
			
			String sKey = getSkey("DeductData",rs.getString("businesstype"),rs.getString("PayType"),rs.getString("disdate"),sBankFlag);
			IRepayDataSplit iRepayDataSplit =  repayDataSplitMap.get(sKey);			
			
			ArrayList<PamsAs400>  pamsAs400List =iRepayDataSplit.execute(loanAccount);
			for(int i=0;i<pamsAs400List.size();i++)
			{
				PamsAs400 pamsAs400 = pamsAs400List.get(i);
				String temp=ESBTransaction.getBZSerialNo(connection);
				String transSerialno=temp;
				String businessSerialno=transSerialno;
				psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,pamsAs400.getSPutOutNo(),pamsAs400.getSCurrency(),pamsAs400.getSPayType(),pamsAs400.getAmount(),
						pamsAs400.getSDudectAccNo(),pamsAs400.getSRelativeAccNo(),pamsAs400.getDeductSerialNo(),pamsAs400.getAmountAttribute(),pamsAs400.getSterm(),pamsAs400.getSaheadSerialNo(),loanAccount.getOrgID(),businessSerialno,transSerialno,sBankFlag,pamsAs400.getDeductAccNo1(),pamsAs400.getDeductAccNo2());
			}
			
			ArrayList<BatchErrorRecord>  batchErrorRecordList =iRepayDataSplit.getErrorList();
			for(int i=0;i<batchErrorRecordList.size();i++)
			{
				BatchErrorRecord batchErrorRecord = batchErrorRecordList.get(i);
				batchErrorRecord.setInputDate(deductDate);
				batchErrorRecord.errorRecord(connection);
			}
			
			
			 if(deductDateNum>=commitNum)
			 {
				 psInsertPamsAs400.executeBatch();
				 deductDateNum=0;
				 logger.info("�ѻ���һ�㻹������"+icount+"����");
				 
			 }
		}
		 psInsertPamsAs400.executeBatch();
		 rs.close();
		 psInsertPamsAs400.close();
		 psSelectSql.close();
	}
	
	private void dealFareList(LoanAccount loanAccount, Connection connection) throws SQLException {
		//���û�����۱�����Ϣ����
		if(loanAccount.getDeductdataList().size() == 0){
			if(loanAccount.getFareDetailList().size() !=0 || loanAccount.getFareDetailList() != null){
				ArrayList<FareDetaill> fareDetailList = loanAccount.getFareDetailList();
				//ѭ��������ö�Ӧ���ڴ�
				for(int i=0;i<fareDetailList.size();i++){
					FareDetaill fareDetail = fareDetailList.get(i);
					psSelectSql6.setString(1,fareDetail.getPutOutNo() );
					psSelectSql6.setString(2,fareDetail.getPayDate());
					ResultSet rs = psSelectSql6.executeQuery();
					while(rs.next()){
						fareDetail.setSterm(rs.getInt("sterm"));
					}
					rs.close();
				}
			}
		}
		
	}
	
	private void dealAcctFeeInfoList(LoanAccount loanAccount, Connection connection) throws SQLException {
		//���û�����۱�����Ϣ����
		if(loanAccount.getDeductdataList().size() == 0){
			if(loanAccount.getFareDetailList().size() !=0 || loanAccount.getFareDetailList() != null){
				ArrayList<AcctFeeInfoBatch> acctFeeInfoList = loanAccount.getAcctFeeInfoList();
				//ѭ��������ö�Ӧ���ڴ�
				for(int i=0;i<acctFeeInfoList.size();i++){
					AcctFeeInfoBatch acctFeeInfo = acctFeeInfoList.get(i);
					psSelectSql6.setString(1,acctFeeInfo.getObjectNo() );
					psSelectSql6.setString(2,acctFeeInfo.getPayDate());
					ResultSet rs = psSelectSql6.executeQuery();
					while(rs.next()){
						acctFeeInfo.setSterm(rs.getInt("sterm"));
					}
					rs.close();
				}
			}
		}
		
	}


	private void formatAheadDeductData() throws Exception
	{
	        String sDeductAccno2="";
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,businessSerialno,transSerialno,BankFlag,DeductAccno1,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		
		String selectSql = " select lb.putoutno,lb.orgid,lb.businesstype,nvl(bc.PayType,'0') as PayType,nvl(lb.disdate,'2009/10/10') as disdate ,nvl(lb.bankflag,'PAB') as bankflag " +
				" from loan_balance lb,business_contract bc,business_type bt " +
				" where lb.contractserialno=bc.serialno " +
				"  and lb.businesstype = bt.typeno and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) " +
				"  and exists (select 1 from ahead_deduct_data ad where lb.putoutno = ad.putoutno) " +
				" order by bt.decisionscript2 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//���Ϊί�д�����ڴ˴�����ֱ�ӵ�ʵʱ�ӿڴ���
			if("1190030".equals(rs.getString("businesstype"))||"2170100".equalsIgnoreCase(rs.getString("businesstype"))) continue;
			ArrayList<PamsAs400> pamsAs400List = new ArrayList<PamsAs400>();
			String sPutOutNo = rs.getString("putoutno");
			String sBankFlag = rs.getString("bankflag");//����PAB��SDB�����ֱ�־  modify by jxie  2011-09-27	
			String sOrgid = rs.getString("orgid");	
			LoanAccount loanAccount = new LoanAccount();	
			loanAccount.setSPutOutNo(sPutOutNo);
			loanAccount.setOrgID(OrgInfoConfig.getMainFrameOrgId(sOrgid));


			initAllDeductList(loanAccount);

			
			String sKey = getSkey("AheadDeductData",rs.getString("businesstype"),rs.getString("PayType"),rs.getString("disdate"),sBankFlag);
			IRepayDataSplit iRepayDataSplit =  repayDataSplitMap.get(sKey);	
			
			pamsAs400List = iRepayDataSplit.execute(loanAccount);
			for(int i=0;i<pamsAs400List.size();i++)
			{
				PamsAs400 pamsAs400 = pamsAs400List.get(i);
				//sDeductAccno2=this.checkDudectAccNo2(sPutOutNo,pamsAs400);//���ַǴ���źʹ����
				String temp=ESBTransaction.getBZSerialNo(connection);
				String transSerialno=temp;
				String businessSerialno=transSerialno;
				psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,pamsAs400.getSPutOutNo(),pamsAs400.getSCurrency(),pamsAs400.getSPayType(),pamsAs400.getAmount(),
						pamsAs400.getSDudectAccNo(),pamsAs400.getSRelativeAccNo(),pamsAs400.getDeductSerialNo(),pamsAs400.getAmountAttribute(),pamsAs400.getSterm(),pamsAs400.getSaheadSerialNo(),loanAccount.getOrgID(),businessSerialno,transSerialno,sBankFlag,"","");
			}
			
			
			ArrayList<BatchErrorRecord>  batchErrorRecordList =iRepayDataSplit.getErrorList();
			for(int i=0;i<batchErrorRecordList.size();i++)
			{
				BatchErrorRecord batchErrorRecord = batchErrorRecordList.get(i);
				batchErrorRecord.setInputDate(deductDate);
				batchErrorRecord.errorRecord(connection);
			}
			
			 if(deductDateNum>=commitNum)
			 {
				 psInsertPamsAs400.executeBatch();
				 deductDateNum=0;
				 logger.info("�ѻ���һ�㻹������"+icount+"����");
				 
			 }
			 logger.info("�����˺�"+sPutOutNo);
		}
		 psInsertPamsAs400.executeBatch();
		 rs.close();
		 psInsertPamsAs400.close();
		 psSelectSql.close();
	}
	
	private String getSkey(String KeyType,String sBusinessType,String sPayType,String sDisDate,String sBankFlag)
	{
		String sReturn = "";
		if("1150020".equals(sBusinessType)&&DateTools.getDays(sDisDate,deductDate)<=0){
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "GJZX";
			else
				sReturn = "GJZXTQHK";
		}
		else if("1190030".equals(sBusinessType)||"2170100".equalsIgnoreCase("sBusinessType"))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "WTDK";
			else
				sReturn = "WTTQHK";
		}
		else if("1150060".equals(sBusinessType) && "Q02".equals(sPayType))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "XB36HK";
			else
				sReturn = "XB36TQHK";
		}
		else if("1120030".equals(sBusinessType))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "CDHK";
			else
				sReturn = "CDTQHK";
		}
		else if("1140100".equals(sBusinessType))
		{
			if("DeductData".equalsIgnoreCase(KeyType)){
				sReturn = "XYDHK";
			}else if("AheadDeductData".equalsIgnoreCase(KeyType)&&"SDB".equals(sBankFlag)){
				sReturn = "SDBXYDTQHK";
			}else{
				sReturn = "XYDTQHK";
			}
		}
		else
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "YBHK";
			else
				sReturn = "YBTQHK";
		}
		return sReturn;
	}
	
	public PreparedStatement insertPsPamsAs400(PreparedStatement psInsertSql,String sPutOutNo,String sCurrency,String sPayType,double amount,String sDudectAccNo,String sRelativeAccNo,String deductSerialNo,String sAmountAttribute,int Sterm,String sAheadSerialNo,String orgid,String sBusinessSerialno,String sTransSerialno,String BankFlag,String DeductAccno1,String DeductAccno2) throws SQLException
	{
		icount++;
		//SerialNo
		psInsertSql.setInt(1,icount);
		//PutOutNo
		psInsertSql.setString(2,sPutOutNo);
		//Currency
		psInsertSql.setString(3,sCurrency);
		//PayType
		psInsertSql.setString(4,sPayType);
		//PayAmount
		psInsertSql.setDouble(5,amount);
		//DeductAccNo
		psInsertSql.setString(6,sDudectAccNo);
		//RelativeAccNo
		psInsertSql.setString(7,sRelativeAccNo);
		//AheadSerialNo
		psInsertSql.setString(8,sAheadSerialNo);
		//DeductSerialNo
		psInsertSql.setString(9,deductSerialNo);
		//AmountAttribute
		psInsertSql.setString(10,sAmountAttribute);
		//Sterm
		psInsertSql.setInt(11,Sterm);
		psInsertSql.setString(12,orgid);
		psInsertSql.setString(13,sBusinessSerialno);
		psInsertSql.setString(14,sTransSerialno);
		psInsertSql.setString(15, BankFlag);
		psInsertSql.setString(16, DeductAccno1);
		psInsertSql.setString(17, DeductAccno2);
		psInsertSql.addBatch();
		deductDateNum++;
		
		return psInsertSql;
	}

	
	private void initPs() throws SQLException
	{
		String selectSql1 = " select PutOutNo,STerm,Currency,PayCurrentCorp,ActualCurrentCorp," +
		"  PayDefaultCorp,ActualDefaultCorp,PayOverDueCorp,ActualOverDueCorp, " +
		"  PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, " +
		"  PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,DeductAccNo,PayDate" +
		" FROM DEDUCT_DATA " +
		" where putoutno = ? " +
		" order by sterm ";
		psSelectSql1 = connection.prepareStatement(selectSql1);
				
		String selectSql2 = " select ChangeSerialNo,PutOutNo,Currency,DeductAccNo,PayDate,PayCurrentCorp, " +
		"  PayInte,PayPoundage,DealFlag " +
		" from ahead_deduct_data " +
		" where putoutno = ? " +
		" order by sterm ";
		psSelectSql2 = connection.prepareStatement(selectSql2);
				
		String selectSql3 = " select PutOutNo,PayDate,PayMoney,ActualMoney,AccDate,Currency  " +
		"  from fare_detail " +
		" where putoutno = ? and offFlag = '0' " +
		" order by PayDate ";
		psSelectSql3 = connection.prepareStatement(selectSql3);
		
		String selectSql4 = "  select lb.OrgID,lb.putoutno,lb.deductAccNo,lb.deductAccNo1,lb.deductAccNo2,lb.TrustAccNo,nvl(bp.TransFerAccNo,'') as TransFerAccNo,lb.Currency,lb.BusinessType,nvl(lb.DisDate,'2009/09/10') as DisDate,lb.BankFlag  " +
		" from loan_balance lb,business_putout bp "+
		" where lb.putoutno = ? and lb.putoutno = bp.serialno(+) ";
		psSelectSql4 = connection.prepareStatement(selectSql4);
		
		
		String selectSql5 = "  select nvl(ii.TrustBankNo,'') as TrustBankNo " +
		" from loan_balance lb,business_contract bc,business_applicant bap,ind_info ii " +
		" where lb.contractserialno = bc.serialno " +
		" and bc.relativeserialno = bap.objectno and bap.objecttype = 'CBCreditApply' " +
		" and bap.applicantid = ii.customerid and ii.isUseBankNo = '1' " +
		" and lb.putoutno = ? ";
		psSelectSql5 = connection.prepareStatement(selectSql5);

		//�¼ӣ����С�����ȿ��˱�����Ϣ��û�п۷��õ����,��ʼ����ȥ�ڴΣ������������������
		String selectSql6 = " SELECT sterm FROM loanback_status WHERE putoutno = ? AND paydate = ? AND aheadnum = 0";
		psSelectSql6 = connection.prepareStatement(selectSql6);
		//�˴����ܽ�ȥ�ķ��ÿ϶��Ǳ��ڴ����������û�У��ʸ������ʻ�һ����һ��
		String selectSql7 = "select afi.SerialNo,afi.FeeAccountNo,afi.ObjectNo,fd.PayDate,afi.FeeType,fd.PayMoney,fd.ActualMoney,fd.AccDate,fd.Currency " +
				" from Fare_Detail fd,Acct_Fee_Info afi where fd.PutOutNo = afi.SerialNo and afi.objectNo = ? " +
				" and offFlag = '0' and afi.AccountFlag = '1' order by fd.PayDate,afi.SerialNo";
		psSelectSql7 = connection.prepareStatement(selectSql7);
		
	}
	
	private void closePs() throws SQLException
	{
		psSelectSql1.close();
		psSelectSql2.close();
		psSelectSql3.close();
		psSelectSql4.close();
		psSelectSql5.close();
		psSelectSql6.close();
		psSelectSql7.close();
	}
	
	private void initAllDeductList(LoanAccount loanAccount) throws SQLException
	{
		//����ۿ�����
		initDeductList(loanAccount);
		//��ǰ����ۿ�����
		initAheadDeductList(loanAccount);
		//δ����������
		initFareDetailList(loanAccount);
		//δ��С΢��������
		initAcctFeeInfo(loanAccount);
		//����˻�Map
		initAccountInfoMap(loanAccount);
	}
	
	/*
	 * ��ʼ��һ�㻹������
	 * */
	private void initDeductList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<DeductData> deductdataList = new ArrayList<DeductData>();
		
		psSelectSql1.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql1.executeQuery();
		while(rs.next())
		{
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("STerm"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo(rs.getString("DeductAccNo"));
			deductData.setPayDate(rs.getString("PayDate"));
			deductdataList.add(deductData);		
		}
		rs.close();

		loanAccount.setDeductdataList(deductdataList);
	}

	/*
	 * ��ʼ����ǰ����ۿ�����
	 * */
	private void initAheadDeductList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<AheadDeductData> aheadDeductdataList = new ArrayList<AheadDeductData>();
		
		psSelectSql2.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql2.executeQuery();
		while(rs.next())
		{
			AheadDeductData aheadDeductData = new AheadDeductData();
			aheadDeductData.setPutOutNo(rs.getString("PutOutNo"));
			aheadDeductData.setPayDate(rs.getString("PayDate"));
			aheadDeductData.setCurrency(rs.getString("Currency"));
			aheadDeductData.setDeductAccNo(rs.getString("DeductAccNo"));
			aheadDeductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			aheadDeductData.setActualCurrentCorp(0);
			aheadDeductData.setPayInte(rs.getDouble("PayInte"));
			aheadDeductData.setActualInte(0);
			aheadDeductData.setPayPoundage(rs.getDouble("PayPoundage"));
			aheadDeductData.setActualPoundage(0);
			aheadDeductData.setChangeSerialNo(rs.getString("ChangeSerialNo"));
			aheadDeductData.setDeductDate(deductDate);
			aheadDeductdataList.add(aheadDeductData);
		}
		rs.close();
		
		loanAccount.setAheadDeductdataList(aheadDeductdataList);
	}

	/*
	 * ��ʼ����������
	 * */
	private void initFareDetailList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<FareDetaill> fareDetailList = new ArrayList<FareDetaill>();
		
		psSelectSql3.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql3.executeQuery();
		while(rs.next())
		{
			FareDetaill fareDetail = new FareDetaill();
			fareDetail.setPutOutNo(rs.getString("PutOutNo"));
			fareDetail.setPayDate(rs.getString("PayDate"));
			fareDetail.setCurrency(rs.getString("Currency"));
			fareDetail.setPayMoney(rs.getDouble("PayMoney")-rs.getDouble("ActualMoney"));
			fareDetail.setActualMoney(0);
			fareDetailList.add(fareDetail);
		}
		rs.close();
		
		loanAccount.setFareDetailList(fareDetailList);
		//���޸Ĳ����������ݣ����ֻ�з���(ҵ���ϲ�����֣���ΪС���Ŀۿ�˳���Ǳ���->��Ϣ->���𣬵���400�Ķ��̲߳������ƻᵼ��������ǧ����ʱ������ȿ۱�����Ϣ�����)����
		//��deductDateListû�����ݣ���Ҫ��������ã��ӷ��ö�Ӧ���ڴμ��ϡ�modify dxu1 2011-05-17
		dealFareList(loanAccount,connection);
	}
	//С΢����
	private void initAcctFeeInfo(LoanAccount loanAccount) throws SQLException{
		ArrayList<AcctFeeInfoBatch> acctFeeInfoList = new ArrayList<AcctFeeInfoBatch>();
		psSelectSql7.setString(1, loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql7.executeQuery();
		while(rs.next()){
			AcctFeeInfoBatch acctFeeInfoBatch = new AcctFeeInfoBatch();
			acctFeeInfoBatch.setSerialNo(rs.getString("SerialNo"));
			acctFeeInfoBatch.setObjectNo(rs.getString("ObjectNo"));
			acctFeeInfoBatch.setPayDate(rs.getString("PayDate"));
			acctFeeInfoBatch.setPayMoney(rs.getDouble("PayMoney")-rs.getDouble("ActualMoney"));
			acctFeeInfoBatch.setCurrency(rs.getString("Currency"));
			acctFeeInfoBatch.setFeeAccountNo(rs.getString("FeeAccountNo"));
			acctFeeInfoBatch.setActualMoney(0);
			acctFeeInfoList.add(acctFeeInfoBatch);
		}
		rs.close();
		loanAccount.setAcctFeeInfoList(acctFeeInfoList);
		
		dealAcctFeeInfoList(loanAccount,connection);
	}
	/*
	 * ��ʼ������˻�
	 * */
	private void initAccountInfoMap(LoanAccount loanAccount) throws SQLException
	{
		HashMap<String,DeductAccountInfo> accountInfoMap = new HashMap<String,DeductAccountInfo>();
		
		psSelectSql4.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql4.executeQuery();
		while(rs.next())
		{
			//������ʽ��˻�
			accountInfoMap.put("DeductAccNo",new DeductAccountInfo("DeductAccNo",rs.getString("deductAccNo")));
			accountInfoMap.put("DeductAccNo1",new DeductAccountInfo("DeductAccNo1",rs.getString("deductAccNo1")));
			accountInfoMap.put("DeductAccNo2",new DeductAccountInfo("DeductAccNo2",rs.getString("deductAccNo2")));
			
			//400�м��˻�
			String sRelativeAccNo = "";
			try
			{
				//������ICS�����ʻ�
				if("SDB".equals(rs.getString("BankFlag"))){
					sRelativeAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),AccountConstants.RCPM_ICS_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type_ICS);
				}else{
					//������FCR�����ʻ�
					sRelativeAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),AccountConstants.Ahead_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type);
				}
			}
			catch(Exception ex)
			{
				sRelativeAccNo = "";
			}
			accountInfoMap.put("RelativeAccNo",new DeductAccountInfo("RelativeAccNo",sRelativeAccNo));
			
			/*//ί�д��������ȫ��
			String sOrgTrustAccNo = "";*/
			/*try
			{
				sOrgTrustAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),BatchConstant.ACCOUNT_NAME_4060102,rs.getString("Currency"),AccountConstants.Org_Save_Type);
			}
			catch(Exception ex)
			{
				sOrgTrustAccNo = "";
			}
			accountInfoMap.put("OrgTrustAccNo",new DeductAccountInfo("OrgTrustAccNo",sOrgTrustAccNo));*/
			
			//������ѧ������Ϣ�˻�
			String sDsInteAccNo = "";
			try
			{
			//	logger.info("====XINX=== "+rs.getString("putoutno")+"===="+rs.getString("DisDate").compareTo(deductDate)+"==="+deductDate+"====="+rs.getString("DisDate"));
				if("1150020".equalsIgnoreCase(rs.getString("BusinessType")) && rs.getString("DisDate").compareTo(deductDate)>=0){
					sDsInteAccNo = OrgInfoConfig.getAccountNo(rs.getString("orgID"),AccountConstants.Student_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type_Student);
				}else{
					sDsInteAccNo = rs.getString("deductAccNo");
				}
			}
			catch(Exception ex)
			{
				sDsInteAccNo = "";
			}
			accountInfoMap.put("DsInteAccNo",new DeductAccountInfo("DsInteAccNo",sDsInteAccNo));		
			
			
			//ί�����ʽ�
			String sTrustorAccNo = rs.getString("TrustAccNo");
			accountInfoMap.put("TrustorAccNo",new DeductAccountInfo("TrustorAccNo",sTrustorAccNo));
			String sTrustBankAccNo = "";
			
			psSelectSql5.setString(1,loanAccount.getSPutOutNo());
			ResultSet rsTmp = psSelectSql5.executeQuery();
			if(rsTmp.next())
			{
				sTrustBankAccNo = rsTmp.getString("TrustBankNo");
			}
			rsTmp.close();
			accountInfoMap.put("TrustBankAccNo",new DeductAccountInfo("TrustBankAccNo",sTrustBankAccNo));
			
			//������ȡ�˺�(ĿǰPAB��FCR��ICS���ɻ���SDBֱ���뱣���ʻ�)
			String sXBFareAccNo = "";
			try{
				//ȡ ������FCR�ݹҿ�Ŀ(����������)
				String fcr_icsNo = OrgInfoConfig.getGjjNo("1",AccountConstants.XB_FCR,rs.getString("Currency"),AccountConstants.Org_Account_Type_XB_FCR);
				//ICS����ר��
				String XBAccount = OrgInfoConfig.getGjjNo("200580001",AccountConstants.XB_ICS_BF,rs.getString("Currency"),AccountConstants.Org_Account_Type_XB_ICS_BF);
				if("SDB".equals(rs.getString("BankFlag"))){
					sXBFareAccNo = XBAccount;
				}else{
					sXBFareAccNo = fcr_icsNo;
				}
			}catch(Exception ex)
			{
				sXBFareAccNo = "";
			}
			accountInfoMap.put("XBFareAccNo",new DeductAccountInfo("XBFareAccNo",sXBFareAccNo));
			
			//���ÿ����������˻�
			String sCreditCardFAccNo = "";
			try
			{
				sCreditCardFAccNo = OrgInfoConfig.getAccountNo("100200",AccountConstants.CREDIT_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Credit_Type);
			}
			catch(Exception ex)
			{
				sCreditCardFAccNo = "";
			}
			accountInfoMap.put("CreditCardFAccNo",new DeductAccountInfo("CreditCardFAccNo",sCreditCardFAccNo));
			
			
		}
		rs.close();
		
		loanAccount.setAccountInfoMap(accountInfoMap);
	}
	
	
	

	
	/**
	 * ��ѯ����PAB��SDB�����ֱ�־
	 * @param  PutOutNo
	 * @return sBankFlag
	 * @throws Exception
	 */
	public String selectBankFlag(String ObjectNo)throws Exception{
		String sBankFlag="";
		String sSql=" select bc.bankflag From business_contract bc where bc.serialno in(select lr.objectno From lawcase_relative lr where lr.relativeserialno " +
				  " =(select serialno From law_case lc where lc.serialno =(select objectno From account_receivable ar where ar.serialno= ?))) ";
		PreparedStatement ps = connection.prepareStatement(sSql);
		ps.setString(1, ObjectNo);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			sBankFlag = rs.getString("bankflag");
		}
		ps.close();
		rs.close();
		return sBankFlag;
	}
/*	
	*//**
	 * ���ַǴ���źʹ����
	 * @param  sPutOutNo
	 * @return sDudectAccNo2
	 *//*
	public String checkDudectAccNo2(String sPutOutNo,PamsAs400 pamsAs400)throws Exception{
		String sDeductAccno2="",sAccFlag="";
		PreparedStatement psSql=connection.prepareStatement(" select lb.deductaccno from loan_balance lb where lb.putoutno='"+sPutOutNo+"' ");
		ResultSet rs1= psSql.executeQuery();
		while(rs1.next())
		{
			sDeductAccno2=rs1.getString("deductaccno");
			if(!sDeductAccno2.equals(pamsAs400.getSDudectAccNo())){
				sAccFlag="1";//�Ǵ��
			}else{
				sAccFlag="2";//���
			}
		}
		rs1.close();
		psSql.close();
		return sAccFlag;
	}*/
	
}