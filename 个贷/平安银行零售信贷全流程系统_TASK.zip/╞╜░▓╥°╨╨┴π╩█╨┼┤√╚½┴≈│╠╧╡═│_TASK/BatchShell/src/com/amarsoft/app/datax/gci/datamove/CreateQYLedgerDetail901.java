package com.amarsoft.app.datax.gci.datamove;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateQYLedgerDetail901 extends CommonExecuteUnit  {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");

				logger.info("................��ʼ���ɷ�����ҵ�����ݣ�.............");
				InsertLedgerDetail();
				logger.info("................���ɷ�����ҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void initData() {
		commitNum = getProperty("commitNum", 1);
	}
	
	public void InsertLedgerDetail() throws SQLException{
		String al=" insert into qy_ledger_detail_901(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno)    "
				+"  select lg.putoutno,'' as BILLNO ,999998 as TRANSID,99 as SORTID,'' as OCCURTIME,'2012/09/01' as OCCURDATA,lg.currency,lg.subjectno,   "
				+"  lg.creditbalance ,lg.debitbalance,'1' as HANDSTATUS,lg.orgid,'DM901'||lg.putoutno||SEQ_CLEAN.NEXTVAL  as serialno    "
				+"  from ledger_general lg where (lg.creditbalance<>0 or lg.debitbalance<>0)   ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
		
	}
	
}
