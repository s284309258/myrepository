package com.amarsoft.app.datax.gci.deductacc;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateConsultStampFile extends CommonExecuteUnit{

	private String sFileUrl;	
	

	public int execute() {
			
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{	
					logger.info("����OF����ӡ��˰�ļ�......");
					sFileUrl=getProperty("FileUrl");
					CreateFile();
					logger.info("����OF����ӡ��˰�ļ���ɣ�");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
	}
	
	public void CreateFile() throws IOException, SQLException, ParseException
	{
		String sDate = DateTools.getStringDate(deductDate);
		
		String sFName = sFileUrl+"/STAMPTAX_"+sDate+".dat";
		FileWriter fw = new FileWriter(sFName);
		
		String selectSql1 = " select OrgID,ConsultAmount from Consult_stamp where ConsultDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql1 =  connection.prepareStatement(selectSql1);
		ResultSet rs1 = psSelectSql1.executeQuery();
		while(rs1.next())
		{
			String sWriteFileRow = "10|"+rs1.getString("OrgID")+"|"+rs1.getDouble("ConsultAmount")+"|"+"\n";
			fw.write(sWriteFileRow);
		}
		psSelectSql1.close();
		rs1.getStatement().close();
		
		String selectSql2 = " select count(*) as icount,sum(ConsultAmount) as sumAmount,'"+sDate+"' as ConsultDate from Consult_stamp where ConsultDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql2 =  connection.prepareStatement(selectSql2);
		ResultSet rs2 = psSelectSql2.executeQuery();
		while(rs2.next())
		{
			String sWriteFileRow = "20|"+rs2.getInt("icount")+"|"+rs2.getDouble("sumAmount")+"|"+rs2.getString("ConsultDate")+"|"+"\n";
			fw.write(sWriteFileRow);
		}
		psSelectSql2.close();
		rs2.getStatement().close();
		fw.close();
	}
	
	
}
