package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.BatchRecallIsLocale;
import com.amarsoft.app.datax.gci.CallInfoConfigCodeRe;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class BatchReCall extends CommonExecuteUnit{

	private int commitNum ;
	private int iSerialcount = 0;
	private int iTaskSerialcount = 0;
	private int dealNumLoacle = 0;
	private int icountLocale = 0;
	//���ֳ�����List
	private ArrayList<CallInfoConfigCodeRe> callConfigListNotLocale = new ArrayList<CallInfoConfigCodeRe>();
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				if(nextDate.equals(nextMonth+"/01"))
					{
					connection.setAutoCommit(false);
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					initConfig();
					
					logger.info("��ʼ���Call_Info��FLOW_TASK��FLOW_OBJECT����������������......");
					String sDate = DateTools.getStringDate(nextDate);
					Statement stmt=connection.createStatement();
					String sTaskSerialNo = "B"+sDate+"%";
					stmt.execute("delete from Call_Info where InputDate = '"+nextDate+"' ");
					stmt.execute("delete from FLOW_TASK where SerialNo like '"+sTaskSerialNo+"' and ObjectType = 'DHBackApply'");
					stmt.execute("delete from FLOW_OBJECT where InputUser = 'System' and InputDate = '"+nextDate+"' and ObjectType = 'DHBackApply' ");
					stmt.close();
					logger.info("���Call_Info��FLOW_TASK��FLOW_OBJECT������������������ɡ�");
					
					logger.info("��ʼ��������������......");
					firstReCall();
					otherReCall();
					updateNotLocaleDate();
					logger.info("��������������ɣ�");
					connection.commit();
					}
				else{
					logger.info("���ղ���Ҫִ����������ط�����");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/*
	 * �����ֳ�����ֳ����������,д��һ�����ֳ��ļ�¼
	 */ 
	private void updateNotLocaleDate() throws Exception {
		String initTaskSql1 = " insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName, "
							+ " PhaseNo,PhaseName,UserID) "
							+ " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql1 = connection.prepareStatement(initTaskSql1);
		
		String initTaskSql2 = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,PhaseNo, "
							+ " PhaseName,InputDate,InputUser,UserId) "
							+ " values(?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql2 = connection.prepareStatement(initTaskSql2);

		String isLocaleSql = " select ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag," +
							 " InputOrgid,CheckType,FormerlyCheckDate,isLocale" +
							 " from call_info" +
							 " where islocale = '1' and inputdate = '"+nextDate+"'";
		PreparedStatement psIsLocale = connection.prepareStatement(isLocaleSql);
		String insertIsNotLocale = " insert into Call_Info(SerialNo,ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag,InputOrgid,CheckType,FormerlyCheckDate,isLocale) "
						 + " values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertIsNotLocale = connection.prepareStatement(insertIsNotLocale);
		ResultSet rs = psIsLocale.executeQuery();
		while(rs.next()){
			String newSerialNo = createSerialNo();
			psInitTaskSql1  = insertTask(psInitTaskSql1,newSerialNo);
			psInitTaskSql2 = insertObject(psInitTaskSql2,newSerialNo);
			
			psInsertIsNotLocale.setString(1, newSerialNo);
			psInsertIsNotLocale.setString(2, rs.getString("ObjectType"));
			psInsertIsNotLocale.setString(3, rs.getString("ObjectNo"));
			psInsertIsNotLocale.setString(4, rs.getString("GuarantyType"));
			psInsertIsNotLocale.setString(5, nextDate);
			psInsertIsNotLocale.setString(6, rs.getString("Flag"));
			psInsertIsNotLocale.setString(7, rs.getString("HouseType"));
			psInsertIsNotLocale.setString(8, rs.getString("SchemeNo"));
			psInsertIsNotLocale.setString(9, "0");
			psInsertIsNotLocale.setString(10, rs.getString("InputOrgid"));
			psInsertIsNotLocale.setString(11, "020");
			psInsertIsNotLocale.setString(12, rs.getString("FormerlyCheckDate"));
			psInsertIsNotLocale.setString(13, "1");
			psInsertIsNotLocale.addBatch();
			icountLocale++;
			dealNumLoacle++;
			if(dealNumLoacle>=commitNum)
			{
				psInitTaskSql1.executeBatch();
				psInitTaskSql2.executeBatch();
				psInsertIsNotLocale.executeBatch();
				dealNumLoacle=0;
				logger.info("�Ѿ�����"+icountLocale+"�����ֳ��ط�����!");
			}	
		}
		psInitTaskSql1.executeBatch();
		psInitTaskSql2.executeBatch();
		psInsertIsNotLocale.executeBatch();
		psIsLocale.close();
		psInitTaskSql1.close();
		psInitTaskSql2.close();
		psInsertIsNotLocale.close();
		rs.close();
		dealNumLoacle=0;
		logger.info("�Ѿ�����"+icountLocale+"�����ֳ��ط�����!");
	}

	public PreparedStatement insertTask(PreparedStatement psInitTaskSql1,String sObjectNo) throws Exception
	{
		String sNewSerialNo = createTaskSerialNo();
		psInitTaskSql1.setString(1,sNewSerialNo);
		psInitTaskSql1.setString(2,"DHBackApply");
		psInitTaskSql1.setString(3,sObjectNo);
		psInitTaskSql1.setString(4,"0100");
		psInitTaskSql1.setString(5,"DHBackApply");
		psInitTaskSql1.setString(6,"DHBackFlow");
		psInitTaskSql1.setString(7,"����������");
		psInitTaskSql1.setString(8,"0010");
		psInitTaskSql1.setString(9,"���Ǽ�");
		psInitTaskSql1.setString(10,"System");
		psInitTaskSql1.addBatch();
		return psInitTaskSql1;
	}
	
	public PreparedStatement insertObject(PreparedStatement psInitTaskSql2,String sObjectNo) throws Exception
	{
		psInitTaskSql2.setString(1,"DHBackApply");
		psInitTaskSql2.setString(2,sObjectNo);
		psInitTaskSql2.setString(3,"0100");
		psInitTaskSql2.setString(4,"DHBackApply");
		psInitTaskSql2.setString(5,"DHBackFlow");
		psInitTaskSql2.setString(6,"����������");
		psInitTaskSql2.setString(7,"0010");
		psInitTaskSql2.setString(8,"���Ǽ�");
		psInitTaskSql2.setString(9,nextDate);
		psInitTaskSql2.setString(10,"System");
		psInitTaskSql2.setString(11,"System");
		psInitTaskSql2.addBatch();
		return psInitTaskSql2;
	}
	
	
	public void firstReCall() throws Exception
	{
		String insertSql = " insert into Call_Info(SerialNo,ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag,InputOrgid,CheckType,FormerlyCheckDate,isLocale,GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE, RULEVALUE, LABOURMEASURE, WHETHERMANAGE) "
			 + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		//String insertSql = " insert into Call_Info(SerialNo,ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag,InputOrgid,CheckType,FormerlyCheckDate,isLocale) "
			//			 + " values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String initTaskSql1 = " insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName, "
							+ " PhaseNo,PhaseName,UserID) "
							+ " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql1 = connection.prepareStatement(initTaskSql1);
		
		String initTaskSql2 = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,PhaseNo, "
							+ " PhaseName,InputDate,InputUser,UserId) "
							+ " values(?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql2 = connection.prepareStatement(initTaskSql2);
		
		String selectTemp = " select gi.GuarantyType,gi.HouseType,decode(gi.guarantytype,'020010',gi.confirmvalue,0) as confirmvalue  "
						+ " from Guaranty_Info gi,Guaranty_Relative gr "
						+ " where gi.GuarantyID = gr.GuarantyID and gr.objectno = ? and gr.ObjectType = 'CBContractApply'";
		PreparedStatement psSelectTemp = connection.prepareStatement(selectTemp);

		//��ѯbc����Ϣ
		String selectSql = " select bc.SerialNo,bc.SchemeNo,bc.BusinessSum,bc.BusinessType,bc.balance,bc.LoanTerm,bc.MainReturnType ,bc.wholeconfirmvalue" +
					" from business_contract bc" +
					" where not exists (select ObjectNo from Call_Info ci where ci.ObjectType = 'CBContractApply' and ci.objectno = bc.serialno) " +
					" and bc.FinishDate is null " +
					" and bc.Balance > 0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		
		//��ѯ��������,������������
		String loanbalanceTmp = " select min(lb.PutOutDate) as PutOutDate,max(lr.overdays) as overdays" +
						" from loan_balance lb,loanbalance_relative lr" +
						" where lb.putoutno = lr.putoutno" +
						" and lb.contractserialno = ?";
		PreparedStatement psLoanbalanceTmp = connection.prepareStatement(loanbalanceTmp);
		
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//��ͬ��
			String contractSerialNo = rs.getString("SerialNo");
			//��������
			String schemeNo = rs.getString("SchemeNo");
			//ҵ��Ʒ��
			String businessType = rs.getString("BusinessType");
			//������
			double businessSum = rs.getDouble("BusinessSum");
			//���ʽ
			String mainReturnType = rs.getString("MainReturnType");
			//��������
			int loanTerm = rs.getInt("LoanTerm");
			//�������
			double balance = rs.getDouble("balance");
			
			//��Ѻ�ﾻֵ
			double guarantyValue= rs.getDouble("wholeconfirmvalue");
			//��Ѻ���ֵ��ѯ�Լ�ȷ��
			//������³���
			double scale = 0;
			if(guarantyValue == 0){
				scale=0;
			}else{
				scale = (balance/guarantyValue)*100;
			}
			

			//��ѯ���������,��������.��������
			String putoutdate = "";
			int overdueDays = 0;
			psLoanbalanceTmp.setString(1, contractSerialNo);
			ResultSet rsLoanBalanceTmp = psLoanbalanceTmp.executeQuery();
			while(rsLoanBalanceTmp.next()){
				putoutdate = rsLoanBalanceTmp.getString("PutOutDate");
				overdueDays = rsLoanBalanceTmp.getInt("overdays");
			}
			rsLoanBalanceTmp.close();
			if(putoutdate == null || putoutdate.equals(""))
				continue;
			int loanYear = DateTools.getMonths(putoutdate.substring(0,7)+"/01",nextDate);
			ArrayList<BatchRecallIsLocale> batchRecallList = returnRecallPeriod(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays);
			
			//size���,������ʹ��ڶ���������迼��
			if(!checkListSize(batchRecallList)){
				continue;
			}
			//���ڼ��,�Լ��ֳ��ͷ��ֳ��ļ��
			BatchRecallIsLocale batchRecallIsLocale = checkList(batchRecallList,putoutdate,putoutdate);
			//////
			
			
			//���ж�����
			if(batchRecallIsLocale.getReturnPeriod() == 0 || batchRecallIsLocale.getCheckType() == null || batchRecallIsLocale.getCheckType().equals(""))
				continue;
			//���Ƶ��
			int callPeriod = batchRecallIsLocale.getReturnPeriod();
			String sGuarantyType = "";
			String sHouseType = "";
			double dConfirmValue = 0;
			
			psSelectTemp.setString(1,contractSerialNo);
			ResultSet rsTemp = psSelectTemp.executeQuery();
			/*String flag = "0";*/
			while(rsTemp.next())
			{
				/*flag = "1";*/
				if(dConfirmValue<rsTemp.getDouble("ConfirmValue"))
				{
					sGuarantyType = rsTemp.getString("GuarantyType");
					sHouseType = rsTemp.getString("HouseType");
					dConfirmValue = rsTemp.getDouble("ConfirmValue");
				}
			}
			rsTemp.close();
			String GUARANTYUPVALUE="";
			String GUARANTYTHISVALUE="";
			String UPESTIMATEDATE="";
			String RULEVALUE="";
			String LABOURMEASURE="";
			String WHETHERMANAGE="";
			String newSerialNo = createSerialNo();
			psInitTaskSql1  = insertTask(psInitTaskSql1,newSerialNo);
			psInitTaskSql2 = insertObject(psInitTaskSql2,newSerialNo);
			
			//�ֳ��ͷ��ֳ����ֿ��ܶ������ʱ��,ִֻ���ֳ���,Ȼ��ֵ1�����־,����ͳһ���·��ֳ�������
			if(batchRecallIsLocale.isSingle()){
				psInsertSql = setPs(psInsertSql,"010",contractSerialNo,sGuarantyType,sHouseType,businessType,schemeNo,newSerialNo,"1",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
			}else{
				if("010".equals(batchRecallIsLocale.getCheckType()))
				{
					psInsertSql = setPs(psInsertSql,"010",contractSerialNo,sGuarantyType,sHouseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
				}
				else
				{
					psInsertSql = setPs(psInsertSql,"020",contractSerialNo,sGuarantyType,sHouseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
				}
			}
			icountLocale++;
			dealNumLoacle++;
			
			if(dealNumLoacle>=commitNum)
			{
				psInsertSql.executeBatch();
				psInitTaskSql1.executeBatch();
				psInitTaskSql2.executeBatch();
				dealNumLoacle=0;
				logger.info("�Ѿ�����"+icountLocale+"���������!");
			}	
			
		}
		psInsertSql.executeBatch();
		psInitTaskSql1.executeBatch();
		psInitTaskSql2.executeBatch();
		rs.close();
		psInitTaskSql1.close();
		psInitTaskSql2.close();
		psInsertSql.close();
		psSelectTemp.close();
		psSelectSql.close();
		psLoanbalanceTmp.close();
		logger.info("�Ѿ�����"+icountLocale+"���������!");
		dealNumLoacle=0;
		
	}
	public void otherReCall() throws Exception
	{
		
		String insertSql = " insert into Call_Info(SerialNo,ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag,InputOrgid,CheckType,FormerlyCheckDate,isLocale,GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE, RULEVALUE, LABOURMEASURE, WHETHERMANAGE) "
		 + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		//String insertSql = " insert into Call_Info(SerialNo,ObjectType,ObjectNo,GuarantyType,InputDate,Flag,HouseType,SchemeNo,ViewFlag,InputOrgid,CheckType,FormerlyCheckDate,isLocale) "
			// + " values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String updateSql = " update Call_Info set ViewFlag = '0' where serialNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String initTaskSql1 = " insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName, "
			+ " PhaseNo,PhaseName,UserID) "
			+ " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql1 = connection.prepareStatement(initTaskSql1);

		String initTaskSql2 = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,PhaseNo, "
			+ " PhaseName,InputDate,InputUser,UserId) "
			+ " values(?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInitTaskSql2 = connection.prepareStatement(initTaskSql2);
		
		 String selectSql = " select ci.SerialNo as ciSerialNo,ci.checktype,bc.SerialNo,bc.SchemeNo,bc.BusinessSum,bc.Balance,lr.overdays," +
						   " bc.BusinessType,bc.LoanTerm,bc.MainReturnType," +
						   " bc.wholeconfirmvalue as GuarantyValue,min(lb.putoutdate) as PutOutDate,max(ci.EndDate) as EndDate," +
						   " ci.GUARANTYUPVALUE,ci.GUARANTYTHISVALUE,ci.UPESTIMATEDATE,ci.RULEVALUE,ci.LABOURMEASURE,ci.WHETHERMANAGE" +
						   " from Business_Contract bc,Call_info ci,Loanbalance_Relative lr,loan_balance lb" +
						   " where bc.SerialNo = ci.ObjectNo and ci.ObjectType = 'CBContractApply' and bc.Balance>0 " +
						   //" and gi.guarantyid = gr.guarantyid and gr.objecttype = 'CBContractApply'" +
						   //" and gr.objectno = bc.serialno" +
						   " and bc.serialno = lb.contractserialno" +
						   " and lb.putoutno = lr.putoutno " +
						   " and ci.ViewFlag = '1' and '"+nextDate+"'< bc.MaturityDate " +
						   " group by ci.checktype,ci.SerialNo,bc.SerialNo,bc.Balance,bc.SchemeNo,bc.BusinessSum,lr.overdays," +
						   " bc.BusinessType,bc.LoanTerm,bc.MainReturnType,bc.wholeconfirmvalue," +
						   " ci.GUARANTYUPVALUE,ci.GUARANTYTHISVALUE,ci.UPESTIMATEDATE,ci.RULEVALUE,ci.LABOURMEASURE,ci.WHETHERMANAGE";
		
		//beg by 2011-04-19 jxie   ��Ѻ��[��Ѻ��]����Ϣ,����ȡ��
		 String GuarantySql = " select gi.GuarantyType,gi.HouseType from Business_Contract  bc ,Guaranty_Relative gr,Guaranty_Info gi  " +
		    		          " where bc.serialno = gr.objectno  and gr.guarantyid = gi.guarantyid  " +
		    		          " and gr.objecttype = 'CBContractApply' and bc.serialno= ? ";
	    logger.info("������selectSql=:" + selectSql);
	    logger.info("ȡ��Ѻ����ϢGuarantySql=:" + GuarantySql);
		PreparedStatement psGuarantySql = connection.prepareStatement(GuarantySql);
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String endDate = rs.getString("EndDate");
			if(endDate==null || endDate.equals(""))
				continue;
			String sCheckType = rs.getString("checktype"); 
			//��ͬ���
			String contractSerialNo = rs.getString("SerialNo");
			psGuarantySql.setString(1, contractSerialNo);
			ResultSet rsGu = psGuarantySql.executeQuery();
			//ciSerialNo
			String ciSerialNo = rs.getString("ciSerialNo");
			//��������
			String schemeNo = rs.getString("SchemeNo");
			String guarantyType="",houseType="";
			int i=0;
			while(rsGu.next()){
			 i++;
			//��Ѻ������
			 guarantyType = DataConvert.toString(rsGu.getString("GuarantyType"));//update 2011-04-19  jxie
			//��������
			 houseType = DataConvert.toString(rsGu.getString("HouseType"));      //update 2011-04-19  jxie
			}
			if(i>=2){
				guarantyType="15";//15������ͬ���ж��ѺƷ,��־call_info����guarantyType�ֶ�ʹ��
			}
			rsGu.close();
			//ҵ��Ʒ��
			String businessType = rs.getString("BusinessType");
			//������
			double businessSum = rs.getDouble("BusinessSum");
			//���ʽ
			String mainReturnType = rs.getString("MainReturnType");
			//��������
			int loanTerm = rs.getInt("LoanTerm");
			//�������
			double balance = rs.getDouble("Balance");
			//��Ѻ���ֵ
			double sGuarantyValue = rs.getDouble("GuarantyValue");
			double guarantyValue = 0;
			//������³���
			double scale = 0;
			guarantyValue = sGuarantyValue;
			if(guarantyValue == 0){
				scale=0;
			}else{
				scale = (balance/guarantyValue)*100;
			}
			//���������,��������
			String putoutdate = rs.getString("PutOutDate");
			if(putoutdate == null || putoutdate.equals(""))
				continue;
			int loanYear = DateTools.getMonths(putoutdate.substring(0,7)+"/01",nextDate);
			//��������
			int overdueDays = rs.getInt("overdays");
			
			String sDate1 = endDate;
			String sDate2 = endDate;
			ArrayList<BatchRecallIsLocale> iReCallPeriodList = returnRecallPeriod(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays);
			//���ڼ��,�Լ��ֳ��ͷ��ֳ��ļ��
			BatchRecallIsLocale batchRecallIsLocale = checkList(iReCallPeriodList,sDate1,sDate2);
			String GUARANTYUPVALUE=rs.getString("GUARANTYUPVALUE");
			String GUARANTYTHISVALUE=rs.getString("GUARANTYTHISVALUE");
			String UPESTIMATEDATE=rs.getString("UPESTIMATEDATE");
			String RULEVALUE=rs.getString("RULEVALUE");
			String LABOURMEASURE=rs.getString("LABOURMEASURE");
			String WHETHERMANAGE=rs.getString("WHETHERMANAGE");
			String newSerialNo = createSerialNo();
			//���Ƶ��
			int callPeriod = batchRecallIsLocale.getReturnPeriod();
			
			//size���,������������迼��
			if(!checkListSize(iReCallPeriodList)){//�����ϼ�飬ɨ���Ƿ����෴���͵ļ���������
				if("010".equals(sCheckType)){
					//����Ƿ��з��ֳ��ļ���������
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate1, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
						psUpdateSql.setString(1,ciSerialNo);
						psUpdateSql.addBatch();
					}
				}else if("020".equals(sCheckType)){
					//����Ƿ����ֳ��ļ���������
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate2, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
						psUpdateSql.setString(1,ciSerialNo);
						psUpdateSql.addBatch();
					}
				}
				continue;
			}
			
			if(callPeriod == 0){//�����ϼ�飬ɨ���Ƿ����෴���͵ļ���������
				if("010".equals(sCheckType)){
					//����Ƿ��з��ֳ��ļ���������
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate1, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
						psUpdateSql.setString(1,ciSerialNo);
						psUpdateSql.addBatch();
					}
				}else if("020".equals(sCheckType)){
					//����Ƿ����ֳ��ļ���������
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate2, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
						psUpdateSql.setString(1,ciSerialNo);
						psUpdateSql.addBatch();
					}
				}
				continue;
			}
		
			psInitTaskSql1  = insertTask(psInitTaskSql1,newSerialNo);
			psInitTaskSql2 = insertObject(psInitTaskSql2,newSerialNo);
			
			//�ֳ��ͷ��ֳ����ֿ��ܶ������ʱ��,ִֻ���ֳ���,Ȼ���ֳ������ڸ�ֵ�����ֳ�
			if(batchRecallIsLocale.isSingle())
			{
				psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"1",callPeriod,sDate1, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
				
				psUpdateSql.setString(1,ciSerialNo);
				psUpdateSql.addBatch();
			}
			else{
				//String chrckType = batchRecallIsLocale.getCheckType();
				if("010".equals(batchRecallIsLocale.getCheckType()))
				{
					//��ʱ���ֳ���飬ɨ���Ƿ���������ֳ���������
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"1",callPeriod,sDate1, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					}else{
						psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate1, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					}
					psUpdateSql.setString(1,ciSerialNo);
					psUpdateSql.addBatch();
				}
				else if("020".equals(batchRecallIsLocale.getCheckType()))
				{
					boolean isInsert = insert020Check(schemeNo,businessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays,psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,putoutdate, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					if(isInsert){
						psInsertSql = setPs(psInsertSql,"010",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"1",callPeriod,sDate2, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					}else{
						psInsertSql = setPs(psInsertSql,"020",contractSerialNo,guarantyType,houseType,businessType,schemeNo,newSerialNo,"0",callPeriod,sDate2, GUARANTYUPVALUE, GUARANTYTHISVALUE, UPESTIMATEDATE,  RULEVALUE,  LABOURMEASURE, WHETHERMANAGE);
					}
					
					//<��ɨ���Ƿ����෴���͵ļ��>
					//<>��������������·��ֳ�Ϊ����ʾ
					
					psUpdateSql.setString(1,ciSerialNo);
					psUpdateSql.addBatch();
				}
			}
			icountLocale++;
			dealNumLoacle++;
			
			if(dealNumLoacle>=commitNum)
			{
				psInsertSql.executeBatch();
				psUpdateSql.executeBatch();
				psInitTaskSql1.executeBatch();
				psInitTaskSql2.executeBatch();
				dealNumLoacle=0;
				logger.info("�Ѿ�����"+icountLocale+"���ط�����!");
			}	
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		psInitTaskSql1.executeBatch();
		psInitTaskSql2.executeBatch();
		rs.close();
		psGuarantySql.close();
		psUpdateSql.close();
		psInitTaskSql1.close();
		psInitTaskSql2.close();
		psInsertSql.close();
		psSelectSql.close();
		dealNumLoacle=0;
		logger.info("�Ѿ�����"+icountLocale+"���ط�����!");
		icountLocale=0;
	}
	
	private boolean insert020Check(String schemeNo,String businessType,double businessSum,String mainReturnType,int loanTerm,double balance,double scale,int loanYear,int overdueDays,
			PreparedStatement ps,String sCheckType,String sContractNo,
			String sGuarantyType,String sHouseType,String sBusinessType,String sSchemeNo,
			String serialNo,String isLocale,int callPeriod,String putoutdate,String GUARANTYUPVALUE,
			String GUARANTYTHISVALUE,String UPESTIMATEDATE, String RULEVALUE,
			String LABOURMEASURE,String WHETHERMANAGE) throws Exception {
		boolean result = true;
		
		String sql = "SELECT COUNT(*) as icnt FROM CALL_INFO WHERE objectno = '"+sContractNo+"' AND enddate IS NULL AND checktype = '"+sCheckType+"'";
		PreparedStatement psSelectSql = connection.prepareStatement(sql);
		
		String sql1 = "SELECT max(enddate) as eDate FROM CALL_INFO WHERE objectno = '"+sContractNo+"' AND checktype = '"+sCheckType+"'";
		PreparedStatement psSelectSql1 = connection.prepareStatement(sql1);
		
		ResultSet rs = psSelectSql.executeQuery();
		//����м���������Ϊ�յģ�����������Ĳ���
		if(rs.next()){
			int icnt = rs.getInt("icnt");
			if(icnt>0)
				result = false;
			else{

				ResultSet rs1 = psSelectSql1.executeQuery();
				//����У�����enddate���Ƚ�
				String endDate = "";
				if(rs1.next()){
					 endDate = rs1.getString("eDate");
					 if(endDate==null || "".endsWith(endDate))
						 endDate = putoutdate;//���û�У��÷����������Ƚ�
				}
				rs1.close();
				
				ArrayList<BatchRecallIsLocale> iReCallPeriodList = returnRecallPeriodType(sCheckType,sSchemeNo,sBusinessType,businessSum,mainReturnType,loanTerm,balance,scale,loanYear,overdueDays);
				if(!checkListSize(iReCallPeriodList)) result = false;
				else{
					BatchRecallIsLocale batchRecallIsLocale = checkList(iReCallPeriodList,endDate,endDate);
					int iCallPeriod = batchRecallIsLocale.getReturnPeriod();
					if(iCallPeriod == 0)result =  false;
					else{
						result =  true;
					}
				}
			}
		}
		rs.close();
		psSelectSql.close();
		psSelectSql1.close();
		return result;
	}

	private ArrayList<BatchRecallIsLocale> returnRecallPeriodType(
			String checkType, String sSchemeNo,String sBusinessType,
			double dBusinessSum,String sRepayType,int iLoanTerm,
			double Balance,double Scale,int LoanYear,int OverdueDays) {
		ArrayList<BatchRecallIsLocale>  returnList = new ArrayList<BatchRecallIsLocale>();
		//���ѭ��
		for(int i=0;i<callConfigListNotLocale.size();i++)
		{
			CallInfoConfigCodeRe callInfoConfig = callConfigListNotLocale.get(i);
			if(!callInfoConfig.getBackCheckType().equalsIgnoreCase(checkType)) continue;
			//���������ж�����
			if(callInfoConfig.getSchemeNo()!=null && !isCheck(sSchemeNo,callInfoConfig.getSchemeNo()))
				continue;
			//ҵ��Ʒ���ж�����
			if(callInfoConfig.getBusinessType()!=null && !isCheck(sBusinessType,callInfoConfig.getBusinessType()))
				continue;
			//�������ж�����
			if(callInfoConfig.getMinAmount()!=0 && callInfoConfig.getMaxAmount()!=0)
			{
				if(dBusinessSum<callInfoConfig.getMinAmount()||dBusinessSum>callInfoConfig.getMaxAmount())
					continue;
			}
			//���ʽ�ж�����
			if(callInfoConfig.getRepayType()!=null && !isCheck(sRepayType,callInfoConfig.getRepayType()))
				continue;
			//���������ж�����
			if(callInfoConfig.getMinTerm() !=0 && callInfoConfig.getMaxTerm()!= 0)
			{
				if(iLoanTerm<callInfoConfig.getMinTerm()||iLoanTerm>callInfoConfig.getMaxTerm())
					continue;
			}
			//��������ж�����
			if(callInfoConfig.getMinBalance() != 0  && callInfoConfig.getMaxBalance() != 0 )
			{
				if(Balance <callInfoConfig.getMinBalance() || Balance > callInfoConfig.getMaxBalance())
					continue;
			}
      //���³����ж�����,�������ʱ��Ͳ������ж�
			if(callInfoConfig.getMinScale() != 0 && callInfoConfig.getMaxScale() != 0 )
			{
				if(Scale < callInfoConfig.getMinScale() || Scale > callInfoConfig.getMaxScale())
					continue;
			}
			
			//���������ж�����,��Ҫ�ж��Ƿ�����������
			if(LoanYear < callInfoConfig.getMinLoanYear()|| LoanYear > callInfoConfig.getMaxLoanYear())
				continue;
			
			//���������ж�����
			if(OverdueDays < callInfoConfig.getMinOverdueDay() || OverdueDays > callInfoConfig.getMaxOverdueDay())
				continue;
			
			//�������� 
			BatchRecallIsLocale recallIsLocale = new BatchRecallIsLocale();
			recallIsLocale.setReturnPeriod(callInfoConfig.getCallPeriod());
			recallIsLocale.setCheckType(callInfoConfig.getBackCheckType());
			
			returnList.add(recallIsLocale);
		}
		
		return returnList;
	
	}

	//��ʼ��ϵͳ������Ϣ
	public void initConfig() throws SQLException
	{
		/**
		 * ATTRIBUTE1 ATTRIBUTE1 ����������,ATTRIBUTE2 ��������,ATTRIBUTE3 ҵ��Ʒ��,ATTRIBUTE6 ���ʽ,ATTRIBUTE8 ���Ƶ��
		 * Attribute4 ����������,Attribute5 ����������,ATTRIBUTE7 ������������,ATTRIBUTE9 ������������
		 * ATTRIBUTE11 �����������,ATTRIBUTE12 �����������,ATTRIBUTE13 ���³�������
		 * ATTRIBUTE14 ���³�������,ATTRIBUTE15 ������������,ATTRIBUTE16 ������������
		 * ATTRIBUTE17 ������������,ATTRIBUTE18 ������������,CHECKTYPE �����鷽ʽ
		 */
		//�ֳ����
		String initSqlNotLoacle = " select SERIALNO,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,nvl(ATTRIBUTE6, 0) as ATTRIBUTE6," +
						 " ATTRIBUTE8,nvl(Attribute4, 0) as Attribute4,nvl(Attribute5, 0) as Attribute5 ,ATTRIBUTE7," +
						 " ATTRIBUTE9,nvl(ATTRIBUTE11,0) as ATTRIBUTE11,nvl(ATTRIBUTE12,0) as ATTRIBUTE12,nvl(ATTRIBUTE13,0) as ATTRIBUTE13," +
						 " nvl(ATTRIBUTE14,0) as ATTRIBUTE14,nvl(ATTRIBUTE15,0) as ATTRIBUTE15 ,nvl(ATTRIBUTE16,0) as ATTRIBUTE16," +
						 " nvl(ATTRIBUTE17,0) as ATTRIBUTE17,nvl(ATTRIBUTE18,0) as ATTRIBUTE18,CHECKTYPE" +
						 " from BACKBATCHMANAGE where isinuse = '1'";
		PreparedStatement psInitSqlNotLoacle = connection.prepareStatement(initSqlNotLoacle);
		ResultSet InitRsNotLoacle = psInitSqlNotLoacle.executeQuery();
		while(InitRsNotLoacle.next())
		{
			CallInfoConfigCodeRe callInfoConfig = new CallInfoConfigCodeRe();
			
			callInfoConfig.setSerialNo(InitRsNotLoacle.getString("SERIALNO"));
			callInfoConfig.setCheckType(InitRsNotLoacle.getString("ATTRIBUTE1"));
			callInfoConfig.setSchemeNo(InitRsNotLoacle.getString("ATTRIBUTE2"));
			callInfoConfig.setBusinessType(InitRsNotLoacle.getString("ATTRIBUTE3"));
			callInfoConfig.setMinAmount(InitRsNotLoacle.getDouble("Attribute4"));
			callInfoConfig.setMaxAmount(InitRsNotLoacle.getDouble("Attribute5"));
			callInfoConfig.setRepayType(InitRsNotLoacle.getString("ATTRIBUTE6"));
			callInfoConfig.setMinTerm(InitRsNotLoacle.getInt("ATTRIBUTE7"));
			callInfoConfig.setMaxTerm(InitRsNotLoacle.getInt("ATTRIBUTE9"));
			callInfoConfig.setCallPeriod(InitRsNotLoacle.getInt("ATTRIBUTE8"));
			callInfoConfig.setMinBalance(InitRsNotLoacle.getDouble("ATTRIBUTE11"));
			callInfoConfig.setMaxBalance(InitRsNotLoacle.getDouble("ATTRIBUTE12"));
			callInfoConfig.setMinScale(InitRsNotLoacle.getDouble("ATTRIBUTE13"));
			callInfoConfig.setMaxScale(InitRsNotLoacle.getDouble("ATTRIBUTE14"));
			callInfoConfig.setMinLoanYear(InitRsNotLoacle.getInt("ATTRIBUTE15"));
			callInfoConfig.setMaxLoanYear(InitRsNotLoacle.getInt("ATTRIBUTE16"));
			callInfoConfig.setMinOverdueDay(InitRsNotLoacle.getInt("ATTRIBUTE18"));
			callInfoConfig.setMaxOverdueDay(InitRsNotLoacle.getInt("ATTRIBUTE17"));
			callInfoConfig.setBackCheckType(InitRsNotLoacle.getString("CHECKTYPE"));
			
			callConfigListNotLocale.add(callInfoConfig);
		}
		InitRsNotLoacle.close();
		psInitSqlNotLoacle.close();
		
	}
	
	//�ж��������,ȷ���Ƿ�����ֳ������ֳ����Ĺ���,���ط��Ϲ����BatchRecallIsLocale�����List
	public ArrayList<BatchRecallIsLocale> returnRecallPeriod(String sSchemeNo,String sBusinessType,double dBusinessSum,String sRepayType,int iLoanTerm,double Balance,double Scale,int LoanYear,int OverdueDays)
	{
		
		ArrayList<BatchRecallIsLocale>  returnList = new ArrayList<BatchRecallIsLocale>();
		//���ѭ��
		for(int i=0;i<callConfigListNotLocale.size();i++)
		{
			CallInfoConfigCodeRe callInfoConfig = callConfigListNotLocale.get(i);
			//���������ж�����
			if(callInfoConfig.getSchemeNo()!=null && !isCheck(sSchemeNo,callInfoConfig.getSchemeNo()))
				continue;
			//ҵ��Ʒ���ж�����
			if(callInfoConfig.getBusinessType()!=null && !isCheck(sBusinessType,callInfoConfig.getBusinessType()))
				continue;
			//�������ж�����
			if(callInfoConfig.getMinAmount()!=0 && callInfoConfig.getMaxAmount()!=0)
			{
				if(dBusinessSum<callInfoConfig.getMinAmount()||dBusinessSum>callInfoConfig.getMaxAmount())
					continue;
			}
			//���ʽ�ж�����
			if(callInfoConfig.getRepayType()!=null && !isCheck(sRepayType,callInfoConfig.getRepayType()))
				continue;
			//���������ж�����
			if(callInfoConfig.getMinTerm() !=0 && callInfoConfig.getMaxTerm()!= 0)
			{
				if(iLoanTerm<callInfoConfig.getMinTerm()||iLoanTerm>callInfoConfig.getMaxTerm())
					continue;
			}
			//��������ж�����
			if(callInfoConfig.getMinBalance() != 0  && callInfoConfig.getMaxBalance() != 0 )
			{
				if(Balance <callInfoConfig.getMinBalance() || Balance > callInfoConfig.getMaxBalance())
					continue;
			}
//			//���³����ж�����,�������ʱ��Ͳ������ж�
//			if(callInfoConfig.getMinScale() != 0 && callInfoConfig.getMaxScale() != 0 )
//			{
//				if(Scale < callInfoConfig.getMinScale() || Scale > callInfoConfig.getMaxScale())
//					continue;
//			}
			
			//���������ж�����,��Ҫ�ж��Ƿ�����������
			if(LoanYear < callInfoConfig.getMinLoanYear()|| LoanYear > callInfoConfig.getMaxLoanYear())
				continue;
			
			//���������ж�����
			if(OverdueDays < callInfoConfig.getMinOverdueDay() || OverdueDays > callInfoConfig.getMaxOverdueDay())
				continue;
			
			//�������� 
			BatchRecallIsLocale recallIsLocale = new BatchRecallIsLocale();
			recallIsLocale.setReturnPeriod(callInfoConfig.getCallPeriod());
			recallIsLocale.setCheckType(callInfoConfig.getBackCheckType());
			
			returnList.add(recallIsLocale);
		}
		
		return returnList;
	}
	
	//List���ȼ��,�������е����
	private boolean checkListSize(ArrayList<BatchRecallIsLocale> oldList)
	{
		int listSize = oldList.size();
		if(listSize>0 && listSize <=2)
			return true;
		else if(listSize ==0)
			return false;
		else
			return false;
	}
	
	/*
	 * ����������LIST,�����жϸô�������Ƿ���Ҫ���
	 * */
	private BatchRecallIsLocale checkList(ArrayList<BatchRecallIsLocale> oldList, String sDate1,String sDate2) throws Exception
	{
		ArrayList<BatchRecallIsLocale> newList = new ArrayList<BatchRecallIsLocale>();
		BatchRecallIsLocale returnBatchRecallIsLocale = new BatchRecallIsLocale();
		
		//�жϴ���date�������� �Ƿ���ڵ��ڼ��Ƶ��
		for(int i=0;i<oldList.size();i++)
		{
			BatchRecallIsLocale batchRecallIsLocale = oldList.get(i);
			String sCheckType = batchRecallIsLocale.getCheckType();
			int iPeriod = batchRecallIsLocale.getReturnPeriod();
			
			String sCheckDate = "";
			try{
				//�ֳ�����
				if("010".equals(sCheckType))
					sCheckDate = sDate1;
				//���ֳ�����
				else if("020".equals(sCheckType))
					sCheckDate = sDate2;
				else
					throw new Exception("���Ƿ��ϵļ������");
					
				if(DateTools.getMonths(sCheckDate.substring(0,7)+"/01",nextDate)>=iPeriod)
				{
					newList.add(batchRecallIsLocale);
				}		
			}catch(Exception e){
				errorRecord("","checkType����010��020��,������ñ�BackBatchManage��CheckType");
			}
				
		}
		
		//�жϵ���Ļط��Ƿ� �Ȱ����ֳ�,Ҳ�������ֳ�
		if(newList.size()==2)
		{
			for(int i=0;i<newList.size();i++)
			{
				BatchRecallIsLocale batchRecallIsLocale2 = newList.get(i);
				//ҵ�����,�����ֳ������ֳ���Ϊ׼
				if("010".equals(batchRecallIsLocale2.getCheckType()))
				{
					batchRecallIsLocale2.setSingle(true);
					returnBatchRecallIsLocale = batchRecallIsLocale2;
				}
				//����Ϊ2�����Ҳ�Ϊ�ֳ��ͷ��ֳ����У�һ��Ϊ���ֳ�����������������Ϊ���ֳ���
				if(i==1 && (returnBatchRecallIsLocale.getCheckType() == null || returnBatchRecallIsLocale.getCheckType().equals(""))){
					returnBatchRecallIsLocale = batchRecallIsLocale2;
				}
			}
		}
		//ֻ��һ�����
		else if(newList.size()==1)
		{
			BatchRecallIsLocale batchRecallIsLocale2 = newList.get(0);
			batchRecallIsLocale2.setSingle(false);
			returnBatchRecallIsLocale = batchRecallIsLocale2;
		}else{
			//����2�����ȵ���������м�飬��Ƶ������Ϊ0���Ա���
			returnBatchRecallIsLocale.setReturnPeriod(0);
		}
		
		return returnBatchRecallIsLocale;
	}
	
	
	//�жϼ������
	private boolean isCheck(String check,String checkList)
	{
		String[] singleCheckList = checkList.split("@");
		for(int i=0;i<singleCheckList.length;i++)
		{
			if(singleCheckList[i].equalsIgnoreCase(check))
			{
				return true;
			}
		}
		return false;
		
	}
	
	//�������,�õ�����������
	private String getCheckType(String sSchemeNo,String sBusinessType)
	{
		if("001".equals(sSchemeNo))
		{
			return "010";
		}
		else if("1110080".equals(sBusinessType))
		{
			return "020";
		}
		else
		{
			return "030";
		}
	}
	
	public String createSerialNo() throws Exception
	{
		iSerialcount++;
		String sDate = DateTools.getStringDate(nextDate);
		String sSortNo = NumberTools.lPad(iSerialcount,8,'0');
		return "B"+sDate+sSortNo;
	}
	
	public String createTaskSerialNo() throws Exception
	{
		iTaskSerialcount++;
		String sDate = DateTools.getStringDate(nextDate);
		String sSortNo = NumberTools.lPad(iTaskSerialcount,8,'0');
		return "B"+sDate+sSortNo;
	}
	
	//�����¼
	public void errorRecord(String sNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sNo);
		batchErrorRecord.setObjectType("BusinessContract");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
	
	//set CALL_INFO��
	private PreparedStatement setPs(PreparedStatement ps,String sCheckType,String sContractNo,String sGuarantyType,String sHouseType,String sBusinessType,String sSchemeNo,String serialNo,String isLocale,int callPeriod,String putoutdate,String GUARANTYUPVALUE,String GUARANTYTHISVALUE,String UPESTIMATEDATE, String RULEVALUE, String LABOURMEASURE,String WHETHERMANAGE) throws Exception
	{
		ps.setString(1,serialNo);
		ps.setString(2,"CBContractApply");
		ps.setString(3,sContractNo);
		ps.setString(4,sGuarantyType);
		ps.setString(5,nextDate);
		ps.setString(6,"020");
		ps.setString(7,sHouseType);
		String newSchemeNo = getCheckType(sSchemeNo,sBusinessType);
		ps.setString(8,newSchemeNo);
		ps.setString(9,"1");
		ps.setString(10,"System");
		ps.setString(11,sCheckType);
		String formerlyCheckDate = DateTools.getRelativeDate(putoutdate, "M", callPeriod);
		ps.setString(12,formerlyCheckDate);
		ps.setString(13,isLocale);
		
		ps.setString(14,GUARANTYUPVALUE);
		ps.setString(15,GUARANTYTHISVALUE);
		ps.setString(16,UPESTIMATEDATE);
		ps.setString(17,RULEVALUE);
		ps.setString(18,LABOURMEASURE);
		ps.setString(19,WHETHERMANAGE);
		ps.addBatch();
		return ps;
	}
}
