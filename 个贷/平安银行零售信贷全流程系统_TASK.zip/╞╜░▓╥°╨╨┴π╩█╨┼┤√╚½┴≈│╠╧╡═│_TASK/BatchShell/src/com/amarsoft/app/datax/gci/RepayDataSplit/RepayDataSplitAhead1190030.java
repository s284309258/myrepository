package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;

public class RepayDataSplitAhead1190030 extends BasicRepayDataSplit {

	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		/*//���л�����ȫ��
		String OrgTrustAccNo = accountMap.get("OrgTrustAccNo").getAccountNo();*/
		//ί�����ʽ�
		String TrustorAccNo = accountMap.get("TrustorAccNo").getAccountNo();
		//ί����ί�л�
		String TrustBankAccNo = accountMap.get("TrustBankAccNo").getAccountNo();
		
		for(int i=0;i<aheadDeductdataList.size();i++)
		{
			AheadDeductData aheadDeductData = aheadDeductdataList.get(i);
			//��ǰ������
			String DeductSerialNo = createDeductSerialNo();
			//��Ϣ
			double inteAmount = returnAheadInte(aheadDeductData);
			if(inteAmount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),inteAmount,
						aheadDeductData.getDeductAccNo(),TrustorAccNo,DeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_AHEADINTE,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				
				pamsAs400ArrayList.add(pamsAs400);
			}
			
			//����
			double corpAmount = returnAheadCorp(aheadDeductData);
			if(corpAmount>0)
			{
				//�ͻ������ʽ��˻� --> ��400������
				PamsAs400 pamsAs400_1 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),corpAmount,
						aheadDeductData.getDeductAccNo(),RelativeAccNo,DeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_AHEADCORP,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				/*//���л�����ȫ�� --> ί����ί�л�
				PamsAs400 pamsAs400_2 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),corpAmount,
						OrgTrustAccNo,TrustBankAccNo,DeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_TRUN,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");*/
				//ί����ί�л� --> ί�����ʽ�
				PamsAs400 pamsAs400_2 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),corpAmount,
						TrustBankAccNo,TrustorAccNo,DeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_TRUN,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				
				pamsAs400ArrayList.add(pamsAs400_1);
				pamsAs400ArrayList.add(pamsAs400_2);
			}
			

		}
		
		return pamsAs400ArrayList;
	}

	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		String sPutOutNo = aheadDeductdataList.get(0).getPutOutNo();
		boolean dReturn = true;
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		if(DeductAccNo == null||DeductAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
			dReturn = false;
		}
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		if(RelativeAccNo==null||RelativeAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
			dReturn = false;
		}
		//���л�����ȫ��
		/*
		String OrgTrustAccNo = accountMap.get("OrgTrustAccNo").getAccountNo();
		if(OrgTrustAccNo==null||OrgTrustAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д������л�����ȫ�������ڣ�");
			dReturn = false;
		}
		*/
		//ί�����ʽ�
		String TrustorAccNo = accountMap.get("TrustorAccNo").getAccountNo();
		if(TrustorAccNo==null||TrustorAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д���ί�����ʽ𻧲����ڣ�");
			dReturn = false;
		}
		//ί����ί�л�
		String TrustBankAccNo = accountMap.get("TrustBankAccNo").getAccountNo();
		if(TrustBankAccNo==null||TrustBankAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д���ί����ί�л������ڣ�");
			dReturn = false;
		}
		return dReturn;
	}


}
