package com.amarsoft.app.datax.gci.deductdata;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.CalInterest;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;

public class BatchAheadDeductData extends CommonExecuteUnit{
	
	private int commitNum ;
	private int deductNum = 0;
	private int icount = 0;
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','AHEAD_DEDUCT_DATA') ";
				logger.info("���AHEAD_DEDUCT_DATA:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("�����ǰ�����������ݱ�AHEAD_DEDUCT_DATA������� ");
				psDelSql.close();
				
				logger.info("������ǰ������������......");
				insertAheadDeductData();
				logger.info("��������ǰ������������"+icount+"���� ");
				logger.info("������ǰ��������������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}  	
		
	}
	
	public boolean checkColnameValue(String sColName,String sNewValue)
	{
		if(sColName.equalsIgnoreCase("BillKind"))
		{
			if(!sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_ALL) && !sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_HINGT) && !sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_LOW))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("CorpType"))
		{
			if(!sNewValue.equalsIgnoreCase(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS) && !sNewValue.equalsIgnoreCase(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS_INTEREST))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("AheadCorp"))
		{
			double dAheadCorp = Double.parseDouble(sNewValue);
			if(dAheadCorp<=0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("AheadTerm"))
		{
			int iAheadTerm = Integer.parseInt(sNewValue);
			if(iAheadTerm<=0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("PayPoundage"))
		{
			double dPayPoundage = Double.parseDouble(sNewValue);
			if(dPayPoundage<0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return false;
		}
	}

	
	public void insertAheadDeductData() throws Exception
	{
				
		String insertSql = " INSERT INTO Ahead_Deduct_Data(ChangeSerialNo,PutOutNo,STerm,Currency,Term, "
			      + " DeductAccNo,DeductAccNo1,DeductAccNo2,PayCurrentCorp,PayInte,PayPoundage,DealFlag,Payfareamount,Paydate) "
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select ObjectNo,ChangeSerialNo, "
			      + " max(decode(colname,'BillKind',newvalue,null)) as BillKind, "
			      + " max(decode(colname,'CorpType',newvalue,null)) as CorpType, "
			      + " max(decode(colname,'AheadCorp',newvalue,0)) as AheadCorp, "
			      + " max(decode(colname,'AheadTerm',newvalue,0)) as AheadTerm, "
			      + " max(decode(colname,'Poundage',newvalue,0)) as PayPoundage, "
			      + " max(decode(colname,'DeductAccNo',newvalue,null)) as DeductAccNo "
			      + " from Loan_Change "
			      + " where ChangeDate = '"+deductDate+"' and ChangeType = '"+BatchConstant.CHANGE_TYPE_AHEADPAY+"' and Status='1' "
			      + " group by ObjectNo,ChangeSerialNo "
			      + " order by ChangeSerialNo ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		//�жϻ��ʽ  ���ռ�Ȩ���⴦����
		String selectLoan="select lb.mainreturntype,lb.analyspar from loan_balance lb where lb.putoutno=?";
		PreparedStatement psSelectLoan = connection.prepareStatement(selectLoan);
		while(rs.next())
		{
			if(!checkColnameValue("BillKind",rs.getString("BillKind")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"��ǰ��������BillKind����");
				continue;
			}
			if(!checkColnameValue("CorpType",rs.getString("CorpType")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"�������CorpType����");
				continue;
			}
			if(!checkColnameValue("AheadCorp",rs.getString("AheadCorp")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"������С�ڵ���0");
				continue;
			}
			if(!checkColnameValue("PayPoundage",rs.getString("PayPoundage")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"��ǰ����ΥԼ��С��0");
				continue;
			}
			
			String sPutOutNo = rs.getString("ObjectNo");
			String sChangeSerialNo = rs.getString("ChangeSerialNo");
			String sCorpType = rs.getString("CorpType");
			String sDeductAccNo = rs.getString("DeductAccNo");
			
			LoanBalance loanBalance = new LoanBalance();
			loanBalance.SetLoanBalance(sPutOutNo,connection);
			loanBalance.initLoanRateAlter(connection);
			//�����ǰ�����˻�Ϊ�գ���ʹ�ý��㻧
			if(sDeductAccNo != null && !"".equals(sDeductAccNo))
			{
				loanBalance.setDeDuctAccNo(sDeductAccNo);
			}
			
			double dSumAmount = rs.getDouble("AheadCorp");
			double dCorp = 0.0;
			double dInte = loanBalance.getPeriodInte();
				
			if(sCorpType.equals(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS)) 
				dCorp = dSumAmount;
			else 
				dCorp = NumberTools.round(dSumAmount - dInte,AccountConstants.MONEY_PRECISION);
				
			if(dCorp > loanBalance.getNormalBalance()) 
			{
				dCorp = loanBalance.getNormalBalance();//ȫ����ǰ����
				dInte = loanBalance.getPeriodInte();
			}
			
			int sAheadTerm = rs.getInt("AheadTerm");
			double  dPayPoundage = rs.getDouble("PayPoundage");
			
			if(dCorp==0)
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"�ñ���ǰ����ı���Ϊ0");
				continue;
			}
			double addSum=0.00d;//���ռ�Ȩ��� ��۲���
			String   sMainReturnType="";//���ʽ
			String  sAnalyspar= "";////���ռ�Ȩ����
			psSelectLoan.setString(1,sPutOutNo);
			ResultSet rs1 = psSelectLoan.executeQuery();
			if(rs1.next())		
			{
				sMainReturnType=rs1.getString("mainreturntype");
				sAnalyspar=rs1.getString("analyspar");
			}
			rs1.close();
			if(sMainReturnType.equals("21"))//���ռ�Ȩ���
			{
			  double dAnalyspar= DataConvert.toDouble(sAnalyspar);//���ռ�Ȩ����
			  addSum=(dCorp+dInte)*(dAnalyspar-1);//��۽� 
			  addSum=Double.parseDouble(NumberTools.numberFormat(addSum,0 ,2));
			}
            
			psInsertSql.setString(1,sChangeSerialNo);
			psInsertSql.setString(2,sPutOutNo);
			psInsertSql.setInt(3,loanBalance.getSTerm());
			psInsertSql.setString(4,loanBalance.getCurrency());
			psInsertSql.setInt(5,sAheadTerm);  
			psInsertSql.setString(6,loanBalance.getDeDuctAccNo());
			psInsertSql.setString(7,loanBalance.getDeDuctAccNo1());
			psInsertSql.setString(8,loanBalance.getDeDuctAccNo2());
			psInsertSql.setDouble(9,dCorp);
			psInsertSql.setDouble(10,dInte);
			psInsertSql.setDouble(11,dPayPoundage+addSum);
			psInsertSql.setString(12,BatchConstant.PAYAHEAD_DEALFLAG_FALSE);
			psInsertSql.setDouble(13,0);
			psInsertSql.setString(14,deductDate);
			psInsertSql.addBatch();
			deductNum++;
			icount++;
			
			if(deductNum>commitNum)
			{
				psInsertSql.executeBatch();
				deductNum=0;
				logger.info("�Ѳ�������"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		psSelectLoan.close();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		deductNum=0;
	}
	

	public void aheadErrorRecord(String sChangeSerialNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sChangeSerialNo);
		batchErrorRecord.setObjectType("LoanChange");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
}

