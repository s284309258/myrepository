package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.entity.OrgInfo;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.DepositLoanInfo;
import com.amarsoft.app.datax.gci.VipRate;
import com.amarsoft.task.TaskConstants;

/**
 * @author YUJIYU090
 * @title ��������ۺ��ʲ������ʸ�������
 */

public class BatchDepositLoanRelation extends CommonExecuteUnit{
	
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int serialCount = 0;
	private ArrayList<VipRate> vipRateConfigList = new ArrayList<VipRate>();
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip")){
				return TaskConstants.ES_SUCCESSFUL;
			}else{
				
				logger.info("ÿ�ո��½�ݽ���Ĵ������ΪʧЧ......");
				UpdateCancelData();
				logger.info("ÿ�ո��½�ݽ���Ĵ������ΪʧЧ��ɣ�");
				
				//ÿ��5�Ų�ִ�м���
				if(deductDate.substring(8,10).equals("05")){
					String sChangeType = BatchConstant.CHANGE_TYPE_RATEFLOAT;
					String sDate = DateTools.getStringDate(deductDate);
					String sChangeSerialNoHead = "R"+sDate+sChangeType;
					
					String delSql=" delete from Loan_Change where ChangeSerialNo like '"+sChangeSerialNoHead+"%' ";
					logger.info("��ʼ���loan_change�н��������������ʸ������ȱ������.....");
					PreparedStatement psDeleteData = connection.prepareStatement(delSql);
					psDeleteData.execute();
					logger.info("���loan_change�н��������������ʸ������ȱ���������! ");
					psDeleteData.close();
					
					logger.info("��������ͻ��ۺ��ʲ�����......");
					calcBalance();
					logger.info("��������ͻ��ۺ��ʲ�������ɣ�");
					
					logger.info("���������������ʸ������ȱ�����ݿ�ʼ......");
					InsertFloatRateChange();
					logger.info("���������������ʸ������ȱ��������ɣ�");
				}
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/**
	 * @author YUJIYU090
	 * ���´���״̬Ϊ����Ĵ������ΪʧЧ
	 * */
	public void UpdateCancelData() throws Exception{
		String sSql = "Update business_putout_relative bpr Set status = '050',CancelDate='"+deductDate+"' Where bpr.ObjectNo Is Null  And bpr.Status ='030' And Exists (Select 1 From loan_balance lb Where lb.putoutno = bpr.putoutno And lb.Finishdate = '"+deductDate+"' And lb.loanstatus Not In('0','1','4','5'))";
		PreparedStatement psUpdateSql = connection.prepareStatement(sSql);
		psUpdateSql.execute();
		psUpdateSql.close();
	}
	
	/**
	 * @author YUJIYU090
	 * С΢��������ͻ��ۺ��ʲ�����
	 * */
	public void calcBalance() throws Exception{
		
		//ȡ���µ����վ����ڣ����������Ϊÿ�µ�1��
		String sDate = currentMonth+"/01";
		
		//ȡȨ��������������ͬ���ʲ����ͣ�Ȩ�ز�ͬ
		HashMap<String, Double> deductAccnoType = new HashMap<String, Double>();
		String sSql = "Select itemno,attribute1 from Code_Library Where codeno='DeductAccnoType' And isinuse='1'";
		PreparedStatement ps = connection.prepareStatement(sSql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			deductAccnoType.put(rs.getString("itemno"), rs.getDouble("attribute1"));
		}
		rs.close();
		
		//��ѯ����������е����й����ͻ��ĺ��Ŀͻ���
		String selectMfCustomerIDSql = "Select MfCustomerID From business_putout_relative Where ObjectNo is null";
		
		//��ȡ�ÿͻ��վ����ڴ���ܽ��
		String selectFixedSavingAmtSql =" select nvl(sum(getERateAmount(frm.Balance,frm.currency,'RMB')),0) as sumFixedSavingAmount " +
										" from Fixedsaving_Record_Month frm " +
										" where frm.ecifcustomerid = ? and frm.InputDate = '"+sDate+"' and frm.balanceway = '0'";
		PreparedStatement psFixedSavingAmt = connection.prepareStatement(selectFixedSavingAmtSql);	
		
		//��ȡ�ÿͻ��վ����ڴ���ܽ������޳��˴�ִ������˻��еĻ��ڴ��
		String selectSavingAmtSql = " select nvl(sum(getERateAmount(srm.Balance,srm.currency,'RMB')),0) as sumSavingAmount " +
									" from Saving_Record_Month srm " +
									" where srm.ecifcustomerid = ? and srm.InputDate = '"+sDate+"' and srm.balanceway = '0'" +
									" And srm.Deductaccno not in " +
									" (Select Fr.Savingaccno" +
									"  From Finacing_Account Fa, Finacing_Relative Fr, Customer_Info Ci" +
									" Where Fa.Finacingaccno = Fr.Finacingaccno" +
									"  And Fa.Customerid = Ci.Customerid" +
									"  And Fr.Accounttype = '01'" +
									"  And Fa.Status = '1' And Fr.Status = '1'" +
									"  And Ci.Mfcustomerid = Srm.Ecifcustomerid)";
		PreparedStatement psSavingAmt = connection.prepareStatement(selectSavingAmtSql);
		
		//��ȡ�ÿͻ��վ������ʲ��ܽ��
		String selectOtherSavingAmtSql =" select nvl(sum(getERateAmount(ord.Balance,ord.currency,'RMB')),0) as sumOtherSavingAmount " +
										" from Othersaving_Record_Month ord " +
										" where ord.ecifcustomerid = ? and ord.InputDate = '"+sDate+"' and ord.balanceway = '0'";
		PreparedStatement psOtherSavingAmt = connection.prepareStatement(selectOtherSavingAmtSql);
		
		//���¿ͻ��ۺ��ʲ����
		String updateAllBalanceSql = "Update business_putout_relative bpr Set bpr.Allbalance = ? Where ObjectNo Is Null And bpr.Mfcustomerid =?";
		PreparedStatement psUpdateAllBalance = connection.prepareStatement(updateAllBalanceSql);
		
		PreparedStatement psSelectSql = connection.prepareStatement(selectMfCustomerIDSql);
		rs = psSelectSql.executeQuery();
		while(rs.next()){
			double sumFixedSavingBalance = 0.0d; //���ڴ���ܽ��
			double sumSavingBalance = 0.0d;//���ڴ���ܽ��
			double sumOtherSavingBalance = 0.0d; //�������ʲ��ܽ��
			double allBalance = 0.0d;//�ͻ��ۺ��ʲ��ܽ��
			String sMfCustomerID = rs.getString("MfCustomerID");
			
			psFixedSavingAmt.setString(1, sMfCustomerID);
			ResultSet FixedSavingRs = psFixedSavingAmt.executeQuery();
			if(FixedSavingRs.next()){
				sumFixedSavingBalance = FixedSavingRs.getDouble("sumFixedSavingAmount");
			}
			FixedSavingRs.close();
			
			psSavingAmt.setString(1, sMfCustomerID);
			ResultSet SavingRs = psSavingAmt.executeQuery();
			if(SavingRs.next()){
				sumSavingBalance = SavingRs.getDouble("sumSavingAmount");
			}
			SavingRs.close();
			
			psOtherSavingAmt.setString(1,sMfCustomerID);
			ResultSet OtherSavingRs = psOtherSavingAmt.executeQuery();
			if(OtherSavingRs.next()){
				sumOtherSavingBalance = OtherSavingRs.getDouble("sumOtherSavingAmount");
			}
			OtherSavingRs.close();
			
			allBalance = NumberTools.round(
						 sumSavingBalance * deductAccnoType.get("010") / 100 + 
						 sumFixedSavingBalance * deductAccnoType.get("020") / 100 + 
						 sumOtherSavingBalance * deductAccnoType.get("030") /100, 2);
			
			//����Business_Putout_Relative ��AllBalance
			psUpdateAllBalance.setDouble(1, allBalance);
			psUpdateAllBalance.setString(2, sMfCustomerID);
			psUpdateAllBalance.execute();
		}
		rs.close();
		ps.close();
		psSelectSql.close();
		psFixedSavingAmt.close();
		psSavingAmt.close();
		psOtherSavingAmt.close();
		psUpdateAllBalance.close();
	}
	
	//���ʷ��Ȱ�����ȣ��������վ��ۺ��ʲ����/�����վ�����������
	public void InsertFloatRateChange() throws Exception{
		
		//���ش���������ʲ�������
		loanRateConfig();
		
		String insertLoanChange = " insert into Loan_Change(ObjectType,ObjectNo,ChangeDate,Status,ChangeType,OldValue,NewValue,ColName,ChangeSerialNo,RelativeSerialNo)"
            + " values(?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertLC = connection.prepareStatement(insertLoanChange);
		
		String selectSql =  " Select Lb.Putoutno,Lb.Customerid,Lb.Businesstype,Lb.Nextpaydate, 				"+
							"        Lb.Ratefloat,Lb.Orgid,Lr.Lastmonthavgbalance,Lr.Oriratefloat,  		"+
							"        Lb.MaturityDate,Sum(Bpr.Allbalance) As Allbalance 						"+
							"   From Business_Putout_Relative Bpr,Loanbalance_Relative Lr,Loan_Balance Lb 	"+
							"  Where Bpr.Putoutno = Lr.Putoutno And Lr.Putoutno = Lb.Putoutno 				"+
							"    And Status = '030' And Bpr.Objectno Is Null 								"+
							"  Group By Lb.Putoutno,Lb.Customerid,Lb.Businesstype,Lb.Nextpaydate, 			"+
							"        Lb.Ratefloat,Lb.Orgid,Lr.Lastmonthavgbalance,Lr.Oriratefloat,			"+
							"		 Lb.MaturityDate											 			";
		logger.info(selectSql);
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			DepositLoanInfo depositLoanInfo = new DepositLoanInfo();
			depositLoanInfo.setPutOutNo(rs.getString("PutOutNo"));
			depositLoanInfo.setCustomerID(rs.getString("CustomerID"));
			depositLoanInfo.setOrgID(rs.getString("OrgID"));
			depositLoanInfo.setBusinessType(rs.getString("BusinessType"));
			depositLoanInfo.setLastMonthAvgBalance(rs.getDouble("LastMonthAvgBalance"));
			depositLoanInfo.setAllBalance(rs.getDouble("AllBalance"));
			depositLoanInfo.setOrirateFloat(rs.getDouble("OrirateFloat"));
			depositLoanInfo.setOldRateFloat(rs.getDouble("RateFloat"));
			depositLoanInfo.setNextPayDate(rs.getString("NextPayDate"));
			depositLoanInfo.setMaturityDate(rs.getString("MaturityDate"));
			
			//�Ƿ�VIP���ʱ���ж�
			depositLoanInfo = isChange(depositLoanInfo,vipRateConfigList);
			
			if(depositLoanInfo.isRateFloatChange()){
				insertFloatRateChange(psInsertLC,depositLoanInfo.getPutOutNo(),depositLoanInfo.getOldRateFloat(),depositLoanInfo.getNewRateFloat(),depositLoanInfo.getNextPayDate());
				dealNum++;
				icount++;
			}
			if(dealNum>=commitNum){
				psInsertLC.executeBatch();
				dealNum=0;
				logger.info("�Ѿ������������������ʱ��"+icount+"��!");
			}
		}
		rs.close();
		psInsertLC.executeBatch();
		psSelectSql.close();
		psInsertLC.close();
	}
	
	/**
	 * @author YUJIYU090
	 * @title ���ش���������ʲ�������
	 * */
	public void loanRateConfig() throws SQLException{
		//С΢��������������ã�ͬ����VIP����
		String selectSql = " select SerialNo,OrgID,BusinessType,LimAmt,SavingLowerLim,SavingUpperLim,RateFloat,FavRateFloat,VipComFlag,BeginDate,VIPRateType "
			             + " from VIP_RATE "
			             + " where Status = '1' and BeginDate <= '"+deductDate+"' and vipRateType = '030'"
			             + " order by BusinessType,OrgID desc";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			VipRate vipRate = new VipRate();
			vipRate.setSerialNo(rs.getString("SerialNo"));
			vipRate.setOrgID(rs.getString("OrgID"));
			vipRate.setBusinessType(rs.getString("BusinessType"));
			vipRate.setLimAmt(rs.getDouble("LimAmt"));
			vipRate.setSavingLowerLim(rs.getDouble("SavingLowerLim"));
			vipRate.setSavingUpperLim(rs.getDouble("SavingUpperLim"));
			vipRate.setUseDate(rs.getString("BeginDate"));
			vipRate.setRateFloat(rs.getDouble("RateFloat"));
			vipRate.setFavRateFloat(rs.getDouble("FavRateFloat"));
			vipRate.setVipComFlag(rs.getString("VipComFlag"));
			vipRate.setVIPRateType(rs.getString("VIPRateType"));
			vipRateConfigList.add(vipRate);	
		}
		rs.close();
		psSelectSql.close();
	}
	
	public void insertFloatRateChange(PreparedStatement psInsert,String sPutOutNo,double oldRateFloat,double newRateFloat,String sChangeDate) throws Exception{
		String sChangeSerialNo1 = createSerialNo();
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,String.valueOf(oldRateFloat));
		psInsert.setString(7,String.valueOf(newRateFloat));
		psInsert.setString(8,"RateFloat");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,BatchConstant.RATEFLOATTYPE_PROPORTION);
		psInsert.setString(7,BatchConstant.RATEFLOATTYPE_PROPORTION);
		psInsert.setString(8,"RateFloatType");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
		psInsert.setString(1,"LoanBalance");
		psInsert.setString(2,sPutOutNo);
		psInsert.setString(3,sChangeDate);
		psInsert.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
		psInsert.setString(5,BatchConstant.CHANGE_TYPE_RATEFLOAT);
		psInsert.setString(6,BatchConstant.RATEMODE_FLOAT);
		psInsert.setString(7,BatchConstant.RATEMODE_FLOAT);
		psInsert.setString(8,"RateMode");
		psInsert.setString(9,sChangeSerialNo1);
		psInsert.setString(10,sChangeSerialNo1);
		psInsert.addBatch();
		
	}
	
	public String createSerialNo() throws Exception{
		serialCount++;
		String sChangeType = BatchConstant.CHANGE_TYPE_RATEFLOAT;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(serialCount,8,'0');
		return "R"+sDate+sChangeType+sSortNo;
	}
	
	/*
	 * ����������Ϣ���жϸô����Ƿ����VIP���ʱ��
	 * */
	private DepositLoanInfo isChange(DepositLoanInfo depositLoanInfo,ArrayList<VipRate> vipRateConfigList) throws Exception{
		double newRateFloat = 9999.9;//���ڸ�������
		//�������ƽ���������Ϊ0���򲻱��
		if(depositLoanInfo.getLastMonthAvgBalance() == 0.0){
			depositLoanInfo.setRateFloatChange(false);
		}else{
			//��������
			depositLoanInfo.setSavingLoanProport(NumberTools.round(depositLoanInfo.getAllBalance()/depositLoanInfo.getLastMonthAvgBalance(),2));
			for(int i=0;i<vipRateConfigList.size();i++){	
				VipRate vRate = vipRateConfigList.get(i);
				String sOrgID = depositLoanInfo.getOrgID();
				for(int j = 0;j<2;j++){
					OrgInfo orgInfo = OrgInfoConfig.getOrgInfo(sOrgID);
					sOrgID = orgInfo.getRelativeOrgID();
					if(Math.abs(newRateFloat-9999.9)>0.001)
						break;
					newRateFloat = getVIPRateFloat(vRate,sOrgID,depositLoanInfo);
					if(Math.abs(newRateFloat-9999.9)>0.001)
						break;
				}
			}
			
			if(Math.abs(newRateFloat-9999.9)<0.001){
				depositLoanInfo.setRateFloatChange(false);
			}else{
				depositLoanInfo.setRateFloatChange(true);
				depositLoanInfo.setNewRateFloat(newRateFloat);
			}
		}
		return depositLoanInfo;
	}
	
	private double getVIPRateFloat(VipRate vRate,String sOrgID,DepositLoanInfo depositLoanInfo) throws Exception{
		if(!vRate.getBusinessType().equals(depositLoanInfo.getBusinessType()))
			return 9999.9;
		if(!vRate.getOrgID().equals(sOrgID))
			return 9999.9;
		if(depositLoanInfo.getAllBalance()<vRate.getLimAmt())
			return 9999.9;
		if(depositLoanInfo.getSavingLoanProport()<(vRate.getSavingLowerLim()*0.01) || depositLoanInfo.getSavingLoanProport()>=(vRate.getSavingUpperLim()*0.01))
			return 9999.9;
		if(depositLoanInfo.getNextPayDate().compareTo(DateTools.getRelativeDate(depositLoanInfo.getMaturityDate(),AccountConstants.TERM_UNIT_MONTH, -1))>=0)
			return 9999.9;
		return returnRateFloat(vRate,depositLoanInfo.getOrirateFloat());
	}
	
	//����Vip�仯������ʸ�������
	public double returnRateFloat(VipRate vipRate,double dOrirateFloat){
		double dReturn=9999.9;
		//���Żݸ������ȼ���
		if(vipRate.getVipComFlag().equals("010")){
			//�µ����ʸ������� = ԭʼ���ʸ������� + �������ʵ�������
			//������Ĵ������ʲ��õ�������ͬ�ڴ����׼���ʣ�������µ�����С��0���������ڻ�׼���ʣ�ȡ0������׼����
			dReturn = dOrirateFloat+vipRate.getFavRateFloat();
			if(dReturn<0) return 0;
		//���̶����ʷ���
		}else if(vipRate.getVipComFlag().equals("020")){
			dReturn = vipRate.getRateFloat();
		}
		return dReturn;
	}
	
}
