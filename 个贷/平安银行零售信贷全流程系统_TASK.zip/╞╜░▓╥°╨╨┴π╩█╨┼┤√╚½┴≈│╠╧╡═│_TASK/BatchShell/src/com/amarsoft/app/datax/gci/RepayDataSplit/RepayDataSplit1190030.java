package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;

public class RepayDataSplit1190030 extends BasicRepayDataSplit {

	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		if(!preCheck(deductDateList,aheadDeductdataList,fareDetailList,acctFeeInfoList,accountMap))
			return pamsAs400ArrayList;
		else
		{
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			String DeductAccNo1 = accountMap.get("DeductAccNo1").getAccountNo();
			String DeductAccNo2 = accountMap.get("DeductAccNo2").getAccountNo();
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			/*//���л�����ȫ��
			String OrgTrustAccNo = accountMap.get("OrgTrustAccNo").getAccountNo();*/
			//ί�����ʽ�
			String TrustorAccNo = accountMap.get("TrustorAccNo").getAccountNo();
			//ί����ί�л�
			String TrustBankAccNo = accountMap.get("TrustBankAccNo").getAccountNo();
			
			for(int i=0;i<deductDateList.size();i++)
			{
				DeductData deductData = deductDateList.get(i);
				String DeductSerialNo = createDeductSerialNo();
				
				//��Ϣ
				double fineAmount = returnFine(deductData);
				if(fineAmount>0)
				{
					PamsAs400 pamsAs400 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),fineAmount,
							DeductAccNo,TrustorAccNo,DeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_FINE,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,"",DeductAccNo1,DeductAccNo2);
					
					pamsAs400ArrayList.add(pamsAs400);
				}
				
				//��Ϣ
				double inteAmount = returnInte(deductData);
				if(inteAmount>0)
				{
					PamsAs400 pamsAs400 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),inteAmount,
							DeductAccNo,TrustorAccNo,DeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_INTE,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,"",DeductAccNo1,DeductAccNo2);
					
					pamsAs400ArrayList.add(pamsAs400);
				}
				
				//����
				double corpAmount = returnCorp(deductData);
				if(corpAmount>0)
				{
					//�ͻ������ʽ��˻� --> ��400������
					PamsAs400 pamsAs400_1 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),corpAmount,
							DeductAccNo,RelativeAccNo,DeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_CORP,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,"",DeductAccNo1,DeductAccNo2);
					/*//���л�����ȫ�� --> ί����ί�л�
					PamsAs400 pamsAs400_2 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),corpAmount,
							OrgTrustAccNo,TrustBankAccNo,DeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_TRUN,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,"","","");*/
					//ί����ί�л� --> ί�����ʽ�
					PamsAs400 pamsAs400_2 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),corpAmount,
							TrustBankAccNo,TrustorAccNo,DeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_TRUN,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,"","","");
					
					pamsAs400ArrayList.add(pamsAs400_1);
					pamsAs400ArrayList.add(pamsAs400_2);
				}
				
			}
			
			return pamsAs400ArrayList;
		}
	}

	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		String sPutOutNo = deductDateList.get(0).getPutOutNo();
		boolean dReturn = true;
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		if(DeductAccNo == null||DeductAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
			dReturn = false;
		}
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		if(RelativeAccNo==null||RelativeAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
			dReturn = false;
		}
		/*
		//���л�����ȫ��
		String OrgTrustAccNo = accountMap.get("OrgTrustAccNo").getAccountNo();
		if(OrgTrustAccNo==null||OrgTrustAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д������л�����ȫ�������ڣ�");
			dReturn = false;
		}
		*/
		//ί�����ʽ�
		String TrustorAccNo = accountMap.get("TrustorAccNo").getAccountNo();
		if(TrustorAccNo==null||TrustorAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д���ί�����ʽ𻧲����ڣ�");
			dReturn = false;
		}
		//ί����ί�л�
		String TrustBankAccNo = accountMap.get("TrustBankAccNo").getAccountNo();
		if(TrustBankAccNo==null||TrustBankAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"��ί�д���ί����ί�л������ڣ�");
			dReturn = false;
		}
		return dReturn;
	}

}
