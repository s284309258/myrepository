package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class PMOverBatch extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				Statement stmt=connection.createStatement();
				stmt.execute("update Org_Info set BusinessStatus='1' where BusinessStatus='2' ");
				stmt.execute("update Ploan_Setup set login='0',DeductDealFlag='0',NextDeductExecuteDate='"+nextDate+"' ");
				stmt.execute("update BATCHTASK_STATUS set DateFlag='1' where InputDate='"+deductDate+"' and TargetName = 'PMDeductData' ");
				stmt.close();
				logger.info("���մ�����ϣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
}
