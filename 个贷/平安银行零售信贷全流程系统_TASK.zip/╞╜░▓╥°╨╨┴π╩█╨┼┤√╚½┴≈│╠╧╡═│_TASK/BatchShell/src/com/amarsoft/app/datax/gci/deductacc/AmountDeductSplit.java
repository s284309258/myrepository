package com.amarsoft.app.datax.gci.deductacc;

import java.util.ArrayList;

import com.amarsoft.app.datax.gci.DeductData;

public class AmountDeductSplit {
	
	private double deductBalance = 0;
	boolean b = false;
	
	//������� portraitFlag �ۿ����    landFlag ��Ŀ�ۿ�˳��
	public DeductData splitAmount(double amount,DeductData oldDeductData,String portraitFlag,String landFlag)
	{
		deductBalance = amount;
		
		//�Ⱥ����
		if(portraitFlag.equals("1"))
		{  
			portraitFlag1(deductBalance,oldDeductData,landFlag);
		}
		
		return oldDeductData;
	}
	//�Ⱥ����
	public void portraitFlag1(double deductBalance,DeductData deductData,String landFlag)
	{
		
			
			String ss[] = landFlag.split("@");
			//������Ŀۿ�˳�� ѭ���ۿ�
			for(int j=0;j<ss.length;j++)
			{
				String sSingleAmount = ss[j];
				if(deductBalance<=0)
				{
					break;
				}
				//����	
				if(sSingleAmount.equalsIgnoreCase("corp"))
				{
					deductSingleCorpAmount(deductData);
				}
				//��Ϣ
				else if(sSingleAmount.equalsIgnoreCase("Inte"))
				{
					deductSingInteAmount(deductData);
				}
				//��Ϣ
				else
				{
					deductSingleFineAmount(deductData);
				}
			}
		
	}
	
	//������
	public void deductSingleCorpAmount(DeductData deductData)
	{	
		//��������
		if((deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp())>0)
		{
			if(deductBalance>=(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp());
				deductData.setActualCurrentCorp(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualCurrentCorp(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualCurrentCorp(0);
			deductData.setBalance(deductBalance);
		}
		//���ڱ���
		if((deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp())>0)
		{
			if(deductBalance>=(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp());
				deductData.setActualOverDueCorp(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualOverDueCorp(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualOverDueCorp(0);
			deductData.setBalance(deductBalance);
		}
		//ΥԼ����
		if(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp()>0)
		{
			if(deductBalance>=(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp());
				deductData.setActualDefaultCorp(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualDefaultCorp(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualDefaultCorp(0);
			deductData.setBalance(deductBalance);
		}
	}
	
	//��Ϣ����
	public void deductSingInteAmount(DeductData deductData)
	{
		//Ӧ����Ϣ
		if((deductData.getPayInte()-deductData.getActualInte())>0)
		{
			if(deductBalance>=(deductData.getPayInte()-deductData.getActualInte()))
			{
				deductBalance = deductBalance-(deductData.getPayInte()-deductData.getActualInte());
				deductData.setActualInte(deductData.getPayInte()-deductData.getActualInte());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualInte(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualInte(0);
			deductData.setBalance(deductBalance);
		}	
		//Ӧ����Ϣ
		if((deductData.getPayInnerInte()-deductData.getActualInnerInte())>0)
		{
			if(deductBalance>=(deductData.getPayInnerInte()-deductData.getActualInnerInte()))
			{
				deductBalance = deductBalance-(deductData.getPayInnerInte()-deductData.getActualInnerInte());
				deductData.setActualInnerInte(deductData.getPayInnerInte()-deductData.getActualInnerInte());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualInnerInte(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualInnerInte(0);
			deductData.setBalance(deductBalance);
		}
		//��Ӧ����Ϣ
		if(deductData.getPayOutInte()-deductData.getActualOutInte()>0)
		{
			if(deductBalance>=(deductData.getPayOutInte()-deductData.getActualOutInte()))
			{
				deductBalance = deductBalance-(deductData.getPayOutInte()-deductData.getActualOutInte());
				deductData.setActualOutInte(deductData.getPayOutInte()-deductData.getActualOutInte());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualOutInte(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualOutInte(0);
			deductData.setBalance(deductBalance);
		}
	}
	
	//��Ϣ����
	public void deductSingleFineAmount(DeductData deductData)
	{
		
		//���ڷ�Ϣ
		if((deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())>0)
		{
			if(deductBalance>=(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()))
			{
				deductBalance = deductBalance-(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine());
				deductData.setActualInnerInteFine(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualInnerInteFine(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualInnerInteFine(0);
			deductData.setBalance(deductBalance);
		}
		//���ⷣϢ
		if((deductData.getPayOutInteFine()-deductData.getActualOutInteFine())>0)
		{
			if(deductBalance>=(deductData.getPayOutInteFine()-deductData.getActualOutInteFine()))
			{
				deductBalance = deductBalance-(deductData.getPayOutInteFine()-deductData.getActualOutInteFine());
				deductData.setActualOutInteFine(deductData.getPayOutInteFine()-deductData.getActualOutInteFine());
				deductData.setBalance(deductBalance);
			}
			else
			{
				deductData.setActualOutInteFine(deductBalance);
				deductBalance = 0.0;
				deductData.setBalance(deductBalance);
			}
		}else{
			deductData.setActualOutInteFine(0);
			deductData.setBalance(deductBalance);
		}
	}
	
	public double getDeductBalance() {
		return deductBalance;
	}
	
}
