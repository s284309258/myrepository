package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.account.write.execute.FreezeDeposit;
import com.amarsoft.account.write.execute.TransBailAcc;
import com.amarsoft.account.write.execute.TransBailAccSDB;
import com.amarsoft.account.write.execute.TransDepositAcc;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.impl.szpab.esb.SWESBInstance;
import com.amarsoft.impl.szpab.esb.SWProcess;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.Array;
import com.dc.eai.data.CompositeData;

public class BatchTrustRepay extends CommonExecuteUnit{
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				Transaction Sqlca = StringTools.getSqlca();
				logger.info("�������ڳ���3����ʱ������δ���ڣ���֤�𻹿�......");
				savingBillRepay(Sqlca);
				logger.info("��֤�𻹿����!");
				
				logger.info("��������ڱ�֤�𻹿ʼ......");
				repayLoanJQ(Sqlca);
				logger.info("��֤�𻹿����......");
				
				Sqlca.disConnect();
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//��֤�𻹿�
	private void savingBillRepay(Transaction Sqlca) throws Exception
	{
		CompositeData compositeData = null;
		
		FCRESBInstance fcr = new FCRESBInstance();
		SWProcess sw = new SWProcess();
		TransBailAcc transBailAcc = new TransBailAcc();
		TransBailAccSDB transBailAccSDB = new TransBailAccSDB();
		SWESBInstance smesb = new SWESBInstance();
		String ret_status = "";
		String ret_msg = "";
		double paysum = 0.0d;
		try{		
			String sqlBA = "select SerialNo,BailAccount,ChangeSum,BailBaseRate,BailReleaseAccount,BailCurrency,DepositNo,SubSerialNo,BankFlag from bail_info where objectno= ? and status ='20' order by SerialNo";
			PreparedStatement psBC = connection.prepareStatement(sqlBA);
			//��ʱ����������
			/*String sqlFee = "select fd.serialno,fd.paydate,fd.paymoney,fd.actualmoney" +
					" From acct_fee_info afi,fare_detail fd where afi.serialno = fd.putoutno and fd.offflag='0' and afi.objectno = ? ";
			PreparedStatement psFee = connection.prepareStatement(sqlFee);*/
			
			String sqlLB = " select lb.PutoutNo From loan_balance lb, loanbalance_relative lr where lb.putoutno not like 'QY%' and lb.putoutno=lr.putoutno "+
						" and lb.loanstatus in ('0', '1','4','5') and lb.maturitydate > '"+deductDate+"' and lr.overdays >= 90 "+
						" and exists(select 1 from bail_info where objectno =lb.putoutno and status='20')";
			PreparedStatement psLB = connection.prepareStatement(sqlLB);
			ResultSet rsLB = psLB.executeQuery();
			A:while(rsLB.next()){
				String sPutOutNo = DataConvert.toString(rsLB.getString("PutoutNo"));
				LoanBalance loanBalance = new LoanBalance();
				loanBalance.SetLoanBalance(sPutOutNo, connection);
				
				/*psFee.setString(1, sPutOutNo);
				ResultSet rsFee = psFee.executeQuery();
				while(rsFee.next()){
					
				}*/
				//��ȡ��Ҫ������
				double paymoney = loanBalance.getOverDueBalance()+loanBalance.getPayInte()+loanBalance.getPayInnerInte()+loanBalance.getPayOutInte()+loanBalance.getPayInnerInteFine()+loanBalance.getPayOutInteFine();
				//���û�пۿ���ֱ������������һ��
				if(paymoney<=0)continue;
				psBC.setString(1, sPutOutNo);
				ResultSet rsBC = psBC.executeQuery();
				B:while(rsBC.next()){
					String serialNo = DataConvert.toString(rsBC.getString("SerialNo"));
					String bailAccount = DataConvert.toString(rsBC.getString("BailAccount"));//��֤���ʻ�
					double changeSum = rsBC.getDouble("ChangeSum");//��֤���ʻ����
					String bailBaseRate = DataConvert.toString(rsBC.getString("BailBaseRate"));//��֤�����ͣ����ڡ�����000��
					String bailReleaseAccount = DataConvert.toString(rsBC.getString("BailReleaseAccount"));//��֤���ͷ��ʻ�
					String CCY = DataConvert.toString(rsBC.getString("BailCurrency"));
					String despoitNo = DataConvert.toString(rsBC.getString("DepositNo"));
					String subSerialNo = DataConvert.toString(rsBC.getString("SubSerialNo"));
					String bankFlag = DataConvert.toString(rsBC.getString("BankFlag"));//FCR��ICS��ʶ
					if("SDB".equals(bankFlag)){
						if(changeSum<=paymoney){
							//���֤�����֧ȡ��356720��
							compositeData = smesb.marginToSettleDrawn(bailAccount, subSerialNo, CCY, changeSum, despoitNo, bailReleaseAccount, loanBalance.getOrgID(), OCIConfig.getUserID());
							ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
							if("S".equals(ret_status)){
								//��ѯ�ӿڣ�14���˺ţ������߿���
								if(bailReleaseAccount.length()==14){									
									compositeData = fcr.queryAccountBalanceAndStatus("", bailReleaseAccount, CCY, "", "");
								}else{
									compositeData = fcr.queryAccountBalanceAndStatus(bailReleaseAccount, "", CCY, "", "");
								}
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								if("S".equals(ret_status)){
									paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
									if(paysum<=paymoney){
										//���˽ӿ�
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				paymoney-=paysum;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}else{
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				updateBailInfo(serialNo);
						    				paymoney=0;
						    				break B;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}
								}else{
									this.errorRecord(serialNo, "�ͷŲ�ѯʧ��"+ret_msg+"ʧ��");
								}
								updateBailInfo(serialNo);
							}else{
								this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
							}
						}else{
							if (bailReleaseAccount != null && bailReleaseAccount.length() != 14) {// ��Ϊ��֤�𲿷�֧ȡ��֧�ֿ��ţ������Ҫ������ת���ʺŽ����ͷ�
							    compositeData = smesb.selectCardunderAccount(bailReleaseAccount, "", "10");//��ѯ���»����ʺ�
							    String sStatusMainAccount = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �����Ƿ�ɹ�
							    if ("S".equals(sStatusMainAccount)){
							    	String sMainAccount = DataConvert.toString((String) ESBInstance.getValue(compositeData, "ACCT_NO"));// ȡ���µĻ����ʻ�
							    	compositeData = smesb.marginPartialWithdrawal(bailAccount, subSerialNo, CCY, paymoney, despoitNo, sMainAccount,  loanBalance.getOrgID(), OCIConfig.getUserID());					
							    }else{
							    	this.errorRecord(serialNo, "�ͷ��˺ſ����˺Ų�ѯʧ��"+ret_msg+"ʧ��");
							    }
							}else{
								//���֤�𲿷�֧ȡ��351030��
								compositeData = smesb.marginPartialWithdrawal(bailAccount, subSerialNo, CCY, paymoney, despoitNo, bailReleaseAccount,  loanBalance.getOrgID(), OCIConfig.getUserID());
							}
							ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
							if("S".equals(ret_status)){
								//��ѯ�ӿڣ�14���˺ţ������߿���
								if(bailReleaseAccount.length()==14){									
									compositeData = fcr.queryAccountBalanceAndStatus("", bailReleaseAccount, CCY, "", "");
								}else{
									compositeData = fcr.queryAccountBalanceAndStatus(bailReleaseAccount, "", CCY, "", "");
								}
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								if("S".equals(ret_status)){
									paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
									if(paysum<=paymoney){
										//���˽ӿ�
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				//updateBailInfo(serialNo);
						    				paymoney-=paysum;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}else{
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				updateBailInfo(serialNo,paymoney,changeSum);
						    				paymoney=0;
						    				//�ͷű�֤���ʻ�ʣ����
						    				break B;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}
								}else{
									this.errorRecord(serialNo, "�ͷŲ�ѯʧ��"+ret_msg+"ʧ��");
									//ͬʱ���������׳�����ȥ
								}
								updateBailInfo(serialNo,paymoney,changeSum);
							}else{
								this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
							}					
						}
					}else{
						if("000".equals(bailBaseRate)){//����ֱ�ӷ���FCR�ۿ�	
							if(changeSum<paymoney){//��֤����С�ڻ���������ۿͬʱ����ƽ����֤�������ӿ�							
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, changeSum, OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									updateBailInfo(serialNo);
									paymoney-=changeSum;
									System.out.println("\n**********���ڵ���35#���ʻ���������**********");
								    compositeData = smesb.destroyBail(bailAccount, "", CCY, bailReleaseAccount, OCIConfig.getBranchID(),  OCIConfig.getUserID(), "", "", "", 0,"","",0);
								    ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
									if("S".equals(ret_status)){
										System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
										compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
								    	ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								    	if ("S".equals(ret_status)){
											paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
								    		if(paysum<paymoney){
								    			//���û�����˽ӿ�
								    			compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								    			ret_msg= (String)ESBInstance.getValue(compositeData, "RET_MSG");
								    			if(ret_status.equals("F")){
								    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
								    				Sqlca.conn.rollback();
								    			}else{									
								    				Sqlca.conn.commit();
								    				//updateBailInfo(serialNo);
								    				paymoney-=paysum;
								    			}
								    		}else{
								    			compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney,  OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								    			if(ret_status.equals("F")){
								    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
								    				Sqlca.conn.rollback();
								    			}else{									
								    				Sqlca.conn.commit();
								    				//updateBailInfo(serialNo);
								    				paymoney=0;
								    				break B;
								    			}
								    		}
								    	}else{
								    		this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
								    	}
									}else{
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}
								}
							}else if(changeSum==paymoney){//��֤������ڻ���������ۿͬʱ����ƽ����֤�������ӿ�	
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, changeSum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									//�˱ʲ����ٻ���ñʱ�֤��������ֱ������������һ����
									updateBailInfo(serialNo);
									paymoney=0;
									System.out.println("\n**********���ڵ���35#���ʻ���������**********");
								    compositeData = smesb.destroyBail(bailAccount, "", CCY, bailReleaseAccount, OCIConfig.getBranchID(),  OCIConfig.getUserID(), "", "", "", 0,"","",0);
								    ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								    if ("F".equals(ret_status)){
								    	this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
								    }
									break B;
								}
							}else{//��֤������ڻ������ֻ�����ۿ�
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									updateBailInfo(serialNo,paymoney,changeSum);
									paymoney=0;
									break B;
								}
							}
						}else{//ƽ�����ڱ�֤���붨ת���ٿۿ�
							if(changeSum<=paymoney){//��֤����С�ڻ���������ۿͬʱ����ƽ����֤�������ӿ�	
								if ("".equals(despoitNo)) despoitNo = "1";
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								CompositeData compositeData1 = fcr.queryAccountStatus(bailAccount, "", "", "", OCIConfig.getBranchID(), OCIConfig.getUserID());

							    // ��֤���ͷ�ǰ��ȥ��ѯ��֤���˺��Ƿ�����
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "RET_STATUS"));// ����״̬,�ɹ�ΪS,ʧ��ΪF
							    String Acct_Close_Date = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "ACCT_CLOSE_DATE")).trim();// ��ֵ����˻�������
							    String ACCT_STATUS = "";
							    if (!"".equals(Acct_Close_Date) || "F".equalsIgnoreCase(ret_status)) {
							    	this.errorRecord(serialNo, "��֤���ѯ"+ret_msg+"ʧ��");
							    } else {
							    	 Array acctArray = (Array) ESBInstance.getValue(compositeData1, "ACCT_ARRAY");// �˺ŵ�״̬����
									    compositeData1.getStruct("BODY").removeObject("ACCT_ARRAY");// ɾ�����ʻ����飬��ֹ���ڴ浽���ں��Զ�ת����ɵ����ʺ����ڱ��
							    	// ѭ��ȡֵ
							    	AI: for (int i = 0; i < acctArray.size(); i++) {
							    		Array acctPropertyArray = (Array) ESBInstance.getValue(acctArray.getStruct(i), "ACCT_PROPERTY_ARRAY");
							    		for (int j = 0; j < acctPropertyArray.size(); j++) {
							    			ACCT_STATUS = DataConvert.toString((String) ESBInstance.getValue(acctPropertyArray.getStruct(j), "ACCT_STATUS"));
							    			if ("43".equals(ACCT_STATUS)) {
							    				ACCT_STATUS = "43";
							    				break AI;
							    			}
							    		}
							    	}
							    }
							    //�����ֹ��״̬��⸶������ֱ������
								if ("43".equals(ACCT_STATUS)) { // ȫ�֤���ͷ�
									// ��Ҫ�⸶�ʻ�״̬
									System.out.println("\n**********���ڵ���31�Žӿڽ⸶**********");
									compositeData = fcr.freezeAndUnfreeze(ACCT_STATUS, "D", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());// ����31�Žӿڽ⸶
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �⸶�ɹ�����־����ȫ���ͷű�֤��ʧ��֮���֮ǰ�⸶�ɹ����˺Ž���ֹ��
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤��⸶"+ret_msg+"ʧ��");
									}else{
										
										System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
										compositeData = fcr.testCalculate(bailAccount, "", despoitNo, 0.0, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
										
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
										if("F".equalsIgnoreCase(ret_status)){
											this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
											System.out.println("\n**********����ʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
											compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
										}else{		
											double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
											//����5#�ӿڽ���֧ȡ����
											compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, changeSum, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											//���֧ȡʧ���ҽ⸶�ɹ�����Ҫ����ֹ����ȥ
											if ("F".equals(ret_status)){
												this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
												System.out.println("\n**********֧ȡʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
												compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
											}else{
												System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
												compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
												ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
												if ("S".equals(ret_status)){
													paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
													if(paysum<paymoney){
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															paymoney-=paysum;
														}
													}else{
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															updateBailInfo(serialNo);
															paymoney=0;
															break B;
														}
													}
												}else{
													this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
												}
												updateBailInfo(serialNo);
											}
										}
								    }
								}else{
									System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
									compositeData = fcr.testCalculate(bailAccount, "", despoitNo, 0.0, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
									
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}else{		
										double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
										//����5#�ӿڽ���֧ȡ����
										compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, changeSum, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
										//��֤��֧ȡ
										if ("F".equals(ret_status)){
											this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
										}else{
											System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
											compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											if ("S".equals(ret_status)){
												paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
												if(paysum<paymoney){
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														paymoney-=paysum;
													}
												}else{
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														updateBailInfo(serialNo);
														paymoney=0;
														break B;
													}
												}
											}else{
												this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
											}
											updateBailInfo(serialNo);
										}
									}
								}
								
							}else{//��֤������ڵ��ڻ���������ۿƽ�����ڲ���Ҫ���������ӿ�	
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								if ("".equals(despoitNo)) despoitNo = "1";
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								CompositeData compositeData1 = fcr.queryAccountStatus(bailAccount, "", "", "", OCIConfig.getBranchID(), OCIConfig.getUserID());

							    // ��֤���ͷ�ǰ��ȥ��ѯ��֤���˺��Ƿ�����
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "RET_STATUS"));// ����״̬,�ɹ�ΪS,ʧ��ΪF
							    
							    String Acct_Close_Date = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "ACCT_CLOSE_DATE")).trim();// ��ֵ����˻�������
							    String ACCT_STATUS = "";
							    if (!"".equals(Acct_Close_Date) || "F".equalsIgnoreCase(ret_status)) {
							    	this.errorRecord(serialNo, "��֤���ѯ"+ret_msg+"ʧ��");
							    } else {
							    	Array acctArray = (Array) ESBInstance.getValue(compositeData1, "ACCT_ARRAY");// �˺ŵ�״̬����
								    compositeData1.getStruct("BODY").removeObject("ACCT_ARRAY");// ɾ�����ʻ����飬��ֹ���ڴ浽���ں��Զ�ת����ɵ����ʺ����ڱ��
							    	// ѭ��ȡֵ
							    	AI: for (int i = 0; i < acctArray.size(); i++) {
							    		Array acctPropertyArray = (Array) ESBInstance.getValue(acctArray.getStruct(i), "ACCT_PROPERTY_ARRAY");
							    		for (int j = 0; j < acctPropertyArray.size(); j++) {
							    			ACCT_STATUS = DataConvert.toString((String) ESBInstance.getValue(acctPropertyArray.getStruct(j), "ACCT_STATUS"));
							    			if ("43".equals(ACCT_STATUS)) {
							    				ACCT_STATUS = "43";
							    				break AI;
							    			}
							    		}
							    	}
							    }
								if ("43".equals(ACCT_STATUS)) { // ȫ�֤���ͷ�
									// ��Ҫ�⸶�ʻ�״̬
									System.out.println("\n**********���ڵ���31�Žӿڽ⸶**********");
									compositeData = fcr.freezeAndUnfreeze(ACCT_STATUS, "D", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());// ����31�Žӿڽ⸶
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �⸶�ɹ�����־����ȫ���ͷű�֤��ʧ��֮���֮ǰ�⸶�ɹ����˺Ž���ֹ��
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤��⸶"+ret_msg+"ʧ��");
									}else{
										System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
										compositeData = fcr.testCalculate(bailAccount, "", despoitNo, paymoney, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
										
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
										if("F".equalsIgnoreCase(ret_status)){
											this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
										}else{		
											double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
											//����5#�ӿڽ���֧ȡ����
											compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, paymoney, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											//��֤��֧ȡ
											if ("F".equals(ret_status)){
												this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
											}else{
												System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
												compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
												ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
												if ("S".equals(ret_status)){
													paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
													if(paysum<paymoney){
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															//updateBailInfo(serialNo);
															paymoney-=paysum;
														}
													}else{
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															updateBailInfo(serialNo,paymoney,changeSum);
															paymoney=0;
															break B;
														}
													}
												}else{
													this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
												}
												updateBailInfo(serialNo,paymoney,changeSum);
											}
										}
										//����֧ȡֻҪ�⸶�ɹ���
										System.out.println("\n**********֧ȡʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
										compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
								    }
								}else{
									System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
									compositeData = fcr.testCalculate(bailAccount, "", despoitNo, paymoney, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
									
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}else{		
										double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
										//����5#�ӿڽ���֧ȡ����
										compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, paymoney, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
										//��֤��֧ȡ
										if ("F".equals(ret_status)){
											this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
										}else{
											System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
											compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											if ("S".equals(ret_status)){
												paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
												if(paysum<paymoney){
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														//updateBailInfo(serialNo);
														paymoney-=paysum;
													}
												}else{
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														updateBailInfo(serialNo,paymoney,changeSum);
														paymoney=0;
														break B;
													}
												}
											}else{
												this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
											}
											updateBailInfo(serialNo,paymoney,changeSum);
										}
									}
								}
							}
						}
					}
				}
				rsBC.close();
			}
			rsLB.close();
			psBC.close();
			psLB.close();
		}
		catch(Exception e){
			throw e;
		}
		
	}
	//���±�֤��״̬
	public void updateBailInfo(String serialNo) throws Exception{
		String sql = "update bail_info set status ='30',changesum=0,BailReleaseDate='"+deductDate+"' where serialno ='"+serialNo+"'";
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.execute();
	}
	//���±�֤��״̬
	public void updateBailInfo(String serialNo,double sum,double changesum) throws Exception{
		String sql ="";
		double m = changesum-sum;
		if(m<=0){
			m=0;
			sql = "update bail_info set changesum='"+m+"',status ='30',BailReleaseDate='"+deductDate+"' where serialno ='"+serialNo+"'";
		}else{
			sql = "update bail_info set changesum='"+m+"',BailReleaseDate='"+deductDate+"' where serialno ='"+serialNo+"'";
		}
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.execute();
	}
	//���������ñ�֤�𻹿�
	private void repayLoanJQ(Transaction Sqlca) throws Exception
	{
		CompositeData compositeData = null;
		FCRESBInstance fcr = new FCRESBInstance();
		SWProcess sw = new SWProcess();
		TransBailAcc transBailAcc = new TransBailAcc();
		TransBailAccSDB transBailAccSDB = new TransBailAccSDB();
		SWESBInstance smesb = new SWESBInstance();
		String ret_status = "";
		String ret_msg = "";
		double paysum = 0.0d;
		try{		
			String sqlBA = "select SerialNo,BailAccount,ChangeSum,BailBaseRate,BailReleaseAccount,BailCurrency,DepositNo,SubSerialNo,BankFlag from bail_info where objectno= ? and status ='20' order by SerialNo";
			PreparedStatement psBC = connection.prepareStatement(sqlBA);
			//��ʱ����������
			/*String sqlFee = "select fd.serialno,fd.paydate,fd.paymoney,fd.actualmoney" +
					" From acct_fee_info afi,fare_detail fd where afi.serialno = fd.putoutno and fd.offflag='0' and afi.objectno = ? ";
			PreparedStatement psFee = connection.prepareStatement(sqlFee);*/
			
			String sqlLB = " select lb.PutoutNo From loan_balance lb, loanbalance_relative lr where lb.putoutno not like 'QY%' and  lb.putoutno=lr.putoutno "+
						" and lb.loanstatus in ('0', '1','4','5') and lb.maturitydate<='"+deductDate+"' "+
						" and exists(select 1 from bail_info where objectno =lb.putoutno and status='20')";
			PreparedStatement psLB = connection.prepareStatement(sqlLB);
			ResultSet rsLB = psLB.executeQuery();
			A:while(rsLB.next()){
				String sPutOutNo = DataConvert.toString(rsLB.getString("PutoutNo"));
				LoanBalance loanBalance = new LoanBalance();
				loanBalance.SetLoanBalance(sPutOutNo, connection);
				
				/*psFee.setString(1, sPutOutNo);
				ResultSet rsFee = psFee.executeQuery();
				while(rsFee.next()){
					
				}*/
				//��ȡ��Ҫ������
				double paymoney = loanBalance.getOverDueBalance()+loanBalance.getPayInte()+loanBalance.getPayInnerInte()+loanBalance.getPayOutInte()+loanBalance.getPayInnerInteFine()+loanBalance.getPayOutInteFine();
				//���û�пۿ���ֱ������������һ��
				if(paymoney<=0)continue;
				psBC.setString(1, sPutOutNo);
				ResultSet rsBC = psBC.executeQuery();
				B:while(rsBC.next()){
					String serialNo = DataConvert.toString(rsBC.getString("SerialNo"));
					String bailAccount = DataConvert.toString(rsBC.getString("BailAccount"));//��֤���ʻ�
					double changeSum = rsBC.getDouble("ChangeSum");//��֤���ʻ����
					String bailBaseRate = DataConvert.toString(rsBC.getString("BailBaseRate"));//��֤�����ͣ����ڡ�����000��
					String bailReleaseAccount = DataConvert.toString(rsBC.getString("BailReleaseAccount"));//��֤���ͷ��ʻ�
					String CCY = DataConvert.toString(rsBC.getString("BailCurrency"));
					String despoitNo = DataConvert.toString(rsBC.getString("DepositNo"));
					String subSerialNo = DataConvert.toString(rsBC.getString("SubSerialNo"));
					String bankFlag = DataConvert.toString(rsBC.getString("BankFlag"));//FCR��ICS��ʶ
					if("SDB".equals(bankFlag)){
						if(changeSum<=paymoney){
							//���֤�����֧ȡ��356720��
							compositeData = smesb.marginToSettleDrawn(bailAccount, subSerialNo, CCY, changeSum, despoitNo, bailReleaseAccount, loanBalance.getOrgID(), OCIConfig.getUserID());
							ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
							if("S".equals(ret_status)){
								//��ѯ�ӿڣ�14���˺ţ������߿���
								if(bailReleaseAccount.length()==14){									
									compositeData = fcr.queryAccountBalanceAndStatus("", bailReleaseAccount, CCY, "", "");
								}else{
									compositeData = fcr.queryAccountBalanceAndStatus(bailReleaseAccount, "", CCY, "", "");
								}
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								if("S".equals(ret_status)){
									paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
									if(paysum<=paymoney){
										//���˽ӿ�
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				paymoney-=paysum;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}else{
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				updateBailInfo(serialNo);
						    				paymoney=0;
						    				break B;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}
								}else{
									this.errorRecord(serialNo, "�ͷŲ�ѯʧ��"+ret_msg+"ʧ��");
								}
								updateBailInfo(serialNo);
							}else{
								this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
							}
						}else{
							if (bailReleaseAccount != null && bailReleaseAccount.length() != 14) {// ��Ϊ��֤�𲿷�֧ȡ��֧�ֿ��ţ������Ҫ������ת���ʺŽ����ͷ�
							    compositeData = smesb.selectCardunderAccount(bailReleaseAccount, "", "10");//��ѯ���»����ʺ�
							    String sStatusMainAccount = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �����Ƿ�ɹ�
							    if ("S".equals(sStatusMainAccount)){
							    	String sMainAccount = DataConvert.toString((String) ESBInstance.getValue(compositeData, "ACCT_NO"));// ȡ���µĻ����ʻ�
							    	compositeData = smesb.marginPartialWithdrawal(bailAccount, subSerialNo, CCY, paymoney, despoitNo, sMainAccount,  loanBalance.getOrgID(), OCIConfig.getUserID());					
							    }else{
							    	this.errorRecord(serialNo, "�ͷ��˺ſ����˺Ų�ѯʧ��"+ret_msg+"ʧ��");
							    }
							}else{
								//���֤�𲿷�֧ȡ��351030��
								compositeData = smesb.marginPartialWithdrawal(bailAccount, subSerialNo, CCY, paymoney, despoitNo, bailReleaseAccount,  loanBalance.getOrgID(), OCIConfig.getUserID());
							}
							ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
							if("S".equals(ret_status)){
								//��ѯ�ӿڣ�14���˺ţ������߿���
								if(bailReleaseAccount.length()==14){									
									compositeData = fcr.queryAccountBalanceAndStatus("", bailReleaseAccount, CCY, "", "");
								}else{
									compositeData = fcr.queryAccountBalanceAndStatus(bailReleaseAccount, "", CCY, "", "");
								}
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								if("S".equals(ret_status)){
									paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
									if(paysum<=paymoney){
										//���˽ӿ�
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				//updateBailInfo(serialNo);
						    				paymoney-=paysum;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}else{
										compositeData = transBailAccSDB.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
						    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						    			if("S".equals(ret_status)){
						    				Sqlca.conn.commit();
						    				updateBailInfo(serialNo,paymoney,changeSum);
						    				paymoney=0;
						    				//�ͷű�֤���ʻ�ʣ����
						    				break B;
						    			}else{
						    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
						    				Sqlca.conn.rollback();
						    			}
									}
								}else{
									this.errorRecord(serialNo, "�ͷŲ�ѯʧ��"+ret_msg+"ʧ��");
									//ͬʱ���������׳�����ȥ
								}
								updateBailInfo(serialNo,paymoney,changeSum);
							}else{
								this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
							}					
						}
					}else{
						if("000".equals(bailBaseRate)){//����ֱ�ӷ���FCR�ۿ�	
							if(changeSum<paymoney){//��֤����С�ڻ���������ۿͬʱ����ƽ����֤�������ӿ�							
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, changeSum, OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									updateBailInfo(serialNo);
									paymoney-=changeSum;
									System.out.println("\n**********���ڵ���35#���ʻ���������**********");
								    compositeData = smesb.destroyBail(bailAccount, "", CCY, bailReleaseAccount, OCIConfig.getBranchID(),  OCIConfig.getUserID(), "", "", "", 0,"","",0);
								    ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
									if("S".equals(ret_status)){
										System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
										compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
								    	ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								    	if ("S".equals(ret_status)){
											paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
								    		if(paysum<paymoney){
								    			//���û�����˽ӿ�
								    			compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								    			ret_msg= (String)ESBInstance.getValue(compositeData, "RET_MSG");
								    			if(ret_status.equals("F")){
								    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
								    				Sqlca.conn.rollback();
								    			}else{									
								    				Sqlca.conn.commit();
								    				//updateBailInfo(serialNo);
								    				paymoney-=paysum;
								    			}
								    		}else{
								    			compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney,  OCIConfig.getUserID(),loanBalance.getOrgID(), Sqlca);
								    			ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								    			ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								    			if(ret_status.equals("F")){
								    				this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
								    				Sqlca.conn.rollback();
								    			}else{									
								    				Sqlca.conn.commit();
								    				//updateBailInfo(serialNo);
								    				paymoney=0;
								    				break B;
								    			}
								    		}
								    	}else{
								    		this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
								    	}
									}else{
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}
								}
							}else if(changeSum==paymoney){//��֤������ڻ���������ۿͬʱ����ƽ����֤�������ӿ�	
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, changeSum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									//�˱ʲ����ٻ���ñʱ�֤��������ֱ������������һ����
									updateBailInfo(serialNo);
									paymoney=0;
									System.out.println("\n**********���ڵ���35#���ʻ���������**********");
								    compositeData = smesb.destroyBail(bailAccount, "", CCY, bailReleaseAccount, OCIConfig.getBranchID(),  OCIConfig.getUserID(), "", "", "", 0,"","",0);
								    ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
								    if ("F".equals(ret_status)){
								    	this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
								    }
									break B;
								}
							}else{//��֤������ڻ������ֻ�����ۿ�
								compositeData=transBailAcc.GetTransBail(loanBalance, serialNo, bailAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
								ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
								ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
								if(ret_status.equals("F")){
									this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
									Sqlca.conn.rollback();
								}else{									
									Sqlca.conn.commit();
									updateBailInfo(serialNo,paymoney,changeSum);
									paymoney=0;
									break B;
								}
							}
						}else{//ƽ�����ڱ�֤���붨ת���ٿۿ�
							if(changeSum<=paymoney){//��֤����С�ڻ���������ۿͬʱ����ƽ����֤�������ӿ�	
								if ("".equals(despoitNo)) despoitNo = "1";
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								CompositeData compositeData1 = fcr.queryAccountStatus(bailAccount, "", "", "", OCIConfig.getBranchID(), OCIConfig.getUserID());

							    // ��֤���ͷ�ǰ��ȥ��ѯ��֤���˺��Ƿ�����
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "RET_STATUS"));// ����״̬,�ɹ�ΪS,ʧ��ΪF
							    String Acct_Close_Date = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "ACCT_CLOSE_DATE")).trim();// ��ֵ����˻�������
							    String ACCT_STATUS = "";
							    if (!"".equals(Acct_Close_Date) || "F".equalsIgnoreCase(ret_status)) {
							    	this.errorRecord(serialNo, "��֤���ѯ"+ret_msg+"ʧ��");
							    } else {
							    	 Array acctArray = (Array) ESBInstance.getValue(compositeData1, "ACCT_ARRAY");// �˺ŵ�״̬����
									    compositeData1.getStruct("BODY").removeObject("ACCT_ARRAY");// ɾ�����ʻ����飬��ֹ���ڴ浽���ں��Զ�ת����ɵ����ʺ����ڱ��
							    	// ѭ��ȡֵ
							    	AI: for (int i = 0; i < acctArray.size(); i++) {
							    		Array acctPropertyArray = (Array) ESBInstance.getValue(acctArray.getStruct(i), "ACCT_PROPERTY_ARRAY");
							    		for (int j = 0; j < acctPropertyArray.size(); j++) {
							    			ACCT_STATUS = DataConvert.toString((String) ESBInstance.getValue(acctPropertyArray.getStruct(j), "ACCT_STATUS"));
							    			if ("43".equals(ACCT_STATUS)) {
							    				ACCT_STATUS = "43";
							    				break AI;
							    			}
							    		}
							    	}
							    }
							    //�����ֹ��״̬��⸶������ֱ������
								if ("43".equals(ACCT_STATUS)) { // ȫ�֤���ͷ�
									// ��Ҫ�⸶�ʻ�״̬
									System.out.println("\n**********���ڵ���31�Žӿڽ⸶**********");
									compositeData = fcr.freezeAndUnfreeze(ACCT_STATUS, "D", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());// ����31�Žӿڽ⸶
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �⸶�ɹ�����־����ȫ���ͷű�֤��ʧ��֮���֮ǰ�⸶�ɹ����˺Ž���ֹ��
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤��⸶"+ret_msg+"ʧ��");
									}else{
										
										System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
										compositeData = fcr.testCalculate(bailAccount, "", despoitNo, 0.0, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
										
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
										if("F".equalsIgnoreCase(ret_status)){
											this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
											System.out.println("\n**********����ʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
											compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
										}else{		
											double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
											//����5#�ӿڽ���֧ȡ����
											compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, changeSum, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											//���֧ȡʧ���ҽ⸶�ɹ�����Ҫ����ֹ����ȥ
											if ("F".equals(ret_status)){
												this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
												System.out.println("\n**********֧ȡʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
												compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
											}else{
												System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
												compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
												ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
												if ("S".equals(ret_status)){
													paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
													if(paysum<paymoney){
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															paymoney-=paysum;
														}
													}else{
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															updateBailInfo(serialNo);
															paymoney=0;
															break B;
														}
													}
												}else{
													this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
												}
												updateBailInfo(serialNo);
											}
										}
								    }
								}else{
									System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
									compositeData = fcr.testCalculate(bailAccount, "", despoitNo, 0.0, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
									
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}else{		
										double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
										//����5#�ӿڽ���֧ȡ����
										compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, changeSum, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
										//��֤��֧ȡ
										if ("F".equals(ret_status)){
											this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
										}else{
											System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
											compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											if ("S".equals(ret_status)){
												paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
												if(paysum<paymoney){
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														paymoney-=paysum;
													}
												}else{
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														updateBailInfo(serialNo);
														paymoney=0;
														break B;
													}
												}
											}else{
												this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
											}
											updateBailInfo(serialNo);
										}
									}
								}
								
							}else{//��֤������ڵ��ڻ���������ۿƽ�����ڲ���Ҫ���������ӿ�	
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								if ("".equals(despoitNo)) despoitNo = "1";
								System.out.println("\n**********25#��֤����ʻ�״̬�Ϳ�������**********");
								CompositeData compositeData1 = fcr.queryAccountStatus(bailAccount, "", "", "", OCIConfig.getBranchID(), OCIConfig.getUserID());

							    // ��֤���ͷ�ǰ��ȥ��ѯ��֤���˺��Ƿ�����
								ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "RET_STATUS"));// ����״̬,�ɹ�ΪS,ʧ��ΪF
							    
							    String Acct_Close_Date = DataConvert.toString((String) ESBInstance.getValue(compositeData1, "ACCT_CLOSE_DATE")).trim();// ��ֵ����˻�������
							    String ACCT_STATUS = "";
							    if (!"".equals(Acct_Close_Date) || "F".equalsIgnoreCase(ret_status)) {
							    	this.errorRecord(serialNo, "��֤���ѯ"+ret_msg+"ʧ��");
							    } else {
							    	Array acctArray = (Array) ESBInstance.getValue(compositeData1, "ACCT_ARRAY");// �˺ŵ�״̬����
								    compositeData1.getStruct("BODY").removeObject("ACCT_ARRAY");// ɾ�����ʻ����飬��ֹ���ڴ浽���ں��Զ�ת����ɵ����ʺ����ڱ��
							    	// ѭ��ȡֵ
							    	AI: for (int i = 0; i < acctArray.size(); i++) {
							    		Array acctPropertyArray = (Array) ESBInstance.getValue(acctArray.getStruct(i), "ACCT_PROPERTY_ARRAY");
							    		for (int j = 0; j < acctPropertyArray.size(); j++) {
							    			ACCT_STATUS = DataConvert.toString((String) ESBInstance.getValue(acctPropertyArray.getStruct(j), "ACCT_STATUS"));
							    			if ("43".equals(ACCT_STATUS)) {
							    				ACCT_STATUS = "43";
							    				break AI;
							    			}
							    		}
							    	}
							    }
								if ("43".equals(ACCT_STATUS)) { // ȫ�֤���ͷ�
									// ��Ҫ�⸶�ʻ�״̬
									System.out.println("\n**********���ڵ���31�Žӿڽ⸶**********");
									compositeData = fcr.freezeAndUnfreeze(ACCT_STATUS, "D", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());// ����31�Žӿڽ⸶
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// �⸶�ɹ�����־����ȫ���ͷű�֤��ʧ��֮���֮ǰ�⸶�ɹ����˺Ž���ֹ��
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤��⸶"+ret_msg+"ʧ��");
									}else{
										System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
										compositeData = fcr.testCalculate(bailAccount, "", despoitNo, paymoney, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
										
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
										if("F".equalsIgnoreCase(ret_status)){
											this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
										}else{		
											double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
											//����5#�ӿڽ���֧ȡ����
											compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, paymoney, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											//��֤��֧ȡ
											if ("F".equals(ret_status)){
												this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
											}else{
												System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
												compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
												ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
												if ("S".equals(ret_status)){
													paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
													if(paysum<paymoney){
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															//updateBailInfo(serialNo);
															paymoney-=paysum;
														}
													}else{
														compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
														ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
														ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
														if(ret_status.equals("F")){
															this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
															Sqlca.conn.rollback();
														}else{									
															Sqlca.conn.commit();
															updateBailInfo(serialNo,paymoney,changeSum);
															paymoney=0;
															break B;
														}
													}
												}else{
													this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
												}
												updateBailInfo(serialNo,paymoney,changeSum);
											}
										}
										//����֧ȡֻҪ�⸶�ɹ���
										System.out.println("\n**********֧ȡʧ���ҽ⸶�ɹ�������31#ֹ����ȥ**********");
										compositeData = fcr.freezeAndUnfreeze("43", "A", bailAccount, despoitNo, CCY, "", OCIConfig.getBranchID(), OCIConfig.getUserID());
								    }
								}else{
									System.out.println("\n**********��26�Žӿ�.�����������ȡ���ر�Ϣ���**********");
									compositeData = fcr.testCalculate(bailAccount, "", despoitNo, paymoney, loanBalance.getOrgID(), "");// ��26�Žӿ�.�����������ȡ���ر�Ϣ���
									
									ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));// // ȫ���ͷŲ���������[����0]
									if("F".equalsIgnoreCase(ret_status)){
										this.errorRecord(serialNo, "��֤������"+ret_msg+"ʧ��");
									}else{		
										double sAmt = (Double) ESBInstance.getValue(compositeData, "ACCT_CLOSE_BALANCE");// ��Ϣ��� ACCT_CLOSE_BALANCE
										//����5#�ӿڽ���֧ȡ����
										compositeData = fcr.getDeposit(OCIConfig.getBranchID(), OCIConfig.getUserID(), bailAccount, bailReleaseAccount, CCY, despoitNo, paymoney, sAmt, "", "");// 5�Žӿڴ浥֧ȡ����
										ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
										//��֤��֧ȡ
										if ("F".equals(ret_status)){
											this.errorRecord(serialNo, "��֤��֧ȡ"+ret_msg+"ʧ��");
										}else{
											System.out.println("\n**********22#��ѯ�ͷ��ʻ����**********");
											compositeData = fcr.queryAccountBalance(bailReleaseAccount, CCY, "", "", "", "", "", OCIConfig.getBranchID(), "");
											ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
											if ("S".equals(ret_status)){
												paysum = (Double)ESBInstance.getValue(compositeData, "AVAIL_BALANCE");
												if(paysum<paymoney){
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paysum, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(serialNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														//updateBailInfo(serialNo);
														paymoney-=paysum;
													}
												}else{
													compositeData = transBailAcc.GetTransBail(loanBalance, serialNo, bailReleaseAccount, paymoney, OCIConfig.getUserID(), loanBalance.getOrgID(), Sqlca);
													ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
													ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
													if(ret_status.equals("F")){
														this.errorRecord(sPutOutNo, "��֤�𻹿�"+ret_msg+"ʧ��");
														Sqlca.conn.rollback();
													}else{									
														Sqlca.conn.commit();
														updateBailInfo(serialNo,paymoney,changeSum);
														paymoney=0;
														break B;
													}
												}
											}else{
												this.errorRecord(serialNo, "�ͷ��ʻ���ѯ"+ret_msg+"ʧ��");
											}
											updateBailInfo(serialNo,paymoney,changeSum);
										}
									}
								}
							}
						}
					}
				}
				rsBC.close();
			}
			rsLB.close();
			psBC.close();
			psLB.close();
		}
		catch(Exception e){
			throw e;
		}
		
	}
	//�����¼��
	public void errorRecord(String sNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sNo);
		batchErrorRecord.setObjectType("LoanBalance");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
}
