package com.amarsoft.app.datax.gci;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.task.TaskConstants;


/**
 * �������ļ������࣬Ϊ��ִ��Ч�ʣ���Ҫ���ý����±������SQL֮��������������
 * @author EX-ZHONGBING001
 *
 */
public class DealFundInfo extends CommonExecuteUnit {
	private int commitNum ;
	private int deductDataNum = 0;
	private int icount = 0;
	@Override
	public int execute() {
		
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" delete from fund_indinfo_temp where inputdate = '"+deductDate+"' ";
				String delChLSql = "delete from Fund_Change_Ls_Temp where inputdate = '"+deductDate+"'";
				String delAccLSql = "delete from Fund_Account_Ls_Temp where FUND_ACCOUNTLS_INPUTDATE = '"+deductDate+"'";
				String delBLSql = "delete from Fund_BackBill_Ls_Temp where BACK_BILL_INPUTDATE = '"+deductDate+"'";
				String delFLSql = "delete from Fund_Finish_Ls_Temp where FUND_FINISH_INPUTDATE = '"+deductDate+"'";
				String delBAPSql = "delete from Fund_Bap_Info_Temp where FUND_BAP_INPUTDATE = '"+deductDate+"'";
				String delMONDZSql = "delete from Fund_MonthDZ_Info_Temp where Fund_MonthDZ_Inputdate = '"+deductDate+"'";
				logger.info("��� ���칫������Ϣ");
				PreparedStatement psDeleteINDData = connection.prepareStatement(delSql);
				PreparedStatement psDeleteCHLSData = connection.prepareStatement(delChLSql);
				PreparedStatement psDeleteACLSData = connection.prepareStatement(delAccLSql);
				PreparedStatement psDeleteBBLSData = connection.prepareStatement(delBLSql);
				PreparedStatement psDeleteFLSData = connection.prepareStatement(delFLSql);
				PreparedStatement psDeleteBAPSData = connection.prepareStatement(delBAPSql);
				PreparedStatement psDeleteMONSData = connection.prepareStatement(delMONDZSql);
				psDeleteINDData.execute();
				psDeleteCHLSData.execute();
				psDeleteACLSData.execute();
				psDeleteBBLSData.execute();
				psDeleteFLSData.execute();
				psDeleteBAPSData.execute();
				psDeleteMONSData.execute();
				logger.info("��յ��칫����ͻ���Ϣ������� ");
				psDeleteINDData.close();
				psDeleteCHLSData.close();
				psDeleteACLSData.close();
				psDeleteBBLSData.close();
				psDeleteFLSData.close();
				psDeleteBAPSData.close();
				psDeleteMONSData.close();
				logger.info("���ɿͻ���Ϣ��ʼ");
				insertMainIndInfo();
				logger.info("���ɿͻ���Ϣ���");
				logger.info("���ɲδ���Ϣ��ʼ");
				insertBAPInfo();
				logger.info("���ɲδ���Ϣ���");
				logger.info("���ɱ����Ϣ��ʼ");
				insertMainChangeInfo();
				logger.info("���ɱ����Ϣ���");
				logger.info("���ɿ�����Ϣ��ʼ");
				insertAccountLSInfo();
				logger.info("���ɿ�����Ϣ���");
				logger.info("���ɻ�����Ϣ��ʼ");
				insertBackBillLS();
				logger.info("���ɻ�����Ϣ���");
				logger.info("����������Ϣ��ʼ");
				insertFinishLS();
				logger.info("����������Ϣ���");
				
				if(DateTools.monthEnd(deductDate)){
				insertMonDZInfo();
				}
				logger.info("���ɵ��칫������Ϣ......");
				logger.info("�����ɵ��칫������Ϣ"+icount+"����");
				logger.info("���ɵ��칫������Ϣ�������");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	
	//���ɿͻ���Ϣ
	public void insertMainIndInfo() throws Exception{
		
		ArrayList<String> contractNoList = new ArrayList<String>();
		ArrayList<String> customerIDList = new ArrayList<String>();
		String selSql = "select LB.CustomerID,LB.ContractSerialNo,LB.Businesstype,LB.Putoutno," +
				        " (select (case when BC.Purpose = '10' then '10' when BC.Purpose ='30' then '30' else '99' end) from Business_Contract BC where BC.Serialno = LB.Contractserialno) as Purpose,"+
					    " II.Nativeadd,II.Fundhousearea,II.Familyadd,II.Familytel,II.Monthincome,II.Familyzip,II.Workcorp,II.Workadd,II.Workzip,"+
					    " II.Corparea||'-'|| II.WorkTel as WorkTel,(case when II.Worknature = '10' then '10' when II.Worknature = '20' then '20' when II.Worknature = '30' then '60' when II.Worknature = '50' then '50' when II.Worknature = '70' then '70' when II.Worknature = '80' then '30' else '99' end) as Worknature," +
					    "II.Legalage,II.Fundmonmoney,II.Comfundmoney,II.Fundbalance,II.Compfundbalance," +
					    "(case when II.Occupation = 'K' then '10' when II.Occupation in ('C','D','E') then '10' when II.Occupation in ('A','B') then '10' else '99' end ) as Occupation," +
					    "(case when II.Headship='4' then '20' when II.Headship='3' then '30' when II.Headship='2' then '40' when II.Headship='1' then '50' else '99' end) as Headship," +
					    "(case when II.Position = '3' then '10'  when II.Position = '2' then '20' when II.Position = '1' then '30' else '99' end)as Position," +
					    "II.Familyhousearea,II.Familyman,II.Familymonthincome,II.Familyfundsum,'' as MonthRepayMoney"+
						"  from Ind_Info II,Loan_Balance LB where exists (select 1 from org_belong where orgid = '100120'and belongorgid = LB.OrgID)"+
						" and LB.Businesstype = '1110070' and LB.Loanstatus in ('1', '0') and LB.Customerid = II.Customerid and LB.PutOutDate = '"+deductDate+"'";
		
		logger.info(selSql);

		//�������������Ϣ
		String insSql = "insert into Fund_Indinfo_Temp  (INPUTDATE,BUSINESSTYPE ,PUTOUTNO,PURPOSE,NATIVEADD,FUNDHOUSEAREA ,FAMILYADD,FAMILYTEL,MONTHINCOME,FAMILYZIP,"+
						                                "WORKCORP,WORKADD,WORKZIP ,WORKTEL ,CORPTYPE,LEGALAGE,FUNDMONMONEY,COMFUNDMONEY,FUNDBALANCE,COMPFUNDBALANCE,"+
						                                "OCCUPATION, HEADSHIP, POSITION, FAMILYHOUSEAREA,FAMILYMAN,FAMILYMONTHINCOME ,FAMILYFUNDSUM,MONTHREPAYMONEY,Fee,Remark,CustomerID,ContractSerialNo)"+
                        "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		//ͨ��ס�����Ѱ����ż��Ϣ
		String selWLSql = "select II.Mainindfund,II.Certid,II.Fullname,II.Fundmonmoney,II.Comfundmoney,II.Fundbalance,II.Compfundbalance,II.Monthincome from Customer_Relative CR,Ind_Info II where II.Customerid = CR.Relativeid and CR.Customerid = ? and CR.Relationship = '0301'";
		//�������������Ϣ��������ż��Ϣ
		String updWLSql = "update Fund_Indinfo_Temp   set  Wlindfund = ?,Wlcertid = ?,Wlname = ?,Wlfundmonmoney=?,Wlcomfundmoney=?,Wlfundbalance = ?,Wlcompfundbalance = ?,Wlincome=? where CustomerID = ? and InputDate = ?";
		
		
		//ͨ����ͬ��Ѱ�ҷ�����Ϣ
		String selHSSql = "select GI.Location,GI.Fundrightid,GI.Housearea,GI.Houseallprice,GI.Firstpay," +
				          "(case when GI.Guarantysubtype = '10' then '10' when GI.Guarantysubtype = '20' then '20' else '99' end) as Guarantysubtype," +
				          "(case when GI.Housetype = '10' then '40' when GI.Housetype = '40' then '20' else '99' end) as Housetype," +
				          "'99' as Housesellnature,GI.Guarantynowdate," +
				          "(case when GI.Houseframe = '03' then '10' when GI.Houseframe = '01' then '40' when GI.Houseframe = '02' then '30' else '99' end) as Houseframe," +
		                  "GI.HouseLayer from Guaranty_Relative GR,Guaranty_Info GI  where GR.Objectno = ? and GR.Objecttype = 'CBContractApply' and GR.Guarantyid = GI.Guarantyid";
		//���·�����Ϣ
		String updHSSql = "update Fund_Indinfo_Temp   set Location=?,RightID=?,Housearea = ?,Houseprice = ?,FirstPay = ?,Housetype = ?,Housenature = ?,Housesellnature = ?,"+
                          "GuarantyDate = ?,housestructure = ?,houselayer = ? where ContractSerialNo = ? and InputDate = ?";
        
		PreparedStatement preselSt = connection.prepareStatement(selSql);
		PreparedStatement preselWLSt = connection.prepareStatement(selWLSql);
		PreparedStatement preInsSt = connection.prepareStatement(insSql);
		PreparedStatement preupdWLSt = connection.prepareStatement(updWLSql);
		PreparedStatement preupdHSSt = connection.prepareStatement(selHSSql);
		PreparedStatement preselHSSt = connection.prepareStatement(updHSSql);
		ResultSet selRs = preselSt.executeQuery();
		ResultSet selWLRs  = null;
		ResultSet selHSRs  = null;
		
		//ס�������Ϣ
		while(selRs.next()){
			String sCustomerID = selRs.getString("CustomerID");
			String sContractSerialNo = selRs.getString("ContractSerialNo") ;
			customerIDList.add(sCustomerID);
			contractNoList.add(sContractSerialNo);
			preInsSt.setString(1, deductDate);
			preInsSt.setString(2, selRs.getString("Businesstype"));
			preInsSt.setString(3, selRs.getString("Putoutno"));
			preInsSt.setString(4, selRs.getString("Purpose"));
			preInsSt.setString(5, selRs.getString("Nativeadd"));
			preInsSt.setString(6, selRs.getString("Fundhousearea"));
			preInsSt.setString(7, selRs.getString("Familyadd"));
			preInsSt.setString(8, selRs.getString("Familytel"));
			preInsSt.setDouble(9, selRs.getDouble("Monthincome"));
			preInsSt.setString(10, selRs.getString("Familyzip"));
			preInsSt.setString(11, selRs.getString("Workcorp"));
			preInsSt.setString(12, selRs.getString("Workadd"));
			preInsSt.setString(13, selRs.getString("Workzip"));
			preInsSt.setString(14, selRs.getString("WorkTel"));
			preInsSt.setString(15, selRs.getString("Worknature"));
			preInsSt.setString(16, selRs.getString("Legalage"));
			preInsSt.setDouble(17, selRs.getDouble("Fundmonmoney"));
			preInsSt.setDouble(18, selRs.getDouble("Comfundmoney"));
			preInsSt.setDouble(19, selRs.getDouble("Fundbalance"));
			preInsSt.setDouble(20, selRs.getDouble("Compfundbalance"));
			preInsSt.setString(21, selRs.getString("Occupation"));
			preInsSt.setString(22, selRs.getString("Headship"));
			preInsSt.setString(23, selRs.getString("Position"));
			preInsSt.setString(24, selRs.getString("Familyhousearea"));
			preInsSt.setString(25, selRs.getString("Familyman"));
			preInsSt.setString(26, selRs.getString("Familymonthincome"));
			preInsSt.setString(27, selRs.getString("Familyfundsum"));
			preInsSt.setString(28, "");
			preInsSt.setString(29, "");
			preInsSt.setString(30, "");
			preInsSt.setString(31,sCustomerID);
			preInsSt.setString(32,sContractSerialNo);
			preInsSt.addBatch();
			
            icount++;
            deductDataNum++;
			if(deductDataNum>=commitNum){
				preInsSt.executeBatch();
				deductDataNum=0;
			    logger.info("��ִ��"+icount+"����");
			}
			
		}
		preInsSt.executeBatch();
		deductDataNum=0;

		
		//������ż��Ϣ
		for(int i = 0;i < customerIDList.size();i++){
			logger.info("������ż��Ϣ");
			String sCustomerID = (String)customerIDList.get(i);
			preselWLSt.setString(1, sCustomerID);
			selWLRs = preselWLSt.executeQuery();
			
			while(selWLRs.next()){
				
				preupdWLSt.setString(1, selWLRs.getString("Mainindfund"));
				preupdWLSt.setString(2, selWLRs.getString("Certid"));
				preupdWLSt.setString(3, selWLRs.getString("Fullname"));
				preupdWLSt.setString(4, selWLRs.getString("Fundmonmoney"));
				preupdWLSt.setString(5, selWLRs.getString("Comfundmoney"));
				preupdWLSt.setString(6, selWLRs.getString("Fundbalance"));
				preupdWLSt.setString(7, selWLRs.getString("Compfundbalance"));
				preupdWLSt.setString(8, selWLRs.getString("Monthincome"));
				preupdWLSt.setString(9, sCustomerID);
				preupdWLSt.setString(10, deductDate);
				
				preupdWLSt.addBatch();
				deductDataNum++;
				
			}
			
			if(deductDataNum >= commitNum){
				preupdWLSt.executeBatch();
				deductDataNum=0;
				logger.info("�Ѿ�����"+i+"����");
			}
			
		}
		preupdWLSt.executeBatch();
		deductDataNum=0;
		
		//���·�����Ϣ
		for( int i = 0;i<contractNoList.size();i++){
			
			logger.info("���·�����Ϣ");
			String sContractSerialNo = (String)contractNoList.get(i);
			preupdHSSt.setString(1, sContractSerialNo);
			selHSRs = preupdHSSt.executeQuery();
			
			while(selHSRs.next()){
				
				preselHSSt.setString(1, selHSRs.getString("Location"));
				preselHSSt.setString(2, selHSRs.getString("Fundrightid"));
				preselHSSt.setDouble(3, selHSRs.getDouble("Housearea"));
				preselHSSt.setDouble(4, selHSRs.getDouble("Houseallprice"));
				preselHSSt.setDouble(5, selHSRs.getDouble("Firstpay"));
				preselHSSt.setString(6, selHSRs.getString("Guarantysubtype"));
				preselHSSt.setString(7, selHSRs.getString("Housetype"));
				preselHSSt.setString(8, selHSRs.getString("Housesellnature"));
				preselHSSt.setString(9, selHSRs.getString("Guarantynowdate"));
				preselHSSt.setString(10, selHSRs.getString("Houseframe"));
				preselHSSt.setString(11, selHSRs.getString("HouseLayer"));
				preselHSSt.setString(12, sContractSerialNo);
				preselHSSt.setString(13, deductDate);
				
				preselHSSt.addBatch();
				deductDataNum++;
				if(deductDataNum >= commitNum){
					preupdWLSt.executeBatch();
					deductDataNum=0;
					logger.info("�Ѿ�����"+i+"����");
				}
			}
			
		}
		preselHSSt.executeBatch();
		deductDataNum=0;
		
		
		//���·�����Ϣ
		if(selHSRs!=null)selHSRs.close();
		selRs.close();
		if(selWLRs!=null)selWLRs.close();
		preselWLSt.close();
		preInsSt.close();
		preselSt.close();
		
		
	}
	
	
	
	

	//�����ˮ
	public void insertMainChangeInfo() throws Exception{
		ArrayList<String> customerIDList = new ArrayList();
		//�����
		String insSql = "insert into Fund_Change_Ls_Temp ( INPUTDATE,CUSTOMERID,CHANGETYPE,BANKNO,CHANGEDATE,SERIALNO,PUTOUTNO,CONTRACTSERIALNO,"+
                                                           "MAINFUNDACCOUNTNO,MAINCERTID, MAINFULLNAME,EXECUTERATE,"+
                                                           "LOANTERM,MAINRETURNTYPE,OPERATEUSERID,OPERATEDATE, REMARK  ) "+
                         "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String selSql = " SELECT LB.CustomerID,(case when LC.Changetype = '210' then '210' when LC.Changetype = '010' then '230' when LC.Changetype in('040','070') then '240'"+
			            " when LC.Changetype = '030' then '250' else '260' end )as ChangeType,'000000' as bankNo,LC.Changedate,rownum as SerialNo,LB.Putoutno,LB.Contractserialno,II.Mainindfund,"+
			            " II.Certid,II.Fullname,LB.Executerate,LB.Loanterm,LB.Mainreturntype,'' as OperateUserID,LC.Changedate,'' as Remark"+
			            " FROM LOAN_BALANCE LB, LOAN_CHANGE LC, IND_INFO II WHERE LB.Businesstype = '1110070' and LC.Changedate = '2009/12/21'"+
			            " and ((LC.OBJECTTYPE = 'LoanBalance' and LB.PUTOUTNO=LC.OBJECTNO )or (LC.OBJECTTYPE = 'Customer_Info' and LB.CUSTOMERID=LC.OBJECTNO )"+
			            " or (LC.OBJECTTYPE = 'Customer_Info' and LB.Contractserialno=LC.OBJECTNO ))"+
						" and LB.Customerid=II.Customerid and LC.Status in('0','1','2')and exists (select 1 from Org_Belong where orgid = '100120' and BelongOrgid = LB.Orgid)";
  
		
		String selWLSql = "select II.Mainindfund,II.Certid,II.Fullname from Customer_Relative CR,Ind_Info II where II.Customerid = CR.Relativeid and CR.Customerid = ? and CR.Relationship = '0301'";
		//��ż�����������Ϣ
		String updWLSql = "update Fund_Change_Ls_Temp set WLFUNDACCOUNTNO=? ,WLCERTID =? ,WLFULLNAME =?  where CustomerID = ? and InputDate = ?";
		PreparedStatement preInsSt = connection.prepareStatement(insSql);
		PreparedStatement preSelSt = connection.prepareStatement(selSql);
		PreparedStatement preSelWLSt = connection.prepareStatement(selWLSql);
		PreparedStatement preUpdWLSt = connection.prepareStatement(updWLSql);
		ResultSet selRs = preSelSt.executeQuery();
		ResultSet selWLRs = null;
		
		while(selRs.next()){
			String sCustomerID = selRs.getString("CustomerID");
			customerIDList.add(sCustomerID);
			preInsSt.setString(1, deductDate);
			preInsSt.setString(2, sCustomerID);
			preInsSt.setString(3, selRs.getString("ChangeType"));
			preInsSt.setString(4, selRs.getString("bankNo"));
			preInsSt.setString(5, selRs.getString("Changedate"));
			preInsSt.setString(6, selRs.getString("SerialNo"));
			preInsSt.setString(7, selRs.getString("Putoutno"));
			preInsSt.setString(8, selRs.getString("Contractserialno"));
			preInsSt.setString(9, selRs.getString("Mainindfund"));
			preInsSt.setString(10, selRs.getString("Certid"));
			preInsSt.setString(11, selRs.getString("Fullname"));
			preInsSt.setString(12, selRs.getString("Executerate"));
			preInsSt.setString(13, selRs.getString("Loanterm"));
			preInsSt.setString(14, selRs.getString("Mainreturntype"));
			preInsSt.setString(15, selRs.getString("OperateUserID"));
			preInsSt.setString(16, selRs.getString("Changedate"));
			preInsSt.setString(17, selRs.getString("Remark"));
			
			preInsSt.addBatch();
			
			 icount++;
	            deductDataNum++;
				if(deductDataNum>=commitNum){
					preInsSt.executeBatch();
					deductDataNum=0;
				    logger.info("��ִ��"+icount+"����");
				}
		}
		
		preInsSt.executeBatch();
		deductDataNum=0;
		
		
		//������ż�����������Ϣ
		for(int i = 0;i < customerIDList.size();i++){
			
			String sCustomerID = (String)customerIDList.get(i);
			preSelWLSt.setString(1, sCustomerID);
			selWLRs = preSelWLSt.executeQuery();
			
			while(selWLRs.next()){
				preUpdWLSt.setString(1, selWLRs.getString("Mainindfund"));
				preUpdWLSt.setString(2, selWLRs.getString("Certid"));
				preUpdWLSt.setString(3, selWLRs.getString("Fullname"));
				preUpdWLSt.setString(4, sCustomerID);
				preUpdWLSt.setString(5, deductDate);
				
				preUpdWLSt.addBatch();
				deductDataNum++;
			}
			
			if(deductDataNum >= commitNum){
				preUpdWLSt.executeBatch();
				deductDataNum=0;
				logger.info("�Ѿ�����"+i+"����");
			}
			
			
		}
		
		preUpdWLSt.executeBatch();
		deductDataNum=0;
		
		selRs.close();
		if(selWLRs!=null) selWLRs.close();
		preInsSt.close();
		preSelSt.close();
		preSelWLSt.close();
		preUpdWLSt.close();
		
	}
	
	
	
	//������ˮ
	public void insertAccountLSInfo()throws Exception{
		
		
		String selSql = "select (case when bb.billtype = '10' then '110' when bb.billtype in ('50','52')  then '100' end) as FUND_ACCOUNTLS_ACCOUNTTYPE,"+
					    "'000000'  as FUND_ACCOUNTLS_BANKNO , bb.accdate as FUND_ACCOUNTLS_OPENACCDATE, rownum as FUND_ACCOUNTLS_SERIALNO,"+
					    " bb.putoutno as FUND_ACCOUNTLS_PUTOUTNO, lb.contractserialno as FUND_ACCOUNTLS_CONNO,"+
					    " (select bc.fundlendtype from business_contract bc where bc.serialno = lb.contractserialno) as FUND_ACCOUNTLS_FUNDLENDTYPE,"+
					    " ii.mainworkfund as FUND_ACCOUNTLS_MAINWORKFUND,ii.mainindfund as FUND_ACCOUNTLS_MAININDFUND,ii.certid as FUND_ACCOUNTLS_CERTID,"+
					    " ii.fullname as FUND_ACCOUNTLS_FULLNAME, round(nvl(lb.executerate,0),2) as FUND_ACCOUNTLS_EXECUTERATE,"+
					    " round(nvl(lb.businesssum,0),2) as FUND_ACCOUNTLS_BUSINESSSUM, lb.loanterm as FUND_ACCOUNTLS_LOANTERM,"+
					    " (case when lb.mainreturntype = '1' then '10' when lb.mainreturntype='2' then '20' else '99' end) as FUND_ACCOUNTLS_MAINRETURNTYPE ,"+
					    " bb.operateuserid as FUND_ACCOUNTLS_OPERATEUSERNAME,bb.accdate as FUND_ACCOUNTLS_OPERATEDATE, ''as FUND_ACCOUNTLS_REMARK,"+
					    " '' as FUND_ACCOUNTLS_ISDANBAO, '' as FUND_ACCOUNTLS_ACCEPTNO, round(nvl('',0),2) as FUND_ACCOUNTLS_COMBUSINESSSUM,"+
					    " '' as FUND_ACCOUNTLS_COMLOANTERM "+
					  " from back_bill bb, loan_balance lb, ind_info ii "+
					 " where lb.businesstype = '1110070'  and lb.putoutno = bb.putoutno and lb.customerid = ii.customerid  and bb.billtype in ('10','50','52') "+
					  " and bb.accdate = '"+deductDate+"' and exists (select 1 from Org_Belong where orgid = '100120' and BelongOrgid = bb.Orgid)";

		//���뿪����ˮ��
		String insSql = "insert into Fund_Account_Ls_Temp (  FUND_ACCOUNTLS_INPUTDATE,FUND_ACCOUNTLS_ACCOUNTTYPE,FUND_ACCOUNTLS_BANKNO,FUND_ACCOUNTLS_OPENACCDATE,"+
						" FUND_ACCOUNTLS_SERIALNO,FUND_ACCOUNTLS_PUTOUTNO, FUND_ACCOUNTLS_CONNO,FUND_ACCOUNTLS_FUNDLENDTYPE,FUND_ACCOUNTLS_MAINWORKFUND ,"+
						 " FUND_ACCOUNTLS_MAININDFUND , FUND_ACCOUNTLS_CERTID , FUND_ACCOUNTLS_FULLNAME ,FUND_ACCOUNTLS_EXECUTERATE,FUND_ACCOUNTLS_BUSINESSSUM ,"+
						 " FUND_ACCOUNTLS_LOANTERM  , FUND_ACCOUNTLS_MAINRETURNTYPE ,FUND_ACCOUNTLS_OPERATEUSERNAME, FUND_ACCOUNTLS_OPERATEDATE,"+
						 " FUND_ACCOUNTLS_REMARK, FUND_ACCOUNTLS_ISDANBAO ,FUND_ACCOUNTLS_ACCEPTNO,FUND_ACCOUNTLS_COMBUSINESSSUM, FUND_ACCOUNTLS_COMLOANTERM)" +
						 " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		
		PreparedStatement preselSt = connection.prepareStatement(selSql);
		PreparedStatement preinsSt = connection.prepareStatement(insSql);
		
		ResultSet selRs = preselSt.executeQuery();
		
		while(selRs.next()){
			preinsSt.setString(1, deductDate);
			preinsSt.setString(2, selRs.getString("FUND_ACCOUNTLS_ACCOUNTTYPE"));
			preinsSt.setString(3, selRs.getString("FUND_ACCOUNTLS_BANKNO"));
			preinsSt.setString(4, selRs.getString("FUND_ACCOUNTLS_OPENACCDATE"));
			preinsSt.setString(5, selRs.getString("FUND_ACCOUNTLS_SERIALNO"));
			preinsSt.setString(6, selRs.getString("FUND_ACCOUNTLS_PUTOUTNO"));
			preinsSt.setString(7, selRs.getString("FUND_ACCOUNTLS_CONNO"));
			preinsSt.setString(8, selRs.getString("FUND_ACCOUNTLS_FUNDLENDTYPE"));
			preinsSt.setString(9, selRs.getString("FUND_ACCOUNTLS_MAINWORKFUND"));
			preinsSt.setString(10, selRs.getString("FUND_ACCOUNTLS_MAININDFUND"));
			preinsSt.setString(11, selRs.getString("FUND_ACCOUNTLS_CERTID"));
			preinsSt.setString(12, selRs.getString("FUND_ACCOUNTLS_FULLNAME"));
			preinsSt.setString(13, selRs.getString("FUND_ACCOUNTLS_EXECUTERATE"));
			preinsSt.setString(14, selRs.getString("FUND_ACCOUNTLS_BUSINESSSUM"));
			preinsSt.setString(15, selRs.getString("FUND_ACCOUNTLS_LOANTERM"));
			preinsSt.setString(16, selRs.getString("FUND_ACCOUNTLS_MAINRETURNTYPE"));
			preinsSt.setString(17, selRs.getString("FUND_ACCOUNTLS_OPERATEUSERNAME"));
			preinsSt.setString(18, selRs.getString("FUND_ACCOUNTLS_OPERATEDATE"));
			preinsSt.setString(19, selRs.getString("FUND_ACCOUNTLS_REMARK"));
			preinsSt.setString(20, selRs.getString("FUND_ACCOUNTLS_ISDANBAO"));
			preinsSt.setString(21, selRs.getString("FUND_ACCOUNTLS_ACCEPTNO"));
			preinsSt.setString(22, selRs.getString("FUND_ACCOUNTLS_COMBUSINESSSUM"));
			preinsSt.setString(23, selRs.getString("FUND_ACCOUNTLS_COMLOANTERM"));
			
			preinsSt.addBatch();
			icount++;
            deductDataNum++;
			if(deductDataNum>=commitNum){
				preinsSt.executeBatch();
				deductDataNum=0;
			    logger.info("��ִ��"+icount+"����");
			}
			
		}
		preinsSt.executeBatch();
		deductDataNum=0;
		
		selRs.close();
		preselSt.close();
		preinsSt.close();

		
	}
	
	//������ˮ
	public void insertBackBillLS()throws Exception{
		
		String selSql = "select (case when lb.loanstatus = '10' and lb.finishdate = '"+deductDate+"' then '350' when lb.loanstatus = '20' and lb.finishdate = '"+deductDate+"' then '340' " +
				                     "when lb.loanstatus in ('0', '1') and bb.billtype in ('21', '23','24') then '320' "+
				                     "when lb.loanstatus in ('0', '1') and bb.billtype in ('51', '53') then '300' "+
				                     "when lb.loanstatus in ('0', '1') and bb.accdate > bb.paydate then '330' "+
						             " when lb.loanstatus in ('0', '1') and bb.accdate = bb.paydate then '310' "+
						             " when lb.loanstatus in ('0','1') and bb.billtype = '90' then '390'" +
						             " when lb.loanstatus in ('0','1') and bb.billtype = '30' then '100' end) as BACK_BILL_TYPE,"+
								" '000000' as BACK_BILL_BANKNO ,bb.accdate as BACK_BILL_ACCDATE,rownum as BACK_BILL_SERIALNO,"+
								" lb.putoutno as BACK_BILL_PUTOUTNO,nvl(bb.actualcurrentcorp+bb.actualoverduecorp+bb.actualdefaultcorp,0) as BACK_BILL_CORP,"+
								" nvl(bb.actualinte+bb.actualinnerinte+bb.actualoutinte+bb.actualinnerintefine+bb.actualoutintefine,0) as BACK_BILL_INTE,"+
								" nvl(bb.ActualInteFine,0) as BACK_BILL_PUBINTE," +
								" (nvl(bb.actualcurrentcorp+bb.actualoverduecorp+bb.actualdefaultcorp,0)+nvl(bb.actualinte+bb.actualinnerinte+bb.actualoutinte+bb.actualinnerintefine+bb.actualoutintefine,0)+nvl('',0)) as BACK_BILL_SUM,"+
								" (select lr.overdays from loanbalance_relative lr where lr.putoutno = lb.putoutno) as BACK_BILL_OVERDAYS,"+
								" substr(lb.nextpaydate,0,7) as BACK_BILL_PAYDATE, round(months_between(to_date(lb.maturitydate, 'YYYY/MM/DD'),"+
								" to_date(lb.lastintedate, 'YYYY/MM/DD'))) as BACK_BILL_LASTTERM,bb.operateuserid as BACK_BILL_USERID,"+
								" bb.accdate as BACK_BILL_OPERATEDATE,'' as BACK_BILL_REMARK"+
								" from back_bill bb, loan_balance lb"+
								" where  bb.billtype in ('20', '21', '22', '23', '24', '51', '53')"+
								" and lb.businesstype = '1110070'"+
								" and lb.putoutno = bb.putoutno"+
								" and bb.accdate = '"+deductDate+"'"+
								" and exists (select 1 from Org_Belong where orgid = '100120' and BelongOrgid = bb.Orgid)";
			//���뻹����ˮ��
		 String insSql = "insert into Fund_BackBill_Ls_Temp ( BACK_BILL_INPUTDATE, BACK_BILL_TYPE ,BACK_BILL_BANKNO, BACK_BILL_ACCDATE,"+
	                     "BACK_BILL_SERIALNO,BACK_BILL_PUTOUTNO, BACK_BILL_CORP ,BACK_BILL_INTE,BACK_BILL_PUBINTE,BACK_BILL_SUM ,"+
						 " BACK_BILL_OVERDAYS ,BACK_BILL_PAYDATE ,BACK_BILL_LASTTERM,BACK_BILL_USERID ,BACK_BILL_OPERATEDATE,"+
						 " BACK_BILL_REMARK ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 
		 PreparedStatement preselSt = connection.prepareStatement(selSql);
		 PreparedStatement preinsSt = connection.prepareStatement(insSql);
		 ResultSet selRs = preselSt.executeQuery();
			
		 while(selRs.next()){
			 
			    preinsSt.setString(1, deductDate);
				preinsSt.setString(2, selRs.getString("BACK_BILL_TYPE"));
				preinsSt.setString(3, selRs.getString("BACK_BILL_BANKNO"));
				preinsSt.setString(4, selRs.getString("BACK_BILL_ACCDATE"));
				preinsSt.setString(5, selRs.getString("BACK_BILL_SERIALNO"));
				preinsSt.setString(6, selRs.getString("BACK_BILL_PUTOUTNO"));
				preinsSt.setDouble(7, selRs.getDouble("BACK_BILL_CORP"));
				preinsSt.setDouble(8, selRs.getDouble("BACK_BILL_INTE"));
				preinsSt.setDouble(9, selRs.getDouble("BACK_BILL_PUBINTE"));
				preinsSt.setDouble(10, selRs.getDouble("BACK_BILL_SUM"));
				preinsSt.setInt(11, selRs.getInt("BACK_BILL_OVERDAYS"));
				preinsSt.setString(12, selRs.getString("BACK_BILL_PAYDATE"));
				preinsSt.setInt(13, selRs.getInt("BACK_BILL_LASTTERM"));
				preinsSt.setString(14, selRs.getString("BACK_BILL_USERID"));
				preinsSt.setString(15, selRs.getString("BACK_BILL_OPERATEDATE"));
				preinsSt.setString(16, selRs.getString("BACK_BILL_REMARK"));
				
				preinsSt.addBatch();
				icount++;
	            deductDataNum++;
				if(deductDataNum>=commitNum){
					preinsSt.executeBatch();
					deductDataNum=0;
				    logger.info("��ִ��"+icount+"����");
				}
				
			}
			preinsSt.executeBatch();
			deductDataNum=0;
	 
	 
		selRs.close();
		preselSt.close();
		preinsSt.close();
	 
	}
	
	
	//������ˮ
	public void insertFinishLS() throws Exception{
		

		
		String selSql = "select (case  when lb.loanstatus = '20' then '410'when lb.loanstatus = '30' then '420'"+
									    "when lb.loanstatus = '10' then '430' when lb.loanstatus = '80' then '400'"+
									    " else  '440' end) as Fund_Finish_Type," +
									    " '000000' as Fund_Finish_Org, lb.finishdate as Fund_Finish_OccDate,rownum as Fund_Finish_SerialNo," +
									    " lb.putoutno as Fund_Finish_PutOutNo,lb.userid as Fund_Finish_UserID,lb.finishdate as Fund_Finish_OperateDate,"+
									    " ''as Fund_Finish_Remark"+
									    " from loan_balance lb where lb.loanstatus not in ('0', '1')and lb.finishdate = '"+deductDate+"'"+
									    " and lb.businesstype = '1110070'  and exists (select 1 from Org_Belong where orgid = '100120' and BelongOrgid = lb.Orgid)";
        //����������ˮ��			
		 String insSql = "insert into Fund_Finish_Ls_Temp( FUND_FINISH_INPUTDATE ,FUND_FINISH_TYPE,FUND_FINISH_ORG,FUND_FINISH_OCCDATE ,FUND_FINISH_SERIALNO ," +
		 	             " FUND_FINISH_PUTOUTNO,FUND_FINISH_USERID ,FUND_FINISH_OPERATEDATE,FUND_FINISH_REMARK  ) values(?,?,?,?,?,?,?,?,?)";
		 
		 PreparedStatement preselSt = connection.prepareStatement(selSql);
		 PreparedStatement preinsSt = connection.prepareStatement(insSql);
		 ResultSet selRs = preselSt.executeQuery();
			
		 while(selRs.next()){
			 
			    preinsSt.setString(1, deductDate);
				preinsSt.setString(2, selRs.getString("Fund_Finish_Type"));
				preinsSt.setString(3, selRs.getString("Fund_Finish_Org"));
				preinsSt.setString(4, selRs.getString("Fund_Finish_OccDate"));
				preinsSt.setString(5, selRs.getString("Fund_Finish_SerialNo"));
				preinsSt.setString(6, selRs.getString("Fund_Finish_PutOutNo"));
				preinsSt.setString(7, selRs.getString("Fund_Finish_UserID"));
				preinsSt.setString(8, selRs.getString("Fund_Finish_OperateDate"));
				preinsSt.setString(9, selRs.getString("Fund_Finish_Remark"));
				
				preinsSt.addBatch();
				icount++;
	            deductDataNum++;
				if(deductDataNum>=commitNum){
					preinsSt.executeBatch();
					deductDataNum=0;
				    logger.info("��ִ��"+icount+"����");
				}
				
			}
			preinsSt.executeBatch();
			deductDataNum=0;
	 
	 
		selRs.close();
		preselSt.close();
		preinsSt.close();
	 
	}
	
	/**
	 * �δ��˻�����Ϣ��
	 * @throws Exception
	 */
	
	
	public void insertBAPInfo() throws Exception {
		

		
		String selSql = "select '920' as Fund_Bap_BusinessType, LB.Putoutno as Fund_Bap_PutOutNo,II.Fullname as Fund_Bap_FullName,"+
	                   " II.Certid as Fund_Bap_CertID,"+
	                   " (case when BAp.Relationship= '0302' and II.Sex = '1' then '10' when BAp.Relationship = '0302' and II.Sex = '2' then '20'" +
	                   "  when BAp.Relationship = '0304' and II.Sex = '1' then '30' when BAp.Relationship = '0304' and II.Sex = '2' then '40' else '99' end ) as Fund_Bap_Relationship,"+
	                   " round(nvl(II.Monthincome,0)) as Fund_Bap_MonthIncome,"+
	                   " II.Mainworkfund as Fund_Bap_MainWorkFund,"+
	                   " II.Mainindfund as Fund_Bap_MainIndFund,"+
	                   " round(nvl(II.Fundmonmoney,0)) as Fund_Bap_FundMonMoney,"+
	                   " round(nvl(II.Comfundmoney,0)) as Fund_Bap_ComFundMoney,"+
	                   " round(nvl(II.Fundbalance,0),2) as Fund_Bap_FundBalance,"+
	                   " round(nvl(II.Compfundbalance,0),2) as Fund_Bap_CompFundBalance,"+
	                   " '' as Fund_Bap_Remark "+
	                   " from Business_Applicant BAp, Loan_Balance LB, Ind_Info II"+
	                   " where BAp.Objecttype = 'CBContractApply'"+
	                   " and BAp.Objectno = LB.Contractserialno"+
	                   " and II.CUSTOMERID = BAp.Applicantid"+
	                   " and LB.BUSINESSTYPE = '1110070'"+
	                   " and LB.LOANSTATUS in ('0', '1')"+
	                   " and LB.PutoutDate='"+deductDate+"'"+
	                   " and exists (select 1 from org_belong where belongorgid = LB.OrgID and orgid = '100120' )";
			//����δ���Ϣ��
		 String insSql = " insert into Fund_Bap_Info_Temp (FUND_BAP_INPUTDATE,Fund_Bap_BusinessType,FUND_BAP_PUTOUTNO,FUND_BAP_FULLNAME,FUND_BAP_CERTID ,FUND_BAP_RELATIONSHIP," +
		 		         " FUND_BAP_MONTHINCOME,FUND_BAP_MAINWORKFUND, FUND_BAP_MAININDFUND, FUND_BAP_FUNDMONMONEY,FUND_BAP_COMFUNDMONEY, FUND_BAP_FUNDBALANCE,FUND_BAP_COMPFUNDBALANCE,"+
                         " FUND_BAP_REMARK ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 
		 PreparedStatement preselSt = connection.prepareStatement(selSql);
		 PreparedStatement preinsSt = connection.prepareStatement(insSql);
		 ResultSet selRs = preselSt.executeQuery();
			
		 while(selRs.next()){
			 
			    preinsSt.setString(1, deductDate);
			    preinsSt.setString(2, selRs.getString("Fund_Bap_BusinessType"));
				preinsSt.setString(3, selRs.getString("Fund_Bap_PutOutNo"));
				preinsSt.setString(4, selRs.getString("Fund_Bap_FullName"));
				preinsSt.setString(5, selRs.getString("Fund_Bap_CertID"));
				preinsSt.setString(6, selRs.getString("Fund_Bap_Relationship"));
				preinsSt.setDouble(7, selRs.getDouble("Fund_Bap_MonthIncome"));
				preinsSt.setString(8, selRs.getString("Fund_Bap_MainWorkFund"));
				preinsSt.setString(9, selRs.getString("Fund_Bap_MainIndFund"));
				preinsSt.setDouble(10, selRs.getDouble("Fund_Bap_FundMonMoney"));
				preinsSt.setDouble(11, selRs.getDouble("Fund_Bap_ComFundMoney"));
				preinsSt.setDouble(12, selRs.getDouble("Fund_Bap_FundBalance"));
				preinsSt.setDouble(13, selRs.getDouble("Fund_Bap_CompFundBalance"));
				preinsSt.setString(14, selRs.getString("Fund_Bap_Remark"));
				
				preinsSt.addBatch();
				icount++;
	            deductDataNum++;
				if(deductDataNum>=commitNum){
					preinsSt.executeBatch();
					deductDataNum=0;
				    logger.info("��ִ��"+icount+"����");
				}
				
			}
			preinsSt.executeBatch();
			deductDataNum=0;
	 
	 
		selRs.close();
		preselSt.close();
		preinsSt.close();
	 
	
	}
        
	
	
	
	/**
	 * ��ĩ���˱�
	 * @throws Exception
	 */
	
public void insertMonDZInfo() throws Exception {
		

		

		ArrayList putoutNoList = new ArrayList();
		String selSql = "select lb.putoutno as PutOutNo,  nvl(lb.businesssum,0) as BusinessSum, " +
				         "nvl((lb.normalbalance + lb.currentbalance+lb.overduebalance),0) as Balance,"+
						 "(lb.CTerm - lb.STerm + 1) as LastTerm,lr.addoverterms as OverTerm,"+
                         "(case when lb.loanstatus not in ('0', '1') then '20' "+
                                " when lb.loanstatus in ('0', '1') and lr.overdays > 0 then '30' "+
                                " else '10' end) as Status"+
                         "  From loan_balance lb, loanbalance_relative lr"+
                         "  where (lb.loanstatus in ('0', '1') or lb.finishdate like '"+currentMonth+"%') "+
                         "  and lr.putoutno = lb.putoutno and lb.businesstype = '1110070' "+
                         "  and exists (select 1 from org_belong ob where ob.orgid = '100120'and ob.belongorgid = lb.orgid)";
			
		 String insSql = " insert into   FUND_MONTHDZ_INFO_TEMP (FUND_MONTHDZ_INPUTDATE ,FUND_MONTHDZ_PUTOUTNO ,FUND_MONTHDZ_BUSINESSSUM ," +
		 		         " FUND_MONTHDZ_BALANCE,FUND_MONTHDZ_LASTTERM  ,FUND_MONTHDZ_OVERTERM ,FUND_MONTHDZ_STATUS)"+
						 "	values (?,?,?,?,?,?,?)";
		 
		 //Ϊ��ִ��Ч�ʣ������в������ݲ��ø��·�ʽ����
		 String updSql = "update Fund_MonthDZ_Info_Temp set FUND_MONTHDZ_INTE = ?,FUND_MONTHDZ_FINE = ?,FUND_MONTHDZ_LASTPAY =? ,FUND_MONTHDZ_MONEY = ? where FUND_MONTHDZ_PUTOUTNO = ? and FUND_MONTHDZ_INPUTDATE = '"+deductDate+"'"; 
		 String selBBSql = "select sum(actualinte + actualinnerinte + actualoutinte - actualintefine) as FUND_MONTHDZ_INTE,"+
						   " sum(ACTUALINNERINTEFINE + ACTUALOUTINTEFINE + actualintefine) as FUND_MONTHDZ_FINE,"+
						   " sum(decode(accdate," +
						   "(select max(accdate)  from back_bill bb2 where bb2.putoutno = ? and bb2.billtype in ('20', '21', '23', '22', '24'))," +
						   " nvl(ACTUALCURRENTCORP + ACTUALDEFAULTCORP +ACTUALOVERDUECORP + ACTUALINTE + ACTUALINNERINTE +ACTUALOUTINTE + ACTUALINNERINTEFINE +ACTUALOUTINTEFINE, 0),0)) as FUND_MONTHDZ_LASTPAY,"+
						   " sum(nvl(actualcurrentcorp+actualoverduecorp,0)) as FUND_MONTHDZ_MONEY from back_bill where putoutno = ? and billtype in ('20', '21', '23', '22', '24') ";
		 PreparedStatement preselSt = connection.prepareStatement(selSql);
		 PreparedStatement preinsSt = connection.prepareStatement(insSql);
		 PreparedStatement preupdSt = connection.prepareStatement(updSql);
		 PreparedStatement preselBBSt = connection.prepareStatement(selBBSql);
		 ResultSet selRs = preselSt.executeQuery();
		 ResultSet selBBRs = null;
		
		 //�����������Ϣ
		 while(selRs.next()){
			    String putOutNo = selRs.getString("PutOutNo");
			    putoutNoList.add(putOutNo);
			    preinsSt.setString(1, deductDate);
			    preinsSt.setString(2, putOutNo);
				preinsSt.setDouble(3, selRs.getDouble("BusinessSum"));
				preinsSt.setDouble(4, selRs.getDouble("Balance"));
				preinsSt.setString(5, selRs.getString("LastTerm"));
				preinsSt.setString(6, selRs.getString("OverTerm"));
				preinsSt.setDouble(7, selRs.getDouble("Status"));
				preinsSt.addBatch();
				icount++;
	            deductDataNum++;
				if(deductDataNum>=commitNum){
					preinsSt.executeBatch();
					deductDataNum=0;
				    logger.info("��ִ��"+icount+"����");
				}
				
			}
			preinsSt.executeBatch();
			deductDataNum=0;
			
			//���±���������Ϣ
			for(int i = 0;i< putoutNoList.size();i++){
				String putoutNo = (String)putoutNoList.get(i);
				preselBBSt.setString(1, putoutNo);
				preselBBSt.setString(2, putoutNo);
				selBBRs = preselBBSt.executeQuery();
				
				while(selBBRs.next()){
					
					preupdSt.setDouble(1, selBBRs.getDouble("FUND_MONTHDZ_INTE"));
					preupdSt.setDouble(2, selBBRs.getDouble("FUND_MONTHDZ_FINE"));
					preupdSt.setDouble(3, selBBRs.getDouble("FUND_MONTHDZ_LASTPAY"));
					preupdSt.setDouble(4, selBBRs.getDouble("FUND_MONTHDZ_MONEY"));
					preupdSt.setString(5, putoutNo);
					preupdSt.addBatch();
					
					if(deductDataNum>=commitNum){
						preupdSt.executeBatch();
						deductDataNum=0;
					    logger.info("��ִ��"+icount+"����");
					}
				}
				
			}
			
			preupdSt.executeBatch();
			deductDataNum=0;
	 
	 
			
		if(selBBRs!=null) selBBRs.close();
		selRs.close();
		preselSt.close();
		preinsSt.close();
		preupdSt.close();
		preselBBSt.close();
	 
	
	}

}
