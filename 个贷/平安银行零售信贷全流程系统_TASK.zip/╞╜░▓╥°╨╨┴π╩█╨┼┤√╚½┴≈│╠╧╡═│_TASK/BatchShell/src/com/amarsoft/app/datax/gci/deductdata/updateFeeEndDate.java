package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;


/**
 * ���õ������޴���
 * @author EX-WANLONG001
 * */
public class updateFeeEndDate extends CommonExecuteUnit{
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("�������õ������ڿ�ʼ������");
				dealFeeEndDate();
				logger.info("�������õ���������� ��");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}  	
		
	}
	
	public void dealFeeEndDate(){
		//�������
		String SystemNo="",Flag="";
		int term=0;
		
		//����ȡ���ڵ���������ĵ�������
		String sql="select ItemNo,RelativeCode,Attribute1 from Code_Library where CodeNo='FeeConfig' "+
				   " and IsInUse='1' AND ItemDescribe='"+deductDate+"'";
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				SystemNo=DataConvert.toString(rs.getString("ItemNo"));//ϵͳ��ţ�SWPM.RCPM��
				term=DataConvert.toInt(rs.getString("RelativeCode"));//����
				Flag=DataConvert.toString(rs.getString("Attribute1"));//�ո���־��A��P��
				
				if("A".equals(Flag)){//��ȡ
					String sqlfeedetialIn="Select Afd.SerialNo as SerialNo, afd.BeginDate as BeginDate From Acct_Fee_Detail Afd "+
										  " Where Afd.Objecttype In ('SWTransPayApply', 'SWPutOutApply')"+
										  " And Exists (Select 1 From Business_Putout Bp Where Bp.Serialno = Afd.Objectno "+
										  " And Bp.Businesskind = '"+SystemNo+"') "+
										  " and afd.ifdeferred = '1' and afd.status = '0'";
					PreparedStatement ps1 = connection.prepareStatement(sqlfeedetialIn);
					ResultSet rs1=ps1.executeQuery();
					while(rs1.next()){
						String sSerialNo=DataConvert.toString(rs1.getString("SerialNo"));
						String sBeginDate=DataConvert.toString(rs1.getString("BeginDate"));
						String sEndDate=DateTools.getRelativeDate(sBeginDate, "M", term);
						
						if(sEndDate.compareTo(nextDate)<0)sEndDate=nextDate;
						
						String updatesql="update Acct_Fee_Detail set Enddate='"+sEndDate+"' where SerialNo='"+sSerialNo+"'";
						PreparedStatement ps2 = connection.prepareStatement(updatesql);
						ps2.execute();
						ps2.close();
					}
					rs1.close();
					ps1.close();
				}else{
					String sqlfeedetialIn="Select Afd.SerialNo as SerialNo, afd.BeginDate as BeginDate From Acct_Fee_Detail Afd "+
										 " Where Afd.Objecttype='SWPayFeeApply' and afd.FeeType='"+SystemNo+"'"+
										 " and afd.ifdeferred = '1' and afd.status = '0'";
					PreparedStatement ps1 = connection.prepareStatement(sqlfeedetialIn);
					ResultSet rs1=ps1.executeQuery();
					while(rs1.next()){
						String sSerialNo=DataConvert.toString(rs1.getString("SerialNo"));
						String sBeginDate=DataConvert.toString(rs1.getString("BeginDate"));
						String sEndDate=DateTools.getRelativeDate(sBeginDate, "M", term);
						
						if(sEndDate.compareTo(nextDate)<0)sEndDate=nextDate;
						
						String updatesql="update Acct_Fee_Detail set Enddate='"+sEndDate+"' where SerialNo='"+sSerialNo+"'";
						PreparedStatement ps2 = connection.prepareStatement(updatesql);
						ps2.execute();
						ps2.close();
					}
					rs1.close();
					ps1.close();
				}
			}
			rs.close();
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
