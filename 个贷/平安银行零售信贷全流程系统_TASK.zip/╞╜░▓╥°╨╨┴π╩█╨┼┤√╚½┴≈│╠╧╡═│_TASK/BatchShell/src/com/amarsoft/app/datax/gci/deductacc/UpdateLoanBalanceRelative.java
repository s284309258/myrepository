package com.amarsoft.app.datax.gci.deductacc;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateLoanBalanceRelative extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				logger.info("��ʼ����loanBalance_relative...");
				calcThreadNum(); 
				multiThread("com.amarsoft.app.datax.gci.deductacc.thread.UpdateLoanBalanceRelativeThread");
				if(errorThreadNumber > 0)
				{
					throw new Exception("����loanBalance_relative��"+errorThreadNumber+"���̳߳����쳣��������־��");
				}
				logger.info("����loanBalance_relative���");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
