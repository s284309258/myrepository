package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateAccountAsCreditCard extends CommonExecuteUnit{

	private static final String PreparedStatement = null;
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	
	@Override
	public int execute() {

		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" delete from ACCOUNT_ASCREDITCARD ";
				logger.info("��� ACCOUNT_ASCREDITCARD:sql="+delSql);
				PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
				psDeleteDeductData.execute();
				logger.info("���ACCOUNT_ASCREDITCARD������� ");
				psDeleteDeductData.close();
				
				logger.info("��ʼ��V+�������ݱ�......");
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				batchCreateAccountAsCreditCard();
				logger.info("����ʼ����������"+icount+"����");
				logger.info("��ʼ��V+�������ݱ���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}

	public void batchCreateAccountAsCreditCard() throws Exception 
	{
		
		try
		{
			String insertSql1 = "insert into account_ascreditcard(CARDNUMBER,TRANCODE,TRANAMOUNT,TRANDATE,TRANTIME,LOANFLAG,"
								+ "LOANTOTTERM,LOANCURRTERM,LOANSEQ,LOANADVFLAG,LOANORLENDFLAG,ISOTRANAMOUNT) values(?,?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement psInsertSql1 = connection.prepareStatement(insertSql1);
			connection.setAutoCommit(false);
			String selectSql = "select lb.putoutno,lb.DeductAccNo, lb.loanterm, lb.loanstatus, " +
			" bb.sterm as sterm,replace(bb.accdate, '/') as accdate  , " +
			"abs(bb.actualcurrentcorp+bb.actualdefaultcorp+bb.actualoverduecorp) as corp, " +
			"(case when bb.BillType in('20','21','22','23','24','55','56','57') then '621' else case when bb.BillType in('51','53') then '622' else '0' end end) as Type, " +
			"(case when bb.BillType in('20','21','22','23','24','55','56','57') then 'D' else case when bb.BillType in('51','53') then 'C' else '0' end end) as Dir, " +
			" (case when bb.billtype in ('21','23','24','55','56','57') then 'Y' else ' ' end) as OffFlag   from back_bill bb,loan_balance lb,loanbalance_relative lr " +
			" where lb.putoutno = bb.putoutno and lb.putoutno = lr.putoutno and lb.businesstype = '1120030'and bb.accdate = '"+deductDate+"' " +
			" and bb.billtype in ('20', '21', '22', '23', '24', '55', '56', '57') " +
			"  union all " +
			" select lb.putoutno,lb.DeductAccNo,lb.loanterm,lb.loanstatus, " +
			"nvl((select sterm from loanback_status where putoutno = lb.putoutno and paydate = fb.paydate),lb.sterm-1) as sterm,replace(fb.accdate, '/') as accdate, " +
			" abs(fb.amount) as corp,(case when fb.billtype in('10','20','40') then '623' else case when fb.billtype in('30','50') then '624' else '0' end end) as Type, " +
			"(case when fb.billtype in('10','20','40') then 'D' else case when fb.billtype in('30','50') then 'C' else '0' end end) as Dir, " +
			"' ' as OffFlag  from loan_balance lb,fare_bill fb " +
			" where lb.putoutno = fb.putoutno and lb.businesstype = '1120030' and fb.billtype in('10','20','40','50') and fb.accdate = '"+deductDate+"' " +
			" union all " +
			" select lb.putoutno,lb.DeductAccNo, lb.loanterm, lb.loanstatus, " +
			" bb.sterm as sterm, replace(bb.accdate, '/') as accdate  , " +
			" lb.businesssum , '622' as Type, 'C' as Dir, " +
			" ' ' as OffFlag   from back_bill bb,loan_balance lb,loanbalance_relative lr " +
			" where lb.putoutno = bb.putoutno and lb.putoutno = lr.putoutno and lb.businesstype = '1120030' and bb.accdate = '"+deductDate+"' " +
			" and bb.billtype in ( '55', '56', '57') ";
			logger.info(selectSql);
			PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
			ResultSet rs = psSelectSql.executeQuery();
			while(rs.next())
			{
				dealNum++;
				String DeductAccNo = rs.getString("DeductAccNo");//���ÿ�����
				String LoanTerm = String.valueOf(rs.getInt("loanterm"));//���ڴ�
				String LoanStatus = rs.getString("loanstatus");//�����־
				String sTerm = String .valueOf(rs.getInt("sterm"));//��ǰ�ڴ�
				String accDate = rs.getString("accdate");//������
				String Type = rs.getString("type");  //�������
				String LoanSEQ = rs.getString("putoutno");				//������ˮ��
				double Corp = rs.getDouble("corp");  //Ӧ������
				String Dir = rs.getString("Dir");	//��������
				String OffFlag = rs.getString("OffFlag"); //��ǰ�����־
				String ISOAmount = "1562"+Dir+getStringCorp(String.valueOf(Corp));
				
				this.insertAccount(psInsertSql1,DeductAccNo, Type, Corp, accDate, LoanTerm, sTerm, LoanSEQ, OffFlag, Dir, ISOAmount);
				icount++;
			
				if(dealNum>=commitNum)
				{
					dealNum=0;
					psInsertSql1.executeBatch();
					logger.info("�ѳ�ʼ������V+��������"+icount+"����");
				}
			}
			rs.close();
			psSelectSql.close();
			psInsertSql1.executeBatch();
			psInsertSql1.close();
			connection.commit();
		}catch(Exception e)
		{
			connection.rollback();
			e.printStackTrace();
			throw new Exception("��ʼ��V+�������ݱ�ʧ��");
		}
	}
	
	public String getStringCorp(String s)
	{
		String temp=s;
		if(s.indexOf(".")>0) temp=s.substring(0,s.indexOf("."));
		s=NumberTools.numberFormat(Double.parseDouble(s),temp.length(), 2);
		int a = 17-s.length();
        for(int i=0;i<a;i++){
    		s="0"+s;
    	}
        s = "0"+s.substring(0,s.indexOf("."))+s.substring(s.indexOf(".")+1,s.length());
        return s;
	}
	
	public void insertAccount(PreparedStatement psInsertSql1,String CardNumber, String TranCode,
			double TranAmount, String TranDate, String LoanTotTerm,
			String LoanCurrTerm, String LoanSEQ, String LoanAdvFlag,
			String LoanOrlendFlag, String ISOTranAmount) throws Exception {
		try {

			psInsertSql1.setString(1, CardNumber); // ���ÿ�����
			psInsertSql1.setString(2, TranCode); // ������
			psInsertSql1.setDouble(3, TranAmount); // ���׽��
			psInsertSql1.setString(4, TranDate); // ��������
			psInsertSql1.setString(5, "00000000"); // ����ʱ��
			psInsertSql1.setString(6, "C"); // ���������ʶ,Ĭ��"C"
			psInsertSql1.setString(7, LoanTotTerm); // ����������
			psInsertSql1.setString(8, LoanCurrTerm); // ��ǰ����
			psInsertSql1.setString(9, LoanSEQ); // ��ݺ�
			psInsertSql1.setString(10, LoanAdvFlag); // �����־
			psInsertSql1.setString(11, LoanOrlendFlag); // �����־
			psInsertSql1.setString(12, ISOTranAmount); // ISO���׽��
			psInsertSql1.addBatch();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}
}
