package com.amarsoft.app.datax.gci.deductdata;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.amarsoft.DBConnection.DBConnection;

public class InsertAccountAsCreditCard {

	public void insertAccount(String CardNumber,String TranCode,double TranAmount,String TranDate,
					String LoanTotTerm,String LoanCurrTerm,String LoanSEQ,String LoanAdvFlag,String LoanOrlendFlag,String ISOTranAmount) 
	{
		try
		{
			DBConnection dc = new DBConnection();
			Connection connection;
			connection =dc.getConn("Loan");
			
			String insertSql1 = "insert into account_ascreditcard(CARDNUMBER,TRANCODE,TRANAMOUNT,TRANDATE,TRANTIME,LOANFLAG," +
			"LOANTOTTERM,LOANCURRTERM,LOANSEQ,LOANADVFLAG,LOANORLENDFLAG,ISOTRANAMOUNT) values(?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement psInsertSql1 = connection.prepareStatement(insertSql1);
			
			psInsertSql1.setString(1, CardNumber); //���ÿ�����
			psInsertSql1.setString(2, TranCode);  //������
			psInsertSql1.setDouble(3, TranAmount);  //���׽��
			psInsertSql1.setString(4, TranDate);	//��������
			psInsertSql1.setString(5, "00000000");	//����ʱ��
			psInsertSql1.setString(6, "C");	//���������ʶ,Ĭ��"C"
			psInsertSql1.setString(7, LoanTotTerm);		//����������
			psInsertSql1.setString(8, LoanCurrTerm);	//��ǰ����
			psInsertSql1.setString(9, LoanSEQ);		//��ݺ�
			psInsertSql1.setString(10, LoanAdvFlag);	//�����־
			psInsertSql1.setString(11, LoanOrlendFlag);		//�����־
			psInsertSql1.setString(12, ISOTranAmount);		//ISO���׽��
			psInsertSql1.execute();
			psInsertSql1.close();

			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
