package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

public class FilesTransfer1WithDC extends CommonExecuteUnit{

	private String sSeq_id; 
	private String sFile_path; 
	private String sMegType;
	
	@Override
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPare();
				sendFileTODC();
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void initPare() throws Exception
	{
//		OCIConfig.loadOCIConfig(true);
//		OCIConfig.setEnvironment("Cycle");
//		OCIConfig.setDataSourceName("Loan");
		
		sSeq_id = this.getProperty("Seq_id");
		String sDate = StringFunction.replace(deductDate,"/","");
		String sMonth = StringFunction.replace(currentMonth,"/","");
		String sTime = StringFunction.replace(StringFunction.getNow(), ":", "");
		sSeq_id=StringFunction.replace(sSeq_id,"{$CurrentDate}",sDate);
		sSeq_id=StringFunction.replace(sSeq_id,"{$CurrentMonth}",sMonth);
		sSeq_id=StringFunction.replace(sSeq_id,"{$Time}",sTime);
		
		sFile_path = this.getProperty("File_path");
		sFile_path=StringFunction.replace(sFile_path,"{$CurrentDate}",sDate);
		sFile_path=StringFunction.replace(sFile_path,"{$CurrentMonth}",sMonth);
		sMegType = this.getProperty("MegType");
	}
	//����ESB����V+�����ļ�,����
	//�ļ�����,�������Ϊ�����������������û������α�š��ļ�·������¼��
	public void sendFileTODC() throws Exception
	{
		ESBInstance esbInstance = new ESBInstance();
		int icount = 0;
		String tempSql = " select count(*) as icount from account_ascreditcard ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		ResultSet rs = psTempSql.executeQuery();
		if(rs.next()){
			icount = rs.getInt("icount") + 2;
		}
		rs.close();
		psTempSql.close();
		logger.info("icount==" + icount);
		CompositeData compositeData = esbInstance.filesTransferForDC("", "",sSeq_id,sFile_path, String.valueOf(icount),"947444","790162");//�ļ�����
		String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF
		String ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");//�������������׳ɹ�����ʧ��ԭ��
		if(ret_status.startsWith("S")){
			logger.info("��V+����"+sMegType+"��Ϣ�ɹ���");
		}else{
			throw new Exception("V+����"+sMegType+"��Ϣʧ�ܣ�ʧ��ԭ��"+ret_msg);
		}
	}
}
