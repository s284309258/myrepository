package com.amarsoft.app.datax.gci;

public class QRateFloatCode {

	private String sBusinessType;
	private String sOrgID;
	private int iMinOverDays;
	private int iMaxOverDays;
	private double dMinOldRateFloat;
	private double dMaxOldRateFloat;
	private String sRateFloatType;
	private double dRateFloatValue;
	private int dNomalRepayNum;
	
	public String getSBusinessType() {
		return sBusinessType;
	}
	public void setSBusinessType(String businessType) {
		sBusinessType = businessType;
	}
	public String getSOrgID() {
		return sOrgID;
	}
	public void setSOrgID(String orgID) {
		sOrgID = orgID;
	}
	public int getIMinOverDays() {
		return iMinOverDays;
	}
	public void setIMinOverDays(int minOverDays) {
		iMinOverDays = minOverDays;
	}
	public int getIMaxOverDays() {
		return iMaxOverDays;
	}
	public void setIMaxOverDays(int maxOverDays) {
		iMaxOverDays = maxOverDays;
	}
	public double getDMinOldRateFloat() {
		return dMinOldRateFloat;
	}
	public void setDMinOldRateFloat(double minOldRateFloat) {
		dMinOldRateFloat = minOldRateFloat;
	}
	public double getDMaxOldRateFloat() {
		return dMaxOldRateFloat;
	}
	public void setDMaxOldRateFloat(double maxOldRateFloat) {
		dMaxOldRateFloat = maxOldRateFloat;
	}
	public String getSRateFloatType() {
		return sRateFloatType;
	}
	public void setSRateFloatType(String rateFloatType) {
		sRateFloatType = rateFloatType;
	}
	public double getDRateFloatValue() {
		return dRateFloatValue;
	}
	public void setDRateFloatValue(double rateFloatValue) {
		dRateFloatValue = rateFloatValue;
	}
	public int getDNomalRepayNum() {
		return dNomalRepayNum;
	}
	public void setDNomalRepayNum(int nomalRepayNum) {
		dNomalRepayNum = nomalRepayNum;
	}
	
	
}
