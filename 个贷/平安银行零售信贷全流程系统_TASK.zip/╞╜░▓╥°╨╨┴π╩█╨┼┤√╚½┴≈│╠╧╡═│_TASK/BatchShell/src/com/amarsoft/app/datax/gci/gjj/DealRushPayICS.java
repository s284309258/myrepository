package com.amarsoft.app.datax.gci.gjj;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.write.TransAccountEntryArray;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

/**
 * ����Down�ļ����ݺ�loan_balance����BtoX����
 * @author XIATIAN020
 * @since 2012-06-06
 */

public class DealRushPayICS extends CommonExecuteUnit{
	
		public int execute() {
				
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{	
					logger.info("���г廹��ICS��������ʼ......");
					deal();
					logger.info("���г廹��ICS��������ɣ�");
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}

		public void deal() throws Exception {

			String selectSqlReturn = " select BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID" +
									" from GJJ_RETURN " +
									" where InputDate = ? and LoanType in('01','03') and Status = '0' ";
			String selectSqlUpdate = " select BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID" +
									" from GJJ_UPDATE " +
									" where InputDate = ? and LoanType in('01','03') and Status = '0' ";
			
			String updateSqlReturn = " update GJJ_RETURN set Status = ? where InputDate = ? and LoanNo = ? ";
			String updateSqlUpdate = " update GJJ_UPDATE set Status = ? where InputDate = ? and LoanNo = ? ";
			
			PreparedStatement psSelectSqlReturn = null,psSelectSqlUpdate = null,psUpdateSqlReturn = null,psUpdateSqlUpdate = null;
			ResultSet rs = null;
			
			try
			{
				ESBTransaction esbTransaction = OCIConfig.getTransactionByCode("ASMAIN0200");
				esbTransaction.BIZ_SEQ_NO = "";
				psSelectSqlReturn = connection.prepareStatement(selectSqlReturn);
				psSelectSqlUpdate = connection.prepareStatement(selectSqlUpdate);
				psUpdateSqlReturn = connection.prepareStatement(updateSqlReturn); 
				psUpdateSqlUpdate = connection.prepareStatement(updateSqlUpdate); 
				
				psSelectSqlReturn.setString(1, this.deductDate);
				rs = psSelectSqlReturn.executeQuery();
				while(rs.next())
				{
					double corp = rs.getDouble("PAYCORPUS");
					double inte = rs.getDouble("PAYINTE");
					double fineInte = rs.getDouble("PAYFINEINTE");
					String orgID = rs.getString("ORGID");
					CompositeData compositeData = CHDCorp(esbTransaction,orgID,corp,inte,fineInte);
					String ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
					String ret_code = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_CODE"));
					String CONSUMER_SEQ_NO = DataConvert.toString((String) ESBInstance.getValue(compositeData, "CONSUMER_SEQ_NO"));// ǰ�û�������ˮ��
					//ESB���صĽ�����ˮ�ţ�����������������ڷ����ף���Ҫ�õ�
					try{
						// �������ΪS�������
						if("S".equals(ret_status) && !"".equals(CONSUMER_SEQ_NO) || ret_code.contains("80078")){
							psUpdateSqlReturn.setString(1, "1");
							psUpdateSqlReturn.setString(2, rs.getString("LoanNo"));
							psUpdateSqlReturn.execute();
						}
						connection.commit();
					}catch(Exception e){
						connection.rollback();
						e.printStackTrace();
						throw e;
					}
				}
				rs.close();
				
				psSelectSqlUpdate.setString(1, this.deductDate);
				rs = psSelectSqlUpdate.executeQuery();
				while(rs.next())
				{
					double corp = rs.getDouble("PAYCORPUS");
					double inte = rs.getDouble("PAYINTE");
					double fineInte = rs.getDouble("PAYFINEINTE");
					String orgID = rs.getString("ORGID");
					CompositeData compositeData = CHDCorpInte(esbTransaction,orgID,corp,inte,fineInte);
					String ret_status = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_STATUS"));
					String ret_code = DataConvert.toString((String) ESBInstance.getValue(compositeData, "RET_CODE"));
					String CONSUMER_SEQ_NO = DataConvert.toString((String) ESBInstance.getValue(compositeData, "CONSUMER_SEQ_NO"));// ǰ�û�������ˮ��
					//ESB���صĽ�����ˮ�ţ�����������������ڷ����ף���Ҫ�õ�
					try{
						// �������ΪS�������
						if("S".equals(ret_status) && !"".equals(CONSUMER_SEQ_NO) || ret_code.contains("80078")){
							psUpdateSqlReturn.setString(1, "1");
							psUpdateSqlReturn.setString(2, rs.getString("LoanNo"));
							psUpdateSqlReturn.execute();
						}
						connection.commit();
					}catch(Exception e){
						connection.rollback();
						e.printStackTrace();
						throw e;
					}
				}
				rs.close();
			}catch(Exception ex)
			{
				ex.printStackTrace();
				throw ex;
			}
			finally
			{
				if(psSelectSqlReturn!=null) psSelectSqlReturn.close();
				if(psSelectSqlUpdate!=null) psSelectSqlUpdate.close();
				if(psUpdateSqlReturn!=null) psUpdateSqlReturn.close();
				if(psUpdateSqlUpdate!=null) psUpdateSqlUpdate.close();
			}
		}
		
		
		public static CompositeData CHDCorp(ESBTransaction esbTransaction, String OrgID,double corp,double inte,double fineInte) throws Exception {
			CompositeData compositeData = null;
			// ��ȡ��������͹�Ա
			String BRANCH_ID = OrgInfoConfig.getMainFrameOrgId(OrgID);
			String USER_ID = TransAccountEntryArray.getBranUserID("UserID_SDB");
			String sRed_flag = "";// ���ױ�־
			String sCcy = "";// ����
			String sCard_or_Acct_No = "";// �ʺš�����
			HashMap<String, ArrayList<HashMap<String, Object>>> CoreDeal = new HashMap<String, ArrayList<HashMap<String, Object>>>();
			ArrayList<HashMap<String, Object>> CoreArray = new ArrayList<HashMap<String, Object>>();
			HashMap<String, Object> ParaHashMap = new HashMap<String, Object>();

				sRed_flag = "B";
			    sCcy =  "RMB";
			    HashMap<String, Object> paraHashMap = new HashMap<String, Object>();
			    paraHashMap.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap.put("CCY", sCcy);// ����
			    paraHashMap.put("TRAN_AMT", corp);// ���
			    paraHashMap.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_GJJ_Save);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
					paraHashMap.put("CARD_NO", sCard_or_Acct_No);// ����
					paraHashMap.put("ACCT_NO", "");// �ʺ�
			    } else {
					paraHashMap.put("CARD_NO", "");// ����
					paraHashMap.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap);
			    
			    HashMap<String, Object> paraHashMap1 = new HashMap<String, Object>();
			    paraHashMap1.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap1.put("CCY", sCcy);// ����
			    paraHashMap1.put("TRAN_AMT", corp);// ���
			    paraHashMap1.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_ICS);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap1.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap1.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap1.put("CARD_NO", "");// ����
			    	paraHashMap1.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap1);
			    CoreDeal.put("ASMAINBODY_0290_TRAN_LIST_ARRAY", CoreArray);

			ParaHashMap.put("BRANCH_ID", BRANCH_ID);// ��������
			if("B".equals(sRed_flag))sRed_flag="N";//ת�������������
			ParaHashMap.put("REVERSAL_FLAG", sRed_flag);// ���ױ�־��N��������R�����ʡ�
			ParaHashMap.put("CCY",sCcy);// ����
			ParaHashMap.put("CA_TT_FLAG", "C");// ��/���־
			ParaHashMap.put("REMARK", "");//  ժҪ
			ParaHashMap.put("USER_ID", USER_ID);
			compositeData = esbTransaction.transferTrade(CoreDeal, ParaHashMap);
			return compositeData;
	    }
		
		
		public static CompositeData CHDCorpInte(ESBTransaction esbTransaction, String OrgID,double corp,double inte,double fineInte) throws Exception {
			CompositeData compositeData = null;
			// ��ȡ��������͹�Ա
			String BRANCH_ID = OrgInfoConfig.getMainFrameOrgId(OrgID);
			String USER_ID = TransAccountEntryArray.getBranUserID("UserID_SDB");
			String sRed_flag = "";// ���ױ�־
			String sCcy = "";// ����
			String sCard_or_Acct_No = "";// �ʺš�����
			HashMap<String, ArrayList<HashMap<String, Object>>> CoreDeal = new HashMap<String, ArrayList<HashMap<String, Object>>>();
			ArrayList<HashMap<String, Object>> CoreArray = new ArrayList<HashMap<String, Object>>();
			HashMap<String, Object> ParaHashMap = new HashMap<String, Object>();

				sRed_flag = "B";
			    sCcy =  "RMB";
			    HashMap<String, Object> paraHashMap = new HashMap<String, Object>();
			    paraHashMap.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap.put("CCY", sCcy);// ����
			    paraHashMap.put("TRAN_AMT", corp);// ���
			    paraHashMap.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_GJJ_Save);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
					paraHashMap.put("CARD_NO", sCard_or_Acct_No);// ����
					paraHashMap.put("ACCT_NO", "");// �ʺ�
			    } else {
					paraHashMap.put("CARD_NO", "");// ����
					paraHashMap.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap);
			    
			    HashMap<String, Object> paraHashMap1 = new HashMap<String, Object>();
			    paraHashMap1.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap1.put("CCY", sCcy);// ����
			    paraHashMap1.put("TRAN_AMT", corp);// ���
			    paraHashMap1.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_SHGJJ_Corpus);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap1.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap1.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap1.put("CARD_NO", "");// ����
			    	paraHashMap1.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap1);
			    
			    HashMap<String, Object> paraHashMap2 = new HashMap<String, Object>();
			    paraHashMap2.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap2.put("CCY", sCcy);// ����
			    paraHashMap2.put("TRAN_AMT", inte);// ���
			    paraHashMap2.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_ICS);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap2.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap2.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap2.put("CARD_NO", "");// ����
			    	paraHashMap2.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap2);
			    
			    HashMap<String, Object> paraHashMap3 = new HashMap<String, Object>();
			    paraHashMap3.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap3.put("CCY", sCcy);// ����
			    paraHashMap3.put("TRAN_AMT", inte);// ���
			    paraHashMap3.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_GJJ_Inte);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap3.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap3.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap3.put("CARD_NO", "");// ����
			    	paraHashMap3.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap3);
			    
			    HashMap<String, Object> paraHashMap4 = new HashMap<String, Object>();
			    paraHashMap4.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap4.put("CCY", sCcy);// ����
			    paraHashMap4.put("TRAN_AMT", inte);// ���
			    paraHashMap4.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_ICS);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap4.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap4.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap4.put("CARD_NO", "");// ����
			    	paraHashMap4.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap4);
			    
			    HashMap<String, Object> paraHashMap5 = new HashMap<String, Object>();
			    paraHashMap5.put("SUB_BRANCH_ID", BRANCH_ID);// �ʺ�����
			    paraHashMap5.put("CCY", sCcy);// ����
			    paraHashMap5.put("TRAN_AMT", inte);// ���
			    paraHashMap5.put("CR_DR_FLAG", "D");// �����־
			    sCard_or_Acct_No = OrgInfoConfig.getGjjNo(OrgID,"",sCcy,AccountConstants.Org_Account_Type_SHGJJ_InteFine);
			    //�ҵ��������Ŀ����ת������ʺ�
			    if(sCard_or_Acct_No.length()==7)sCard_or_Acct_No="99"+sCard_or_Acct_No+"00010";
			    // ���ֿ��ź��ʺ�
			    if (sCard_or_Acct_No.length() == 16 || sCard_or_Acct_No.length() == 19) {
			    	paraHashMap5.put("CARD_NO", sCard_or_Acct_No);// ����
			    	paraHashMap5.put("ACCT_NO", "");// �ʺ�
			    } else {
			    	paraHashMap5.put("CARD_NO", "");// ����
			    	paraHashMap5.put("ACCT_NO", sCard_or_Acct_No);// �ʺ�
			    }
			    CoreArray.add(paraHashMap5);
			    
			    CoreDeal.put("ASMAINBODY_0290_TRAN_LIST_ARRAY", CoreArray);

			ParaHashMap.put("BRANCH_ID", BRANCH_ID);// ��������
			if("B".equals(sRed_flag))sRed_flag="N";//ת�������������
			ParaHashMap.put("REVERSAL_FLAG", sRed_flag);// ���ױ�־��N��������R�����ʡ�
			ParaHashMap.put("CCY",sCcy);// ����
			ParaHashMap.put("CA_TT_FLAG", "C");// ��/���־
			ParaHashMap.put("REMARK", "");//  ժҪ
			ParaHashMap.put("USER_ID", USER_ID);
			compositeData = esbTransaction.transferTrade(CoreDeal, ParaHashMap);
			return compositeData;
	    }
}
