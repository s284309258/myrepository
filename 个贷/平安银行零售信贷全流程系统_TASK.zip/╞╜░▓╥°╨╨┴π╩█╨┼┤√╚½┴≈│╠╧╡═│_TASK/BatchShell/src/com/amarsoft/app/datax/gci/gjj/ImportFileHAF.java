package com.amarsoft.app.datax.gci.gjj;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.DataSourceMetaData;
import com.amarsoft.are.metadata.MetaDataFactory;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.SWESBInstance;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

/**
 * ��Down�ļ����������
 * @author xiatian020
 * @since 2012-06-05
 * 
 */
public class ImportFileHAF extends CommonExecuteUnit {
	private String NASUrl;//NAS�ռ�·��
	private String fileName;//�ļ�����
	private String fileUrl;//�ļ�·��
	private int commitNum;//���ݿ�����ύ����
	private String sqlType;//SQL���� insert��update
	private String updateKeyColumns;//updateʱ����ֵ����WHERE���������ж�
	private String deleteClause;//insertʱ����ֵ����WHERE������������
	private String separator;//�ָ��ַ�
	private String tableName;//��������
	private String sourceName;//MetaData����
	private String sourceTable;//MetaData����
	private String ESBFlag;//�Ƿ���ESB��Ϣ
	private String updateField;//�Զ�������ֶ�
	private DataSourceMetaData sourceMetaData;

	public int execute() {
		try {
			String sInit = super.init();
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			}else {
				logger.info("ģ�������ʼ��.......");
				initPara();
				logger.info("ģ�������ʼ����ɣ�");
				prepareUpdate();//ǰ�洦��SQL
				logger.info("�����ļ���ʼ.......");
				dealExpFile();
				logger.info("�����ļ��ɹ�������");
				postUpdate();//��������SQL
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}


	/**
	 * ��ʼ������ģ�������õĲ���
	 */
	public void initPara() throws Exception {

		NASUrl = ARE.getProperty("NASUrl");
		String sDate = StringFunction.replace(deductDate,"/","");
		String sMonth = StringFunction.replace(currentMonth,"/","");
		String sLastDate = StringFunction.replace(lastDate,"/","");
		String sLastMonth = StringFunction.replace(lastMonth,"/","");
		
		fileName = this.getProperty("FileName");
		fileUrl = this.getProperty("FileUrl");
		commitNum = this.getProperty("CommitNum",1000);
		sqlType = this.getProperty("SqlType","insert");
		updateKeyColumns = getProperty("UpdateKeyColumns");
		updateField = getProperty("UpdateField");
		deleteClause = getProperty("DeleteClause");
		separator = getProperty("Separator");
		tableName = getProperty("TableName");
		sourceName = getProperty("SourceName");
		sourceTable = getProperty("SourceTable");
		ESBFlag = getProperty("ESBFlag","N");
		
		deleteClause=StringFunction.replace(deleteClause,"{$CurrentDate}",this.deductDate);
		deleteClause=StringFunction.replace(deleteClause,"{$CurrentMonth}",this.currentMonth);
		deleteClause=StringFunction.replace(deleteClause,"{$LastDate}",this.lastDate);
		deleteClause=StringFunction.replace(deleteClause,"{$LastMonth}",this.lastMonth);
		fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
		fileUrl=StringFunction.replace(fileUrl,"{$CurrentMonth}",sMonth);
		fileUrl=StringFunction.replace(fileUrl,"{$LastDate}",sLastDate);
		fileUrl=StringFunction.replace(fileUrl,"{$LastMonth}",sLastMonth);
		fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
		fileName=StringFunction.replace(fileName,"{$CurrentMonth}",sMonth);
		fileName=StringFunction.replace(fileName,"{$LastDate}",sLastDate);
		fileName=StringFunction.replace(fileName,"{$LastMonth}",sLastMonth);
		
		if(!"insert".equalsIgnoreCase(sqlType) && !"update".equalsIgnoreCase(sqlType)) throw new Exception("��֧�ָò������ͣ�");
	}
	

	/**
	 * �����ļ�
	 * 
	 * @throws Exception
	 */
	public void dealExpFile() throws Exception {
		String fileFullName = this.NASUrl + this.fileUrl + this.fileName;
		File inputFile = new File(fileFullName);
		if (!inputFile.exists()) {
			throw new Exception("�ļ������ڣ�");
		}
		
		String feilds = "";
		String values = "";
		//��ȡ�����ļ�
		sourceMetaData = MetaDataFactory.getFactory().getInstance(sourceName);
		TableMetaData tableMetaData = sourceMetaData.getTable(sourceTable);
		ColumnMetaData[] columnMetaData =  tableMetaData.getColumns();
		for(int i = 0; i < columnMetaData.length; i ++)
		{
			if("insert".equalsIgnoreCase(sqlType))
			{
				if(i+1 == columnMetaData.length) //���һ��
				{
					feilds += columnMetaData[i].getName();
					values +="?";
				}
				else
				{
					feilds += columnMetaData[i].getName()+" , ";
					values +="?,";
				}
			}
			else if("update".equalsIgnoreCase(sqlType))
			{
				if(i+1 == columnMetaData.length) //���һ��
				{
					feilds += columnMetaData[i].getName()+" = ? ";
				}
				else
				{
					feilds += columnMetaData[i].getName()+" = ?,";
				}
			}
		}
		
		PreparedStatement pstm = null;
		int lineCount = 0;//��¼��ǰ����
		int dealCount = 0;//ͳ��δ�ύ����
		try
		{
			//���붯��
			if("insert".equalsIgnoreCase(sqlType))
			{
				pstm = connection.prepareStatement("delete from "+tableName+" where "+deleteClause);
				pstm.execute();
				pstm.close();
				pstm = connection.prepareStatement("insert into "+tableName+"("+feilds+") values("+values+") ");
			}
			else if("update".equalsIgnoreCase(sqlType))//����
			{
				String whereClause = " ";
				for(String cl:updateKeyColumns.split(","))
				{
					whereClause += " and "+cl+" = ? ";
				}
				if(updateField != null && !"".equals(updateField))
				{
					logger.info("update "+tableName+" set "+updateField+" where "+deleteClause+whereClause);
					pstm = connection.prepareStatement("update "+tableName+" set "+updateField+" where "+deleteClause+whereClause);
				}
				else
					pstm = connection.prepareStatement("update "+tableName+" set "+feilds+" where "+deleteClause+whereClause);
			}
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile)));
			String sLine;
			while((sLine = reader.readLine())!= null)
			{
				lineCount++;
				dealCount++;
				String[] str = sLine.trim().split(separator);//����־�ָ�

				//�жϸü�¼�Ƿ����ݼ����¼
				if(str.length != columnMetaData.length+1)
				{
					throw new Exception("�ļ���"+lineCount+"�в����ж�����ļ���ʽ����ʵ���ļ���ʽ����ͬ��");
				}else
				{
					
					for(int i = 0; i < columnMetaData.length ; i ++)
					{
						if(updateField == null || "".equals(updateField))
						{
							if(columnMetaData[i].getTypeName().equals("DOUBLE"))//DOUBLE
							{
								pstm.setDouble(i+1, DataConvert.toDouble(str[i+1])/columnMetaData[i].getPrecision());
							}
							else if(columnMetaData[i].getTypeName().equals("INT"))//INT
							{
								pstm.setDouble(i+1, DataConvert.toInt(str[i+1]));
							}
							else if(columnMetaData[i].getTypeName().equals("DATE")) //DATE
							{
								SimpleDateFormat sdf=new SimpleDateFormat(columnMetaData[i].getFormat());
								Date now = sdf.parse(DataConvert.toString(str[i+1]).trim());
								SimpleDateFormat sdf1=new SimpleDateFormat("yyyy/MM/dd");
								pstm.setString(i+1, sdf1.format(now));
							}
							else
							{
								pstm.setString(i+1, DataConvert.toString(str[i+1]).trim());
							}
						}
						
						if("update".equalsIgnoreCase(sqlType))
						{
							String updateClauses[] = updateKeyColumns.split(",");
							for(int j = 0; j < updateClauses.length; j ++)
							{
								int length = 0;
								if(updateField == null || "".equals(updateField))
								{
									length = columnMetaData.length;
								}
								else
								{
									length = 0;
								}
								if(updateClauses[j].equalsIgnoreCase(columnMetaData[i].getName()))
								{
									if(columnMetaData[i].getTypeName().equals("DOUBLE"))//DOUBLE
									{
										pstm.setDouble(length+j+1, DataConvert.toDouble(str[i+1])/columnMetaData[i].getPrecision());
									}
									else if(columnMetaData[i].getTypeName().equals("INT"))//INT
									{
										pstm.setDouble(length+j+1, DataConvert.toInt(str[i+1]));
									}
									else if(columnMetaData[i].getTypeName().equals("DATE")) //DATE
									{
										SimpleDateFormat sdf=new SimpleDateFormat(columnMetaData[i].getFormat());
										Date now = sdf.parse(DataConvert.toString(str[i+1]).trim());
										SimpleDateFormat sdf1=new SimpleDateFormat("yyyy/MM/dd");
										pstm.setString(length+j+1, sdf1.format(now));
									}
									else
									{
										pstm.setString(length+j+1, DataConvert.toString(str[i+1]).trim());
									}
								}
							}
						}
					}
				}
				pstm.addBatch();
				
				if(dealCount >= commitNum)
				{
					pstm.executeBatch();
					dealCount=0;
					logger.info("�Ѿ�����"+lineCount+"�����ݣ�");
				}
			}
			pstm.executeBatch();
			reader.close();
			logger.info("�ܹ�����"+lineCount+"�����ݣ�");
		}catch(Exception ex)
		{
			ex.printStackTrace();
			logger.info("��"+lineCount+"�е��������"+ex.getMessage());
			throw ex;
		}
		finally
		{
			if(pstm != null) pstm.close();
		}
		
		
		//����ESB��Ϣ
		if("Y".equals(ESBFlag))
		{
			SWESBInstance swei = new SWESBInstance();
			CompositeData compositeData = swei.FileTransferNotice("","",fileName,"000000","���ܲ������ɹ���");
			String ret_status = (String) ESBInstance.getValue(compositeData, "RET_STATUS");// ����״̬,�ɹ�ΪS,ʧ��ΪF
			if(!ret_status.startsWith("S")) throw new Exception("�ļ��������״̬֪ͨʧ�ܣ�"); 
		}
	}
	
	//ǰ��ִ�е�SQL
	protected void prepareUpdate() throws Exception{
		Statement stmt = connection.createStatement();
		for (int i = 1;!(getProperty("prepareUpdate" + i) == null || 
				getProperty("prepareUpdate" + i).trim().equals("")); i++) {
			String sqlPrepareUpdate = getProperty("prepareUpdate" + i);
			sqlPrepareUpdate=StringFunction.replace(sqlPrepareUpdate,"{$LastDate}", lastDate);
			sqlPrepareUpdate=StringFunction.replace(sqlPrepareUpdate,"{$CurrentMonth}", currentMonth);
			sqlPrepareUpdate=StringFunction.replace(sqlPrepareUpdate,"{$LastMonth}", lastMonth);
			sqlPrepareUpdate=StringFunction.replace(sqlPrepareUpdate,"{$NextMonth}", nextMonth);
			sqlPrepareUpdate=StringFunction.replace(sqlPrepareUpdate,"{$CurrentDate}", deductDate);
			logger.info(sqlPrepareUpdate);
			stmt.execute(sqlPrepareUpdate);
			connection.commit();
		}
		stmt.close();
	}
	
	//����ִ�е�SQL�������ж��̴߳���
	protected void postUpdate() throws Exception {

		Statement stmt = connection.createStatement();
		for (int i = 1; !(getProperty("postUpdate" + i) == null || getProperty("postUpdate" + i).trim().equals("")); i++) {
			String sqlpostUpdate = getProperty("postUpdate" + i);
			sqlpostUpdate=StringFunction.replace(sqlpostUpdate,"{$LastDate}", lastDate);
			sqlpostUpdate=StringFunction.replace(sqlpostUpdate,"{$CurrentMonth}", currentMonth);
			sqlpostUpdate=StringFunction.replace(sqlpostUpdate,"{$LastMonth}", lastMonth);
			sqlpostUpdate=StringFunction.replace(sqlpostUpdate,"{$NextMonth}", nextMonth);
			sqlpostUpdate=StringFunction.replace(sqlpostUpdate,"{$CurrentDate}", deductDate);
			logger.info(sqlpostUpdate);
			stmt.execute(sqlpostUpdate);
			connection.commit();
		}
		stmt.close();
	}
}
