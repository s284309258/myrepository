package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateDCFlag extends CommonExecuteUnit{

	private int icount = 0;
	
	@Override
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ���½᰸��־......");
				insertData();
				logger.info("�����±�"+icount+"����");
				logger.info("���±���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void insertData() throws SQLException 
	{
		try
		{
			connection.setAutoCommit(false);
			
			String updateSql = " update business_contract set DCFLAG = '1' where  SERIALNO = (select CONTRACTSERIALNO from business_putout where SERIALNO = ?) ";
			PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
			
			String selectSql = "select LOANSEQ from RECKONING_DC";
			PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
			ResultSet rs = psSelectSql.executeQuery();
			while(rs.next())
			{
				String LoanSEQ = rs.getString("LOANSEQ");	//������ˮ��
				
				psUpdateSql.setString(1, LoanSEQ);
				psUpdateSql.addBatch();
				icount++;
				
			}
			psUpdateSql.executeBatch();
			rs.close();
			psUpdateSql.close();
			psSelectSql.close();
			connection.commit();
		}catch(Exception e)
		{
			connection.rollback();
			e.printStackTrace();
			throw new SQLException("���½᰸��־ʧ��");
		}
	}

}
