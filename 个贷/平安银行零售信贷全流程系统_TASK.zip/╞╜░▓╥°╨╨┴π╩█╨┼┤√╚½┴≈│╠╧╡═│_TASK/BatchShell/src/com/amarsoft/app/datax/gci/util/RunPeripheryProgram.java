/**
 * 
 */
package com.amarsoft.app.datax.gci.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

/**
 * @author Administrator
 *
 */
public class RunPeripheryProgram  extends CommonExecuteUnit {
	private String	fileName;
	protected String loadStream(InputStream inputstream) throws IOException {
		int i = 0;
		inputstream = new BufferedInputStream(inputstream);
		StringBuffer stringbuffer = new StringBuffer();
		while ((i = inputstream.read()) != -1)
			stringbuffer.append((char) i);
		return stringbuffer.toString();
	}
	
	
	@SuppressWarnings("finally")
	public int execute() {
		try{
			String initStatus=init();
			if(initStatus.equals("skip")){
				return unitStatus;
			}
			fileName = getProperty("File_Name");
			logger.info("����ϵͳ����......");
			Process process = Runtime.getRuntime().exec(fileName);
			logger.info(loadStream(process.getInputStream()));
			logger.error(loadStream(process.getErrorStream()));
			
			unitStatus= TaskConstants.ES_SUCCESSFUL;
		}
		catch(Exception e){
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
		}
		finally{
			this.clearResource();
			return unitStatus;
		}
	}
}
