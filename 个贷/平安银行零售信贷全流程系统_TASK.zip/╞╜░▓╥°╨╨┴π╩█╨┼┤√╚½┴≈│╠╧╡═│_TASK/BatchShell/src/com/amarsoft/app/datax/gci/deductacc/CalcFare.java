package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.deductdata.BatchInsertAheadFare;
import com.amarsoft.task.TaskConstants;


public class CalcFare extends CommonExecuteUnit{
	
	
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0 ;	

	public int execute() {
	
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String sDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
				String delSql1=" delete from Fare_Detail where PayDate = '"+sDate+"' and OffFlag = '0' ";
				logger.info("��� Fare_Detail�����յ�����:sql="+delSql1);
				PreparedStatement psDelSql1 = connection.prepareStatement(delSql1);
				psDelSql1.execute();
				logger.info("���Fare_Detail�����յ�������� ");
				psDelSql1.close();
				
				logger.info("���������˻�������......");
				batchCalcFare();
				logger.info("�������˻�������"+icount+"����");
				logger.info("�˻������Ѽ������!");
				
				logger.info("����������ڴ�����������......");
				batchBNCalcFee();
				logger.info("���ڴ����������ü������!");
				
				logger.info("����������������������......");
				batchBWCalcFee();
				logger.info("��������������ü������!");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}

	public void batchCalcFare() throws Exception
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		String insertSql = " INSERT INTO Fare_Detail(PutOutNo,PayDate,PayMoney,OffFlag,Currency) "
			  + " VALUES(?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String select1 = "  select round(Nvl(businessSum*POUNDAGERATE/100,0),2) as fareSum from business_contract where serialno = ? ";
		PreparedStatement pstmp1= connection.prepareStatement(select1);
		
		
		String select2 = " select sum(fd.paymoney) as ofare from loan_balance lb,fare_detail fd " +
				"where lb.putoutno = fd.putoutno and lb.contractserialno = ? ";
		PreparedStatement pstmp2= connection.prepareStatement(select2);
		
		
		String UpdateSql = "update Fare_detail set PayMoney = ?,OffFlag = ?,Currency =? where PutOutNo = ? and PayDate = ?";
		PreparedStatement psUpdateSql= connection.prepareStatement(UpdateSql);
		

		
		String selectSql = " select lb.Putoutno,lb.contractSerialNo,lr.FareMoneyType,lr.Amount,lr.MoneyProportion,lb.BusinessSum,(lb.NormalBalance+lb.DefaultBalance+lb.OverdueBalance+lb.CurrentBalance) as CorpBalance,lb.Currency,lr.FeeMethod,lb.Sterm,lb.businessType,lb.MaturityDate "
			  			 + " from loanbalance_relative lr,loan_balance lb "
			  			 + " where lb.PutOutNo = lr.PutOutNo " +
			  			 "  and (lr.FeeType = '02' or lr.FeeType = '03' or lr.FeeType = '04' or lr.FeeType = '210' or lr.FeeType = '220') and (lr.FeeMethod = '03' or lr.FeeMethod = '02') and lb.lastintedate = '"+this.nextDate+"' and lb.lastintedate <> lb.putoutdate and lb.maturitydate>='"+deductDate+"'" ;
		PreparedStatement psSelectSql= connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double FareAmount = 0;
			
			if(rs.getString("BusinessType").equalsIgnoreCase("1120030")&& nextDate.compareTo(rs.getString("MaturityDate"))>=0&&"03".equals(rs.getString("FeeMethod")))
			{
				double fareSum = 0,ofare=0;
				pstmp1.setString(1,rs.getString("contractSerialNo"));
				ResultSet rsTmp1 = pstmp1.executeQuery();
				if(rsTmp1.next())
				{
					fareSum = rsTmp1.getDouble("fareSum");
				}
				rsTmp1.close();
				
				pstmp2.setString(1,rs.getString("contractSerialNo"));
				ResultSet rsTmp2 = pstmp2.executeQuery();
				if(rsTmp2.next())
				{
					ofare = rsTmp2.getDouble("ofare");
				}
				rsTmp2.close();
				
				double fare = fareSum-ofare;
				if(fare>0)
					FareAmount = fare;
			}
			else	
				FareAmount = this.calcFareAmount(rs.getString("FeeMethod"),rs.getInt("Sterm"),rs.getString("FareMoneyType"),rs.getDouble("MoneyProportion"),rs.getDouble("Amount"),rs.getDouble("CorpBalance"),rs.getDouble("BusinessSum"));
			
			if(FareAmount==0)
			{
				continue;
			}
			
			String sPutOutNo = rs.getString("Putoutno");
			
			if(!checkData(sPutOutNo,this.nextDate)){
				
				psUpdateSql.setDouble(1, FareAmount);
				psUpdateSql.setString(2, "0");
				psUpdateSql.setString(3, rs.getString("Currency"));
				psUpdateSql.setString(4, sPutOutNo);
				psUpdateSql.setString(5, this.nextDate);
				psUpdateSql.addBatch();
				continue;
			}
				
			psInsertSql.setString(1,rs.getString("Putoutno"));
			psInsertSql.setString(2,this.nextDate);
			psInsertSql.setDouble(3,FareAmount);
			psInsertSql.setString(4,"0");
			psInsertSql.setString(5,rs.getString("Currency"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ������˻�����"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		//psSelectSql.close();
		psUpdateSql.close();
		pstmp1.close();
		pstmp2.close();
		
	}
	//����
	public void batchBNCalcFee() throws Exception {
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		icount = 0;
		String insertSql = " INSERT INTO Fare_Detail(PutOutNo,PayDate,PayMoney,OffFlag,Currency) "
			  + " VALUES(?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);	
		
		String UpdateSql = "update Fare_detail set PayMoney = ?,OffFlag = ?,Currency =? where PutOutNo = ? and PayDate = ?";
		PreparedStatement psUpdateSql= connection.prepareStatement(UpdateSql);
		//ֻ��SWPutOutApply���Ͳ������Ϣ����ȡ������һ�λ�����ȡ
		String selectSql = "select afi.SerialNo,lb.contractSerialNo,afi.FeePaymentType,afi.FeeBalance,afi.FeeCalType,lb.BusinessSum,lb.DeductAccNo,afi.FeeAccountNo," +
				"(lb.NormalBalance+lb.DefaultBalance+lb.OverdueBalance+lb.CurrentBalance) as CorpBalance,lb.Currency,afi.FeeProportior,lb.Sterm," +
				"lb.businessType,lb.MaturityDate from Acct_Fee_Info afi,Loan_Balance lb where lb.PutOutNo=afi.ObjectNo and " +
				"afi.ObjectType = 'SWPutOutApply'  and lb.lastintedate = '"+this.nextDate+"' and (afi.FeePaymentType = '02' or afi.FeePaymentType = '03') " +
				" and afi.Status = '0' and lb.lastintedate <> lb.putoutdate and lb.maturityDate >='"+deductDate+"' " ;
		PreparedStatement psSelectSql= connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double FareAmount = 0;
			//���´�����㻧����û����һ���ԣ����ں�������
			updateAccountFlag(rs.getString("DeductAccNo"),rs.getString("FeeAccountNo"),rs.getString("SerialNo"));
			//����ÿ�ڻ���Ľ��	
			FareAmount = this.calcFareAmount(rs.getString("FeePaymentType"),rs.getInt("Sterm"),rs.getString("FeeCalType"),rs.getDouble("FeeProportior"),rs.getDouble("FeeBalance"),rs.getDouble("CorpBalance"),rs.getDouble("BusinessSum"));

			if(FareAmount==0)
			{
				continue;
			}
			
			String sSerialNo = rs.getString("SerialNo");
			//�˴��������������ķ��ú�
			if(!checkData(sSerialNo,this.nextDate)){
				
				psUpdateSql.setDouble(1, FareAmount);
				psUpdateSql.setString(2, "0");
				psUpdateSql.setString(3, rs.getString("Currency"));
				psUpdateSql.setString(4, sSerialNo);
				psUpdateSql.setString(5, this.nextDate);
				psUpdateSql.addBatch();
				continue;
			}
				
			psInsertSql.setString(1,rs.getString("SerialNo"));
			psInsertSql.setString(2,this.nextDate);
			psInsertSql.setDouble(3,FareAmount);
			psInsertSql.setString(4,"0");
			psInsertSql.setString(5,rs.getString("Currency"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����С΢����"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		//psSelectSql.close();
		psUpdateSql.close();
		
	}
	//����
	public void batchBWCalcFee() throws Exception {
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		icount = 0;
		String insertSql = " INSERT INTO Fare_Detail(PutOutNo,PayDate,PayMoney,OffFlag,Currency) "
			  + " VALUES(?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);	
		
		String UpdateSql = "update Fare_detail set PayMoney = ?,OffFlag = ?,Currency =? where PutOutNo = ? and PayDate = ?";
		PreparedStatement psUpdateSql= connection.prepareStatement(UpdateSql);
		//ֻ��SWPutOutApply���Ͳ������Ϣ����ȡ������һ�λ�����ȡ
		String selectSql = "select afi.SerialNo,lb.contractSerialNo,afi.FeePaymentType,afi.FeeBalance,afi.FeeCalType,lb.BusinessSum,afi.FeeAccountNo," +
				"lb.NormalBalance as CorpBalance,lb.Currency,afi.FeeProportior,lb.PutOutDate," +
				"lb.businessType,lb.MaturityDate from Acct_Fee_Info afi,Loan_Balance_Off lb where lb.PutOutNo=afi.ObjectNo and " +
				"afi.ObjectType = 'SWPutOutApply'  and (afi.FeePaymentType = '02' or afi.FeePaymentType = '03') " +
				" and afi.Status = '0' and lb.putoutdate<>'"+deductDate+"' and lb.maturityDate >='"+deductDate+"' " ;
		PreparedStatement psSelectSql= connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String putoutDate = rs.getString("PutOutDate");
			
			double FareAmount = 0;
			//������㻧����û���Ĳ�һ�£����ں�������
			updateAccountFlag("",rs.getString("FeeAccountNo"),rs.getString("SerialNo"));
			//��ȡ�ſ���ɺ��һ�ε����ڣ���ȡ�¸��»���ĵ���
			String sDate = DateTools.getRelativeDate(putoutDate,AccountConstants.TERM_UNIT_MONTH,1).substring(0,8)+putoutDate.substring(8,10);
			//��ȡÿ���´����յ�����
			String sDeductDate = deductDate.substring(0,8)+putoutDate.substring(8,10);
			if(deductDate.equals(sDate)){
				//�����һ�λ�����嵱�ʷ��õĽ��	
				FareAmount = this.calcFareAmount(rs.getString("FeePaymentType"),2,rs.getString("FeeCalType"),rs.getDouble("FeeProportior"),rs.getDouble("FeeBalance"),rs.getDouble("CorpBalance"),rs.getDouble("BusinessSum"));
			}else if(DateTools.getDays(deductDate, sDate)>0&&deductDate.equals(sDeductDate)){//�����ǰ���ڵ���ÿ�´����յ����ڣ���������
				FareAmount = this.calcFareAmount(rs.getString("FeePaymentType"),0,rs.getString("FeeCalType"),rs.getDouble("FeeProportior"),rs.getDouble("FeeBalance"),rs.getDouble("CorpBalance"),rs.getDouble("BusinessSum"));
			}
			if(FareAmount==0)
			{
				continue;
			}
			
			String sSerialNo = rs.getString("SerialNo");
			//�˴��������������ķ��ú�
			if(!checkData(sSerialNo,this.nextDate)){
				
				psUpdateSql.setDouble(1, FareAmount);
				psUpdateSql.setString(2, "0");
				psUpdateSql.setString(3, rs.getString("Currency"));
				psUpdateSql.setString(4, sSerialNo);
				psUpdateSql.setString(5, this.nextDate);
				psUpdateSql.addBatch();
				continue;
			}
				
			psInsertSql.setString(1,rs.getString("SerialNo"));
			psInsertSql.setString(2,this.nextDate);
			psInsertSql.setDouble(3,FareAmount);
			psInsertSql.setString(4,"0");
			psInsertSql.setString(5,rs.getString("Currency"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����С΢����"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		//psSelectSql.close();
		psUpdateSql.close();
		
	}
	
	public double calcFareAmount(String FeeMethod,int Sterm,String sFareAmounttype,double dFareAmountProportion,double dAmount,double dNormalBalance,double dBusinessSum)
	{
		double dFareAmount=0;
		
		if(FeeMethod.equals("03"))
		{
			
			// faremoneyttype=01Ϊ�̶���
			if(sFareAmounttype.equals("01"))
			{
				dFareAmount = NumberTools.round(dAmount,2);
			}
			// faremoneyttype=02����������
			else if(sFareAmounttype.equals("02"))
			{
				dFareAmount = NumberTools.round(dFareAmountProportion*dNormalBalance/100,2);
			}
			// faremoneyttype=03Ϊ�����������
			else
			{
				dFareAmount = NumberTools.round(dFareAmountProportion*dBusinessSum/100,2);
			}
			
		}
		if(FeeMethod.equals("02")&& Sterm==2)
		{
			// faremoneyttype=01Ϊ�̶���
			if(sFareAmounttype.equals("01"))
			{
				dFareAmount = NumberTools.round(dAmount,2);
			}
			// faremoneyttype=02Ϊ����������
			else if(sFareAmounttype.equals("02"))
			{
				dFareAmount = NumberTools.round(dFareAmountProportion*dNormalBalance/100,2);
			}
			// faremoneyttype=03Ϊ�����������
			else
			{
				dFareAmount = NumberTools.round(dFareAmountProportion*dBusinessSum/100,2);
			}
		}
		
		return dFareAmount;
	}
	
	public void updateAccountFlag(String deductAccNo,String feeAccountNo,String serialNo) throws Exception{
		String sql = "update Acct_Fee_Info set AccountFlag = '1' where serialNo = '"+serialNo+"'";//��ͬ����Ϊ1
		PreparedStatement psSql = connection.prepareStatement(sql);
		String sql1 = "update Acct_Fee_Info set AccountFlag = '0' where serialNo = '"+serialNo+"'";//��ͬ����Ϊ0
		PreparedStatement psSql1 = connection.prepareStatement(sql1);
		if(deductAccNo.equals(feeAccountNo)){
			psSql.addBatch();
		}else{
			psSql1.addBatch();
		}	
		psSql.executeBatch();
		psSql1.executeBatch();
		psSql.close();
		psSql1.close();
	}
	
	//��������Ѿ������ݣ��򷵻�false��������
	private boolean checkData(String putoutno,String nextPayDate) throws SQLException {
		boolean result = true;
		String querySql = " SELECT COUNT(1) as cnt FROM fare_detail WHERE putoutno = ? AND paydate = ?";
		PreparedStatement psQuerySql = connection.prepareStatement(querySql);
		psQuerySql.setString(1, putoutno);
		psQuerySql.setString(2, nextPayDate);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			int cnt = rs.getInt("cnt");
			if(cnt >0){
				result = false;
			}
		}
		psQuerySql.close();
		rs.close();
		return result;
	}
}
