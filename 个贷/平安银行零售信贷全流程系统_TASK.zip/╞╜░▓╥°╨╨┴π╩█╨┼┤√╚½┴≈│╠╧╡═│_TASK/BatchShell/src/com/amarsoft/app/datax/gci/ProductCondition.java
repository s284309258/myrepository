package com.amarsoft.app.datax.gci;

public class ProductCondition {

	private String TypeNo;
	private String OrgID;
	private String LoanStatus;
	private String PaySeq;
	private String PaySubjectSeq;
	public String getTypeNo() {
		return TypeNo;
	}
	public void setTypeNo(String typeNo) {
		TypeNo = typeNo;
	}
	public String getOrgID() {
		return OrgID;
	}
	public void setOrgID(String orgID) {
		OrgID = orgID;
	}
	public String getLoanStatus() {
		return LoanStatus;
	}
	public void setLoanStatus(String loanStatus) {
		LoanStatus = loanStatus;
	}
	public String getPaySeq() {
		return PaySeq;
	}
	public void setPaySeq(String paySeq) {
		PaySeq = paySeq;
	}
	public String getPaySubjectSeq() {
		return PaySubjectSeq;
	}
	public void setPaySubjectSeq(String paySubjectSeq) {
		PaySubjectSeq = paySubjectSeq;
	}

}
