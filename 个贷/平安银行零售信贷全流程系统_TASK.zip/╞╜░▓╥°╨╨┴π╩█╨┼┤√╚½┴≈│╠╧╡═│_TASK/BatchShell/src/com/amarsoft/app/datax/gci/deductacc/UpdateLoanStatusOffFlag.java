package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.task.TaskConstants;

public class UpdateLoanStatusOffFlag extends CommonExecuteUnit{

	private int icount = 0;
	private int commitNum ;
	private int dealNum = 0;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				logger.info("��ʼ�������´���ƻ�����״̬...");
				updatePayOffFalg();
				logger.info("�������´���ƻ�����״̬���");
				logger.info("��ʼ�������´���״̬...");
				updateLoanStatus();
				logger.info("�������´���״̬���");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void updatePayOffFalg() throws SQLException
	{
		String updateSql = " update Loanback_Status set PayOffFlag = ? where PutOutNo = ? and Sterm = ? and AheadNum = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select PutOutNo,Sterm,AheadNum from Loanback_Status  "
						 + " where  PayOffFlag = '"+BatchConstant.PAYOFFFLAG_FALSE+"' and AccDate in('"+this.deductDate+"','"+this.lastDate+"') "
						 + " and (PayCurrentCorp+PayDefaultCorp+PayOverDueCorp+PayInte+PayInnerInte+PayOutInte+PayInnerInteFine+PayOutInteFine)<= "
						 + " (ActualCurrentCorp+ActualDefaultCorp+ActualOverDueCorp+ActualInte+ActualInnerInte+ActualOutInte+ActualInnerInteFine+ActualOutInteFine) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,BatchConstant.PAYOFFFLAG_TRUE);
			psUpdateSql.setString(2,rs.getString("PutOutNo"));
			psUpdateSql.setString(3,rs.getString("Sterm"));
			psUpdateSql.setString(4,rs.getString("AheadNum"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"�����ݣ�");
			}
		}
		psUpdateSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psUpdateSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
	//�˴�ֻ��Ժ������������⴦��
	public void updateLoanStatus() throws SQLException
	{
		String updateSql = " update loan_balance set loanstatus = '60',finishdate = '"+deductDate+"' where PutOutNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String sql = "select  sum(ls.payoverduecorp+ls.payinte+ls.payinnerinte+ls.payoutinte+ls.payinnerintefine+ls.payoutintefine) as amount "+
				     " from LOANBACK_STATUS ls where ls.PutOutNo = ? and ls.payoffflag='0'";
		PreparedStatement psSql = connection.prepareStatement(sql);
		
		String selectSql = "select lb.putoutno from loan_balance lb "+
					" where lb.loanstatus in ('4','5') "+
					" and lb.normalbalance+lb.overduebalance+lb.payinte+lb.payinnerinte+lb.payoutinte "+
					" +lb.payinnerintefine+lb.payoutintefine<=0 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rsSelect = psSelectSql.executeQuery();
		while(rsSelect.next())
		{
			psSql.setString(1, rsSelect.getString("putoutno"));
			ResultSet rs = psSql.executeQuery();
			double sReturn = 0.0d;
			if(rs.next()){
				sReturn = rs.getDouble("amount");
			}
			rs.close();
			//�����Ӧ����Ӧ�ý���
			if(sReturn>0) continue;
			psUpdateSql.setString(1, rsSelect.getString("putoutno"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"�����ݣ�");
			}
		}
		psUpdateSql.executeBatch();
		rsSelect.close();
		psSelectSql.close();
		psSql.close();
		psUpdateSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
	
}
