package com.amarsoft.app.datax.gci;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.DateTools;

public class ExpFundFile extends CommonExecuteUnit{
	
	private String sql;
	private String fileName;
	private PrintWriter outputstreamwriter;
	private String separator;
	private String NASUrl;
	private String fileUrl;
	
	//����ȡ�����ݽ��а���metedata.xml�ж�����и�ʽ��
	public String getFieldValue(ColumnMetaData columnMetaData,String s){
		String sType = columnMetaData.getTypeName();
		int iLength=s.getBytes().length;
		int iDisplaySize = columnMetaData.getDisplaySize();
		//int iPrecision = columnMetaData.getPrecision();
		int iScale = columnMetaData.getScale();
		if(sType.equals("CHAR")){
			
		if(iLength > iDisplaySize){
	        try{
	        	//�������ݳ�����ȡ����ֹ���ְ���ַ�
	           s = subCHN(s,0,iDisplaySize);
	           }catch(Exception e){
	            	e.printStackTrace();	
	        }
		}
		iLength = s.getBytes().length;
		//��䣬�Է��ϲ��㳤�ȵ��������Ҷ���
	    for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=s + " ";
	    	}
          
		}
		if(sType.equals("INT")){
			
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			if(iLength > iDisplaySize){
			s = s.substring(0,iDisplaySize);
			}
			iLength = s.getBytes().length;
			 for(int i=0;i<iDisplaySize-iLength;i++){
		    		s=" "+s;
		    }
			 
			 
		}
		if(sType.equals("DATE")){
			s = StringFunction.replace(s,"/","");
			iLength=s.getBytes().length;
			if(iLength > iDisplaySize){
			s = s.substring(0,iDisplaySize);
			}
			iLength = s.getBytes().length;
	        for(int i=0;i<iDisplaySize-iLength;i++){
	        	s=s + " ";
	    	}
	        
         
		}
		
		if(sType.equals("TIME")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
			if(iLength > iDisplaySize){
			s = s.substring(0,iDisplaySize);
			}
			iLength = s.getBytes().length;
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=s+" ";
	    	}
          
		}
		if(sType.equals("DOUBLE")){
			if(s.equals("")){
				s="0.00";
				iLength=3;
			}
			
			String temp=s;
			if(s.indexOf(".")>0) temp=s.substring(0,s.indexOf("."));
			s=NumberTools.numberFormat(Double.parseDouble(s),temp.length(), iScale);
			iLength=s.length();
			if(iLength > iDisplaySize){
					s = s.substring(0,iDisplaySize);
			}
			iLength = s.getBytes().length;
			for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=" "+s;
	    	}
			
		}
		return s;
	}
	
	//�����ݿ��ж�ȡ���ݲ�д���ļ�
	public void exportResultSet(String sql,TableMetaData tableMetaData,PrintWriter outputstreamwriter) throws SQLException, IOException{
		separator = this.getProperty("separator");
		System.out.println("*********************");
		Statement stm = connection.createStatement();
		
		ResultSet rs=stm.executeQuery(sql);
		int rowNum=0;
		//�����ļ�������
		while(rs.next()){
			String s="";
			rowNum++;
			//һ�����ݵĴ���
			for(int i=1;i<=tableMetaData.getColumnCount();i++){
				
				//����ĳһ�ֶεĴ���
				ColumnMetaData columnMetaData= tableMetaData.getColumn(i);
				logger.info(columnMetaData.getName());
				//�����ݿ��ȡ����
				String rsString=rs.getString(columnMetaData.getName());
				if(rsString==null)rsString="";
				if(rsString.equals("{$RowNum}")) rsString=String.valueOf(rowNum);
				if(rsString.equals("AMTX_H_FILE_SEQ")) rsString=String.valueOf(1);
				s+=getFieldValue(columnMetaData,rsString)+separator;
			}
			s+="\r\n";
			outputstreamwriter.write(s);
		}
		rs.close();
		stm.close();
	}
	@SuppressWarnings("finally")
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				unitStatus= TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				fileName =  this.getProperty("unit.fileName");
				
				//�жϵ����Ƿ������ļ�
				if(!isTodayEx(fileName))
				{
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					NASUrl = ARE.getProperty("NASUrl");//��ȡNAS�ռ䣬������ARE.XML�У���Ϊ�ļ�·����һ����
					fileUrl= this.getProperty("unit.fileUrl"); 
					
					String sDate = StringFunction.replace(deductDate,"/","");
					String sMonth = StringFunction.replace(currentMonth,"/","");
					fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
					fileName=StringFunction.replace(fileName,"{$CurrentMonth}",sMonth);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentMonth}",sMonth);
					
					fileUrl = NASUrl+fileUrl;
					File file = new File(fileUrl);
					if(!file.exists())
					{
						file.mkdirs();
					}
					
					fileName = fileUrl+fileName;
					outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName))),true);
					//outputstreamwriter = new OutputStreamWriter(new FileOutputStream(new File(fileName)), "GBK");
					for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty(
							"unit.recordSet" + i).trim().equals("")); i++) {
						
						//��ȡSQL���
						sql=this.getProperty("unit.recordSet"+i);
						
						//�滻����
						sql=StringFunction.replace(sql,"{$CurrentDate}", deductDate);
						sql=StringFunction.replace(sql,"{$CurrentMonth}", currentMonth);
						
						sql=StringFunction.replace(sql,"{$CurrentDateNoSplit}", StringFunction.replace(deductDate, "/",""));
						sql=StringFunction.replace(sql,"{$CurrentMonthNoSplit}", StringFunction.replace(currentMonth, "/",""));
						
						
						String[] s=sql.split(":");
						//��װSQL
						sql=sql.substring(sql.indexOf(s[1])+s[1].length()+1);
						logger.info("��ǰ������sql="+sql);
						logger.info("s[1]:"+s[1]);
						logger.info("TableName:"+ARE.getMetaData(s[0]).getTable(s[1]).getName());
						exportResultSet(sql,ARE.getMetaData(s[0]).getTable(s[1]),outputstreamwriter);
					}
				
					outputstreamwriter.close();
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}
			}
		}
		catch(Exception e){
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
		}
		finally{
			clearResource();
			return unitStatus;
		}
	}
	
	private boolean isTodayEx(String sFileName) throws ParseException
	{
		if(this.getProperty("EndMonthFlag").equals("1")&&!DateTools.monthEnd(deductDate))
			return false;
		else
			return true;
	}
	
	
	
	//���ĳ����涨�ַ���ȡ
	public String subCHN(String str,int index,int length) throws Exception{    
		        try{    
		               String returnStr=null;    
		                String tmpStr;    
		                StringBuffer tmpBfStr=new StringBuffer();    
		                int j=0,i=0;    
	               while(j<length){  
	                     char mychar = str.charAt(i);  
		                 tmpStr=String.valueOf(mychar);    
	                    if(tmpStr.getBytes().length%2==0){    
	                       j+=2;    
		                    if(j>length){    
	                           break;    
	                        }    
		                    }else{    
	                         j++;    
		                   }    
		                    tmpBfStr.append(tmpStr); 
		                    i++;
		                }    
		                returnStr=tmpBfStr.toString();    
			            return returnStr;    
		        } catch(Exception e){    
			            e.printStackTrace();    
			            e.getMessage();    
		            throw new Exception(e);    
		        }    
		    }  

	
}
