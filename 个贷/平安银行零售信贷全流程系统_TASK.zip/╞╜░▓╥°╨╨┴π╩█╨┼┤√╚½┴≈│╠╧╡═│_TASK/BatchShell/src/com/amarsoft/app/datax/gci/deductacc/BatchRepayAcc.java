package com.amarsoft.app.datax.gci.deductacc;



import com.amarsoft.account.Deal.TransLoanCancelRepay;
import com.amarsoft.account.Deal.TransScheduler;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchRepayAcc extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				this.connection.setAutoCommit(false);
				logger.info("��ʼ����һ�㻹�����......");
				TransScheduler transScheduler = new TransScheduler(connection);
				transScheduler.BatchTransScheduler("2001",deductDate);
				logger.info("����һ�㻹�������ɣ�");
				this.connection.setAutoCommit(true);
				this.connection.setAutoCommit(false);
				logger.info("��ʼ���������������......");
				TransLoanCancelRepay transLoanCacelRepay= new TransLoanCancelRepay();
				transLoanCacelRepay.BatchLoanCancelHandAcc("6002", deductDate,"50", connection);
				logger.info("��������������ɣ�");
				this.connection.setAutoCommit(true);
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
		/*finally{
			clearResource();
			return unitStatus;
		}*/
	}
}
