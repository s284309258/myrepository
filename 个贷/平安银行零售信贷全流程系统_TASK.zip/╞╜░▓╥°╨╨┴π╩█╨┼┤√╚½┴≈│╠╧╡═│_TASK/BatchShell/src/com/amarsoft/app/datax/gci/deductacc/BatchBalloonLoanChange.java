package com.amarsoft.app.datax.gci.deductacc;

import java.sql.SQLException;

import com.amarsoft.account.change.UpdateLoanBalance;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchBalloonLoanChange extends CommonExecuteUnit{


	public int execute() {
			
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				int commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��ʼ��������...");
				connection.setAutoCommit(false);
				UpdateLoanBalance.init(connection,1);
				UpdateLoanBalance.executeLoanChange(" and ChangeDate='"+deductDate+"' and ChangeType = '120' and objectType = 'LoanBalance' and exists (select 1 from loan_balance lb where loan_change.objectno = lb.putoutno and lb.loanstatus in ('0','1','4','5'))", connection);
				connection.commit();
				logger.info("�����������");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			try {
				connection.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
