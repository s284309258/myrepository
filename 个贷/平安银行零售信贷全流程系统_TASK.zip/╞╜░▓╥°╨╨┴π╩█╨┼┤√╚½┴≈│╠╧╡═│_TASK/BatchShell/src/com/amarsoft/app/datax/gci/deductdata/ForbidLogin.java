package com.amarsoft.app.datax.gci.deductdata;

import java.sql.Statement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class ForbidLogin extends CommonExecuteUnit{

public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ֹ�û���¼......");
				Statement stmt=connection.createStatement();
				stmt.execute("update PLOAN_SETUP set  login='1',etlDealFlag = '0' ");
				stmt.close();
				logger.info("��ֹ�û���¼�ɹ�......");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
