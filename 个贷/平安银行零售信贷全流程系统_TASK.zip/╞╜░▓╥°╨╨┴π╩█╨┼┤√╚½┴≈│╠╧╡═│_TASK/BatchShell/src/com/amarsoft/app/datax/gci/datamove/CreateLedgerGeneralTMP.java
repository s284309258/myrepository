package com.amarsoft.app.datax.gci.datamove;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateLedgerGeneralTMP extends CommonExecuteUnit  {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("................��ʼ��ʼ��������.............");
					initData();
					logger.info("................��ʼ������������..............");
	
					logger.info("................��ʼ����ҵ�����ݣ�.............");
					CreateTMP1();
					logger.info("................����ҵ��������ɣ�..............");
				}else{
					logger.info("................���첻��Ҫ���У�..............");
				}
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void initData() {
		commitNum = getProperty("commitNum", 1);
	}
	
	public void CreateTMP1() throws SQLException{
		CallableStatement   cs =connection.prepareCall("call QY_LEDGER_GENERAL_TMP_901PR()");    
		  //ִ�д洢����   
		  cs.execute();      
		  cs.close();   
	}
}
