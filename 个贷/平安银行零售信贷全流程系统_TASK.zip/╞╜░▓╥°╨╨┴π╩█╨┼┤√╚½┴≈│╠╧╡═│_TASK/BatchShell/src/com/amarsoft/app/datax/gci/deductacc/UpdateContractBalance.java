package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateContractBalance extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int iCount=0;
	
public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��ʼ���º�ͬ���......");
				updateBalance();
				logger.info("������"+iCount+"������");
				logger.info("���º�ͬ������!");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
			}
			clearResource();
			return unitStatus;
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	
	}

	public void updateBalance() throws SQLException
	{
		String updateSql = " update business_contract set Balance = ? where SerialNo =? ";
		PreparedStatement psUpdateDeductDate = connection.prepareStatement(updateSql);
		
		String selectSql = " select bc.SerialNo,sum(lb.NormalBalance+lb.OverDueBalance) as SumBalance " +
				" from loan_balance lb,business_contract bc " +
				" where lb.ContractSerialNo = bc.SerialNo and (bc.FinishDate is null or bc.balance>0) " +
				" group by bc.SerialNo	";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateDeductDate.setDouble(1,rs.getDouble("SumBalance"));
			psUpdateDeductDate.setString(2,rs.getString("SerialNo"));
			psUpdateDeductDate.addBatch();
			dealNum++;
			iCount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateDeductDate.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+iCount+"����");
			}
		}
		psUpdateDeductDate.executeBatch();
		psUpdateDeductDate.close();
		rs.close();
		psSelectSql.close();
	}
	
}
