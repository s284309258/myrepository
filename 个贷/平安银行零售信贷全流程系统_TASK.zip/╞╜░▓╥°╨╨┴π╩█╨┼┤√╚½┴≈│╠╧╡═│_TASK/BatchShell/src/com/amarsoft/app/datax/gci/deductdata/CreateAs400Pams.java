package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateAs400Pams extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','AS400_PAMS') ";
				logger.info("��� AS400_PAMS:sql="+delSql);
				PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
				psDeleteDeductData.execute();
				logger.info("���AS400_PAMS������� ");
				psDeleteDeductData.close();
				
				logger.info("��ʼ�����պ��������ݱ�......");
				BatchCreateAs400Pams();
				logger.info("����ʼ�����պ���������"+icount+"����");
				logger.info("��ʼ�����պ��������ݱ���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void BatchCreateAs400Pams() throws SQLException
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		String insertSql = " insert into AS400_PAMS(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,DeductAccNo1,DeductAccNo2,RelativeAccNo,AheadSerialNo,SplitType,AmountAttribute,Sterm,TransSerialNo,BusinessSerialNo,BankFlag,DeductSerialNo) "
				         + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,DeductAccNo1,DeductAccNo2,RelativeAccNo,AheadSerialNo,SplitType,AmountAttribute,Sterm,TransSerialNo,BusinessSerialNo,BankFlag,DeductSerialNo "
						 + " from PAMS_AS400 "
						 + " where 1=1 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("SerialNo"));
			psInsertSql.setString(2,rs.getString("PutOutNo"));
			psInsertSql.setString(3,rs.getString("Currency"));
			psInsertSql.setString(4,rs.getString("PayType"));
			psInsertSql.setDouble(5,rs.getDouble("PayAmount"));
			psInsertSql.setString(6,rs.getString("DeductAccNo"));
			psInsertSql.setString(7,rs.getString("DeductAccNo1"));
			psInsertSql.setString(8,rs.getString("DeductAccNo2"));
			psInsertSql.setString(9,rs.getString("RelativeAccNo"));
			psInsertSql.setString(10,rs.getString("AheadSerialNo"));
			psInsertSql.setString(11,rs.getString("SplitType"));
			psInsertSql.setString(12,rs.getString("AmountAttribute"));
			psInsertSql.setInt(13,rs.getInt("Sterm"));
			psInsertSql.setString(14, rs.getString("TransSerialNo"));
			psInsertSql.setString(15, rs.getString("BusinessSerialNo"));
			psInsertSql.setString(16, rs.getString("BankFlag"));
			psInsertSql.setString(17, rs.getString("DeductSerialNo"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�ѳ�ʼ�����պ�ۿ�����"+icount+"����");
			}
			
		}
		psInsertSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
	}
}
