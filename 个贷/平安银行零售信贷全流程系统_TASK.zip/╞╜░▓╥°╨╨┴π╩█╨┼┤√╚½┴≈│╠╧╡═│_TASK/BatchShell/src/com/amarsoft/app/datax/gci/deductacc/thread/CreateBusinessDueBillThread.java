package com.amarsoft.app.datax.gci.deductacc.thread;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateBusinessDueBillThread extends BatchThread {

	private int commitNum ;
	private int dealNum = 0;
	private int icount=0;
	boolean ok = true; 
	
	public void run() {
		
		try{
				commitNum=Integer.parseInt(this.mainProcess.getProperty("commitNum", "1"));
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','business_duebill_tmp') ";
				logger.info("��� BUSINESS_DUEBILL_TMP:sql="+delSql);
				PreparedStatement psDel = connection.prepareStatement(delSql);
				psDel.execute();
				logger.info("���BUSINESS_DUEBILL_TMP������� ");
				psDel.close();
				
				logger.info("��ʼ����BUSINESS_DUEBILL_TMP����......");
				insertDueBill();
				logger.info("����BUSINESS_DUEBILL_TMP������ɣ�");
				this.connection.commit();
				//�ɹ�ע���߳�
				mainProcess.threadLogOff( this, TaskConstants.ES_SUCCESSFUL);//���̳߳ɹ�ִ��
				
		}catch(Exception ex){
			ex.printStackTrace();
			try {
				this.connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			// �̱߳����쳣���������ȱ����������󣬲�ע���߳�
			this.logger.error("����BUSINESS_DUEBILL_TMP�����̡߳�" + this.getName() + "�������쳣����������ȳ��򱨸����...");
			mainProcess.threadLogOff(this, TaskConstants.ES_FAILED);//��ʧ�ܷ�ʽ�����߳�״̬
		} finally {
			this.close();
		} 
	}
	
	public void insertDueBill() throws SQLException
	{
		String insertSql = " insert into business_duebill_tmp(SerialNo,RelativeSerialNo1,RelativeSerialNo2,SubjectNo,MFCustomerID," +
				"CustomerID,CustomerName,BusinessType,BusinessSubType,BusinessStatus," +
				"BusinessCurrency,BusinessSum,PutOutDate,Maturity,ActualMaturity," +
				"BusinessRate,ActualBusinessRate,Balance,NormalBalance,OverDueBalance," +
				"InterestBalance1,InterestBalance2,PayAccount,PutOutAccount,PayBackAccount," +
				"PayInterestAccount,TaBalance,TaInterestBalance,OverDueDays,TaTimes," +
				"LcaTimes,MFAreaID,MFOrgID,MFUserID,OperateOrgID," +
				"OperateUserID,InputOrgID,InputUserID,TimsFlag,ActualArtificialNo," +
				"AccountNo,LoanAccountNo,OverDueDate,OweInterestDate,LoanType," +
				"ReturnType,FinishDate,SaleDate,CancelFlag,AccountOrgID) " +
				" values(?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?," +
				"?,?,?,?,?)";
		PreparedStatement psInsertDeductData = connection.prepareStatement(insertSql);
		
		String selectGeneralSql = " select SubjectNo from Ledger_General where PutOutNo = ? and accountno = '133' ";
		PreparedStatement psGeneralSql = connection.prepareStatement(selectGeneralSql);
		
		String selectSql = " select lb.PutOutNo,lb.ContractSerialNo,nvl(lb.CustomerID,'') as CustomerID,nvl(lb.CustomerName,'') as CustomerName,nvl(ci.MFCustomerID,'') as MFCustomerID, " +
				" nvl(lb.BusinessType,'') as BusinessType,nvl(lb.BusinessSubType,'') as BusinessSubType,nvl(lb.LoanStatus,'') as LoanStatus,nvl(lb.Currency,'') as Currency,nvl(lb.BusinessSum,0) as BusinessSum, " +
				" nvl(lb.PutOutDate,'') as PutOutDate,nvl(lb.MaturityDate,'') as MaturityDate,nvl(lb.PutoutRate,0.0) as PutoutRate,nvl(lb.ExecuteRate,0.0) as ExecuteRate,nvl((lb.Normalbalance+lb.Overduebalance),0) as Balance, " +
				" nvl(lb.NormalBalance,0.0) as NormalBalance,nvl(lb.OverdueBalance,0) as OverdueBalance,nvl(lb.PayInnerInte,0) as PayInnerInte,nvl(lb.PayOutInte,0.0) as PayOutInte,nvl(lb.DeductAccNo,'') as DeductAccNo,  " +
				" nvl(lb.ReturnType,'') as ReturnType,nvl((lb.Payinnerinte+lb.Payoutinte),0.0) as Interest,nvl(lr.OverDays,0) as OverDays,nvl(lr.AddOverTerms,0) as AddOverTerms,nvl(lr.SeriesOverTerms,0) as SeriesOverTerms, " +
				" nvl(oi.MainFrameOrgID,'') as MainFrameOrgID,nvl(lb.UserID,'') as UserID,nvl(bc.OperateOrgID,'') as OperateOrgID,nvl(bc.OperateUserID,'') as OperateUserID,nvl(lb.OrgID,'') as  OrgID, " +
				" nvl(bc.ArtificialNo,'') as ArtificialNo,nvl(lb.FinishDate,'') as FinishDate " +
				" from loan_balance lb,Customer_info ci,Loanbalance_Relative lr,org_info oi,business_contract bc " +
				" where lb.CustomerID=CI.CUSTOMERID and lb.PutOutNo = lr.Putoutno and lb.OrgID = oi.Orgid " +
				" and lb.Contractserialno = bc.Serialno "; 
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sPutOutNo = rs.getString("PutOutNo");
			
			psInsertDeductData.setString(1,sPutOutNo);
			psInsertDeductData.setString(2,"");
			psInsertDeductData.setString(3,rs.getString("ContractSerialNo"));
			psInsertDeductData.setString(4,selectSubjectNo(psGeneralSql,sPutOutNo));
			psInsertDeductData.setString(5,rs.getString("MFCustomerID"));
			
			psInsertDeductData.setString(6,rs.getString("CustomerID"));
			psInsertDeductData.setString(7,rs.getString("CustomerName"));
			psInsertDeductData.setString(8,rs.getString("BusinessType"));
			psInsertDeductData.setString(9,rs.getString("BusinessSubType"));
			psInsertDeductData.setString(10,rs.getString("LoanStatus"));
			
			psInsertDeductData.setString(11,rs.getString("Currency"));
			psInsertDeductData.setDouble(12,rs.getDouble("BusinessSum"));
			psInsertDeductData.setString(13,rs.getString("PutOutDate"));
			psInsertDeductData.setString(14,rs.getString("MaturityDate"));
			psInsertDeductData.setString(15,rs.getString("MaturityDate"));
			
			psInsertDeductData.setDouble(16,rs.getDouble("PutoutRate"));
			psInsertDeductData.setDouble(17,rs.getDouble("ExecuteRate"));
			psInsertDeductData.setDouble(18,rs.getDouble("Balance"));
			psInsertDeductData.setDouble(19,rs.getDouble("NormalBalance"));
			psInsertDeductData.setDouble(20,rs.getDouble("OverdueBalance"));
			
			psInsertDeductData.setDouble(21,rs.getDouble("PayInnerInte"));
			psInsertDeductData.setDouble(22,rs.getDouble("PayOutInte"));
			psInsertDeductData.setString(23,rs.getString("DeductAccNo"));
			psInsertDeductData.setString(24,rs.getString("DeductAccNo"));
			psInsertDeductData.setString(25,rs.getString("DeductAccNo"));
			
			psInsertDeductData.setString(26,rs.getString("DeductAccNo"));
			if(returnTimsFlag(rs.getString("ReturnType")).equals("2"))
			{
				psInsertDeductData.setDouble(27,rs.getDouble("OverdueBalance"));
				psInsertDeductData.setDouble(28,rs.getDouble("Interest"));
			}
			else
			{
				psInsertDeductData.setDouble(27,0.0);
				psInsertDeductData.setDouble(28,0.0);
			}
			psInsertDeductData.setInt(29,rs.getInt("OverDays"));
			psInsertDeductData.setInt(30,rs.getInt("AddOverTerms"));
			
			psInsertDeductData.setInt(31,rs.getInt("SeriesOverTerms"));
			psInsertDeductData.setString(32,"");//����������
			psInsertDeductData.setString(33,rs.getString("MainFrameOrgID"));
			psInsertDeductData.setString(34,rs.getString("UserID"));
			psInsertDeductData.setString(35,rs.getString("OperateOrgID"));
			
			psInsertDeductData.setString(36,rs.getString("OperateUserID"));
			psInsertDeductData.setString(37,rs.getString("OrgID"));
			psInsertDeductData.setString(38,rs.getString("UserID"));
			psInsertDeductData.setString(39,returnTimsFlag(rs.getString("ReturnType")));
			psInsertDeductData.setString(40,rs.getString("ArtificialNo"));
			
			psInsertDeductData.setString(41,"");//�����ʺ�
			psInsertDeductData.setString(42,"");//���������ʺ�
			psInsertDeductData.setString(43,"");//��������
			psInsertDeductData.setString(44,"");//ǷϢ����
			psInsertDeductData.setString(45,"");//��������
			
			psInsertDeductData.setString(46,rs.getString("ReturnType"));
			psInsertDeductData.setString(47,rs.getString("FinishDate"));
			psInsertDeductData.setString(48,"");//SaleDate
			psInsertDeductData.setString(49,"");//CancelFlag
			psInsertDeductData.setString(50,rs.getString("OrgID"));
			
			psInsertDeductData.addBatch();
			dealNum++;
			icount++;
			if(dealNum>=commitNum)
			{
				psInsertDeductData.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"�����ݣ�");
			}
		}
		psInsertDeductData.executeBatch();
		rs.close();
		psGeneralSql.close();
		psSelectSql.close();
		psInsertDeductData.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
	
	/*
	 * ����PutOutNo ��Ledger_General���� ����������Ŀ��
	 * */
	private String selectSubjectNo(PreparedStatement psTemp,String sPutOutNo) throws SQLException
	{
		String sReturn = "";
		
		psTemp.setString(1,sPutOutNo);
		ResultSet rsTemp = psTemp.executeQuery();
		if(rsTemp.next())
		{
			sReturn = rsTemp.getString("SubjectNo");
		}
		rsTemp.close();
		
		return sReturn;
	}
	
	/*
	 * ����ҵ��Ķ�������ڣ�����1 Ϊ���� 2Ϊ����
	 * ����paras: sReturnType ���ʽ
	 * */
	private String returnTimsFlag(String sReturnType)
	{
		if(sReturnType.equals("1"))  //�ȶ��
			return "2";
		if(sReturnType.equals("2"))  //�ȱ�����
			return "2";
		if(sReturnType.equals("3"))  //���汾��
			return "1";
		if(sReturnType.equals("4"))  //��Ϣ����
			return "1";
		if(sReturnType.equals("5"))  //�ȶ�������
			return "2";
		if(sReturnType.equals("6"))  //�ȱȵ������
			return "2";
		if(sReturnType.equals("7"))  //����˫�ܹ�
			return "2";
		if(sReturnType.equals("10")) //������Ϣһ�λ���
			return "1";
		if(sReturnType.equals("11")) //�Զ��廹��
			return "1";
		if(sReturnType.equals("15")) //�͹���
			return "2";
		if(sReturnType.equals("16")) //β���
			return "2";
		if(sReturnType.equals("17")) //�����ڲ����
			return "2";
		if(sReturnType.equals("18")) //�����ڻ�Ϣ��
			return "2";
		if(sReturnType.equals("19")) //�����ڹ̶�����
			return "2";
		else return " ";
	}
	
}
