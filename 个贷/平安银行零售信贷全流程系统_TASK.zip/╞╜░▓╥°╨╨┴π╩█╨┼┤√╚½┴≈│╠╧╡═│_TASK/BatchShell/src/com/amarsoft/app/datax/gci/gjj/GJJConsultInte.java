package com.amarsoft.app.datax.gci.gjj;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.Deal.ContinueTransDayInte;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class GJJConsultInte extends CommonExecuteUnit{

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ�����������ǰ��Ϣ");
				//��������+1
				String sDate =  DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
				String EndMonthDate = DateTools.getEndDateOfMonth(deductDate);
				ContinueTransDayInte continueTransDayInte = new ContinueTransDayInte();
				continueTransDayInte.BatchDayInteZTOB(sDate,EndMonthDate, connection);	
				continueTransDayInte.BatchDayInteCTOB(sDate,EndMonthDate, connection);	
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				logger.info("�����������ǰ��Ϣ������");
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
