package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.account.write.execute.FreezeDeposit;
import com.amarsoft.account.write.execute.SWFreezeDeposit;
import com.amarsoft.account.write.execute.TransDepositAcc;
import com.amarsoft.account.write.execute.TransDepositAccBF;
import com.amarsoft.account.write.execute.TransDepositAccSW;
import com.amarsoft.account.write.execute.TransXXBF;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;
//С���������⴦��
public class DealXXBF extends CommonExecuteUnit{
	
	private String timeFlag="";
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				timeFlag=getProperty("timeFlag", "AM");
				logger.info("С���������⴦����ʼ......");
				dealXXBF(timeFlag);
				logger.info("С���������⴦�����!");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//ֻ�������������Ļ���
	private void dealXXBF(String timeFlag) throws Exception
	{
		Transaction Sqlca = StringTools.getSqlca();
		double sum = 0.0;
		//�Ѿ��ۿ�ɹ��ı���
		String sql = "select nvl(sum(apb.actualamount),0) as sumamount from loan_balance lb,as400_pams_bak apb where lb.putoutno=apb.putoutno and lb.businesstype='1150060' and  "+
		" apb.inputdate='"+deductDate+"' and  apb.amountattribute='3' and apb.actualamount>0 and lb.bankflag='PAB' and apb.deductaccno is not null and apb.timeflag='"+timeFlag+"'";
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			sum = rs.getDouble("sumamount");
		}
		//����н���ȫ�������߿��н���
		try
		{
			if(sum>0){
				TransXXBF transXXBF = new TransXXBF();
				CompositeData compositeData=transXXBF.getXX(sum,OCIConfig.getUserID(), Sqlca);
				String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
				String ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
				if(ret_status.equals("F")){
					logger.info("С�����⴦������ʧ��"+ret_msg);
					Sqlca.conn.rollback();
				}
				Sqlca.conn.commit();
			}else{
				logger.info("������С�����⴦������");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			Sqlca.conn.rollback();
		}
		
		rs.close();
		ps.close();
	}

}
