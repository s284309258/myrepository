package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchUpdateContractConfirm extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 1;
	
	public int execute() {
			
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					
					logger.info("��ʼ������������ÿ�ʺ�ͬ�µ�ѺƷ�ܶ�.....");
					updateContractConfirm();
					logger.info("��������ÿ�ʺ�ͬ�µ�ѺƷ�ܶ���ɣ�");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}

	public void updateContractConfirm() throws SQLException
	{
		String updateSql = " update business_contract set WholeConfirmValue=? where SerialNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String updateSql2 = " update Guaranty_Info set GuarantyRate=? "
			 			  + " where GuarantyID =? ";
		PreparedStatement psUpdateSql2 = connection.prepareStatement(updateSql2);
	
		String updateSql3 = " update Guaranty_Change set NewGuarantyRate=?,WholeConfirmValue=? " +
				" where ChangeDate = ?  and changeType = '01' " +
				   " and GuarantyID =? ";
		PreparedStatement psUpdateSql3 = connection.prepareStatement(updateSql3);
		
		String tmpSql = " select GR.GuarantyID,BC.BusinessKind from Guaranty_Relative GR,Business_Contract BC where GR.ObjectNo = ? and GR.ObjectNo=BC.SerialNo and GR.Objecttype in ('CBContractApply','SWContractApply') ";
		PreparedStatement psTmpSql = connection.prepareStatement(tmpSql);
		
		String tempSql2 = "  select count(*) as icount  " +
				" from Guaranty_Change gc,Guaranty_Relative gr " +
				"  where gc.GuarantyID= gr.GuarantyID and gr.Objecttype in ('CBContractApply','SWContractApply') and gc.inputdate = ? and gr.ObjectNo = ? ";
		PreparedStatement psTempSql2 = connection.prepareStatement(tempSql2);
					
		String selectSql = " select sum(nvl(gi.ReevaluateValue,0)) as WholeConfirmValue,gr.ObjectNo,bc.Balance,bc.BusinessSum,bc.PutOutType   "
						 + " from guaranty_info gi,guaranty_relative gr,Business_Contract bc   "
						 + " where gi.GuarantyID = gr.GuarantyID and gr.Objecttype in ('CBContractApply','SWContractApply') and bc.serialno = gr.objectno " 
						 + " group by gr.ObjectNo,bc.Balance,bc.BusinessSum,bc.PutOutType ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			int icount = 0;
			psTempSql2.setString(1,nextDate);
			psTempSql2.setString(2,rs.getString("ObjectNo"));
			ResultSet rsTemp2 = psTempSql2.executeQuery();
			if(rsTemp2.next())
			{
				icount = rsTemp2.getInt("icount");
			}
			rsTemp2.close();
			if(icount==0)
				continue;
			
			psUpdateSql.setDouble(1,rs.getDouble("WholeConfirmValue"));
			psUpdateSql.setString(2,rs.getString("ObjectNo"));
			psUpdateSql.addBatch();
			
			//��Ѻ�ʼ��㹫ʽ���������/����ѺƷ�϶���ֵ
			double dGuarantRate = 0.0;
			//���Ϊ��ȣ�ȡ��ͬ���
			if("030".equals(rs.getString("PutOutType"))){
				dGuarantRate = NumberTools.round(rs.getDouble("BusinessSum")/rs.getDouble("WholeConfirmValue"),6);
			}else{
				dGuarantRate = NumberTools.round(rs.getDouble("Balance")/rs.getDouble("WholeConfirmValue"),6);
			}
			
			psTmpSql.setString(1,rs.getString("ObjectNo"));
			ResultSet rsTmp = psTmpSql.executeQuery();
			while(rsTmp.next())
			{
				if("SWPM".equals(rsTmp.getString("BusinessKind"))){
					psUpdateSql2.setDouble(1,dGuarantRate*100);
				}else{
					psUpdateSql2.setDouble(1,dGuarantRate);
				}
				psUpdateSql2.setString(2,rsTmp.getString("GuarantyID"));
				psUpdateSql2.addBatch();
				
				psUpdateSql3.setDouble(1,dGuarantRate);
				psUpdateSql3.setDouble(2,rs.getDouble("WholeConfirmValue"));
				psUpdateSql3.setString(3,nextMonth);
				psUpdateSql3.setString(4,rsTmp.getString("GuarantyID"));
				psUpdateSql3.addBatch();
				
				dealNum++;
				icount++;
			}
			rsTmp.close();

			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				psUpdateSql2.executeBatch();
				psUpdateSql3.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"������!");
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSql2.executeBatch();
		psUpdateSql3.executeBatch();
		rs.close();
		psUpdateSql.close();
		psUpdateSql2.close();
		psUpdateSql3.close();
		psSelectSql.close();
		psTempSql2.close();
		psTmpSql.close();
		logger.info("һ������"+dealNum+"������!");
	}
}
