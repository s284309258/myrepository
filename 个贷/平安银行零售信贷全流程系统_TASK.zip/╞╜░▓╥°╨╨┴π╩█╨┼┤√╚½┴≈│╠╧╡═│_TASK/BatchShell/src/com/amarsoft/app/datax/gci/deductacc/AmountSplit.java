package com.amarsoft.app.datax.gci.deductacc;

import java.util.ArrayList;

import com.amarsoft.app.datax.gci.DeductData;

public class AmountSplit {
	
	private double deductBalance = 0;
	boolean b = false;
	
	//������� portraitFlag �ۿ����    landFlag ��Ŀ�ۿ�˳��
	public ArrayList<DeductData> splitAmount(double amount,ArrayList<DeductData> oldDeductDataList,String portraitFlag,String landFlag)
	{
		deductBalance = amount;
		
		//�Ⱥ����
		if(portraitFlag.equals("1"))
		{  
			portraitFlag1(deductBalance,oldDeductDataList,landFlag);
		}
		//���ݺ��
		else
		{
			portraitFlag2(deductBalance,oldDeductDataList,landFlag);
			
		}
		
		return oldDeductDataList;
	}
	//�Ⱥ����
	public void portraitFlag1(double deductBalance,ArrayList<DeductData> oldDeductDataList,String landFlag)
	{
		DeductData deductData;
		//ѭ��ȡ��ArrayList������
		for(int i=0;i<oldDeductDataList.size();i++)
		{
			if(deductBalance<=0)
				break;
			deductData = oldDeductDataList.get(i);
			String ss[] = landFlag.split("@");
			//������Ŀۿ�˳�� ѭ���ۿ�
			for(int j=0;j<ss.length;j++)
			{
				String sSingleAmount = ss[j];
				if(deductBalance<=0)
				{
					b=true;
					break;
				}
				//����	
				if(sSingleAmount.equalsIgnoreCase("corp"))
				{
					deductSingleCorpAmount(deductData);
				}
				//��Ϣ
				else if(sSingleAmount.equalsIgnoreCase("Inte"))
				{
					deductSingInteAmount(deductData);
				}
				//��Ϣ
				else
				{
					deductSingleFineAmount(deductData);
				}
			}
			if(b == true)
				break;
		}
	}
	//���ݺ��
	public void portraitFlag2(double deductBalance,ArrayList<DeductData> oldDeductDataList,String landFlag)
	{
		DeductData deductData;
		String ss[] = landFlag.split("@");
		//�ҳ�����ۿ�˳��
		for(int i=0;i<ss.length;i++)
		{
			if(deductBalance<=0)
				break;
			String sSingleAmount = ss[i];
			//�۳�����Ӧ������
			if(sSingleAmount.equalsIgnoreCase("corp"))
			{
				for(int j=0;j<oldDeductDataList.size();j++)
				{
					if(deductBalance<=0)
					{
						b = true;
						break;
					}
					deductData = oldDeductDataList.get(j);
					deductSingleCorpAmount(deductData);
				}
			}
			//�۳�����Ӧ����Ϣ
			else if(sSingleAmount.equalsIgnoreCase("Inte"))
			{
				for(int j=0;j<oldDeductDataList.size();j++)
				{
					if(deductBalance<=0)
					{
						b = true;
						break;
					}
					deductData = oldDeductDataList.get(j);
					deductSingInteAmount(deductData);
				}
			}
			//�۳�����Ӧ����Ϣ
			else
			{
				for(int j=0;j<oldDeductDataList.size();j++)
				{
					if(deductBalance<=0)
					{
						b = true;
						break;
					}
					deductData = oldDeductDataList.get(j);
					deductSingleFineAmount(deductData);
				}
			}
			if(b == true)
				break;
		}
	}
	
	//������
	public void deductSingleCorpAmount(DeductData deductData)
	{	
		//��������
		if((deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp())>0)
		{
			if(deductBalance>=(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp());
				deductData.setActualCurrentCorp(deductData.getPayCurrentCorp()-deductData.getActualCurrentCorp());
			}
			else
			{
				deductData.setActualCurrentCorp(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			//�˴δ���û�н���
			deductData.setActualCurrentCorp(0);
		}
		//���ڱ���
		if((deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp())>0)
		{
			if(deductBalance>=(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp());
				deductData.setActualOverDueCorp(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp());
			}
			else
			{
				deductData.setActualOverDueCorp(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualOverDueCorp(0);
		}
		//ΥԼ����
		if(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp()>0)
		{
			if(deductBalance>=(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp()))
			{
				deductBalance = deductBalance-(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp());
				deductData.setActualDefaultCorp(deductData.getPayDefaultCorp()-deductData.getActualDefaultCorp());
			}
			else
			{
				deductData.setActualDefaultCorp(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualDefaultCorp(0);
		}
	}
	
	//��Ϣ����
	public void deductSingInteAmount(DeductData deductData)
	{
		//Ӧ����Ϣ
		if((deductData.getPayInte()-deductData.getActualInte())>0)
		{
			if(deductBalance>=(deductData.getPayInte()-deductData.getActualInte()))
			{
				deductBalance = deductBalance-(deductData.getPayInte()-deductData.getActualInte());
				deductData.setActualInte(deductData.getPayInte()-deductData.getActualInte());
			}
			else
			{
				deductData.setActualInte(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualInte(0);
		}	
		//Ӧ����Ϣ
		if((deductData.getPayInnerInte()-deductData.getActualInnerInte())>0)
		{
			if(deductBalance>=(deductData.getPayInnerInte()-deductData.getActualInnerInte()))
			{
				deductBalance = deductBalance-(deductData.getPayInnerInte()-deductData.getActualInnerInte());
				deductData.setActualInnerInte(deductData.getPayInnerInte()-deductData.getActualInnerInte());
			}
			else
			{
				deductData.setActualInnerInte(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualInnerInte(0);
		}
		//��Ӧ����Ϣ
		if(deductData.getPayOutInte()-deductData.getActualOutInte()>0)
		{
			if(deductBalance>=(deductData.getPayOutInte()-deductData.getActualOutInte()))
			{
				deductBalance = deductBalance-(deductData.getPayOutInte()-deductData.getActualOutInte());
				deductData.setActualOutInte(deductData.getPayOutInte()-deductData.getActualOutInte());
			}
			else
			{
				deductData.setActualOutInte(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualOutInte(0);
		}
	}
	
	//��Ϣ����
	public void deductSingleFineAmount(DeductData deductData)
	{
		
		//���ڷ�Ϣ
		if((deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())>0)
		{
			if(deductBalance>=(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()))
			{
				deductBalance = deductBalance-(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine());
				deductData.setActualInnerInteFine(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine());
			}
			else
			{
				deductData.setActualInnerInteFine(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualInnerInteFine(0);
		}
		//���ⷣϢ
		if((deductData.getPayOutInteFine()-deductData.getActualOutInteFine())>0)
		{
			if(deductBalance>=(deductData.getPayOutInteFine()-deductData.getActualOutInteFine()))
			{
				deductBalance = deductBalance-(deductData.getPayOutInteFine()-deductData.getActualOutInteFine());
				deductData.setActualOutInteFine(deductData.getPayOutInteFine()-deductData.getActualOutInteFine());
			}
			else
			{
				deductData.setActualOutInteFine(deductBalance);
				deductBalance = 0.0;
			}
		}else{
			deductData.setActualOutInteFine(0);
		}
	}
	
	public double getDeductBalance() {
		return deductBalance;
	}

}
