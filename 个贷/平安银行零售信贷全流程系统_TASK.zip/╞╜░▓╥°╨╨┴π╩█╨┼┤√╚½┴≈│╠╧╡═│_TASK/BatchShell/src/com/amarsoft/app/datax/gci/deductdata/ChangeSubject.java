package com.amarsoft.app.datax.gci.deductdata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class ChangeSubject extends CommonExecuteUnit{

	private int iMaxLedgerNum = 0;//ledger_detail
	private int iMaxBCLNum = 0;//business_change_log
	private int count = 0;
	
	private int allCount = 0;
	
	public int execute() {
		try {
			String sInit = super.init();
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				// connection.setAutoCommit(false);
				logger.info("��ʼ�����Ŀ����......");
				BatchChangeSubjectNo();
				logger.info("��ʼ�����Ŀ��������......");
				unitStatus = TaskConstants.ES_SUCCESSFUL;

				clearResource();
				return unitStatus;
			}
		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	// ���б����Ŀ����,����ʱ��͹���������������ʱ��һ��,�����������03/04���ߣ���Ҫ�޸Ĵ����BatchChangeSubjectNo����
	private void BatchChangeSubjectNo() throws Exception {
		String changeDateSql = " SELECT itemname FROM CODE_LIBRARY WHERE CODENO = 'BatchChangeSubjectNo' AND ItemNo = 'ChangeDate'";
		PreparedStatement psChangeDateSql = connection.prepareStatement(changeDateSql);
		ResultSet rs = psChangeDateSql.executeQuery();
		if(rs.next()){
			String changeDate = rs.getString("itemname");
			if(deductDate.equalsIgnoreCase(changeDate)){
				initSerialCount(deductDate,connection);
				//����һ������������ɾ����֧���ظ����С�		
				dealRepay();

				//���ڶ���������������Ϣ��
				logger.info("��ʼ����loan_subject��Trans_enty~~~~~~~~~~~~~~~");
				UpdateLoanAndTrans();
				SystemConfig.loadSystemConfig(true,connection);
				logger.info("����loan_subject~~~~~~~~~~~~~~~");
				
				//�������������շ����ı��������ɿ�Ŀ����Ϊ�¿�Ŀ��
				logger.info("��ʼ�������ձ��ⷢ����~~~~~~~~~~~~~~~");
				dealTodayLedgerDetail();
				logger.info("�������ձ��ⷢ�������~~~~~~~~~~~~~~~");
				
				//�����Ĳ��������յ����˽��и��¡�
				logger.info("��ʼ�������˱�~~~~~~~~~~~~~~~");
				dealSubjectBalance();
				logger.info("�������˱����~~~~~~~~~~~~~~");
				
				//�����岽���Է��˽��и��¡�
				logger.info("��ʼ���˱���Ŀ����~~~~~~~~~~~~~~~");
				BatchChangeLedgerGeneral();
				logger.info("��ʼ���˱���Ŀ��������~~~~~~~~~~~~~~~");
			}else{
				logger.info("����:"+deductDate+":����Ҫ���п�Ŀ����......");
			}
		}
		rs.close();
		psChangeDateSql.close();
	}
	
	//�����յ����������и��£��Դ����¿�Ŀ�����˵�of
	private void dealSubjectBalance() throws Exception {
		String occurDate = DateTools.getRelativeDate(deductDate, "D", -1);
		
		//�����������˱�
		String deteleSubjectBalance = " DELETE FROM  subject_balance_tmp  WHERE  occurdate = '"+occurDate+"'";
		Statement statDeleteSubjectBalance=connection.createStatement();
		statDeleteSubjectBalance.execute(deteleSubjectBalance);
		statDeleteSubjectBalance.close();
		
		String copySubjectBalance = " INSERT INTO subject_balance_tmp (SELECT * FROM subject_balance WHERE  occurdate = '"+occurDate+"' )";
		Statement statCopySubjectBalance=connection.createStatement();
		statCopySubjectBalance.execute(copySubjectBalance);
		statCopySubjectBalance.close();
		
		
		//������ˮ�������Ǳ���ͨ�������������������죬�ǽ���
		String SqlInsertLedgerDetail = " Insert Into Ledger_Detail(SerialNo,PutOutNo,BillNo,TransID,SortID,OccurTime,"+
										" OccurDate,Currency,SubjectNo,CreditAmt,DebitAmt,HandStatus,OrgID) "+
										" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,? )";
		PreparedStatement psInsertLedgerDetail = connection.prepareStatement(SqlInsertLedgerDetail);
		
		//�仯����
		//'70500201'+'70500301' --->70500102
		//'70500501'--->70500109
		//'70900111'--->70900107
		String sqlQuery = " SELECT * FROM subject_balance WHERE  occurdate = ? AND Orgid = ? AND  subjectno LIKE '7%'  ORDER BY Currency,Orgid,Subjectno";
		PreparedStatement psSqlQuery = connection.prepareStatement(sqlQuery);
		
		//��¼ɾ���Ŀ�Ŀ����־
		String sqlLog= " INSERT INTO business_change_log (SerialNo,objecttype,objectno,changedate,status,transid,colname,oldvalue,newvalue,relativeserialno) " +
				       " VALUES (?,?,?,?,?," +
				       " ?,?,?,?,?)";
		PreparedStatement psSqlLog = connection.prepareStatement(sqlLog);
		
//		//���¿�Ŀ
//		String updateSubjectNo = " UPDATE subject_balance SET subjectno=?,checksubjectno=?  WHERE  occurdate = ? AND  checksubjectno=? AND currency =? AND  orgid=? AND subjectno=?";
//		PreparedStatement psUpdateSubjectNo= connection.prepareStatement(updateSubjectNo);
//		
//		//ɾ���ɵ����˱���Ŀ
//		String deleteSql = " DELETE FROM subject_balance WHERE  occurdate = ? AND  checksubjectno=? AND currency =? AND  orgid=? AND subjectno=?";
//		PreparedStatement psDeleteSql = connection.prepareStatement(deleteSql);
		
		//��û�е��¿�Ŀ���뵽���˱�
		String sqlInsert = " INSERT INTO subject_balance (Currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno)" +
							" VALUES (?,?,?,?,?,?,?)";
		PreparedStatement psSqlInsert = connection.prepareStatement(sqlInsert);
		
		String sqlOrgid = " SELECT orgid FROM org_info ORDER BY orgid";
		PreparedStatement psSqlOrgid = connection.prepareStatement(sqlOrgid);
		
		ResultSet rsSqlOrgid = psSqlOrgid.executeQuery();
		while(rsSqlOrgid.next()){
			String orgid = rsSqlOrgid.getString("orgid");
			psSqlQuery.setString(1, occurDate);
			psSqlQuery.setString(2, orgid);
			String currency = "";
			
			double amount70500201 = 0.0;//���ڸ���
			double amount70500301 = 0.0;//���⸴��
			double amount70500102 = 0.0;//��������
			double amount70500501 = 0.0;//ί�д���ǷϢ
			double amount70900111 = 0.0;//������ǷϢ
			
			
			ResultSet rsSqlQuery = psSqlQuery.executeQuery();
			while(rsSqlQuery.next()){
				currency = rsSqlQuery.getString("currency");
				String orgidSb = rsSqlQuery.getString("orgid");
				String subjectno = rsSqlQuery.getString("subjectno");
				double debitbalance = rsSqlQuery.getDouble("debitbalance");
				if("70500201".equalsIgnoreCase(subjectno)){
					amount70500201 = debitbalance;
					//��ɾ����Ŀ����¼�����־��
					iMaxBCLNum++;
					String bChangeLogNo = "ChSub" +deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxBCLNum,8,'0');
					//(SerialNo,objecttype,objectno,changedate,status,transid,colname,oldvalue,newvalue,relativeserialno)
					psSqlLog.setString(1, bChangeLogNo)	;
					psSqlLog.setString(2, "SubjectNOChange");
					psSqlLog.setString(3, subjectno+orgidSb+currency);
					psSqlLog.setString(4, occurDate);
					psSqlLog.setString(5, "2");
					psSqlLog.setString(6, "ChSub");
					psSqlLog.setString(7, "debitbalance");
					psSqlLog.setString(8, Double.toString(debitbalance));
					psSqlLog.setString(9, "0");
					psSqlLog.setString(10, "");
					psSqlLog.addBatch();
					
					//��¼���յ���������ˮ�������գ��ǽ���
					DealLedgerDetail(psInsertLedgerDetail,debitbalance,orgidSb+subjectno+currency,currency,subjectno,orgid,"70500102","OF");
				}else if("70500301".equalsIgnoreCase(subjectno)){
					amount70500301 = debitbalance;
					//��ɾ����Ŀ����¼�����־��
					iMaxBCLNum++;
					String bChangeLogNo = "ChSub" +deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxBCLNum,8,'0');
					//(SerialNo,objecttype,objectno,changedate,status,transid,colname,oldvalue,newvalue,relativeserialno)
					psSqlLog.setString(1, bChangeLogNo)	;
					psSqlLog.setString(2, "SubjectNOChange");
					psSqlLog.setString(3, subjectno+orgidSb+currency);
					psSqlLog.setString(4, occurDate);
					psSqlLog.setString(5, "2");
					psSqlLog.setString(6, "ChSub");
					psSqlLog.setString(7, "debitbalance");
					psSqlLog.setString(8, Double.toString(debitbalance));
					psSqlLog.setString(9, "0");
					psSqlLog.setString(10, "");
					psSqlLog.addBatch();
					
					//��¼���յ���������ˮ�������գ��ǽ���
					DealLedgerDetail(psInsertLedgerDetail,debitbalance,orgidSb+subjectno+currency,currency,subjectno,orgid,"70500102","OF");
				}else if("70500501".equalsIgnoreCase(subjectno)){
					amount70500501 = debitbalance;
					//�����¿�Ŀ����¼�����־��
					iMaxBCLNum++;
					String bChangeLogNo = "ChSub" +deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxBCLNum,8,'0');
					//(SerialNo,objecttype,objectno,changedate,status,transid,colname,oldvalue,newvalue,relativeserialno)
					psSqlLog.setString(1, bChangeLogNo)	;
					psSqlLog.setString(2, "SubjectNOChange");
					psSqlLog.setString(3, subjectno+orgidSb+currency);
					psSqlLog.setString(4, deductDate);
					psSqlLog.setString(5, "2");
					psSqlLog.setString(6, "ChSub");
					psSqlLog.setString(7, "Subjectno");
					psSqlLog.setString(8, subjectno);
					psSqlLog.setString(9, "70500109");
					psSqlLog.setString(10, "");
					psSqlLog.addBatch();
					
					//��¼���յ���������ˮ�������գ��ǽ���
					DealLedgerDetail(psInsertLedgerDetail,debitbalance,orgidSb+subjectno+currency,currency,subjectno,orgid,"70500501","OF");
				}else if("70900111".equalsIgnoreCase(subjectno)){
					amount70900111 = debitbalance;
					
					//�����¿�Ŀ����¼�����־��
					iMaxBCLNum++;
					String bChangeLogNo = "ChSub" +deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxBCLNum,8,'0');
					//(SerialNo,objecttype,objectno,changedate,status,transid,colname,oldvalue,newvalue,relativeserialno)
					psSqlLog.setString(1, bChangeLogNo)	;
					psSqlLog.setString(2, "SubjectNOChange");
					psSqlLog.setString(3, subjectno+orgidSb+currency);
					psSqlLog.setString(4, deductDate);
					psSqlLog.setString(5, "2");
					psSqlLog.setString(6, "ChSub");
					psSqlLog.setString(7, "Subjectno");
					psSqlLog.setString(8, subjectno);
					psSqlLog.setString(9, "70900107");
					psSqlLog.setString(10, "");
					psSqlLog.addBatch();
					
					//��¼���յ���������ˮ�������գ��ǽ���
					DealLedgerDetail(psInsertLedgerDetail,debitbalance,orgidSb+subjectno+currency,currency,subjectno,orgid,"70900107","OF");
				}
			}
			rsSqlQuery.close();
			amount70500102 = amount70500201+ amount70500301;
			//����ǷϢ����
//			if(amount70500102>0){
//				//INSERT INTO subject_balance (Currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno)
//				psSqlInsert.setString(1, currency);
//				psSqlInsert.setString(2, orgid);
//				psSqlInsert.setString(3, "70500102");
//				psSqlInsert.setDouble(4, amount70500102);
//				psSqlInsert.setDouble(5, 0);
//				psSqlInsert.setString(6, occurDate );
//				psSqlInsert.setString(7,  "70500102" );
//				psSqlInsert.addBatch();
//			}
//			//wί�д���ǷϢ
//			if(amount70500501>0){
//				//INSERT INTO subject_balance (Currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno)
//				psSqlInsert.setString(1, currency);
//				psSqlInsert.setString(2, orgid);
//				psSqlInsert.setString(3, "70500501");
//				psSqlInsert.setDouble(4, amount70500501);
//				psSqlInsert.setDouble(5, 0);
//				psSqlInsert.setString(6, occurDate );
//				psSqlInsert.setString(7,  "70500501" );
//				psSqlInsert.addBatch();
//			}
//			
//			//����ǷϢ
//			if(amount70900111>0){
//				//INSERT INTO subject_balance (Currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno)
//				psSqlInsert.setString(1, currency);
//				psSqlInsert.setString(2, orgid);
//				psSqlInsert.setString(3, "70900107");
//				psSqlInsert.setDouble(4, amount70900111);
//				psSqlInsert.setDouble(5, 0);
//				psSqlInsert.setString(6, occurDate );
//				psSqlInsert.setString(7,  "70900107" );
//				psSqlInsert.addBatch();
//			}
			psSqlLog.executeBatch();
//			psSqlInsert.executeBatch();
			psInsertLedgerDetail.executeBatch();
		}
		rsSqlOrgid.close();
		psSqlOrgid.close();
		psSqlQuery.close();
		psSqlLog.close();
		psInsertLedgerDetail.close();
		psSqlInsert.close();
	}

	//���շ����ı��������ɿ�Ŀ����Ϊ�¿�Ŀ
	private void dealTodayLedgerDetail() throws SQLException {
		String updateSql = " UPDATE ledger_detail SET Subjectno = ? WHERE SerialNo = ? AND  Subjectno = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		//�ɿ�Ŀ�ֱ��� �����������ǷϢ���� �������������ǷϢ���� ��ί�д���ǷϢ  �����⻵�ʡ������������ǷϢת��
		String sqlOccurToday = " SELECT SerialNo,Subjectno FROM ledger_detail WHERE occurdate = ?  AND subjectno IN('70500201','70500301','70500501','70900111') ";
		PreparedStatement psOccurToday = connection.prepareStatement(sqlOccurToday);
		
		psOccurToday.setString(1, deductDate);
		ResultSet rsOccurToday = psOccurToday.executeQuery();
		while(rsOccurToday.next()){
			String serialNo = rsOccurToday.getString("SerialNo");
			String subjectno = rsOccurToday.getString("Subjectno");
			//�仯����
			//'70500201','70500301' --->70500102
			//'70500501'--->70500109
			//'70900111'--->70900107
			if("70500201".equalsIgnoreCase(subjectno) || "70500301".equalsIgnoreCase(subjectno)){
				psUpdateSql.setString(1, "70500102");
				psUpdateSql.setString(2, serialNo);
				psUpdateSql.setString(3, subjectno);
				psUpdateSql.addBatch();
				count++;
			}else if("70500501".equalsIgnoreCase(subjectno)){
				psUpdateSql.setString(1, "70500109");
				psUpdateSql.setString(2, serialNo);
				psUpdateSql.setString(3, subjectno);
				psUpdateSql.addBatch();
				count++;
			}else if("70900111".equalsIgnoreCase(subjectno)){
				psUpdateSql.setString(1, "70900107");
				psUpdateSql.setString(2, serialNo);
				psUpdateSql.setString(3, subjectno);
				psUpdateSql.addBatch();
				count++;
			}else{
				logger.info("û�еĿ�Ŀ:"+subjectno+":......");
			}
			
			if(count>=1000){
				psUpdateSql.executeBatch();
				allCount +=count;
				logger.info("�Ѿ����£�"+allCount+"��");
				count =0;
			}
		}
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		allCount +=count;
		logger.info("�Ѿ����£�"+allCount+"��");
		allCount= 0;
		count = 0;
		
		rsOccurToday.close();
		psOccurToday.close();
	}

	//��������м�������ع�
	private void dealRepay() throws SQLException {
		//70500201  70500301   70900111
		//ɾ��ledger_detail
		String detatilSerialNo = "ChS%" + deductDate.replaceAll("/", "") + "%";
		String dealDetail = " DELETE FROM ledger_detail WHERE SerialNo LIKE '"+detatilSerialNo+"'";
		Statement statDealDetail=connection.createStatement();
		statDealDetail.execute(dealDetail);
		statDealDetail.close();
		
		//�������������
		String hexiaoSql = " SELECT * FROM ledger_general WHERE DebitBalance>0 and subjectno = '70900107' AND ( ledger_general.creditbalance >0 OR ledger_general.debitbalance >0)";
		PreparedStatement psHexiaoSql = connection.prepareStatement(hexiaoSql);
		
		String updateLedgerGeneralHexiao = " UPDATE ledger_general SET debitbalance = ?  WHERE SubjectNo = ? and putoutno=?";
		PreparedStatement psUpdateLedgerGeneralHexiao = connection.prepareStatement(updateLedgerGeneralHexiao);
		
		ResultSet rsHexiao = psHexiaoSql.executeQuery();
		while(rsHexiao.next()){
			String putoutno = rsHexiao.getString("putoutno");
			double amount = rsHexiao.getDouble("DebitBalance");
			
			psUpdateLedgerGeneralHexiao.setDouble(1, amount);
			psUpdateLedgerGeneralHexiao.setString(2, "70900111");
			psUpdateLedgerGeneralHexiao.setString(3, putoutno);
			
			psUpdateLedgerGeneralHexiao.addBatch();
		}
		psUpdateLedgerGeneralHexiao.executeBatch();
		psUpdateLedgerGeneralHexiao.close();
		rsHexiao.close();
		psHexiaoSql.close();
		
		//ɾ��ledger_general
		String dealGeneral = " DELETE FROM ledger_general WHERE subjectno in ('70500102','70500109','70900107')";
		Statement statDealGeneral=connection.createStatement();
		statDealGeneral.execute(dealGeneral);
		statDealGeneral.close();
		
		String updateLedgerGeneral = " UPDATE ledger_general SET debitbalance = ?  WHERE SubjectNo = ? and putoutno = ?";
		PreparedStatement psUpdateLedgerGeneral = connection.prepareStatement(updateLedgerGeneral);
		
		//���д��Ҫ����
		String sqlLoanBalance = " SELECT payinnerintefine,payoutintefine,businessType,putoutno FROM loan_balance WHERE 1=1 ";
		PreparedStatement psLoanBalance = connection.prepareStatement(sqlLoanBalance);
		ResultSet rsLoanBalance = psLoanBalance.executeQuery();
		while(rsLoanBalance.next()){
			String putoutno = rsLoanBalance.getString("putoutno");
			String businessType = rsLoanBalance.getString("businessType");
			double payinnerintefine = rsLoanBalance.getDouble("payinnerintefine");//���ڸ���
			double payoutintefine = rsLoanBalance.getDouble("payoutintefine");//���⸴��
			double allFineInte = payinnerintefine+payoutintefine;//ί�д����
			if(businessType.equalsIgnoreCase("1190010") || businessType.equalsIgnoreCase("1190030")){
				psUpdateLedgerGeneral.setDouble(1, allFineInte);
				psUpdateLedgerGeneral.setString(2, "70500501");
				psUpdateLedgerGeneral.setString(3, putoutno);
				psUpdateLedgerGeneral.addBatch();
				count++;
			}else{
				if(payinnerintefine>0){
					psUpdateLedgerGeneral.setDouble(1, payinnerintefine);
					psUpdateLedgerGeneral.setString(2, "70500201");
					psUpdateLedgerGeneral.setString(3, putoutno);
					psUpdateLedgerGeneral.addBatch();
					count++;
				}
				if(payoutintefine>0){
					psUpdateLedgerGeneral.setDouble(1, payoutintefine);
					psUpdateLedgerGeneral.setString(2, "70500301");
					psUpdateLedgerGeneral.setString(3, putoutno);
					psUpdateLedgerGeneral.addBatch();
					count++;
				}
				
			}
			if(count>=1000){
				psUpdateLedgerGeneral.executeBatch();
				allCount +=count;
				logger.info("�Ѿ����£�"+allCount+"��");
				count =0;
				
			}
		}
		psUpdateLedgerGeneral.executeBatch();
		allCount +=count;
		logger.info("�Ѿ����£�"+allCount+"��");
		allCount= 0;
		count = 0;
		rsLoanBalance.close();
		psLoanBalance.close();
		psUpdateLedgerGeneral.close();
	}

	//�������ñ�����
    private void UpdateLoanAndTrans() throws SQLException {
    	int i = 1;
    	String updateSql = " SELECT Itemdescribe FROM CODE_LIBRARY WHERE CODENO = 'BatchChangeSubjectNo'  AND Itemdescribe IS NOT NULL AND ISINUSE = '1' ORDER BY sortno";
    	PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
    	ResultSet rsUpdateSql = psUpdateSql.executeQuery();
    	while(rsUpdateSql.next()){
    		String sItemdescribe = rsUpdateSql.getString("Itemdescribe");
    		//logger.info("���µ�sql@:+"+i+"@:");
    		String[] sItemdescribeArry = sItemdescribe.split(";");
    		for(int k=0;k<sItemdescribeArry.length;k++){
    			i++;
    			logger.info("���µ�sql@:"+i+"@:"+sItemdescribeArry[k]);
    			Statement stmt=connection.createStatement();
				stmt.execute(sItemdescribeArry[k]);
				stmt.close();
    		}
    	}
    	rsUpdateSql.close();
    	psUpdateSql.close();
	}

	//��ʼ����ȥ������Ŀ���ͱ����ǰ�Ŀ�Ŀ	
	private void BatchChangeLedgerGeneral() throws Exception {
		String ledgerGeneral = " SELECT SubjectNo,SerialNo,DebitBalance FROM ledger_general where putoutno = ? AND subjectno  like '7%'  ORDER BY subjectno,putoutno ";
		PreparedStatement psLedgerGeneral = connection.prepareStatement(ledgerGeneral);
		//���·��˱�,���õĿ�Ŀ����Ϊ��
		String updateLedgerGeneral = " UPDATE ledger_general SET debitbalance = 0,creditbalance = 0 WHERE SerialNo = ?";
		PreparedStatement psUpdateLedgerGeneral = connection.prepareStatement(updateLedgerGeneral);
		
		//��ʼ�����˱�
		String insertledgerGeneralSql = "  INSERT INTO ledger_general (Putoutno,SubjectNo,OrgID,currency,creditbalance,debitbalance,accountno,serialno,direction)" +
										"  VALUES (?,?,?,?,?,?,?,?,?)";
		PreparedStatement psInsertledgerGeneralSql = connection.prepareStatement(insertledgerGeneralSql);
		
		//������ˮ
		String SqlInsertLedgerDetail = " Insert Into Ledger_Detail(SerialNo,PutOutNo,BillNo,TransID,SortID,OccurTime,"+
										" OccurDate,Currency,SubjectNo,CreditAmt,DebitAmt,HandStatus,OrgID) "+
										" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,? )";
		PreparedStatement psInsertLedgerDetail = connection.prepareStatement(SqlInsertLedgerDetail);
		
		//���д��Ҫ����(δ�����)
		String sqlLoanBalance = " SELECT putoutno,BusinessType,orgid,currency FROM loan_balance WHERE  loanstatus in('0','1','4','5')";
		PreparedStatement psLoanBalance = connection.prepareStatement(sqlLoanBalance);
		ResultSet rsLoanBalance = psLoanBalance.executeQuery();
		while(rsLoanBalance.next()){
			double inteFine = 0;//ǷϢ����,��Ҫ������ǷϢ�����ͱ���ǷϢ�����ϳ�һ��ֵ
			double badLoan = 0;//��������ǷϢ
			String putoutno = rsLoanBalance.getString("putoutno");
			String businessType = rsLoanBalance.getString("BusinessType");
			String currencyLB = rsLoanBalance.getString("currency");
			String orgidLB = rsLoanBalance.getString("orgid");
			
			//ί�д���,��Ҫ�������������Ŀ
			if(businessType.equals("1190010") || businessType.equals("1190030")){
				psLedgerGeneral.setString(1, putoutno);
				ResultSet rsLedgerGeneral = psLedgerGeneral.executeQuery();
				while(rsLedgerGeneral.next()){
					 
					String subjectNo = rsLedgerGeneral.getString("SubjectNo");
					
					
					//������Ϣ���ϲ���һ����Ŀ
					if("70500501".equals(subjectNo)){
						inteFine += rsLedgerGeneral.getDouble("DebitBalance");
						if(rsLedgerGeneral.getDouble("DebitBalance") > 0){
							String serialNo = rsLedgerGeneral.getString("SerialNo");
							psUpdateLedgerGeneral.setString(1, serialNo);
							psUpdateLedgerGeneral.addBatch();
						}
					}
				}
				rsLedgerGeneral.close();
				
				//�������˱�
				DealLedgerGeneral(psInsertledgerGeneralSql,inteFine,badLoan,putoutno,currencyLB,orgidLB,businessType);
				
			}else{
				psLedgerGeneral.setString(1, putoutno);
				ResultSet rsLedgerGeneral = psLedgerGeneral.executeQuery();
				while(rsLedgerGeneral.next()){
					String subjectNo = rsLedgerGeneral.getString("SubjectNo");
					//������Ϣ���ϲ���һ����Ŀ
					if("70500201".equals(subjectNo) || "70500301".equals(subjectNo)){
						inteFine += rsLedgerGeneral.getDouble("DebitBalance");
						if(rsLedgerGeneral.getDouble("DebitBalance") > 0){
							String serialNo = rsLedgerGeneral.getString("SerialNo");
							psUpdateLedgerGeneral.setString(1, serialNo);
							psUpdateLedgerGeneral.addBatch();
							
						}
					}
				}
				rsLedgerGeneral.close();
				//��ʼ�����˱�
				DealLedgerGeneral(psInsertledgerGeneralSql,inteFine,badLoan,putoutno,currencyLB,orgidLB,businessType);
			}
			
			
			if(count>=1000){
				allCount +=count;
				logger.info("�Ѿ����£�"+allCount+"��");
				count =0;
				psInsertledgerGeneralSql.executeBatch();
				psInsertLedgerDetail.executeBatch();
				psUpdateLedgerGeneral.executeBatch();
			}
		}
		allCount +=count;
		logger.info("�Ѿ����£�"+allCount+"��");
		count=0;
		psInsertledgerGeneralSql.executeBatch();
		psUpdateLedgerGeneral.executeBatch();
		psInsertLedgerDetail.executeBatch();
		rsLoanBalance.close();
		psLoanBalance.close();
		
		logger.info("��ʼ���½���Ĵ���~~~~~~~~~~~~");
		//���д��Ҫ����(�Ѿ������)
		String sqlLoanBalanceFinish = " SELECT putoutno,BusinessType,orgid,currency,loanstatus FROM loan_balance WHERE  loanstatus not in('0','1')";
		PreparedStatement psLoanBalanceFinish = connection.prepareStatement(sqlLoanBalanceFinish);
		ResultSet rsLoanBalanceFinish = psLoanBalanceFinish.executeQuery();
		while(rsLoanBalanceFinish.next()){
			double inteFine = 0;//ǷϢ����,��Ҫ������ǷϢ�����ͱ���ǷϢ�����ϳ�һ��ֵ
			double badLoan = 0;//��������ǷϢ
			String putoutno = rsLoanBalanceFinish.getString("putoutno");
			String businessType = rsLoanBalanceFinish.getString("BusinessType");
			String currencyLB = rsLoanBalanceFinish.getString("currency");
			String orgidLB = rsLoanBalanceFinish.getString("orgid");
			String loanstatus = rsLoanBalanceFinish.getString("loanstatus");
			
			if("60".equals(loanstatus)){
				psLedgerGeneral.setString(1, putoutno);
				ResultSet rsLedgerGeneral = psLedgerGeneral.executeQuery();
				while(rsLedgerGeneral.next()){
					String subjectNo = rsLedgerGeneral.getString("SubjectNo");
					
					String serialNo = rsLedgerGeneral.getString("SerialNo");
					//������������ǷϢ
					if("70900111".equalsIgnoreCase(subjectNo)){
						badLoan = rsLedgerGeneral.getDouble("DebitBalance");
						if(rsLedgerGeneral.getDouble("DebitBalance") > 0){
							psUpdateLedgerGeneral.setString(1, serialNo);
							psUpdateLedgerGeneral.addBatch();
						}
					}
				}
				rsLedgerGeneral.close();
				
			}
			//�������˱�
			DealLedgerGeneral(psInsertledgerGeneralSql,inteFine,badLoan,putoutno,currencyLB,orgidLB,businessType);
			count++;
			if(count>=1000){
				allCount +=count;
				logger.info("�Ѿ����£�"+allCount+"��");
				count =0;
				psInsertledgerGeneralSql.executeBatch();
				psInsertLedgerDetail.executeBatch();
				psUpdateLedgerGeneral.executeBatch();
			}
		}
		rsLoanBalanceFinish.close();
		psLoanBalanceFinish.close();
		psInsertledgerGeneralSql.executeBatch();
		psInsertLedgerDetail.executeBatch();
		psUpdateLedgerGeneral.executeBatch();
		psLedgerGeneral.close();
		psUpdateLedgerGeneral.close();
		psInsertLedgerDetail.close();
		psInsertledgerGeneralSql.close();
	}
	
	//����general��
	private void DealLedgerGeneral(PreparedStatement psInsertledgerGeneralSql,
			double inteFine, double badLoan, String putoutno,
			String currencyLB, String orgidLB,String businessType) throws Exception {
//		  INSERT INTO ledger_general (Putoutno,SubjectNo,OrgID,currency,creditbalance,debitbalance,accountno,serialno,direction)" +
//			"  VALUES (?,?,?,?,?,?,?,?,?)";
		//ǷϢ����
		if(businessType.equalsIgnoreCase("1190010") || businessType.equalsIgnoreCase("1190030")){
			psInsertledgerGeneralSql.setString(1, putoutno);
			psInsertledgerGeneralSql.setString(2, "70500109");
			psInsertledgerGeneralSql.setString(3, orgidLB);
			psInsertledgerGeneralSql.setString(4, currencyLB);
			psInsertledgerGeneralSql.setDouble(5, 0);
			psInsertledgerGeneralSql.setDouble(6, inteFine);
			psInsertledgerGeneralSql.setString(7, "65");
			psInsertledgerGeneralSql.setString(8, getAccountNo(connection));
			psInsertledgerGeneralSql.setString(9, "D");
			psInsertledgerGeneralSql.addBatch();
			count++;
		}else{
			psInsertledgerGeneralSql.setString(1, putoutno);
			psInsertledgerGeneralSql.setString(2, "70500102");
			psInsertledgerGeneralSql.setString(3, orgidLB);
			psInsertledgerGeneralSql.setString(4, currencyLB);
			psInsertledgerGeneralSql.setDouble(5, 0);
			psInsertledgerGeneralSql.setDouble(6, inteFine);
			psInsertledgerGeneralSql.setString(7, "64");
			psInsertledgerGeneralSql.setString(8, getAccountNo(connection));
			psInsertledgerGeneralSql.setString(9, "D");
			psInsertledgerGeneralSql.addBatch();
			count++;
		}
	
		
		//�Ѻ���������-����ǷϢ
		psInsertledgerGeneralSql.setString(1, putoutno);
		psInsertledgerGeneralSql.setString(2, "70900107");
		psInsertledgerGeneralSql.setString(3, orgidLB);
		psInsertledgerGeneralSql.setString(4, currencyLB);
		psInsertledgerGeneralSql.setDouble(5, 0);
		psInsertledgerGeneralSql.setDouble(6, badLoan);
		psInsertledgerGeneralSql.setString(7, "92");
		psInsertledgerGeneralSql.setString(8, getAccountNo(connection));
		psInsertledgerGeneralSql.setString(9, "D");
		psInsertledgerGeneralSql.addBatch();
		count++;
	}

	//����detail
	 private void DealLedgerDetail(PreparedStatement psInsertLedgerDetail,
			double amount,String putoutno,String currency,String subjectNo,String orgid,String changeSubjectNo,String type) throws Exception {
		 
		 //���˵��ճ�����Ŀ�����ǽ��յ����
		 if("OF".equalsIgnoreCase(type)){
//			 String SqlInsertLedgerDetail = " Insert Into Ledger_Detail(SerialNo,PutOutNo,BillNo,TransID,SortID,OccurTime,"+
//				" OccurDate,Currency,SubjectNo,CreditAmt,DebitAmt,HandStatus,OrgID) "+
//				" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,? )";
		 	iMaxLedgerNum +=1;
			String ldSerialNo1 = "ChS"+deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxLedgerNum,8,'0');
			psInsertLedgerDetail.setString(1, ldSerialNo1);
			psInsertLedgerDetail.setString(2, putoutno);
			psInsertLedgerDetail.setString(3, "");	
			psInsertLedgerDetail.setString(4, "");
			psInsertLedgerDetail.setString(5, "ChSubjectNo1");
			psInsertLedgerDetail.setString(6, DateTools.getDateTime(new Date(),"HH:mm:ss"));
			psInsertLedgerDetail.setString(7, deductDate);
			psInsertLedgerDetail.setString(8, currency);
			psInsertLedgerDetail.setString(9, subjectNo);
			psInsertLedgerDetail.setDouble(10, amount);
			psInsertLedgerDetail.setDouble(11, 0);
			psInsertLedgerDetail.setString(12, "2");
			psInsertLedgerDetail.setString(13, orgid);
			count++;
			psInsertLedgerDetail.addBatch();
			
			iMaxLedgerNum +=1;
			String ldSerialNo2 = "ChS"+deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxLedgerNum,8,'0');
			psInsertLedgerDetail.setString(1, ldSerialNo2);
			//psInsertLedgerDetail.setString(2, loanTransaction.getBizDocument().getAttributeStringValue("BillNo"));
			psInsertLedgerDetail.setString(2, putoutno);
			psInsertLedgerDetail.setString(3, "");	
			psInsertLedgerDetail.setString(4, "");
			psInsertLedgerDetail.setString(5, "ChSubjectNo2");
			psInsertLedgerDetail.setString(6, DateTools.getDateTime(new Date(),"HH:mm:ss"));
			psInsertLedgerDetail.setString(7, deductDate);
			psInsertLedgerDetail.setString(8, currency);
			psInsertLedgerDetail.setString(9, changeSubjectNo);
			psInsertLedgerDetail.setDouble(10, 0);
			psInsertLedgerDetail.setDouble(11, amount);
			psInsertLedgerDetail.setString(12, "2");
			psInsertLedgerDetail.setString(13, orgid);
			count++;
			psInsertLedgerDetail.addBatch();
			
		 }else{
			 //һ���������ݣ�һ���ǳ���ǰ�ģ�һ���Ǽǽ����
		 	iMaxLedgerNum +=1;
			String ldSerialNo1 = "ChS"+deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxLedgerNum,8,'0');
			psInsertLedgerDetail.setString(1, ldSerialNo1);
			//psInsertLedgerDetail.setString(2, loanTransaction.getBizDocument().getAttributeStringValue("BillNo"));
			psInsertLedgerDetail.setString(2, putoutno);
			psInsertLedgerDetail.setString(3, "");	
			psInsertLedgerDetail.setString(4, "");
			psInsertLedgerDetail.setString(5, "ChSubjectNo1");
			psInsertLedgerDetail.setString(6, DateTools.getDateTime(new Date(),"HH:mm:ss"));
			psInsertLedgerDetail.setString(7, deductDate);
			psInsertLedgerDetail.setString(8, currency);
			psInsertLedgerDetail.setString(9, subjectNo);
			psInsertLedgerDetail.setDouble(10, amount);
			psInsertLedgerDetail.setDouble(11, 0);
			psInsertLedgerDetail.setString(12, "2");
			psInsertLedgerDetail.setString(13, orgid);
			count++;
			psInsertLedgerDetail.addBatch();
			
			
			iMaxLedgerNum +=1;
			String ldSerialNo2 = "ChS"+deductDate.replaceAll("/", "") + NumberTools.lPad(iMaxLedgerNum,8,'0');
			psInsertLedgerDetail.setString(1, ldSerialNo2);
			//psInsertLedgerDetail.setString(2, loanTransaction.getBizDocument().getAttributeStringValue("BillNo"));
			psInsertLedgerDetail.setString(2, putoutno);
			psInsertLedgerDetail.setString(3, "");	
			psInsertLedgerDetail.setString(4, "");
			psInsertLedgerDetail.setString(5, "ChSubjectNo2");
			psInsertLedgerDetail.setString(6, DateTools.getDateTime(new Date(),"HH:mm:ss"));
			psInsertLedgerDetail.setString(7, deductDate);
			psInsertLedgerDetail.setString(8, currency);
			psInsertLedgerDetail.setString(9, changeSubjectNo);
			psInsertLedgerDetail.setDouble(10, 0);
			psInsertLedgerDetail.setDouble(11, amount);
			psInsertLedgerDetail.setString(12, "2");
			psInsertLedgerDetail.setString(13, orgid);
			count++;
			psInsertLedgerDetail.addBatch();
		 }
		
		
	}

	private String getAccountNo(Connection conn) throws Exception{
	      // String accountNo=subjectno+OrgID+ObjectType+ObjectNo;
	    	   String serialNo = com.amarsoft.account.util.StringTools.getSequence(conn,"SEQ_CLEAN");
	    	  // transAction.disConnect();
	           return serialNo;
	    }
	 
	//�ҳ�������ˮ
		public void initSerialCount(String deductDate,Connection conn) throws Exception
		{
			iMaxLedgerNum = NumberTools.getMaxNo("Ledger_Detail", "SerialNo", "ChS"+deductDate.replaceAll("/", ""), 8, conn);
			iMaxBCLNum = NumberTools.getMaxNo("business_change_log", "SerialNo", "ChSub"+deductDate.replaceAll("/", ""), 8, conn);
			
		}
}
