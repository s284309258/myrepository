package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class InnerCheckHinder extends CommonExecuteUnit{
  
  private int dealnum;
  private int icount;
  private int commitNum;
  
  public int execute() {
    
    try{
      String sInit = super.init();
      if(sInit.equalsIgnoreCase("skip"))
      {
        return TaskConstants.ES_SUCCESSFUL;
      }
      else
      {  
        commitNum=Integer.parseInt(getProperty("commitNum", "1"));
        logger.info("��ʼ��� Hinder_Error��Error_LBHinder....");
        Statement stmt=connection.createStatement();
        stmt.execute("call dbmgr.truncate_table ('RCPMDATA','Hinder_Error') ");
        stmt.execute("call dbmgr.truncate_table ('RCPMDATA','Error_LBHinder') ");
        stmt.close();
        logger.info("��� Hinder_Error��Error_LBHinder��ɣ�");
        
        logger.info("��ʼ��֤���ֻ�����Ƿ����.......");
        checkLedgerEven();
        logger.info("��֤���ֻ�����Ƿ������ɣ�");
        
        logger.info("��ʼ�ֶܷ���......");
        CheckHinder();
        logger.info("�ֶܷ�����ɣ�");

        
        /*logger.info("��¼����laon_balance����......");
        CheckLBHinder();
        logger.info("��¼����laon_balance�������");*/
        unitStatus= TaskConstants.ES_SUCCESSFUL;
        
        clearResource();
        return unitStatus;
      }
    }catch(Exception ex){
      logger.error(ex);
      ex.printStackTrace();
      unitStatus= TaskConstants.ES_FAILED;
      
      clearResource();
      return unitStatus;
    } 
  }
  
  
  /*
   * �ֶܷ���
   * */
  public void CheckHinder() throws SQLException, LoanException
  {
    String insertSql =" Insert Into Hinder_Error(SubjectNo,LGDebit,LGCredit,SBDebit,SBCredit,InputDate,OrgID,Currency) values(?,?,?,?,?,?,?,?)";
    PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
    String tempSql = " select DebitBalance,creditbalance from subject_balance where SubjectNo = ? and occurdate = ? and orgid = ? and currency = ?";
    PreparedStatement psTempSql=connection.prepareStatement(tempSql);
    
    String selectSql = "select lg.Subjectno,sum(lg.DebitBalance) as LGDebit,sum(lg.CreditBalance) as LGCredit,lg.Orgid,lg.Currency "
             + " from ledger_general lg "
             + " group by lg.Subjectno,lg.Orgid,lg.Currency ";
    PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
    ResultSet rs = psSelectSql.executeQuery();
    while(rs.next())
    {
      String sSubjectNo = rs.getString("Subjectno");
      if("6080201".equals(sSubjectNo)||"6080202".equals(sSubjectNo)) continue;
      double dLGDebit = rs.getDouble("LGDebit");
      double dLGCredit = rs.getDouble("LGCredit");
      
      psTempSql.setString(1,sSubjectNo);
      psTempSql.setString(2,deductDate);
      psTempSql.setString(3,rs.getString("Orgid"));
      psTempSql.setString(4,rs.getString("Currency"));
      
      ResultSet rsTemp = psTempSql.executeQuery();
      if(rsTemp.next())
      {
        double dSBDebit = rsTemp.getDouble("DebitBalance");
        double dSBCredit = rsTemp.getDouble("creditbalance");
        
        boolean bb = false;
        //�ж����˷����Ƿ�ƽ��
        String sLoanWay =LedgerSubjectConfig.getSubjectLoanWay(rs.getString("SubjectNo"));
        if(sLoanWay.equalsIgnoreCase("B"))
        {
          if(NumberTools.round(Math.abs(dSBDebit-dSBCredit),2)==NumberTools.round(Math.abs(dLGDebit-dLGCredit),2))
              bb=true;
          else
            bb=false;
        }
        else
        {
          if(NumberTools.round(dLGDebit-dLGCredit,2)-NumberTools.round(dSBDebit-dSBCredit,2)<0.01)
            bb=true;
          else
            bb=false;
        }
        
        
        if(!bb)
        {
          psInsertSql.setString(1,sSubjectNo);
          psInsertSql.setDouble(2,dLGDebit);
          psInsertSql.setDouble(3,dLGCredit);
          psInsertSql.setDouble(4,dSBDebit);
          psInsertSql.setDouble(5,dSBCredit);
          psInsertSql.setString(6,deductDate);
          psInsertSql.setString(7,rs.getString("Orgid"));
          psInsertSql.setString(8,rs.getString("Currency"));
          psInsertSql.addBatch();
        }
      }  
      rsTemp.close();
    }
    psInsertSql.executeBatch();
    rs.close();
    psTempSql.close();
    psSelectSql.close();
    psInsertSql.close();
    
  }

  /*
   * ��ʾû�н����ֶܷ��˵Ŀ�Ŀ��
   * */
  public void ViewNotCheckSubjectNo() throws SQLException
  {
    String selectSql = " select Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,Occurdate " +
        " from subject_balance " +
        " where SubjectNo not in (select SubjectNo from ledger_general) ";
    PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
    ResultSet rs = psSelectSql.executeQuery();
    while(rs.next())
    {
      String sView = "����Ϊ����"+rs.getString("Currency")+"��  �������Ϊ����"+rs.getString("OrgID")+"��  ��Ŀ��Ϊ����"+rs.getString("SubjectNo")
        + "��  �跽���շ�������"+rs.getDouble("DebitBalance")+"��  ����������������"+rs.getDouble("CreditBalance")+"��  ����Ϊ:��"+rs.getString("Occurdate")+"��";
      
      logger.info(sView);
    }
    rs.close();
  }
  
  /*
   * ����Ƿ�ƽ����
   * */
  public void checkLedgerEven() throws SQLException
  {
    String insertSql =" Insert Into Error_LBHinder(PutOutNo,ErrorType,DeductDate) values(?,?,?)";
    PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
    
    String selectSql = " select OrgID,sum(CreditBalance) as CreditAmt,sum(DebitBalance) as DeditAmt "
             + " from ledger_general where (SubjectNo not like '7%' and SubjectNo not like '6%') group by OrgID  ";
    PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
    ResultSet rs = psSelectSql.executeQuery();
    while(rs.next())
    {
      double dCreditAmout = rs.getDouble("CreditAmt");
      double dDeditAmt = rs.getDouble("DeditAmt");
      if(dCreditAmout != dDeditAmt)
      {
        psInsertSql.setString(1,rs.getString("OrgID"));
        psInsertSql.setString(2,"LedgerNotEven");
        psInsertSql.setString(3,deductDate);
        psInsertSql.addBatch();
        dealnum++;
        icount++;
      }
      
      if(dealnum>=commitNum)
      {
        psInsertSql.executeBatch();
        dealnum=0;
      }
    }
    psInsertSql.executeBatch();
    rs.close();
    psInsertSql.close();
  }
  
  /*
   * ��loan_balance����
   * */
  public void CheckLBHinder() throws SQLException
  {
      String insertSql =" Insert Into Error_LBHinder(PutOutNo,ErrorType,DeductDate) values(?,?,?)";
      PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
    
    String selectSql =" select PutOutNo,(NormalBalance+DefaultBalance+OverDueBalance) as Corp, "
             +" (PayInte+PayInnerInte+PayOutInte+PayInnerInteFine+PayOutInteFine) as Inte, "
             +" PeriodInte,PayInte"
             +" from  loan_balance "
             +" where LoanStatus in ('0','1','4','5') ";
    PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
    ResultSet rs = psSelectSql.executeQuery();
    while(rs.next())
    {
      double lgCorp = 0.0;
      double lgInte = 0.0;
      double lgPeriodInte = 0.0;
      double lgPayInte = 0.0;
      
      String sqlTemp =" select substr(SubjectNo,1,4) as SubjectNo,sum(DebitBalance) as SumDebitBalance,sum(CreditBalance) as SumCreditBalance "
                   +" from ledger_general "
                   +" where PutOutNo = '"+rs.getString("PutOutNo")+"' "
                   +" group by substr(SubjectNo,1,4) ";
      PreparedStatement psSqlTemp = connection.prepareStatement(sqlTemp);
      ResultSet rsTemp = psSqlTemp.executeQuery();
      while(rsTemp.next())
      {
        if(rsTemp.getString("SubjectNo").equals("1201"))
          lgCorp += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
        else if(rsTemp.getString("SubjectNo").equals("1202"))
          lgCorp += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
        else if(rsTemp.getString("SubjectNo").equals("1281"))
          lgCorp += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
        else if(rsTemp.getString("SubjectNo").equals("1321"))
          lgPeriodInte += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
        else if(rsTemp.getString("SubjectNo").equals("1322"))
          lgPayInte += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
        else if(rsTemp.getString("SubjectNo").equals("7050"))
          lgInte += rsTemp.getDouble("SumDebitBalance")-rsTemp.getDouble("SumCreditBalance");
      }
      rsTemp.getStatement().close();
      psSqlTemp.close();
      //�����ʲ�ƽ
      if(lgCorp==rs.getDouble("Corp"))
      {
        psInsertSql.setString(1,rs.getString("PutOutNo"));
        psInsertSql.setString(2,"Corp");
        psInsertSql.setString(3,deductDate);
        psInsertSql.addBatch();
      }
      //��Ϣ�ʲ�ƽ
      if(lgInte==rs.getDouble("Inte"))
      {
        psInsertSql.setString(1,rs.getString("PutOutNo"));
        psInsertSql.setString(2,"Inte");
        psInsertSql.setString(3,deductDate);
        psInsertSql.addBatch();
      }
      //����Ϣ�ʲ�ƽ
      if(lgPeriodInte==rs.getDouble("PeriodInte"))
      {
        psInsertSql.setString(1,rs.getString("PutOutNo"));
        psInsertSql.setString(2,"PeriodInte");
        psInsertSql.setString(3,deductDate);
        psInsertSql.addBatch();
      }
      //Ӧ����Ϣ�ʲ�ƽ
      if(lgPayInte==rs.getDouble("PayInte"))
      {
        psInsertSql.setString(1,rs.getString("PutOutNo"));
        psInsertSql.setString(2,"PayInte");
        psInsertSql.setString(3,deductDate);
        psInsertSql.addBatch();
      }
    }
    if(psInsertSql!=null) psInsertSql.executeBatch();
    rs.getStatement().close();
    psInsertSql.close();
    psSelectSql.close();
  }
  
}
