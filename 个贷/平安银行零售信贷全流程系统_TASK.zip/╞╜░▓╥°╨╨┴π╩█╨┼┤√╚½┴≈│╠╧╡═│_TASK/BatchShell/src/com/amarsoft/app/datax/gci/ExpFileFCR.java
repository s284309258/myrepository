package com.amarsoft.app.datax.gci;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;


/**                                                                                                                             
 * ��FCR�����������ļ�                                                                                                                    
 * WANGWEIXING492                                                                                                               
 *                                                                                                                              
 */
public class ExpFileFCR extends CommonExecuteUnit {

	private String sql;
	private String fileName; //�ļ�����                                                                          
	private PrintWriter outputstreamwriter;
	private String separator;
	private String NASUrl;
	private String fileUrl;
	private String fileType; //�ļ�����   
	private String sDate;
	//�����ļ����ʹ���
	private String sFileCount01="";
	//���ҽ��ļ����ʹ���
	private String sFileCount02="";

	public void exportResultSet(String sql, TableMetaData tableMetaData,
			PrintWriter outputstreamwriter) throws Exception {
		separator = this.getProperty("separator");
		Statement stm = connection.createStatement();
		ResultSet rs = stm.executeQuery(sql);
		
		while (rs.next()) {
			String s = "";
			int lineNum = 0;
			
			for (int i = 1; i <= tableMetaData.getColumnCount(); i++) {
				
				lineNum++;
				ColumnMetaData columnMetaData = tableMetaData.getColumn(i);
				String columnName = columnMetaData.getName();
				String rsString = rs.getString(columnName);
				if (rsString == null || "".equals(rsString))
					rsString = "";  
				rsString = rsString.replaceAll("\n", "");
				rsString = rsString.replaceAll("\t", "");
				rsString = rsString.trim();
				if(lineNum == 1){
					s = rsString;
				}else{
					s = s.concat(separator).concat(rsString);			
				}				

			}
			s += "\r\n";
			outputstreamwriter.write(s);

		}
		rs.close();
		stm.close();
	}

	@SuppressWarnings("finally")
	public int execute() {
		try {
			String sInit = super.init();      
			if (sInit.equalsIgnoreCase("skip")) {
				unitStatus = TaskConstants.ES_SUCCESSFUL;
			} else {
				initPara();
				/*�ж��ļ����ͣ��ļ��Ƿ�Ϊ���ҽ��ļ���BIFMFBAJUP��*/
				if (!isTodayEx(fileType)) {
					unitStatus = TaskConstants.ES_SUCCESSFUL;
				} else {
					/*ƴ�ӱ����ļ�·��*/
					fileUrl = NASUrl + fileUrl;
					File file = new File(fileUrl);
					if (!file.exists()) {
						file.mkdirs();
					}
					/*ƴ�ӱ����ļ�·�����ļ���*/
					fileName = fileUrl + fileName;
					System.out.println("recordeSet:"
							+ this.getProperty("unit.recordSet1"));
					outputstreamwriter = new PrintWriter(new BufferedWriter(
							new OutputStreamWriter(new FileOutputStream(
									fileName), "UTF-8")), true);
					String fileSerialNo = ESBTransaction
							.getBZSerialNo(connection);//�ļ���ˮ                                             

					for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty(
							"unit.recordSet" + i).trim().equals("")); i++) {

						sql = this.getProperty("unit.recordSet" + i);
						sql = StringFunction.replace(sql, "{$CurrentDate}",
								sDate);
						sql = StringFunction.replace(sql, "{$FileSerialNo}",
								fileSerialNo);
						sql = StringFunction.replace(sql, "{$branchID}",
								OCIConfig.getBranchID());
						sql = StringFunction
								.replace(sql, "{$userID}", OCIConfig
										.getUserID()
										+ OCIConfig.getBranchID());
						
						sql=StringFunction.replace(sql,"{$CurrentDateNoSplit}", StringFunction.replace(deductDate, "/",""));
						sql=StringFunction.replace(sql,"{$CalcDate}", deductDate);
						String[] s = sql.split(":");
						sql = sql.substring(sql.indexOf(s[1]) + s[1].length()
								+ 1);
						logger.info("��ǰ������sql=" + sql);
						exportResultSet(sql, ARE.getMetaData(s[0]).getTable(
								s[1]), outputstreamwriter);
					}

					outputstreamwriter.close();

					unitStatus = TaskConstants.ES_SUCCESSFUL;
				}
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
		} finally {
			clearResource();
			return unitStatus;
		}
	}

	private boolean isTodayEx(String sfileType) {
		if (sfileType.equalsIgnoreCase("BIFMFBAJUP")) {
			return true;
		} else
			return true;
	}
	
	public void initPara() throws Exception{
		sDate = StringFunction.replace(deductDate, "/", "");
		NASUrl = ARE.getProperty("NASUrl");
		fileUrl = this.getProperty("unit.fileUrl");
		fileUrl = StringFunction.replace(fileUrl, "{$CurrentDate}",sDate);
		fileType = this.getProperty("FileType", "");
		if (!"BIFMFBATUP".equals(fileType) && !"BIFMFBAJUP".equals(fileType)) {
			throw new Exception("fileType���岻��ȷ��");
		}
		fileName = this.getProperty("unit.fileName");
		fileName = StringFunction.replace(fileName,"{$SixCurrentDate}", sDate.substring(2, 8));
		
		String selectSql = "";
		selectSql = "select cl.attribute4,cl.attribute7 from code_library cl where codeno = 'DownloadFileFromFCR' and itemno = '001'";
		PreparedStatement psQuery = connection.prepareStatement(selectSql);
		ResultSet rs = psQuery.executeQuery();
		if (rs.next()) {
			sFileCount01 = rs.getString("attribute4").trim();
			sFileCount02 = rs.getString("attribute7").trim();
		}else{
			rs.close();
			psQuery.close();
			throw new Exception("�ļ����ʹ�����ѯʧ�ܣ�");
		}
		rs.close();
		psQuery.close();
		if("BIFMFBATUP".equals(fileType)){
			fileName = StringFunction.replace(fileName,"{$FileCount}",sFileCount01);
		}else{
			fileName = StringFunction.replace(fileName,"{$FileCount}",sFileCount02);
		}
		
	}

}