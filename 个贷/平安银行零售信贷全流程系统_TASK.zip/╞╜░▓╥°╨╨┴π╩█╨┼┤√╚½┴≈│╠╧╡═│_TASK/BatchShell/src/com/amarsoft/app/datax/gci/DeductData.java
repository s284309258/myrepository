package com.amarsoft.app.datax.gci;

public class DeductData {
	
	private String PutOutNo;         
	private int STerm;
	private int AheadNum=0;			
	private String Currency;          
	private double PayCurrentCorp=0;
	private double ActualCurrentCorp=0;
	private double PayDefaultCorp=0;
	private double ActualDefaultCorp=0;
	private double PayOverDueCorp=0;
	private double ActualOverDueCorp=0;
	private double PayInte=0;
	private double ActualInte=0;
	private double PayInnerInte=0;
	private double ActualInnerInte=0;
	private double PayOutInte=0;
	private double ActualOutInte=0;
	private double PayInnerInteFine=0;     
	private double ActualInnerInteFine=0; 
	private double PayOutInteFine=0;   
	private double ActualOutInteFine=0;
	private String AccountFlag;
	private String RelativeAccNo;
	private String PayDate;
	private String DeductAccNo;
	private String DeductAccNo1;
	private String DeductAccNo2;
	private String FDSerialNo;//������ˮ��
	private String FeeType;//��������
	private double PayMoney;//����Ӧ��
	private double ActualMoney;//����ʵ��
	private double Balance;//ʣ����
	private double ActualAmount1;
	private double ActualAmount2;
	private double ActualAmount3;
	
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public int getSTerm() {
		return STerm;
	}
	public void setSTerm(int term) {
		STerm = term;
	}
	public int getAheadNum() {
		return AheadNum;
	}
	public void setAheadNum(int aheadNum) {
		AheadNum = aheadNum;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public double getPayCurrentCorp() {
		return PayCurrentCorp;
	}
	public void setPayCurrentCorp(double payCurrentCorp) {
		PayCurrentCorp = payCurrentCorp;
	}
	public double getActualCurrentCorp() {
		return ActualCurrentCorp;
	}
	public void setActualCurrentCorp(double actualCurrentCorp) {
		ActualCurrentCorp = actualCurrentCorp;
	}
	public double getPayDefaultCorp() {
		return PayDefaultCorp;
	}
	public void setPayDefaultCorp(double payDefaultCorp) {
		PayDefaultCorp = payDefaultCorp;
	}
	public double getActualDefaultCorp() {
		return ActualDefaultCorp;
	}
	public void setActualDefaultCorp(double actualDefaultCorp) {
		ActualDefaultCorp = actualDefaultCorp;
	}
	public double getPayOverDueCorp() {
		return PayOverDueCorp;
	}
	public void setPayOverDueCorp(double payOverDueCorp) {
		PayOverDueCorp = payOverDueCorp;
	}
	public double getActualOverDueCorp() {
		return ActualOverDueCorp;
	}
	public void setActualOverDueCorp(double actualOverDueCorp) {
		ActualOverDueCorp = actualOverDueCorp;
	}
	public double getPayInte() {
		return PayInte;
	}
	public void setPayInte(double payInte) {
		PayInte = payInte;
	}
	public double getActualInte() {
		return ActualInte;
	}
	public void setActualInte(double actualInte) {
		ActualInte = actualInte;
	}
	public double getPayInnerInte() {
		return PayInnerInte;
	}
	public void setPayInnerInte(double payInnerInte) {
		PayInnerInte = payInnerInte;
	}
	public double getActualInnerInte() {
		return ActualInnerInte;
	}
	public void setActualInnerInte(double actualInnerInte) {
		ActualInnerInte = actualInnerInte;
	}
	public double getPayOutInte() {
		return PayOutInte;
	}
	public void setPayOutInte(double payOutInte) {
		PayOutInte = payOutInte;
	}
	public double getActualOutInte() {
		return ActualOutInte;
	}
	public void setActualOutInte(double actualOutInte) {
		ActualOutInte = actualOutInte;
	}
	public double getPayInnerInteFine() {
		return PayInnerInteFine;
	}
	public void setPayInnerInteFine(double payInnerInteFine) {
		PayInnerInteFine = payInnerInteFine;
	}
	public double getActualInnerInteFine() {
		return ActualInnerInteFine;
	}
	public void setActualInnerInteFine(double actualInnerInteFine) {
		ActualInnerInteFine = actualInnerInteFine;
	}
	public double getPayOutInteFine() {
		return PayOutInteFine;
	}
	public void setPayOutInteFine(double payOutInteFine) {
		PayOutInteFine = payOutInteFine;
	}
	public double getActualOutInteFine() {
		return ActualOutInteFine;
	}
	public void setActualOutInteFine(double actualOutInteFine) {
		ActualOutInteFine = actualOutInteFine;
	}
	public String getPayDate() {
		return PayDate;
	}
	public void setPayDate(String payDate) {
		PayDate = payDate;
	}
	public String getDeductAccNo() {
		return DeductAccNo;
	}
	public void setDeductAccNo(String deductAccNo) {
		DeductAccNo = deductAccNo;
	}
	public String getDeductAccNo1() {
		return DeductAccNo1;
	}
	public void setDeductAccNo1(String deductAccNo1) {
		DeductAccNo1 = deductAccNo1;
	}
	public String getDeductAccNo2() {
		return DeductAccNo2;
	}
	public void setDeductAccNo2(String deductAccNo2) {
		DeductAccNo2 = deductAccNo2;
	}
	public String getAccountFlag() {
		return AccountFlag;
	}
	public void setAccountFlag(String accountFlag) {
		AccountFlag = accountFlag;
	}
	public String getRelativeAccNo() {
		return RelativeAccNo;
	}
	public void setRelativeAccNo(String relativeAccNo) {
		RelativeAccNo = relativeAccNo;
	}
	public String getFDSerialNo() {
		return FDSerialNo;
	}
	public void setFDSerialNo(String serialNo) {
		FDSerialNo = serialNo;
	}
	public String getFeeType() {
		return FeeType;
	}
	public void setFeeType(String feeType) {
		FeeType = feeType;
	}
	public double getPayMoney() {
		return PayMoney;
	}
	public void setPayMoney(double payMoney) {
		PayMoney = payMoney;
	}
	public double getActualMoney() {
		return ActualMoney;
	}
	public void setActualMoney(double actualMoney) {
		ActualMoney = actualMoney;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double getActualAmount1() {
		return ActualAmount1;
	}
	public void setActualAmount1(double actualAmount1) {
		ActualAmount1 = actualAmount1;
	}
	public double getActualAmount2() {
		return ActualAmount2;
	}
	public void setActualAmount2(double actualAmount2) {
		ActualAmount2 = actualAmount2;
	}
	public double getActualAmount3() {
		return ActualAmount3;
	}
	public void setActualAmount3(double actualAmount3) {
		ActualAmount3 = actualAmount3;
	}   	   
	
	
}
