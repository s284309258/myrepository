package com.amarsoft.app.datax.gci.gjj;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

/**
 * ����Down�ļ����ݺ�loan_balance����BtoX����
 * @author XIATIAN020
 * @since 2012-06-06
 */

public class SplitDownFileHAFData extends CommonExecuteUnit{
	
		private int commitNum ;
		private int dealNum = 0;
		private int icount = 0;
		
		public int execute() {
				
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{	
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					logger.info("����BtoC��BtoB��BtoC_TMP���ݿ�ʼ......");
					initData();
					logger.info("����BtoC��BtoB��BtoC_TMP���ݽ���......");
					logger.info("����BtoC��BtoB��BtoC_TMP���ݿ�ʼ......");
					createData();
					logger.info("����BtoC��BtoB��BtoC_TMP������ɣ�");
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}
		
		public void initData() throws Exception {
			String deleteSqlBtoC = " delete from GJJ_BTOC where InputDate = ? ";
			String deleteSqlBtoB = " delete from GJJ_BTOB where InputDate = ? ";
			String deleteSqlBtoC_Tmp = " delete from GJJ_BTOC_TMP where InputDate = ? ";
			PreparedStatement psDeleteSqlBtoC = null,psDeleteSqlBtoB = null,psDeleteSqlBtoC_Tmp = null;
			try
			{
				psDeleteSqlBtoC = connection.prepareStatement(deleteSqlBtoC);
				psDeleteSqlBtoC.setString(1, this.deductDate);
				psDeleteSqlBtoC.execute();
				psDeleteSqlBtoB = connection.prepareStatement(deleteSqlBtoB);
				psDeleteSqlBtoB.setString(1, this.deductDate);
				psDeleteSqlBtoB.execute();
				psDeleteSqlBtoC_Tmp = connection.prepareStatement(deleteSqlBtoC_Tmp);
				psDeleteSqlBtoC_Tmp.setString(1, this.deductDate);
				psDeleteSqlBtoC_Tmp.execute();
			}catch(Exception ex)
			{
				ex.printStackTrace();
				throw ex;
			}
			finally
			{
				if(psDeleteSqlBtoC!=null) psDeleteSqlBtoC.close();
				if(psDeleteSqlBtoB!=null) psDeleteSqlBtoB.close();
				if(psDeleteSqlBtoC_Tmp!=null) psDeleteSqlBtoC_Tmp.close();
			}
		}

		public void createData() throws Exception {

			String insertSqlBtoC = " insert into GJJ_BTOC(bankcode,loanno,idcard,loanbalance,payamt," +
					" paycorpus,payinte,payfineinte,inputdate,deducttype,loantype)" +
					" values (?,?,?,?,?,?,?,?,?,?,?) ";
			String insertSqlBtoB = " insert into GJJ_BTOB(loanno,customername,contractno,accountno,inputdate) values(?,?,?,?,?) ";
			String insertSqlBtoC_Tmp = "insert into GJJ_BTOC_TMP(bankcode,loanno,idcard,inputdate,deducttype,loantype) (select bankcode,loanno,idcard,inputdate,deducttype,loantype from GJJ_DOWN where inputdate = ? and not exists(select 'X' from GJJ_BTOC where loanNo = GJJ_DOWN.LoanNo and inputdate = ?) ) ";
			String updateSqlRushpayFlag = "update LOAN_BALANCE set RUSHPAYFLAG = '1' where PutOutNo = ?";
			String selectSqlBtoC = " select GD.BankCode,GD.LoanNo,GD.IdCard,(LB.NormalBalance+LB.OverdueBalance) as LoanBalance," +
									" LB.PutOutNo,GD.INPUTDATE,GD.DEDUCTTYPE,GD.LOANTYPE,LB.CustomerName,LB.ContractSerialNo,LB.LoanAccNo " +
									" from LOAN_BALANCE LB,GJJ_DOWN GD " +
									" where getLoanNo(LB.PutOutNo) = getGJJLoanNo(GD.LoanNo,'1') and GD.InputDate = ? " +
									" union all" +
									" select GD.BankCode,GD.LoanNo,GD.IdCard,(LB.NormalBalance+LB.OverdueBalance) as LoanBalance," +
									" LB.PutOutNo,GD.INPUTDATE,GD.DEDUCTTYPE,GD.LOANTYPE,LB.CustomerName,LB.ContractSerialNo,LB.LoanAccNo " +
									" from LOAN_BALANCE LB,GJJ_DOWN GD " +
									" where getLoanNo(LB.PutOutNo) = getGJJLoanNo(GD.LoanNo,'2') and GD.InputDate = ? ";
			String selectSqlLoanBack = "select sum(ls.PayCurrentCorp+ls.PayDefaultCorp+ls.PayOverDueCorp-ls.ActualCurrentCorp-ls.ActualDefaultCorp-ls.ActualOverdueCorp) as PayCorpus," +
										" sum(ls.PayInte+ls.PayInnerInte+ls.PayOutInte-ls.ActualInte-ls.ActualInnerInte-ls.ActualOutInte) as PayInte," +
										" sum(ls.PAYOVERDUECORPINTE) - sum(nvl((select sum(nvl(BACK_BILL.Actualintefine, 0.0)) from BACK_BILL where putoutno = ls.putoutno and aheadnum = ls.aheadnum and sterm = ls.sterm  and BillType in('20','22') and BillStatus = '1' ),0.0)) as PayOverFineInte ," +
										" sum(ls.PayInnerInteFine+ls.PayOutInteFine-ls.ActualInnerInteFine-ls.ActualOutInteFine) as PayFineInte" +
										" from loanback_status ls where putoutno = ? and paydate <=  ? and ls.payoffflag = '"+BatchConstant.PAYOFFFLAG_FALSE+"' ";
			String selectSqlRepayPlan = "select sum(RepayCorpus) as Corpus,(sum(RepayInterest)+sum(FareAmount)) as Inte from REPAY_PLAN where PutOutNo = ? and RepayDate <= ? and RepayDate > ?";
			PreparedStatement psInsertSqlBtoC = null,psInsertSqlBtoB = null,psInsertSqlBtoC_Tmp = null,psSelectSqlBtoC = null,psSelectSqlLoanBack = null,psUpdateSqlRushpayFlag = null,psSelectSqlRepayPlan = null;
			
			
			try
			{
				psInsertSqlBtoC = connection.prepareStatement(insertSqlBtoC);
				psInsertSqlBtoB = connection.prepareStatement(insertSqlBtoB);
				psInsertSqlBtoC_Tmp = connection.prepareStatement(insertSqlBtoC_Tmp);
				psSelectSqlBtoC = connection.prepareStatement(selectSqlBtoC); 
				psSelectSqlLoanBack = connection.prepareStatement(selectSqlLoanBack); 
				psUpdateSqlRushpayFlag = connection.prepareStatement(updateSqlRushpayFlag);
				psSelectSqlRepayPlan = connection.prepareStatement(selectSqlRepayPlan); 
				
				psSelectSqlBtoC.setString(1, this.deductDate);
				psSelectSqlBtoC.setString(2, this.deductDate);
				ResultSet rsBtoC = psSelectSqlBtoC.executeQuery();
				while(rsBtoC.next())
				{
					String endMonthDate = DateTools.getEndDateOfMonth(this.deductDate);
					
					String bankCode = rsBtoC.getString("BankCode");
					String loanNo = rsBtoC.getString("LoanNo");
					String idCard = rsBtoC.getString("IdCard");
					double loanBalance = rsBtoC.getDouble("LoanBalance");
					String putoutNo = rsBtoC.getString("PutOutNo");
					String inputDate = rsBtoC.getString("INPUTDATE");
					String deductType = rsBtoC.getString("DEDUCTTYPE");
					String loanType = rsBtoC.getString("LOANTYPE");
					String customerName = rsBtoC.getString("CustomerName");
					String contractNo = rsBtoC.getString("ContractSerialNo");
					String accountNo = rsBtoC.getString("LoanAccNo");
					
					psSelectSqlLoanBack.setString(1, putoutNo);
					psSelectSqlLoanBack.setString(2, this.deductDate);
					ResultSet rsLoanBack = psSelectSqlLoanBack.executeQuery();
					double payCorpus=0.0d,payInte=0.0d,payFineInte=0.0d,payOverFineInte = 0.0d;
					if(rsLoanBack.next())
					{
						payCorpus = rsLoanBack.getDouble("PayCorpus");
						payInte = rsLoanBack.getDouble("PayInte");
						payFineInte = rsLoanBack.getDouble("PayFineInte");
						payOverFineInte = rsLoanBack.getDouble("PayOverFineInte");
						if(payOverFineInte > payInte)
						{
							payFineInte = payFineInte + payInte;
							payInte = 0;
						}
						else
						{
							payInte = payInte - payOverFineInte;
							payFineInte = payFineInte + payOverFineInte;
						}
					}
					rsLoanBack.close();
					
					
					psSelectSqlRepayPlan.setString(1, putoutNo);
					psSelectSqlRepayPlan.setString(2, endMonthDate);
					psSelectSqlRepayPlan.setString(3, this.deductDate);
					ResultSet rsRepayPlan = psSelectSqlRepayPlan.executeQuery();
					if(rsRepayPlan.next())
					{
						payCorpus += rsRepayPlan.getDouble("Corpus");
						payInte += rsRepayPlan.getDouble("Inte");
					}
					rsRepayPlan.close();
					
					psInsertSqlBtoC.setString(1, bankCode);
					psInsertSqlBtoC.setString(2, loanNo);
					psInsertSqlBtoC.setString(3, idCard);
					psInsertSqlBtoC.setDouble(4, loanBalance);
					if("1".equals(deductType))//���¿�
					{
						psInsertSqlBtoC.setDouble(5, NumberTools.round(payCorpus+payInte+payFineInte, 2));
						psInsertSqlBtoC.setDouble(6, NumberTools.round(payCorpus,2));
						psInsertSqlBtoC.setDouble(7, NumberTools.round(payInte,2));
						psInsertSqlBtoC.setDouble(8, NumberTools.round(payFineInte,2));
					}
					else//�����
					{
						psInsertSqlBtoC.setDouble(5, NumberTools.round(loanBalance+payInte+payFineInte, 2));
						psInsertSqlBtoC.setDouble(6, NumberTools.round(loanBalance,2));
						psInsertSqlBtoC.setDouble(7, NumberTools.round(payInte,2));
						psInsertSqlBtoC.setDouble(8, NumberTools.round(payFineInte,2));
					}
					psInsertSqlBtoC.setString(9, inputDate);
					psInsertSqlBtoC.setString(10, deductType);
					psInsertSqlBtoC.setString(11, loanType);
					psInsertSqlBtoC.addBatch();
				
					
					psInsertSqlBtoB.setString(1, loanNo);
					psInsertSqlBtoB.setString(2, customerName);
					psInsertSqlBtoB.setString(3, contractNo);
					psInsertSqlBtoB.setString(4, accountNo);
					psInsertSqlBtoB.setString(5, inputDate);
					psInsertSqlBtoB.addBatch();
					
					psUpdateSqlRushpayFlag.setString(1, putoutNo);
					psUpdateSqlRushpayFlag.addBatch();
					
					
					dealNum++;
					icount++;
				    if(dealNum>=commitNum){
				    	psInsertSqlBtoC.executeBatch();
				    	psInsertSqlBtoB.executeBatch();
						psUpdateSqlRushpayFlag.executeBatch();
				    	dealNum=0;
						logger.info("�ѳ�ʼ��BtoC��BtoB����"+icount+"����");
			        }
				}
				
				psInsertSqlBtoC.executeBatch();
		    	psInsertSqlBtoB.executeBatch();
		    	psUpdateSqlRushpayFlag.executeBatch();
		    	psInsertSqlBtoC_Tmp.setString(1, this.deductDate);
		    	psInsertSqlBtoC_Tmp.setString(2, this.deductDate);
		    	psInsertSqlBtoC_Tmp.execute();
		    	
		    	logger.info("����ʼ��BtoC��BtoB����"+icount+"����");
			}catch(Exception ex)
			{
				ex.printStackTrace();
				throw ex;
			}
			finally
			{
				if(psInsertSqlBtoC!=null) psInsertSqlBtoC.close();
				if(psInsertSqlBtoB!=null) psInsertSqlBtoB.close();
				if(psInsertSqlBtoC_Tmp!=null) psInsertSqlBtoC_Tmp.close();
				if(psSelectSqlBtoC!=null) psSelectSqlBtoC.close();
				if(psSelectSqlLoanBack!=null) psSelectSqlLoanBack.close();
			}
		}
}
