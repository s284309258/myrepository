package com.amarsoft.app.datax.gci.deductacc;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.ledger.AnnualCheck;
import com.amarsoft.account.ledger.SubjectInfo;
import com.amarsoft.account.ledger.UpdateLedgerGeneral;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class BatchAnnualCheck extends CommonExecuteUnit{

	private int commitNum ;
	private int dealNum = 0;
	
	private int changeSerialno = 0;
	private String pre = "DEAL";
	
	private String rate360 = "6.6";//5-30���ڵ�
	private String rate60 = "6.45";//3-5���ڵ�
	private String rate36 = "6.1";//1-3���ڵ�
	private String rate12 = "6.06";//6-12�µ�
	private String rate6 = "5.6";//0-6�µ�
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				
				if(!nextDate.equals(nextYear+"/01/01"))
				{
					if("2011/03/04".equalsIgnoreCase(deductDate)){
						DealBaseRateChange();
					}
					
					logger.info("���ղ���ִ�д�ģ�飡");
				}
				else
				{
					AnnualCheck annualCheck = new AnnualCheck();
					annualCheck.AnnualCheckAccount(deductDate,currentYear,connection);
					//����˫���Ŀ
					UpdateLedgerGeneral.BatchLedgerGeneral(connection);
					
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					
					logger.info("������ϸ��Subject_OccurAmt�н��յ���Ϣ......");
					String delSql = " delete from Subject_OccurAmt where OccurDate = '"+deductDate+"'";
					PreparedStatement psDelSql =connection.prepareStatement(delSql);
					psDelSql.execute();
					logger.info("����Subject_OccurAmt���!");
					
					logger.info("�������˱�Subject_Balance�н��յ���Ϣ......");
					String delSql1 = " delete from Subject_Balance where OccurDate = '"+deductDate+"'";
					PreparedStatement psDelSql1 =connection.prepareStatement(delSql1);
					psDelSql1.execute();
					logger.info("����Subject_Balance���!");
					
					logger.info("������ϸ�ʱ�......");
					insertOccurAmt();
					logger.info("��ϸ�ʱ�������ɣ�");
					
					logger.info("����ϸ���в������ӡ��˰��¼��Ϣ.......");
					stampInsertToOccur();
					logger.info("ӡ��˰�����Ϣ������ɣ�");
					
					logger.info("�������˱�......");
					initSubjectBalance();
					updateSubjectBalance();
					BatchSubjectBalance();
					logger.info("���˱�������ɣ�");
				}
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//���ɵ�����ϸ��
	public void insertOccurAmt() throws SQLException
	{
		
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate,AccAcountFlag) VALUES(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		
		String selectSql = " select OrgID,Currency,SubjectNo,sum(DebitAmt) as DebitAmt,sum(CreditAmt) as CreditAmt "
		      + " from ledger_detail "
		      + " where OccurDate = '"+deductDate+"' and (HandStatus = '1' or HandStatus = '2')"
		      + " group by OrgID,Currency,SubjectNo ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,rs.getString("SubjectNo"));
			psInsertSql.setDouble(4,rs.getDouble("DebitAmt"));
			psInsertSql.setDouble(5,rs.getDouble("CreditAmt"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.setString(7,"0");
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}
	
	public void stampInsertToOccur() throws SQLException
	{
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate) VALUES(?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		
		String selectSql = " select OrgID,ConsultAmount,Currency from Consult_stamp where ConsultDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,"9100101");
			psInsertSql.setDouble(4,rs.getDouble("ConsultAmount"));
			psInsertSql.setDouble(5,0);
			psInsertSql.setString(6,deductDate);
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}
	
	//��ʼ���������˱�
	public void initSubjectBalance() throws SQLException
	{	
		String insertSql = " insert into Subject_Balance(Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,OccurDate,CheckSubjectNo) "
						 + " values(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,CheckSubjectNo from subject_balance where OccurDate = '"+lastDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,rs.getString("SubjectNo"));
			psInsertSql.setDouble(4,rs.getDouble("DebitBalance"));
			psInsertSql.setDouble(5,rs.getDouble("CreditBalance"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.setString(7,rs.getString("CheckSubjectNo"));
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum =0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psInsertSql.close();
		psSelectSql.close();
		dealNum =0;
	}
	
	//�������˱�
	public void updateSubjectBalance() throws SQLException, LoanException
	{
		
		String updateSql = " update Subject_balance set DebitBalance = DebitBalance+?,CreditBalance = CreditBalance+? where SubjectNo=? and OrgID=? and Currency=? and OccurDate = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String updateOccurAmt = " update Subject_OccurAmt set AccAcountFlag = '1' where SubjectNo=? and OrgID=? and Currency=? and OccurDate = ? ";
		PreparedStatement psUpdateOccurAmt = connection.prepareStatement(updateOccurAmt);
		
		String insertSql = " insert into Subject_Balance(Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,OccurDate,CheckSubjectNo)  "
			 + " SELECT Currency,OrgID,SubjectNo,0,0,'"+deductDate+"',SubjectNo from Subject_Occuramt so " 
			 + " WHERE NOT EXISTS(select sb.* from Subject_Balance sb where sb.currency=so.currency and sb.orgid = so.orgid and sb.subjectno = so.subjectno and sb.occurdate=so.occurdate)"
			 + "  and so.occurdate = '"+deductDate+"' ";
		PreparedStatement psInserSql = connection.prepareStatement(insertSql);
		psInserSql.execute();
		psInserSql.close();
		
		String selectSql = " select Currency,OrgID,SubjectNo,DebitAmt,CreditAmt "
		      + " from Subject_OccurAmt "
		      + " where OccurDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sLoanWay =LedgerSubjectConfig.getSubjectLoanWay(rs.getString("SubjectNo"));
			if(sLoanWay.equalsIgnoreCase("D"))
			{
				psUpdateSql.setDouble(1,rs.getDouble("DebitAmt")-rs.getDouble("CreditAmt"));
				psUpdateSql.setDouble(2,0);
			}
			else if(sLoanWay.equalsIgnoreCase("C"))
			{
				psUpdateSql.setDouble(1,0);
				psUpdateSql.setDouble(2,rs.getDouble("CreditAmt")-rs.getDouble("DebitAmt"));
			}
			else
			{
				psUpdateSql.setDouble(1,rs.getDouble("DebitAmt"));
				psUpdateSql.setDouble(2,rs.getDouble("CreditAmt"));
			}
			psUpdateSql.setString(3,rs.getString("SubjectNo"));
			psUpdateSql.setString(4,rs.getString("OrgID"));
			psUpdateSql.setString(5,rs.getString("Currency"));
			psUpdateSql.setString(6,deductDate);
			psUpdateSql.addBatch();
			
			psUpdateOccurAmt.setString(1,rs.getString("SubjectNo"));
			psUpdateOccurAmt.setString(2,rs.getString("OrgID"));
			psUpdateOccurAmt.setString(3,rs.getString("Currency"));
			psUpdateOccurAmt.setString(4,deductDate);
			psUpdateOccurAmt.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psUpdateSql.executeBatch();
				psUpdateOccurAmt.executeBatch();
				dealNum=0;
			}
		}
		psUpdateSql.executeBatch();
		psUpdateOccurAmt.executeBatch();
		rs.getStatement().close();
		psSelectSql.close();
		psUpdateOccurAmt.close();
		psUpdateSql.close();
	}
	
	//���·���˫���Ŀ�����ֵ
	public void BatchSubjectBalance() throws Exception{
		String updateSql="UPDATE subject_balance SET CreditBalance=CreditBalance-DebitBalance," +
			"DebitBalance=0 WHERE SubjectNo=? and OccurDate = ? And CreditBalance-DebitBalance>=0";
		String updateSql2="UPDATE subject_balance SET CreditBalance=0," +
			"DebitBalance=DebitBalance-CreditBalance WHERE SubjectNo=? and OccurDate = ? And CreditBalance-DebitBalance<0";
		
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		PreparedStatement psUpdateSql2 = connection.prepareStatement(updateSql2);
		
		HashMap<String, SubjectInfo> subjectInfoHashMap = LedgerSubjectConfig.getSubjectInfoHashMap();
		for (Iterator<String> iter = subjectInfoHashMap.keySet().iterator(); iter.hasNext();){
			String key = iter.next();
			SubjectInfo subjectInfo=subjectInfoHashMap.get(key);
			if(subjectInfo.getSubjectLevel().equals("3")&&subjectInfo.getStatus().equals("1")&&subjectInfo.getLoanWay().equalsIgnoreCase("B")){//������Ŀ��Ϊ���ÿ�Ŀ				
				psUpdateSql.setString(1, subjectInfo.getSubjectNo());
				psUpdateSql.setString(2, deductDate);
				psUpdateSql.addBatch();
				psUpdateSql.executeBatch();
				
				psUpdateSql2.setString(1, subjectInfo.getSubjectNo());
				psUpdateSql2.setString(2, deductDate);
				psUpdateSql2.addBatch();
				psUpdateSql2.executeBatch();
			}
		}
		psUpdateSql.close();
		psUpdateSql2.close();
	}
	
	private void DealBaseRateChange() throws SQLException {
		String objectType = "LoanBalance";
		String status = "1";
		String changeType = "070";
		String colName = "BaseRate";
		
		Statement stmt=connection.createStatement();
		stmt.execute("delete from loan_change where changeserialno like 'DEAL%'");
		stmt.close();
		
		String insertBaseRateSql = " INSERT INTO loan_change(objecttype,changedate,status,changetype,oldvalue,newvalue,colname,changeserialno,objectno,relativeserialno)" +
				" VALUES (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement psInsertBaseRateSql = connection.prepareStatement(insertBaseRateSql);
		
		
		//�ſ�����11��ǰ��,�ſ���11����û��,�·ݴ���360,102��,��������--�´ν�Ϣ�ղ�����
		String sqlNextYear = " select * from loan_balance " +
				" where loan_balance.rateadjusttype = '2' and loanstatus in('0','1','4','5') and loan_balance.normalbalance>0 " +
				" and  months_between(to_date(loan_balance.maturitydate,'yyyy-mm-dd'),to_date(loan_balance.putoutdate,'yyyy-mm-dd')) >360";
		PreparedStatement psNextYear = connection.prepareStatement(sqlNextYear);
		ResultSet rsNextYear = psNextYear.executeQuery();
		while(rsNextYear.next()){
			changeSerialno++;
			String changeDate = rsNextYear.getString("NextPayDate");
			String objectno = rsNextYear.getString("putoutno");
			String oldValue =DataConvert.toString(rsNextYear.getDouble("BaseRate"));
			String newValue = "6.6";
			String changeNo = pre +changeSerialno;
			dealInsert(psInsertBaseRateSql,objectType,changeDate,status,changeType,oldValue,newValue,colName,changeNo,objectno,changeNo);
		}
		psInsertBaseRateSql.executeBatch();
		rsNextYear.close();
		psNextYear.close();

		
		
		String loanChangeSql = " SELECT * FROM loan_change WHERE objectno = ? AND changetype = '070' AND status = '1' ";
		PreparedStatement psLoanChangeSql = connection.prepareStatement(loanChangeSql);
		
		String updateLoanChangeSql = " UPDATE loan_change SET changedate = ? ,newvalue=? WHERE CHANGESERIALNO=? AND CHANGETYPE=? AND COLNAME='BaseRate'";
		PreparedStatement psUpdateLoanChangeSql = connection.prepareStatement(updateLoanChangeSql);
		
		//������¶��գ�û�д���360�µ�
		//�����������������У�Ԥ�ñ����һЩ�����⣬��Ӧ�õ���δ�����ĸ��µ��´ν�Ϣ�յ�����δ����(Ԥ�õ�������)�ĸ���Ϊ����
		String toDayToMonth = " select months_between(to_date(loan_balance.maturitydate,'yyyy-mm-dd'),to_date(loan_balance.putoutdate,'yyyy-mm-dd')) as Month,loan_balance.* from loan_balance " +
				" where loan_balance.rateadjusttype = '3' and loanstatus in('0','1','4','5') and loan_balance.normalbalance>0 " +
				" and putoutdate <'2011/01/01' and  substr(putoutdate,6,10 )> '02/09'";
		PreparedStatement pstoDayToMonth = connection.prepareStatement(toDayToMonth);
		ResultSet rsToDayToMonth = pstoDayToMonth.executeQuery();
		while(rsToDayToMonth.next()){
			double Month = rsToDayToMonth.getDouble("Month");
			String changeDate = rsToDayToMonth.getString("NextPayDate");
			String objectno = rsToDayToMonth.getString("putoutno");
			String changeSerialNo = "";
			
			String loanChangeDate = "";
			psLoanChangeSql.setString(1, objectno);
			ResultSet rsLoanChange = psLoanChangeSql.executeQuery();
			while(rsLoanChange.next()){
				loanChangeDate = rsLoanChange.getString("ChangeDate");
				changeSerialNo = rsLoanChange.getString("CHANGESERIALNO");
			}
			rsLoanChange.close();
			if("".equals(loanChangeDate) || loanChangeDate==null) continue;
			if(loanChangeDate.compareTo("2012/03/04")<=0) {
				loanChangeDate=changeDate;
			}else if(loanChangeDate.startsWith("2012")){
				loanChangeDate = loanChangeDate.replace("2012", "2011");
			}
			
			//���ݲ�ͬ�ķ�ʽ����
			dealInsertOher(psUpdateLoanChangeSql,loanChangeDate,changeType,objectno,Month,changeSerialNo);
			psUpdateLoanChangeSql.executeBatch();
		}
		
		rsToDayToMonth.close();
		psLoanChangeSql.close();
		psUpdateLoanChangeSql.close();
		
	}

	//
	private void dealInsertOher(PreparedStatement psUpdateLoanChangeSql,String loanChangeDate,String changeType,
			String objectno, double month, String changeSerialNo) throws SQLException {
//		private String rate360 = "6.6";//5-30���ڵ�
//		private String rate60 = "6.45";//3-5���ڵ�
//		private String rate36 = "6.1";//1-3���ڵ�
//		private String rate12 = "6.06";//6-12�µ�
//		private String rate6 = "5.6";//0-6�µ�
		
		String newVue= "0";
		if(month>=60){
			newVue = rate360;
		}else if(month>=36 && month<60){
			newVue = rate60;
		}else if(month>=12 && month<36){
			newVue = rate36;
		}else if(month>=6 && month<12){
			newVue = rate12;
		}else if(month>=0 && month<6){
			newVue = rate6;
		}
		// UPDATE loan_change SET changedate = ? ,newvalue=? WHERE CHANGESERIALNO=? AND CHANGETYPE=? AND COLNAME='BaseRate'";
		psUpdateLoanChangeSql.setString(1, loanChangeDate);
		psUpdateLoanChangeSql.setString(2, newVue);
		psUpdateLoanChangeSql.setString(3, changeSerialNo);
		psUpdateLoanChangeSql.setString(4, changeType);
		psUpdateLoanChangeSql.addBatch();
	}

	private void dealInsert(PreparedStatement psInsertBaseRateSql,String objectType, String changeDate,
			String status, String changeType, String oldValue, String newValue,
			String colName, String changeNo, String objectno, String changeNo2) throws SQLException {
		psInsertBaseRateSql.setString(1, objectType);
		psInsertBaseRateSql.setString(2, changeDate);
		psInsertBaseRateSql.setString(3, status);
		psInsertBaseRateSql.setString(4, changeType);
		psInsertBaseRateSql.setString(5, oldValue);
		psInsertBaseRateSql.setString(6, newValue);
		psInsertBaseRateSql.setString(7, colName);
		psInsertBaseRateSql.setString(8, changeNo);
		psInsertBaseRateSql.setString(9, objectno);
		psInsertBaseRateSql.setString(10, changeNo2);
		psInsertBaseRateSql.addBatch();
		
		
	}
	
}
