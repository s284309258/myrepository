package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class initSubjectBalance extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��ʼ��ʼ��subject_balance......");
				initSB();
				logger.info("��ʼ��subject_balance��ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void initSB() throws SQLException
	{
		String insertSql = " insert into Subject_Balance(Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,OccurDate) "
			 + " values(?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String temSql = " select OrgID from Org_info where (orglevel = '3' or orglevel = '6') and status = '1' ";
		PreparedStatement psTemSql = connection.prepareStatement(temSql);
		
		String selectSql = " select SubjectNo from Subject_Info where subjectLevel = '3' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			ResultSet rsTemp = psTemSql.executeQuery();
			while(rsTemp.next())
			{
				psInsertSql.setString(1,"RMB");
				psInsertSql.setString(2,rsTemp.getString("OrgID"));
				psInsertSql.setString(3,rs.getString("SubjectNo"));
				psInsertSql.setDouble(4,0);
				psInsertSql.setDouble(5,0);
				psInsertSql.setString(6,deductDate);
				psInsertSql.addBatch();
				dealNum++;	
				
				psInsertSql.setString(1,"USD");
				psInsertSql.setString(2,rsTemp.getString("OrgID"));
				psInsertSql.setString(3,rs.getString("SubjectNo"));
				psInsertSql.setDouble(4,0);
				psInsertSql.setDouble(5,0);
				psInsertSql.setString(6,deductDate);
				psInsertSql.addBatch();
				dealNum++;	
			}
			rsTemp.close();
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psTemSql.close();
		psSelectSql.close();
		psInsertSql.close();
		
	}
}
