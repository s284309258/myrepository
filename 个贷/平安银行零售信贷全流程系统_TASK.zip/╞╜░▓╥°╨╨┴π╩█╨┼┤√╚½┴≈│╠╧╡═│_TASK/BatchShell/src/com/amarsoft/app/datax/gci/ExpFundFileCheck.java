package com.amarsoft.app.datax.gci;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class ExpFundFileCheck extends CommonExecuteUnit {

	private String sql;
	private String fileName;
	private PrintWriter outputstreamwriter;
	private String separator;
	private String NASUrl;
	private String fileUrl;
	public String getFieldValue(ColumnMetaData columnMetaData,String s){
		String sType = columnMetaData.getTypeName();
		int iLength=s.getBytes().length;
		int iDisplaySize = columnMetaData.getDisplaySize();
		//int iPrecision = columnMetaData.getPrecision();
		int iScale = columnMetaData.getScale();
		if(sType.equals("CHAR")){
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s=s + " ";
	    	}
		}
		if(sType.equals("INT")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s="0"+s;
	    	}
		}
		if(sType.equals("DATE")){
			s = StringFunction.replace(s,"/","");
			iLength=s.getBytes().length;
	        for(int i=0;i<iDisplaySize-iLength;i++){
	        	s=s + " ";
	    	}
		}
		if(sType.equals("DOUBLE")){
			if(s.equals("")){
				s="0";
				iLength=1;
			}
			
			String temp=s;
			if(s.indexOf(".")>0) temp=s.substring(0,s.indexOf("."));
			s=NumberTools.numberFormat(Double.parseDouble(s),temp.length(), iScale);
			iLength=s.length();
	        for(int i=0;i<iDisplaySize-iLength;i++){
	    		s="0"+s;
	    	}
	        s = "0"+s.substring(0,s.indexOf("."))+s.substring(s.indexOf(".")+1,iDisplaySize);
	        
		}
		return s;
	}
	public void exportResultSet(String sql,TableMetaData tableMetaData,PrintWriter outputstreamwriter) throws SQLException, IOException{
		separator = this.getProperty("separator");
		Statement stm = connection.createStatement();
		ResultSet rs=stm.executeQuery(sql);
		int rowNum=0;
		while(rs.next()){
			String s="";
			rowNum++;
			for(int i=1;i<=tableMetaData.getColumnCount();i++){
				ColumnMetaData columnMetaData= tableMetaData.getColumn(i);
				logger.info(columnMetaData.getName());
				String rsString=rs.getString(columnMetaData.getName());if(rsString==null)rsString="";
				if(rsString.equals("{$RowNum}")) rsString=String.valueOf(rowNum);
				s+=getFieldValue(columnMetaData,rsString)+separator;
			}
			s+="\r\n";
			outputstreamwriter.write(s);
		}
		rs.close();
		stm.close();
	}
	@SuppressWarnings("finally")
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				unitStatus= TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				fileName =  this.getProperty("unit.fileName");
				
				if(!isTodayEx(fileName))
				{
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					fileUrl= this.getProperty("unit.fileUrl"); 
					
					String sDate = StringFunction.replace(deductDate,"/","");
					String sMonth = StringFunction.replace(currentMonth,"/","");
					fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
					fileName=StringFunction.replace(fileName,"{$CurrentMonth}",sMonth);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentMonth}",sMonth);
					
					File file = new File(fileUrl);
					if(!file.exists())
					{
						file.mkdirs();
					}
					
					fileName = fileUrl+fileName;
					outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName))),true);
					//outputstreamwriter = new OutputStreamWriter(new FileOutputStream(new File(fileName)), "GBK");
					for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty(
							"unit.recordSet" + i).trim().equals("")); i++) {
						
						sql=this.getProperty("unit.recordSet"+i);
						sql=StringFunction.replace(sql,"{$CurrentDate}", deductDate);
						sql=StringFunction.replace(sql,"{$CurrentMonth}", currentMonth);
						
						sql=StringFunction.replace(sql,"{$CurrentDateNoSplit}", StringFunction.replace(deductDate, "/",""));
						sql=StringFunction.replace(sql,"{$CurrentMonthNoSplit}", StringFunction.replace(currentMonth, "/",""));
						
						
						String[] s=sql.split(":");
						sql=sql.substring(sql.indexOf(s[1])+s[1].length()+1);
						logger.info("��ǰ������sql="+sql);
						exportResultSet(sql,ARE.getMetaData(s[0]).getTable(s[1]),outputstreamwriter);
					}
				
					outputstreamwriter.close();
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}
			}
		}
		catch(Exception e){
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
		}
		finally{
			clearResource();
			return unitStatus;
		}
	}
	
	private boolean isTodayEx(String sFileName)
	{
		if(sFileName.equalsIgnoreCase("BIFMFBAJUP"))
		{
			if(deductDate.substring(8,10).equals("05"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
			return true;
	}

}
