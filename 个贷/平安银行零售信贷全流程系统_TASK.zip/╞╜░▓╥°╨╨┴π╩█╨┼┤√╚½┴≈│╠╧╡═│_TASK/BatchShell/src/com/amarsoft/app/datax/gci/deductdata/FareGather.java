package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;

public class FareGather extends CommonExecuteUnit{
	
	private int commitNum ;
	private String selectSql;
	private String insertSql;
	private PreparedStatement psSelectSql;
	private PreparedStatement psInsertSumSql;
	private int dealNum = 0;
	private int icount = 0 ;

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','SUMFARE') ";
				logger.info("��� SUMFARE:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("���SUMFARE������� ");
				
				logger.info("��ʼ�����˻�������......");
				gatherFare();
				logger.info("�������˻�������"+icount+"����");
				logger.info("�����˻����������!");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			
			clearResource();
			return unitStatus;
		} 
	}
	
	
	//�����˻�������
	public void gatherFare() throws SQLException
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		insertSql = " INSERT INTO SUMFARE(PutOutNo,PayMoney,Currency) "
			  + " VALUES(?,?,?) ";
		psInsertSumSql = connection.prepareStatement(insertSql);
		
		//��һ��������Fare_Detail������
		selectSql = " select fd.PutOutNo,sum(fd.PayMoney-fd.ActualMoney) as PayMoney,fd.Currency "
				  + " from Fare_Detail fd,loan_balance lb"
				  + " where fd.OffFlag = '0' and fd.putoutno=lb.putoutno and lb.businessType = '1140100' "
				  + " group by fd.PutOutNo,fd.Currency ";
		psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
		//�ڶ���������û��ܱ� SumFare��������
			psInsertSumSql.setString(1,rs.getString("Putoutno"));
			psInsertSumSql.setDouble(2,rs.getDouble("PayMoney"));
			psInsertSumSql.setString(3,rs.getString("Currency"));
			psInsertSumSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>commitNum)
			{
				psInsertSumSql.executeBatch();
				dealNum=0;
				logger.info("�ѻ����˻�������"+icount+"����");
			}
		}
		psInsertSumSql.executeBatch();
		rs.getStatement().close();
		psInsertSumSql.close();
		psSelectSql.close();
		
	}
}


