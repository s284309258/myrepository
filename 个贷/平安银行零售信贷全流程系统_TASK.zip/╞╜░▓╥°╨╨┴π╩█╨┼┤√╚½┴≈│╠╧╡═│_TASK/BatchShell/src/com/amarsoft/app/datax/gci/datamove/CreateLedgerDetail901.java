package com.amarsoft.app.datax.gci.datamove;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateLedgerDetail901 extends CommonExecuteUnit  {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("................��ʼ��ʼ��������.............");
					initData();
					logger.info("................��ʼ������������..............");
	
					logger.info("................��ʼ����901����LD��ҵ�����ݣ�.............");
					InsertLedgerDetailPR();
					logger.info("................����901����LD��ҵ��������ɣ�..............");
				}else{
					logger.info("...............���첻��Ҫ����.............");
				}
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void initData() {
		commitNum = getProperty("commitNum", 1);
	}
	
	public void InsertLedgerDetailPR() throws SQLException{
		CallableStatement   cs =connection.prepareCall("call QY_LEDGER_DETAIL_901PR('"+deductDate+"')");    
		  //ִ�д洢����   
		  cs.execute();      
		  cs.close();   
	}
	
//	public void InsertLedgerDetail() throws SQLException{
//		String al=" insert into ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno)  "
//					+" select lg.putoutno,'' as BILLNO ,99999 as TRANSID,99 as SORTID,'' as OCCURTIME,'"+deductDate+"' as OCCURDATA,lg.currency,lg.subjectno,  "
//					+" lg.creditbalance*-1 ,lg.debitbalance*-1,'0' as HANDSTATUS,lg.orgid,'DM901'||lg.putoutno||SEQ_CLEAN.NEXTVAL   as serialno   "
//					+" from qy_ledger_general_bak901 lg where (lg.creditbalance<>0 or lg.debitbalance<>0)  ";
//		PreparedStatement ps = connection.prepareStatement(al);
//		ps.execute();
//		connection.commit();
//		
//	}
	
}
