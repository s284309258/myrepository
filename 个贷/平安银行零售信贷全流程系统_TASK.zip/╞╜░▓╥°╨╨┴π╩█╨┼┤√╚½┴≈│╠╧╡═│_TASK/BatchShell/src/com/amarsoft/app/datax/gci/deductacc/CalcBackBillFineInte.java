package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class CalcBackBillFineInte extends CommonExecuteUnit{

	private int icount = 0;
	private int commitNum ;
	private int dealNum = 0;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String sInitDate = DataConvert.toString(getProperty("initDate", "1"));
				logger.info("������ʼ��ʵ����Ϣ");
				if(sInitDate.equals(deductDate)){
					updateFineInte(deductDate);
				}				
				logger.info("��ʼ�����");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void updateFineInte(String deductDate) throws SQLException
	{
		
		double dPayAllInte = 0.0,dActualAllInte = 0.0,dPayOverdueCorpInte = 0.0,dPayNormalInte = 0.0,dPayInteFine = 0.0;
		String sBillNo = "",sPutOutNo = "",sSterm = "",sAheadNum = "";
		String sLoanStatus = "";//����״̬
		
		String updateSql = " update Back_Bill set ACTUALINTEFINE = ? where BillNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select BillNo,(ActualInte+ActualInnerInte+ActualOutInte) as ActualAllInte" 
						 + " from Back_Bill  " 
						 + " where  BillType in('20','22') and BillStatus = '1' and PutoutNo = ? "
						 + " and STerm = ? and AheadNum = ?"
						 + " and (ActualInte+ActualInnerInte+ActualOutInte) > 0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		
		//ȡ����״̬��Ӧ��������Ϣ,��Ϣ
		String selectLoanBackStatus = " select PutoutNo,Sterm,AheadNum,PayOverdueCorpInte as PAYINTEFINE "
									+ " from LoanBack_Status"
									+ " where AheadNum = 0 order by PutoutNo";		
		PreparedStatement psSelectLoanBackStatus = connection.prepareStatement(selectLoanBackStatus);
		
		ResultSet rs = psSelectLoanBackStatus.executeQuery();
		while(rs.next())
		{			
			sPutOutNo = DataConvert.toString(rs.getString("PutoutNo"));
			sSterm = DataConvert.toString(rs.getString("Sterm"));
			sAheadNum = DataConvert.toString(rs.getString("AheadNum"));
			dPayInteFine = rs.getDouble("PAYINTEFINE");
			if("".equals(sPutOutNo) || "".equals(sSterm) || "".equals(sAheadNum) || dPayInteFine == 0){
				continue;
			}
			
			psSelectSql.setString(1, sPutOutNo);
			psSelectSql.setString(2, sSterm);
			psSelectSql.setString(3, sAheadNum);
			ResultSet rs1 = null;
			rs1 = psSelectSql.executeQuery();
			while(rs1.next()){
				if(dPayInteFine <= 0){
					break;
				}
				sBillNo = rs1.getString("BillNo");
				//����ʵ������Ϣ
				dActualAllInte = rs1.getDouble("ActualAllInte");				
				//�������������Ϣ����ʣ�෣Ϣ��� ֹͣѭ�� �����÷�Ϣ��ȥ����������Ϣ
				if(dActualAllInte >= dPayInteFine){
					psUpdateSql.setDouble(1, dPayInteFine);
					psUpdateSql.setString(2, sBillNo);
					psUpdateSql.addBatch();
					dealNum++;
					icount++;
					break;
				}else{
					psUpdateSql.setDouble(1, dActualAllInte);
					psUpdateSql.setString(2, sBillNo);
					psUpdateSql.addBatch();
					dPayInteFine -= dActualAllInte;
					dealNum++;
					icount++;
				}
				
			}
			rs1.close();
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ���"+icount+"�����ݣ�");
			}
		}
		rs.close();
		//����ʣ���¼
		psUpdateSql.executeBatch();
		
		psSelectSql.close();
		psUpdateSql.close();
		psSelectLoanBackStatus.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
}
