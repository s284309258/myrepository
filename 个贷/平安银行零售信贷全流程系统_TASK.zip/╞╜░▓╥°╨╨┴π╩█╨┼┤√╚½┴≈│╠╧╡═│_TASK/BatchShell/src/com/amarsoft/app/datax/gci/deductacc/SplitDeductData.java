package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.ProductCondition;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.account.Deal.TransFareSW;
import com.amarsoft.account.entity.AcctFeeInfo;
import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;

public class SplitDeductData extends CommonExecuteUnit  {
	
	private HashMap <String,ProductCondition> productConditionHashMap;
	
	private int commitNum ;
	private int deductDateNum = 0;
	private int icount = 0;
	private String sSerialNo = "";
	private int iFareSerialNo = 0;
	

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				logger.info("С΢���ú�����һ��ۿ��......");
				SWDataSplit1();
				SWDataSplit2();
				SWDataSplit3();
				logger.info("С΢���ú�����һ��ۿ�����");
				logger.info("��ʼ�����������......");
				DataSplit1();
				DataSplit2();
				DataSplit3();
				logger.info("���������һ��������"+icount+"����");
				logger.info("��ʼ�����������ݲ��......");
				specialSplit1();
				specialSplit2();
				specialSplit3();
				specialDataSplit();
				logger.info("�������������ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	//С΢���ú�����һ��ۿ��
	public void SWDataSplit1() throws Exception {
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		double balance=0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo=?,ActualAmount1=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = "(select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,"+
           "dd.ActualDefaultCorp,dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,"+
           "dd.ActualOutInte,dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,ap.ActualAmount1,lb.BusinessType,"+
           "lb.OrgID,lb.LoanStatus,ap.SerialNo,DD.PAYDATE,nvl(bc.IfDunFlag, '0') as IfDunFlag,nvl(bc.IsBadness, '0') as IsBadness,'' as fdserialno,"+
           " '' as feetype,0 as paymoney,0 as actualmoney,ap.deductaccno from Deduct_Data dd, loan_balance lb, AS400_PAMS ap, business_contract bc "+
           " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno = bc.serialno and ap.actualamount1 > 0 "+
           " and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_SW+"') UNION ALL "+
           " (SELECT AFI.OBJECTNO,0,0,'RMB',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,ap.actualamount1,LB.BUSINESSTYPE,LB.ORGID,LB.LOANSTATUS,ap.serialno,FD.PAYDATE,'0','0',AFI.SERIALNO ,afi.feetype, FD.PAYMONEY, FD.ACTUALMONEY,'' "+
           " FROM ACCT_FEE_INFO AFI, LOAN_BALANCE LB, FARE_DETAIL FD,as400_pams ap WHERE AFI.OBJECTNO = LB.PUTOUTNO AND AFI.SERIALNO = FD.PUTOUTNO and ap.putoutno=lb.putoutno "+
           " AND FD.OFFFLAG = '0' AND AFI.ACCOUNTFLAG = '1' and ap.actualamount1>0)  order by PutOutNo,paydate,AheadNum,sterm ";
						 
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					balance = sumAmount;
					for(int i=0;i<deductDataList.size();i++){
						
						DeductData DeductData = deductDataList.get(i);
						if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
							balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
							if(balance==0.0){
								break;
							}
							
						}else{
							//ÿ�����ݲ��
							DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
							if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
								continue;
							}
							psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
							psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
							psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
							psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
							psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
							psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
							psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
							psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo());
							psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
							psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
							psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
							psUpdateSql.setString(14,ReturnDeductData.getCurrency());
							psUpdateSql.addBatch();
							balance=ReturnDeductData.getBalance();
							if(balance==0.0){
								break;
							}
						}
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
						psDelSql.executeBatch();
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount1");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo(rs.getString("DeductAccNo"));
			deductData.setPayDate(rs.getString("paydate"));
			deductData.setFDSerialNo(rs.getString("fdserialno"));
			deductData.setFeeType(rs.getString("feetype"));
			deductData.setPayMoney(rs.getDouble("paymoney"));
			deductData.setActualMoney(rs.getDouble("actualmoney"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			balance = sumAmount;
			for(int i=0;i<deductDataList.size();i++){
				
				DeductData DeductData = deductDataList.get(i);
				if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
					balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
					if(balance==0.0){
						break;
					}
				}else{
					//ÿ�����ݲ��
					DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
					if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
						continue;
					}
					psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
					psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
					psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
					psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
					psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
					psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
					psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
					psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo());
					psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
					psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
					psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
					psUpdateSql.setString(14,ReturnDeductData.getCurrency());
					psUpdateSql.addBatch();
					balance=ReturnDeductData.getBalance();
					if(balance==0.0){
						break;
					}
				}
				
				if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}
				icount++;
			}
		}
		
		psUpdateSql.executeBatch();
		psDelSql.executeBatch();
		psUpdateSql.close();
		psDelSql.close();
		psSelectSql.close();
		psTempSql.close();
			
	}
	
	//С΢���ú�����һ��ۿ��
	public void SWDataSplit2() throws Exception {
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		double balance=0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo1=?,ActualAmount2=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = "(select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,"+
           "dd.ActualDefaultCorp,dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,"+
           "dd.ActualOutInte,dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,ap.ActualAmount2,lb.BusinessType,"+
           "lb.OrgID,lb.LoanStatus,ap.SerialNo,DD.PAYDATE,nvl(bc.IfDunFlag, '0') as IfDunFlag,nvl(bc.IsBadness, '0') as IsBadness,'' as fdserialno,"+
           " '' as feetype,0 as paymoney,0 as actualmoney,ap.deductaccno1 from Deduct_Data dd, loan_balance lb, AS400_PAMS ap, business_contract bc "+
           " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno = bc.serialno and ap.actualamount2 > 0 "+
           " and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_SW+"') UNION ALL "+
           " (SELECT AFI.OBJECTNO,0,0,'RMB',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,ap.actualamount2,LB.BUSINESSTYPE,LB.ORGID,LB.LOANSTATUS,ap.serialno,FD.PAYDATE,'0','0',AFI.SERIALNO ,afi.feetype, FD.PAYMONEY, FD.ACTUALMONEY,'' "+
           " FROM ACCT_FEE_INFO AFI, LOAN_BALANCE LB, FARE_DETAIL FD,as400_pams ap WHERE AFI.OBJECTNO = LB.PUTOUTNO AND AFI.SERIALNO = FD.PUTOUTNO and ap.putoutno=lb.putoutno "+
           " AND FD.OFFFLAG = '0' AND AFI.ACCOUNTFLAG = '1' and ap.actualamount2>0)  order by PutOutNo,paydate,AheadNum,sterm ";
						 
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					balance = sumAmount;
					for(int i=0;i<deductDataList.size();i++){
						
						DeductData DeductData = deductDataList.get(i);
						if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
							balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
							if(balance==0.0){
								break;
							}
							
						}else{
							//ÿ�����ݲ��
							DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
							if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
								continue;
							}
							psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
							psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
							psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
							psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
							psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
							psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
							psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
							psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo1());
							psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
							psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
							psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
							psUpdateSql.setString(14,ReturnDeductData.getCurrency());
							psUpdateSql.addBatch();
							balance=ReturnDeductData.getBalance();
							if(balance==0.0){
								break;
							}
						}
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
						psDelSql.executeBatch();
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount2");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo1(rs.getString("DeductAccNo1"));
			deductData.setPayDate(rs.getString("paydate"));
			deductData.setFDSerialNo(rs.getString("fdserialno"));
			deductData.setFeeType(rs.getString("feetype"));
			deductData.setPayMoney(rs.getDouble("paymoney"));
			deductData.setActualMoney(rs.getDouble("actualmoney"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			balance = sumAmount;
			for(int i=0;i<deductDataList.size();i++){
				
				DeductData DeductData = deductDataList.get(i);
				if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
					balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
					if(balance==0.0){
						break;
					}
				}else{
					//ÿ�����ݲ��
					DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
					if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
						continue;
					}
					psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
					psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
					psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
					psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
					psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
					psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
					psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
					psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo1());
					psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
					psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
					psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
					psUpdateSql.setString(14,ReturnDeductData.getCurrency());
					psUpdateSql.addBatch();
					balance=ReturnDeductData.getBalance();
					if(balance==0.0){
						break;
					}
				}
				
				if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}
				icount++;
			}
		}
		
		psUpdateSql.executeBatch();
		psDelSql.executeBatch();
		psUpdateSql.close();
		psDelSql.close();
		psSelectSql.close();
		psTempSql.close();
			
	}
	
	//С΢���ú�����һ��ۿ��
	public void SWDataSplit3() throws Exception {
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		double balance=0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo2=?,ActualAmount3=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = "(select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,"+
           "dd.ActualDefaultCorp,dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,"+
           "dd.ActualOutInte,dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,ap.ActualAmount3,lb.BusinessType,"+
           "lb.OrgID,lb.LoanStatus,ap.SerialNo,DD.PAYDATE,nvl(bc.IfDunFlag, '0') as IfDunFlag,nvl(bc.IsBadness, '0') as IsBadness,'' as fdserialno,"+
           " '' as feetype,0 as paymoney,0 as actualmoney,ap.deductaccno2 from Deduct_Data dd, loan_balance lb, AS400_PAMS ap, business_contract bc "+
           " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno = bc.serialno and ap.actualamount3 > 0 "+
           " and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_SW+"') UNION ALL "+
           " (SELECT AFI.OBJECTNO,0,0,'RMB',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,ap.actualamount3,LB.BUSINESSTYPE,LB.ORGID,LB.LOANSTATUS,ap.serialno,FD.PAYDATE,'0','0',AFI.SERIALNO ,afi.feetype, FD.PAYMONEY, FD.ACTUALMONEY,'' "+
           " FROM ACCT_FEE_INFO AFI, LOAN_BALANCE LB, FARE_DETAIL FD,as400_pams ap WHERE AFI.OBJECTNO = LB.PUTOUTNO AND AFI.SERIALNO = FD.PUTOUTNO and ap.putoutno=lb.putoutno "+
           " AND FD.OFFFLAG = '0' AND AFI.ACCOUNTFLAG = '1' and ap.actualamount3>0)  order by PutOutNo,paydate,AheadNum,sterm ";
						 
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					balance = sumAmount;
					for(int i=0;i<deductDataList.size();i++){
						
						DeductData DeductData = deductDataList.get(i);
						if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
							balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
							if(balance==0.0){
								break;
							}
							
						}else{
							//ÿ�����ݲ��
							DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
							if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
								continue;
							}
							psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
							psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
							psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
							psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
							psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
							psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
							psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
							psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo2());
							psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
							psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
							psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
							psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
							psUpdateSql.setString(14,ReturnDeductData.getCurrency());
							psUpdateSql.addBatch();
							balance=ReturnDeductData.getBalance();
							if(balance==0.0){
								break;
							}
						}
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
						psDelSql.executeBatch();
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount3");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo2(rs.getString("DeductAccNo2"));
			deductData.setPayDate(rs.getString("paydate"));
			deductData.setFDSerialNo(rs.getString("fdserialno"));
			deductData.setFeeType(rs.getString("feetype"));
			deductData.setPayMoney(rs.getDouble("paymoney"));
			deductData.setActualMoney(rs.getDouble("actualmoney"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			balance = sumAmount;
			for(int i=0;i<deductDataList.size();i++){
				
				DeductData DeductData = deductDataList.get(i);
				if(DeductData.getFDSerialNo()!=null && DeductData.getFDSerialNo().length()!=0){
					balance=updateFareDetail(DeductData.getFDSerialNo(),DeductData.getFeeType(),DeductData.getPayMoney(),DeductData.getActualMoney(),balance,DeductData.getPayDate());
					if(balance==0.0){
						break;
					}
				}else{
					//ÿ�����ݲ��
					DeductData ReturnDeductData = executeSplitDeductData(balance,sKey,DeductData,sIfDunFlag,sIsBadness);
					if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
						continue;
					}
					psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
					psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
					psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
					psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
					psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
					psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
					psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
					psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo2());
					psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
					psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
					psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
					psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
					psUpdateSql.setString(14,ReturnDeductData.getCurrency());
					psUpdateSql.addBatch();
					balance=ReturnDeductData.getBalance();
					if(balance==0.0){
						break;
					}
				}
				
				if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}
				icount++;
			}
		}
		
		psUpdateSql.executeBatch();
		psDelSql.executeBatch();
		psUpdateSql.close();
		psDelSql.close();
		psSelectSql.close();
		psTempSql.close();
			
	}

	public void DataSplit1() throws SQLException, LoanException
	{
		//��ʼ��
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo=?,ActualAmount1=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		/*String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);*/
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = " select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,dd.ActualDefaultCorp, "
						 + " dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,dd.ActualOutInte, "
						 + " dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,lb.BusinessType,lb.OrgID,lb.LoanStatus,ap.SerialNo,nvl(bc.IfDunFlag,'0') as IfDunFlag,nvl(bc.IsBadness,'0') as IsBadness, " +
						   " ap.DeductAccNo,ap.ActualAmount1 "
						 + " from Deduct_Data dd,loan_balance lb,AS400_PAMS ap,business_contract bc  "
						 + " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno=bc.serialno "
						 + " and ap.actualamount1 > 0 and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_CUR+"' "
						 + " order by dd.PutOutNo,dd.Sterm,dd.AheadNum ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					//����ִ�в�ֳ���
					ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
					
					//����returnDeductDataList
					for(int i=0;i<returnDeductDataList.size();i++)
					{
						DeductData ReturnDeductData = returnDeductDataList.get(i);
						if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
							continue;
						}
						psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
						psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
						psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
						psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
						psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
						psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
						psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
						psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo());
						psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
						psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
						psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
						psUpdateSql.setString(14,ReturnDeductData.getCurrency());
						psUpdateSql.addBatch();
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					/*psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();*/
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
					/*	psDelSql.executeBatch();*/
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount1");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo(rs.getString("DeductAccNo"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			//����ִ�в�ֳ���
			ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
			
			//����returnDeductDataList
			for(int i=0;i<returnDeductDataList.size();i++)
			{
				DeductData ReturnDeductData = returnDeductDataList.get(i);
				if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
					continue;
				}
				psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
				psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
				psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
				psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
				psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
				psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
				psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
				psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo());
				psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
				psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
				psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
				psUpdateSql.setString(14,ReturnDeductData.getCurrency());
				psUpdateSql.addBatch();
				
				/*if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}*/
				icount++;
			}
		}
		psUpdateSql.executeBatch();
		/*psDelSql.executeBatch();*/
		psUpdateSql.close();
		/*psDelSql.close();*/
		psSelectSql.close();
		psTempSql.close();
		
	}
	public void DataSplit2() throws SQLException, LoanException
	{
		//��ʼ��
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo1=?,ActualAmount2=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		/*String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);*/
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = " select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,dd.ActualDefaultCorp, "
						 + " dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,dd.ActualOutInte, "
						 + " dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,lb.BusinessType,lb.OrgID,lb.LoanStatus,ap.SerialNo,nvl(bc.IfDunFlag,'0') as IfDunFlag,nvl(bc.IsBadness,'0') as IsBadness, " +
						   " ap.DeductAccNo1,ap.ActualAmount2 "
						 + " from Deduct_Data dd,loan_balance lb,AS400_PAMS ap,business_contract bc  "
						 + " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno=bc.serialno "
						 + " and ap.actualamount2 > 0 and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_CUR+"' "
						 + " order by dd.PutOutNo,dd.Sterm,dd.AheadNum ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					//����ִ�в�ֳ���
					ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
					
					//����returnDeductDataList
					for(int i=0;i<returnDeductDataList.size();i++)
					{
						DeductData ReturnDeductData = returnDeductDataList.get(i);
						if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
							continue;
						}
						psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
						psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
						psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
						psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
						psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
						psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
						psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
						psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo1());
						psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
						psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
						psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
						psUpdateSql.setString(14,ReturnDeductData.getCurrency());
						psUpdateSql.addBatch();
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					/*psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();*/
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
					/*	psDelSql.executeBatch();*/
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount2");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo1(rs.getString("DeductAccNo1"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			//����ִ�в�ֳ���
			ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
			
			//����returnDeductDataList
			for(int i=0;i<returnDeductDataList.size();i++)
			{
				DeductData ReturnDeductData = returnDeductDataList.get(i);
				if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
					continue;
				}
				psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
				psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
				psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
				psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
				psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
				psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
				psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
				psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo1());
				psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
				psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
				psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
				psUpdateSql.setString(14,ReturnDeductData.getCurrency());
				psUpdateSql.addBatch();
				
				/*if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}*/
				icount++;
			}
		}
		psUpdateSql.executeBatch();
		/*psDelSql.executeBatch();*/
		psUpdateSql.close();
		/*psDelSql.close();*/
		psSelectSql.close();
		psTempSql.close();
		
	}
	public void DataSplit3() throws SQLException, LoanException
	{
		//��ʼ��
		initProductCondition();
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		ArrayList<DeductData> deductDataList = new ArrayList<DeductData>();
		String lastPutOutNo ="";
		String sKey="";
		double sumAmount =0.0d;
		String sIfDunFlag="0";//�Ƿ�����
		String sIsBadness = "0";//�Ƿ���
		
		String updateSql ="Update Deduct_Data set ActualCurrentCorp =ActualCurrentCorp+?,ActualDefaultCorp=ActualDefaultCorp+?,ActualOverDueCorp=ActualOverDueCorp+?,"
			  +"ActualInte=ActualInte+?,ActualInnerInte=ActualInnerInte+?,ActualOutInte=ActualOutInte+?, "
			  +"ActualInnerInteFine=ActualInnerInteFine+?,ActualOutInteFine=ActualOutInteFine+?,DeductAccNo2=?,ActualAmount3=? "
			  +" where PutOutNo=? and Sterm=? and AheadNum=? and Currency=?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		/*String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);*/
		
		String tempSql = "  select count(*) as icount from PRODUCT_CONDITION where OrgID = ? and TypeNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String selectSql = " select dd.PutOutNo,dd.Sterm,dd.AheadNum,dd.Currency,dd.PayCurrentCorp,dd.ActualCurrentCorp,dd.PayDefaultCorp,dd.ActualDefaultCorp, "
						 + " dd.PayOverDueCorp,dd.ActualOverDueCorp,dd.PayInte,dd.ActualInte,dd.PayInnerInte,dd.ActualInnerInte,dd.PayOutInte,dd.ActualOutInte, "
						 + " dd.PayInnerInteFine,dd.ActualInnerInteFine,dd.PayOutInteFine,dd.ActualOutInteFine,lb.BusinessType,lb.OrgID,lb.LoanStatus,ap.SerialNo,nvl(bc.IfDunFlag,'0') as IfDunFlag,nvl(bc.IsBadness,'0') as IsBadness, " +
						   " ap.DeductAccNo2,ap.ActualAmount3 "
						 + " from Deduct_Data dd,loan_balance lb,AS400_PAMS ap,business_contract bc  "
						 + " where dd.PutOutNo = lb.PutOutNo and ap.putoutno = lb.putoutno and lb.contractserialno=bc.serialno "
						 + " and ap.actualamount3 > 0 and ap.AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_CUR+"' "
						 + " order by dd.PutOutNo,dd.Sterm,dd.AheadNum ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			sSerialNo ="";
			
			if(!rs.getString("PutOutNo").equalsIgnoreCase(lastPutOutNo))
			{
				if(lastPutOutNo !=null && lastPutOutNo.length()!=0)
				{
					//����ִ�в�ֳ���
					ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
					
					//����returnDeductDataList
					for(int i=0;i<returnDeductDataList.size();i++)
					{
						DeductData ReturnDeductData = returnDeductDataList.get(i);
						if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
							continue;
						}
						psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
						psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
						psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
						psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
						psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
						psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
						psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
						psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo2());
						psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
						psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
						psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
						psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
						psUpdateSql.setString(14,ReturnDeductData.getCurrency());
						psUpdateSql.addBatch();
						
						deductDateNum++;
						icount++;
						
					}
					
					sSerialNo = rs.getString("SerialNo");
					/*psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();*/
					
					if(deductDateNum>=commitNum)
					{
						psUpdateSql.executeBatch();
					/*	psDelSql.executeBatch();*/
						deductDateNum=0;
						logger.info("�Ѳ������"+icount+"����");
					}
				}
				
				int icount = 0;
				String sOrgID = rs.getString("OrgID");
				String sBusinessType = rs.getString("BusinessType");
				for(int i=0;i<2;i++)
				{
					psTempSql.setString(1,sOrgID);
					psTempSql.setString(2,sBusinessType);
					ResultSet rsTemp = psTempSql.executeQuery();
					if(rsTemp.next())
					{
						icount = rsTemp.getInt("icount");
					}
					rsTemp.close();
					
					if(icount>0)
					{
						break;
					}
					else
					{
						sOrgID = OrgInfoConfig.getBelongOrgID(sOrgID);
					}
				}

				sKey = rs.getString("BusinessType")+sOrgID+rs.getString("LoanStatus");
				lastPutOutNo = rs.getString("PutOutNo");
				sumAmount = rs.getDouble("ActualAmount3");
				sIfDunFlag = rs.getString("IfDunFlag");
				sIsBadness = rs.getString("IsBadness");
				deductDataList.clear();
			}
			
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("Sterm"));
			deductData.setAheadNum(rs.getInt("AheadNum"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualOutInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo2(rs.getString("DeductAccNo2"));
			deductDataList.add(deductData);
				
		}
		rs.close();
		if(deductDataList.size()>0)
		{
			//����ִ�в�ֳ���
			ArrayList<DeductData> returnDeductDataList = executeSplit(sumAmount,sKey,deductDataList,sIfDunFlag,sIsBadness);
			
			//����returnDeductDataList
			for(int i=0;i<returnDeductDataList.size();i++)
			{
				DeductData ReturnDeductData = returnDeductDataList.get(i);
				if((ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine())==0){
					continue;
				}
				psUpdateSql.setDouble(1,ReturnDeductData.getActualCurrentCorp());
				psUpdateSql.setDouble(2,ReturnDeductData.getActualDefaultCorp());
				psUpdateSql.setDouble(3,ReturnDeductData.getActualOverDueCorp());
				psUpdateSql.setDouble(4,ReturnDeductData.getActualInte());
				psUpdateSql.setDouble(5,ReturnDeductData.getActualInnerInte());
				psUpdateSql.setDouble(6,ReturnDeductData.getActualOutInte());
				psUpdateSql.setDouble(7,ReturnDeductData.getActualInnerInteFine());
				psUpdateSql.setDouble(8,ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(9, ReturnDeductData.getDeductAccNo2());
				psUpdateSql.setDouble(10, ReturnDeductData.getActualOverDueCorp()+ReturnDeductData.getActualInte()+ReturnDeductData.getActualInnerInte()+ReturnDeductData.getActualOutInte()+ReturnDeductData.getActualInnerInteFine()+ReturnDeductData.getActualOutInteFine());
				psUpdateSql.setString(11,ReturnDeductData.getPutOutNo());
				psUpdateSql.setInt(12,ReturnDeductData.getSTerm());
				psUpdateSql.setInt(13,ReturnDeductData.getAheadNum());
				psUpdateSql.setString(14,ReturnDeductData.getCurrency());
				psUpdateSql.addBatch();
				
				/*if(sSerialNo!=null && sSerialNo.length() != 0)
				{
					psDelSql.setString(1,sSerialNo);
					psDelSql.addBatch();
				}*/
				icount++;
			}
		}
		psUpdateSql.executeBatch();
		/*psDelSql.executeBatch();*/
		psUpdateSql.close();
		/*psDelSql.close();*/
		psSelectSql.close();
		psTempSql.close();
		
	}
	
	public void specialSplit1() throws Exception
	{	
		String selectDeductSql = " select PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,PayDefaultCorp,PayOverDueCorp,ActualOverDueCorp," +
		" PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte,PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine " +
		" from Deduct_Data " +
		" where putoutno = ? and  Sterm = ? and AheadNum = '0' ";
		PreparedStatement psDeductData = connection.prepareStatement(selectDeductSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = " select ap.SerialNo,ap.PutOutNo,ap.Currency,ap.PayType,ap.PayAmount,ap.ActualAmount1,ap.DeductAccNo,ap.RelativeAccNo, " +
				" ap.AheadSerialNo,ap.Sterm,ap.AmountAttribute " +
				" from as400_pams ap" +
				" where ap.amountattribute in ('"+BatchConstant.AMOUNTATTRIBUTE_FINE+"'," +
						" '"+BatchConstant.AMOUNTATTRIBUTE_INTE+"','"+BatchConstant.AMOUNTATTRIBUTE_CORP+"') and ap.ActualAmount1>0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sUpdate  = "";
				
			DeductData deductData = new DeductData();
			psDeductData.setString(1,rs.getString("PutOutNo"));
			psDeductData.setInt(2,rs.getInt("Sterm"));
			ResultSet DDrs = psDeductData.executeQuery();
			if(DDrs.next())
			{					
				deductData.setPutOutNo(DDrs.getString("PutOutNo"));
				deductData.setSTerm(DDrs.getInt("Sterm"));
				deductData.setAheadNum(DDrs.getInt("AheadNum"));
				deductData.setCurrency(DDrs.getString("Currency"));
				deductData.setPayCurrentCorp(DDrs.getDouble("PayCurrentCorp"));
				deductData.setPayDefaultCorp(DDrs.getDouble("PayDefaultCorp"));
				deductData.setPayOverDueCorp(DDrs.getDouble("PayOverDueCorp"));
				deductData.setActualOverDueCorp(DDrs.getDouble("ActualOverDueCorp"));
				deductData.setPayInte(DDrs.getDouble("PayInte"));
				deductData.setActualInte(DDrs.getDouble("ActualInte"));
				deductData.setPayInnerInte(DDrs.getDouble("PayInnerInte"));
				deductData.setActualInnerInte(DDrs.getDouble("ActualInnerInte"));
				deductData.setPayOutInte(DDrs.getDouble("PayOutInte"));
				deductData.setActualOutInte(DDrs.getDouble("ActualOutInte"));
				deductData.setPayInnerInteFine(DDrs.getDouble("PayInnerInteFine"));
				deductData.setActualInnerInteFine(DDrs.getDouble("ActualInnerInteFine"));
				deductData.setPayOutInteFine(DDrs.getDouble("PayOutInteFine"));
				deductData.setActualOutInteFine(DDrs.getDouble("ActualOutInteFine"));
			}
			DDrs.close();
				
			//��Ϣ
			if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_FINE))
			{
				String sFineSet = "";
				double dInnerInteFine=0.0d;
				double dOutInteFine = 0.0d;
				double actualAmount = rs.getDouble("ActualAmount1");
				if(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()>0)
				{
					dInnerInteFine = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(actualAmount-(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())):0;
					sFineSet = sFineSet+" ActualInnerInteFine = ActualInnerInteFine+"+dInnerInteFine;
				}
				if(deductData.getPayOutInteFine()>0)
				{
					dOutInteFine = actualAmount>deductData.getPayOutInteFine()?deductData.getPayOutInteFine():actualAmount;
					actualAmount = actualAmount>deductData.getPayOutInteFine()?(actualAmount-deductData.getPayOutInteFine()):0;
					if(sFineSet.length()>0||sFineSet!="")
					{
						sFineSet = sFineSet+" , ";
					}
					sFineSet = sFineSet+" ActualOutInteFine = ActualOutInteFine+"+dOutInteFine;
				}
				if(sFineSet.length()>0||sFineSet!="")
				{
					//�������ø���
					if(dOutInteFine==0&&dInnerInteFine==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sFineSet+",ActualAmount1 = ActualAmount1+'"+rs.getDouble("ActualAmount1")+"',DeductAccNo ='"+rs.getString("DeductAccNo")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
					
			}
			//��Ϣ
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_INTE))
			{
				String sInteSet = "";
				double dInnerInte=0.0d,dOutInte=0.0d,dInte=0.0d;
				double actualAmount = rs.getDouble("ActualAmount1");
				if(deductData.getPayInnerInte()-deductData.getActualInnerInte()>0)
				{
					dInnerInte = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(deductData.getPayInnerInte()-deductData.getActualInnerInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(actualAmount-(deductData.getPayInnerInte()-deductData.getActualInnerInte())):0;
					sInteSet = sInteSet+" ActualInnerInte = ActualInnerInte+"+dInnerInte;
				}
				if(deductData.getPayOutInte()-deductData.getActualOutInte()>0)
				{
					dOutInte = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(deductData.getPayOutInte()-deductData.getActualOutInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(actualAmount-(deductData.getPayOutInte()-deductData.getActualOutInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualOutInte = ActualOutInte+"+dOutInte;
				}
				if(deductData.getPayInte()-deductData.getActualInte()>0)
				{
					dInte = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(deductData.getPayInte()-deductData.getActualInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(actualAmount-(deductData.getPayInte()-deductData.getActualInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualInte = "+dInte;
				}
				if(sInteSet.length()>0||sInteSet!="")
				{
					if(dInnerInte==0&&dOutInte==0&&dInte==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sInteSet+",ActualAmount1 = ActualAmount1+'"+rs.getDouble("ActualAmount1")+"',DeductAccNo ='"+rs.getString("DeductAccNo")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
			}
			//����
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_CORP))
			{
				if(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp()==0){
					continue;
				}
				sUpdate = " Update Deduct_Data " +
				"set ActualOverDueCorp= ActualOverDueCorp+'"+rs.getDouble("ActualAmount1")+"',ActualAmount1 =ActualAmount1+ '"+rs.getDouble("ActualAmount1")+"',DeductAccNo ='"+rs.getString("DeductAccNo")+"' "+
				" where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
				" and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
			}

			if(sUpdate.length()> 10)
			{
				PreparedStatement psUpdate = connection.prepareStatement(sUpdate);
				psUpdate.execute();
				psUpdate.close();
			}
			
			/*psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.execute();*/
		}
		psDeductData.close();
		/*psDelSql.close();*/
		
	}
	public void specialSplit2() throws Exception
	{	
		String selectDeductSql = " select PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,PayDefaultCorp,PayOverDueCorp,ActualOverDueCorp," +
		" PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte,PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine " +
		" from Deduct_Data " +
		" where putoutno = ? and  Sterm = ? and AheadNum = '0' ";
		PreparedStatement psDeductData = connection.prepareStatement(selectDeductSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = " select ap.SerialNo,ap.PutOutNo,ap.Currency,ap.PayType,ap.PayAmount,ap.ActualAmount2,ap.DeductAccNo1,ap.RelativeAccNo, " +
				" ap.AheadSerialNo,ap.Sterm,ap.AmountAttribute " +
				" from as400_pams ap" +
				" where ap.amountattribute in ('"+BatchConstant.AMOUNTATTRIBUTE_FINE+"'," +
						" '"+BatchConstant.AMOUNTATTRIBUTE_INTE+"','"+BatchConstant.AMOUNTATTRIBUTE_CORP+"') and ap.ActualAmount2>0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sUpdate  = "";
				
			DeductData deductData = new DeductData();
			psDeductData.setString(1,rs.getString("PutOutNo"));
			psDeductData.setInt(2,rs.getInt("Sterm"));
			ResultSet DDrs = psDeductData.executeQuery();
			if(DDrs.next())
			{					
				deductData.setPutOutNo(DDrs.getString("PutOutNo"));
				deductData.setSTerm(DDrs.getInt("Sterm"));
				deductData.setAheadNum(DDrs.getInt("AheadNum"));
				deductData.setCurrency(DDrs.getString("Currency"));
				deductData.setPayCurrentCorp(DDrs.getDouble("PayCurrentCorp"));
				deductData.setPayDefaultCorp(DDrs.getDouble("PayDefaultCorp"));
				deductData.setPayOverDueCorp(DDrs.getDouble("PayOverDueCorp"));
				deductData.setActualOverDueCorp(DDrs.getDouble("ActualOverDueCorp"));
				deductData.setPayInte(DDrs.getDouble("PayInte"));
				deductData.setActualInte(DDrs.getDouble("ActualInte"));
				deductData.setPayInnerInte(DDrs.getDouble("PayInnerInte"));
				deductData.setActualInnerInte(DDrs.getDouble("ActualInnerInte"));
				deductData.setPayOutInte(DDrs.getDouble("PayOutInte"));
				deductData.setActualOutInte(DDrs.getDouble("ActualOutInte"));
				deductData.setPayInnerInteFine(DDrs.getDouble("PayInnerInteFine"));
				deductData.setActualInnerInteFine(DDrs.getDouble("ActualInnerInteFine"));
				deductData.setPayOutInteFine(DDrs.getDouble("PayOutInteFine"));
				deductData.setActualOutInteFine(DDrs.getDouble("ActualOutInteFine"));
			}
			DDrs.close();
				
			
			//��Ϣ
			if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_FINE))
			{
				String sFineSet = "";
				double dInnerInteFine=0.0d;
				double dOutInteFine = 0.0d;
				double actualAmount = rs.getDouble("ActualAmount2");
				if(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()>0)
				{
					dInnerInteFine = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(actualAmount-(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())):0;
					sFineSet = sFineSet+" ActualInnerInteFine = ActualInnerInteFine+"+dInnerInteFine;
				}
				if(deductData.getPayOutInteFine()>0)
				{
					dOutInteFine = actualAmount>deductData.getPayOutInteFine()?deductData.getPayOutInteFine():actualAmount;
					actualAmount = actualAmount>deductData.getPayOutInteFine()?(actualAmount-deductData.getPayOutInteFine()):0;
					if(sFineSet.length()>0||sFineSet!="")
					{
						sFineSet = sFineSet+" , ";
					}
					sFineSet = sFineSet+" ActualOutInteFine = ActualOutInteFine+"+dOutInteFine;
				}
				if(sFineSet.length()>0||sFineSet!="")
				{
					//�������ø���
					if(dOutInteFine==0&&dInnerInteFine==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sFineSet+",ActualAmount2 = ActualAmount2+'"+rs.getDouble("ActualAmount2")+"',DeductAccNo1 ='"+rs.getString("DeductAccNo1")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
					
			}
			//��Ϣ
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_INTE))
			{
				String sInteSet = "";
				double dInnerInte=0.0d,dOutInte=0.0d,dInte=0.0d;
				double actualAmount = rs.getDouble("ActualAmount2");
				if(deductData.getPayInnerInte()-deductData.getActualInnerInte()>0)
				{
					dInnerInte = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(deductData.getPayInnerInte()-deductData.getActualInnerInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(actualAmount-(deductData.getPayInnerInte()-deductData.getActualInnerInte())):0;
					sInteSet = sInteSet+" ActualInnerInte = ActualInnerInte+"+dInnerInte;
				}
				if(deductData.getPayOutInte()-deductData.getActualOutInte()>0)
				{
					dOutInte = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(deductData.getPayOutInte()-deductData.getActualOutInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(actualAmount-(deductData.getPayOutInte()-deductData.getActualOutInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualOutInte = ActualOutInte+"+dOutInte;
				}
				if(deductData.getPayInte()-deductData.getActualInte()>0)
				{
					dInte = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(deductData.getPayInte()-deductData.getActualInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(actualAmount-(deductData.getPayInte()-deductData.getActualInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualInte = "+dInte;
				}
				if(sInteSet.length()>0||sInteSet!="")
				{
					if(dInnerInte==0&&dOutInte==0&&dInte==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sInteSet+",ActualAmount2=ActualAmount2+'"+rs.getDouble("ActualAmount2")+"',DeductAccNo1 ='"+rs.getString("DeductAccNo1")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
			}
			//����
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_CORP))
			{
				if(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp()==0){
					continue;
				}
				sUpdate = " Update Deduct_Data " +
				"set ActualOverDueCorp= ActualOverDueCorp+'"+rs.getDouble("ActualAmount2")+"',ActualAmount2 =ActualAmount2+ '"+rs.getDouble("ActualAmount2")+"',DeductAccNo1 ='"+rs.getString("DeductAccNo1")+"' "+
				" where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
				" and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
			}
			
			if(sUpdate.length()> 10)
			{
				PreparedStatement psUpdate = connection.prepareStatement(sUpdate);
				psUpdate.execute();
				psUpdate.close();
			}
			
			/*psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.execute();*/
		}
		psDeductData.close();
		/*psDelSql.close();*/
		
	}
	public void specialSplit3() throws Exception
	{	
		String selectDeductSql = " select PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,PayDefaultCorp,PayOverDueCorp,ActualOverDueCorp," +
		" PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte,PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine " +
		" from Deduct_Data " +
		" where putoutno = ? and  Sterm = ? and AheadNum = '0' ";
		PreparedStatement psDeductData = connection.prepareStatement(selectDeductSql);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = " select ap.SerialNo,ap.PutOutNo,ap.Currency,ap.PayType,ap.PayAmount,ap.ActualAmount3,ap.DeductAccNo2,ap.RelativeAccNo, " +
				" ap.AheadSerialNo,ap.Sterm,ap.AmountAttribute " +
				" from as400_pams ap" +
				" where ap.amountattribute in ('"+BatchConstant.AMOUNTATTRIBUTE_FINE+"'," +
						" '"+BatchConstant.AMOUNTATTRIBUTE_INTE+"','"+BatchConstant.AMOUNTATTRIBUTE_CORP+"') and ap.ActualAmount1>0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sUpdate  = "";
				
			DeductData deductData = new DeductData();
			psDeductData.setString(1,rs.getString("PutOutNo"));
			psDeductData.setInt(2,rs.getInt("Sterm"));
			ResultSet DDrs = psDeductData.executeQuery();
			if(DDrs.next())
			{					
				deductData.setPutOutNo(DDrs.getString("PutOutNo"));
				deductData.setSTerm(DDrs.getInt("Sterm"));
				deductData.setAheadNum(DDrs.getInt("AheadNum"));
				deductData.setCurrency(DDrs.getString("Currency"));
				deductData.setPayCurrentCorp(DDrs.getDouble("PayCurrentCorp"));
				deductData.setPayDefaultCorp(DDrs.getDouble("PayDefaultCorp"));
				deductData.setPayOverDueCorp(DDrs.getDouble("PayOverDueCorp"));
				deductData.setActualOverDueCorp(DDrs.getDouble("ActualOverDueCorp"));
				deductData.setPayInte(DDrs.getDouble("PayInte"));
				deductData.setActualInte(DDrs.getDouble("ActualInte"));
				deductData.setPayInnerInte(DDrs.getDouble("PayInnerInte"));
				deductData.setActualInnerInte(DDrs.getDouble("ActualInnerInte"));
				deductData.setPayOutInte(DDrs.getDouble("PayOutInte"));
				deductData.setActualOutInte(DDrs.getDouble("ActualOutInte"));
				deductData.setPayInnerInteFine(DDrs.getDouble("PayInnerInteFine"));
				deductData.setActualInnerInteFine(DDrs.getDouble("ActualInnerInteFine"));
				deductData.setPayOutInteFine(DDrs.getDouble("PayOutInteFine"));
				deductData.setActualOutInteFine(DDrs.getDouble("ActualOutInteFine"));
			}
			DDrs.close();
				
			//��Ϣ
			if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_FINE))
			{
				String sFineSet = "";
				double dInnerInteFine=0.0d;
				double dOutInteFine = 0.0d;
				double actualAmount = rs.getDouble("ActualAmount3");
				if(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()>0)
				{
					dInnerInteFine = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())?(actualAmount-(deductData.getPayInnerInteFine()-deductData.getActualInnerInteFine())):0;
					sFineSet = sFineSet+" ActualInnerInteFine = ActualInnerInteFine+"+dInnerInteFine;
				}
				if(deductData.getPayOutInteFine()>0)
				{
					dOutInteFine = actualAmount>deductData.getPayOutInteFine()?deductData.getPayOutInteFine():actualAmount;
					actualAmount = actualAmount>deductData.getPayOutInteFine()?(actualAmount-deductData.getPayOutInteFine()):0;
					if(sFineSet.length()>0||sFineSet!="")
					{
						sFineSet = sFineSet+" , ";
					}
					sFineSet = sFineSet+" ActualOutInteFine = ActualOutInteFine+"+dOutInteFine;
				}
				if(sFineSet.length()>0||sFineSet!="")
				{
					//�������ø���
					if(dOutInteFine==0&&dInnerInteFine==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sFineSet+",ActualAmount3 = ActualAmount3+'"+rs.getDouble("ActualAmount3")+"',DeductAccNo2 ='"+rs.getString("DeductAccNo2")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
					
			}
			//��Ϣ
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_INTE))
			{
				String sInteSet = "";
				double dInnerInte=0.0d,dOutInte=0.0d,dInte=0.0d;
				double actualAmount = rs.getDouble("ActualAmount3");
				if(deductData.getPayInnerInte()-deductData.getActualInnerInte()>0)
				{
					dInnerInte = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(deductData.getPayInnerInte()-deductData.getActualInnerInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInnerInte()-deductData.getActualInnerInte())?(actualAmount-(deductData.getPayInnerInte()-deductData.getActualInnerInte())):0;
					sInteSet = sInteSet+" ActualInnerInte = ActualInnerInte+"+dInnerInte;
				}
				if(deductData.getPayOutInte()-deductData.getActualOutInte()>0)
				{
					dOutInte = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(deductData.getPayOutInte()-deductData.getActualOutInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayOutInte()-deductData.getActualOutInte())?(actualAmount-(deductData.getPayOutInte()-deductData.getActualOutInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualOutInte = ActualOutInte+"+dOutInte;
				}
				if(deductData.getPayInte()-deductData.getActualInte()>0)
				{
					dInte = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(deductData.getPayInte()-deductData.getActualInte()):actualAmount;
					actualAmount = actualAmount>(deductData.getPayInte()-deductData.getActualInte())?(actualAmount-(deductData.getPayInte()-deductData.getActualInte())):0;
					if(sInteSet.length()>0||sInteSet!="")
					{
						sInteSet = sInteSet+" , ";
					}
					sInteSet = sInteSet+" ActualInte = "+dInte;
				}
				if(sInteSet.length()>0||sInteSet!="")
				{
					if(dInnerInte==0&&dOutInte==0&&dInte==0){
						continue;
					}
					sUpdate = " Update Deduct_Data set "+sInteSet+",ActualAmount3=ActualAmount3+'"+rs.getDouble("ActualAmount2")+"',DeductAccNo2 ='"+rs.getString("DeductAccNo2")+"' "+
						   " where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
						   " and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
				}
			}
			//����
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_CORP))
			{
				if(deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp()==0){
					continue;
				}
				sUpdate = " Update Deduct_Data " +
				"set ActualOverDueCorp= ActualOverDueCorp+'"+rs.getDouble("ActualAmount3")+"',ActualAmount3 =ActualAmount3+ '"+rs.getDouble("ActualAmount3")+"',DeductAccNo2 ='"+rs.getString("DeductAccNo2")+"' "+
				" where  putoutno = '"+rs.getString("PutOutNo")+"' and Sterm = '"+rs.getInt("Sterm")+"'" +
				" and AheadNum = '0' and Currency = '"+rs.getString("Currency")+"' ";
			}

			if(sUpdate.length()> 10)
			{
				PreparedStatement psUpdate = connection.prepareStatement(sUpdate);
				psUpdate.execute();
				psUpdate.close();
			}
			
			/*psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.execute();*/
		}
		psDeductData.close();
		/*psDelSql.close();*/
		
	}
	
	public void specialDataSplit() throws Exception
	{
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = " select ap.SerialNo,ap.PutOutNo,ap.Currency,ap.PayType,ap.PayAmount,ap.ActualAmount,ap.DeductAccNo,ap.RelativeAccNo, " +
				" ap.AheadSerialNo,ap.Sterm,ap.AmountAttribute " +
				" from as400_pams ap" +
				" where ap.amountattribute in ('"+BatchConstant.AMOUNTATTRIBUTE_XBFARE+"','"+BatchConstant.AMOUNTATTRIBUTE_AHEADCORP+"', " +
							" '"+BatchConstant.AMOUNTATTRIBUTE_AHEAD_XBFARE+"' ) and ap.ActualAmount>0";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sUpdate  = "";
				
			//����
			if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_XBFARE))
			{
				sUpdate = " update fare_detail " +
						" set ActualMoney = ActualMoney+'"+rs.getDouble("ActualAmount")+"',accdate = '"+deductDate+"' " +
						" where putoutno = '"+rs.getString("PutOutNo")+"' and " +
						" paydate in " +
						" (select paydate from loanback_status where putoutno = '"+rs.getString("PutOutNo")+"' and aheadnum = '0' and sterm = '"+rs.getInt("Sterm")+"') ";
			}
			
			//��ǰ�����
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_AHEADCORP))
			{
				if(rs.getDouble("ActualAmount")>0)
				{
					sUpdate = " update Ahead_Deduct_Data  " +
							" set ActualCurrentCorp=PayCurrentCorp,ActualInte=PayInte,ActualPoundage=PayPoundage,Actualfareamount=Payfareamount " +
							" where ChangeSerialNo='"+rs.getString("AheadSerialNo")+"' ";
				}
				else
					sUpdate = "";
			}
			//��ǰ�����
			//��Ϊ��ǰ����Ѳ����ʱ��Fare_Detail��������´λ����գ����ܵ�ʱ���ղ������ѣ����Խ�paydate��Ϊ >=
			else if(rs.getString("AmountAttribute").equals(BatchConstant.AMOUNTATTRIBUTE_AHEAD_XBFARE))
			{
				if(rs.getDouble("ActualAmount")>0)
				{
					sUpdate = " update fare_detail " +
							" set ActualMoney = PayMoney,OffFlag = '1',accdate = '"+deductDate+"'  " +
							" where putoutno = '"+rs.getString("PutOutNo")+"' and paydate >= '"+deductDate+"' ";
				}
			}
			
			if(sUpdate.length()> 10)
			{
				PreparedStatement psUpdate = connection.prepareStatement(sUpdate);
				psUpdate.execute();
				psUpdate.close();
			}
			
			psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.execute();
		}
		psDelSql.close();
	}
	
	//��ʼ��
	public void initProductCondition() throws SQLException
	{
		productConditionHashMap = new HashMap<String,ProductCondition>();
		
		String tempSql = " select TypeNo,OrgID,LoanStatus,PaySeq,PaySubjectSeq from product_condition order by TypeNo,OrgID,LoanStatus ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		ResultSet rs = psTempSql.executeQuery();
		while(rs.next())
		{
			String sKey = rs.getString("TypeNo")+rs.getString("OrgID")+rs.getString("LoanStatus");
			
			ProductCondition productCondition = new ProductCondition();
			productCondition.setTypeNo(rs.getString("TypeNo"));
			productCondition.setOrgID(rs.getString("OrgID"));
			productCondition.setLoanStatus(rs.getString("LoanStatus"));
			productCondition.setPaySeq(rs.getString("PaySeq"));
			productCondition.setPaySubjectSeq(rs.getString("PaySubjectSeq"));
			
			productConditionHashMap.put(sKey,productCondition);
		}
		rs.getStatement().close();
		psTempSql.close();
	}
	
	public ArrayList<DeductData> executeSplit(double sumAmount,String sKey,ArrayList<DeductData> deductDataList,String sIfDunFlag,String sIsBadness)
	{
		String sPortraitFlag = getportraitFlag(sKey,"portraitFlag");
		//��ȡ��Ŀ�ۿ�˳��
		String slandFlag = getportraitFlag(sKey,"landFlag");
		
		if(sIfDunFlag==null)
		{
			sIfDunFlag="0";
		}
		if(sIsBadness==null)
		{
			sIsBadness="0";
		}
		if(sIsBadness.equals("1"))
		{
			sPortraitFlag="2";
			slandFlag="Corp@Inte@Fine";	
		}
		//���ò�ֳ��򣬷���DedcutData��list
		AmountSplit amoountSplit = new AmountSplit();
		
		return  amoountSplit.splitAmount(sumAmount,deductDataList,sPortraitFlag,slandFlag);
	}
	
	public DeductData executeSplitDeductData(double sumAmount,String sKey,DeductData deductData,String sIfDunFlag,String sIsBadness)
	{
		String sPortraitFlag = getportraitFlag(sKey,"portraitFlag");
		//��ȡ��Ŀ�ۿ�˳��
		String slandFlag = getportraitFlag(sKey,"landFlag");
		
		if(sIfDunFlag==null)
		{
			sIfDunFlag="0";
		}
		if(sIsBadness==null)
		{
			sIsBadness="0";
		}
		if(sIsBadness.equals("1"))
		{
			sPortraitFlag="2";
			slandFlag="Corp@Inte@Fine";	
		}
		
		AmountDeductSplit amoountSplit = new AmountDeductSplit();
		
		return  amoountSplit.splitAmount(sumAmount,deductData,sPortraitFlag,slandFlag);
	}
	
	//��ȡ�ۿ���ԺͿ�Ŀ�ۿ�˳��
	public String getportraitFlag(String sKey,String returnType)
	{
		ProductCondition productCon = productConditionHashMap.get(sKey);
		if(productCon == null)
		{
			if(returnType.equalsIgnoreCase("portraitFlag"))
			{
				return "1";
			}
			else
			{
				return "Fine@Inte@Corp";
			}
		}
		else
		{
			String sPaySeq = productCon.getPaySeq();
			String sPaySubjectSeq = productCon.getPaySubjectSeq();
			
			if(returnType.equalsIgnoreCase("portraitFlag"))
			{
				if(sPaySeq.equals("1"))
					return "1";
				else
					return "2";
			}
			else{
				if(sPaySubjectSeq.equals("1")) // ����--->��Ϣ--->��Ϣ
					return "Corp@Inte@Fine";
				else if(sPaySubjectSeq.equals("2"))// ��Ϣ--->��Ϣ--->����
					return "Fine@Inte@Corp";
				else if(sPaySubjectSeq.equals("3"))//����--->��Ϣ--->��Ϣ
					return "Corp@Fine@Inte";
				else if(sPaySubjectSeq.equals("4"))//��Ϣ--->����--->��Ϣ
					return "Fine@Corp@Inte";
				else if(sPaySubjectSeq.equals("5"))//��Ϣ--->��Ϣ--->����
					return "Inte@Fine@Corp";
				else
					return "Inte@Corp@Fine";	//��Ϣ--->����--->��Ϣ
			}
		}
	}
	
	public double updateFareDetail(String putoutno,String feeType,double paymoney,double actualmoney,double sumAmount,String paydate) throws Exception{
		String updateFareDetailSql=" update FARE_DETAIL set ActualMoney = ActualMoney+?,AccDate=?,OffFlag = ? where PutOutNo = ? and PayDate = ? "; 
		PreparedStatement psUpdateFareDetailSql = connection.prepareStatement(updateFareDetailSql);
		double sum = paymoney-actualmoney;
		AcctFeeInfo acctFeeInfo = AcctFeeInfo.createAcctFeeInfo(putoutno, connection);
		if(sumAmount-sum>=0){
			acctFeeInfo.setFeeBalance(sum);
			sumAmount = sumAmount - sum;
			psUpdateFareDetailSql.setDouble(1,sum);
			psUpdateFareDetailSql.setString(2, deductDate);
			psUpdateFareDetailSql.setString(3,"1");
			psUpdateFareDetailSql.setString(4,putoutno);
			psUpdateFareDetailSql.setString(5,paydate);
			psUpdateFareDetailSql.addBatch();
		}else{
			acctFeeInfo.setFeeBalance(sumAmount);
			sumAmount = 0.0;
			psUpdateFareDetailSql.setDouble(1,sumAmount);
			psUpdateFareDetailSql.setString(2, deductDate);
			psUpdateFareDetailSql.setString(3,"0");
			psUpdateFareDetailSql.setString(4,putoutno);
			psUpdateFareDetailSql.setString(5,paydate);
			psUpdateFareDetailSql.addBatch();
		}
		if(acctFeeInfo.getFeeBalance()>0){			
			TransFareSW transFareSW = new TransFareSW();
			transFareSW.transFeeAcc(acctFeeInfo, connection);
		}
		
		psUpdateFareDetailSql.executeBatch();
		return sumAmount;
	}
	

	
	private String createFareSerialNo() throws Exception
	{
		iFareSerialNo++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iFareSerialNo,8,'0');
		return "B"+sDate+"200103"+sSortNo;
	}
	

}
