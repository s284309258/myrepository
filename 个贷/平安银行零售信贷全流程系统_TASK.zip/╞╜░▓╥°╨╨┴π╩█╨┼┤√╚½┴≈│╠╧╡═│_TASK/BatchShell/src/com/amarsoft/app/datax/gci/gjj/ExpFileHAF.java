package com.amarsoft.app.datax.gci.gjj;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.task.TaskConstants;


/**                                                                                                                             
 * ����BtoX�ļ�
 * @author XIATIAN020
 * @since 2012-06-09                                                                                                                              
 */
public class ExpFileHAF extends CommonExecuteUnit {

	private String NASUrl;//NAS�ռ�
	private String fileName; //�ļ�����
	private String fileUrl;//�ļ�·��
	private String separator; //�ָ���
	private String recordSet;//������Դ
	private String fixFlag;//�Ƿ񶨳�
	private String megType;//��Ϣ���� 
	private String frequency;//Ƶ�� D ÿ�� M ÿ�� Y ÿ��
	private int no = 0;
	private String firstSeparatorIsShow;//�Ƿ����ɵ�һ��һ���ָ���

	public int execute() {
		try {
			String sInit = super.init();      
			if (sInit.equalsIgnoreCase("skip")) {
				unitStatus = TaskConstants.ES_SUCCESSFUL;
			} else {
			    initPara();
			    
			    if("D".equals(frequency) || "M".equals(frequency) && this.nextDate.endsWith("01") || "Y".equals(frequency) && this.nextDate.endsWith("01/01"))
			    {
				    logger.info("��ʼ"+megType+"�ļ�...");
	                ExportFile();
	                logger.info("����"+megType+"����...");
			    }
				
                unitStatus = TaskConstants.ES_SUCCESSFUL;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
		} finally {
			clearResource();
			return unitStatus;
		}
	}

	public void initPara() throws Exception{
		NASUrl = ARE.getProperty("NASUrl");
		fileUrl = this.getProperty("FileUrl");
		fileName = this.getProperty("FileName");
		recordSet = this.getProperty("RecordSet");
		fixFlag = this.getProperty("FixFlag","N");
		megType = this.getProperty("MegType");
		frequency = this.getProperty("frequency","D");
		no = 0;
		firstSeparatorIsShow = this.getProperty("FirstSeparatorIsShow","yes");
	
		
		String sDate = StringFunction.replace(deductDate,"/","");
		String sMonth = StringFunction.replace(currentMonth,"/","");
		String sLastDate = StringFunction.replace(lastDate,"/","");
		String sLastMonth = StringFunction.replace(lastMonth,"/","");
		
		
		fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
		fileUrl=StringFunction.replace(fileUrl,"{$CurrentMonth}",sMonth);
		fileUrl=StringFunction.replace(fileUrl,"{$LastDate}",sLastDate);
		fileUrl=StringFunction.replace(fileUrl,"{$LastMonth}",sLastMonth);
		fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
		fileName=StringFunction.replace(fileName,"{$CurrentMonth}",sMonth);
		fileName=StringFunction.replace(fileName,"{$LastDate}",sLastDate);
		fileName=StringFunction.replace(fileName,"{$LastMonth}",sLastMonth);
		recordSet=StringFunction.replace(recordSet,"{$CurrentDate}",this.deductDate);
		recordSet=StringFunction.replace(recordSet,"{$CurrentMonth}",this.currentMonth);
		recordSet=StringFunction.replace(recordSet,"{$LastDate}",this.lastDate);
		recordSet=StringFunction.replace(recordSet,"{$LastMonth}",this.lastMonth);
	}
	
	//�ļ���ʽ����
	public void exportResultSet(String sql,TableMetaData tableMetaData,PrintWriter outputstreamwriter) throws Exception{
		separator = this.getProperty("separator");
		Statement stm = connection.createStatement();
		ResultSet rs=stm.executeQuery(sql);
		int rowNum=0;
		while(rs.next()){
			String s=separator;
			if(firstSeparatorIsShow.equalsIgnoreCase("no"))
			{
				s="";
			}
			rowNum++;
			for(int i=1;i<=tableMetaData.getColumnCount();i++){
				ColumnMetaData columnMetaData= tableMetaData.getColumn(i);
				s+=getFieldValue(columnMetaData,rs)+separator;
			}
			s+="\n";
			outputstreamwriter.write(s);
		}
		rs.close();
		stm.close();
	}
	
	//�ֶ����Ϳ���
	public String getFieldValue(ColumnMetaData columnMetaData,ResultSet rs) throws Exception{
		String sType = columnMetaData.getTypeName();
		int iDisplaySize = columnMetaData.getDisplaySize();
		int iPrecision = columnMetaData.getPrecision();
		int iScale = columnMetaData.getScale();
		String format = columnMetaData.getFormat();
		String value = "";
		if(sType.equals("INT")){
			value = String.valueOf(rs.getInt(columnMetaData.getName()));
			int len = value.length();
			if("Y".equals(fixFlag))
			{
				for(int i=0;i<iDisplaySize-len;i++)
		        {
		        	value = " "+value;
		        }
			}
		}
		else if(sType.equals("DATE")){
			value = DataConvert.toString(rs.getString(columnMetaData.getName()));
			if(!"".equals(value))
			{
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd");
				Date now = sdf.parse(DataConvert.toString(value).trim());
				SimpleDateFormat sdf1=new SimpleDateFormat(format);
				value = sdf1.format(now);
			}
			if("Y".equals(fixFlag))
			{
				int len = value.length();
				for(int i=0;i<iDisplaySize-len;i++){
		        	value=value + " ";
		    	}
			}
		}
		else if(sType.equals("DOUBLE")){
			NumberFormat nf = NumberFormat.getInstance();
			nf.setMinimumFractionDigits(columnMetaData.getScale())  ;
			nf.setMaximumFractionDigits(columnMetaData.getScale())  ;
			value = nf.format(rs.getDouble(columnMetaData.getName())).replaceAll(",", "");
			
			if("Y".equals(fixFlag))
			{
				int len = value.length();
				for(int i=0;i<iDisplaySize-len;i++)
		        {
		        	value = " "+value;
		        }
			}
		}
		else
		{
			value = DataConvert.toString(rs.getString(columnMetaData.getName()));
			if("${SerialNo}".equals(format)) value = getSerialNo(iDisplaySize);
			if("Y".equals(fixFlag))
			{
				int len = 0;
				for(int j=0;j<value.length(); j++)
				{
					char a = value.charAt(j);
					if(a >= 256)
					{
						len +=2;
					}
					else
					{
						len +=1;
					}
				}
		        for(int i=0;i<iDisplaySize-len;i++){
		        	value=value + " ";
		    	}
			}
		}
		return value;
	}
	
	public void ExportFile() throws Exception {
		
		/*����NAS�ռ�*/
		fileUrl = NASUrl + fileUrl;
		File file = new File(fileUrl);
		if (!file.exists()) {
			file.mkdirs();
		}
		/*�ļ�ȫ·��*/
		String FileFullName = fileUrl + fileName;
		PrintWriter outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(FileFullName), "GBK")), true);
		String[] recordSetarr = recordSet.split("@");
		for (int i=0;i<recordSetarr.length;i++)
		{
			String[] rsarr = recordSetarr[i].split(":");
			String sDataSource = rsarr[0];
			String sTableSource = rsarr[1];
			String sSql = rsarr[2];
			exportResultSet(sSql, ARE.getMetaData(sDataSource).getTable(sTableSource), outputstreamwriter);
		}
		outputstreamwriter.close();
	}
	
	
	public String getSerialNo(int iDisplaySize) throws Exception
	{
		no++;
		return deductDate.substring(8,10)+NumberTools.lPad(no, iDisplaySize-2, '0');
	}
}