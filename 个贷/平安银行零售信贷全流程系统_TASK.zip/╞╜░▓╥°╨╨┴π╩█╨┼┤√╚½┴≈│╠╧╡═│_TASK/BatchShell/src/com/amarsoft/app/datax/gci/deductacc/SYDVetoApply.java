package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class SYDVetoApply extends CommonExecuteUnit {

	@Override
	public int execute() {
		// TODO Auto-generated method stub
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ�������״�����ʧЧ�������...");
				updateOneDayStatus();
				logger.info("��ʼ�������״�����ʧЧ���������ɣ�");
				
				logger.info("��ʼ�������״�һ����ʧЧ�������...");
				updateOneMonthStatus();
				logger.info("��ʼ�������״�һ����ʧЧ���������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	
	private void updateOneDayStatus() throws Exception{
		//����BP��״̬
		String sql="update BUSINESS_PUTOUT bp set bp.PUTOUTSTATUS = '6' "
			+" where bp.SERIALNO in (select SYD_BUSINESS_PUTOUT_TEMP.SERIALNO "
			+" from SYD_BUSINESS_PUTOUT_TEMP "
			+" where SYD_BUSINESS_PUTOUT_TEMP.PASS_TIME = '"+deductDate+"' "
			+" and SYD_BUSINESS_PUTOUT_TEMP.STATUS_CODE = '020')"; 
		//����SYD_BUSINESS_PUTOUT_TEMP��״̬
		String sql2="update SYD_BUSINESS_PUTOUT_TEMP set STATUS_CODE='080' where PASS_TIME='"+deductDate+"' and STATUS_CODE='020'";
		logger.info("sql1 "+sql);
		logger.info("sql2 "+sql2);
		PreparedStatement psQuerySql  = null;
			psQuerySql = connection.prepareStatement(sql);
			psQuerySql.executeUpdate();
			psQuerySql = connection.prepareStatement(sql2);
			psQuerySql.executeUpdate();
			if(psQuerySql != null){
				psQuerySql.close();
			}
	}
	
private void updateOneMonthStatus() throws Exception{
		//����BP��״̬  
		String sql="update BUSINESS_PUTOUT bp set bp.PUTOUTSTATUS = '6' "
			+" where bp.SERIALNO in (select SYD_BUSINESS_PUTOUT_TEMP.SERIALNO "
			+" from SYD_BUSINESS_PUTOUT_TEMP "
			+" where SYD_BUSINESS_PUTOUT_TEMP.PASS_TIME = '"+DateTools.getRelativeDate(deductDate, "M", -1)+"' "
			+" and SYD_BUSINESS_PUTOUT_TEMP.STATUS_CODE = '040')"; 
		//����SYD_BUSINESS_PUTOUT_TEMP��״̬
		String sql2="update SYD_BUSINESS_PUTOUT_TEMP set STATUS_CODE='080' where PASS_TIME='"+DateTools.getRelativeDate(deductDate, "M", -1)+"' and STATUS_CODE='040'";
		logger.info("sql3 "+sql);
		logger.info("sql2 "+sql2);
		PreparedStatement psQuerySql = null;
			psQuerySql = connection.prepareStatement(sql);
			psQuerySql.executeUpdate();
			psQuerySql = connection.prepareStatement(sql2);
			psQuerySql.executeUpdate();
			if(psQuerySql != null){
				psQuerySql.close();
			}
	}
}
