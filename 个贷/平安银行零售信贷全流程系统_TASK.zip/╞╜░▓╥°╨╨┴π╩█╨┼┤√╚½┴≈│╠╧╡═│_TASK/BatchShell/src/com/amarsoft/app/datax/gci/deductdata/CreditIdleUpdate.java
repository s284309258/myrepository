package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;
 

public class CreditIdleUpdate extends CommonExecuteUnit {
	
	private int iSerialCount = 0;

	public int execute() {
		try {
			String sInit = super.init();
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				if(deductDate.endsWith("01")){
					logger.info("��ʼ������");
					String delSql = " delete from CREDIT_IDLE where OccurTime = '"+lastDate+"' ";
					PreparedStatement psdelSql = connection.prepareStatement(delSql);
					psdelSql.execute();
					psdelSql.close();
					getCreditIdleContract();
					updateOtherCol();
					logger.info("��ɡ�����");
					unitStatus = TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}else{	
					System.out.println("����ĩ���գ����ܴ�������");
					unitStatus = TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
                    }
			}
		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public String createSerialNo(String deductDate) throws Exception
	{
		iSerialCount++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iSerialCount,8,'0');
		return "CI"+sDate+sSortNo;
	}

	public void getCreditIdleContract() throws SQLException {
		
		String delOldSql= " delete from CREDIT_IDLE where IdleFlag = '0' ";
		PreparedStatement psdelSql = connection.prepareStatement(delOldSql);
		psdelSql.execute();
		psdelSql.close();

		// ����CREDIT_IDLE
		String insertSql = " insert into CREDIT_IDLE(SerialNo,BusinessType,CustomerID,CustomerName,BusinessSum,Currency,OperateUserID,IdleFlag," +
				" ContractSerialNo,ApplyType,FinalCheckDate,OperateDate,BankFlag,OccurTime) "
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		
		// ��ǩ��ͬ��һ����δ֧�ö�ȵ�ҵ��
		String sql1 = "select SerialNo,BusinessType,CustomerID,CustomerName,BusinessSum,Currency,OperateUserID,ApplyType,InputDate,OperateDate,BankFlag from BUSINESS_CONTRACT BC "
				+ " where ApproveResult = '020' and  (ActualPutOutSum is null or ActualPutOutSum = 0.0) and"
				+ "(to_date('"+ deductDate + "','yyyy-mm-dd')- to_date(ApproveDate,'yyyy-mm-dd')) < 7 and BusinessKind = 'SWPM'";

		// ����ͨ����һ�����������ڣ�������������δǩ��ͬҵ��
		String sql2 = "select SerialNo,BusinessType,CustomerID,CustomerName,BusinessSum,Currency,OperateUserID,ApplyType,InputDate,OperateDate,BankFlag from BUSINESS_CONTRACT BC "
				+ " where ApproveResult = '010' and  (to_date('"+ deductDate+ "','yyyy-mm-dd')- to_date(InputDate,'yyyy-mm-dd')) > 0 "
				+ "and (to_date('"+ deductDate + "','yyyy-mm-dd')- to_date(InputDate,'yyyy-mm-dd')) < 150 and BusinessKind = 'SWPM'";

		// ��ǩ���ͬ����ѭ����Ȳ���֧ȡ�����ҵ�񡣲���֧ȡ��ָ�������ȡ���� < ���ʣ�����ޱ�����
		// ���� �����ȡ���� = ����ۼ���ȡ��� / ����ܽ�� ��
		//    ʣ�����ޱ��� = ���ʣ������ / ���������	
		String sql3 = "select  SerialNo,BusinessType,CustomerID,CustomerName,BusinessSum,Currency,OperateUserID,ApplyType,InputDate,OperateDate,BankFlag from BUSINESS_CONTRACT BC  where (bc.cycleflag = '0' and PutOutType = '030'  and PutOutDate is not null) and BusinessKind = 'SWPM' and Businesssum Is Not Null And Businesssum <> 0.0 and (((to_date(MaturityDate,'yyyy-mm-dd')) - (to_date('"+ lastDate + "','yyyy-mm-dd')))/((to_date(MaturityDate,'yyyy-mm-dd')) - (to_date(PutOutDate,'yyyy-mm-dd')))) >(BusinessSum - (select SUM(businesssum) from business_contract where relativecreditNo = bc.serialno)/BusinessSum) ";
		logger.info("sql��䣺-------" + sql1);
		logger.info("sql2��䣺-------" + sql2);
		logger.info("sql3��䣺-------" + sql3);

		PreparedStatement psInsertSql1 = connection.prepareStatement(insertSql);
		PreparedStatement psInsertSql2 = connection.prepareStatement(insertSql);
		PreparedStatement psInsertSql3 = connection.prepareStatement(insertSql);

		PreparedStatement psSelectSql1 = connection.prepareStatement(sql1);
		ResultSet rs1 = psSelectSql1.executeQuery();
		PreparedStatement psSelectSql2 = connection.prepareStatement(sql2);
		ResultSet rs2 = psSelectSql2.executeQuery();
		PreparedStatement psSelectSql3 = connection.prepareStatement(sql3);
		ResultSet rs3 = psSelectSql3.executeQuery();
		if (rs1.next() || rs2.next() || rs3.next()) {
			try {
				while (rs1.next()) {
					String SerialNo = this.createSerialNo(deductDate);
					psInsertSql1.setString(1, SerialNo);
					psInsertSql1.setString(2, rs1.getString("BusinessType"));
					psInsertSql1.setString(3, rs1.getString("CustomerID"));
					psInsertSql1.setString(4, rs1.getString("CustomerName"));
					psInsertSql1.setDouble(5, rs1.getDouble("BusinessSum"));
					psInsertSql1.setString(6, rs1.getString("Currency"));
					psInsertSql1.setString(7, rs1.getString("OperateUserID"));
					psInsertSql1.setString(8, "0");
					psInsertSql1.setString(9, rs1.getString("SerialNo"));
					psInsertSql1.setString(10, rs1.getString("ApplyType"));
					psInsertSql1.setString(11, rs1.getString("InputDate"));
					psInsertSql1.setString(12, rs1.getString("OperateDate"));
					psInsertSql1.setString(13, rs1.getString("BankFlag"));
					psInsertSql1.setString(14, lastDate);
					psInsertSql1.addBatch();
				}
				rs1.close();
				psInsertSql1.executeBatch();
				psInsertSql1.close();
				psSelectSql1.close();


				while (rs2.next()) {
					String SerialNo = this.createSerialNo(deductDate);
					psInsertSql2.setString(1, SerialNo);
					psInsertSql2.setString(2, rs2.getString("BusinessType"));
					psInsertSql2.setString(3, rs2.getString("CustomerID"));
					psInsertSql2.setString(4, rs2.getString("CustomerName"));
					psInsertSql2.setDouble(5, rs2.getDouble("BusinessSum"));
					psInsertSql2.setString(6, rs2.getString("Currency"));
					psInsertSql2.setString(7, rs2.getString("OperateUserID"));
					psInsertSql2.setString(8, "0");
					psInsertSql2.setString(9, rs2.getString("SerialNo"));
					psInsertSql2.setString(10, rs2.getString("ApplyType"));
					psInsertSql2.setString(11, rs2.getString("InputDate"));
					psInsertSql2.setString(12, rs2.getString("OperateDate"));
					psInsertSql2.setString(13, rs2.getString("BankFlag"));
					psInsertSql2.setString(14, lastDate);
					psInsertSql2.addBatch();
				}
				rs2.close();
				psInsertSql2.executeBatch();
				psInsertSql2.close();
				psSelectSql2.close();

				
				while (rs3.next()) {
					String SerialNo = this.createSerialNo(deductDate);
					psInsertSql3.setString(1, SerialNo);
					psInsertSql3.setString(2, rs3.getString("BusinessType"));
					psInsertSql3.setString(3, rs3.getString("CustomerID"));
					psInsertSql3.setString(4, rs3.getString("CustomerName"));
					psInsertSql3.setDouble(5, rs3.getDouble("BusinessSum"));
					psInsertSql3.setString(6, rs3.getString("Currency"));
					psInsertSql3.setString(7, rs3.getString("OperateUserID"));
					psInsertSql3.setString(8, "0");
					psInsertSql3.setString(9, rs3.getString("SerialNo"));
					psInsertSql3.setString(10, rs3.getString("ApplyType"));
					psInsertSql3.setString(11, rs3.getString("InputDate"));
					psInsertSql3.setString(12, rs3.getString("OperateDate"));
					psInsertSql3.setString(13, rs3.getString("BankFlag"));
					psInsertSql3.setString(14, lastDate);
					psInsertSql3.addBatch();
				}
				rs3.close();
				psInsertSql3.executeBatch();
				psInsertSql3.close();
				psSelectSql3.close();
			} catch (Exception ex) {
					ex.printStackTrace();
			}finally{
				if(psInsertSql1!=null)  psInsertSql1.close();
				if(psInsertSql2!=null)  psInsertSql2.close();
				if(psInsertSql3!=null)  psInsertSql3.close();
				if(psSelectSql1!=null) psSelectSql1.close();
				if(psSelectSql2!=null) psSelectSql2.close();
				if(psSelectSql3!=null) psSelectSql3.close();
			}
		}
	}
	public void updateOtherCol() throws SQLException{
		String sCustomerPhone = "",sCustomerID = "",BankFlag = "",sSerialNo = "";
		String sSaleManageName = "",sOperateUserID = "";
		String sSMWorkTel = "",sCertType = "",sCertID = "";
		String sSMPhone = "";
		String sql = "Select SerialNo,CustomerID,BankFlag,OperateUserID from CREDIT_IDLE";
		System.out.println("sql==========" + sql);
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
			sSerialNo=DataConvert.toString(rs.getString("SerialNo"));
			sCustomerID=DataConvert.toString(rs.getString("CustomerID"));
			BankFlag=DataConvert.toString(rs.getString("BankFlag"));
			sOperateUserID=DataConvert.toString(rs.getString("OperateUserID"));
			if(BankFlag.equals("PAB")){
			String sql1 = "Select MobileTelePhone,CertType,CertID from Ind_Info where CustomerID = '" + sCustomerID  + "'";
			String sql11 = "Select SalerName,Phone,WorkTel from SALE_MANAGER where SerialNo = '" + sOperateUserID + "'";
			PreparedStatement ps1 = connection.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery();
			if(rs1.next()){
			sCustomerPhone =  DataConvert.toString(rs1.getString("MobileTelePhone"));
			sCertType =  DataConvert.toString(rs1.getString("CertType"));
			sCertID =  DataConvert.toString(rs1.getString("CertID"));

			
			}
			if(sCustomerPhone == null) sCustomerPhone = "";	
			if(sCertType == null) sCertType = "";				 
			if(sCertID == null) sCertID = "";				 

			PreparedStatement ps11 = connection.prepareStatement(sql11);
			ResultSet rs11=ps11.executeQuery();
			if(rs11.next()){
			sSaleManageName =  DataConvert.toString(rs11.getString("SalerName"));
			sSMWorkTel =  DataConvert.toString(rs11.getString("WorkTel"));
			sSMPhone =  DataConvert.toString(rs11.getString("Phone"));}
			if(sSaleManageName == null) sSaleManageName = "";
			if(sSMWorkTel == null) sSMWorkTel = "";
			if(sSMPhone == null) sSMPhone = "";


							 
			String updatesql="update CREDIT_IDLE set CustomerPhone ='"+sCustomerPhone+"',SMName = '"+sSaleManageName+
							 "',SMPhone = '"+sSMPhone+"',SMWorkTel = '"+sSMWorkTel+"',CustomerCertType = '"+sCertType+
							 "',CustomerCertID = '"+sCertID+"' where SerialNo='"+sSerialNo+"'";
			PreparedStatement ps2 = connection.prepareStatement(updatesql);
			ps2.execute();
			ps2.close();
			rs1.close();
			ps1.close();
			rs11.close();
			ps11.close();
			}else{
				String sql11 = "Select SalerName,Phone,WorkTel from SALE_MANAGER where SerialNo = '" + sOperateUserID + "'";
				String sql1 = "Select OfficeTel,FICTITIOUSPERSONID,FICTITIOUSCERTTYPE from Ent_Info where CustomerID = '" + sCustomerID+"'";
				PreparedStatement ps1 = connection.prepareStatement(sql1);
				ResultSet rs1=ps1.executeQuery();
				if(rs1.next()){
				sCustomerPhone =  DataConvert.toString(rs1.getString("OfficeTel"));
				sCertType =  DataConvert.toString(rs1.getString("FICTITIOUSCERTTYPE"));
				sCertID =  DataConvert.toString(rs1.getString("FICTITIOUSPERSONID"));
				}
				if(sCustomerPhone == null) sCustomerPhone = "";
				if(sCertType == null) sCertType = "";				 
				if(sCertID == null) sCertID = "";		
				PreparedStatement ps11 = connection.prepareStatement(sql11);
				ResultSet rs11=ps11.executeQuery();
				if(rs11.next()){
				sSaleManageName =  DataConvert.toString(rs11.getString("SalerName"));
				sSMWorkTel =  DataConvert.toString(rs11.getString("WorkTel"));
				sSMPhone =  DataConvert.toString(rs11.getString("Phone"));}
				if(sSaleManageName == null) sSaleManageName = "";
				if(sSMWorkTel == null) sSMWorkTel = "";
				if(sSMPhone == null) sSMPhone = "";

				String updatesql="update CREDIT_IDLE set CustomerPhone ='"+sCustomerPhone+"',SMName = '"+sSaleManageName+
				 "',SMPhone = '"+sSMPhone+"',SMWorkTel = '"+sSMWorkTel+"',CustomerCertType = '"+sCertType+
				 "',CustomerCertID = '"+sCertID+"' where SerialNo='"+sSerialNo+"'";
				PreparedStatement ps2 = connection.prepareStatement(updatesql);
				ps2.execute();
				ps2.close();
				rs1.close();
				ps1.close();
				rs11.close();
				ps11.close();
			}
			}		
			rs.close();
			ps.close();
		}catch (Exception e) {
			e.printStackTrace();
		
	}
}}
