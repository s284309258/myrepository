package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.Deal.TransFareSW;
import com.amarsoft.account.entity.AcctFeeInfo;
import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.LedgerGeneral;
import com.amarsoft.account.ledger.UpdateLedgerGeneral;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchTransProvider;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.task.TaskConstants;

public class SplitFare extends CommonExecuteUnit {
	
	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int iSerialNo = 0;
	private String timeFlag="";
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				timeFlag=getProperty("timeFlag", "AM");
				
				logger.info("��ʼһ�㻹�����ϷѼ���......");
				UpdateSumFare(BatchConstant.AMOUNTATTRIBUTE_XYDFARE);
				logger.info("һ�㻹�����ϷѼ�����ɣ�");
				
				logger.info("��ʼ��ǰ�������ϷѼ���......");
				UpdateSumFare(BatchConstant.AMOUNTATTRIBUTE_AHEAF_XYDFARE);
				logger.info("��ǰ�������ϷѼ�����ɣ�");
				
				logger.info("��ʼ��ǰ�չ��������Ѽ���......");
				UpdateSumFareSDB(BatchConstant.AMOUNTATTRIBUTE_SDB_AHEADAMOUNT);
				logger.info("��ʼ��ǰ�չ��������Ѽ��ˣ�");
				
				logger.info("��ʼС΢���õ�������......");
				UpdateSumFeeSW(BatchConstant.AMOUNTATTRIBUTE_SW_DF_FEE);
				logger.info("С΢���õ���������ɣ�");
				//���·���˫���Ŀ�����ֵ
				UpdateLedgerGeneral.BatchLedgerGeneral(connection);
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/**
	 * �ۿ�˳�����˻���������Ϊ���ȣ����ȿ��˻�������
	 * @throws Exception 
	 */
	public void UpdateSumFare(String AmountAttribute) throws Exception
	{
		LedgerDetail ledgerDetail = new LedgerDetail();
		LedgerGeneral ledgerGeneral = new LedgerGeneral();
		ledgerDetail.OpenInsertLedgerDetail(connection);
		ledgerGeneral.OpenUpdateLedgerGeneral(connection);
		
		String updateFareDetailSql=" update FARE_DETAIL set ActualMoney = ActualMoney+?,AccDate=?,OffFlag = ? where PutOutNo = ? and PayDate = ? "; 
		PreparedStatement psUpdateFareDetailSql = connection.prepareStatement(updateFareDetailSql);
		
		String sqlTemp = " select PutoutNo,PayDate,(PayMoney-ActualMoney) as PayMoney  "
			   + " from Fare_Detail "
			   + " where PutOutNo =? and OffFlag = '0' and paydate<='"+deductDate+"' order by PayDate ";
		PreparedStatement psSqlTemp=connection.prepareStatement(sqlTemp);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = "select ap.SerialNo,ap.PutOutNo,ap.ActualAmount,lb.Currency,lb.Orgid,lb.BankFlag,lr.feetype "+
		 " from as400_pams ap,loan_balance lb,loanbalance_relative lr  "+
		 " where ap.PutOutNo=lb.PutOutNo and lb.putoutno=lr.putoutno and  lb.businesstype = '1140100' and ap.AmountAttribute = '"+AmountAttribute+"'";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//ʵ���ܽ��
			double actualAllMoney = rs.getDouble("ActualAmount");
			String putoutno = rs.getString("PutOutNo");
			//�˺Ź����Ѽ���
			HashMap<String,AttributeField> inputPara = new HashMap<String,AttributeField>();
			String sNewSerialNo = createSerialNo();
			inputPara = BatchTransProvider.SetInputPara(inputPara,"LoanFeeType",rs.getString("feeType"));//��������
			inputPara = BatchTransProvider.SetInputPara(inputPara,"SerialNo",sNewSerialNo);//������ˮ��
			inputPara = BatchTransProvider.SetInputPara(inputPara,"PutOutNo",putoutno); //��ݺ�
			inputPara = BatchTransProvider.SetInputPara(inputPara,"ActualMoney",actualAllMoney); //ʵ�����
			inputPara = BatchTransProvider.SetInputPara(inputPara,"TransNo","8001");//���ױ��
			inputPara = BatchTransProvider.SetInputPara(inputPara,"AccDate",deductDate);//���ױ��
			inputPara = BatchTransProvider.SetInputPara(inputPara,"Currency",rs.getString("Currency"));//����
			inputPara = BatchTransProvider.SetInputPara(inputPara,"OrgID",rs.getString("Orgid"));//����
			String bankFlag = rs.getString("BankFlag");
			if("".equals(bankFlag)|| bankFlag==null || "PAB".equals(bankFlag)){
				 inputPara = BatchTransProvider.SetInputPara(inputPara, "BankFlag","0");
			}else if(bankFlag.equals("SDB")){
				 inputPara = BatchTransProvider.SetInputPara(inputPara, "BankFlag","1");
			}
			BatchTransProvider batTransP = new BatchTransProvider();
			//������
			batTransP.LedgerDeal(ledgerDetail,ledgerGeneral,inputPara,LoanBalance.getAccountSubjectHashMap(rs.getString("PutOutNo"),connection));
			psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.addBatch();
			
			//����fare_detail��
			double balance = rs.getDouble("ActualAmount");
			psSqlTemp.setString(1,putoutno);
			ResultSet rsTemp = psSqlTemp.executeQuery();
			while(rsTemp.next())
			{
				if(balance>=rsTemp.getDouble("PayMoney"))
				{
					psUpdateFareDetailSql.setDouble(1,rsTemp.getDouble("PayMoney"));
					psUpdateFareDetailSql.setString(2, deductDate);
					psUpdateFareDetailSql.setString(3,"1");
					psUpdateFareDetailSql.setString(4,putoutno);
					psUpdateFareDetailSql.setString(5,rsTemp.getString("PayDate"));
					psUpdateFareDetailSql.addBatch();
					balance = balance-rsTemp.getDouble("PayMoney");
					if(balance==0)
					{
						break;
					}
				}	
				else
				{
					psUpdateFareDetailSql.setDouble(1,balance);
					psUpdateFareDetailSql.setString(2, deductDate);
					psUpdateFareDetailSql.setString(3,"0");
					psUpdateFareDetailSql.setString(4,putoutno);
					psUpdateFareDetailSql.setString(5,rsTemp.getString("PayDate"));
					psUpdateFareDetailSql.addBatch();
					balance = 0;
					break;
				}
			}
			rsTemp.close();
			
			
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				psDelSql.executeBatch();
				psUpdateFareDetailSql.executeBatch();
				ledgerDetail.executeBatch();
				ledgerGeneral.executeBatch();
				dealNum=0;
			}
		}
		rs.close();
		psSelectSql.close();
		ledgerDetail.executeBatch();
		ledgerGeneral.executeBatch();
		psDelSql.executeBatch();
		psUpdateFareDetailSql.executeBatch();
		ledgerDetail.close();
		ledgerGeneral.close();
		psDelSql.close();
		psSqlTemp.close();
	}
	
	public void UpdateSumFareSDB(String AmountAttribute) throws Exception{
		ArrayList<FareDetaill> fareDetailList = new ArrayList<FareDetaill>();
		LedgerDetail ledgerDetail = new LedgerDetail();
		LedgerGeneral ledgerGeneral = new LedgerGeneral();
		ledgerDetail.OpenInsertLedgerDetail(connection);
		ledgerGeneral.OpenUpdateLedgerGeneral(connection);
		
		String updateFareDetailSql=" update FARE_DETAIL set ActualMoney = ActualMoney+?,AccDate=?,OffFlag = ? where PutOutNo = ? and PayDate = ? "; 
		PreparedStatement psUpdateFareDetailSql = connection.prepareStatement(updateFareDetailSql);
		
		String sqlTemp = " select PutoutNo,PayDate,Currency,(PayMoney-ActualMoney) as PayMoney  "
			   + " from Fare_Detail "
			   + " where PutOutNo =? and OffFlag = '0' and paydate<='"+deductDate+"' order by PayDate ";
		PreparedStatement psSqlTemp=connection.prepareStatement(sqlTemp);
		
		//String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		//PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = "select ap.SerialNo,ap.PutOutNo,ap.ActualAmount,lb.Currency,lb.Orgid,lb.BankFlag,lr.feetype "+
			 " from as400_pams ap,loan_balance lb ,loanbalance_relative lr  "+
			 " where ap.PutOutNo=lb.PutOutNo and lb.putoutno=lr.putoutno and lb.businesstype = '1140100' and ap.AmountAttribute = '"+AmountAttribute+"'";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String putoutno = rs.getString("PutOutNo");
			double actualAmount=rs.getDouble("ActualAmount");
			//����ۿ�������㣬����ǰ����ۿ�ɹ���ֱ��ȡ����������ܽ�Ȼ��ȥ����
			if(actualAmount>0){
			
				psSqlTemp.setString(1,putoutno);
				ResultSet rsTemp = psSqlTemp.executeQuery();
				while(rsTemp.next())
				{
					//��ȡʵ����������ѵĽ��
					FareDetaill fareDetail = new FareDetaill();
					fareDetail.setPutOutNo(rsTemp.getString("PutOutNo"));
					fareDetail.setPayDate(rsTemp.getString("PayDate"));
					fareDetail.setCurrency(rsTemp.getString("Currency"));
					fareDetail.setPayMoney(rsTemp.getDouble("PayMoney"));
					fareDetail.setActualMoney(0);
					fareDetailList.add(fareDetail);	
					//���¸���fare_detail��
					psUpdateFareDetailSql.setDouble(1,rsTemp.getDouble("PayMoney"));
					psUpdateFareDetailSql.setString(2, deductDate);
					psUpdateFareDetailSql.setString(3,"1");
					psUpdateFareDetailSql.setString(4,putoutno);
					psUpdateFareDetailSql.setString(5,rsTemp.getString("PayDate"));
					psUpdateFareDetailSql.addBatch();
				}
				rsTemp.close();
				//ʵ����������ѵ��ܺ�
				double actualFareAmount = returnFareAmount(fareDetailList);
				HashMap<String,AttributeField> inputPara = new HashMap<String,AttributeField>();
				String sNewSerialNo = createSerialNo();
				inputPara = BatchTransProvider.SetInputPara(inputPara,"LoanFeeType",rs.getString("feeType"));//��������
				inputPara = BatchTransProvider.SetInputPara(inputPara,"SerialNo",sNewSerialNo);//������ˮ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"PutOutNo",putoutno); //��ݺ�
				inputPara = BatchTransProvider.SetInputPara(inputPara,"ActualMoney",actualFareAmount); //ʵ�����
				inputPara = BatchTransProvider.SetInputPara(inputPara,"TransNo","8001");//���ױ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"AccDate",deductDate);//���ױ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"Currency",rs.getString("Currency"));//����
				inputPara = BatchTransProvider.SetInputPara(inputPara,"OrgID",rs.getString("Orgid"));//����
				String bankFlag = rs.getString("BankFlag");
				if("".equals(bankFlag)|| bankFlag==null || "PAB".equals(bankFlag)){
					 inputPara = BatchTransProvider.SetInputPara(inputPara, "BankFlag","0");
				}else if(bankFlag.equals("SDB")){
					 inputPara = BatchTransProvider.SetInputPara(inputPara, "BankFlag","1");
				}
			
				BatchTransProvider batTransP = new BatchTransProvider();
				//������
				batTransP.LedgerDeal(ledgerDetail,ledgerGeneral,inputPara,LoanBalance.getAccountSubjectHashMap(rs.getString("PutOutNo"),connection));
				//psDelSql.setString(1,rs.getString("SerialNo"));
				//psDelSql.addBatch();
			
			}
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				//psDelSql.executeBatch();
				psUpdateFareDetailSql.executeBatch();
				ledgerDetail.executeBatch();
				ledgerGeneral.executeBatch();
				dealNum=0;
			}
		}
		rs.close();
		psSelectSql.close();
		ledgerDetail.executeBatch();
		ledgerGeneral.executeBatch();
		//psDelSql.executeBatch();
		psUpdateFareDetailSql.executeBatch();
		ledgerDetail.close();
		ledgerGeneral.close();
		//psDelSql.close();
		psSqlTemp.close();
	}
	
	//С΢�������ü���
	private void UpdateSumFeeSW(String amountattributeSwDfFee) throws Exception {
		
		String updateFareDetailSql=" update FARE_DETAIL set ActualMoney = ActualMoney+?,AccDate=?,OffFlag = ? where PutOutNo = ? and PayDate = ? "; 
		PreparedStatement psUpdateFareDetailSql = connection.prepareStatement(updateFareDetailSql);
		
		String sqlTemp = " select PutoutNo,PayDate,(PayMoney-ActualMoney) as PayMoney  "
			   + " from Fare_Detail "
			   + " where PutOutNo =? and OffFlag = '0' order by PayDate ";
		PreparedStatement psSqlTemp=connection.prepareStatement(sqlTemp);
		
		String delSql = "delete from AS400_PAMS where SerialNo = ? ";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		
		String selectSql = " select ap.SerialNo,ap.PutOutNo,ap.ActualAmount,afi.Currency,bp.operateOrgId "
			  + " from as400_pams ap,acct_fee_Info afi,business_putout bp   "
			  + " where ap.PutOutNo=afi.serialno and afi.objectno=bp.serialno  and ap.AmountAttribute = '"+amountattributeSwDfFee+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//ʵ�����
			double actualAllMoney = rs.getDouble("ActualAmount");
			String serialNo = rs.getString("PutOutNo");
			
			AcctFeeInfo acctFeeInfo = AcctFeeInfo.createAcctFeeInfo(serialNo, connection);
			//����ʵ�����Ϊ������ý��
			acctFeeInfo.setFeeBalance(actualAllMoney);
			
			psDelSql.setString(1,rs.getString("SerialNo"));
			psDelSql.addBatch();
			
			//����fare_detail��
			double balance = rs.getDouble("ActualAmount");
			psSqlTemp.setString(1,serialNo);
			ResultSet rsTemp = psSqlTemp.executeQuery();
			while(rsTemp.next())
			{
				if(balance>=rsTemp.getDouble("PayMoney"))
				{
					psUpdateFareDetailSql.setDouble(1,rsTemp.getDouble("PayMoney"));
					psUpdateFareDetailSql.setString(2, deductDate);
					psUpdateFareDetailSql.setString(3,"1");
					psUpdateFareDetailSql.setString(4,serialNo);
					psUpdateFareDetailSql.setString(5,rsTemp.getString("PayDate"));
					psUpdateFareDetailSql.addBatch();
					balance = balance-rsTemp.getDouble("PayMoney");
					if(balance==0)
					{
						break;
					}
				}	
				else
				{
					psUpdateFareDetailSql.setDouble(1,balance);
					psUpdateFareDetailSql.setString(2, deductDate);
					psUpdateFareDetailSql.setString(3,"0");
					psUpdateFareDetailSql.setString(4,serialNo);
					psUpdateFareDetailSql.setString(5,rsTemp.getString("PayDate"));
					psUpdateFareDetailSql.addBatch();
					balance = 0;
					break;
				}
			}
			rsTemp.close();
			
			//����С΢���ü���
			TransFareSW transFareSW = new TransFareSW();
			transFareSW.transFeeAcc(acctFeeInfo, connection);
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				psDelSql.executeBatch();
				psUpdateFareDetailSql.executeBatch();
				dealNum=0;
			}
			
		}
		rs.close();
		psSelectSql.close();
		psDelSql.executeBatch();
		psUpdateFareDetailSql.executeBatch();
		psDelSql.close();
		psSqlTemp.close();
		
	}

	//���ؿۿ�ֵ������ۿ�Ľ������˻��������򷵻س�ȥ�����ѵ�ֵ
	public double getAS400ActualMoney(double actualAllMoney,double payFareMoney)
	{
		if(actualAllMoney>=payFareMoney)
		{
			return actualAllMoney-payFareMoney;
		}
		else
		{
			return 0.0;
		}
		
	}
	
	//SDBʵ������������ܺ�
	private double returnFareAmount(ArrayList<FareDetaill> fareDetailList) {
		double fareAmount = 0.0;
		for(int i=0;i<fareDetailList.size();i++){
			FareDetaill fareDetail = fareDetailList.get(i);
			fareAmount += fareDetail.getPayMoney()-fareDetail.getActualMoney();
		}
		return fareAmount;
	}

	//���ؿ۵��˻������ѣ��������Ǯ�����˻������ѣ��򷵻ؽ��Ϊ�����ѣ����򷵻�ʵ�����۵�
	public double getFareActualMoney(double actualAllMoney,double payFareMoney)
	{
		if(actualAllMoney>=payFareMoney)
		{
			return payFareMoney;
		}
		else
		{
			return actualAllMoney;
		}
	}

	public String createSerialNo() throws Exception
	{
		iSerialNo++;
		String sTransType = "8001";
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iSerialNo,8,'0');
		return "B"+timeFlag+sDate+sTransType+sSortNo;
	}
}
