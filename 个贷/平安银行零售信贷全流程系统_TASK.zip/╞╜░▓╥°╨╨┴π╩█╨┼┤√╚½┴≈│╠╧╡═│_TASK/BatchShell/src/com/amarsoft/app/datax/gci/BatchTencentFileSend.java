package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import sun.misc.BASE64Encoder;

import com.amarsoft.are.ARE;
import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.bis.middle.MD5WithRSA;
import com.amarsoft.task.TaskConstants;

import filetrans.BankFileHandleServiceImp;
import filetrans.ResultBean;

public class BatchTencentFileSend  extends CommonExecuteUnit{
	int icount = 0;
	private String sLocalFileUrl;//��������·��
	private String sXslFileNameOffer;//ƽ��CSV�ļ�����
	private String sXslFileNameReject;
	private String sBISFrontIp;//ǰ�û�IP
	private String sBISFrontPort;//ǰ�ö˿�
	private String NASUrl;
	private String sUserName;
	private String sPassword;
	private String sKeyStore;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ������Ѷ�����ļ�......");
				initPara();
				sendTencentFile();
				logger.info("������Ѷ�����ļ���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_SUCCESSFUL;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void appendToFile(String fullFileName) throws Exception 
	{
		BufferedReader reader = new BufferedReader(new FileReader(fullFileName));
		String line="";
		while((line=reader.readLine())!=null)
		{
			if(line.startsWith("sign,"))
			{
				return;
			}
		}
		MD5WithRSA md5 = new MD5WithRSA();
		byte[] t = md5.sigFile(fullFileName, sUserName, sPassword,
				sLocalFileUrl+sKeyStore);
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter
				(new FileOutputStream(fullFileName, true)));  
		out.write("sign,"+new BASE64Encoder().encode(t));
		out.close();
	 }
	
	/*
	 * ��ʼ��������Ϣ 
	 * */
	public void initPara()
	{
		String sDate = StringFunction.replace(deductDate,"/","");
		NASUrl = ARE.getProperty("NASUrl");
		sLocalFileUrl = StringFunction.replace(NASUrl+getProperty("LocalFileUrl"),"{$CurrentDate}",sDate);		
		sXslFileNameOffer = StringFunction.replace(getProperty("XslFileNameOffer"),"{$CurrentDate}",sDate);
		sXslFileNameReject = StringFunction.replace(getProperty("XslFileNameReject"),"{$CurrentDate}",sDate);
		sBISFrontIp = getProperty("BISFrontIp");
		sBISFrontPort = getProperty("BISFrontPort");
		sUserName = getProperty("UserName");
		sPassword = getProperty("Password");
		sKeyStore = getProperty("KeyStore");
	}
	public void sendTencentFile() throws Exception
	{
		File file = new File(sLocalFileUrl);
		if(!file.exists())
		{
			logger.error(sLocalFileUrl+"�����ڣ�");
			return;
		}
		if(!file.isDirectory())
		{
			logger.error("����ϵͳ����sLocalFileUrl��"+sLocalFileUrl+"����Ŀ¼��");
			return;
		}
		appendToFile(sLocalFileUrl+sXslFileNameOffer);
		BankFileHandleServiceImp send = new BankFileHandleServiceImp();
		ResultBean bean = send.sendBankFile(sLocalFileUrl+sXslFileNameOffer, sXslFileNameOffer, sBISFrontIp, Integer.parseInt(sBISFrontPort), "in");
		String msgSend1 = bean.getPA_RSLT_CODE();
		if("999999".equals(msgSend1))
		{
			logger.info("�ļ���"+sXslFileNameOffer+"���ͳɹ���");
		}
		else
		{
			logger.info(msgSend1);
		}
		appendToFile(sLocalFileUrl+sXslFileNameReject);
		bean = send.sendBankFile(sLocalFileUrl+sXslFileNameReject, sXslFileNameReject, sBISFrontIp, Integer.parseInt(sBISFrontPort), "in");
		String msgSend2 = bean.getPA_RSLT_CODE();
		if("999999".equals(msgSend2))
		{
			logger.info("�ļ���"+sXslFileNameReject+"���ͳɹ���");
		}
		else
		{
			logger.info(msgSend2);
		}
		//��¼�ɹ�����ʧ����־
		if(!"999999".equals(msgSend1) || !"999999".equals(msgSend2))
		{
			inserttencent_monitor("F");
		}else
		{
			inserttencent_monitor("S");
		}
	}
	
	private void inserttencent_monitor(String status)
	{
		String SerialNo = "";
		PreparedStatement prepareStatement = null;
		try {
			SerialNo = DBFunction.getSerialNo("TENCENT_MONITOR", "SERIALNO","RL",null);
			prepareStatement = connection.prepareStatement("insert into TENCENT_MONITOR(Serialno,Objecttype,Oper_Date,Batch_Flag) values(?,?,?,?)");
			prepareStatement.setString(1, SerialNo);
			prepareStatement.setString(2, "SEND");
			prepareStatement.setString(3, deductDate);
			prepareStatement.setString(4, status);
			prepareStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				if(prepareStatement!=null)prepareStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
}
