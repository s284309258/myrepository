package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateReliefList extends CommonExecuteUnit {

	private int dealNum = 0;
	private int commitNum;
	private int iSerialCount = 0;

	public int execute() {
		try {
			String sInit = super.init();
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				commitNum = Integer.parseInt(getProperty("commitNum", "1"));

				String delSql = "delete from Relief_List rl where rl.inputdate = '" + deductDate + "'";
				logger.info("���Relief_List :sql=" + delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute(delSql);
				logger.info("���Relief_List�������! ");

				logger.info("ÿ����¾ȼ��嵥��ʼ��");
				insertRiskList();
				insertClassifyList();
				insertFXCheckList();
				logger.info("���¾ȼ��嵥ִ����ɣ�");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}


	// ��Relief_List�в������Ԥ�������ľȼ��嵥
	public void insertRiskList() throws Exception {
		String insertSql = " insert into Relief_List (serialno,contractserialno,reliefsource,ClassifyResult,riskresult,ifdispense,inputdate) values (?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);

		String selectSql = " select bc.serialno as serialno, bc.classifyresult as classifyresult from business_contract bc "+
			" where bc.finishdate is null and bc.businesskind = 'SWPM' and bc.putouttype in ('010','050') and PutOutDate is not null "+
			" and bc.serialno in (select rs.objectno from risk_signal rs where rs.objecttype = '3' and rs.actiontype like '%@7@%' and rs.signalstatus = '20') "+
			" and exists (select 1 from loan_balance lb where lb.contractserialno = bc.serialno and lb.loanstatus in ('0', '1', '4', '5')) "+
			" and not exists (select 1 from Relief_List rl where rl.contractserialno = bc.serialno) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while (rs.next()) {
			String newSerialNo = createSerialNo();
			psInsertSql.setString(1, newSerialNo);
			psInsertSql.setString(2, rs.getString("serialno"));
			psInsertSql.setString(3, "01");
			psInsertSql.setString(4, rs.getString("classifyresult"));
			psInsertSql.setString(5, "7");
			psInsertSql.setString(6, "01");
			psInsertSql.setString(7, deductDate);
			psInsertSql.addBatch();
			dealNum++;

			if (dealNum >= commitNum) {
				psInsertSql.executeBatch();
				dealNum = 0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		dealNum = 0;
		connection.commit();
		psInsertSql.close();
		psSelectSql.close();
	}
	
	// ��Relief_List�в����弶��������ľȼ��嵥
	private void insertClassifyList() throws Exception {
		String insertSql = " insert into Relief_List (serialno,contractserialno,reliefsource,classifyresult,ifdispense,inputdate) values (?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);

		String selectSql = " select bc.serialno as serialno, bc.classifyresult as classifyresult from business_contract bc "+
			" where bc.finishdate is null and bc.businesskind = 'SWPM' and bc.putouttype in ('010','050') and PutOutDate is not null and bc.classifyresult in ('3', '4', '5') "+ 
			" and exists (select 1 from loan_balance lb where lb.contractserialno = bc.serialno and lb.loanstatus in ('0', '1', '4', '5')) "+
			" and not exists (select 1 from Relief_List rl where rl.contractserialno = bc.serialno) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while (rs.next()) {
			String newSerialNo = createSerialNo();
			psInsertSql.setString(1, newSerialNo);
			psInsertSql.setString(2, rs.getString("serialno"));
			psInsertSql.setString(3, "02");
			psInsertSql.setString(4, rs.getString("classifyresult"));
			psInsertSql.setString(5, "01");
			psInsertSql.setString(6, deductDate);
			psInsertSql.addBatch();
			dealNum++;
			if (dealNum >= commitNum) {
				psInsertSql.executeBatch();
				dealNum = 0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		dealNum = 0;
		connection.commit();
		psInsertSql.close();
		psSelectSql.close();
	}
	
	// ��Relief_List�в�����ռ������ľȼ��嵥
	private void insertFXCheckList() throws Exception {
		String insertSql = " insert into Relief_List (serialno,contractserialno,reliefsource,classifyresult,ifdispense,inputdate) values (?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);

		String selectSql = " select bc.serialno as serialno, bc.classifyresult as classifyresult from business_contract bc "+
			" where bc.finishdate is null and bc.businesskind = 'SWPM' and bc.putouttype in ('010','050') and PutOutDate is not null and bc.serialno in (select fi.contractno from fxcheck_info fi where fi.watchresult='P' and fi.watchtype='040') "+ 
			" and exists (select 1 from loan_balance lb where lb.contractserialno = bc.serialno and lb.loanstatus in ('0', '1', '4', '5')) "+
			" and not exists (select 1 from Relief_List rl where rl.contractserialno = bc.serialno) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while (rs.next()) {
			String newSerialNo = createSerialNo();
			psInsertSql.setString(1, newSerialNo);
			psInsertSql.setString(2, rs.getString("serialno"));
			psInsertSql.setString(3, "04");
			psInsertSql.setString(4, rs.getString("classifyresult"));
			psInsertSql.setString(5, "01");
			psInsertSql.setString(6, deductDate);
			psInsertSql.addBatch();
			dealNum++;
			if (dealNum >= commitNum) {
				psInsertSql.executeBatch();
				dealNum = 0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		dealNum = 0;
		connection.commit();
		psInsertSql.close();
		psSelectSql.close();
	}

	public String createSerialNo() throws Exception {
		iSerialCount++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iSerialCount, 8, '0');
		String Re = "Re";
		return Re + sDate + sSortNo;
	}
}