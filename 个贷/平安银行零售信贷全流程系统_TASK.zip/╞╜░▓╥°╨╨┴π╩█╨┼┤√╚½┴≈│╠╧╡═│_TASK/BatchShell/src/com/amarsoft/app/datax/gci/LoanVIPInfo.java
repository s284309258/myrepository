package com.amarsoft.app.datax.gci;

public class LoanVIPInfo {

	//��ݱ��
	private String PutOutNo;
	//ҵ��Ʒ��
	private String BusinessType;
	//������˻���
	private String OrgID;
	//����ϵͳ�ͻ���
	private String CustomerID;
	//Ecif�ͻ���
	private String EcifCustomerID;
	//�ÿͻ����ڴ�����ܺ�
	private double sumSavingBalance;
	//�ÿͻ����ڴ�����ܺ�
	private double SumFixedSavingBalance;
	//�ÿͻ��������ܺ�
	private double SumLoanBalance;
	//�����ʸ�������
	private double OldRateFloat;
	//ԭʼ���ʸ�������
	private double OrirateFloat;
	//�����ʸ�������
	private double NewRateFloat;
	//�������
	private String ChangeDate;
	//�Ƿ���Ҫ����VIP���ʱ��
	private boolean IsRateFloatChange;
	
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public String getBusinessType() {
		return BusinessType;
	}
	public void setBusinessType(String businessType) {
		BusinessType = businessType;
	}
	public String getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}
	public String getEcifCustomerID() {
		return EcifCustomerID;
	}
	public void setEcifCustomerID(String ecifCustomerID) {
		EcifCustomerID = ecifCustomerID;
	}
	public double getSumSavingBalance() {
		return sumSavingBalance;
	}
	public void setSumSavingBalance(double sumSavingBalance) {
		this.sumSavingBalance = sumSavingBalance;
	}
	public double getSumFixedSavingBalance() {
		return SumFixedSavingBalance;
	}
	public void setSumFixedSavingBalance(double sumFixedSavingBalance) {
		SumFixedSavingBalance = sumFixedSavingBalance;
	}
	public double getSumLoanBalance() {
		return SumLoanBalance;
	}
	public void setSumLoanBalance(double sumLoanBalance) {
		SumLoanBalance = sumLoanBalance;
	}
	public double getOldRateFloat() {
		return OldRateFloat;
	}
	public void setOldRateFloat(double oldRateFloat) {
		OldRateFloat = oldRateFloat;
	}
	public double getNewRateFloat() {
		return NewRateFloat;
	}
	public void setNewRateFloat(double newRateFloat) {
		NewRateFloat = newRateFloat;
	}
	public String getChangeDate() {
		return ChangeDate;
	}
	public void setChangeDate(String changeDate) {
		ChangeDate = changeDate;
	}
	public boolean isRateFloatChange() {
		return IsRateFloatChange;
	}
	public void setRateFloatChange(boolean isRateFloatChange) {
		IsRateFloatChange = isRateFloatChange;
	}
	public String getOrgID() {
		return OrgID;
	}
	public void setOrgID(String orgID) {
		OrgID = orgID;
	}
	public double getOrirateFloat() {
		return OrirateFloat;
	}
	public void setOrirateFloat(double orirateFloat) {
		OrirateFloat = orirateFloat;
	}
	

	
	
}
