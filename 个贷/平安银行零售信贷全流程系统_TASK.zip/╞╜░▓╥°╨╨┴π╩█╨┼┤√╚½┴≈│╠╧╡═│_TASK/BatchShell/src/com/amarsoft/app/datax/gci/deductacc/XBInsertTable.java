package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.CalInterest;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class XBInsertTable extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int iSerialCount;
	private ArrayList<String> workFreeDateList; 
	
	public int execute() {
			
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					
					logger.info("��ʼɾ��xb_loandetail���������...");
					String deleteSqlLoanDetail = " delete from xb_loandetail where InputDate='"+lastDate+"'";
					PreparedStatement psDeleteLoanDetail = connection.prepareStatement(deleteSqlLoanDetail);
					psDeleteLoanDetail.execute();
					connection.commit();
					psDeleteLoanDetail.close();
					logger.info("��ʼɾ��xb_loandetail������������...");
					logger.info("�ſ���ϸxb_loandetail���뵽����ϵͳ��(����).....");
					XB_LoanDetail();
					logger.info("�ſ���ϸxb_loandetail���뵽����ϵͳ��(����)��ɣ�");
					 	
					
					logger.info("��ʼɾ������ƻ���XB_ReturnPlan���������...");
					String deleteSqlReturnPlan = "delete from xb_returnplan ";
					PreparedStatement psDelete = connection.prepareStatement(deleteSqlReturnPlan);
					psDelete.execute();
					connection.commit();
					psDelete.close();
					logger.info("ɾ������ƻ���XB_ReturnPlan������������");
					logger.info("����ƻ����뵽����ϵͳ��(ȫ��).....");
					XB_ReturnPlan();
					logger.info("ÿ�ս�ȫ���Ļ���ƻ����뵽����ϵͳ��(ȫ��)��ɣ�");
				
					
					logger.info("ɾ������ƻ���XB_Returndetail��������ݿ�ʼ");
					String deleteSqlReturnDetail = "delete from XB_Returndetail where InputDate='"+deductDate+"' or InputDate='"+lastDate+"'";
					PreparedStatement psDeleteReturnDetail = connection.prepareStatement(deleteSqlReturnDetail);
					psDeleteReturnDetail.execute();
					connection.commit();
					psDeleteReturnDetail.close();
					logger.info("ɾ������ƻ���XB_Returndetail������������");
					initSerialCount();//��ʼ������
					logger.info("��ÿ�տͻ������¼��Ϣxb_returndetail���뵽����ϵͳ��(����)");
					XB_Returndetail();
					logger.info("ÿ�տͻ������¼��Ϣxb_returndetail���뵽����ϵͳ��(����)���");
					
					
					logger.info("��ʼɾ��xb_willcompensate���������...");
					String deleteSqlWillCompensate = " delete from xb_willcompensate where InputDate='"+lastDate+"'";
					PreparedStatement psDeleteWillCompensate = connection.prepareStatement(deleteSqlWillCompensate);
					psDeleteWillCompensate.execute();
					connection.commit();
					psDeleteWillCompensate.close();
					logger.info("ÿ�ս���������60�����ϵĴ�����Ϣxb_willcompensate���뵽����ϵͳ��(����)");
					XB_WillCompensate();
					logger.info("ÿ�ս���������60�����ϵĴ�����Ϣxb_willcompensate���뵽����ϵͳ��(����)���...");
					
					
					logger.info("��ʼɾ��xb_havecompensated���������...");
					String deleteSqlHaveCompensate = " delete from xb_havecompensated where InputDate='"+lastDate+"'";
					PreparedStatement sDeleteXbHaveCompensate = connection.prepareStatement(deleteSqlHaveCompensate);
					sDeleteXbHaveCompensate.execute();
					connection.commit();
					sDeleteXbHaveCompensate.close();
					logger.info("ÿ�ս��������������Ĵ�����Ϣxb_havecompensated���뵽����ϵͳ��(����)");
					XB_HaveCompensated();
					logger.info("ÿ�ս��������������Ĵ�����Ϣxb_havecompensated���뵽����ϵͳ��(����)���");
					
					logger.info("��ʼɾ��xb_stat_records���������...");
					String deleteSqlStatRecords = " delete from xb_stat_records where InputDate='"+lastDate+"'";
					PreparedStatement sDeleteSqlStatRecords = connection.prepareStatement(deleteSqlStatRecords);
					sDeleteSqlStatRecords.execute();
					connection.commit();
					sDeleteSqlStatRecords.close();
					logger.info("ÿ�ս����ն�����Ϣxb_stat_records���뵽����ϵͳ��(����)");
					XB_StatRecords();
					logger.info("������Ϣxb_stat_records���뵽����ϵͳ��(����)���");
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}
	

	//ÿ�ս��ſ���ϸ���뵽����ϵͳ��
	private void XB_LoanDetail() throws SQLException {
		String insertSql = " insert into xb_loandetail(Guarantyid,Custname,Idtype,Idnum,Contractno,Lnsacct,Dpsacct," +
						   " Sdate,Loanamt,Totterm,Rate,Npdate,Edate,Flag,Inputdate,Updatetime)" +
						   " values(?,?,?,?,?," +
						   " ?,?,?,?,?," +
						   " ?,?,?,?,?," +
						   " ?)" ;
		PreparedStatement psInsertSql =  connection.prepareStatement(insertSql);
		
		String querySql =  " select gi.INSURNO as GuarantyID," +//������
						   " LB.Customername as CustName," +//�ͻ�����
						   " decode(ci.certtype,'Ind01','1','Ind03','2','Ind04','3','Ind05','4','Ind07','5','Ent02','8','��') as IdType," +//֤������
						   " ci.certid as IdNum," +//֤������
						   " bc.artificialno as ContractNo," +//��ͬ��
						   " lb.putoutno as Lnsacct," +//�����ʺ�
						   " lb.deductaccno as Dpsacct," +//�ۿ��ʺ�
						   " bp.senddate as Sdate," +//�ſ�ʱ��
						   " lb.businesssum as Loanamt," +//�ſ���
						   " lb.cterm as Totterm," +//����
						   " lb.executerate as Rate," +//��������
						   " lb.nextpaydate as Npdate," +//�״λ�����
						   " lb.maturitydate as Edate," +//�������
						   " '10' as Flag," +//������־
						   " '"+lastDate+"' as InputDate," +//�������
						   " '"+lastDate+"' as UpdateTime" +//�޸�����
						   " from Loan_Balance LB," +
						   " Customer_Info ci,Business_Contract bc,Business_Putout bp,Guaranty_Relative gr,guaranty_info gi" +
						   " where bc.customerid = ci.customerid" +
						   " and lb.ContractSerialNo = bc.SerialNo" +
						   " and lb.putoutno = bp.serialno" +
						   " and lb.contractserialno = gr.objectno" +
						   " and gr.guarantyid = gi.guarantyid" +
						   " and gr.objecttype = 'CBContractApply'" +
						   " and lb.businesstype = '1150060'" +
						   " and gi.guarantytype='010010'" +
						   " and lb.loanstatus in('0','1','4','5')" +
						   " and lb.putoutdate='"+lastDate+"'";
		logger.info("�ſ���ϸ:::" + querySql);
		PreparedStatement psQuerySql =  connection.prepareStatement(querySql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			psInsertSql.setString(1, rs.getString("GuarantyID"));
			psInsertSql.setString(2, rs.getString("CustName"));
			psInsertSql.setString(3, rs.getString("IdType"));
			psInsertSql.setString(4, rs.getString("IdNum"));
			psInsertSql.setString(5, rs.getString("ContractNo"));
			psInsertSql.setString(6, rs.getString("Lnsacct"));
			psInsertSql.setString(7, rs.getString("Dpsacct"));
			psInsertSql.setString(8, rs.getString("Sdate"));
			psInsertSql.setDouble(9, rs.getDouble("Loanamt"));
			psInsertSql.setDouble(10, rs.getDouble("Totterm"));
			psInsertSql.setDouble(11, rs.getDouble("Rate"));
			psInsertSql.setString(12, rs.getString("Npdate"));
			psInsertSql.setString(13, rs.getString("Edate"));
			psInsertSql.setString(14, rs.getString("Flag"));
			psInsertSql.setString(15, rs.getString("InputDate"));
			psInsertSql.setString(16, rs.getString("UpdateTime"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			if(dealNum > commitNum){
				psInsertSql.executeBatch();
				logger.info("�Ѿ�����"+icount+"��");
				dealNum=0;
			}
			
		}
		rs.close();
		psInsertSql.executeBatch();
		icount = 0;
		psQuerySql.close();
		psInsertSql.close();
		
	}
	//ÿ�ս�����ƻ����뱣��ϵͳ��
	private void XB_ReturnPlan() throws Exception {
		String insertSql = " insert into xb_returnplan(Lnsacct,Pflg,RpTerm,Wrpdte,Rate,ORate,CAPITAL,INTAMT,OINT,RRPDTE" +
		   " ,Flag,InputDate,UpdateTime,MONTHLY_INSURED_AMT)" +
		   " values(?,?,?,?,?," +
		   " ?,?,?,?,?," +
		   " ?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		//�õ������µ�
		String day1 = DateTools.getEndDateOfMonth(nextMonth+"/01");
		//�õ�������һ��
		String day2 = DateTools.getRelativeDate(day1, AccountConstants.TERM_UNIT_DAY, 1);
		
		String sQuerySql = " select lb.putoutno as Lnsacct," +
						   " decode(ls.Payoffflag,'1','1','0','2') as Pflg," +
						   " ls.sterm as RpTerm," +
						   " lb.sterm as LBSterm," +
						   " ls.PayDate as Wrpdte," +
						   " lb.AheadNum as lbAheadNum," +
						   " lb.LoanStatus as LoanStatus," +
						   " lb.executerate as Rate," +
						   " lb.finerate/10000*360*100 as ORate," +
						   " (ls.paycurrentcorp + ls.paydefaultcorp +ls.payoverduecorp) as CAPITAL," +
						   " (ls.payInte+ls.payinnerinte + ls.payoutinte)as INTAMT," +
						   " (ls.payinnerintefine+ls.payoutintefine) as OINT," +
						   " decode(ls.Payoffflag,'1',ls.accdate,'0','') as RRPDTE," +
						   " '10' as Flag," +
						   " '"+deductDate+"' as InputDate," +
						   " '"+deductDate+"' as UpdateTime," +
						   " ls.AheadNum, " +
						   " NVL(fd.actualmoney,0) as AMT," +
						   " NVL(PayMoney,0) as AMT2" +
						   " from Loan_Balance lb, Loanback_Status ls left join Fare_detail fd  on ls.putoutno = fd.putoutno  and ls.paydate = fd.paydate " +
						   " where ls.putoutno = lb.putoutno" +
						   " and  lb.businesstype = '1150060' and ls.accdate<='"+deductDate+"' " +
						   " and (lb.FinishDate in('"+lastDate+"','"+deductDate+"') or lb.loanstatus in ('0','1','4','5'))" +
						   " and (ls.Payoffflag = '0' or (ls.Payoffflag = '1' and ls.accdate in('"+lastDate+"','"+deductDate+"')))" +
						   " union all " +
						   " select rp.PUTOUTNO as Lnsacct," +//�����ʺ�
						   " '9' as Pflg," +//�����־
						   " rp.Term as RpTerm," +//��������
						   " lb.sterm as LBSterm," +//��ݱ����ڴ�
						   " rp.Repaydate as Wrpdte," +//Ӧ������
						   " 0 as lbAheadNum," +//��ݱ���ǰ�������
						   " lb.LoanStatus as LoanStatus," +
						   " lb.executerate as Rate," +//��������
						   " lb.finerate/10000*360*100 as ORate," +//��������
						   " rp.repaycorpus as CAPITAL," +//����
						   " rp.repayinterest as INTAMT," +//��Ϣ
						   " 0 as OINT," +//��Ϣ
						   " '' as RRPDTE," +//ʵ�ʻ�����
						   " '10' as Flag," +//������־
						   " '"+deductDate+"'as InputDate," +//�������
						   " '"+deductDate+"' as UpdateTime, " +//�޸�����
						   " 0 as AheadNum, " +//״̬������ǰ����
						   " rp.FAREAMOUNT as AMT," +//���ѣ��˻�������
						   " rp.FAREAMOUNT as AMT2" +//���ѣ��˻������ѣ�
						   " from repay_plan rp,loan_balance lb" +
						   " where rp.putoutno = lb.putoutno" +
						   " and  lb.businesstype = '1150060' and (rp.RepayDate <='"+day2+"' or lb.PutOutDate = '"+lastDate+"' )" +
						   " and lb.loanstatus in('0','1','4','5')" +
						   " and  rp.repaycorpus + rp.repayinterest>0" +
						   " and rp.Term not in (select sterm from loanback_status ls1 where lb.PutOutNo = ls1.PutOutNo " +
						   " and ls1.accdate<='"+deductDate+"')";
		logger.info("����ƻ�:::" + sQuerySql);
		PreparedStatement psQuerySql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			psInsertSql.setString(1, rs.getString("Lnsacct"));
			String sPflg = rs.getString("Pflg");
			int RpTerm = rs.getInt("RpTerm");			
			int AheadNum = rs.getInt("AheadNum");
			int lbAheadNum = rs.getInt("lbAheadNum");
			int lbSterm = rs.getInt("LBSterm");
			String LoanStatus =rs.getString("LoanStatus");
			//���˵�������ǰ����
			if ((LoanStatus.equals("0") || LoanStatus.equals("1") || LoanStatus.equals("4") || LoanStatus.equals("5"))){//δ�������
				if(AheadNum> 0) continue;				
			}else if(LoanStatus.equals("20")||LoanStatus.equals("90")){//��ǰ����/��������
				if(AheadNum>0){
					if(lbAheadNum!=AheadNum) continue;
					else{
						if(RpTerm!=lbSterm) RpTerm=lbSterm;
					}
				}				
			}else{
				if(AheadNum> 0) continue;	
			}
			
			if(sPflg.equals("1"))
			{
				if(AheadNum> 0)
				{
					sPflg = "4";
				}
			}
			psInsertSql.setString(2, sPflg);
			psInsertSql.setDouble(3, RpTerm);
			psInsertSql.setString(4, rs.getString("Wrpdte"));
			psInsertSql.setDouble(5, rs.getDouble("Rate"));
			psInsertSql.setDouble(6, rs.getDouble("ORate"));
			psInsertSql.setDouble(7, rs.getDouble("CAPITAL"));
			psInsertSql.setDouble(8, rs.getDouble("INTAMT"));
			psInsertSql.setDouble(9, rs.getDouble("OINT"));
			psInsertSql.setString(10, rs.getString("RRPDTE"));
			psInsertSql.setString(11, rs.getString("Flag"));
			psInsertSql.setString(12, rs.getString("InputDate"));
			psInsertSql.setString(13, rs.getString("UpdateTime"));
			if (sPflg.equals("4")){
			//	psInsertSql.setDouble(14, NumberTools.round(rs.getDouble("AMT2"), AccountConstants.MONEY_PRECISION));
				PreparedStatement tempSql = connection.prepareStatement("select lr.Amount AMT  from loanbalance_relative lr where lr.putoutno = '"+rs.getString("Lnsacct")+"' and lr.feetype = '03' and lr.feemethod = '03'");
				ResultSet tempRs = tempSql.executeQuery();
				if (tempRs.next()){
					psInsertSql.setDouble(14, NumberTools.round(tempRs.getDouble("AMT"), AccountConstants.MONEY_PRECISION));
				}
				tempRs.close();
				tempSql.close();
			}
			else
				psInsertSql.setDouble(14, NumberTools.round(rs.getDouble("AMT2"), AccountConstants.MONEY_PRECISION));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			if(dealNum > commitNum){
				psInsertSql.executeBatch();
				logger.info("�Ѿ�����"+icount+"��");
				dealNum=0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		icount=0;
		psQuerySql.close();
		psInsertSql.close();
	}
	
	//������ϸ��
	private void XB_Returndetail() throws Exception {
		String sInsertSql = " insert into XB_Returndetail(returnSeqNo,rrpdte,lnsacct,rpterm,capital," +
				    		" intamt,oint,Flag,InputDate,UpdateTime,INSURED_AMT)" +
				    		" values(?,?,?,?,?," +
				    		" ?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(sInsertSql);
		
		String sQuerySql = " select bb.billno as returnSeqNo," +//������ˮ��
						   " bb.accdate as rrpdte," +//��������
						   " bb.putoutno as lnsacct," +//�����ʺ�
						   " bb.sterm rpterm," +//��������
						   " sum(bb.actualcurrentcorp+bb.actualdefaultcorp+bb.actualoverduecorp) as capital," +//����
						   " sum(bb.actualinte+bb.actualinnerinte+bb.actualoutinte) as intamt," +//��Ϣ
						   " sum(bb.actualinnerintefine+bb.actualoutintefine) as oint," +//��Ϣ
						   " '10' as Flag," +//������־
						   " bb.accdate as InputDate," +//�������
						   " bb.accdate as UpdateTime," +
						   " 0 as INSURED_AMT," +
						   " '' as FdPayDate" +//�޸����� ��������
						   " from Loan_Balance LB,Back_Bill bb" +
						   " where lb.putoutno = bb.putoutno" +
						   " and  lb.businesstype = '1150060'" +
						   " and bb.billtype in ('20','21','22','23','24') " +
						   " and bb.Billstatus = '1'" +
						   " and (bb.accdate = '"+lastDate+"' or bb.accdate = '"+deductDate+"')" +
						   " and (bb.actualcurrentcorp+bb.actualdefaultcorp+bb.actualoverduecorp" +
						   " +bb.actualinte+bb.actualinnerinte+bb.actualoutinte" +
						   " +bb.actualinnerintefine+bb.actualoutintefine)>0 " +
						   " group by bb.billno,bb.accdate,bb.putoutno,bb.sterm" +
						   " union all" +
						   " select '' as returnSeqNo," +
						   " fd.accdate as rrpdte," +
						   " fd.putoutno as lnsacct," +
						   " 1 as rpterm," +
						   " 0 as capital," +
						   " 0 as intamt," +
						   " 0 as oint," +
						   " '10' as Flag," +
						   " fd.accdate as InputDate," +
						   " fd.accdate as UpdateTime," +
						   " fd.actualmoney as INSURED_AMT," +
						   " fd.paydate as FdPayDate" +
						   " from fare_detail fd,loan_balance lb,loanbalance_relative lr" +
						   " where fd.putoutno = lb.putoutno and lb.businesstype = '1150060'" +
						   " and lb.putoutno = lr.putoutno and lr.FeeType = '03'" +
						   " and fd.actualmoney >0 and (fd.accdate = '"+lastDate+"' or fd.accdate = '"+deductDate+"')";
		
		PreparedStatement psQuerySql = connection.prepareStatement(sQuerySql);
		
		//ȡ�ڴ�
		String termSql = "select sterm from loanback_status ls, fare_detail fd "
				+ "where fd.putoutno = ls.putoutno and fd.paydate = ls.paydate "
				+ " and fd.paydate = ?"
				+ "and fd.putoutno = ?";
		PreparedStatement termQuerySql = connection.prepareStatement(termSql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			String newSerialNo = rs.getString("returnSeqNo");
			if ( "".equals(newSerialNo) || newSerialNo == null){//������ˮ��Ϊ����Ϊ36��
				newSerialNo = createSerialNo(rs.getString("lnsacct"),rs.getString("FdPayDate"),rs.getString("rrpdte"));
			//ȡ�ڴ�	
			double sterm = getSterm(termQuerySql,rs.getString("FdPayDate"),rs.getString("lnsacct"));
			psInsertSql.setDouble(4, sterm);
			// logger.info(newSerialNo);
			}else{
				psInsertSql.setDouble(4, rs.getDouble("rpterm"));
			}
			psInsertSql.setString(1,rs.getString("returnSeqNo") == null ? newSerialNo : rs.getString("returnSeqNo"));
			
			psInsertSql.setString(2, rs.getString("rrpdte"));
			psInsertSql.setString(3, rs.getString("lnsacct"));
			psInsertSql.setDouble(5, rs.getDouble("capital"));
			psInsertSql.setDouble(6, rs.getDouble("intamt"));
			psInsertSql.setDouble(7, rs.getDouble("oint"));
			psInsertSql.setString(8, rs.getString("Flag"));
			psInsertSql.setString(9, rs.getString("InputDate"));
			psInsertSql.setString(10, rs.getString("UpdateTime"));
			psInsertSql.setDouble(11, NumberTools.round(rs.getDouble("INSURED_AMT"), AccountConstants.MONEY_PRECISION));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			if(dealNum > commitNum){
				psInsertSql.executeBatch();
				logger.info("�Ѿ�����"+icount+"��");
				dealNum=0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		icount=0;
		psQuerySql.close();
		termQuerySql.close();
		psInsertSql.close();
	}
	
	
	//��������60�����ϵĴ�����Ϣ
	private void XB_WillCompensate() throws Exception {
		
		initWorkFreeDateList();
		
		String sInsertSql = " insert into XB_WillCompensate(Lnsacct,Lntterm,Lntday,Capital,Intamt," +
						    " Oint,Nint,Balance,Lpamt,Paydate," +
						    " Payflag,Flag,Inputdate,Updatetime)" +
						    " values(?,?,?,?,?," +
						    " ?,?,?,?,?," +
						    " ?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(sInsertSql);
		String sQuerySql = " select lb.putoutno as  LNSAcct," +//�����ʺ�
						   " lbr.SERIESOVERTERMS as LNTTERM," +//����������
						   " lbr.overdays as LNTDAY," +//����������
						   " lb.overduebalance as CAPITAL," +//Ƿ��
						   " (lb.payoutinte+lb.payinnerinte) as INTAMT," +//Ƿ��Ϣ
						   " (lb.payinnerintefine+lb.payoutintefine) as OINT," +//��Ϣ
						   " decode(lb.LastInteDate,'"+deductDate+"',lb.PayInte,lb.PeriodInte) as NINT," +//δ����Ϣ
						   " (lb.normalbalance + lb.overduebalance) as Balance," +//��ǰ���
						   " (lb.NormalBalance+lb.OverDueBalance+lb.PayInnerInte+lb.PayOutInte+lb.PayInnerInteFine+lb.PayOutInteFine+" +
						   " decode(lb.LastInteDate,'"+deductDate+"',lb.PayInte,lb.PeriodInte)) as LPAMT," +//������
						   " lbr.OverDays, " +
						   " '10' as Flag," +//������־
						   " '"+lastDate+"' as InputDate," +//�������
						   " '"+lastDate+"' as UpdateTime" +//�޸�����
						   " from " +
						   " loanBalance_relative lbr,Loan_Balance lb" +
						   " where lb.putoutno = lbr.putoutno" +
						   " and  lb.businesstype = '1150060'" +
						   " and lb.loanstatus in('0','1','4','5') " +
						   " and lbr.OverDays > 60";
		logger.info("������Ϣ:::" + sQuerySql);
		PreparedStatement psQuerySql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			double dLPamt = rs.getDouble("LPAMT");
			psInsertSql.setString(1, rs.getString("LNSAcct"));
			psInsertSql.setDouble(2, rs.getDouble("LNTTERM"));
			psInsertSql.setDouble(3, rs.getDouble("LNTDAY"));
			psInsertSql.setDouble(4, rs.getDouble("CAPITAL"));
			psInsertSql.setDouble(5, rs.getDouble("INTAMT"));
			psInsertSql.setDouble(6, rs.getDouble("OINT"));
			
			double Nint = rs.getDouble("NINT");
			if(Nint==0)
			{
				LoanBalance loanBalance = new LoanBalance();
				loanBalance.SetLoanBalance(rs.getString("LNSAcct"),connection);
				
				Nint = NumberTools.round(CalInterest.getInterest(loanBalance, AccountConstants.REPAY_AMOUNT_TYPE_CORPUS,
						loanBalance.getNormalBalance(),deductDate),AccountConstants.MONEY_PRECISION);
				dLPamt += Nint;
			}
			
			psInsertSql.setDouble(7, Nint);
			psInsertSql.setDouble(8, rs.getDouble("Balance"));
			psInsertSql.setDouble(9, dLPamt);
			String sPayDate = returnPayDate(rs.getInt("OverDays"));
			psInsertSql.setString(10, sPayDate);
			int i = sPayDate.compareTo(deductDate);
			String sPayFlag = "";
			if(i>0)
			{
				sPayFlag = "0";
			}
			else if(i==0)
			{
				sPayFlag = "1";
			}
			else
			{
				sPayFlag = "2";
			}
			psInsertSql.setString(11, sPayFlag);
			psInsertSql.setString(12, rs.getString("Flag"));
			psInsertSql.setString(13, rs.getString("InputDate"));
			psInsertSql.setString(14, rs.getString("UpdateTime"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			if(dealNum > commitNum){
				psInsertSql.executeBatch();
				logger.info("�Ѿ�����"+icount+"��");
				dealNum=0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		icount=0;
		psQuerySql.close();
		psInsertSql.close();
	}
	//����ÿ�����������Ĵ�����Ϣ
	private void XB_HaveCompensated() throws SQLException {
		String queryRepatTmp = " select Lnsacct from XB_HaveCompensated where Lnsacct = ?";
		PreparedStatement psQueryRepatTmp = connection.prepareStatement(queryRepatTmp);
		//ɾ��XB_HaveCompensated���ظ�������
		String deleteRepat = " delete from XB_HaveCompensated where Lnsacct=?";
		logger.info("ɾ���ظ��Ĵ���:::" + deleteRepat);
		PreparedStatement psDeleteRepat = connection.prepareStatement(deleteRepat);
		
		String sInsertSql = " insert into XB_HaveCompensated(Lnsacct,Lntterm,Lntday,Capital,Intamt," +
							" Oint,Nint,Balance,Lpamt,Valdat," +
							" Valtime,Subbankid,Flag,Inputdate,Updatetime)" +
							" values(?,?,?,?,?," +
							" ?,?,?,?,?," +
							" ?,?,?,?,?)";
		PreparedStatement psInertSql = connection.prepareStatement(sInsertSql);
		String sQuerySql = " select xbc.Lnsacct as Lnsacct," +//�����ʺ�
				 		   " xbc.LNTTERM as LNTTERM," +//����������
				 		   " xbc.LNTDAY as LNTDAY," +//����������
				 		   " xbc.CAPITAL as CAPITAL," +//Ƿ��
				 		   " xbc.INTAMT as INTAMT," +//Ƿ��Ϣ
				 		   " xbc.OINT as OINT," +//��Ϣ
				 		   " xbc.NINT as NINT," +//δ����Ϣ
				 		   " xbc.Balance as Balance," +//��ǰ���
				 		   " xbc.LPAMT as LPAMT," +//������
				 		   " xbc.inputdate as ValDat," +//��������
				 		   " '' as ValTime," +//����ʱ��
				 		   " lb.orgid as SubBankId," +//�ۿ����
				 		   " '10' as Flag," +//������־
				 		   " '"+lastDate+"' as InputDate," +//�������
				 		   " '"+lastDate+"' as UpdateTime " +//�޸�����
				 		   " from xb_compensated xbc,loan_balance lb" +
				 		   " where xbc.lnsacct = lb.putoutno" +
				 		   " and lb.LoanStatus = '90'" +
				 		   " and lb.Finishdate = '"+lastDate+"'" +
				 		   " order by xbc.inputdate ";
		logger.info("ȷ������:::" + sQuerySql);
		PreparedStatement psQuerySql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			String lnSacct = rs.getString("LNSAcct");
			psQueryRepatTmp.setString(1, lnSacct);
			ResultSet rsRepat = psQueryRepatTmp.executeQuery();
			while(rsRepat.next()){
				String repatLnSAcct = rsRepat.getString("Lnsacct");
				logger.info("�˱ʴ����ظ�,�����˺���:::" + repatLnSAcct);
				psDeleteRepat.setString(1, repatLnSAcct);
				psDeleteRepat.execute();
			}
			rsRepat.close();
			
			psInertSql.setString(1, lnSacct);
			psInertSql.setDouble(2, rs.getDouble("LNTTERM"));
			psInertSql.setDouble(3, rs.getDouble("LNTDAY"));
			psInertSql.setDouble(4, rs.getDouble("CAPITAL"));
			psInertSql.setDouble(5, rs.getDouble("INTAMT"));
			psInertSql.setDouble(6, rs.getDouble("OINT"));
			psInertSql.setDouble(7, rs.getDouble("NINT"));
			psInertSql.setDouble(8, rs.getDouble("Balance"));
			psInertSql.setDouble(9, rs.getDouble("LPAMT"));
			psInertSql.setString(10, rs.getString("ValDat"));
			psInertSql.setString(11, rs.getString("ValTime"));
			psInertSql.setString(12, rs.getString("SubBankId"));
			psInertSql.setString(13, rs.getString("Flag"));
			psInertSql.setString(14, rs.getString("InputDate"));
			psInertSql.setString(15, rs.getString("UpdateTime"));
			psInertSql.execute();
		}
		psQueryRepatTmp.close();
		psDeleteRepat.close();
		rs.close();
		psQuerySql.close();
		psInertSql.close();
	
	}
	
	/**
	 * ���ʼ�¼����xb_stat_records
	 * �����ֶΣ�ǰһ��ſ��ܱ�����ǰһ��ſ��ܽ���ʣ������������ʣ�౾��ǰһ�������¼�ܱ�����ǰһ�������¼�ܽ��
	 * @throws SQLException 
	 */
	private void XB_StatRecords() throws SQLException {
		//�ſ����
		int loanCount = 0;
		//�ſ���
		double loanAmtSum = 0;
		//ʣ�����
		int leftLoanCount = 0;
		//ʣ����
		double leftPrinSum = 0;
		//ǰһ���������
		int claimCount = 0;
		//������
		double claimSum = 0;
		//ǰһ�컹�����
		int rpyDetailCount = 0;
		//ǰһ�컹����
		double rpyDetailSum = 0;
		//��־
		String flag = "10";
		//��������
		String inputdate = lastDate;
		//��������
		String updateDate = lastDate;
		
		String insertSql = " insert into xb_stat_records(LoanCount,LoanAmtSum,LeftLoanCount,LeftPrinSum,ClaimCount," +
						   " ClaimAmtSum,Flag,InputDate,UpdateTime,RpyDetailCount,RpyDetailSum) " +
						   " values(?,?,?,?,?," +
						   " ?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		//ǰһ�컹������������ܶ�
		String lastRepay = " select sum(bb.actualcurrentcorp + bb.actualdefaultcorp+bb.actualoverduecorp+bb.actualinte " +
						   "  +bb.actualinnerinte+bb.actualoutinte + bb.actualinnerintefine+bb.actualoutintefine) as rpyDetailSum,count(*) as cntLast " +
						   " from back_bill bb,loan_balance lb " +
						   " where (bb.accdate = '"+lastDate+"' or bb.accdate = '"+deductDate+"') " +
						   " and bb.BillType in('20','21','22','23','24') " +
						   " and bb.BillStatus = '1' " +
						   " and lb.putoutno = bb.putoutno " +
						   " and lb.businesstype = '1150060'";
		PreparedStatement psLastRepay = connection.prepareStatement(lastRepay);
		//�ſ���ſ����
		String lastPutoutDate = " select sum(lb.businesssum) as BusinessSum,count(*) as cntPutoutDate " +
								" from loan_balance lb" +
								" where lb.putoutdate ='"+lastDate+"' " +
								" and lb.businesstype = '1150060'";
		
		PreparedStatement psLastPutoutDate = connection.prepareStatement(lastPutoutDate);
		//ʣ���ʣ�����
		String leftLoan = " select sum(lb.normalbalance+lb.overduebalance) as LeftSum,count(*) as cntLeft " +
						  " from loan_balance lb " +
						  " where lb.loanstatus in('0','1','4','5') and lb.normalbalance+lb.overduebalance > 0 and lb.businesstype = '1150060'";
		PreparedStatement psLeftLoan = connection.prepareStatement(leftLoan);
		//ǰһ��������������
		String haveCompensated = " select sum(xh.lpamt) as LpAmt, count(*) as cntLp " +
								 " from xb_havecompensated xh " +
								 " where xh.inputdate = '"+lastDate+"' ";
		PreparedStatement psHaveCompensated = connection.prepareStatement(haveCompensated);
		//�ſ���Ϣ��ѯ
		ResultSet rsLastDate = psLastPutoutDate.executeQuery();
		while(rsLastDate.next()){
			loanCount =  rsLastDate.getInt("cntPutoutDate");
			loanAmtSum = rsLastDate.getDouble("BusinessSum");
			//���ȿ���
			loanAmtSum = NumberTools.round(loanAmtSum, AccountConstants.MONEY_PRECISION);
			psInsertSql.setInt(1,loanCount);
			psInsertSql.setDouble(2, loanAmtSum);
		}
		psLastPutoutDate.close();
		rsLastDate.close();
		//ʣ�౾�𣬱�����ѯ
		ResultSet rsLeftLoan = psLeftLoan.executeQuery();
		while(rsLeftLoan.next()){
			leftLoanCount = rsLeftLoan.getInt("cntLeft");
			leftPrinSum = rsLeftLoan.getDouble("LeftSum");
			//���ȿ���
			leftPrinSum = NumberTools.round(leftPrinSum, AccountConstants.MONEY_PRECISION);
			psInsertSql.setInt(3, leftLoanCount);
			psInsertSql.setDouble(4, leftPrinSum);
		}
		psLeftLoan.close();
		rsLeftLoan.close();
		//���Ȿ�����������ѯ
		ResultSet rsHaveCompensated = psHaveCompensated.executeQuery();
		while(rsHaveCompensated.next()){
			claimCount = rsHaveCompensated.getInt("cntLp");
			claimSum = rsHaveCompensated.getDouble("LpAmt");
			//���ȿ���
			claimSum = NumberTools.round(claimSum, AccountConstants.MONEY_PRECISION);
			psInsertSql.setInt(5, claimCount);
			psInsertSql.setDouble(6, claimSum);
		}
		psHaveCompensated.close();
		rsHaveCompensated.close();
		//ǰһ�컹������������ܶ�
		ResultSet rsLastRepay = psLastRepay.executeQuery();
		while(rsLastRepay.next()){
			rpyDetailCount = rsLastRepay.getInt("cntLast");
			rpyDetailSum = rsLastRepay.getDouble("rpyDetailSum");
			//���ȿ���
			rpyDetailSum = NumberTools.round(rpyDetailSum, AccountConstants.MONEY_PRECISION);
			psInsertSql.setInt(10, rpyDetailCount);
			psInsertSql.setDouble(11, rpyDetailSum);
		}
		psLastRepay.close();
		rsLastRepay.close();
		//������Ϣ
		psInsertSql.setString(7, flag);
		psInsertSql.setString(8, inputdate);
		psInsertSql.setString(9, updateDate);
		psInsertSql.execute();
		psInsertSql.close();
	}
	
	
	/*
	 * ��ʼ�������б�,�������еĽڼ��յ�list��
	 * */
	private void initWorkFreeDateList() throws SQLException
	{
		workFreeDateList = new ArrayList<String>();
		String sLastDate = StringFunction.replace(lastDate,"/","-");
		String selectSql = " select CurDate from work_register where CurDate > '"+sLastDate+"' and WorkFlag <> '1' order by CurDate ";
		PreparedStatement psQuerySql = connection.prepareStatement(selectSql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next())
		{
			String sDate = rs.getString("CurDate");
			if(sDate==null || sDate.length() ==0)
				continue;
			sDate = StringFunction.replace(sDate,"-","/");
			workFreeDateList.add(sDate);
		}
		rs.close();
		psQuerySql.close();
	}
	
	/*
	 * ��������������������������
	 * */
	private String returnPayDate(int OverDays) throws Exception
	{
		//��������80����������(80���ʱ��Ҫ����)
		String sPayDate;
		sPayDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,80-OverDays);
		
		
		boolean bb = true;
		while(bb)
		{
			//�ڼ���Ҫ��ǰ,������������ǽڼ���,����ǰ��ǰһ��
			if(!getIsWorkDate(sPayDate)) break;
			sPayDate = DateTools.getRelativeDate(sPayDate,AccountConstants.TERM_UNIT_DAY,-1);
		}
		
		return sPayDate;
	}
	
	//������������,��ڼ����б��еĽڼ��ս��бȽ�,����ǽڼ���,�򷵻�true
	private boolean getIsWorkDate(String sDate){
		boolean b=false;
		for(int i=0;i<workFreeDateList.size();i++)
		{
			if(sDate.equals(workFreeDateList.get(i)))
			{
				b=true;
				break;
			}
		}
		return b;
	}
	
	//С������ȡ�ڴ���Ϣ"where fd.putoutno = ls.putoutno and fd.paydate = ls.paydate " +	" and fd.paydate = '"+rs.getString("payDate")+"'" +	"and fd.putoutno = '"+rs.getString("lnsacct")+"'";
	private Double getSterm(PreparedStatement termQuerySql,String payDate,String putOutNo) throws SQLException{
		double sterm = 0;
		termQuerySql.setString(1, payDate);
		termQuerySql.setString(2, putOutNo);
		ResultSet termRs = termQuerySql.executeQuery();
		if (termRs.next()){
			sterm = termRs.getDouble("sterm");
		}else{
			sterm = 1;
		}
		termRs.close();
		return sterm;
	}
	
	/*
	 * ��ʼ��iSerialCount
	 * */
	private void initSerialCount() throws SQLException
	{
		String selectSql = " select nvl(max(returnSeqNo),'') as SerialNo from XB_Returndetail where Inputdate = '"+deductDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		if(rs.next())
		{
			if(rs.getString("SerialNo") == null||rs.getString("SerialNo").length()==0){
				iSerialCount = 0;
			}else{
				if(rs.getString("SerialNo").startsWith("BF")){
					iSerialCount = Integer.valueOf(rs.getString("SerialNo").substring(11,18));
				}else{
					iSerialCount = Integer.valueOf(rs.getString("SerialNo").substring(9,16));
				}
			}
		}
		rs.close();
		psSelectSql.close();
	}
	
	private String createSerialNo(String putoutno,String FdPayDate,String FdAccDate) throws Exception
	{
		String payDate = FdPayDate.replace("/", "");
		String accDate = FdAccDate.replace("/", "");
		String repaChar = putoutno.substring(0, 2);
		putoutno = putoutno.replace(repaChar, "");
		return putoutno+payDate+accDate;
	}
	
}
