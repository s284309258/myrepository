package com.amarsoft.app.datax.gci.deductdata;


import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.deductacc.AmountSplit;
import com.amarsoft.task.TaskConstants;

public class BatchFund extends CommonExecuteUnit{
	
	private String selectFundSql;
	private String deleteSql;
	private String insertSql;
	private String updateSql;
	private PreparedStatement psDeleteDeductData;
	private PreparedStatement psUpdateDeductData;
	private PreparedStatement psInsertDeductData;
	private PreparedStatement psSelectSql;
	private int deductDateNum = 0;
	private int commitNum;
	//�������ʺ�
	private String fundAccNo;
	
	boolean ok = true; 

	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				if(returnFundFlag().equals("1"))
				{
					logger.info("��Ϊ�����Ϻ�������ֻ���ر�1������Ӧɾ���Ϻ��������Ӧ��������");
					fundDeleteDeductData();
				}
				else if(returnFundFlag().equals("2"))
				{
					logger.info("��ʼִ���Ϻ���������");
					fundUpdateDeductData();
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public String returnFundFlag() throws SQLException
	{
		String sReturn = "0";
		String sqlTemp = " select FundDealFlag from FUND_FLAG where FundName = 'SHGJJ' ";
		PreparedStatement psTempSql = connection.prepareStatement(sqlTemp);
		ResultSet rsTemp = psTempSql.executeQuery();
		while(rsTemp.next())
		{
			sReturn = rsTemp.getString("FundDealFlag");
		}
		rsTemp.close();
		psTempSql.close();
		return sReturn;
	}
	
	public void fundDeleteDeductData() throws SQLException
	{
		int icount = 0;
		deleteSql = " delete from Deduct_Data where PutOutNo = ?";
		psDeleteDeductData = connection.prepareStatement(deleteSql);
		
		selectFundSql = " select lb.PutOutNo"
					  +" from PublicFund_PutData t1,PublicFund_ActualData t3,Loan_Balance lb"
					  +" where t1.LoanAccNo = t3.LoanAccNo and t1.PutDate <> t3.PutDate and t1.LoanAccNo = lb.LoanAccNo ";
		psSelectSql =connection.prepareStatement(selectFundSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sLoanAccNo = rs.getString("PutOutNo"); 
			
			psDeleteDeductData.setString(1, sLoanAccNo);
			
			psDeleteDeductData.addBatch();
			deductDateNum++;
			icount++;
			
			if(deductDateNum>commitNum)
			{
				logger.info("��ɾ��"+icount+"����");
				psDeleteDeductData.executeBatch();
				connection.commit();
				deductDateNum=0;
			}
			
		}
		psDeleteDeductData.executeBatch();
		connection.commit();
		rs.close();
		psDeleteDeductData.close();
		psSelectSql.close();
		deductDateNum=0;
		logger.info("��ɾ��"+icount+"���� ɾ������ִ����ɡ�");
	}
	
	
	public void fundUpdateDeductData() throws SQLException
	{
		updateSql = " update Deduct_Data "
			+" set PayCurrentCorp= ?,ActualCurrentCorp= ?,PayDefaultCorp= ?,ActualDefaultCorp= ?,PayOverDueCorp= ?,ActualOverDueCorp= ?, "
			+" PayInte= ?,ActualInte= ?,PayInnerInte= ?,ActualInnerInte= ?,PayOutInte= ?,ActualOutInte= ?, " 
			+" PayInnerInteFine= ?,ActualInnerInteFine= ?,PayOutInteFine= ?,ActualOutInteFine= ?,AccountFlag = ?,PayDate=?,DeductAccNo=?,DeductAccNo1=?,DeductAccNo2=? "
			+" where PutOutNo=? and Sterm=? and AheadNum=?";
		psUpdateDeductData = connection.prepareStatement(updateSql);
		
		insertSql = " INSERT INTO Deduct_Data(PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,ActualCurrentCorp,PayDefaultCorp,ActualDefaultCorp, "
			+" PayOverDueCorp,ActualOverDueCorp,PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, "
			+" PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,AccountFlag,PayDate,DeductAccNo,DeductAccNo1,DeductAccNo2) "
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		psInsertDeductData = connection.prepareStatement(insertSql);
		
		selectFundSql = " select t3.BankCode,t3.LoanAccNo,t3.DeductAccount,t3.CustomerID,(t3.ActualMoney/100) as ActualMoney,t3.PutDate,t3.RushReturnFlag,t3.BusinessSubType,t3.InputDate,t3.UpLoadDate,lb.PutOutNo  "
			+" from PublicFund_ActualData t3,Loan_balance lb "
			+" where t3.LoanAccNo = lb.LoanAccNo and to_date(PutDate,'yyyymmdd')= to_date('"+deductDate+"','yyyy/mm/dd') ";
		psSelectSql =connection.prepareStatement(selectFundSql);
		
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			//��һ��������PutOutNo ��DeductDataȡ����PutOutNo��һ������
	    	ArrayList<DeductData> deductDateArrayList = new ArrayList<DeductData>();
	    	readDeductDataList(rs.getString("PutOutNo"),deductDateArrayList);
	    	
	    	//�ڶ��������ڴΡ����𡢷�Ϣ����Ϣ ����� ��3�еĽ��
	    	AmountSplit amoountSplit = new AmountSplit();
			ArrayList<DeductData> returnDeductDataList = amoountSplit.splitAmount(rs.getDouble("ActualMoney"),deductDateArrayList,"1","Fine@Inte@Corp");

			//��������01 ��������� 03 ��ϴ�����𲿷� ����
			if(rs.getString("BusinessSubType").equals("01")||rs.getString("BusinessSubType").equals("03"))
			{
				//�ۿʽΪ�����  ����ǰ������
				
				updateDeduct_data1(returnDeductDataList);
			}
			//���Ĳ���02��ҵ����  04��ϴ�����ҵ���� ����
			else
			{
				//�ۿʽΪ�����  ����ǰ������
				
				updateDeduct_data2(returnDeductDataList);
			}
			
			if(deductDateNum>commitNum)
			{
				psUpdateDeductData.executeBatch();
				psInsertDeductData.executeBatch();
				connection.commit();
				deductDateNum=0;
			}
			
		}
		psUpdateDeductData.executeBatch();
		psInsertDeductData.executeBatch();
		connection.commit();
		rs.getStatement().close();
		psUpdateDeductData.close();
		psInsertDeductData.close();
		psSelectSql.close();
	}
	
	//��ʼ��deductDateArrayList
	public void readDeductDataList(String sPutOutNo,ArrayList<DeductData> deductDateArrayList) throws SQLException
	{
    	String selectDeductSql = "select PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,ActualCurrentCorp,PayDefaultCorp,ActualDefaultCorp, "
			+" PayOverDueCorp,ActualOverDueCorp,PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, "
			+" PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,DeductAccNo,DeductAccNo1,DeductAccNo2 "
			+" from Deduct_Data "
			+" where PutOutNo = '"+sPutOutNo+"' and AheadNum = '0'"
			+" order by Sterm ";
    	PreparedStatement psSelectDeductSql =connection.prepareStatement(selectDeductSql);
		ResultSet rsTemp = psSelectDeductSql.executeQuery();
		while(rsTemp.next())
		{
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rsTemp.getString("PutOutNo"));
			deductData.setSTerm(rsTemp.getInt("Sterm"));
			deductData.setAheadNum(rsTemp.getInt("AheadNum"));
			deductData.setCurrency(rsTemp.getString("Currency"));
			deductData.setPayCurrentCorp(rsTemp.getDouble("PayCurrentCorp"));
			deductData.setPayDefaultCorp(rsTemp.getDouble("PayDefaultCorp"));
			deductData.setPayOverDueCorp(rsTemp.getDouble("PayOverDueCorp"));
			deductData.setPayInte(rsTemp.getDouble("PayInte"));
			deductData.setPayInnerInte(rsTemp.getDouble("PayInnerInte"));
			deductData.setPayOutInte(rsTemp.getDouble("PayOutInte"));
			deductData.setPayInnerInteFine(rsTemp.getDouble("PayInnerInteFine"));
			deductData.setPayOutInteFine(rsTemp.getDouble("PayOutInteFine"));
			deductData.setDeductAccNo(rsTemp.getString("DeductAccNo"));
			deductData.setDeductAccNo1(rsTemp.getString("DeductAccNo1"));
			deductData.setDeductAccNo2(rsTemp.getString("DeductAccNo2"));
			deductDateArrayList.add(deductData);
		}
		rsTemp.getStatement().close();
		psSelectDeductSql.close();
	}
	
	//���¿�ת���͵�Deduct_data
	public void updateDeduct_data1(ArrayList<DeductData> returnDeductDataList) throws SQLException
	{
		for(int i=0;i<returnDeductDataList.size();i++)
		{
			DeductData deductData = returnDeductDataList.get(i);
			int ii = checkPayAndActual(deductData);
			if(ii==1)
			{
				//�Ѵ����־��Ϊ��ת��־
				deductData.setAccountFlag("1");
				addPsUpdateDeductData(deductData);
				psUpdateDeductData.addBatch();
			}
			else if(ii==0)
			{
				//��������ʱ ��ֳ���һ�㻹��
				addPsUpdateDeductData(splitDeductData(deductData,"0","1"));
				//������п�ת�Ĺ�������
				addPsInsertDeductData(splitDeductData(deductData,"1","1")); 
				psUpdateDeductData.addBatch();
				psInsertDeductData.addBatch();
			}
			deductDateNum++;
		}
		
	}
	
	//�����轻400������Deduct_data
	public void updateDeduct_data2(ArrayList<DeductData> returnDeductDataList) throws SQLException
	{
		for(int i=0;i<returnDeductDataList.size();i++)
		{
			DeductData deductData = returnDeductDataList.get(i);
			int ii = checkPayAndActual(deductData);
			if(ii==1)
			{
				addPsUpdateDeductData(splitDeductData(deductData,"1","2"));
				psUpdateDeductData.addBatch();
			}
			else if(ii==0)
			{
				//��������ʱ ��ֳ���һ�㻹��
				addPsUpdateDeductData(splitDeductData(deductData,"0","2"));
				//������п�ת�Ĺ�������
				addPsInsertDeductData(splitDeductData(deductData,"1","2")); 
				psUpdateDeductData.addBatch();
				psInsertDeductData.addBatch();
			}
			deductDateNum++;
		}
	}
	
	//��������Ƿ��� ���巵��1  ��һ���ַ���0  û�й黹����-1
	public int checkPayAndActual(DeductData deductData)
	{
		double sumPayCorp = deductData.getPayCurrentCorp()+deductData.getPayDefaultCorp()+deductData.getPayOverDueCorp();
		double sumAcutalCorp = deductData.getActualCurrentCorp()+deductData.getActualDefaultCorp()+deductData.getActualOverDueCorp();
		
		double sumPayInte = deductData.getPayInte()+deductData.getPayInnerInte()+deductData.getPayOutInte();
		double sumActualInte = deductData.getActualInte()+deductData.getActualInnerInte()+deductData.getActualOutInte();

		double sumPayFine = deductData.getPayInnerInteFine()+deductData.getPayOutInteFine();
		double sumActualFine = deductData.getActualInnerInteFine()+deductData.getActualOutInteFine();
		
		double sumPay = sumPayCorp+sumPayInte+sumPayFine;
		double sumActual = sumAcutalCorp+sumActualInte+sumActualFine;
		//ȫ��ۿ�
		if(sumPay==sumActual)
			return 1;
		//���ֿۿ�
		else if(sumPay>sumActual || sumActual>0.0)
			return 0;
		//û�пۿ�
		else
			return -1;
	}
	
	//���ͬһ�ڳ���һ�����ɹ������ʺŻ���һ�����ɿͻ��ۿ��ʺŻ������������DeductData���в��  ����1��DeductData����  ����2������DeductData 0 Ϊ������ҵ���� 1 Ϊ���������� ����3���ۿ����� 1 Ϊ��ת 2Ϊʵ�ʹ�������
	public DeductData splitDeductData(DeductData deductData,String sReturnFlag,String sFundFlag)
	{
		DeductData fundDeductData = new DeductData();
		DeductData otherductData = new DeductData();
		
		String sPutOutNo= deductData.getPutOutNo();
		int iSTerm= deductData.getSTerm();
		int iAheadNum = deductData.getAheadNum();
		String sCurrency= deductData.getCurrency();
		double dPayCurrentCorp= deductData.getPayCurrentCorp();
		double dActualCurrentCorp= deductData.getActualCurrentCorp();
		double dPayDefaultCorp= deductData.getPayDefaultCorp();
		double dActualDefaultCorp= deductData.getActualDefaultCorp();
		double dPayOverDueCorp= deductData.getPayOverDueCorp();
		double dActualOverDueCorp = deductData.getActualOverDueCorp();
		double dPayInte= deductData.getPayInte();
		double dActualInte= deductData.getActualInte();
		double dPayInnerInte= deductData.getPayInnerInte();
		double dActualInnerInte= deductData.getActualInnerInte();
		double dPayOutInte= deductData.getPayOutInte();
		double dActualOutInte= deductData.getActualOutInte();
		double dPayInnerInteFine= deductData.getPayInnerInteFine();
		double dActualInnerInteFine= deductData.getActualInnerInteFine();
		double dPayOutInteFine= deductData.getPayOutInteFine();
		double dActualOutInteFine = deductData.getActualOutInteFine();
		String sPayDate= deductData.getPayDate();
		String sDeductAccNo= deductData.getDeductAccNo();
		String sDeductAccNo1= deductData.getDeductAccNo1();
		String sDeductAccNo2= deductData.getDeductAccNo2();
		
		otherductData.setPutOutNo(sPutOutNo);
		otherductData.setSTerm(iSTerm);
		otherductData.setAheadNum(iAheadNum);
		otherductData.setCurrency(sCurrency);
		otherductData.setPayCurrentCorp(dPayCurrentCorp-dActualCurrentCorp);
		otherductData.setActualCurrentCorp(0.0);
		otherductData.setPayDefaultCorp(dPayDefaultCorp-dActualDefaultCorp);
		otherductData.setActualDefaultCorp(0.0);
		otherductData.setPayOverDueCorp(dPayOverDueCorp-dActualOverDueCorp);
		otherductData.setActualOverDueCorp(0.0);
		otherductData.setPayInte(dPayInte-dActualInte);
		otherductData.setActualInte(0.0);
		otherductData.setPayInnerInte(dPayInnerInte-dActualInnerInte);
		otherductData.setActualInnerInte(0.0);
		otherductData.setPayOutInte(dPayOutInte-dActualOutInte);
		otherductData.setActualOutInte(0.0);
		otherductData.setPayInnerInteFine(dPayInnerInteFine-dActualInnerInteFine);
		otherductData.setActualInnerInteFine(0.0);
		otherductData.setPayOutInteFine(dPayOutInteFine-dActualOutInteFine);
		otherductData.setActualOutInteFine(0.0);
		otherductData.setAccountFlag("0");
		otherductData.setPayDate(sPayDate);
		otherductData.setDeductAccNo(sDeductAccNo);
		otherductData.setDeductAccNo1(sDeductAccNo1);
		otherductData.setDeductAccNo2(sDeductAccNo2);
		
		if(sFundFlag.equals("1"))
		{
			fundDeductData.setPutOutNo(sPutOutNo);
			fundDeductData.setSTerm(iSTerm);
			fundDeductData.setAheadNum(iAheadNum);
			fundDeductData.setCurrency(sCurrency);
			fundDeductData.setPayCurrentCorp(dActualCurrentCorp);
			fundDeductData.setActualCurrentCorp(dActualCurrentCorp);
			fundDeductData.setPayDefaultCorp(dActualDefaultCorp);
			fundDeductData.setActualDefaultCorp(dActualDefaultCorp);
			fundDeductData.setPayOverDueCorp(dActualOverDueCorp);
			fundDeductData.setActualOverDueCorp(dActualOverDueCorp);
			fundDeductData.setPayInte(dActualInte);
			fundDeductData.setActualInte(dActualInte);
			fundDeductData.setPayInnerInte(dActualInnerInte);
			fundDeductData.setActualInnerInte(dActualInnerInte);
			fundDeductData.setPayOutInte(dActualOutInte);
			fundDeductData.setActualOutInte(dActualOutInte);
			fundDeductData.setPayInnerInteFine(dActualInnerInteFine);
			fundDeductData.setActualInnerInteFine(dActualInnerInteFine);
			fundDeductData.setPayOutInteFine(dActualOutInteFine);
			fundDeductData.setActualOutInteFine(dActualOutInteFine);
			fundDeductData.setAccountFlag("1");
			fundDeductData.setPayDate(sPayDate);
		}
		else
		{
			fundDeductData.setPutOutNo(sPutOutNo);
			fundDeductData.setSTerm(iSTerm);
			fundDeductData.setAheadNum(iAheadNum);
			fundDeductData.setCurrency(sCurrency);
			fundDeductData.setPayCurrentCorp(dActualCurrentCorp);
			fundDeductData.setActualCurrentCorp(0.0);
			fundDeductData.setPayDefaultCorp(dActualDefaultCorp);
			fundDeductData.setActualDefaultCorp(0.0);
			fundDeductData.setPayOverDueCorp(dActualOverDueCorp);
			fundDeductData.setActualOverDueCorp(0.0);
			fundDeductData.setPayInte(dActualInte);
			fundDeductData.setActualInte(0.0);
			fundDeductData.setPayInnerInte(dActualInnerInte);
			fundDeductData.setActualInnerInte(0.0);
			fundDeductData.setPayOutInte(dActualOutInte);
			fundDeductData.setActualOutInte(0.0);
			fundDeductData.setPayInnerInteFine(dActualInnerInteFine);
			fundDeductData.setActualInnerInteFine(0.0);
			fundDeductData.setPayOutInteFine(dActualOutInteFine);
			fundDeductData.setActualOutInteFine(0.0);
			fundDeductData.setAccountFlag("2");
			fundDeductData.setPayDate(sPayDate);
			fundDeductData.setDeductAccNo(fundAccNo);
		}

		if(sReturnFlag.equals("0"))  //0 Ϊ������ҵ�����
			return otherductData;
		else 
			return fundDeductData;  //1 Ϊ���������� 
		
	}
	
	public void addPsUpdateDeductData(DeductData deductData) throws SQLException
	{
		psUpdateDeductData.setDouble(1,deductData.getPayCurrentCorp());
		psUpdateDeductData.setDouble(2,deductData.getActualCurrentCorp());
		psUpdateDeductData.setDouble(3,deductData.getPayDefaultCorp());
		psUpdateDeductData.setDouble(4,deductData.getActualDefaultCorp());
		psUpdateDeductData.setDouble(5,deductData.getPayOverDueCorp());
		psUpdateDeductData.setDouble(6,deductData.getActualOverDueCorp());
		psUpdateDeductData.setDouble(7,deductData.getPayInte());
		psUpdateDeductData.setDouble(8,deductData.getActualInte());
		psUpdateDeductData.setDouble(9,deductData.getPayInnerInte());
		psUpdateDeductData.setDouble(10,deductData.getActualInnerInte());
		psUpdateDeductData.setDouble(11,deductData.getPayOutInte());
		psUpdateDeductData.setDouble(12,deductData.getActualOutInte());
		psUpdateDeductData.setDouble(13,deductData.getPayInnerInteFine());
		psUpdateDeductData.setDouble(14,deductData.getActualInnerInteFine());
		psUpdateDeductData.setDouble(15,deductData.getPayOutInteFine());
		psUpdateDeductData.setDouble(16,deductData.getActualOutInteFine());
		psUpdateDeductData.setString(17,deductData.getAccountFlag());
		psUpdateDeductData.setString(18,deductData.getPayDate());
		psUpdateDeductData.setString(19,deductData.getDeductAccNo());
		psUpdateDeductData.setString(20,deductData.getDeductAccNo1());
		psUpdateDeductData.setString(21,deductData.getDeductAccNo2());
		psUpdateDeductData.setString(22,deductData.getPutOutNo());
		psUpdateDeductData.setInt(23,deductData.getSTerm());
		psUpdateDeductData.setInt(24,deductData.getAheadNum());
		
	}
	public void addPsInsertDeductData(DeductData deductData) throws SQLException
	{
		psInsertDeductData.setString(1,deductData.getPutOutNo());
		psInsertDeductData.setInt(2,deductData.getSTerm());
		psInsertDeductData.setInt(3,deductData.getAheadNum());
		psInsertDeductData.setString(4,deductData.getCurrency());
		psInsertDeductData.setDouble(5,deductData.getPayCurrentCorp());
		psInsertDeductData.setDouble(6,deductData.getActualCurrentCorp());
		psInsertDeductData.setDouble(7,deductData.getPayDefaultCorp());
		psInsertDeductData.setDouble(8,deductData.getActualDefaultCorp());
		psInsertDeductData.setDouble(9,deductData.getPayOverDueCorp());
		psInsertDeductData.setDouble(10,deductData.getActualOverDueCorp());
		psInsertDeductData.setDouble(11,deductData.getPayInte());
		psInsertDeductData.setDouble(12,deductData.getActualInte());
		psInsertDeductData.setDouble(13,deductData.getPayInnerInte());
		psInsertDeductData.setDouble(14,deductData.getActualInnerInte());
		psInsertDeductData.setDouble(15,deductData.getPayOutInte());
		psInsertDeductData.setDouble(16,deductData.getActualOutInte());
		psInsertDeductData.setDouble(17,deductData.getPayInnerInteFine());
		psInsertDeductData.setDouble(18,deductData.getActualInnerInteFine());
		psInsertDeductData.setDouble(19,deductData.getPayOutInteFine());
		psInsertDeductData.setDouble(20,deductData.getActualOutInteFine());
		psInsertDeductData.setString(21,deductData.getAccountFlag());
		psInsertDeductData.setString(22,deductData.getPayDate());
		psInsertDeductData.setString(23,deductData.getDeductAccNo());
		psInsertDeductData.setString(24,deductData.getDeductAccNo1());
		psInsertDeductData.setString(25,deductData.getDeductAccNo2());
	}
	
}
