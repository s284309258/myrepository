package com.amarsoft.app.datax.gci;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

import filetrans.BankFileHandleServiceImp;
import filetrans.ResultBean;

public class DealWithExpFileSH extends CommonExecuteUnit {

	private String sSaveFilePath;// ��ȡ�ļ���ַ
	private String sBISFrontIp;// ǰ�û�IP
	private String sBISFrontPort;// ǰ�ö˿�
	private String NASUrl;// NAS�ռ��ַ
	private static final String READEIN = "in";
	private List<String> fileList = null;
	private boolean fileStatus = false;    // �ļ��Ƿ����ɹ���־
	private String keyUrl;
	private int commitNum=1;
	private boolean tryStatus = false; //�Ƿ��쳣��־�ļ��Ƿ����ɹ���־


	public int execute() {
		try {
			String sInit = super.init();
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("=========��ʼ��ʼ������=======");
				initPara();
				getFileNameList();
				logger.info("=========��ʼ���������=======");
				logger.info("=========��ʼ����ƽ���ػ��ļ�=======");
				dealFile(fileList);
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				logger.info("=========����ƽ���ػ��ļ����=======");
				clearResource();
				return unitStatus;
			}
		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
			unitStatus = TaskConstants.ES_SUCCESSFUL;
			clearResource();
			return unitStatus;
		}
	}
	
	
	/**
	 * ��ʼ��������Ϣ
	 */
	public void initPara() throws Exception {
		NASUrl = ARE.getProperty("NASUrl");
		sSaveFilePath = getProperty("SaveFilePath");
		sBISFrontIp = getProperty("BISFrontIp");
		sBISFrontPort = getProperty("BISFrontPort");
		fileList = new ArrayList();
		keyUrl = getProperty("keyUrl");
		commitNum =getProperty("commitNum",1);
		
	}
	
	public void dealFile(List<String> fileList) throws Exception{
		String fileDate = ""; // �ļ�����
		String sFileName = ""; // �ļ���
		String filePath = ""; // �滻���ļ�·��
		for (int i = 0; i < fileList.size(); i++) {
			fileStatus = false;
			sFileName = fileList.get(i);
			fileDate = sFileName.substring(24, 32);

			filePath = StringFunction.replace(sSaveFilePath,
					"{$CurrentDate}", fileDate);

			String sFilePath = NASUrl + filePath + sFileName;
			File file = new File(NASUrl + filePath);
			if (!file.exists()) {
				file.mkdir();
			}
			ResultBean bean = BankFileHandleServiceImp.recvBankFile(
					sFileName, sFilePath, sBISFrontIp,
					Integer.parseInt(sBISFrontPort), READEIN);
			if (bean == null) {
				continue;
			}
			if ("999999".equals(bean.getPA_RSLT_CODE())) {
				logger.info("======��ȡƽ���ػ��ļ�:" + sFileName
						+ " �ɹ���ʼ�������ݿ�=====");
				BatchUpdateData(sFilePath);
				UpdateFileStatus(sFileName, fileStatus);
				logger.info("=========ƽ���ػ��ļ�:" + sFileName
						+ " �ɹ��������ݿ����===========");
			}
		}
	}

	/**
	 * ȡ��δ�����ļ����б�
	 * 
	 * @throws SQLException
	 */
	public void getFileNameList() throws Exception {
		PreparedStatement selSql = null;
		String selectSql = "select sl.returnfilename from SHFILE_LIST sl where sl.filestatus='0' ";
		selSql = connection.prepareStatement(selectSql);
		ResultSet rs = null;
		rs = selSql.executeQuery();
		while (rs.next()) {
			if (!"".equals(rs.getString("returnfilename"))
					&& rs.getString("returnfilename") != null) {
				fileList.add(rs.getString("returnfilename"));
			}
		}
		rs.close();
		selSql.close();
	}

	public void UpdateFileStatus(String sFileName, boolean flag) 
			throws Exception {
		if (flag) {
			PreparedStatement upSql = null;
			String updateSql = "update SHFILE_LIST sl set sl.filestatus='1' where sl.returnfilename= ? ";
			upSql = connection.prepareStatement(updateSql);
			upSql.setString(1, sFileName);
			upSql.executeUpdate();
			upSql.close();
		}
	}

	/**
	 * ��ȡBIS�Ļ�ȡƽ���ػ��ļ����뵽���ݿ�
	 * 
	 * @throws Exception
	 */
	public void BatchUpdateData(String fileName) throws Exception {
		tryStatus=false;
		File inputFile = new File(fileName);
		String sLine = "";
		int countNo = 0; // ����������
		String decryptPassword="";
		TOAPasswordUtil passfile= new TOAPasswordUtil();

		// ��ȡ�����ļ�
		if (!inputFile.exists()) {
			fileStatus = false;
			logger.error("ƽ���ػ��ļ�" + fileName + "�����ڣ�");
		} else {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName), "UTF-8"));
			sLine = reader.readLine();
			decryptPassword = passfile.decryptPassword(NASUrl+keyUrl+"TOAkey.dat",sLine);

			String[] lins = decryptPassword.split("\\|");
			Long linNumber = Long.parseLong(lins[1]);
			while (reader.readLine() != null) {
				countNo++;
			}
			// У���ļ�ͷ������ʱ�������Ƿ����
			if (linNumber * 1 != countNo) {
				fileStatus = false;
				reader.close();
				logger.error("�ļ������������� �ļ�ͷ����" + linNumber + " ʵ����������  "
						+ countNo);
			}
			if (linNumber > 0) {
				try{
				reader = new BufferedReader(new InputStreamReader(
						new FileInputStream(fileName), "UTF-8"));
				reader.readLine();

				String lineData;
				String[] dataArray;
				int i = 0;
				PreparedStatement upSql = null;
				String updateSql = " update SHDATA_VAlUE sv "
						+ " set sv.POLICYNO         = ? ," + // ������1
						" sv.INSURANCESUM     = ?," + // ���ս��2
						" sv.INSURANCEFARE    = ?," + // ���շ�3
						" sv.INSURANCESECTION = ?," + // �����ڼ�4
						" sv.FIRSTBENEFICIARY = ?," + // ��һ������5
						" sv.INSURANCETYPE    = ?," + // �μӱ���6
						" sv.ERRORREMARK      = ?" + // ������Ϣ7
						" where sv.serialnos=? 	"; // ������ˮ��8
				upSql = connection.prepareStatement(updateSql);

				while ((lineData = reader.readLine()) != null) {
					i++;
					if(!"".equals(lineData)){
						if(lineData.length()>20){
							decryptPassword = passfile.decryptPassword(NASUrl+keyUrl+"TOAkey.dat",lineData);
							dataArray = decryptPassword.split("\\|");
							if (!"".equals(dataArray[0])) {
								upSql.setString(1, dataArray[0]);
								upSql.setDouble(2, Double.parseDouble(dataArray[2]));
								upSql.setDouble(3, Double.parseDouble(dataArray[3]));
								upSql.setString(4, dataArray[4]);
								upSql.setString(5, dataArray[5]);
								upSql.setString(6, dataArray[6]);
								upSql.setString(7, "");
								upSql.setString(8, dataArray[7]);
								upSql.addBatch();
							} else {
								upSql.setString(1, "");
								upSql.setDouble(2, 0.0);
								upSql.setDouble(3, 0.0);
								upSql.setString(4, "");
								upSql.setString(5, "");
								upSql.setString(6, "");
								upSql.setString(7, dataArray[12]);
								upSql.setString(8, dataArray[7]);
								upSql.addBatch();
							}
							if (i > commitNum) {
								upSql.executeBatch();
								connection.commit();
								i = 0;
							}
						}
					}
				}
				upSql.executeBatch();
				connection.commit();
				upSql.close();
				}catch(Exception e){
					reader.close();
					fileStatus = false;
					tryStatus=true;
					logger.error("�ļ�"+fileName+"���ݴ���ʧ��");
					e.printStackTrace();
				}
			}
			if(!tryStatus){
			reader.close();
			fileStatus = true;
			}

		}
	}

	/**
	 * �õ����ڸ�ʽYYYY/MM/DD
	 * 
	 * @param sAPPALYDATE
	 * @return
	 */
	private String getDateFormat(String sAPPALYDATE) {
		sAPPALYDATE = sAPPALYDATE.trim();
		sAPPALYDATE = sAPPALYDATE.replace("-", "/");
		// ������ڸ�ʽΪ8λ
		if (sAPPALYDATE.length() == 8 || sAPPALYDATE.length() == 10) {
			if (sAPPALYDATE.contains("/") && sAPPALYDATE.length() == 8) {
				sAPPALYDATE = sAPPALYDATE.replace("/", "");
				sAPPALYDATE = sAPPALYDATE.substring(0, 4) + "/0"
						+ sAPPALYDATE.substring(4, 5) + "/0"
						+ sAPPALYDATE.substring(5);
			} else {
				// ��ʽΪYYYYMMDD
				sAPPALYDATE = sAPPALYDATE.replace("/", "");
				sAPPALYDATE = sAPPALYDATE.substring(0, 4) + "/"
						+ sAPPALYDATE.substring(4, 6) + "/"
						+ sAPPALYDATE.substring(6);
			}
		}
		if (sAPPALYDATE.length() == 9) {
			// ��ʽΪYYYYMMDD
			if (sAPPALYDATE.substring(0, 4).indexOf("/") == -1) {
				if (sAPPALYDATE.substring(sAPPALYDATE.indexOf("/") + 1,
						sAPPALYDATE.lastIndexOf("/")).length() == 1) {
					sAPPALYDATE = sAPPALYDATE.replace("/", "");
					sAPPALYDATE = sAPPALYDATE.substring(0, 4) + "/0"
							+ sAPPALYDATE.substring(4, 5) + "/"
							+ sAPPALYDATE.substring(5);
				} else {
					sAPPALYDATE = sAPPALYDATE.replace("/", "");
					sAPPALYDATE = sAPPALYDATE.substring(0, 4) + "/"
							+ sAPPALYDATE.substring(4, 6) + "/0"
							+ sAPPALYDATE.substring(6);
				}
			}
		}
		return sAPPALYDATE;
	}

}
