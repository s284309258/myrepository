package com.amarsoft.app.datax.gci;

public class PamsAs400 {

	//��ݱ��
	private String sPutOutNo;
	//����
	private String sCurrency;
	//���
	private double amount;
	//�ۿ��˺ţ���������
	private String sDudectAccNo;
	//�տ��˺ţ����뷽��
	private String sRelativeAccNo;
	//������ˮ��ͬʱ��Ч��־��
	private String deductSerialNo;
	//�������(������Ϣ����Ϣ������)
	private String amountAttribute;
	//�ڴ�
	private int Sterm;
	//��������
	private String sPayType;
	//��ǰ������ˮ��
	private String sAheadSerialNo;
	//�ۿ��˺�1
	private String deductAccNo1;
	//�ۿ��˺�2
	private String deductAccNo2;
	
	public PamsAs400()
	{}
	public PamsAs400(String sPutOutNo,String sCurrency,double amount,String sDudectAccNo,String sRelativeAccNo,
			String deductSerialNo,String amountAttribute,int Sterm,String sPayType,String sAheadSerialNo,String deductAccNo1,String deductAccNo2)
	{
		this.sPutOutNo=sPutOutNo;
		this.sCurrency=sCurrency;
		this.amount=amount;
		this.sDudectAccNo=sDudectAccNo;
		this.sRelativeAccNo=sRelativeAccNo;
		this.deductSerialNo=deductSerialNo;
		this.amountAttribute=amountAttribute;
		this.Sterm=Sterm;
		this.sPayType=sPayType;
		this.sAheadSerialNo = sAheadSerialNo;
		this.deductAccNo1 = deductAccNo1;
		this.deductAccNo2 = deductAccNo2;
	}
	
	
	public String getSPayType() {
		return sPayType;
	}
	public void setSPayType(String payType) {
		sPayType = payType;
	}
	public String getSPutOutNo() {
		return sPutOutNo;
	}
	public void setSPutOutNo(String putOutNo) {
		sPutOutNo = putOutNo;
	}
	public String getSCurrency() {
		return sCurrency;
	}
	public void setSCurrency(String currency) {
		sCurrency = currency;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getSDudectAccNo() {
		return sDudectAccNo;
	}
	public void setSDudectAccNo(String dudectAccNo) {
		sDudectAccNo = dudectAccNo;
	}
	public String getSRelativeAccNo() {
		return sRelativeAccNo;
	}
	public void setSRelativeAccNo(String relativeAccNo) {
		sRelativeAccNo = relativeAccNo;
	}
	public String getDeductSerialNo() {
		return deductSerialNo;
	}
	public void setDeductSerialNo(String deductSerialNo) {
		this.deductSerialNo = deductSerialNo;
	}
	public String getSaheadSerialNo() {
		return sAheadSerialNo;
	}
	public void setAheadSerialNo(String sAheadSerialNo) {
		this.sAheadSerialNo = sAheadSerialNo;
	}
	public String getAmountAttribute() {
		return amountAttribute;
	}
	public void setAmountAttribute(String amountAttribute) {
		this.amountAttribute = amountAttribute;
	}
	public int getSterm() {
		return Sterm;
	}
	public void setSterm(int sterm) {
		Sterm = sterm;
	}
	public String getDeductAccNo1() {
		return deductAccNo1;
	}
	public void setDeductAccNo1(String deductAccNo1) {
		this.deductAccNo1 = deductAccNo1;
	}
	public String getDeductAccNo2() {
		return deductAccNo2;
	}
	public void setDeductAccNo2(String deductAccNo2) {
		this.deductAccNo2 = deductAccNo2;
	}
	
	
}
