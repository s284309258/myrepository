package com.amarsoft.app.datax.gci;

public class DeductAccountInfo {

	//�˻�����
	private String AccountName;
	//�˺�
	private String AccountNo;
	
	public DeductAccountInfo()
	{}
	
	public DeductAccountInfo(String AccountName,String AccountNo)
	{
		this.AccountName = AccountName;
		this.AccountNo = AccountNo;
	}
	
	public String getAccountName() {
		return AccountName;
	}
	public void setAccountName(String accountName) {
		AccountName = accountName;
	}
	public String getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}
	
	
	
}
