package com.amarsoft.app.datax.gci;

import java.io.File;

import com.amarsoft.Exec.RunTimeInfo;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class CommandExec extends CommonExecuteUnit{

	private String sCommand;
	//private String sDmpFileName;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				//��ʼ������
				initPara();
				//ִ������
				RunTimeInfo rti = ExecCommand(sCommand) ;
		    	 if(rti.getExitValue()!=0)
		    	 {
		    		 logger.error("��������,������Ϣ");
		    		 logger.error(rti.getErrorInfo());  		
		    		 throw new Exception("���"+sCommand+"��ִ��ʧ�ܣ�");
		    	 }
		    	 else
		    	 {
		    		 logger.info(rti.getInputInfo());
		    	 }
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/*
	 * ��ʼ��·���д���Ĳ���
	 * */
	private void initPara() throws Exception
	{
		sCommand = getProperty("Command");
		//sDmpFileName = getProperty("DmpFileName");
		String NAS = ARE.getProperty("NASUrl");
		
		sCommand=StringFunction.replace(sCommand,"{$CurrentDate}",deductDate);
		sCommand=StringFunction.replace(sCommand,"{$CurrentMonth}",currentMonth);
		sCommand=StringFunction.replace(sCommand,"{$LastDate}",lastDate);
		sCommand=StringFunction.replace(sCommand,"{$LastMonth}",lastMonth);
		sCommand=StringFunction.replace(sCommand,"{$NextDate}",nextDate);
		sCommand=StringFunction.replace(sCommand,"{$NextMonth}",nextMonth);
		
		sCommand = StringFunction.replace(sCommand,"{$NAS}",NAS);
		
		/*sDmpFileName=StringFunction.replace(sDmpFileName,"{$CurrentDate}",deductDate);
		sDmpFileName=StringFunction.replace(sDmpFileName,"{$CurrentMonth}",currentMonth);
		sDmpFileName=StringFunction.replace(sDmpFileName,"{$LastDate}",lastDate);
		sDmpFileName=StringFunction.replace(sDmpFileName,"{$LastMonth}",lastMonth);
		sDmpFileName=StringFunction.replace(sDmpFileName,"{$NextDate}",nextDate);
		sDmpFileName=StringFunction.replace(sDmpFileName,"{$NextMonth}",nextMonth);*/
		
		//delFile(sDmpFileName);
	}
	
	
	/*
	 * ɾ�������ļ�
	 * */
	public void delFile(String sFileName) throws Exception
	{
		File file = new File(sFileName);
		if(file.exists())
		{
			boolean b = file.delete();
			if(!b)
			{
				throw new Exception("�ļ���"+sFileName+"��ɾ��ʧ�ܣ�");
			}
			
		}
	}
	
	
	/*
	 * ����RunTimeInfo�๫�÷���,ִ��Command����
	 * */
	public static RunTimeInfo ExecCommand(String sCommand) {
		RunTimeInfo rti =  null;
		try {

			rti = new RunTimeInfo(sCommand);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rti;
	}
	
}
