package com.amarsoft.app.datax.gci.deductacc.thread;

import java.io.Reader;
import java.io.StringReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class BatchDataCleanThread extends BatchThread{
	
	private ResultSet rsexecute = null;
	
	private PreparedStatement ps_select_business_apply = null;
	private PreparedStatement ps_update_business_apply = null;
	private PreparedStatement ps_select_business_contract = null;
	private PreparedStatement ps_update_business_contract = null;
	private PreparedStatement ps_select_guaranty_contract = null;
	private PreparedStatement ps_update_guaranty_contract = null;
	private PreparedStatement ps_select_business_applicant = null;
	private PreparedStatement ps_update_business_applicant = null;
	private PreparedStatement ps_select_loan_balance = null;
	private PreparedStatement ps_update_loan_balance = null;
	private PreparedStatement ps_select_loan_changeapply = null;
	private PreparedStatement ps_update_loan_changeapply = null;
	private PreparedStatement ps_select_guaranty_owner = null;
	private PreparedStatement ps_update_guaranty_owner = null;
	private PreparedStatement ps_select_finacing_account = null;
	private PreparedStatement ps_update_finacing_account = null;
	private PreparedStatement ps_delete_customer_info = null;
	private PreparedStatement ps_delete_ind_info = null;
	private PreparedStatement ps_delete_customer_relative = null;
	private PreparedStatement ps_insert_data_backup = null;
	private PreparedStatement ps_select_customer_info = null;
	private PreparedStatement ps_select_ind_info = null;
	private PreparedStatement ps_select_customer_relative = null;
	private PreparedStatement ps_select_loan_balance_off = null;
	private PreparedStatement ps_update_loan_balance_off = null;
	private PreparedStatement ps_select_business_putout = null;
	private PreparedStatement ps_update_business_putout = null;
	private PreparedStatement ps_select_jointguaranty_info = null;
	private PreparedStatement ps_update_jointguaranty_info = null;
	private PreparedStatement ps_select_customer_work = null;
	private PreparedStatement ps_update_customer_work = null;
	private PreparedStatement ps_select_customer_finance = null;
	private PreparedStatement ps_update_customer_finance = null;
	private PreparedStatement ps_select_business_putout_relative = null;
	private PreparedStatement ps_update_business_putout_relative = null;
	private PreparedStatement ps_select_credit_idle = null;
	private PreparedStatement ps_update_credit_idle = null;
	private PreparedStatement ps_select_business_continue = null;
	private PreparedStatement ps_update_business_continue = null;
	
	public void run() {
		try {
			mergeCustomerInfo();
			this.connection.commit();
			//�ɹ�ע���߳�
			mainProcess.threadLogOff( this, TaskConstants.ES_SUCCESSFUL);//���̳߳ɹ�ִ��
		} catch (Exception e) {
			e.printStackTrace();
			try {
				this.connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			// �̱߳����쳣���������ȱ����������󣬲�ע���߳�
			this.logger.error("�����ͻ��ϲ��̡߳�" + this.getName() + "�������쳣����������ȳ��򱨸����...");
			mainProcess.threadLogOff(this, TaskConstants.ES_FAILED);//��ʧ�ܷ�ʽ�����߳�״̬
		} finally {
			this.close();
		}
		return;
	}
	
	
	/**
	 * �ϲ��ͻ���Ϣ
	 * �����������������Ϣ��ECIF�ͻ�һ�������˶�����ͻ������
	 * 
	 * @throws Exception
	 */
	public void mergeCustomerInfo() throws Exception {
		try {
			// -------------------------��ʼ���ϲ��ű���ʼ-----------------------------
			// 1.business_apply
			String select_business_apply = "select serialno from business_apply where customerid = ?";
			ps_select_business_apply = connection.prepareStatement(select_business_apply);

			String update_business_apply = "update business_apply set customerid = ?,customername = ? where customerid = ?";
			ps_update_business_apply = connection.prepareStatement(update_business_apply);

			// 2.business_contract
			String select_business_contract = "select serialno from business_contract where customerid = ?";
			ps_select_business_contract = connection.prepareStatement(select_business_contract);

			String update_business_contract = "update business_contract set customerid = ?,customername = ? where customerid = ?";
			ps_update_business_contract = connection.prepareStatement(update_business_contract);

			// 3.business_putout
			String select_business_putout = "select serialno from business_putout where customerid = ?";
			ps_select_business_putout = connection.prepareStatement(select_business_putout);

			String update_business_putout = "update business_putout set customerid = ?,customername = ? where customerid = ?";
			ps_update_business_putout = connection.prepareStatement(update_business_putout);

			// 4.guaranty_contract
			String select_guaranty_contract = "select serialno from guaranty_contract where guarantorid = ?";
			ps_select_guaranty_contract = connection.prepareStatement(select_guaranty_contract);

			String update_guaranty_contract = "update guaranty_contract set guarantorid = ?,guarantorname = ? where guarantorid = ?";
			ps_update_guaranty_contract = connection.prepareStatement(update_guaranty_contract);

			// 4.business_applicant
			String select_business_applicant = "select serialno from business_applicant where applicantid = ?";
			ps_select_business_applicant = connection.prepareStatement(select_business_applicant);

			String update_business_applicant = "update business_applicant set applicantid = ?,applicantname = ? where applicantid = ?";
			ps_update_business_applicant = connection.prepareStatement(update_business_applicant);

			// 5.loan_balance
			String select_loan_balance = "select putoutno from loan_balance where customerid = ?";
			ps_select_loan_balance = connection.prepareStatement(select_loan_balance);

			String update_loan_balance = "update loan_balance set customerid = ?,customername = ? where customerid = ?";
			ps_update_loan_balance = connection.prepareStatement(update_loan_balance);

			// 6.loan_changeapply
			String select_loan_changeapply = "select changeserialno from loan_changeapply where customerid = ?";
			ps_select_loan_changeapply = connection.prepareStatement(select_loan_changeapply);

			String update_loan_changeapply = "update loan_changeapply set customerid = ?,customername = ? where customerid = ?";
			ps_update_loan_changeapply = connection.prepareStatement(update_loan_changeapply);

			// 7.guaranty_owner
			String select_guaranty_owner = "select serialno from guaranty_owner where customerid = ?";
			ps_select_guaranty_owner = connection.prepareStatement(select_guaranty_owner);

			String update_guaranty_owner = "update guaranty_owner set customerid = ?,ownername = ? where customerid = ?";
			ps_update_guaranty_owner = connection.prepareStatement(update_guaranty_owner);

			// 8.finacing_account
			String select_finacing_account = "select finacingaccno from finacing_account where customerid = ?";
			ps_select_finacing_account = connection.prepareStatement(select_finacing_account);

			String update_finacing_account = "update finacing_account set customerid = ? where customerid = ?";
			ps_update_finacing_account = connection.prepareStatement(update_finacing_account);

			// 9.customer_info
			String select_customer_info = "select * from customer_info where customerid =? ";
			ps_select_customer_info = connection.prepareStatement(select_customer_info);

			String delete_customer_info = "delete from customer_info where customerid = ?";
			ps_delete_customer_info = connection.prepareStatement(delete_customer_info);

			// 10.ind_info
			String select_ind_info = "select * from ind_info where customerid =? ";
			ps_select_ind_info = connection.prepareStatement(select_ind_info);

			String delete_ind_info = "delete from ind_info where customerid = ?";
			ps_delete_ind_info = connection.prepareStatement(delete_ind_info);

			// 11.customer_relative
			String select_customer_relative = "select * from customer_relative where customerid =? ";
			ps_select_customer_relative = connection.prepareStatement(select_customer_relative);

			String delete_customer_relative = "delete from customer_relative where customerid = ?";
			ps_delete_customer_relative = connection.prepareStatement(delete_customer_relative);

			// 12.loan_balance_off
			String select_loan_balance_off = "select * from loan_balance_off where customerid =? ";
			ps_select_loan_balance_off = connection.prepareStatement(select_loan_balance_off);

			String update_loan_balance_off = "update loan_balance_off set customerid = ?,CustomerName=? where customerid = ?";
			ps_update_loan_balance_off = connection.prepareStatement(update_loan_balance_off);

			// 12.data_backup
			String insert_data_backup = "insert into data_backup(serialno,objectno,sqlrecord,objecttype,inputdate) values(?,?,?,?,?)";
			ps_insert_data_backup = connection.prepareStatement(insert_data_backup);

			// 13.jointguaranty_info
			String select_jointguaranty_info = "select serialno from jointguaranty_info where customerid = ?";
			ps_select_jointguaranty_info = connection.prepareStatement(select_jointguaranty_info);

			String update_jointguaranty_info = "update jointguaranty_info set customerid = ?,CustomerName=? where customerid = ?";
			ps_update_jointguaranty_info = connection.prepareStatement(update_jointguaranty_info);

			// 14.customer_work
			String select_customer_work = "select serialno from customer_work where customerid = ?";
			ps_select_customer_work = connection.prepareStatement(select_customer_work);

			String update_customer_work = "update customer_work set customerid = ? where customerid = ?";
			ps_update_customer_work = connection.prepareStatement(update_customer_work);

			// 15.customer_finance
			String select_customer_finance = "select serialno from customer_finance where customerid = ?";
			ps_select_customer_finance = connection.prepareStatement(select_customer_finance);

			String update_customer_finance = "update customer_finance set customerid = ? where customerid = ?";
			ps_update_customer_finance = connection.prepareStatement(update_customer_finance);

			// 16.business_putout_relative
			String select_business_putout_relative = "select SerialNo from business_putout_relative where customerid = ?";
			ps_select_business_putout_relative = connection.prepareStatement(select_business_putout_relative);

			String update_business_putout_relative = "update business_putout_relative set customerid = ?,CustomerName=? where customerid = ?";
			ps_update_business_putout_relative = connection.prepareStatement(update_business_putout_relative);

			// 17.credit_idle
			String select_credit_idle = "select serialno from credit_idle where customerid = ?";
			ps_select_credit_idle = connection.prepareStatement(select_credit_idle);

			String update_credit_idle = "update credit_idle set customerid = ?,CustomerName=? where customerid = ?";
			ps_update_credit_idle = connection.prepareStatement(update_credit_idle);

			// 18.business_continue
			String select_business_continue = "select serialno from business_continue where customerid = ?";
			ps_select_business_continue = connection.prepareStatement(select_business_continue);

			String update_business_continue = "update business_continue set customerid = ?,CustomerName=? where customerid = ?";
			ps_update_business_continue = connection.prepareStatement(update_business_continue);
			// -------------------------��ʼ���ϲ��ű�����---------------------

			// ��ѯ�ͻ���Ϣ��ϸ��Ϣ
			String sqlMfCustomer = "select customerid from customer_info where mfcustomerid = ? and customername = ? and certtype = ? and certid = ? order by( case when customerid like 'RL%' then 0 when customerid like 'QY%' then 2 else 1 end) asc ";
			PreparedStatement psmf = connection.prepareStatement(sqlMfCustomer);

			// ��ѯ�ظ��ͻ���Ϣ
			String sqlCustomer = "select count(1) as cnt ,ci.mfcustomerid,ci.customername,ci.certtype,ci.certid from customer_info ci where ci.mfcustomerid is not null and ci.customername is not null and ci.certtype is not null and ci.certid is not null and customertype ='03' group by ci.mfcustomerid, ci.customername, ci.certtype, ci.certid having count(1) > 1" +
					" and MOD(to_number(ci.mfcustomerid),?) = ?";
			PreparedStatement ps = connection.prepareStatement(sqlCustomer);
			ps.setInt(1, this.mod);
			ps.setInt(2, this.modvalue);
			ResultSet rs = ps.executeQuery();
			int sCount = 0;
			while (rs.next()) {
				sCount++;
				String sMfCustomerID = DataConvert.toString(rs.getString("mfcustomerid"));
				String sCustomerName = DataConvert.toString(rs.getString("customername"));
				String sCertType = DataConvert.toString(rs.getString("certtype"));
				String sCertID = DataConvert.toString(rs.getString("certid"));
				if ("".equals(sMfCustomerID) || "".equals(sCustomerName) || "".equals(sCertType) || "".equals(sCertID))continue;

				// ��ѯ�����ظ��ͻ�����ϸ��Ϣ
				psmf.setString(1, sMfCustomerID);
				psmf.setString(2, sCustomerName);
				psmf.setString(3, sCertType);
				psmf.setString(4, sCertID);
				ResultSet rsmf = psmf.executeQuery();
				String SaveCustomerID = "";
				int i = 0;
				while (rsmf.next()) {
					i++;
					if ("".equals(SaveCustomerID)) {
						SaveCustomerID = DataConvert.toString(rsmf.getString("customerid"));
						continue;
					}
					String sDropCustomerID = DataConvert.toString(rsmf.getString("customerid"));// ���ϲ��ͻ���
					if ("".equals(sDropCustomerID))
						continue;
					// �ϲ��ͻ��š����ݡ�ɾ�����ϲ���Ϣ
					String sReturnSql = this.CustomerComDeal(SaveCustomerID, sDropCustomerID, sCustomerName);
					this.DelSQl(SaveCustomerID, sReturnSql);
				}
				rsmf.close();
				
				if(i<=1){
					logger.info("�����쳣��"+SaveCustomerID);
				}
				
				if(sCount % 1 == 0 ){
					this.executeBatch();
					connection.commit();
					if(sCount%100==0){
						logger.info("�������䡾"+mod+","+modvalue+"���Ѿ�ִ��"+sCount+"����");
					}
				}
			}
			this.executeBatch();
			connection.commit();
			psmf.close();
			this.closePs();// �ر�����ִ�нű����������Ӷ���
			rs.close();
			ps.close();
			logger.info("�ظ��ͻ���Ϣ�ܼ�¼��"+sCount+"����");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * ����ִ�з���
	 * @param sMainCustomerID �����ͻ���
	 * @param sDropCustomerID ���ϲ��ͻ���
	 * @param sCustomerName �ͻ�����
	 * @return
	 * @throws Exception
	 */
	public String CustomerComDeal(String sMainCustomerID, String sDropCustomerID, String sCustomerName) throws Exception {
		try {
			String RlockSQL = "";
			// ----------------------------------------------------------------1------------------------------------------------------------------------------------
			// ���BA���ϲ�������
			ps_select_business_apply.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_apply.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update BUSINESS_APPLY set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();

			// ����BA��
			ps_update_business_apply = this.updateTable_Name(ps_update_business_apply, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------2------------------------------------------------------------------------------------
			// ���BC���ϲ�����Ϣ
			ps_select_business_contract.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_contract.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update BUSINESS_CONTRACT set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����BC��
			ps_update_business_contract= this.updateTable_Name(ps_update_business_contract, sMainCustomerID, sCustomerName, sDropCustomerID);

			
			// ���BP���ϲ�����Ϣ
			ps_select_business_putout.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_putout.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update business_putout set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����BP��
			ps_update_business_putout = this.updateTable_Name(ps_update_business_putout, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------3------------------------------------------------------------------------------------
			// ���GC���ϲ�����Ϣ
			ps_select_guaranty_contract.setString(1, sDropCustomerID);
			rsexecute = ps_select_guaranty_contract.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update GUARANTY_CONTRACT set GuarantorID = '" + sDropCustomerID + "',GuarantorName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����GC��
			ps_update_guaranty_contract = this.updateTable_Name(ps_update_guaranty_contract, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------4------------------------------------------------------------------------------------
			// ���ҹ�ͬ�����business_applicant���ϲ��ļ�¼
			ps_select_business_applicant.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_applicant.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update BUSINESS_APPLICANT set ApplicantID = '" + sDropCustomerID + "',ApplicantName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ���¹�ͬ����˱�
			ps_update_business_applicant = this.updateTable_Name(ps_update_business_applicant, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------5------------------------------------------------------------------------------------
			// ����LOAN_BALANCE���ϲ��ļ�¼
			ps_select_loan_balance.setString(1, sDropCustomerID);
			rsexecute = ps_select_loan_balance.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("PutOutNo") != null)
					RlockSQL += "update LOAN_BALANCE set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where PutOutNo = '" + rsexecute.getString("PutOutNo") + "';";
			}
			rsexecute.close();
			// ����LOAN_BALANCE��
			ps_update_loan_balance = this.updateTable_Name(ps_update_loan_balance, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------6------------------------------------------------------------------------------------
			// ����LOAN_CHANGEAPPLY���ϲ��ļ�¼
			ps_select_loan_changeapply.setString(1, sDropCustomerID);
			rsexecute = ps_select_loan_changeapply.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("ChangeSerialNo") != null)
					RlockSQL += "update LOAN_CHANGEAPPLY set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where ChangeSerialNo = '" + rsexecute.getString("ChangeSerialNo") + "';";
			}
			rsexecute.close();
			// ����LOAN_CHANGEAPPLY��
			ps_update_loan_changeapply = this.updateTable_Name(ps_update_loan_changeapply, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------7------------------------------------------------------------------------------------
			// ��ѯGUARANTY_OWNER��
			ps_select_guaranty_owner.setString(1, sDropCustomerID);
			rsexecute = ps_select_guaranty_owner.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update GUARANTY_OWNER set CustomerID = '" + sDropCustomerID + "',OwnerName='" + sCustomerName + "' where SerialNo = '" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();

			// ����GUARANTY_OWNER��
			ps_update_guaranty_owner = this.updateTable_Name(ps_update_guaranty_owner, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------8------------------------------------------------------------------------------------
			// ����FINACING_ACCOUNT���ϲ��ļ�¼
			ps_select_finacing_account.setString(1, sDropCustomerID);
			rsexecute = ps_select_finacing_account.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("FinacingAccNo") != null)
					RlockSQL += "update FINACING_ACCOUNT set CustomerID = '" + sDropCustomerID + "' where FinacingAccNo ='" + rsexecute.getString("FinacingAccNo") + "';";
			}
			rsexecute.close();
			// ����FINACING_ACCOUNT��
			ps_update_finacing_account = this.updateTable(ps_update_finacing_account, sMainCustomerID, sDropCustomerID);

			// ----------------------------------------------------------------9------------------------------------------------------------------------------------
			// ����loan_balance_off���ϲ��ļ�¼
			ps_select_loan_balance_off.setString(1, sDropCustomerID);
			rsexecute = ps_select_loan_balance_off.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update loan_balance_off set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����loan_balance_off��
			ps_update_loan_balance_off = this.updateTable_Name(ps_update_loan_balance_off, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------10------------------------------------------------------------------------------------
			// ����jointguaranty_info���ϲ��ļ�¼
			ps_select_jointguaranty_info.setString(1, sDropCustomerID);
			rsexecute = ps_select_jointguaranty_info.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update jointguaranty_info set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����jointguaranty_info��
			ps_update_jointguaranty_info = this.updateTable_Name(ps_update_jointguaranty_info, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------11------------------------------------------------------------------------------------
			// ����customer_work���ϲ��ļ�¼
			ps_select_customer_work.setString(1, sDropCustomerID);
			rsexecute = ps_select_customer_work.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update customer_work set CustomerID = '" + sDropCustomerID + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����customer_work��
			ps_update_customer_work = this.updateTable(ps_update_customer_work, sMainCustomerID, sDropCustomerID);

			// ----------------------------------------------------------------12------------------------------------------------------------------------------------
			// ����customer_finance���ϲ��ļ�¼
			ps_select_customer_finance.setString(1, sDropCustomerID);
			rsexecute = ps_select_customer_finance.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update customer_finance set CustomerID = '" + sDropCustomerID + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����customer_finance��
			ps_update_customer_finance = this.updateTable(ps_update_customer_finance, sMainCustomerID, sDropCustomerID);

			// ----------------------------------------------------------------13------------------------------------------------------------------------------------
			// ����business_putout_relative���ϲ��ļ�¼
			ps_select_business_putout_relative.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_putout_relative.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update business_putout_relative set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����business_putout_relative��
			ps_update_business_putout_relative = this.updateTable_Name(ps_update_business_putout_relative, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------14------------------------------------------------------------------------------------
			// ����credit_idle���ϲ��ļ�¼
			ps_select_credit_idle.setString(1, sDropCustomerID);
			rsexecute = ps_select_credit_idle.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update credit_idle set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����credit_idle��
			ps_update_credit_idle = this.updateTable_Name(ps_update_credit_idle, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ----------------------------------------------------------------15------------------------------------------------------------------------------------
			// ����business_continue���ϲ��ļ�¼
			ps_select_business_continue.setString(1, sDropCustomerID);
			rsexecute = ps_select_business_continue.executeQuery();
			while (rsexecute.next()) {
				if (rsexecute.getString("SerialNo") != null)
					RlockSQL += "update business_continue set CustomerID = '" + sDropCustomerID + "',CustomerName='" + sCustomerName + "' where SerialNo ='" + rsexecute.getString("SerialNo") + "';";
			}
			rsexecute.close();
			// ����business_continue��
			ps_update_business_continue = this.updateTable_Name(ps_update_business_continue, sMainCustomerID, sCustomerName, sDropCustomerID);

			// ------------------------------------------------------------��ɾ������------------------------------------------
			// ɾ������¼
			// ����Customer_info,��ɾ����Ӧ�ļ�¼
			ps_select_customer_info.setString(1, sDropCustomerID);
			rsexecute = ps_select_customer_info.executeQuery();
			String sReturnSql = getBackUpSql(rsexecute, "customer_info");

			if (!"".equals(sReturnSql))RlockSQL += sReturnSql + ";";
			ps_delete_customer_info.setString(1, sDropCustomerID);
			ps_delete_customer_info.addBatch();

			// ����IND_INFO����ɾ����Ӧ�ļ�¼
			ps_select_ind_info.setString(1, sDropCustomerID);
			rsexecute = ps_select_ind_info.executeQuery();
			sReturnSql = getBackUpSql(rsexecute, "ind_info");

			if (!"".equals(sReturnSql))RlockSQL += sReturnSql + ";";
			ps_delete_ind_info.setString(1, sDropCustomerID);
			ps_delete_ind_info.addBatch();

			// ����CUSTOMER_RELATIVE����ɾ����Ӧ�ļ�¼
			ps_select_customer_relative.setString(1, sDropCustomerID);
			rsexecute = ps_select_customer_relative.executeQuery();
			sReturnSql = getBackUpSql(rsexecute, "customer_relative");

			if (!"".equals(sReturnSql))RlockSQL += sReturnSql + ";";
			ps_delete_customer_relative.setString(1, sDropCustomerID);
			ps_delete_customer_relative.addBatch();

			return RlockSQL;
		} catch (Exception e) {
			throw e;
		}
	}

	// ���ݷ���
	public String getBackUpSql(ResultSet rsexecute, String TableName) throws SQLException {
		String sInsertSQL = "insert into " + TableName + "(";
		String sValuesSQL = " values(";
		if (rsexecute.next()) {
			ResultSetMetaData rsmd = rsexecute.getMetaData();
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				sInsertSQL = sInsertSQL + rsmd.getColumnName(i) + ",";
				int iFieldType = rsmd.getColumnType(i);
				if (isNumeric(iFieldType)) {
					String iFieldValue = rsexecute.getString(rsmd.getColumnName(i));
					if (iFieldValue == null)
						sValuesSQL += "null,";
					else if ("".equals(iFieldValue))
						sValuesSQL += "null,";
					else
						sValuesSQL = sValuesSQL + iFieldValue + ",";
				} else {
					String iFieldValue = rsexecute.getString(rsmd.getColumnName(i));
					if (iFieldValue == null)
						sValuesSQL += "null,";
					else if ("".equals(iFieldValue))
						sValuesSQL += "null,";
					else
						sValuesSQL = sValuesSQL + "'" + iFieldValue + "',";
				}
			}
			if (sInsertSQL.length() > 0) {
				sInsertSQL = sInsertSQL.substring(0, sInsertSQL.length() - 1);
				sInsertSQL = sInsertSQL + ")";
			}
			if (sValuesSQL.length() > 0) {
				sValuesSQL = sValuesSQL.substring(0, sValuesSQL.length() - 1);
				sValuesSQL = sValuesSQL + ")";
			}
			rsexecute.close();
			return sInsertSQL + sValuesSQL;
		} else {
			rsexecute.close();
			return "";
		}
	}

	// �ж��ֶ������Ƿ�Ϊ��������
	private static boolean isNumeric(int iType) {
		if (iType == java.sql.Types.BIGINT || iType == java.sql.Types.SMALLINT || iType == java.sql.Types.DECIMAL || iType == java.sql.Types.NUMERIC || iType == java.sql.Types.DOUBLE || iType == java.sql.Types.FLOAT || iType == java.sql.Types.REAL)
			return true;
		return false;
	}

	public PreparedStatement updateTable_Name(PreparedStatement psUpdateSqlname,String sMainCustomerID,String sCustomerName,String sDropCustomerID) throws Exception
	{
		psUpdateSqlname.setString(1, sMainCustomerID);
		psUpdateSqlname.setString(2, sCustomerName);
		psUpdateSqlname.setString(3, sDropCustomerID);
		psUpdateSqlname.addBatch();
		return psUpdateSqlname;
	}
	
	public PreparedStatement updateTable(PreparedStatement psUpdateSql,String sMainCustomerID,String sDropCustomerID) throws Exception
	{
		psUpdateSql.setString(1, sMainCustomerID);
		psUpdateSql.setString(2, sDropCustomerID);
		psUpdateSql.addBatch();
		return psUpdateSql;
	}
	
	/**
	 * �������ݺϲ���SQL��¼
	 * @param SaveCustomerID �����ͻ���ˮ��
	 * @param SQL ����SQL�ű�
	 * @throws Exception
	 */
	public void DelSQl(String SaveCustomerID, String SQL) throws Exception {
		try {
			String sSerialNo = com.amarsoft.app.datax.gci.deductacc.BatchDataClean.getSerialNo(connection, deductDate,"data_backup");
			Reader reader = new StringReader(SQL);
			ps_insert_data_backup.setString(1, sSerialNo);
			ps_insert_data_backup.setString(2, SaveCustomerID);
			ps_insert_data_backup.setCharacterStream(3, reader, SQL.length());
			ps_insert_data_backup.setString(4, "BatchComCustomer");
			ps_insert_data_backup.setString(5, deductDate);
			ps_insert_data_backup.addBatch();
		} catch (Exception e) {
			throw e;
		}
	}

	//����ִ�кϲ����
	public void executeBatch() throws Exception {
		if (ps_update_business_apply != null)
			ps_update_business_apply.executeBatch();
		if (ps_update_business_contract != null)
			ps_update_business_contract.executeBatch();
		if (ps_update_guaranty_contract != null)
			ps_update_guaranty_contract.executeBatch();
		if (ps_update_business_applicant != null)
			ps_update_business_applicant.executeBatch();
		if (ps_update_loan_balance != null)
			ps_update_loan_balance.executeBatch();
		if (ps_update_loan_changeapply != null)
			ps_update_loan_changeapply.executeBatch();
		if (ps_update_guaranty_owner != null)
			ps_update_guaranty_owner.executeBatch();
		if (ps_update_finacing_account != null)
			ps_update_finacing_account.executeBatch();
		if (ps_delete_customer_info != null)
			ps_delete_customer_info.executeBatch();
		if (ps_delete_ind_info != null)
			ps_delete_ind_info.executeBatch();
		if (ps_delete_customer_relative != null)
			ps_delete_customer_relative.executeBatch();
		if (ps_insert_data_backup != null)
			ps_insert_data_backup.executeBatch();
		if (ps_update_loan_balance_off != null)
			ps_update_loan_balance_off.executeBatch();
		if (ps_update_business_putout != null)
			ps_update_business_putout.executeBatch();
		if (ps_update_jointguaranty_info != null)
			ps_update_jointguaranty_info.executeBatch();
		if (ps_update_customer_work != null)
			ps_update_customer_work.executeBatch();
		if (ps_update_customer_finance != null)
			ps_update_customer_finance.executeBatch();
		if (ps_update_business_putout_relative != null)
			ps_update_business_putout_relative.executeBatch();
		if (ps_update_credit_idle != null)
			ps_update_credit_idle.executeBatch();
		if (ps_update_business_continue != null)
			ps_update_business_continue.executeBatch();
	}

	//����ִ�йر����Ӷ���
	public void closePs() throws Exception {
		if (ps_select_business_apply != null)
			ps_select_business_apply.close();
		if (ps_update_business_apply != null)
			ps_update_business_apply.close();
		if (ps_select_business_contract != null)
			ps_select_business_contract.close();
		if (ps_update_business_contract != null)
			ps_update_business_contract.close();
		if (ps_select_guaranty_contract != null)
			ps_select_guaranty_contract.close();
		if (ps_update_guaranty_contract != null)
			ps_update_guaranty_contract.close();
		if (ps_select_business_applicant != null)
			ps_select_business_applicant.close();
		if (ps_update_business_applicant != null)
			ps_update_business_applicant.close();
		if (ps_select_loan_balance != null)
			ps_select_loan_balance.close();
		if (ps_update_loan_balance != null)
			ps_update_loan_balance.close();
		if (ps_select_loan_changeapply != null)
			ps_select_loan_changeapply.close();
		if (ps_update_loan_changeapply != null)
			ps_update_loan_changeapply.close();
		if (ps_select_guaranty_owner != null)
			ps_select_guaranty_owner.close();
		if (ps_update_guaranty_owner != null)
			ps_update_guaranty_owner.close();
		if (ps_select_finacing_account != null)
			ps_select_finacing_account.close();
		if (ps_update_finacing_account != null)
			ps_update_finacing_account.close();
		if (ps_delete_customer_info != null)
			ps_delete_customer_info.close();
		if (ps_delete_ind_info != null)
			ps_delete_ind_info.close();
		if (ps_delete_customer_relative != null)
			ps_delete_customer_relative.close();
		if (ps_insert_data_backup != null)
			ps_insert_data_backup.close();
		if (ps_select_customer_info != null)
			ps_select_customer_info.close();
		if (ps_select_ind_info != null)
			ps_select_ind_info.close();
		if (ps_select_customer_relative != null)
			ps_select_customer_relative.close();
		if (ps_select_loan_balance_off != null)
			ps_select_loan_balance_off.close();
		if (ps_update_loan_balance_off != null)
			ps_update_loan_balance_off.close();
		if (ps_select_business_putout != null)
			ps_select_business_putout.close();
		if (ps_update_business_putout != null)
			ps_update_business_putout.close();
		if (ps_select_jointguaranty_info != null)
			ps_select_jointguaranty_info.close();
		if (ps_update_jointguaranty_info != null)
			ps_update_jointguaranty_info.close();
		if (ps_select_customer_work != null)
			ps_select_customer_work.close();
		if (ps_update_customer_work != null)
			ps_update_customer_work.close();
		if (ps_select_customer_finance != null)
			ps_select_customer_finance.close();
		if (ps_update_customer_finance != null)
			ps_update_customer_finance.close();
		if (ps_select_business_putout_relative != null)
			ps_select_business_putout_relative.close();
		if (ps_update_business_putout_relative != null)
			ps_update_business_putout_relative.close();
		if (ps_select_credit_idle != null)
			ps_select_credit_idle.close();
		if (ps_update_credit_idle != null)
			ps_update_credit_idle.close();
		if (ps_select_business_continue != null)
			ps_select_business_continue.close();
		if (ps_update_business_continue != null)
			ps_update_business_continue.close();
	}
}
