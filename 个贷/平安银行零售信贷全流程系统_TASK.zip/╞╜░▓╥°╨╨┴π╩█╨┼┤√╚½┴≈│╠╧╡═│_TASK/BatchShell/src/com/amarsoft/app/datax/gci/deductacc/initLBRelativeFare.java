package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class initLBRelativeFare extends CommonExecuteUnit{

	private int icount = 0;
	private int commitNum ;
	private int dealNum = 0;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				logger.info("��ʼ�������������������Ϣ...");
				initLBFare();
				logger.info("��ʼ�����");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void initLBFare() throws SQLException
	{
		String updateSql = " update LoanBalance_Relative set Feetype=?,Feemethod=?,FareMoneyType=?,Amount=?,Moneyproportion=? "
						 + " where PutOutNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select lb.PutOutNo,bd.FeeType,bd.FeeMethod,bd.FareMoneytType,bd.Amount,bd.Moneyproportion "
						 + " from Loan_Balance lb,Business_Define bd "
						 + " where lb.BusinessType = bd.TypeNo and lb.Putoutdate = '"+deductDate+"'  and bd.FeeType is not null ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,rs.getString("FeeType"));
			psUpdateSql.setString(2,rs.getString("FeeMethod"));
			psUpdateSql.setString(3,rs.getString("FareMoneytType"));
			psUpdateSql.setDouble(4,rs.getDouble("Amount"));
			psUpdateSql.setDouble(5,rs.getDouble("Moneyproportion"));
			psUpdateSql.setString(6,rs.getString("PutOutNo"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"��!");
			}
		}
		psUpdateSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psUpdateSql.close();
		logger.info("һ������"+icount+"��!");
	}
}
