package com.amarsoft.app.datax.gci;

public class scpFileInfo {
	public String LocalFile = "";
	public String RemoteUserName = "";
	public String RemoteServerName = "";
	public String RemoteFile = "";
	boolean sendResult = true ; //trueΪ�ɹ� false Ϊʧ��
	
    public long getLocalFileSize()
    {
    	java.io.File file = new java.io.File(LocalFile);
        if(!file.exists())	
        	return 0;
        else 
        	return file.length();
    }
}
