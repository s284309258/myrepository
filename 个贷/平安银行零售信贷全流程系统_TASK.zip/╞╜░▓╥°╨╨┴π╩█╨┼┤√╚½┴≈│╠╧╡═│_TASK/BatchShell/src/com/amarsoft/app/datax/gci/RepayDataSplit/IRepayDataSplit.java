package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;


import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.LoanAccount;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.app.datax.gci.AheadDeductData;

public interface IRepayDataSplit {

	public ArrayList<BatchErrorRecord> arrayListErrorRecord =new ArrayList<BatchErrorRecord>();
	
	public ArrayList<BatchErrorRecord> getErrorList();
	
	public boolean preCheck(ArrayList<DeductData> deductDateList,ArrayList<AheadDeductData> aheadDeductdataList,ArrayList<FareDetaill> fareDetailList,ArrayList<AcctFeeInfoBatch> acctFeeInfoList,HashMap<String,DeductAccountInfo> accountMap) throws Exception;
	
	public ArrayList<PamsAs400> execute(LoanAccount loanAccount) throws Exception;
	
}
