package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.AreaExponent;
import com.amarsoft.app.datax.gci.GuarantyFrequency;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.entity.OrgInfo;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;

public class BatchGuarantyChange extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int serialCount = 0;
	private HashMap<String,AreaExponent> AreaExponentHashMap = new HashMap<String,AreaExponent>();
	private ArrayList<GuarantyFrequency> frequencyList = new ArrayList<GuarantyFrequency>();
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��ʼ���guaranty_change����������������......");
				Statement stmt=connection.createStatement();
				stmt.execute("delete from guaranty_change where InputDate = '"+nextDate+"' ");
				stmt.close();
				logger.info("���guaranty_change������������������ɡ�");
				
				logger.info("��ʼ��������ѺƷ�ع�.....");
				guarantyChange();
				logger.info("����ѺƷ�ع���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
		
	public void guarantyChange() throws Exception
	{
		
		initAreaExponent();
		
		String insertSql = " insert into guaranty_change(SerialNo,GuarantyID,ChangeDate,ChangeType,ChangeMethod,Balance,NewConfirmValue,InputDate,UpdateDate,OldExponent,NewExponent,OldGuarantyRate,Status,OldConfirmValue,MaxOverDays) "
			             + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String updateSql = " update Guaranty_Info set UpdateDate=?,ReevaluateValue=?,ReevaluateDate=? "
						 + " where GuarantyID = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String tempSql = " select sum(lb.NormalBalance+lb.DefaultBalance+lb.OverdueBalance+lb.CurrentBalance) as sumBalance from Loan_Balance lb where lb.ContractSerialNo = ? ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		
		String overDaysSql = "  select max(lr.Overdays) as MaxOverDays " +
				" from Guaranty_Relative gr,Loan_Balance lb,Loanbalance_Relative lr  " +
				"  where gr.objectno = lb.contractserialno and lr.Putoutno = lb.putoutno and gr.GuarantyID = ? ";
		PreparedStatement psOverDaysSql = connection.prepareStatement(overDaysSql);
		//ȡ�״��϶���ֵ,�ϴ��϶���ֵ,�ϴ��϶���ֵ�������뵽GC����������ʾ,�״��϶���ֵ����������
		String selectSql = " select gi.GuarantyID,bc.serialNo as ContractSerialNo,bc.BusinessType,gi.ReevaluateDate,nvl(gi.ConfirmValue, 0) as ConfirmValue,nvl(gi.ReevaluateValue, 0) as ReevaluateValue, " +
				" gi.GuarantyArea,nvl(gi.MarkIndex, 0) as MarkIndex,gi.GuarantyRate,bc.operateorgid as orgid,bc.putoutdate as PutOutDate " +
				" from Guaranty_Info gi, Guaranty_Relative gr, business_contract bc " +
				" where gi.GuarantyId = gr.GuarantyId and gr.ObjectNo = bc.serialNo and gr.ObjectType in('CBContractApply','SWContractApply') " +
				" and bc.FinishDate is null and gi.GuarantyType = '020010' and bc.PutOutDate is not null ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double dSumBalance = 0.0;
			psTempSql.setString(1,rs.getString("ContractSerialNo"));
			ResultSet rsTemp = psTempSql.executeQuery();
			if(rsTemp.next())
			{
				dSumBalance = rsTemp.getDouble("sumBalance");
			}
			rsTemp.close();
			
			if(rs.getString("ReevaluateDate")!=null && rs.getString("ReevaluateDate").length() != 0 )
			{
				//��������Ѿ�ִ�й��ع�������
				if(rs.getString("ReevaluateDate").substring(0,7).equals(nextMonth))
					continue;
			}
			//����ѺƷ�ع�Ƶ�ʼ�� ���ո�ѺƷ�Ƿ���Ҫ����
			if(!isTodayChange(rs.getString("BusinessType"),rs.getString("OrgID"),rs.getString("PutOutDate")))
				continue;

			double dNewExponent = returnEvalnetValue(rs.getString("GuarantyArea"));
			if(dNewExponent==0)
			{
				errorRecord(rs.getString("GuarantyArea"),"GuarantyArea","������ָ�����ô���");
				continue;
			}
			if(rs.getDouble("MarkIndex")==0)
			{
				errorRecord(rs.getString("GuarantyID"),"GuarantyInfo","��Ѻ����ָ������");
				continue;
			}
			
			double dNewEvalnetValue = returnNewEvalnetValue(rs.getDouble("ConfirmValue"),dNewExponent,rs.getDouble("MarkIndex"));
			
			psUpdateSql.setString(1,nextDate);
			psUpdateSql.setDouble(2,dNewEvalnetValue);
			psUpdateSql.setString(3,nextDate);
			psUpdateSql.setString(4,rs.getString("GuarantyID"));
			psUpdateSql.addBatch();
			
			int maxOverDays = 0;
			psOverDaysSql.setString(1,rs.getString("GuarantyID"));
			ResultSet overDaysRs = psOverDaysSql.executeQuery();
			if(overDaysRs.next())
			{
				maxOverDays = overDaysRs.getInt("MaxOverDays");
			}
			overDaysRs.close();
			
			psInsertSql.setString(1,createSerialNo());
			psInsertSql.setString(2,rs.getString("GuarantyID"));
			psInsertSql.setString(3,nextMonth);
			psInsertSql.setString(4,"01");
			psInsertSql.setString(5,"02");
			psInsertSql.setDouble(6,dSumBalance);
			psInsertSql.setDouble(7,dNewEvalnetValue);
			psInsertSql.setString(8,nextDate);
			psInsertSql.setString(9,nextDate);
			psInsertSql.setDouble(10,rs.getDouble("MarkIndex"));
			psInsertSql.setDouble(11,dNewExponent);
			psInsertSql.setDouble(12,rs.getDouble("GuarantyRate"));
			psInsertSql.setString(13,"1");
			psInsertSql.setDouble(14,rs.getDouble("ReevaluateValue"));
			psInsertSql.setInt(15,maxOverDays);
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"����");
			}	
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psUpdateSql.close();
		psSelectSql.close();
		psTempSql.close();
		psOverDaysSql.close();
		logger.info("һ������"+icount+"����");
	}
	
	//�������������ָ�����������в�Ʒ��Ӧ��ѺƷ�ع�Ƶ��
	public void initAreaExponent() throws SQLException
	{
		//�����������ָ��
		String loadSql1 = " select ItemNo,nvl(Attribute2,0) as Attribute2 from code_library where codeno = 'AreaCode' and IsInUse = '1' order by ItemNo ";
		PreparedStatement psLoadSql1 = connection.prepareStatement(loadSql1);
		ResultSet rsTemp1 = psLoadSql1.executeQuery();
		while(rsTemp1.next())
		{
			String sAreaCodeNo = rsTemp1.getString("ItemNo");
			AreaExponent areaExponent = new AreaExponent();
			areaExponent.setAreaCode(sAreaCodeNo);
			areaExponent.setExponent(rsTemp1.getDouble("Attribute2"));
			AreaExponentHashMap.put(sAreaCodeNo,areaExponent);
		}
		rsTemp1.close();
		psLoadSql1.close();
		
		String loadSql2 = " select ItemNo,nvl(ItemAttribute,' ') as ItemAttribute,nvl(RelativeCode,' ') as RelativeCode from Code_library where CodeNo = 'GuarantyFrequency' and IsInuse = '1' ";
		PreparedStatement psloadSql2 = connection.prepareStatement(loadSql2);
		ResultSet rsTemp2 = psloadSql2.executeQuery();
		while(rsTemp2.next())
		{
			GuarantyFrequency guarantyFrequency = new GuarantyFrequency();
			guarantyFrequency.setSTypeNo(rsTemp2.getString("ItemAttribute"));
			guarantyFrequency.setSOrgID(rsTemp2.getString("RelativeCode"));
			guarantyFrequency.setSGuarantyFrequency(rsTemp2.getString("ItemNo"));
			frequencyList.add(guarantyFrequency);
		}
		rsTemp2.close();
		psloadSql2.close();
		
		
	}
	
	//���鵱�ո�ѺƷ�Ƿ�����ع�
	public boolean isTodayChange(String sTypeNo,String sOrgID,String sPutOutDate) throws Exception
	{
		
		OrgInfo orgInfo = OrgInfoConfig.getOrgInfo(sOrgID);
		String fOrgID = orgInfo.getRelativeOrgID();
		String sGuarantyFrequency = "";
		
		for(int i=0;i<frequencyList.size();i++)
		{
			GuarantyFrequency guarantyFrequency = frequencyList.get(i);
			if(guarantyFrequency.getSTypeNo().indexOf(sTypeNo)>=0 && guarantyFrequency.getSOrgID().indexOf(fOrgID)>=0)
			{
				sGuarantyFrequency = guarantyFrequency.getSGuarantyFrequency();
			}
		}
		if(sGuarantyFrequency==null||sGuarantyFrequency.length()==0)
		{
			return false;
		}
		//ѺƷ�ع�Ƶ��Ϊ����
		if(sGuarantyFrequency.equals(BatchConstant.GUARANTY_FREQUENCY_MONTH))
		{
			String sDate = DateTools.getRelativeDate(sPutOutDate,AccountConstants.TERM_UNIT_MONTH,1);
			if(nextDate.substring(8,10).equals("01")&& DateTools.getDays(sDate,nextDate)>0)
				return true;
			else
				return false;
		}
		//ѺƷ�ع�Ƶ��Ϊ����
		else if(sGuarantyFrequency.equals(BatchConstant.GUARANTY_FREQUENCY_SEASON))
		{
			String sDate = DateTools.getRelativeDate(sPutOutDate,AccountConstants.TERM_UNIT_MONTH,3);
			
			if(nextDate.substring(4,10).equals("/04/01")&& DateTools.getDays(sDate,nextDate)>0 )
				return true;
			else if(nextDate.substring(4,10).equals("/07/01")&& DateTools.getDays(sDate,nextDate)>0)
				return true; 
			else if(nextDate.substring(4,10).equals("/10/01")&& DateTools.getDays(sDate,nextDate)>0)
				return true; 
			else if(nextDate.substring(4,10).equals("/01/01")&& DateTools.getDays(sDate,nextDate)>0)
				return true;
			else
				return false;
				
		}
		//ѺƷ�ع�Ƶ��Ϊ��Ѯ
		else
		{
			return false;
		}
	}
	
	//���ݸ�ѺƷ�����ţ����ظõ����ĵ���ָ��
	public double returnEvalnetValue(String sGuarantyArea)
	{
		double evalnetValue = 0.0;
		AreaExponent areaExponent = AreaExponentHashMap.get(sGuarantyArea);
		if(areaExponent!=null)
			evalnetValue = areaExponent.getExponent();
		return evalnetValue;
	}
	
	//���ر���������ֵ    ���룺�ϴ�����ֵ������ָ��������ָ��
	public double returnNewEvalnetValue(double lastEvalnetValue,double NewExponent,double OldExponent)
	{
		return NumberTools.round(lastEvalnetValue*(NewExponent/OldExponent),2);
	}
	
	public String createSerialNo() throws Exception
	{
		serialCount++;
		String sDate = DateTools.getStringDate(nextDate);
		String sSortNo = NumberTools.lPad(serialCount,8,'0');
		return "B"+sDate+sSortNo;
	}
	
	/*
	 * �����¼
	 * */
	public void errorRecord(String sNo,String sType,String sDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sNo);
		batchErrorRecord.setObjectType(sType);
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sDescribe);
		batchErrorRecord.errorRecord(connection);
	}
}
