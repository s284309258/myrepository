package com.amarsoft.app.datax.gci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import com.amarsoft.account.util.DateTools;

public class BatchErrorRecord {
	
	private String SerialNo;
	private String ObjectNo ="";
	private String ObjectType = "";
	private String TargetName= "";
	private String TargetDescribe= "";
	private String TaskName= "";
	private String TaskDescribe= "";
	private String errorDescribe= "";
	private String InputDate= "";
	private static String lastDate = "";
	private static String lastNo = "";
	
	public String getSerialNo() {
		return SerialNo;
	}


	private static synchronized String getSerialNo(Connection connection,String sDate) throws ParseException, SQLException {
		
		String no = "";
		if(!lastDate.equals(sDate))
		{
			String sSql = " select max(SerialNo)+1 as SerialNo from BatchError_Record where InputDate = '"+sDate+"'";
			PreparedStatement psSql = connection.prepareStatement(sSql);
			ResultSet rs = psSql.executeQuery();
			if(rs.next())
			{
				no = rs.getString("SerialNo");
				if(no==null)
					no = DateTools.getStringDate(sDate)+"0000001";
			}
			rs.close();
			psSql.close();
			lastDate = sDate;
		}
		else
		{
			no = String.valueOf(Long.parseLong(lastNo)+1);
		}
		
		lastNo = no;
		return no;
	}


	public String getObjectNo() {
		return ObjectNo;
	}


	public void setObjectNo(String objectNo) {
		ObjectNo = objectNo;
	}


	public String getObjectType() {
		return ObjectType;
	}


	public void setObjectType(String objectType) {
		ObjectType = objectType;
	}


	public String getTargetName() {
		return TargetName;
	}


	public void setTargetName(String targetName) {
		TargetName = targetName;
	}


	public String getTargetDescribe() {
		return TargetDescribe;
	}


	public void setTargetDescribe(String targetDescribe) {
		TargetDescribe = targetDescribe;
	}


	public String getTaskName() {
		return TaskName;
	}


	public void setTaskName(String taskName) {
		TaskName = taskName;
	}


	public String getTaskDescribe() {
		return TaskDescribe;
	}


	public void setTaskDescribe(String taskDescribe) {
		TaskDescribe = taskDescribe;
	}


	public String getErrorDescribe() {
		return errorDescribe;
	}


	public void setErrorDescribe(String errorDescribe) {
		this.errorDescribe = errorDescribe;
	}


	public String getInputDate() {
		return InputDate;
	}


	public void setInputDate(String inputDate) {
		InputDate = inputDate;
	}

	public boolean errorRecord(Connection connection) throws SQLException, ParseException
	{
		try
		{
			SerialNo = getSerialNo(connection,InputDate);
			
			String sInsertSql = " insert into BatchError_Record(SerialNo,ObjectType,ObjectNo,TargetName,TargetDescribe,TaskName,TaskDescribe,errorDescribe,InputDate)"
							 + " values('"+SerialNo+"','"+ObjectType+"','"+ObjectNo+"','"+TargetName+"','"+TargetDescribe+"',"
							 + " '"+TaskName+"','"+TaskDescribe+"','"+errorDescribe.replaceAll("'", "''")+"','"+InputDate+"') ";
			Statement stm = connection.createStatement();
			boolean b = stm.execute(sInsertSql);
			connection.commit();
			stm.close();
			return b;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
}
