package com.amarsoft.app.datax.gci.gjj;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

/**
 * ����Down�ļ����ݺ�loan_balance����BtoX����
 * @author XIATIAN020
 * @since 2012-06-06
 */

public class CreateUpdateReturnData extends CommonExecuteUnit{
	
		private int commitNum ;
		private int dealNum = 0;
		private int icount = 0;
		
		public int execute() {
				
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{	
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					logger.info("����Update��Return���ݿ�ʼ......");
					initData();
					logger.info("����Update��Return���ݽ���......");
					logger.info("����Update��Return���ݿ�ʼ......");
					createData();
					logger.info("����Update��Return������ɣ�");
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}
		
		public void initData() throws Exception {
			String deleteSqlUpdate = " delete from GJJ_UPDATE where InputDate = ? ";
			String deleteSqlReturn = " delete from GJJ_RETURN where InputDate = ? ";
			String deleteSqlCTOBTMP = " delete from GJJ_CTOB_TMP where InputDate = ? ";
			PreparedStatement psDeleteSqlUpdate = null,psDeleteSqlReturn = null,psDeleteSqlCTOBTMP = null;
			try
			{
				psDeleteSqlUpdate = connection.prepareStatement(deleteSqlUpdate);
				psDeleteSqlUpdate.setString(1, this.deductDate);
				psDeleteSqlUpdate.execute();
				psDeleteSqlReturn = connection.prepareStatement(deleteSqlReturn);
				psDeleteSqlReturn.setString(1, this.deductDate);
				psDeleteSqlReturn.execute();
				psDeleteSqlCTOBTMP = connection.prepareStatement(deleteSqlCTOBTMP);
				psDeleteSqlCTOBTMP.setString(1, this.deductDate);
				psDeleteSqlCTOBTMP.execute();
			}catch(Exception ex)
			{
				ex.printStackTrace();
				throw ex;
			}
			finally
			{
				if(psDeleteSqlUpdate!=null) psDeleteSqlUpdate.close();
				if(psDeleteSqlReturn!=null) psDeleteSqlReturn.close();
			}
		}

		public void createData() throws Exception {

			String insertSqlReturn = " insert into GJJ_RETURN(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT," +
									" PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)" +
									" values (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			String insertSqlUpdate = " insert into GJJ_UPDATE(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT," +
									" PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)" +
									" values (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			
			String insertSqlCTOB_TMP = "insert into GJJ_CTOB_TMP(BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE)" +
									" (select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE from GJJ_CTOB where InputDate = ? " +
									" and not exists(select 'X' from GJJ_UPDATE where LoanNo = GJJ_CTOB.LoanNo and inputDate = GJJ_CTOB.InputDate)" +
									" union all" +
									"  select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE from GJJ_ZTOB where InputDate = ? " +
									" and not exists(select 'X' from GJJ_RETURN where LoanNo = GJJ_ZTOB.LoanNo and inputDate = GJJ_ZTOB.InputDate)) ";
			
			String insertSqlUpdate_Tmp1 = "insert into GJJ_UPDATE(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)"+
								" (select GC.BANKCODE,GC.GJJNO,GC.IDCARD,LB.NormalBalance+LB.OverdueBalance,0.0,0.0,0.0,0.0,GC.INPUTDATE,GC.LOANNO,GC.DEDUCTTYPE,GC.LOANTYPE,'01',LB.OrgID " +
								" from GJJ_CTOB GC,LOAN_BALANCE LB where InputDate = ? and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'1') " +
								" and not exists(select 'X' from GJJ_UPDATE where LoanNo = GC.LoanNo and inputDate = GC.InputDate))";
			String insertSqlUpdate_Tmp2 = "insert into GJJ_UPDATE(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)"+
								" (select GC.BANKCODE,GC.GJJNO,GC.IDCARD,LB.NormalBalance+LB.OverdueBalance,0.0,0.0,0.0,0.0,GC.INPUTDATE,GC.LOANNO,GC.DEDUCTTYPE,GC.LOANTYPE,'01',LB.OrgID " +
								" from GJJ_CTOB GC,LOAN_BALANCE LB where InputDate = ? and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'2') " +
								" and not exists(select 'X' from GJJ_UPDATE where LoanNo = GC.LoanNo and inputDate = GC.InputDate))";
			
			String insertSqlReturn_Tmp1 = "insert into GJJ_RETURN(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)"+
								" (select GC.BANKCODE,GC.GJJNO,GC.IDCARD,LB.NormalBalance+LB.OverdueBalance,0.0,0.0,0.0,0.0,GC.INPUTDATE,GC.LOANNO,GC.DEDUCTTYPE,GC.LOANTYPE,'01',LB.OrgID " +
								" from GJJ_ZTOB GC,LOAN_BALANCE LB where InputDate = ? and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'1') " +
								" and not exists(select 'X' from GJJ_RETURN where LoanNo = GC.LoanNo and inputDate = GC.InputDate))";
			String insertSqlReturn_Tmp2 = "insert into GJJ_RETURN(BANKCODE,GJJNO,IDCARD,LOANBALANCE,PAYAMT,PAYCORPUS,PAYINTE,PAYFINEINTE,INPUTDATE,LOANNO,DEDUCTTYPE,LOANTYPE,ADJUSTFLAG,ORGID)"+
								" (select GC.BANKCODE,GC.GJJNO,GC.IDCARD,LB.NormalBalance+LB.OverdueBalance,0.0,0.0,0.0,0.0,GC.INPUTDATE,GC.LOANNO,GC.DEDUCTTYPE,GC.LOANTYPE,'01',LB.OrgID " +
								" from GJJ_ZTOB GC,LOAN_BALANCE LB where InputDate = ? and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'2') " +
								" and not exists(select 'X' from GJJ_RETURN where LoanNo = GC.LoanNo and inputDate = GC.InputDate))";
			
			String selectSqlCTOB = "select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE,USEAMT from GJJ_CTOB " +
									" where InputDate = ? and getGjjLoanNo(LoanNo,'1') = ? " +
									" union " +
									" select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE,USEAMT from GJJ_CTOB " +
									" where InputDate = ? and getGjjLoanNo(LoanNo,'2') = ? ";
			
			String selectSqlZTOB = "select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE,USEAMT from GJJ_ZTOB " +
									" where InputDate = ? and getGjjLoanNo(LoanNo,'1') = ? " +
									" union " +
									" select BANKCODE,LOANNO,GJJNO,IDCARD,PAYAMT,DEDUCTTYPE,INPUTDATE,LOANTYPE,USEAMT from GJJ_ZTOB " +
									" where InputDate = ? and getGjjLoanNo(LoanNo,'2') = ? ";
			
			String selectSqlBackBill = " select LB.PutOutNo,getLoanNo(LB.PutOutNo) as LoanNo,LB.OrgID,(LB.NormalBalance+LB.OverdueBalance) as LoanBalance," +
									" sum(BB.Actualcurrentcorp+BB.Actualdefaultcorp+BB.Actualoverduecorp) as Corp," +
									" sum(BB.Actualinte+BB.Actualinnerinte+BB.Actualoutinte-BB.actualintefine) as Inte," +
									" sum(BB.Actualinnerintefine+BB.ACTUALOUTINTEFINE+BB.actualintefine) as FineInte," +
									" BB.AccDate " +
									" from LOAN_BALANCE LB,BACK_BILL BB " +
									" where LB.PutOutNo = BB.PutOutNo and BB.AccDate = ? and BB.ReturnChannel in('30','40') " +
									" group by LB.PutOutNo,LB.OrgID,(LB.NormalBalance+LB.OverdueBalance),BB.accDate ";
			
			
			
			PreparedStatement psInsertSqlReturn = null,psInsertSqlUpdate = null,psInsertSqlCTOB_TMP = null,psSelectSqlCTOB = null,psSelectSqlZTOB = null,psSelectSqlBackBill = null,
			psInsertSqlUpdate_Tmp1 = null,psInsertSqlUpdate_Tmp2 = null,psInsertSqlReturn_Tmp1 = null,psInsertSqlReturn_Tmp2 = null;
			
			
			try
			{
				psInsertSqlReturn = connection.prepareStatement(insertSqlReturn);
				psInsertSqlUpdate = connection.prepareStatement(insertSqlUpdate);
				psInsertSqlCTOB_TMP = connection.prepareStatement(insertSqlCTOB_TMP); 
				psSelectSqlCTOB = connection.prepareStatement(selectSqlCTOB); 
				psSelectSqlZTOB = connection.prepareStatement(selectSqlZTOB); 
				psSelectSqlBackBill = connection.prepareStatement(selectSqlBackBill);
				psInsertSqlUpdate_Tmp1 = connection.prepareStatement(insertSqlUpdate_Tmp1);
				psInsertSqlUpdate_Tmp2 = connection.prepareStatement(insertSqlUpdate_Tmp2);
				psInsertSqlReturn_Tmp1 = connection.prepareStatement(insertSqlReturn_Tmp1);
				psInsertSqlReturn_Tmp2 = connection.prepareStatement(insertSqlReturn_Tmp2);
				
				psSelectSqlBackBill.setString(1, this.deductDate);
				ResultSet rs = psSelectSqlBackBill.executeQuery();
				while(rs.next())
				{
					String putOutNo = rs.getString("PutOutNo");
					String putoutLoanNo = rs.getString("LoanNo");
					double loanBalance = rs.getDouble("LoanBalance");
					double corp = rs.getDouble("Corp");
					double inte = rs.getDouble("Inte");
					double fineInte = rs.getDouble("FineInte");
					String accDate = rs.getString("AccDate");
					double allAmt = corp + inte + fineInte;
					String orgID = rs.getString("OrgID");
					psSelectSqlZTOB.setString(1, this.deductDate);
					psSelectSqlZTOB.setString(2, putoutLoanNo);
					psSelectSqlZTOB.setString(3, this.deductDate);
					psSelectSqlZTOB.setString(4, putoutLoanNo);
					ResultSet rsZTOB = psSelectSqlZTOB.executeQuery();
					if(rsZTOB.next())
					{
						String bankCode = rsZTOB.getString("BANKCODE");
						String gjjNo = rsZTOB.getString("GJJNO");
						String idcard = rsZTOB.getString("IDCARD");
						String loanNo = rsZTOB.getString("LOANNO");
						String deductType = rsZTOB.getString("DEDUCTTYPE");
						String loanType = rsZTOB.getString("LOANTYPE");
						double amt = rsZTOB.getDouble("PAYAMT");
						double useamt = rsZTOB.getDouble("USEAMT");
						double ztobCorp = 0.0;
						double ztobInte = 0.0;
						double ztobFineInte = 0.0;
						//�Է�Ǯ���ɹ��Ĳ����д���
						if(Math.abs(useamt-amt) <= 0.00000001)
						{
							ztobCorp = 0.0;
							ztobInte = 0.0;
							ztobFineInte = 0.0;
						}
						else if(amt > allAmt)
						{
							amt = allAmt;
							allAmt = 0;
							ztobCorp = corp;
							corp = 0;
							ztobInte = inte;
							inte = 0;
							ztobFineInte = fineInte;
							fineInte = 0;
						}
						else
						{
							double amtTmp = amt;
							ztobFineInte = Math.min(amtTmp, fineInte);
							amtTmp = Math.max(amtTmp-fineInte, 0);
							fineInte -= ztobFineInte;
							
							ztobInte = Math.min(amtTmp, inte);
							amtTmp = Math.max(amtTmp-inte, 0);
							inte -= ztobInte;
							
							ztobCorp = Math.min(amtTmp, corp);
							amtTmp = Math.max(amtTmp-corp,0);
							corp -= ztobCorp;
						}
						String flag = rsZTOB.getDouble("PAYAMT") <= NumberTools.round(ztobCorp+ztobInte+ztobFineInte,2) ? " " : "01";
						psInsertSqlReturn.setString(1, bankCode);
						psInsertSqlReturn.setString(2, gjjNo);
						psInsertSqlReturn.setString(3, idcard);
						psInsertSqlReturn.setDouble(4, loanBalance);
						psInsertSqlReturn.setDouble(5, NumberTools.round(ztobCorp+ztobInte+ztobFineInte,2));
						psInsertSqlReturn.setDouble(6, ztobCorp);
						psInsertSqlReturn.setDouble(7, ztobInte);
						psInsertSqlReturn.setDouble(8, ztobFineInte);
						psInsertSqlReturn.setString(9, this.deductDate);
						psInsertSqlReturn.setString(10, loanNo);
						psInsertSqlReturn.setString(11, deductType);
						psInsertSqlReturn.setString(12, loanType);
						psInsertSqlReturn.setString(13, flag);
						psInsertSqlReturn.setString(14, orgID);
						psInsertSqlReturn.addBatch();
					}
					rsZTOB.close();
					
					psSelectSqlCTOB.setString(1, this.deductDate);
					psSelectSqlCTOB.setString(2, putoutLoanNo);
					psSelectSqlCTOB.setString(3, this.deductDate);
					psSelectSqlCTOB.setString(4, putoutLoanNo);
					ResultSet rsCTOB = psSelectSqlCTOB.executeQuery();
					if(rsCTOB.next())
					{
						String bankCode = rsCTOB.getString("BANKCODE");
						String gjjNo = rsCTOB.getString("GJJNO");
						String idcard = rsCTOB.getString("IDCARD");
						String loanNo = rsCTOB.getString("LOANNO");
						String deductType = rsCTOB.getString("DEDUCTTYPE");
						String loanType = rsCTOB.getString("LOANTYPE");
						double amt = rsCTOB.getDouble("PAYAMT");
						double ctobCorp = 0.0;
						double ctobInte = 0.0;
						double ctobFineInte = 0.0;
						if(amt > allAmt)
						{
							amt = allAmt;
							allAmt = 0;
							ctobCorp = corp;
							corp = 0;
							ctobInte = inte;
							inte = 0;
							ctobFineInte = fineInte;
							fineInte = 0;
						}
						else
						{
							double amtTmp = amt;
							ctobFineInte = Math.min(amtTmp, fineInte);
							amtTmp = Math.max(amtTmp-fineInte, 0);
							fineInte -= ctobFineInte;
							
							ctobInte = Math.min(amtTmp, inte);
							amtTmp = Math.max(amtTmp-inte, 0);
							inte -= ctobInte;
							
							ctobCorp = Math.min(amtTmp, corp);
							amtTmp = Math.max(amtTmp-corp,0);
							corp -= ctobCorp;
						}
						
						String flag = rsCTOB.getDouble("PAYAMT") <= NumberTools.round(ctobCorp+ctobInte+ctobFineInte, 2) ? " " : "01";
						psInsertSqlUpdate.setString(1, bankCode);
						psInsertSqlUpdate.setString(2, gjjNo);
						psInsertSqlUpdate.setString(3, idcard);
						psInsertSqlUpdate.setDouble(4, loanBalance);
						psInsertSqlUpdate.setDouble(5, NumberTools.round(ctobCorp+ctobInte+ctobFineInte, 2));
						psInsertSqlUpdate.setDouble(6, ctobCorp);
						psInsertSqlUpdate.setDouble(7, ctobInte);
						psInsertSqlUpdate.setDouble(8, ctobFineInte);
						psInsertSqlUpdate.setString(9, this.deductDate);
						psInsertSqlUpdate.setString(10, loanNo);
						psInsertSqlUpdate.setString(11, deductType);
						psInsertSqlUpdate.setString(12, loanType);
						psInsertSqlUpdate.setString(13, flag);
						psInsertSqlUpdate.setString(14, orgID);
						psInsertSqlUpdate.addBatch();
					}
					rsCTOB.close();
					
					
					dealNum++;
					icount++;
				    if(dealNum>=commitNum){
				    	psInsertSqlReturn.executeBatch();
				    	psInsertSqlUpdate.executeBatch();
				    	dealNum=0;
						logger.info("�ѳ�ʼ��BtoC����"+icount+"����");
			        }
				}
				
				psInsertSqlReturn.executeBatch();
		    	psInsertSqlUpdate.executeBatch();
		    	psInsertSqlUpdate_Tmp1.setString(1, this.deductDate);
		    	psInsertSqlUpdate_Tmp1.execute();
		    	psInsertSqlUpdate_Tmp2.setString(1, this.deductDate);
		    	psInsertSqlUpdate_Tmp2.execute();
		    	psInsertSqlReturn_Tmp1.setString(1, this.deductDate);
		    	psInsertSqlReturn_Tmp1.execute();
		    	psInsertSqlReturn_Tmp2.setString(1, this.deductDate);
		    	psInsertSqlReturn_Tmp2.execute();
		    	psInsertSqlCTOB_TMP.setString(1, this.deductDate);
		    	psInsertSqlCTOB_TMP.setString(2, this.deductDate);
		    	psInsertSqlCTOB_TMP.execute();
			}catch(Exception ex)
			{
				ex.printStackTrace();
				throw ex;
			}
			finally
			{
				if(psInsertSqlReturn!=null) psInsertSqlReturn.close();
				if(psInsertSqlUpdate!=null) psInsertSqlUpdate.close();
				if(psInsertSqlCTOB_TMP!=null) psInsertSqlCTOB_TMP.close();
				if(psSelectSqlCTOB!=null) psSelectSqlCTOB.close();
				if(psSelectSqlZTOB!=null) psSelectSqlZTOB.close();
				if(psSelectSqlBackBill!=null) psSelectSqlBackBill.close();
				if(psInsertSqlUpdate_Tmp1!=null) psInsertSqlUpdate_Tmp1.close();
				if(psInsertSqlUpdate_Tmp2!=null) psInsertSqlUpdate_Tmp2.close();
				if(psInsertSqlReturn_Tmp1!=null) psInsertSqlReturn_Tmp1.close();
				if(psInsertSqlReturn_Tmp2!=null) psInsertSqlReturn_Tmp2.close();
			}
		}
}
