package com.amarsoft.app.datax.gci;

public class VipRate {

	private String SerialNo;
	private String OrgID;
	private String BusinessType;
	private double LimAmt;
	private double SavingLowerLim;
	private double SavingUpperLim;
	private String UseDate;
	private String VipComFlag;
	private double FavRateFloat;
	private double RateFloat;
	private String VIPRateType;
	
	public String getVIPRateType() {
		return VIPRateType;
	}
	public void setVIPRateType(String rateType) {
		VIPRateType = rateType;
	}
	public String getVipComFlag() {
		return VipComFlag;
	}
	public void setVipComFlag(String vipComFlag) {
		VipComFlag = vipComFlag;
	}
	public double getFavRateFloat() {
		return FavRateFloat;
	}
	public void setFavRateFloat(double favRateFloat) {
		FavRateFloat = favRateFloat;
	}
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public String getOrgID() {
		return OrgID;
	}
	public void setOrgID(String orgID) {
		OrgID = orgID;
	}
	public String getBusinessType() {
		return BusinessType;
	}
	public void setBusinessType(String businessType) {
		BusinessType = businessType;
	}
	public double getLimAmt() {
		return LimAmt;
	}
	public void setLimAmt(double limAmt) {
		LimAmt = limAmt;
	}
	public double getSavingLowerLim() {
		return SavingLowerLim;
	}
	public void setSavingLowerLim(double savingLowerLim) {
		SavingLowerLim = savingLowerLim;
	}
	public double getSavingUpperLim() {
		return SavingUpperLim;
	}
	public void setSavingUpperLim(double savingUpperLim) {
		SavingUpperLim = savingUpperLim;
	}
	public String getUseDate() {
		return UseDate;
	}
	public void setUseDate(String useDate) {
		UseDate = useDate;
	}
	public double getRateFloat() {
		return RateFloat;
	}
	public void setRateFloat(double rateFloat) {
		RateFloat = rateFloat;
	}
	
}
