package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class CreateFixedSaving extends CommonExecuteUnit{
	
	int icount = 0;
	private int commitNum = 0;
	int dealNum = 0;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				if(deductDate.endsWith("02"))
				{
					commitNum=Integer.parseInt(getProperty("commitNum", "1"));
					String delSql=" call dbmgr.truncate_table ('RCPMDATA','FIXEDSAVING_RECORD') ";
					logger.info("��ʼ���fixedsaving_record������....");
					PreparedStatement psDeleteData = connection.prepareStatement(delSql);
					psDeleteData.execute();
					logger.info("���fixedsaving_record���������! ");
					psDeleteData.close();
				
					logger.info("��ʼ����fixedsaving_record���ڴ������....");
					batchCreateFixedSaving();
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void batchCreateFixedSaving() throws SQLException, ParseException
	{
		String sDate = deductDate.substring(0,4)+deductDate.substring(5,7)+"01";
		String sDate1 = deductDate.substring(0,4)+"/"+deductDate.substring(5,7)+"/01";
		
		String insertSql = " insert into fixedsaving_record(DeductAccNo,EcifCustomerID,Currency,InputDate,Balance) " +
				" values(?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select m.macct as DeductAccNo,sum(getERateAmount(m.mbal,m.mccy,'RMB') ) as Balance,e.ecifno as EcifCustomerID  " +
				" from tbufmavgs m,tBCFMCAMP c,TBCFMECIF e  " +
				" where m.macct = c.caccta and m.mdate = '"+sDate+"' and m.mseq = c.cacsna and e.custno = c.ccusnf and m.mccy = c.ciccya " +
				" group by m.macct,e.ecifno " ;
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("DeductAccNo"));
			psInsertSql.setString(2,rs.getString("EcifCustomerID"));
			psInsertSql.setString(3,"RMB");
			psInsertSql.setString(4,sDate1);
			psInsertSql.setDouble(5,rs.getDouble("Balance"));
			psInsertSql.addBatch();
			icount++;
			dealNum++;
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѳ���"+icount+"������!");
			}
		}
		psInsertSql.executeBatch();
		logger.info("һ������"+icount+"������!");
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
	}

}
