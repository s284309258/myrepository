package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchClassify extends CommonExecuteUnit{
	
	private String delSql;
	private String selectSql;
	private String insertSql;
	private String updateClassifyRSql;
	private String updateLoanBalanceSql;
	private PreparedStatement psUpdateLoanBalanceSql;
	private PreparedStatement psInsertSql;
	private PreparedStatement psUpdateClassifyRSql;
	private PreparedStatement psSelectSql;
	private String aa[][];
	private int dealNum = 0;
	private int commitNum;
	private int iSerialCount = 0;


	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initAa();
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				//���յ����ں� Ϊint��
				int CurrDay = Integer.parseInt(deductDate.substring(8,10));
				//������ĩ�����ں� int��
				int EndMonthDay = Integer.parseInt(DateTools.getEndDateOfMonth(deductDate).substring(8,10));
				
				//����������� Ϊ����25��
				if(CurrDay == 25)
				{
					delSql=" delete from classify_record where ClassifyDate = '"+deductDate+"' and BusinessKind = 'RCPM'";
					logger.info("���classify_record :sql="+delSql);
					PreparedStatement psDelSql = connection.prepareStatement(delSql);
					psDelSql.execute(delSql);
					logger.info("���classify_record�������! ");
					
					logger.info("ÿ��25�ս��е�һ��ʮ�������࣡");
					insertAllClassify();
					batchClassify25();
					logger.info("ʮ��������ִ����ɣ�");
				}
				//����������25~��ĩ֮��
				else if(CurrDay>25 && CurrDay<= EndMonthDay)
				{
					delSql=" delete from classify_record where ClassifyDate = '"+deductDate+"' and BusinessKind = 'RCPM'";
					logger.info("���classify_record :sql="+delSql);
					PreparedStatement psDelSql = connection.prepareStatement(delSql);
					psDelSql.execute(delSql);
					logger.info("���classify_record�������! ");
					
					logger.info("��"+deductDate+"�����������12������......");
					batchClassifyAfter25();
					logger.info("ʮ��������ִ����ɣ�");
				}
				else
				{
					logger.info("���첻�����ʮ�������࣡");
				}
				//�������Ϊÿ����ĩ
				if(CurrDay==EndMonthDay)
				{	
					logger.info("ÿ����ĩ���еڶ���ʮ��������......");
					batchClassifyMonthEndNew();
					updateContractClassify();
					logger.info("ʮ��������ִ����ɣ�");
					
					
				}
				else
				{
					logger.info("���ղ����������ʮ�������࣡");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			
			clearResource();
			return unitStatus;
		} 
	}

	//��classify_record�в������д���ĳ�ʼ�����ݡ�
	public void insertAllClassify() throws Exception
	{
		int icount = 0;
		
		String insertSql =" insert into classify_record(ObjectType,ObjectNo,SerialNo,FirstResult,ClassifyDate,AccountMonth,LastResult,OverDays,BusinessKind) "
			      +" values(?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql =" select PutOutNo,ClassifyResult,businesstype,BusinessKind "
	      +" from loan_balance "
	      +" where loanstatus in ('0','1','4','5') and BusinessKind = 'RCPM'";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String newSerialNo = createSerialNo();
			String sClassify = dealClassify(rs.getString("businesstype"),0);
			
			psInsertSql.setString(1,"LoanBalance");
			psInsertSql.setString(2,rs.getString("PutOutNo"));
			psInsertSql.setString(3,newSerialNo);
			psInsertSql.setString(4,sClassify);
			psInsertSql.setString(5,deductDate);
			psInsertSql.setString(6,currentMonth);
			psInsertSql.setString(7,rs.getString("ClassifyResult"));
			psInsertSql.setInt(8,0);
			psInsertSql.setString(9, rs.getString("BusinessKind"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"����¼��");
			}
		}
		psInsertSql.executeBatch();
		connection.commit();
		rs.close();
		psInsertSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"����¼��");
		logger.info("�����˹�����Ľ����ʼ...");
		String sql1=" update classify_record cr1 set (cr1.manualresult,cr1.flag,cr1.classifydate,cr1.updatedate,cr1.classifyorgid,cr1.classifyuserid)"+
					" =(select cr.manualresult,cr.flag,cr.classifydate,cr.updatedate,cr.classifyorgid,cr.classifyuserid "+
					" from classify_record cr " +
				    " where cr.objectno=cr1.objectno and cr.objecttype=cr1.objecttype and cr.objecttype='LoanBalance' and cr.BusinessKind='RCPM' and cr.accountmonth='"+this.lastMonth+"')"+
				    " where exists(select 1 from classify_record cr2 where cr1.objectno=cr2.objectno and cr1.objecttype=cr2.objecttype "+
				    " and cr2.objecttype='LoanBalance' and cr2.manualresult is not null and cr2.accountmonth='"+this.lastMonth+"') "+
				    " and cr1.accountmonth='"+this.currentMonth+"'";
		logger.info("���±��µ�12��������,�����˹����:sql:" + sql1);
		logger.info("�����˹�����Ľ������...");
		Statement stmt=connection.createStatement();
		stmt.execute(sql1);
		stmt.close();
	
		dealNum = 0;
	}
	
	
	//25�� update�������ڴ����ʮ��������
	public void batchClassify25() throws Exception
	{
		int icount = 0;
		updateClassifyRSql =" update classify_record set FirstResult=?,OverDays=? where  SerialNo = ? ";
		psUpdateClassifyRSql = connection.prepareStatement(updateClassifyRSql);
		
		selectSql ="  select lb.PutOutNo,cr.SerialNo,lb.businesstype,lb.ClassifyResult,nvl(lr.OverDays, 0) as OverDays,cr.FinallyResult "
	      +" from loan_balance lb,LoanBalance_relative lr,classify_record cr,Business_Contract bc "
	      +" where lb.putoutno = lr.putoutno and cr.ObjectNo = lb.putoutno and lb.contractserialno = bc.serialno and lb.loanstatus in('0','1','4','5') "
	      +" and cr.ObjectType = 'LoanBalance' and cr.AccountMonth = '"+currentMonth+"' and lb.BusinessKind = 'RCPM' ";
		psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//����ʮ�������༶��
			String sClassify = dealClassify(rs.getString("businesstype"),rs.getInt("OverDays"));
			if(sClassify == null || sClassify.equals("")){
				System.out.println("null111111111111111");
			}
			psUpdateClassifyRSql.setString(1,sClassify);
			psUpdateClassifyRSql.setInt(2,rs.getInt("OverDays"));
			psUpdateClassifyRSql.setString(3,rs.getString("SerialNo"));
			psUpdateClassifyRSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateClassifyRSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"�����ݣ�");
			}
		}
		psUpdateClassifyRSql.executeBatch();
		rs.getStatement().close();
		psUpdateClassifyRSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
		
		dealNum = 0;
	}
	
	//��25����ĩ�ڼ�ÿ��������������ʮ��������
	public void batchClassifyAfter25() throws Exception
	{
		//��ʼ��ʮ�����������ñ�
		int icount = 0;
		
		insertSql =" insert into classify_record(ObjectType,ObjectNo,SerialNo,FirstResult,ClassifyDate,AccountMonth,LastResult,OverDays,BusinessKind) "
			   +" values(?,?,?,?,?,?,?,?,?) ";
		psInsertSql = connection.prepareStatement(insertSql);
	
		selectSql = "select PutOutNo,BusinessType,BusinessKind from loan_balance where PutOutDate = '"+deductDate+"' and BusinessKind = 'RCPM' ";
		psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			
			String newSerialNo = createSerialNo();
			//����ʮ�������༶��
			String sClassify = dealClassify(rs.getString("BusinessType"),0);
			
			psInsertSql.setString(1,"LoanBalance");
			psInsertSql.setString(2,rs.getString("PutOutNo"));
			psInsertSql.setString(3,newSerialNo);
			psInsertSql.setString(4,sClassify);
			psInsertSql.setString(5,deductDate);
			psInsertSql.setString(6,currentMonth);
			psInsertSql.setString(7,"");
			psInsertSql.setInt(8,0);
			psInsertSql.setString(9, rs.getString("BusinessKind"));
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ�������"+icount+"����");
			}
			
		}
		psInsertSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		logger.info("�Ѹ�������"+icount+"����");
		
		dealNum = 0;
	}
	
	
	//��������,��ĩ�����˹��޸ĺ�Ľ���������յķ�����
	public void batchClassifyMonthEndNew() throws Exception{
		int icount =0 ;
		
		updateClassifyRSql =" update classify_record set SecondResult=?,FinallyResult=?,FinishDate=?,OverDays=? "
            			   +" where  SerialNo = ?";
		psUpdateClassifyRSql = connection.prepareStatement(updateClassifyRSql);
		
		updateLoanBalanceSql = " update loan_balance set ClassifyResult=? where PutOutNo = ? ";
		psUpdateLoanBalanceSql = connection.prepareStatement(updateLoanBalanceSql);
		
		selectSql =" select lb.PutOutNo,cr.SerialNo,lb.businesstype,nvl(lr.OverDays, 0) as OverDays,cr.FinallyResult,nvl(cr.ManualResult,0) as ManualResult"
	      		  +" from loan_balance lb,LoanBalance_relative lr,classify_record cr"
	              +" where lb.putoutno = lr.putoutno and cr.ObjectNo = lb.putoutno and lb.BusinessKind = 'RCPM' "
	              +" and cr.ObjectType = 'LoanBalance' and cr.AccountMonth = '"+currentMonth+"' ";
		psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sClassify = dealClassify(rs.getString("businesstype"),rs.getInt("OverDays"));
			if(sClassify==null || sClassify.equals("")){
				sClassify = "0";
			}
			psUpdateClassifyRSql.setString(1,sClassify);
			//�˹�������
			String manualResult = rs.getString("ManualResult");
			int iManualResult = Integer.parseInt(manualResult);
			int classify = Integer.parseInt(sClassify);
			if(iManualResult <= classify){
				manualResult = sClassify;
			}
			psUpdateClassifyRSql.setString(2,manualResult);
			psUpdateClassifyRSql.setString(3,deductDate);
			psUpdateClassifyRSql.setInt(4,rs.getInt("OverDays"));
			psUpdateClassifyRSql.setString(5,rs.getString("SerialNo"));
			psUpdateClassifyRSql.addBatch();
			
			psUpdateLoanBalanceSql.setString(1,manualResult);
			psUpdateLoanBalanceSql.setString(2,rs.getString("PutOutNo"));
			psUpdateLoanBalanceSql.addBatch();
			
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateLoanBalanceSql.executeBatch();
				psUpdateClassifyRSql.executeBatch();
				dealNum=0;
				logger.info("�Ѹ�������"+icount+"����");
			}
			
		}
		
		psUpdateLoanBalanceSql.executeBatch();
		psUpdateClassifyRSql.executeBatch();
		rs.getStatement().close();
		psUpdateLoanBalanceSql.close();
		psUpdateClassifyRSql.close();
		psSelectSql.close();
		logger.info("һ����������"+icount+"����");
		dealNum = 0;
		
	}
	
	public void initAa() throws Exception
	{
		int n = 0;
		String initSql1 = " select count(*) as icount from Classify_Config ";
		PreparedStatement psInitSql1 = connection.prepareStatement(initSql1);
		ResultSet rs1 = psInitSql1.executeQuery();
		if(rs1.next())
		{
			n = rs1.getInt("icount");
		}
		rs1.close();
		psInitSql1.close();
		if(n==0)
		{
			throw new Exception("Classify_Config û����Ϣ��");
		}
		
		int i=0;
		aa = new String[n][16];//Over720,add by ex-chenjinbing002,���������޸�����
		String initSql2 = " select NoOver,Over0,Over30,Over60,Over90,Over120,Over150,Over180,Over210,Over240,Over270,Over300,Over330,Over360,Over720,BusinessType " //Over720,add by ex-chenjinbing002,���������޸�����
			            + " from Classify_Config ";
		PreparedStatement psInitSql2 = connection.prepareStatement(initSql2);
		ResultSet rs2 = psInitSql2.executeQuery();
		while(rs2.next())
		{
			aa[i][0] = rs2.getString("Noover"); 
			aa[i][1] = rs2.getString("Over0");
			aa[i][2] = rs2.getString("Over30");
			aa[i][3] = rs2.getString("Over60");
			aa[i][4] = rs2.getString("Over90");
			aa[i][5] = rs2.getString("Over120");
			aa[i][6] = rs2.getString("Over150");
			aa[i][7] = rs2.getString("Over180");
			aa[i][8] = rs2.getString("Over210");
			aa[i][9] = rs2.getString("Over240");
			aa[i][10] = rs2.getString("Over270");
			aa[i][11] = rs2.getString("Over300");
			aa[i][12] = rs2.getString("Over330");
			aa[i][13] = rs2.getString("Over360");
			aa[i][14] = rs2.getString("Over720");//Over720,add by ex-chenjinbing002,���������޸�����
			aa[i][15] = rs2.getString("BusinessType");
			i++;
		}
		rs2.close();
		psInitSql2.close();
	}
	
	public String createSerialNo() throws Exception
	{
		iSerialCount++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iSerialCount,8,'0');
		String businessKind = "RCPM";
		return businessKind+sDate+sSortNo;
	}
	
	public String dealClassify(String businessType,double overDays) throws Exception
	{
		String sReturn = "";
		int x = 0;
		int i ;
		if(overDays>0)
			i = (int)java.lang.Math.ceil(overDays/30);
		else
			i = 0;

	    x=i;
	    if(x>14) x=14;
	    
		int y = 100;
		//Ѱ�Ҹ�ҵ��Ʒ��BusinessType ����Ӧ����yֵ
		for(int j=0;j<aa.length;j++)
		{
			String s = aa[j][15]; //Over720,modify by ex-chenjinbing002,���������޸�����
			String [] ss = s.split("@");
			for(int jj=0;jj<ss.length;jj++)
			{
				if(businessType.equals(ss[jj].trim()))
				{
					y=j;
				}
			}
		}
		if(y==100)
		{
			logger.error("����δ����12�������ҵ��Ʒ�֣�"+businessType);
			return "0";
			//throw new Exception("����δ����12�������ҵ��Ʒ�֣�"+businessType);
		}
		
		sReturn = aa[y][x];
	    return sReturn;
	}
	
	/*
	 * ���º�ͬ�е�ʮ��������
	 * */
	public void updateContractClassify() throws Exception
	{
		String updateSql1 = " update Loan_Balance set ClassifyResult=? where contractserialno=? ";
		PreparedStatement psUpdateSql1 = connection.prepareStatement(updateSql1);
		
		String updateSql2 = " update business_contract set ClassifyResult=? where serialno=? ";
		PreparedStatement psUpdateSql2 = connection.prepareStatement(updateSql2);
		
		String insertSql =" insert into classify_record(ObjectType,ObjectNo,SerialNo,FinallyResult,ClassifyDate,AccountMonth,LastResult,OverDays,BusinessKind) "
		      +" values(?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select bc.SerialNo,nvl(bc.ClassifyResult,0) as bcClassify,max(lb.ClassifyResult) as lbMaxClassify,max(lr.OverDays) as maxOverDays " +
				" from business_contract bc,loan_balance lb,loanbalance_relative lr " +
				" where bc.serialno = lb.contractserialno and lb.putoutNo = lr.PutOutNo and bc.balance >0 " +
				" and lb.loanstatus in('0','1','4','5') and lb.BusinessKind = 'RCPM' " +
				" group by bc.SerialNo,bc.ClassifyResult ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String newSerialNo = createSerialNo();
			
			psInsertSql.setString(1,"CBContractApply");
			psInsertSql.setString(2,rs.getString("SerialNo"));
			psInsertSql.setString(3,newSerialNo);
			psInsertSql.setString(4,String.valueOf(rs.getInt("lbMaxClassify")));
			psInsertSql.setString(5,deductDate);
			psInsertSql.setString(6,currentMonth);
			psInsertSql.setString(7,rs.getString("bcClassify"));
			psInsertSql.setInt(8,rs.getInt("maxOverDays"));
			psInsertSql.setString(9,"RCPM");
			psInsertSql.addBatch();
			
			psUpdateSql1.setInt(1,rs.getInt("lbMaxClassify"));
			psUpdateSql1.setString(2,rs.getString("SerialNo"));
			psUpdateSql1.addBatch();
			
			psUpdateSql2.setInt(1,rs.getInt("lbMaxClassify"));
			psUpdateSql2.setString(2,rs.getString("SerialNo"));
			psUpdateSql2.addBatch();
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql1.executeBatch();
				psUpdateSql2.executeBatch();
				psInsertSql.executeBatch();
				dealNum = 0;
			}
		}
		psUpdateSql1.executeBatch();
		psUpdateSql2.executeBatch();
		psInsertSql.executeBatch();
		psUpdateSql1.close();
		psUpdateSql2.close();
		psInsertSql.close();
		rs.close();
		psSelectSql.close();	
		
	}
	
}
