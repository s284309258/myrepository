package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.interfaces.instance.NetBankAccDC;
import com.amarsoft.task.TaskConstants;

public class DCAheadRepaying extends CommonExecuteUnit{

	private int icount = 0;
	@Override
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ����LOAN_CHANGE��......");
				insertData();
				logger.info("������LOAN_CHANGE��"+icount+"����");
				logger.info("�������ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void insertData() throws SQLException 
	{
		String sDate = StringFunction.replace(deductDate, "/", "");
		String BatchNo = "TQJQ" + sDate;
		try
		{
			NetBankAccDC netBankAcc = new NetBankAccDC();
			LoanBalance loanBalance = new LoanBalance(); 
			
			connection.setAutoCommit(false);
			String selectSql = " select PutOutNo from ahead_pl where batchstatus = '50' and replace(inputdate,'/','') = '"+sDate+"' and batchno = '"+BatchNo+"'";
			PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
			ResultSet rs = psSelectSql.executeQuery();
			while(rs.next())
			{
				String PutOutNo = rs.getString("PUTOUTNO");
				
				loanBalance.SetLoanBalance(PutOutNo,connection);
				loanBalance.SetFareAccount(PutOutNo,connection);
				if(loanBalance.getNormalBalance()>0.000000)
				{
					netBankAcc.netBankRun(PutOutNo,String.valueOf(loanBalance.getNormalBalance()),"0", "0","0",nextDate,connection);
					icount++;
				}
			}
			rs.close();
			psSelectSql.close();
			connection.commit();
		}catch(Exception e)
		{
			connection.rollback();
			e.printStackTrace();
			throw new SQLException("����LOAN_CHANGE��ʧ��");
		}
	}

}
