package com.amarsoft.app.datax.gci.datamove;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateSBLastDayData  extends CommonExecuteUnit {
	private int commitNum=1;
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("................��ʼ��������subject_balance��ҵ�����ݣ�.............");
					CraeteData();
					logger.info("................����ҵ��������ɣ�..............");
					
					logger.info("................��ʼ��������subject_balance��ӡ��˰���ݣ�.............");
					CreateCox();
					logger.info("................����ҵ��������ɣ�..............");
				}else{
					logger.info("...............���첻��Ҫ����.............");
				}
			
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	
	public void CraeteData() throws Exception{
		String al="insert into subject_balance(currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno) "
				+" select lg.currency,lg.orgid,lg.subjectno,sum(lg.debitbalance),sum(lg.creditbalance),'"+lastDate+"',lg.subjectno  from ledger_general lg "
				+" group by lg.currency,lg.orgid,lg.subjectno,lg.subjectno ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();	
	}
	
	public void CreateCox() throws Exception{
		String al="insert into subject_balance(currency,orgid,subjectno,debitbalance,creditbalance,occurdate,checksubjectno) "
					+" select sb.currency,sb.orgid,'9100101',sb.debitbalance,sb.Creditbalance,'"+lastDate+"','9100101' " +
					" from subject_balance_bak901 sb where sb.subjectno= '73000101' ";
				PreparedStatement ps = connection.prepareStatement(al);
				ps.execute();
				connection.commit();	
	}
	
}
