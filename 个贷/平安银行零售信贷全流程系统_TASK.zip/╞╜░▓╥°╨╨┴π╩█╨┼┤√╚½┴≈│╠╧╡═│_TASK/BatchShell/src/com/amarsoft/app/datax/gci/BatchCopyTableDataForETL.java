package com.amarsoft.app.datax.gci;



import java.sql.Statement;
import com.amarsoft.app.datax.gci.deductacc.thread.BatchThread;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class BatchCopyTableDataForETL extends CommonExecuteUnit{

	//�������ݵ�����Դ,����DataSourceURI�ĸ�ʽ����
	private Statement stmt = null;
	
	public int execute() {
		// �����д�����������ÿһ������
		try {
			String initStatus=super.init();
			if(initStatus.equals("skip")){
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				this.logger.info("�������ݿ�ʼ......");
				String callNames = this.getProperty("CallName", "");
				prepareProcess();
				//ִ�����ݶ���
				multiThread("com.amarsoft.app.datax.gci.deductacc.thread.BatchCopyTableDataForETLThread",callNames,this.deductDate);
				if(errorThreadNumber > 0)
				{
					throw new Exception("���ݴ���"+errorThreadNumber+"���̳߳����쳣��������־��");
				}
				postProcess();
				this.logger.info("�������ݽ���......");
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
			
				return TaskConstants.ES_SUCCESSFUL;
			}
		}
		catch (Exception e) {
			logger.error("����ʧ��"+ e.toString());
			e.printStackTrace();
			clearResource();
			
			return unitStatus;
		}
	}
	
	/**
	 * ���̴߳���
	 */
	public void multiThread(String className,String callNames,String deductDate) throws Exception {
		//�����������߳�
		this.runningThreadNumber = 0;
		this.errorThreadNumber = 0;
		if(callNames != null && !"".equals(callNames))
		{
			String callName[] = callNames.split(",");
			for ( int i = 1; i <= callName.length; i++ ) {
				//�½�һ�������߳�
				BatchThread theThread = (BatchThread)Class.forName(className).newInstance();
				theThread.init(this, i, callName[i-1].trim().toLowerCase(), this.deductDate);
				//����
				theThread.start();
				this.logger.info("�߳� [" + theThread.getName() + "]���� ...");
				System.out.println("�߳� [" + theThread.getName() + "]���� ...");
				this.runningThreadNumber ++;
			}
		}
		
		
		for (int i = 1;!(getProperty("executeProcess" + i) == null || 
				getProperty("executeProcess" + i).trim().equals("")); i++) {
			className = getProperty("executeProcess" + i);
			//�½�һ�������߳�
			BatchThread theThread = (BatchThread)Class.forName(className).newInstance();
			theThread.init(this, runningThreadNumber+i, className, this.deductDate);
			//����
			theThread.start();
			this.logger.info("�߳� [" + theThread.getName() + "]���� ...");
			System.out.println("�߳� [" + theThread.getName() + "]���� ...");
			this.runningThreadNumber ++;
		}
		

		//�ȴ����������߳�ע��
		while ( this.runningThreadNumber > 0 ) {
			if ( this.runningThreadNumber < this.threadNumber ) {
				this.logger.info("  ���� [" + this.runningThreadNumber + "] �������߳� �������� ...");
			}
			
			try {
				Thread.sleep( 30*1000);
			} catch (InterruptedException e) {
				this.logger.info("\n\nThreadScheduler.sleep( this.sleepRetry ) be InterruptedException !");
			} 
		}

		return;
	}
	
	
	
	//ǰ��ִ�е�SQL�������ж��̴߳���
	protected void prepareProcess() throws Exception{
		stmt = connection.createStatement();
		for (int i = 1;!(getProperty("prepareProcess" + i) == null || 
				getProperty("prepareProcess" + i).trim().equals("")); i++) {
			String sqlPrepareProcess = getProperty("prepareProcess" + i);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$inputdate}", lastDate);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$CurrentMonth}", currentMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$LastMonth}", lastMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$NextMonth}", nextMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$ReportDate}", deductDate);
			logger.info(sqlPrepareProcess);
			stmt.execute(sqlPrepareProcess);
			connection.commit();
		}
		stmt.close();
	}
	
	//����ִ�е�SQL�������ж��̴߳���
	protected void postProcess() throws Exception {

		stmt = connection.createStatement();
		for (int i = 1; !(getProperty("postProcess" + i) == null || getProperty("postProcess" + i).trim().equals("")); i++) {
			String sqlPostProcess = getProperty("postProcess" + i);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$CurrentMonth}", currentMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$LastMonth}", lastMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$NextMonth}", nextMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$ReportDate}", deductDate);
			logger.info(sqlPostProcess);
			stmt.execute(sqlPostProcess);
		}
		stmt.close();
	}
}
