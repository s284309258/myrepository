package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchInsertFinacingLoanAccNo extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��������й�ѡ��ͨ���ҽ����������Զ���ͨ���ҽ��˻�.....");
				insertFinacingAccount();
				logger.info("��������й�ѡ��ͨ���ҽ����������Զ���ͨ���ҽ��˻���ɣ�");
				
				logger.info("������������·��Ŵ���İ��ҽ���������ϵ.....");
				insertFinacingRelative();
				logger.info("������������·��Ŵ���İ��ҽ���������ϵ��ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/*
	 * �����а��ҽ��˻��Ŀͻ�  ��������ʱ���Զ����밴�ҽ������ϵ 
	 * */
	public void insertFinacingRelative() throws SQLException
	{
		String insertSql = " insert into finacing_relative(FinacingAccNo,SavingAccNo,InputDate,InputOrg,InputUser,Status,AccountType)" +
				" values(?,?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectTemp = " select count(*) as icount from finacing_relative where FinacingAccNo = ? and SavingAccNo=? and AccountType='02' ";
		PreparedStatement psSelectTemp = connection.prepareStatement(selectTemp);
		
		String selectSql = "  select fa.FinacingAccNo,lb.DeductAccNo,lb.PutOutNo " +
				" from Finacing_Account fa,Loan_Balance lb " +
				" where fa.CustomerID = lb.CustomerID and lb.PutOutDate = '"+lastDate+"' " +
				" and lb.BusinessKind = 'RCPM'";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			int icount = 0;
			
			psSelectTemp.setString(1,rs.getString("FinacingAccNo"));
			psSelectTemp.setString(2,rs.getString("PutOutNo"));
			ResultSet rsTemp = psSelectTemp.executeQuery();
			if(rsTemp.next())
			{
				icount = rsTemp.getInt("icount");
			}
			rsTemp.close();
			if(icount==0)
			{
			//�����������
				psInsertSql.setString(1,rs.getString("FinacingAccNo"));
				psInsertSql.setString(2,rs.getString("PutOutNo"));
				psInsertSql.setString(3,lastDate);
				psInsertSql.setString(4,"System");
				psInsertSql.setString(5,"Batch");
				psInsertSql.setString(6,"1");
				psInsertSql.setString(7,"02");	
				psInsertSql.addBatch();
				
				dealNum++;
				icount++;
			}
			psInsertSql.executeBatch();
		}
		rs.close();
		psInsertSql.executeBatch();
		psSelectTemp.close();
		psSelectSql.close();
		psInsertSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
	
	/*
	 * ��������й�ѡ��ͨ���ҽ����������Զ���ͨ���ҽ��˻�
	 * */
	public void insertFinacingAccount() throws SQLException
	{
		String insertSql = " insert into Finacing_Account(FinacingAccNo,CustomerID,BeginDate,Status,ApplicantStatus,UserID,OrgID,FinacingAccCard,FinacingType) values(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String insertRelative = " insert into finacing_relative(FinacingAccNo,SavingAccNo,InputDate,InputOrg,InputUser,Status,AccountType)" +
				" values(?,?,?,?,?,?,?)";
		PreparedStatement psInsertRelative = connection.prepareStatement(insertRelative);
		
		String selectPutOutNoSql = " select PutOutNo from Loan_Balance where CustomerID = ?  ";
		PreparedStatement psSelectPutOutNoSql = connection.prepareStatement(selectPutOutNoSql);
		
		String selectTemp = " select count(*) as icount from Finacing_Account where CustomerID=? ";
		PreparedStatement psSelectTemp = connection.prepareStatement(selectTemp);
		
		String selectSql =  " select lb.PutOutNo,lb.DeductAccNo, lb.CustomerID " +
							" from Loan_Balance lb,Business_Contract bc " +
							" where lb.ContractSerialNo = bc.SerialNo and bc.GoldFlag = '1' " +
							"  and lb.PutOutDate = '"+lastDate+"' " +
							"  and lb.BusinessKind = 'RCPM'" +
							"  and lb.customerid not in " +
							"  (select fa.CustomerID from Finacing_Account fa where fa.Status = '1') ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			int icount=0;
			psSelectTemp.setString(1,rs.getString("CustomerID"));
			ResultSet rsTemp = psSelectTemp.executeQuery();
			if(rsTemp.next())
			{
				icount = rsTemp.getInt("icount");
			}
			rsTemp.close();
			if(icount>0)
				continue;
			
			psInsertSql.setString(1,rs.getString("DeductAccNo"));
			psInsertSql.setString(2,rs.getString("CustomerID"));
			psInsertSql.setString(3,lastDate);
			psInsertSql.setString(4,"1");
			psInsertSql.setString(5,"0");  //Ĭ��Ϊ�ǹ�ͬ�����
			psInsertSql.setString(6,"Batch"); 
			psInsertSql.setString(7,"System"); 
			psInsertSql.setString(8,rs.getString("DeductAccNo")); 
			psInsertSql.setString(9,"SDB"); 
			psInsertSql.addBatch();
			
			//����������
			psInsertRelative.setString(1,rs.getString("DeductAccNo"));
			psInsertRelative.setString(2,rs.getString("DeductAccNo"));
			psInsertRelative.setString(3,lastDate);
			psInsertRelative.setString(4,"System");
			psInsertRelative.setString(5,"Batch");
			psInsertRelative.setString(6,"1");
			psInsertRelative.setString(7,"01");	
			psInsertRelative.addBatch();
			
			//�����������
			psSelectPutOutNoSql.setString(1,rs.getString("CustomerID"));
			ResultSet loanRs = psSelectPutOutNoSql.executeQuery();
			while(loanRs.next())
			{
				psInsertRelative.setString(1,rs.getString("DeductAccNo"));
				psInsertRelative.setString(2,loanRs.getString("PutOutNo"));
				psInsertRelative.setString(3,lastDate);
				psInsertRelative.setString(4,"System");
				psInsertRelative.setString(5,"Batch");
				psInsertRelative.setString(6,"1");
				psInsertRelative.setString(7,"02");	
				psInsertRelative.addBatch();
			}
			loanRs.close();

			icount++;
			
			psInsertSql.executeBatch();
			psInsertRelative.executeBatch();		
		}
		rs.close();
		psSelectTemp.close();
		psSelectSql.close();
		psInsertSql.close();
		psInsertRelative.close();
		psSelectPutOutNoSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
		dealNum = 0;
	}

}
