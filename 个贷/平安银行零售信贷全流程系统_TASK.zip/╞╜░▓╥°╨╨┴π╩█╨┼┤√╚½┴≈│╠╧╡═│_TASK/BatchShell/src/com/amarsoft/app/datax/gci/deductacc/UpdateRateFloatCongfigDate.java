package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateRateFloatCongfigDate extends CommonExecuteUnit{
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				logger.info("����VIP�������ñ������ʸ����������������������ñ�����Ч��־.....");
				updateVIPConfig();
				updateQConfig();
				logger.info("������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void updateVIPConfig() throws SQLException
	{
		String updateSql = " update vip_rate set Status = '2' where SerialNo = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select v1.SerialNo " +
				" from vip_rate v1,(select orgid,businesstype,viprateType,min(begindate) as minBegindate,max(begindate) as maxBegindate,count(*) as iCount from vip_rate where status='1' group by orgid,businesstype,viprateType) v2 " +
				" where v1.orgid=v2.orgid and v1.businesstype=v2.businesstype and v1.viprateType = v2.viprateType " +
				" and v1.begindate = v2.minBegindate and v2.maxBegindate = '"+deductDate+"' and v2.iCount > 1 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,rs.getString("SerialNo"));
			psUpdateSql.addBatch();
		}
		rs.close();
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		psSelectSql.close();
	}
	
	public void updateQConfig() throws SQLException
	{
		String updateSql = " update code_library set IsInUse ='2' where Codeno = 'QRateFloat' and ItemNo = ?";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select v1.ItemNo " +
				" from code_library v1,(select RelativeCode as orgid,ItemAttribute as businesstype,min(helptext) as minBegindate,max(helptext) as maxBegindate,count(*) as iCount from code_library where IsInUse='1' and CodeNo = 'QRateFloat' group by RelativeCode,ItemAttribute) v2 " +
				" where v1.RelativeCode=v2.orgid and v1.ItemAttribute=v2.businesstype " +
				" and v1.helptext = v2.minBegindate and v2.maxBegindate = '"+deductDate+"' and v2.iCount >1 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,rs.getString("ItemNo"));
			psUpdateSql.addBatch();
		}
		rs.close();
		psUpdateSql.executeBatch();
		psUpdateSql.close();
		psSelectSql.close();
	}
}
