package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

/**
 * �ж�FCR216�Ƿ�ɹ�
 * @author WANGWEIXING492
 * 
 */
public class FileUploadESBWithFCR extends CommonExecuteUnit {

	//�ļ��ţ������ж��Ƿ��յ�FCR216
	private String fileNo;
	//�ļ����� 
	private String fileType;
	//��Ϣ���� 
	private String megType;
	
	String sFileCount = "";
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPare();
				//FCR���ذ��ҽ��ļ���BIFMFBAJUP��
				if(fileType.equals("BIFMFBAJUP")){
					getFileESBWithFCR();
				}else{
					getFileESBWithFCR();
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void initPare() throws Exception{
		fileNo = this.getProperty("FileNo");
		fileType = this.getProperty("FileType");
		megType = this.getProperty("MegType");
		
		if (!"BIFMFBATUP".equals(fileType) && !"BIFMFBAJUP".equals(fileType)) {
			
			throw new Exception("fileType���岻��ȷ��");
		}
		
		alterFileName();
		
		String sDate= StringFunction.replace(deductDate,"/","");

		fileNo = StringFunction.replace(fileNo,"{$CurrentDate}",sDate);
		fileNo = StringFunction.replace(fileNo,"{$SixCurrentDate}",sDate.substring(2, 8));
		fileNo = StringFunction.replace(fileNo,"{$FileCount}",sFileCount);
		
		
	}
	
		
	//�ȴ�FCR�����ļ�ֱ���ɹ�
	private void getFileESBWithFCR() throws Exception {

		String sSql = "";
		sSql = "select tl.Ret_Status as Ret_Status,tl.describe"
					+ " from TransAction_Log tl"
					+ " where tl.ReceiveSystem = 'FROM_ESB'"
					+ " and tl.Service_Code = '11005000002@51'"
					+ " and tl.describe like '%" +fileNo+".txt@status_code:0000@%'";
		logger.info(sSql);
		PreparedStatement psQuery = connection.prepareStatement(sSql);
		//��ѯFCR�����ļ��Ƿ�ɹ�
		ResultSet rs = psQuery.executeQuery();
		
		if(rs.next()){
			if(rs.getString("Ret_Status").startsWith("S")){
				logger.info("FCR�ļ��ϴ��ɹ���");
			}else{
				rs.close();
				psQuery.close();
				throw new Exception("FCR216�ӿڷ���ʧ�ܣ�");
			}
		}else{
			rs.close();
			psQuery.close();
			throw new Exception("FCR216�ӿڷ���ʧ�ܣ�");
		}
		rs.close();
		psQuery.close();
	}
	
	public void alterFileName() throws Exception{
		String selectSql = "";
		selectSql = "select cl.attribute4,cl.attribute7 from code_library cl where codeno = 'DownloadFileFromFCR' and itemno = '001'";
		PreparedStatement psQuery = connection.prepareStatement(selectSql);
		ResultSet rs = psQuery.executeQuery();
		if (rs.next()) {
			if("BIFMFBATUP".equals(fileType)){
				sFileCount = rs.getString("attribute4").trim();
			}else{
				sFileCount = rs.getString("attribute7").trim();
			}
		}else{
			rs.close();
			psQuery.close();
			throw new Exception("�ļ����ʹ�����ѯʧ�ܣ�");
		}
		rs.close();
		psQuery.close();
	}

}
