package com.amarsoft.app.datax.gci.gjj;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.are.util.DataConvert;

/**
 * ִ��SQL�ű����и���
 * @author ZHAOXIAOJIAN427
 * @since 2012-06-13
 */

public class ExecuteSQLScript extends CommonExecuteUnit{
	
	public int execute() {
			
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				executeSql();
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	

	public void executeSql() throws Exception {
		String Sql = "";
		for(int i = 0; i < 100; i ++)
		{
			Sql = this.getProperty("SQL"+i);
			if(Sql == null || "".equals(Sql))
			{
				break;
			}
			else
			{
				logger.info("ִ��SQL�ű���"+Sql+"��");
				Statement statement = null;
				try
				{
					statement = this.connection.createStatement();
			        int cnt = statement.executeUpdate(Sql);
			        logger.info("�����¡�"+cnt+"��������");
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					throw ex;
				}
				finally
				{
					if(statement != null) statement.close();
				}
			}
		}
	}
}
