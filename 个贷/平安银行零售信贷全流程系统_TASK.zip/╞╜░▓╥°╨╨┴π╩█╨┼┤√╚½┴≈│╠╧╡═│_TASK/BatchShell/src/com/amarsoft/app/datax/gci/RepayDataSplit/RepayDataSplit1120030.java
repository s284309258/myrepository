package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.app.datax.gci.BatchConstant;

public class RepayDataSplit1120030 extends BasicRepayDataSplit {
	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
			boolean dReturn = true;
		
			String sPutOutNo = "";
			if(deductDateList.size()>0)
					sPutOutNo = deductDateList.get(0).getPutOutNo();
			else if(fareDetailList.size()>0)
				sPutOutNo = fareDetailList.get(0).getPutOutNo();
			else
				dReturn = false;
			
			//���ÿ���������
			String CreditCardFAccNo = accountMap.get("CreditCardFAccNo").getAccountNo();
			if(CreditCardFAccNo == null||CreditCardFAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"���ÿ����������������ڣ�");
				dReturn = false;
			}
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			if(RelativeAccNo==null||RelativeAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
				dReturn = false;
			}
			return dReturn;
		
	}


	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		if(!preCheck(deductDateList,aheadDeductdataList,fareDetailList,acctFeeInfoList,accountMap))
			return pamsAs400ArrayList;
		else
		{
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			//���ÿ���������
			String CreditCardFAccNo = accountMap.get("CreditCardFAccNo").getAccountNo();			
			
			//����һ�㻹������
			for(int j=0;j<deductDateList.size();j++)
			{
				DeductData deductData = deductDateList.get(j);
				
				//��Ϣ+��Ϣ
				double inteAmount = returnFine(deductData)+returnInte(deductData);
				if(inteAmount>0)
				{
					ErrorRecord(deductData.getPutOutNo(),"���ÿ���������Ϊ0�����ڵķ�Ϣ+��Ϣ���ܴ���0��");
				}
				
				//����
				double corpAmount = returnCorp(deductData);
				if(corpAmount>0)
				{
					PamsAs400 pamsAs400 = new PamsAs400(deductData.getPutOutNo(),deductData.getCurrency(),corpAmount,
							CreditCardFAccNo,RelativeAccNo,createDeductSerialNo(),
							BatchConstant.AMOUNTATTRIBUTE_CORP,deductData.getSTerm(),
							BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"","","");
					
					pamsAs400ArrayList.add(pamsAs400);
				}
				
			}
			
			/*//���ɷ�������
			for(int i=0;i<fareDetailList.size();i++)
			{
				FareDetaill fareDetail = fareDetailList.get(i);
				
				double fareAmount = fareDetail.getPayMoney()-fareDetail.getActualMoney();
				if(fareAmount>0)
				{
					//�жϸ÷����Ƿ�����һ�㻹��ķ��ü�¼����������ǰ����ķ��ü�¼
					boolean bb = false;
					if(aheadDeductdataList.size()==0)
					{
						bb = true;
					}
					else
					{
						if(deductDateList.size()==0)
						{
							bb = false;
						}
						else
						{
							for(int j=0;j<deductDateList.size();j++)
							{
								if(fareDetail.equals(deductDateList.get(j).getPayDate()))
									bb =true;
							}
						}
					}
					
					if(bb)
					{
						int ipaydate = Integer.valueOf(fareDetail.getPayDate().substring(0,4)+fareDetail.getPayDate().substring(5,7)+fareDetail.getPayDate().substring(8,10));
						PamsAs400 pamsAs400 = new PamsAs400(fareDetail.getPutOutNo(),fareDetail.getCurrency(),fareAmount,
								CreditCardFAccNo,RelativeAccNo,createDeductSerialNo(),
								BatchConstant.AMOUNTATTRIBUTE_CDFARE,ipaydate,
								BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"");
						
						pamsAs400ArrayList.add(pamsAs400);
					}
				}
			}*/
			
			
			
			return pamsAs400ArrayList;
		}
	}

}
