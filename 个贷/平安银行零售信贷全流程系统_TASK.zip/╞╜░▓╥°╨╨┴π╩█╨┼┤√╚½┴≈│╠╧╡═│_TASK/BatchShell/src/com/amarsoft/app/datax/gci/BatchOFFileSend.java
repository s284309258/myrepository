package com.amarsoft.app.datax.gci;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class BatchOFFileSend extends CommonExecuteUnit{

	int icount = 0;
	private String sLocalFileUrl;
	private String sFileClassName;
	private String sRemoteUserName;
	private String sRemoteServerName;
	private String sRemoteFile;
	private String NASUrl;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPara();
				logger.info("��ʼ����OF"+sFileClassName+"�ļ�......");
				delOfOkFile();
				sendOFFile();
				logger.info("����OF"+sFileClassName+"�ļ���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/*
	 * ��ʼ��������Ϣ 
	 * */
	public void initPara()
	{
		NASUrl = ARE.getProperty("NASUrl");
		sLocalFileUrl = NASUrl+getProperty("LocalFileUrl");		
		sFileClassName = getProperty("FileClassName");
		String sDate = "";
		if(sFileClassName.equalsIgnoreCase("OFPre"))
		{
			sDate = StringFunction.replace(deductDate,"/","");
		}
		else
		{
			sDate = StringFunction.replace(lastDate,"/","");
		}
		sLocalFileUrl=StringFunction.replace(sLocalFileUrl,"{$CurrentDate}",sDate);
		
		sRemoteUserName = getProperty("RemoteUserName");
		sRemoteServerName = getProperty("RemoteServerName");
		sRemoteFile = getProperty("RemoteFile");
		
	}
	
	public void delOfOkFile() throws IOException
	{
		File file = new File(sLocalFileUrl);
		if(!file.exists())
		{
			logger.error(sLocalFileUrl+"�����ڣ�");
			return;
		}
		if(!file.isDirectory())
		{
			logger.error("����ϵͳ����sLocalFileUrl��"+sLocalFileUrl+"����Ŀ¼��");
			return;
		}
		File[] fileList = file.listFiles();
		for(int i=0;i<fileList.length;i++)
		{
			File newFile = fileList[i];
			if(newFile.getName().indexOf(".ok")>0 || newFile.getName().indexOf(".OK")>0)
			{
				newFile.delete();
			}
		}
		
	}
	
	public void sendOFFile() throws Exception
	{
		File file = new File(sLocalFileUrl);
		if(!file.exists())
		{
			logger.error(sLocalFileUrl+"�����ڣ�");
			return;
		}
		if(!file.isDirectory())
		{
			logger.error("����ϵͳ����sLocalFileUrl��"+sLocalFileUrl+"����Ŀ¼��");
			return;
		}
		File[] fileList = file.listFiles();
		for(int i=0;i<fileList.length;i++){
			if (fileList[i].isFile()){
				SendFileToOFServer send = new SendFileToOFServer();
				boolean bb = send.scpsend(fileList[i].getPath(),sRemoteUserName,sRemoteServerName,sRemoteFile);
				if(bb)
				{
					String sOKFile = fileList[i].getPath()+".ok";
					boolean b = creatOKFile(sOKFile);
					if(b)
						logger.info("OK!");
					else
						logger.info("No");
					
					logger.info("�ļ���"+fileList[i].getName()+"���ͳɹ���");
				}
				else
					throw new Exception("�����ļ���"+fileList[i].getName()+"����ʧ�ܣ�");
			}
		}
	}
	
	public boolean creatOKFile(String sFileName) throws IOException
	{
		FileWriter fw = new FileWriter(sFileName);
		fw.write("OK");
		fw.close();
		SendFileToOFServer send = new SendFileToOFServer();
		boolean bb = send.scpsend(sFileName,sRemoteUserName,sRemoteServerName,sRemoteFile);
		return bb;
	}
	
	
}
