package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class OverBatch extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				Statement stmt=connection.createStatement();
				stmt.execute("update Org_Info set BusinessStatus='1' where BusinessStatus='2' ");
				stmt.execute("update Ploan_Setup set login='0',BatchDealFlag='0',NextBatchExecuteDate='"+deductDate+"' ");
				stmt.execute("update BATCHTASK_STATUS set DateFlag='1' where (InputDate='"+deductDate+"' or InputDate='"+lastDate+"') and TargetName = 'DeductData' ");
				stmt.close();
				logger.info("���մ�����ϣ�");
				BatchDealResultInfo();
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void BatchDealResultInfo() throws SQLException
	{
		String sql1 = " select SubjectNo,Inputdate,OrgID,Currency,LGDebit,LGCredit,SBDebit,SBCredit from hinder_error ";
		PreparedStatement psSelectSql = connection.prepareStatement(sql1);
		ResultSet rs1 = psSelectSql.executeQuery();
		while(rs1.next())
		{
			String sLine = "�ֲܷ�ƽ�� ";
			sLine = sLine + " ��Ŀ�� : "+rs1.getString("SubjectNo")+"@@";
			sLine = sLine + " ���� : "+rs1.getString("Inputdate")+"@@";
			sLine = sLine + " ������ : "+rs1.getString("OrgID")+"@@";
			sLine = sLine + " ���� : "+rs1.getString("Currency")+"@@";
			sLine = sLine + " ���˽跽��� : "+rs1.getString("LGDebit")+"@@";
			sLine = sLine + " ���˴������ : "+rs1.getString("LGCredit")+"@@";
			sLine = sLine + " ���˽跽��� : "+rs1.getString("SBDebit")+"@@";
			sLine = sLine + " ���˴������ : "+rs1.getString("SBCredit");
			logger.info(sLine);
		}
		rs1.close();
		psSelectSql.close();
		
		String sql2 = " select PutOutNo,ErrorType,DeductDate from error_lbhinder ";
		PreparedStatement psSelectSql2 = connection.prepareStatement(sql2);
		ResultSet rs2 = psSelectSql2.executeQuery();
		while(rs2.next())
		{
			String sLine = "�����ƽ�� ";
			sLine = sLine + " ��ݺ� : "+rs2.getString("PutOutNo")+"@@";
			sLine = sLine + " ���� : "+rs2.getString("DeductDate")+"@@";
			logger.info(sLine);
		}
		rs2.close();
		psSelectSql2.close();
		
	}
}
