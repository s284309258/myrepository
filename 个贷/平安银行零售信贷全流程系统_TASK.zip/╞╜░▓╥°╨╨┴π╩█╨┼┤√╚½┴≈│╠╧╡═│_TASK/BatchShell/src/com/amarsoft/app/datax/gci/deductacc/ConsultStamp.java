package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.task.TaskConstants;

public class ConsultStamp extends CommonExecuteUnit{
	
	private int commitNum ;
	private int dealNum = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String delSql=" delete from Consult_stamp where ConsultDate = '"+deductDate+"' ";
				logger.info("��� Consult_stamp:sql="+delSql);
				PreparedStatement psDeleteData = connection.prepareStatement(delSql);
				psDeleteData.execute();
				logger.info("���Consult_stamp�������! ");
				psDeleteData.close();
				
				logger.info("��ʼ����ſ����ӡ��˰......");
				consultStapDuty();
				logger.info("����ſ����ӡ��˰��ɣ�");
				
				/*logger.info("��ʼ���������·ſ����ӡ��˰......");
				consultStapDutyED();
				logger.info("���������·ſ����ӡ��˰��ɣ�");*/
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	//�������ӡ��˰
	public void consultStapDuty() throws SQLException
	{
		String insertSql = " INSERT INTO Consult_stamp(OrgID,ConsultDate,ConsultAmount,Currency) VALUES(?,?,?,?)";
	
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql =" select bc.OperateOrgID,sum(bc.BusinessSum)*0.00005 as Stamp,bc.Currency  " +
				" from business_contract bc " +
				" where bc.PutOutDate = '"+deductDate+"' and (bc.StampTaxType <> '3' or bc.stamptaxtype is null) " +
				"  and bc.Serialno in (select ContractSerialNo from loan_balance ) " +
				" group by bc.OperateOrgID,bc.Currency ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql); 
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("OperateOrgID"));
			psInsertSql.setString(2,deductDate);
			psInsertSql.setDouble(3,NumberTools.round(rs.getDouble("Stamp"),2));
			psInsertSql.setString(4,rs.getString("Currency"));
			psInsertSql.addBatch();
			
			dealNum++;
				
			if(dealNum>commitNum)
			{
				try
				{
					psInsertSql.executeBatch();
				}
				catch(SQLException ex)
				{
					rs.close();
					psInsertSql.close();
					psSelectSql.close();
					
					throw ex;
				}
				connection.commit();
				dealNum=0;
			}
		}
		try
		{
			psInsertSql.executeBatch();
		}
		catch(SQLException ex)
		{
			throw ex;
		}
		finally
		{
			rs.close();
			psInsertSql.close();
			psSelectSql.close();
		}
	}
	
	/*//����¶�γ��˴������ӡ��˰
	public void consultStapDutyED() throws SQLException
	{
		String insertSql = " INSERT INTO Consult_stamp(OrgID,ConsultDate,ConsultAmount,Currency) VALUES(?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		String select = " select count(*) as count from Consult_stamp where orgid = ?  and consultDate = ? and Currency = ? ";
		PreparedStatement psSelect = connection.prepareStatement(select);
		
		String updateSql = "update Consult_stamp set ConsultAmount = ConsultAmount + ? where OrgID =? and ConsultDate=? and Currency = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql ="select relativeCreditNo from business_contract  where putouttype ='050' and putoutdate = '"+deductDate+"'";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql); 
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//��Ⱥ�ͬ��
			String relativeCreditNo = rs.getString("relativeCreditNo");
			String select1 = "select StampTaxType,businesssum,operateorgid,currency from business_contract where serialno='"+relativeCreditNo+"' ";
			PreparedStatement psSelect1 = connection.prepareStatement(select1);
			ResultSet rsSelect1 = psSelect1.executeQuery();
			String stampTaxType = "",orgid = "",currency="";
			double businessSum = 0d;
			while(rsSelect1.next()){
				stampTaxType = rsSelect1.getString("StampTaxType");
				orgid = rsSelect1.getString("operateorgid");
				businessSum = rsSelect1.getDouble("businesssum");
				currency = rsSelect1.getString("currency");
			}
			rsSelect1.close();
			psSelect1.close();
			//����������һ��
			if("3".equals(stampTaxType)){
				continue;
			}else{
				//����·ſ��¼����
				String sql1= "select count(1) as count from loan_balance where contractserialno in (" +
						"select serialno from business_contract where relativecreditno  ='"+relativeCreditNo+"')";
				PreparedStatement psSql1 = connection.prepareStatement(sql1);
				ResultSet rsSql1 = psSql1.executeQuery();
				int sum = 0;
				if(rsSql1.next()){
					sum = rsSql1.getInt("count");
				}
				rsSql1.close();
				psSql1.close();
				//1�������ñʶ�Ⱥ�ͬ
				if(sum==1){
					psSelect.setString(1, orgid);
					psSelect.setString(2, deductDate);
					psSelect.setString(3, currency);
					ResultSet rsSelect = psSelect.executeQuery();
					while(rsSelect.next()){
						int count = rsSelect.getInt("count");
						//������ڣ������
						if(count>0){
							psUpdateSql.setDouble(1, NumberTools.round(businessSum*0.5/10000,2));
							psUpdateSql.setString(2, orgid);
							psUpdateSql.setString(3, deductDate);
							psUpdateSql.setString(4, currency);
							psUpdateSql.addBatch();
						//�����ڣ������
						}else{
							psInsertSql.setString(1, orgid);
							psInsertSql.setString(2, deductDate);
							psInsertSql.setDouble(3, NumberTools.round(businessSum*0.5/10000,2));
							psInsertSql.setString(4, currency);
							psInsertSql.addBatch();
						}
					}
					rsSelect.close();
					//����������������һ��
				}else{
					continue;
				}
			}
		}
		rs.close();
		try
		{	
			psUpdateSql.executeBatch();
			psInsertSql.executeBatch();
		}
		catch(SQLException ex)
		{
			throw ex;
		}
		psSelectSql.close();
		psUpdateSql.close();
		psInsertSql.close();
	}
	*/
	
}
