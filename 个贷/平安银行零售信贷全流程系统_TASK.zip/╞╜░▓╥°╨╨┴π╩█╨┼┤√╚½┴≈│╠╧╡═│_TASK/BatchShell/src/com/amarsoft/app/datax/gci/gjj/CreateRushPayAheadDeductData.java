package com.amarsoft.app.datax.gci.gjj;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.CalInterest;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;

public class CreateRushPayAheadDeductData extends CommonExecuteUnit{
	
	private int commitNum ;
	private int deductNum = 0;
	private int icount = 0;
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','AHEAD_DEDUCT_DATA') ";
				logger.info("���AHEAD_DEDUCT_DATA:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("�����ǰ�����������ݱ�AHEAD_DEDUCT_DATA������� ");
				psDelSql.close();
				
				logger.info("������ǰ������������......");
				insertAheadDeductData();
				logger.info("��������ǰ������������"+icount+"���� ");
				logger.info("������ǰ��������������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}  	
		
	}
	
	public boolean checkColnameValue(String sColName,String sNewValue)
	{
		if(sColName.equalsIgnoreCase("BillKind"))
		{
			if(!sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_ALL) && !sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_HINGT) && !sNewValue.equalsIgnoreCase(AccountConstants.AHEADCORP_LOW))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("CorpType"))
		{
			if(!sNewValue.equalsIgnoreCase(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS) && !sNewValue.equalsIgnoreCase(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS_INTEREST))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("AheadCorp"))
		{
			double dAheadCorp = Double.parseDouble(sNewValue);
			if(dAheadCorp<=0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("AheadTerm"))
		{
			int iAheadTerm = Integer.parseInt(sNewValue);
			if(iAheadTerm<=0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else if(sColName.equalsIgnoreCase("PayPoundage"))
		{
			double dPayPoundage = Double.parseDouble(sNewValue);
			if(dPayPoundage<0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return false;
		}
	}

	
	public void insertAheadDeductData() throws Exception
	{
				
		String insertSql = " INSERT INTO Ahead_Deduct_Data(ChangeSerialNo,PutOutNo,STerm,Currency,Term, "
			      + " DeductAccNo,DeductAccNo1,DeductAccNo2,PayCurrentCorp,PayInte,PayPoundage,DealFlag,Payfareamount,Paydate) "
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectAmtSql = "select sum(ls.PayCurrentCorp-ls.ActualCurrentCorp+ls.PayDefaultCorp-ls.ActualDefaultCorp+ "
			 +" ls.PayOverDueCorp-ls.ActualOverDueCorp+ls.PayInte-ls.ActualInte+ls.PayInnerInte-ls.ActualInnerInte+ls.PayOutInte-ls.ActualOutInte "
			 +" +ls.PayInnerInteFine-ls.ActualInnerInteFine+ls.PayOutInteFine-ls.ActualOutInteFine) as PayAmt "
			 +" from LOANBACK_STATUS ls "
			 +" where ls.PutOutNo = ? and ls.PayOffFlag = '0' "
			 +" and ls.PayDate <= ? ";
		PreparedStatement psSelectAmtSql = connection.prepareStatement(selectAmtSql);
		
		//��ݱ�š������ˮ��������ǰ�������+��Ϣ�����ޡ�ΥԼ�𡢻����˺�
		String selectSql = " select LB.PutOutNo as ObjectNo,'CHD'||LB.PutOutNo as ChangeSerialNo,'11' as BillKind," +
			      " '1' as CorpType,GC.PayAmt as AheadCorp,0 as AheadTerm,0 as PayPoundage,LB.LoanAccNo,LB.CalcDayInteDate " +
			      " from LOAN_BALANCE LB," +
			      " (select LoanNo,sum(PayAmt) as PayAmt from (select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') and DeductType <> '1' union all " +
			      " select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_ZTOB where inputdate = '"+this.deductDate+"' and DeductType <> '1') where 1=1 group by LoanNo) GC " +
			      " where getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'1') and LB.LoanStatus in('0','1') " +
			      " union all " +
			      " select LB.PutOutNo as ObjectNo,'CHD'||LB.PutOutNo as ChangeSerialNo,'11' as BillKind," +
			      " '1' as CorpType,GC.PayAmt as AheadCorp,0 as AheadTerm,0 as PayPoundage,LB.LoanAccNo,LB.CalcDayInteDate " +
			      " from LOAN_BALANCE LB," +
			      " (select LoanNo,sum(PayAmt) as PayAmt from (select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') and DeductType <> '1' union all " +
			      " select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_ZTOB where inputdate = '"+this.deductDate+"' and DeductType <> '1') where 1=1 group by LoanNo) GC " +
			      " where getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'2') and LB.LoanStatus in('0','1') ";
		System.out.println(selectSql);
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double PayAmt = 0;
			psSelectAmtSql.setString(1, rs.getString("ObjectNo"));
			psSelectAmtSql.setString(2, rs.getString("CalcDayInteDate"));
			ResultSet rs1 = psSelectAmtSql.executeQuery();
			if(rs1.next())
			{
				PayAmt = rs1.getDouble("PayAmt");
			}
			rs1.close();
			
			if(!checkColnameValue("BillKind",rs.getString("BillKind")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"��ǰ��������BillKind����");
				continue;
			}
			if(!checkColnameValue("CorpType",rs.getString("CorpType")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"�������CorpType����");
				continue;
			}
			if(!checkColnameValue("AheadCorp",rs.getString("AheadCorp")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"������С�ڵ���0");
				continue;
			}
			if(!checkColnameValue("PayPoundage",rs.getString("PayPoundage")))
			{
				aheadErrorRecord(rs.getString("ChangeSerialNo"),"��ǰ����ΥԼ��С��0");
				continue;
			}
			
			//�廹���ų�����������Ӧ�ĵ��ڽ��
			if(rs.getDouble("AheadCorp")-PayAmt <= 0)
			{
				continue;
			}
			
			String sPutOutNo = rs.getString("ObjectNo");
			String sChangeSerialNo = rs.getString("ChangeSerialNo");
			String sCorpType = rs.getString("CorpType");
			String sLoanAccNo = rs.getString("LoanAccNo");
			
			LoanBalance loanBalance = new LoanBalance();
			loanBalance.SetLoanBalance(sPutOutNo,connection);
			loanBalance.initLoanRateAlter(connection);
			//����廹���˻�Ϊ�գ��򲻴���
			if(sLoanAccNo == null || "".equals(sLoanAccNo))
			{
				continue;
			}
			
			double dSumAmount = rs.getDouble("AheadCorp")-PayAmt;
			double dCorp = 0.0;
			double dInte = NumberTools.round(CalInterest.getInterest(loanBalance,AccountConstants.REPAY_AMOUNT_TYPE_CORPUS,loanBalance.getNormalBalance(),deductDate),
						AccountConstants.MONEY_PRECISION);
			if(!"0".equals(loanBalance.getLoanStatus())){
				if(dSumAmount >=dInte){
					dCorp = NumberTools.round(dSumAmount - dInte,AccountConstants.MONEY_PRECISION);
				}else
				{
					dInte=dSumAmount;
					dCorp=0.00;
				}
			}else{
				if(dSumAmount >=loanBalance.getPeriodInte()){
					dInte = loanBalance.getPeriodInte();
					dCorp = NumberTools.round(dSumAmount - dInte,AccountConstants.MONEY_PRECISION);
				}else
				{
					dInte=dSumAmount;
					dCorp=0.00;
				}
			}
			
			if(dCorp > loanBalance.getNormalBalance()) {
				dCorp = loanBalance.getNormalBalance();//ȫ����ǰ����
			}
			
			int sAheadTerm = rs.getInt("AheadTerm");
			double  dPayPoundage = rs.getDouble("PayPoundage");
			psInsertSql.setString(1,sChangeSerialNo);
			psInsertSql.setString(2,sPutOutNo);
			psInsertSql.setInt(3,loanBalance.getSTerm());
			psInsertSql.setString(4,loanBalance.getCurrency());
			psInsertSql.setInt(5,sAheadTerm);  
			psInsertSql.setString(6,sLoanAccNo);
			psInsertSql.setString(7,"");
			psInsertSql.setString(8,"");
			psInsertSql.setDouble(9,dCorp);
			psInsertSql.setDouble(10,dInte);
			psInsertSql.setDouble(11,dPayPoundage);
			psInsertSql.setString(12,BatchConstant.PAYAHEAD_DEALFLAG_FALSE);
			psInsertSql.setDouble(13,0);
			psInsertSql.setString(14,deductDate);
			psInsertSql.addBatch();
			deductNum++;
			icount++;
			
			if(deductNum>commitNum)
			{
				psInsertSql.executeBatch();
				deductNum=0;
				logger.info("�Ѳ�������"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		psSelectAmtSql.close();
		deductNum=0;
	}
	

	public void aheadErrorRecord(String sChangeSerialNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sChangeSerialNo);
		batchErrorRecord.setObjectType("LoanChange");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
}

