package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class InsertAheadSettle extends CommonExecuteUnit{

	private int sTemp = 1;
	private int dealNum = 0;
	private int icount = 0;
	private String sDate;
	private String SerialNo;
	private String BatchNo;
	
	@Override
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ����ahead_pl��ʱ��......");
				insertData();
				logger.info("��������ʱ��"+icount+"����");
				logger.info("������ʱ����ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void insertData() throws Exception 
	{
		try
		{
			connection.setAutoCommit(false);
			sDate = StringFunction.replace(deductDate, "/", "");
			String insertSql = "insert into ahead_pl(BATCHNO,SERIALNO,PUTOUTNO,BILLKIND,CORPTYPE,AHEADCORP,CHANGEDATE,POUNDAGE,BATCHSTATUS,INPUTDATE,CARDNUM) values(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
			
			String selectSql = "select RECORDTYPE,CARDNBR,LOANSEQ from ahead_settle";
			PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
			ResultSet rs = psSelectSql.executeQuery();
			while(rs.next())
			{
				dealNum++;
				String RecordType = rs.getString("RECORDTYPE");		//��¼����
				String CardNbr = rs.getString("CARDNBR");	//���ÿ�����
				String LoanSEQ = rs.getString("LOANSEQ");	//������ˮ��
				
				BatchNo = "TQJQ" + sDate;
				SerialNo = "TQJQ" + sDate + getCode(sTemp);
				
				psInsertSql.setString(1, BatchNo); 	//���κ�
				psInsertSql.setString(2, SerialNo);		//��ˮ��
				psInsertSql.setString(3, LoanSEQ);	//��ݺ�
				psInsertSql.setString(4, "10");  //��ǰ��������
				psInsertSql.setString(5, "0");    //��ǰ����������
				psInsertSql.setDouble(6, 0.00);  //��ǰ������
				psInsertSql.setString(7, deductDate);  //��ǰ��������
				psInsertSql.setDouble(8, 0.00);  //ΥԼ��
				psInsertSql.setString(9, RecordType);  //����״̬
				psInsertSql.setString(10, deductDate);  //��������
				psInsertSql.setString(11, CardNbr);  //���ÿ�����
				psInsertSql.addBatch();
				icount++;
				sTemp++;
			}
			psInsertSql.executeBatch();
			rs.close();
			psInsertSql.close();
			psSelectSql.close();
			connection.commit();
		}catch(Exception e)
		{
			connection.rollback();
			e.printStackTrace();
			throw new Exception("����ahead_pl��ʱ��ʧ��");
		}
	}

	public String getCode(int a)
	{
		String s = String.valueOf(a);
		int len = 6-s.length();
		for(int i=0;i<len;i++)
		{
			s="0"+s;
		}
		return s;
	}
}
