package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.security.Key;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;

import sun.misc.BASE64Encoder;

public class TOAPasswordUtil {

	// Ĭ�ϵĹ�Կ�ļ���
	private static String defaultKeyFileName = "/nfsc/BLOAN_RCPM_id947444_vol1/TOAkey.dat";
	
	/**
	 * ����
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public static String decryptPassword(String keyFileName,String password) throws Exception {
		
		Key key = getPublicKey(keyFileName);
		
		String srt[]=password.split(",");
    	byte[] rand1=new byte[8];
    	byte[] ctext1=new byte[srt.length-8];
    	for (int i=0;i<srt.length;i++){		
    		if(i<8){ 
    		    rand1[i]=Byte.parseByte(srt[i]);
    	    }else{
    	    	ctext1[i-8]=Byte.parseByte(srt[i]);
    	    	}
    	}
    	IvParameterSpec iv1=new IvParameterSpec(rand1);//iv����һ��Ϊ8��������
    	Cipher cp1=Cipher.getInstance("DESede/CBC/PKCS5Padding");
    	cp1.init(Cipher.DECRYPT_MODE, key,iv1);
    	byte []ptext1=cp1.doFinal(ctext1);
        String p=new String(ptext1,"UTF-8");
    	return p;
	}
	
	/**
	 * ��ù�Կ
	 * @return
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	private static Key getPublicKey(String keyFileName) throws Exception {
		
		if(null == keyFileName || "".equals(keyFileName)){
			keyFileName = defaultKeyFileName;
		}
		
		InputStream key = new FileInputStream(keyFileName); 
		ObjectInputStream b = new ObjectInputStream(key);
		Key k = (Key) b.readObject();
		key.close();
		b.close();
		return k;
	}
	
	/**
	 * ����
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public static String encryptPassword(String keyFileName,String password) throws Exception {
		Key key = getPublicKey(keyFileName);
		StringBuffer reSEnc=new StringBuffer();
		
		try {
			//����
			byte[] rand=new byte[8];
			Random r=new Random();
			r.nextBytes(rand);
			IvParameterSpec iv=new IvParameterSpec(rand);//iv����һ��Ϊ8��������
			Cipher cp=Cipher.getInstance("DESede/CBC/PKCS5Padding");
			cp.init(Cipher.ENCRYPT_MODE, key,iv);
			byte ptext[]=password.getBytes("UTF-8");
			byte ctext[]=cp.doFinal(ptext);	
		    int cL=ctext.length; 
			for(int i=0;i<cL+8;i++){
				if (i<8){
					reSEnc.append(rand[i]).append(",");
				}else{
					reSEnc.append(ctext[i-8]).append(",");
				}
			}
			reSEnc.deleteCharAt(reSEnc.length()-1);	
		
		} catch (Exception e) {
			throw new Exception("����CBCģʽ���ܷ����쳣!"+e.getMessage());
		}   
    	return reSEnc.toString();
	}
	
	

}
