package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchCreateDsInteData extends CommonExecuteUnit{
	private int commitNum ;
	private int dealNum = 0;
	private int icount=0;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				String delSql=" delete from DsInte_Record where DsDate = '"+deductDate+"' ";
				logger.info("���DsInte_Record :sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("���DsInte_Record������� ");
				
				logger.info("��ʼ������Ϣ����......");
				createDsInteData();
				logger.info("������Ϣ������ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void createDsInteData() throws SQLException
	{
		String insertSql = " INSERT INTO DsInte_Record(PutOutNo,Sterm,DsDate,DsAmount,Currency)"
			+"VALUES(?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select lb.PutOutNo,ls.Sterm,(ls.PayInte+ls.PayInnerInte+ls.PayOutInte)*nvl(lb.DsInteProportion,0) as DsInteAmount,lb.Currency "
			             + " from Loan_Balance lb,Loanback_Status ls "
			             + " where lb.Putoutno = ls.Putoutno and ls.PayDate = '"+deductDate+"' and ls.aheadnum = '0' and lb.DsInteProportion > 0 and lb.disdate > '"+deductDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			if(rs.getDouble("DsInteAmount")==0)
			{
				continue;
			}
			else
			{
				psInsertSql.setString(1,rs.getString("PutOutNo"));
				psInsertSql.setString(2,rs.getString("Sterm"));
				psInsertSql.setString(3,deductDate);
				psInsertSql.setDouble(4,rs.getDouble("DsInteAmount"));
				psInsertSql.setString(5,rs.getString("Currency"));
				psInsertSql.addBatch();
				dealNum++;
				icount++;
			}
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѳ���"+icount+"�����ݣ�");
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psInsertSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"�����ݣ�");
	}
}
