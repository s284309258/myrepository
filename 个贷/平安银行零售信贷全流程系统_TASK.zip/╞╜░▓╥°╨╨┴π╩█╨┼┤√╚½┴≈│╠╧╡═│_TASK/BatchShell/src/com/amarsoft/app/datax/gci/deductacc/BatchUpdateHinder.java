package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;


import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.ledger.SubjectInfo;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class BatchUpdateHinder extends CommonExecuteUnit {
	private int commitNum ;
	private int dealNum = 0;
	boolean ok = true; 
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("������ϸ��Subject_OccurAmt�н��յ���Ϣ......");
				String delSql = " delete from Subject_OccurAmt where OccurDate = '"+deductDate+"'";
				PreparedStatement psDelSql =connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("����Subject_OccurAmt���!");
				
				logger.info("�������˱�Subject_Balance�н��յ���Ϣ......");
				String delSql1 = " delete from Subject_Balance where OccurDate = '"+deductDate+"'";
				PreparedStatement psDelSql1 =connection.prepareStatement(delSql1);
				psDelSql1.execute();
				logger.info("����Subject_Balance���!");
				
				/*logger.info("������ϸ�˽��ƽ����......");
				insertErrorDetail();
				logger.info("������ϸ�˽��ƽ������ɣ�");*/
				
				logger.info("������ϸ�ʱ�......");
				insertOccurAmt();
				logger.info("��ϸ�ʱ�������ɣ�");	
				
				logger.info("���ջ�����ϸ�˽��ƽ���鲢����......");
				checkOccurAmt();
				logger.info("���ջ�����ϸ�˽��ƽ���鲢������ɣ�");
				
				
				logger.info("����ϸ���в������ӡ��˰��¼��Ϣ.......");
				stampInsertToOccur();
				logger.info("ӡ��˰�����Ϣ������ɣ�");
				
				/*=============����901����ӡ��˰���ˣ��ó���ֻ���ߵ���ִ��һ��BEGIN=============*/
				if("2012/09/06".equals(deductDate)){
					logger.info("����901����ӡ��˰���˿�ʼ.......");
					UpdateErrorAccount();
					logger.info("����901����ӡ��˰���˽�����");
				}
				/*===========================END=======================================*/
				
				logger.info("�������˱�......");
				initSubjectBalance();
				updateSubjectBalance();
				BatchSubjectBalance();
				//createSubjectBalance();
				
				/*=============����901����ӡ��˰���ˣ��ó���ֻ���ߵ���ִ��һ��BEGIN=============*/
				if("2012/09/06".equals(deductDate)){
					updateSubjectBalance901();
				}
				/*===========================END=======================================*/
				logger.info("���˱�������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//���ɵ�����ϸ��
	public void insertOccurAmt() throws SQLException
	{
		
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate,AccAcountFlag) VALUES(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		
		String selectSql = " select OrgID,Currency,SubjectNo,sum(DebitAmt) as DebitAmt,sum(CreditAmt) as CreditAmt "
		      + " from ledger_detail "
		      + " where OccurDate = '"+deductDate+"' and (HandStatus = '1' or HandStatus = '2')"
		      + " group by OrgID,Currency,SubjectNo ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,rs.getString("SubjectNo"));
			psInsertSql.setDouble(4,rs.getDouble("DebitAmt"));
			psInsertSql.setDouble(5,rs.getDouble("CreditAmt"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.setString(7,"0");
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}

	//���ս����ƽ�ĵ��ݼ�¼����Error_Detail��
	public void insertErrorDetail() throws SQLException
	{
		String insertsql=" insert into Error_Detail(BillNo,OrgId,Currency) values(?,?,?)";
		String updatesql=" update Ledger_Detail Set HandStatus='0' where BillNo=?";
		PreparedStatement psInsertSql=connection.prepareStatement(insertsql);
		PreparedStatement psUpdateSql=connection.prepareStatement(updatesql);
		String selectsql=" select OrgId, BillNo,Currency,sum(Debitamt),sum(Creditamt)"
		    +" from Ledger_Detail where (SubjectNo not like '7%' and SubjectNo not like '6%') and  OccurDate = '"+deductDate+"'" 
		    +" group by OrgId,BillNo ,Currency "
            +" having sum(Debitamt)<>sum(Creditamt)";
		PreparedStatement psSelectSql=connection.prepareStatement(selectsql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("BillNo"));
			psInsertSql.setString(2,rs.getString("OrgId"));
			psInsertSql.setString(3,rs.getString("Currency"));
			psInsertSql.addBatch();
			
			psUpdateSql.setString(1, rs.getString("BillNo"));
			psUpdateSql.addBatch();
			
		}
		psInsertSql.executeBatch();
		psUpdateSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
		psUpdateSql.close();
		
	}
	
	public void checkOccurAmt() throws SQLException
	{
		//���벹�˻���
		String sql = "INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate,AccAcountFlag) VALUES(?,?,?,?,?,?,?)";
		PreparedStatement psSql = connection.prepareStatement(sql);
		
		String selectsql=" select OrgId,Currency,sum(Debitamt) as DAmt,sum(Creditamt) as CAmt "
		    +" from Subject_OccurAmt where (SubjectNo not like '7%' and SubjectNo not like '6%') and  OccurDate = '"+deductDate+"'" 
		    +" group by OrgId,Currency ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectsql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			double dAmt = rs.getDouble("DAmt");
			double cAmt = rs.getDouble("CAmt");
			String currency = rs.getString("Currency");
			String orgID = rs.getString("OrgId");
			//����跽�࣬����¼��2620088��Ŀ����������࣬����¼�� 1390088��Ŀ��
			if(dAmt>cAmt){
				psSql.setString(1, currency);
				psSql.setString(2,orgID);
				psSql.setString(3,"2620088");
				psSql.setDouble(4, 0);
				psSql.setDouble(5, dAmt-cAmt);
				psSql.setString(6, deductDate);
				psSql.setString(7, "0");
				psSql.addBatch();	
			}
			if(dAmt<cAmt){
				psSql.setString(1, currency);
				psSql.setString(2,orgID);
				psSql.setString(3,"1390088");
				psSql.setDouble(4, cAmt-dAmt);
				psSql.setDouble(5, 0);
				psSql.setString(6, deductDate);
				psSql.setString(7, "0");
				psSql.addBatch();
			
			}	
		}
		psSql.executeBatch();	
		rs.close();
		psSelectSql.close();
		psSql.close();
	}
	
	public void stampInsertToOccur() throws SQLException
	{
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate) VALUES(?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		
		String selectSql = " select OrgID,ConsultAmount,Currency from Consult_stamp where ConsultDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,"9100101");
			psInsertSql.setDouble(4,0);
			psInsertSql.setDouble(5,rs.getDouble("ConsultAmount"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}
	
/**
 * ����901����ӡ��˰���˿�ʼ
 * @throws Exception
 * */
	public void UpdateErrorAccount() throws Exception
	{
		//��ʼ�����뷢��������
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate) VALUES(?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		//��ʼ�����·���������
		String updateSql = " update Subject_OccurAmt set DebitAmt=0,CreditAmt=CreditAmt+? where subjectno='9100101' and OccurDate='"+deductDate+"' " +
						   " and OrgID=? and Currency=?";
		PreparedStatement psUpdateSql=connection.prepareStatement(updateSql);
		//��ʼ����Ҫ���ʵ�����
		String selectSql = " Select Currency,OrgID,DebitBalance,CreditBalance From subject_balance Where SubjectNo='9100101' and OccurDate='"+lastDate+"'";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		
		//�������
		String OrgID="",Currency="";
		boolean isHave=false;
		double debitamt=0d,creditamt=0d;
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//�ȵ���Ҫ�����Ļ�������Ŀ�����
			OrgID=DataConvert.toString(rs.getString("OrgID"));
			Currency=DataConvert.toString(rs.getString("Currency"));
			debitamt=DataConvert.toDouble(rs.getString("DebitBalance"));
			creditamt=DataConvert.toDouble(rs.getString("CreditBalance"));
			
			if(debitamt==0 && creditamt==0) continue;

			//�жϸû�������Ŀ�����ֵ����Ƿ��Ѵ��ڵ��շ���������������������������·�����
			String selectSqlHave = " Select 1 From Subject_OccurAmt Where SubjectNo='9100101' and OccurDate='"+deductDate+"' " +
								   " and OrgID='"+OrgID+"' and Currency='"+Currency+"'";
			PreparedStatement pshave=connection.prepareStatement(selectSqlHave);
			ResultSet rsHave=pshave.executeQuery();
			if(rsHave.next()){
				isHave=true;
			}else{
				isHave=false;
			}
			rsHave.close();
			pshave.close();
			
			if(isHave){
				psUpdateSql.setDouble(1, 2*Math.abs(creditamt-debitamt));
				psUpdateSql.setString(2, OrgID);
				psUpdateSql.setString(3, Currency);
				psUpdateSql.addBatch();
			}else{
				psInsertSql.setString(1,Currency);
				psInsertSql.setString(2,OrgID);
				psInsertSql.setString(3,"9100101");
				psInsertSql.setDouble(4,0);
				psInsertSql.setDouble(5,2*Math.abs(creditamt-debitamt));
				psInsertSql.setString(6,deductDate);
				psInsertSql.addBatch();
			}
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psUpdateSql.executeBatch();
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psUpdateSql.executeBatch();
		psInsertSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psUpdateSql.close();
		psInsertSql.close();
		dealNum=0;
	}
	/**
	 * ����901����ӡ��˰�������˴���
	 * @throws Exception
	 * */
	public void updateSubjectBalance901() throws Exception
	{
		String updateSql = " update Subject_Balance set CreditBalance=CreditBalance-DebitBalance,DebitBalance=0 where subjectno='9100101' and OccurDate='"+deductDate+"'";
		PreparedStatement psUpdateSql=connection.prepareStatement(updateSql);
		psUpdateSql.execute();
		psUpdateSql.close();
	}
	
	//��ʼ���������˱�
	public void initSubjectBalance() throws SQLException
	{	
		String insertSql = " insert into Subject_Balance(Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,OccurDate,CheckSubjectNo) "
						 + " values(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,CheckSubjectNo from subject_balance where OccurDate = '"+lastDate+"' ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,rs.getString("SubjectNo"));
			psInsertSql.setDouble(4,rs.getDouble("DebitBalance"));
			psInsertSql.setDouble(5,rs.getDouble("CreditBalance"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.setString(7,rs.getString("CheckSubjectNo"));
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum =0;
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		psInsertSql.close();
		psSelectSql.close();
		dealNum =0;
	}
	
	//�������˱�
	public void updateSubjectBalance() throws SQLException, LoanException
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		String updateSql = " update Subject_balance set DebitBalance = DebitBalance+?,CreditBalance = CreditBalance+? where SubjectNo=? and OrgID=? and Currency=? and OccurDate = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String updateOccurAmt = " update Subject_OccurAmt set AccAcountFlag = '1' where SubjectNo=? and OrgID=? and Currency=? and OccurDate = ? ";
		PreparedStatement psUpdateOccurAmt = connection.prepareStatement(updateOccurAmt);
		
		String insertSql = " insert into Subject_Balance(Currency,OrgID,SubjectNo,DebitBalance,CreditBalance,OccurDate,CheckSubjectNo)  "
			+ " SELECT Currency,OrgID,SubjectNo,0,0,'"+deductDate+"',SubjectNo from Subject_Occuramt so " 
			+ " WHERE NOT EXISTS(select sb.* from Subject_Balance sb where sb.currency=so.currency and sb.orgid = so.orgid and sb.subjectno = so.subjectno and sb.occurdate=so.occurdate)"
			+ "  and so.occurdate = '"+deductDate+"' ";
		PreparedStatement psInserSql = connection.prepareStatement(insertSql);
		psInserSql.execute();
		psInserSql.close();
		
		String selectSql = " select Currency,OrgID,SubjectNo,DebitAmt,CreditAmt "
		    	+ " from Subject_OccurAmt "
		    	+ " where OccurDate = '"+deductDate+"' ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sLoanWay =LedgerSubjectConfig.getSubjectLoanWay(rs.getString("SubjectNo"));
			if(sLoanWay.equalsIgnoreCase("D"))
			{
				psUpdateSql.setDouble(1,rs.getDouble("DebitAmt")-rs.getDouble("CreditAmt"));
				psUpdateSql.setDouble(2,0);
			}
			else if(sLoanWay.equalsIgnoreCase("C"))
			{
				psUpdateSql.setDouble(1,0);
				psUpdateSql.setDouble(2,rs.getDouble("CreditAmt")-rs.getDouble("DebitAmt"));
			}
			else
			{
				psUpdateSql.setDouble(1,rs.getDouble("DebitAmt"));
				psUpdateSql.setDouble(2,rs.getDouble("CreditAmt"));
			}
			psUpdateSql.setString(3,rs.getString("SubjectNo"));
			psUpdateSql.setString(4,rs.getString("OrgID"));
			psUpdateSql.setString(5,rs.getString("Currency"));
			psUpdateSql.setString(6,deductDate);
			psUpdateSql.addBatch();
			
			psUpdateOccurAmt.setString(1,rs.getString("SubjectNo"));
			psUpdateOccurAmt.setString(2,rs.getString("OrgID"));
			psUpdateOccurAmt.setString(3,rs.getString("Currency"));
			psUpdateOccurAmt.setString(4,deductDate);
			psUpdateOccurAmt.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psUpdateSql.executeBatch();
				psUpdateOccurAmt.executeBatch();
				dealNum=0;
			}
		}
		psUpdateSql.executeBatch();
		psUpdateOccurAmt.executeBatch();
		rs.getStatement().close();
		psSelectSql.close();
		psUpdateOccurAmt.close();
		psUpdateSql.close();
	}
	
	//���·���˫���Ŀ�����ֵ
	public void BatchSubjectBalance() throws Exception{
		String updateSql="UPDATE subject_balance SET CreditBalance=CreditBalance-DebitBalance," +
			"DebitBalance=0 WHERE SubjectNo=? and OccurDate = ? And CreditBalance-DebitBalance>=0";
		String updateSql2="UPDATE subject_balance SET CreditBalance=0," +
			"DebitBalance=DebitBalance-CreditBalance WHERE SubjectNo=? and OccurDate = ? And CreditBalance-DebitBalance<0";
		
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		PreparedStatement psUpdateSql2 = connection.prepareStatement(updateSql2);
		
		HashMap<String, SubjectInfo> subjectInfoHashMap = LedgerSubjectConfig.getSubjectInfoHashMap();
		for (Iterator<String> iter = subjectInfoHashMap.keySet().iterator(); iter.hasNext();){
			String key = iter.next();
			SubjectInfo subjectInfo=subjectInfoHashMap.get(key);
			if(subjectInfo.getSubjectLevel().equals("3")&&subjectInfo.getStatus().equals("1")&&subjectInfo.getLoanWay().equalsIgnoreCase("B")){//������Ŀ��Ϊ���ÿ�Ŀ				
				psUpdateSql.setString(1, subjectInfo.getSubjectNo());
				psUpdateSql.setString(2, deductDate);
				psUpdateSql.addBatch();
				psUpdateSql.executeBatch();
				
				psUpdateSql2.setString(1, subjectInfo.getSubjectNo());
				psUpdateSql2.setString(2, deductDate);
				psUpdateSql2.addBatch();
				psUpdateSql2.executeBatch();
			}
		}
		psUpdateSql.close();
		psUpdateSql2.close();
	}

}
