package com.amarsoft.app.datax.gci;

public class AreaExponent {

	private String AreaCode;
	private double Exponent;
	public String getAreaCode() {
		return AreaCode;
	}
	public void setAreaCode(String areaCode) {
		AreaCode = areaCode;
	}
	public double getExponent() {
		return Exponent;
	}
	public void setExponent(double exponent) {
		Exponent = exponent;
	}
}
