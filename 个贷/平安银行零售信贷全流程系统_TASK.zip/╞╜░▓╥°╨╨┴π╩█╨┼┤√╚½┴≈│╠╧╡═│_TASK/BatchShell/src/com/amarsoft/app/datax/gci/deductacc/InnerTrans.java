package com.amarsoft.app.datax.gci.deductacc;


import com.amarsoft.account.Deal.TransScheduler;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class InnerTrans extends CommonExecuteUnit{

	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				logger.info("��ʼ������ת......");
				TransScheduler transScheduler = new TransScheduler(connection);
				transScheduler.BatchTransScheduler("3001",deductDate);
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
