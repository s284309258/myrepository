package com.amarsoft.app.datax.gci;


public class AcctFeeInfoBatch{
	private String SerialNo;        //��ˮ��
	private String ObjectNo;		//������
	private String FeeType;         //�������ͣ����룺LoanFeeType��
	private String PayDate;
	private double PayMoney;
	private double ActualMoney;
	private String FeeAccountNo;
	private String Currency;
	private String OffFlag;
	private int sterm;
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public String getObjectNo() {
		return ObjectNo;
	}
	public void setObjectNo(String objectNo) {
		ObjectNo = objectNo;
	}
	public String getFeeType() {
		return FeeType;
	}
	public void setFeeType(String feeType) {
		FeeType = feeType;
	}
	public String getPayDate() {
		return PayDate;
	}
	public void setPayDate(String payDate) {
		PayDate = payDate;
	}
	public double getPayMoney() {
		return PayMoney;
	}
	public void setPayMoney(double payMoney) {
		PayMoney = payMoney;
	}
	public double getActualMoney() {
		return ActualMoney;
	}
	public void setActualMoney(double actualMoney) {
		ActualMoney = actualMoney;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getOffFlag() {
		return OffFlag;
	}
	public void setOffFlag(String offFlag) {
		OffFlag = offFlag;
	}
	public int getSterm() {
		return sterm;
	}
	public void setSterm(int sterm) {
		this.sterm = sterm;
	}
	public String getFeeAccountNo() {
		return FeeAccountNo;
	}
	public void setFeeAccountNo(String feeAccountNo) {
		FeeAccountNo = feeAccountNo;
	}
}
