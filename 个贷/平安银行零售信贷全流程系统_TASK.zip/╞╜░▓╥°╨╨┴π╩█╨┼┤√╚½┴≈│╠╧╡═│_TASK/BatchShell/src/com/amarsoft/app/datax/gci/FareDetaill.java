package com.amarsoft.app.datax.gci;

public class FareDetaill {

	private String PutOutNo;
	private String PayDate;
	private double PayMoney;
	private double ActualMoney;
	private String OffFlag;
	private String Currency;
	private int sterm;
	public int getSterm() {
		return sterm;
	}
	public void setSterm(int sterm) {
		this.sterm = sterm;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public String getPayDate() {
		return PayDate;
	}
	public void setPayDate(String payDate) {
		PayDate = payDate;
	}
	public double getPayMoney() {
		return PayMoney;
	}
	public void setPayMoney(double payMoney) {
		PayMoney = payMoney;
	}
	public double getActualMoney() {
		return ActualMoney;
	}
	public void setActualMoney(double actualMoney) {
		ActualMoney = actualMoney;
	}
	public String getOffFlag() {
		return OffFlag;
	}
	public void setOffFlag(String offFlag) {
		OffFlag = offFlag;
	}
	
}
