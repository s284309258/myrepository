package com.amarsoft.app.datax.gci;

public class GuarantyFrequency {

	private String sTypeNo;
	private String sOrgID;
	private String sGuarantyFrequency;
	public String getSTypeNo() {
		return sTypeNo;
	}
	public void setSTypeNo(String typeNo) {
		sTypeNo = typeNo;
	}
	public String getSOrgID() {
		return sOrgID;
	}
	public void setSOrgID(String orgID) {
		sOrgID = orgID;
	}
	public String getSGuarantyFrequency() {
		return sGuarantyFrequency;
	}
	public void setSGuarantyFrequency(String guarantyFrequency) {
		sGuarantyFrequency = guarantyFrequency;
	}
	
}
