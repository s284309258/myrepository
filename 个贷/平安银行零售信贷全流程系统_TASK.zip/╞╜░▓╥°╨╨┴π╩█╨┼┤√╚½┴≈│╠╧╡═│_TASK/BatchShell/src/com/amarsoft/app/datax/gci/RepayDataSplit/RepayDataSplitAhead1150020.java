package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;

public class RepayDataSplitAhead1150020 extends BasicRepayDataSplit {

	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		//������ѧ������Ϣ�˻�
		String DsInteAccNo = accountMap.get("DsInteAccNo").getAccountNo();
		
		for(int i=0;i<aheadDeductdataList.size();i++)
		{
			AheadDeductData aheadDeductData = aheadDeductdataList.get(i);
			String sDeductSerialNo = createDeductSerialNo();
			
			//��ǰ������Ϣ ʹ�ù�����Ϣ�˺Ž��л���
			double inteAmount = returnAheadInte(aheadDeductData);
			if(inteAmount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),inteAmount,
						DsInteAccNo,RelativeAccNo,sDeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_AHEADINTE,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				pamsAs400ArrayList.add(pamsAs400);
			}
			
			double poundageAmount =returnPoundage(aheadDeductData);
			if(poundageAmount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),poundageAmount,
						aheadDeductData.getDeductAccNo(),RelativeAccNo,sDeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_POUNDAGE,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				pamsAs400ArrayList.add(pamsAs400);
			}
			//��ǰ����� ʹ�ø����˺Ž��л���
			double corpAmount =returnAheadCorp(aheadDeductData);
			if(corpAmount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),corpAmount,
						aheadDeductData.getDeductAccNo(),RelativeAccNo,sDeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_AHEADCORP,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				pamsAs400ArrayList.add(pamsAs400);
			}

		}
		
		return pamsAs400ArrayList;
	}

	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		String sPutOutNo = aheadDeductdataList.get(0).getPutOutNo();
		boolean dReturn = true;
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		if(DeductAccNo == null||DeductAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
			dReturn = false;
		}
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		if(RelativeAccNo==null||RelativeAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
			dReturn = false;
		}
		//������ѧ������Ϣ�˻�
		String DsInteAccNo = accountMap.get("DsInteAccNo").getAccountNo();
		if(DsInteAccNo==null||DsInteAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý�ݹ�����ѧ������Ϣ�˻������ڣ�");
			dReturn = false;
		}
		return dReturn;
	}

}
