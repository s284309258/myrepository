package com.amarsoft.app.datax.gci.deductacc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.*;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.task.TaskConstants;
/**
 * ICS�����ļ�
 * @author EX-SHENGXIAOPAN001
 *
 */
public class BatchFileSendMsg extends CommonExecuteUnit{
	
	private String sql;
	private String fileName;
	private PrintWriter outputstreamwriter;
	private String separator;
	private String NASUrl;
	private String fileUrl;
	private String FejrnNo;//ǰ�û���ˮ��
	ESBTransaction transaction =null;
	
	public void exportResultSet(String sql,TableMetaData tableMetaData,PrintWriter outputstreamwriter) throws Exception{
		separator = this.getProperty("separator");
		Statement stm = connection.createStatement();
		ResultSet rs=stm.executeQuery(sql);
		int rowNum=0;
		String rsString="";
		while(rs.next()){
			String s="";
			rowNum++;
			for(int i=1;i<=tableMetaData.getColumnCount();i++){
				ColumnMetaData columnMetaData= tableMetaData.getColumn(i);
				rsString=rs.getString(columnMetaData.getName());
				if(rsString==null)rsString="";
				s+=rsString+separator;
			}
			s+="\n";
			outputstreamwriter.write(s);
		}
		rs.close();
		stm.close();
	}
	@SuppressWarnings({ "finally", "static-access" })
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				unitStatus= TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
					fileName =  this.getProperty("unit.fileName");
				
					NASUrl = ARE.getProperty("NASUrl");
					fileUrl= this.getProperty("unit.fileUrl"); 
					
					String sDate = StringFunction.replace(deductDate,"/","");
					fileName=StringFunction.replace(fileName,"{$CurrentDate}",sDate);
					fileUrl=StringFunction.replace(fileUrl,"{$CurrentDate}",sDate);
					
					fileUrl = NASUrl+fileUrl;
					File file = new File(fileUrl);
					if(!file.exists())
					{
						file.mkdirs();
					}
					
					//updateFileName(fileName);
					fileName = fileUrl+fileName;
					outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName),"UTF-8")),true);
					for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty(
							"unit.recordSet" + i).trim().equals("")); i++) {
						
						sql=this.getProperty("unit.recordSet"+i);
						
						String[] s=sql.split(":");
						sql=sql.substring(sql.indexOf(s[1])+s[1].length()+1);
						sql = StringFunction.replace(sql,"{$CurrentDate}",deductDate);
						logger.info("��ǰ������sql="+sql);
						System.out.println(ARE.getMetaData(s[0]).getTable(s[1]));
						exportResultSet(sql,ARE.getMetaData(s[0]).getTable(s[1]),outputstreamwriter);
					}
				
					outputstreamwriter.close();
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					
				}
		}
		catch(Exception e){
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
		}
		finally{
			clearResource();
			return unitStatus;
		}
	}
}
