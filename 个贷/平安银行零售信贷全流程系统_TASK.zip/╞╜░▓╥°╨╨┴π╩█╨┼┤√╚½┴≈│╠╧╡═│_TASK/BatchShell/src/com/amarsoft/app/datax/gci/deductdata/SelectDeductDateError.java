package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class SelectDeductDateError extends CommonExecuteUnit {
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				
				logger.info("��ʼ�������ݸ�ʽ��ǰ������Ϣɨ��......");
				selectError1();
				selectError2();
				logger.info("�������ݸ�ʽ��ǰ������Ϣɨ����ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void selectError1() throws SQLException, ParseException
	{
		String selectSql = " select dd.PutOutNo from deduct_data dd where dd.Deductaccno is null group by dd.PutOutNo ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			errorRecord(rs.getString("PutOutNo"),"δ���ÿۿ��ʺ�");
		}
		rs.close();
	}
	
	public void selectError2() throws SQLException, ParseException
	{
		String selectSql = " select dd.PutOutNo from deduct_data dd  "
						 + " where (dd.PayCurrentCorp+dd.PayDefaultCorp+dd.PayOverDueCorp+dd.PayInte+dd.PayInnerInte+dd.PayOutInte+dd.PayInnerInteFine+dd.PayOutInteFine)< "
						 + " (ActualCurrentCorp+ActualDefaultCorp+ActualOverDueCorp+ActualInte+ActualInnerInte+ActualOutInte+ActualInnerInteFine+ActualOutInteFine) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			errorRecord(rs.getString("PutOutNo"),"״̬��Ϣ����ʵ��������Ӧ�����");
		}
		rs.close();
	}
	
	public void errorRecord(String sPutOutNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sPutOutNo);
		batchErrorRecord.setObjectType("LoanBalance");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
	
}
