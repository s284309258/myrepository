package com.amarsoft.app.datax.gci;

public class CallInfoConfigCode {

	private String SerialNo;
	private String CheckType;
	private String sSchemeNo;
	private String sBusinessType;
	private double minAmount;
	private double maxAmount;
	private String sRepayType;
	private int iMinTerm;
	private int iMaxTerm;
	private int iCallPeriod;
	
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public String getCheckType() {
		return CheckType;
	}
	public void setCheckType(String checkType) {
		CheckType = checkType;
	}
	public String getSSchemeNo() {
		return sSchemeNo;
	}
	public void setSSchemeNo(String schemeNo) {
		sSchemeNo = schemeNo;
	}
	public String getSBusinessType() {
		return sBusinessType;
	}
	public void setSBusinessType(String businessType) {
		sBusinessType = businessType;
	}
	public double getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(double minAmount) {
		this.minAmount = minAmount;
	}
	public double getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(double maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getSRepayType() {
		return sRepayType;
	}
	public void setSRepayType(String repayType) {
		sRepayType = repayType;
	}
	public int getICallPeriod() {
		return iCallPeriod;
	}
	public void setICallPeriod(int callPeriod) {
		iCallPeriod = callPeriod;
	}
	public int getIMinTerm() {
		return iMinTerm;
	}
	public void setIMinTerm(int minTerm) {
		iMinTerm = minTerm;
	}
	public int getIMaxTerm() {
		return iMaxTerm;
	}
	public void setIMaxTerm(int maxTerm) {
		iMaxTerm = maxTerm;
	}
	
	
}
