package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateGuarantyFinishStatus extends CommonExecuteUnit{

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	boolean ok = true; 
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("��ʼ����ѺƷ����״̬......");
				updateStats();
				logger.info("����ѺƷ����״̬��ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void updateStats() throws SQLException
	{
		String updateSql = " update Guaranty_Info set Status = '04',Unloadreason='01' where Guarantyid = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String selectSql = " select gi.GuarantyID " +
				" from Business_Contract bc,Guaranty_Relative gr,Guaranty_Info gi " +
				" where bc.SerialNo = gr.ObjectNo and gr.ObjectType in ('CBContractApply','SWContractApply') and gr.Guarantyid = gi.Guarantyid " +
				" and gi.Status = '02' and BC.FinishDate is not null and BC.FinishDate <> ' ' "+
				" and (BC.RelativeGJJNo is null or(BC.RelativeGJJNo is not null and not exists(select 1 "+
				" from business_contract bc1, Guaranty_Relative gr1 "+
				" where bc1.serialno = gr1.ObjectNo and gr1.Guarantyid = gr.Guarantyid and bc1.FinishDate is null))) ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,rs.getString("GuarantyID"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum = 0;
				logger.info("�Ѿ�����"+icount+"������");
			}
		}
		psUpdateSql.executeBatch();
		logger.info("һ������"+icount+"�����ݣ�");
		rs.close();
		psUpdateSql.close();
		psSelectSql.close();
	}
	
}
