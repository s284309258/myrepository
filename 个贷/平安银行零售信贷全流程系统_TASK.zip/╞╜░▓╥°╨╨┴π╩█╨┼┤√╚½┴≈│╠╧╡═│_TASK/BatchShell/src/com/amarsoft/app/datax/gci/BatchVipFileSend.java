package com.amarsoft.app.datax.gci;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class BatchVipFileSend extends CommonExecuteUnit{

	int icount = 0;
	private String sLocalFileUrl;
	private String sFileClassName;
	private String sRemoteUserName;
	private String sRemoteServerName;
	private String sRemoteFile;
	private String NASUrl;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPara();
				logger.info("��ʼ����OF"+sFileClassName+"�ļ�......");
				sendOFFile();
				logger.info("����OF"+sFileClassName+"�ļ���ɣ�");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	/*
	 * ��ʼ��������Ϣ 
	 * */
	public void initPara()
	{
		NASUrl = ARE.getProperty("NASUrl");
		sLocalFileUrl = NASUrl+getProperty("LocalFileUrl");		
		sFileClassName = getProperty("FileClassName");
		String sDate = "";
		sDate = StringFunction.replace(deductDate,"/","");
		sLocalFileUrl=StringFunction.replace(sLocalFileUrl,"{$CurrentDate}",sDate);
		logger.info("LocalFileUrl·����"+sLocalFileUrl);
		sRemoteUserName = getProperty("RemoteUserName");
		sRemoteServerName = getProperty("RemoteServerName");
		sRemoteFile = getProperty("RemoteFile");
	}
	
	//�����ļ�
	public void sendOFFile() throws Exception
	{
		File file = new File(sLocalFileUrl);
		if(!file.exists())
		{
			logger.error(sLocalFileUrl+"�����ڣ�");
			return;
		}
		if(!file.isDirectory())
		{
			logger.error("����ϵͳ����sLocalFileUrl��"+sLocalFileUrl+"����Ŀ¼��");
			return;
		}
		File[] fileList = file.listFiles();
		for(int i=0;i<fileList.length;i++){
			if (fileList[i].isFile()){
				SendFileToOFServer send = new SendFileToOFServer();
				boolean bb = send.scpsend(fileList[i].getPath(),sRemoteUserName,sRemoteServerName,sRemoteFile);
				if(bb)
				{
					logger.info("�ļ���"+fileList[i].getName()+"���ͳɹ���");
				}
				else
					throw new Exception("�����ļ���"+fileList[i].getName()+"����ʧ�ܣ�");
			}
		}
	}
	
}
