package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;

public class RepayDataSplitAheadSDB1140100 extends BasicRepayDataSplit {

	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		if(!preCheck(deductDateList,aheadDeductdataList,fareDetailList,acctFeeInfoList,accountMap))
			return pamsAs400ArrayList;
		else
		{	
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			String sDeductSerialNo = createDeductSerialNo();
			String deductAccNo = "";
			String sChangeSerialNo = "";
			String putoutno = "";
			String currency = "";
			double amount = 0;
			double allAmount= 0;
			for(int i=0;i<aheadDeductdataList.size();i++)
			{
				AheadDeductData aheadDeductData = aheadDeductdataList.get(i);	
				deductAccNo = aheadDeductData.getDeductAccNo();
				sChangeSerialNo = aheadDeductData.getChangeSerialNo();
				putoutno = aheadDeductData.getPutOutNo();
				currency = aheadDeductData.getCurrency();
				amount = returnAheadCorp(aheadDeductData)+returnAheadInte(aheadDeductData)+returnPoundage(aheadDeductData);
			}
			
			//���ý��
			double fareAmount = returnFareAmount(fareDetailList);
			//����ͷ���һ�𷢸��չ�ۿ�
			allAmount=amount+fareAmount;
			if(allAmount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(putoutno,currency,allAmount,
						deductAccNo,RelativeAccNo,sDeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_SDB_AHEADAMOUNT,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,sChangeSerialNo,"","");
				pamsAs400ArrayList.add(pamsAs400);
			}

			return pamsAs400ArrayList;
		}
	}
	
	//������ǰ�������
	private double returnFareAmount(ArrayList<FareDetaill> fareDetailList) {
		double fareAmount = 0.0;
		for(int i=0;i<fareDetailList.size();i++){
			FareDetaill fareDetail = fareDetailList.get(i);
			fareAmount += fareDetail.getPayMoney()-fareDetail.getActualMoney();
		}
		return fareAmount;
	}

	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		String sPutOutNo = aheadDeductdataList.get(0).getPutOutNo();
		boolean dReturn = true;
		//�ͻ������ʽ��˻�
		String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
		if(DeductAccNo == null||DeductAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
			dReturn = false;
		}
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		if(RelativeAccNo==null||RelativeAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
			dReturn = false;
		}
		return dReturn;
	}

}
