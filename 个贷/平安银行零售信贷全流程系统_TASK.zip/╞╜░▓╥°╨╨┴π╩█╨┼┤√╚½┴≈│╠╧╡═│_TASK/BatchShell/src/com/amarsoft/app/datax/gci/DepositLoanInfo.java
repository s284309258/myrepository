package com.amarsoft.app.datax.gci;

/**
 * @author YUJIYU090
 * ���������ݶ���
 * */
public class DepositLoanInfo {
	//��ݱ��
	private String PutOutNo;
	//ҵ��Ʒ��
	private String BusinessType;
	//������˻���
	private String OrgID;
	//�´λ�����
	private String NextPayDate;
	//�������
	private String MaturityDate;
	//����ϵͳ�ͻ���
	private String CustomerID;
	//���ʴ�������վ����
	private double LastMonthAvgBalance;
	//�����ʲ�����ֶ�
	private double AllBalance;
	//�����
	private double SavingLoanProport;
	//�����ʸ�������
	private double OldRateFloat;
	//ԭʼ���ʸ�������
	private double OrirateFloat;
	//�����ʸ�������
	private double NewRateFloat;
	//�������
	private String ChangeDate;
	//�Ƿ���Ҫ�������ʱ��
	private boolean IsRateFloatChange;
	
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public String getBusinessType() {
		return BusinessType;
	}
	public void setBusinessType(String businessType) {
		BusinessType = businessType;
	}
	public String getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}
	public double getNewRateFloat() {
		return NewRateFloat;
	}
	public void setNewRateFloat(double newRateFloat) {
		NewRateFloat = newRateFloat;
	}
	public String getChangeDate() {
		return ChangeDate;
	}
	public void setChangeDate(String changeDate) {
		ChangeDate = changeDate;
	}
	public boolean isRateFloatChange() {
		return IsRateFloatChange;
	}
	public void setRateFloatChange(boolean isRateFloatChange) {
		IsRateFloatChange = isRateFloatChange;
	}
	public String getOrgID() {
		return OrgID;
	}
	public void setOrgID(String orgID) {
		OrgID = orgID;
	}
	public String getNextPayDate() {
		return NextPayDate;
	}
	public void setNextPayDate(String nextPayDate) {
		NextPayDate = nextPayDate;
	}
	public String getMaturityDate() {
		return MaturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		MaturityDate = maturityDate;
	}
	public double getOrirateFloat() {
		return OrirateFloat;
	}
	public void setOrirateFloat(double orirateFloat) {
		OrirateFloat = orirateFloat;
	}
	public double getOldRateFloat() {
		return OldRateFloat;
	}
	public void setOldRateFloat(double oldRateFloat) {
		OldRateFloat = oldRateFloat;
	}
	public double getLastMonthAvgBalance() {
		return LastMonthAvgBalance;
	}
	public void setLastMonthAvgBalance(double lastMonthAvgBalance) {
		LastMonthAvgBalance = lastMonthAvgBalance;
	}
	public double getAllBalance() {
		return AllBalance;
	}
	public void setAllBalance(double allBalance) {
		AllBalance = allBalance;
	}
	public double getSavingLoanProport() {
		return SavingLoanProport;
	}
	public void setSavingLoanProport(double savingLoanProport) {
		SavingLoanProport = savingLoanProport;
	}
}
