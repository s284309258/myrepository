package com.amarsoft.app.datax.gci;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.amarsoft.are.sql.DataSourceURI;
import com.amarsoft.are.sql.TabularReader;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class BatchMiarateDataForYearEnd extends CommonExecuteUnit{


	private PreparedStatement pstmInsert = null;

	private ArrayList<String> columns = new ArrayList<String>();

	private Statement stmt;

	protected DataSourceURI sourceData;

	protected ResultSet importResultSet;

	protected int batchUpdateNumber;

	protected int bufferSize;
	
	int currentRow = 0;

	protected TabularReader reader = null;

	protected String[] checkFields = null;
	
	//�������ݵ�����Դ,����DataSourceURI�ĸ�ʽ����
	public final String PROPERTY_SOURCE_DATA = "sourceData";

	// ����Դ�Ļ�������С
	public final String PROPERTY_BUFFER_SIZE = "bufferSize";

	 // ÿ���ύ������
	public final String PROPERTY_BATCH_UPDATE_NUMBER = "batchUpdateNumber";

	protected void init1() throws Exception{
		
		//buffer size
		String buff = getProperty(PROPERTY_BUFFER_SIZE,"1");
		bufferSize = Integer.parseInt(buff);
		//ÿ���ύ������
		String record = getProperty(PROPERTY_BATCH_UPDATE_NUMBER,"1");
		batchUpdateNumber = Integer.parseInt(record);
	
		stmt = connection.createStatement();
		for (int i = 1;!(getProperty("prepareProcess" + i) == null || 
				getProperty("prepareProcess" + i).trim().equals("")); i++) {
			String sqlPrepareProcess = getProperty("prepareProcess" + i);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$currentYear}", currentYear);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$CurrentMonth}", currentMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$LastMonth}", lastMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$NextMonth}", nextMonth);
			sqlPrepareProcess=StringFunction.replace(sqlPrepareProcess,"{$ReportDate}", deductDate);
			logger.info(sqlPrepareProcess);
			stmt.execute(sqlPrepareProcess);
			connection.commit();
		}
		stmt.close();

		//��ԭ���ݿ���ʵõ��������
		String s = getProperty(PROPERTY_SOURCE_DATA); // ԭ���ݿ�����
		s=StringFunction.replace(s,"{$currentYear}", currentYear);
		s=StringFunction.replace(s,"{$CurrentMonth}", currentMonth);
		s=StringFunction.replace(s,"{$LastMonth}", lastMonth);
		s=StringFunction.replace(s,"{$NextMonth}", nextMonth);
		s=StringFunction.replace(s,"{$ReportDate}", deductDate);
		sourceData = new DataSourceURI(s);
		reader = new TabularReader(sourceData);
		if (bufferSize > 0) {
			reader.setBufferSize(bufferSize);
		}
		importResultSet = reader.getResultSet();

		String sqlInsert = "insert into " + getProperty("TableName")+ "(";
		String SqlValues = "values(";
		int columnCount = importResultSet.getMetaData().getColumnCount();
		columns.clear();

		for (int i = 1; i <= columnCount; i++) {
			if (i == columnCount) {
				sqlInsert = sqlInsert+ importResultSet.getMetaData().getColumnName(i)+ ")";
				SqlValues = SqlValues + "?)";
			}
			else {
				sqlInsert = sqlInsert+ importResultSet.getMetaData().getColumnName(i)+ ",";
				SqlValues = SqlValues + "?,";
			}
			columns.add(i - 1, importResultSet.getMetaData().getColumnTypeName(i));
		}
		sqlInsert = sqlInsert + SqlValues;
		logger.info(sqlInsert);
		pstmInsert = connection.prepareStatement(sqlInsert);
		
	}

	protected void processRow()  throws Exception{
		for (int i = 0; i < columns.size(); i++) {
			if (columns.get(i).equals("VARCHAR2")|| columns.get(i).equals("CHAR")) {
				pstmInsert.setString(i + 1, importResultSet.getString(i + 1));
			} else if (columns.get(i).equals("NUMBER")) {
				pstmInsert.setDouble(i + 1, importResultSet.getDouble(i + 1));
			} else {
				pstmInsert.setString(i + 1, importResultSet.getString(i + 1));
			}
		}
		pstmInsert.addBatch();
	}

	@SuppressWarnings("finally")
	public int execute() {
		// �����д�����������ÿһ������
		try {
			String initStatus=super.init();
			if(initStatus.equals("skip")){
				return TaskConstants.ES_SUCCESSFUL;
			}
			String yearendDate = currentYear+"/12/31";
			if(!deductDate.equals(yearendDate))
			{
				logger.info("���ղ����ģ�飡");
				unitStatus=TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
			else
			{
				init1();
				int iRow = 0;
				while (importResultSet.next()) {
					iRow++;
					currentRow = importResultSet.getRow();
					//trace("DEBUG");
					processRow();
					if (iRow == this.batchUpdateNumber) {
						logger.info(currentRow);
						pstmInsert.executeBatch();
						iRow = 0;
					}
				}
				if (iRow > 0) {
					pstmInsert.executeBatch();
					iRow = 0;
				}
				postProcess();
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
			
				return TaskConstants.ES_SUCCESSFUL;
			}
		}
		catch (Exception e) {
			logger.error("����ʧ��"+ e.toString());
			e.printStackTrace();
			clearResource();
			
			return unitStatus;
		}
	}

	protected void postProcess() throws Exception {

		stmt = connection.createStatement();
		for (int i = 1; !(getProperty("postProcess" + i) == null || getProperty("postProcess" + i).trim().equals("")); i++) {
			String sqlPostProcess = getProperty("postProcess" + i);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$CurrentMonth}", currentMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$LastMonth}", lastMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$NextMonth}", nextMonth);
			sqlPostProcess=StringFunction.replace(sqlPostProcess,"{$ReportDate}", deductDate);
			logger.info(sqlPostProcess);
			stmt.execute(sqlPostProcess);
		}
		stmt.close();
	}

	// �ͷ����ݿ���Դ
	protected void clearResource() {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				logger.error("stmt.close()", e);
			}
		}
		stmt = null;
		
		if (pstmInsert != null) {
			try {
				pstmInsert.close();
			} catch (SQLException e) {
				logger.error("pstmInsert.close()", e);
			}
		}
		pstmInsert = null;
		
		if (importResultSet != null) {
			try {
				importResultSet.close();
			} catch (SQLException e) {
				logger.error(e);
			}
			importResultSet = null;
		}
		if (reader != null) {
			reader.close();
		}
		reader = null;
		
		super.clearResource();
	}
}
