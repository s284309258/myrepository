package com.amarsoft.app.datax.gci.deductdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.DateTools;



public class AutoFXCheck extends CommonExecuteUnit {


	private int icount = 0;
	private int iSerialCount = 0;

	public int execute() {
		try{
	           String sInit = super.init();
	           if (sInit.equalsIgnoreCase("skip")) {
	              return TaskConstants.ES_SUCCESSFUL;
	           } else {
					String sDate = DateTools.getStringDate(deductDate);
	        	   String sChangeSerialNoHead = "HP"+sDate;
	              Long l1=System.currentTimeMillis();
	              /**ÿ����ռ����������*/									
					String delSql11=" delete from fxcheck_info where  createdate='"+deductDate+"' and watchmethod='1'";
					String delSql21=" delete from flow_task where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where watchmethod='1' and CreateDate='"+deductDate+"')";
					String delSql31=" delete from flow_object where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where  watchmethod='1' and CreateDate='"+deductDate+"') ";
					logger.info("��ʼ��ս��������������.....");
					
					PreparedStatement psDeleteData21 = connection.prepareStatement(delSql21);
					psDeleteData21.execute();
					psDeleteData21.close();
					PreparedStatement psDeleteData31 = connection.prepareStatement(delSql31);
					psDeleteData31.execute();
					psDeleteData31.close();
					PreparedStatement psDeleteData11 = connection.prepareStatement(delSql11);
					psDeleteData11.execute();
					psDeleteData11.close();
					logger.info("��ս�����������������! ");
	              
	              logger.info("��ʼÿ����ռ����������������");
	              insertDay();
	              logger.info("���ÿ����ռ����������������");

	              /**ÿ�µ��Զ�Ԥ����������*/
	              if (deductDate.equals(DateTools.getEndDateOfMonth(deductDate))) {
	              	String delSql12=" delete from fxcheck_info where serialno like '"+sChangeSerialNoHead+"%' and watchmethod='2' and CreateDate='"+deductDate+"'";
					String delSql22=" delete from flow_task where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where  watchmethod='2' and CreateDate='"+deductDate+"') ";
					String delSql32=" delete from flow_object where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where  watchmethod='2' and CreateDate='"+deductDate+"') ";
					logger.info("��ʼ���ÿ�������������.....");
					PreparedStatement psDeleteData12 = connection.prepareStatement(delSql12);
					PreparedStatement psDeleteData22 = connection.prepareStatement(delSql22);
					PreparedStatement psDeleteData32 = connection.prepareStatement(delSql32);
					psDeleteData22.execute();
					psDeleteData32.execute();
					psDeleteData12.execute();

					logger.info("���ÿ����������������! ");
					psDeleteData22.close();
					psDeleteData32.close();
					psDeleteData12.close();

	            	  logger.info("��ʼÿ�µ׷��ռ����������������");
	                  insertMonth();
	                  logger.info("���ÿ�µ׷��ռ����������������");
	              }
	              /**���ס�1�µף�4�µף�7�µף�10�µס����ռ����������*/
	                  if (deductDate.equals(DateTools.getEndDateOfMonth(deductDate))&&deductDate.substring(5,7).matches("01|04|07|10")) {
	                  String delSql13=" delete from fxcheck_info where serialno in (select serialno from fxcheck_info where  watchmethod='3' and CreateDate='"+deductDate+"') ";
						String delSql23=" delete from flow_task where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where watchmethod='3' and CreateDate='"+deductDate+"') ";
						String delSql33=" delete from flow_object where  objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where  watchmethod='3' and CreateDate='"+deductDate+"') ";
						logger.info("��ʼ���ÿ�������������.....");
						PreparedStatement psDeleteData13 = connection.prepareStatement(delSql13);
						PreparedStatement psDeleteData23 = connection.prepareStatement(delSql23);
						PreparedStatement psDeleteData33 = connection.prepareStatement(delSql33);
						psDeleteData23.execute();
						psDeleteData33.execute();
						psDeleteData13.execute();
						logger.info("���ÿ����������������! ");
						psDeleteData23.close();
						psDeleteData33.close();
						psDeleteData13.close();
	            	  logger.info("��ʼ���ס�1�µף�4�µף�7�µף�10�µס����ռ����������������");
	                  insertSeason();
	                  insertCheck();
	                  logger.info("��ɼ��ס�1�µף�4�µף�7�µף�10�µס����ռ����������������");
	                  }
	            //------------------ÿ��----------------------------------------------------------------------------------
		              if (deductDate.equals(DateTools.getEndDateOfMonth(deductDate))&&deductDate.substring(5,7).matches("12")) {	            	  
		            	 
	                  String delSql14=" delete from fxcheck_info where serialno in (select serialno from fxcheck_info where watchmethod='4' and CreateDate='"+deductDate+"') ";
						
	                  String delSql24="delete from flow_task where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where watchmethod='4' and CreateDate='"+deductDate+"') ";
						System.out.println(delSql24);
	                  String delSql34=" delete from flow_object where objecttype='FXCheckType' and objectno in (select serialno from fxcheck_info where watchmethod='4' and CreateDate='"+deductDate+"') ";
						logger.info("��ʼ��ս��������������.....");
						PreparedStatement psDeleteData24 = connection.prepareStatement(delSql24);
						PreparedStatement psDeleteData34 = connection.prepareStatement(delSql34);
						PreparedStatement psDeleteData14 = connection.prepareStatement(delSql14);
						psDeleteData24.execute();
						psDeleteData34.execute();
						psDeleteData14.execute();
						logger.info("��ս�����������������! ");
						psDeleteData24.close();
						psDeleteData34.close();
						psDeleteData14.close();
	                  logger.info("��ʼ��ס�12�¡����ռ����������������");
	                  insertYear();
	                  logger.info("�����ס�12�¡����ռ����������������");
		              }

	              System.out.println("ִ��ʱ��:"+(System.currentTimeMillis()-l1)/1000+"s");
	              unitStatus = TaskConstants.ES_SUCCESSFUL;
	              clearResource();
	               return unitStatus;
	           }

			}
		catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
		/*finally{s
			clearResource()
			return unitStatus;
		}*/
	}
	//--------------------------------------�������ݿ�-----------------------------------------------------------------------------------------------
	private void insertMonth() throws Exception
	{
			//�ͻ����
		// System.out.println("insertMonth");
			String Sql1="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,CREATEDATE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEORG)values(?,?,?,?,'010','010','2','1',? ) ";
			PreparedStatement psSql1 = connection.prepareStatement(Sql1);
			String SqlInsertFT = "insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,relativeserialno) " +
					" values(?,'FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?,?)";
			PreparedStatement psFTSql = connection.prepareStatement(SqlInsertFT);
			String sqlInsertFO = "insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,Inputdate) " +
					" values ('FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?)";
			PreparedStatement psFOSql = connection.prepareStatement(sqlInsertFO);

			
		String customerid="",customername="",orgid="";
		String selectSql = " select distinct bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.usebalance,bc.vouchtype,bc.relativeserialno,bc.operateuserid,bc.operateorgid from business_contract bc,loan_balance lb,loanbalance_relative lr "+
						   " where bc.serialno=lb.contractserialno and lb.putoutno=lr.putoutno " +
						   "and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1'  " +
						   "and (((select sum(usebalance) from business_contract where businesskind='SWPM' and customerid=bc.customerid and operateorgid=bc.operateorgid )>8000000 and bc.businesstype<>'2110100010') "+
						   "or (lr.overdays>30 and bc.usebalance>1000000) "+
						   "or (bc.occurtype='030'))";
		PreparedStatement psTempSql = connection.prepareStatement(selectSql);
		ResultSet rsSN = psTempSql.executeQuery();

		while(rsSN.next())
		{   
			customerid = DataConvert.toString(rsSN.getString("customerid"));
			customername = DataConvert.toString(rsSN.getString("customername"));
			orgid=DataConvert.toString("operateorgid");
			
			String Serialno= createSerialNo();
		//	System.out.println("ÿ�¿ͻ���"+Serialno);

			psSql1.setString(1,Serialno);	
			psSql1.setString(2,customerid);
			psSql1.setString(3,customername);
			psSql1.setString(4,deductDate);
			psSql1.setString(5,orgid);
			psSql1.addBatch();
			String Serialno2= createSerialNo();	
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount>=500){
				psSql1.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount=0;
				}
			icount++;
			}
			
			rsSN.close();
			psTempSql.close();
			psSql1.executeBatch();
			psSql1.close();
			psFTSql.executeBatch();
			psFTSql.close();
			psFOSql.executeBatch();
			psFOSql.close();
}	
	//------------------------------------------------------����ִ������-----------------------------------------------------
	private void insertSeason() throws Exception{
	//	 System.out.println("insertSeason");

		//����
		String serialNo="",customerid="",customername="",businesstype="",vouchtype="",userid="",orgid="",telphone="",familyadd="",posionlevel="";
		double usebalance=0.0;
		//�ͻ����
		String Sql1="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,CREATEDATE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,'010','010','3','1',?,?,?,? ) ";
		PreparedStatement psSql1 = connection.prepareStatement(Sql1);
		//Ϊ���Ȩ֤���
		String Sql5="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATEDATE,BALANCE,GUARANTEETYPE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,?,?,?,?,'010','010','3','5',?,?,?,?,? )  ";
		PreparedStatement psSql5 = connection.prepareStatement(Sql5);
		//ѺƷ���
		String Sql6="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATEDATE,BALANCE,GUARANTEETYPE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,? ,?,?,?,'010','010','3','6',?,?,?,?,? )  ";
		PreparedStatement psSql6 = connection.prepareStatement(Sql6);
		//�������̱�FT
		String SqlInsertFT = "insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,relativeserialno) " +
		" values(?,'FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?,?)";
		PreparedStatement psFTSql = connection.prepareStatement(SqlInsertFT);
		//����FO
		String sqlInsertFO = "insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,Inputdate) " +
		" values ('FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?)";
		PreparedStatement psFOSql = connection.prepareStatement(sqlInsertFO);

			
		
		/*
		 * �������������300��Ԫ��������800��Ԫ֮��ķǱ�׼ס����Ѻ�����ſͻ���
		 *�������û�֤����������ʽ�Ŀͻ��� 
		 *��CLTV��Ѻ�ʣ�CLTV=����ҵ�����/����ѺƷ������ֵ������ͻ�����Ѻ�ʳ���80%��סլ����������Ѻ�����Ѻ�ʳ���60%����ס�������÷���Ѻ�����Ѻ�ʳ���50%�ı�׼��������Ѻ����� 
		 * һ��ȼ�ҵ��Ŀͻ�
		 *�ǵͷ�����Ѻ�����ſͻ����ͷ�����Ѻ��100%�浥��Ѻ��100%��֤����Ѻ����
		 */
		String selectSql = " select distinct bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.usebalance,bc.vouchtype,bc.relativeserialno,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone "+
		" from business_contract bc,guaranty_info gi,guaranty_relative gr customer_work ck,customer_finance cf "+
		"where bc.serialno = gr.objectno and gr.guarantyid=gi.guarantyid and cw.customerid=cf.customerid and bc.customerid=cw.customerid " +
		"and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1'  " +
		" and gr.objecttype like 'SW%' "+ 
		"and  (( (select sum(usebalance) from business_contract where businesskind='SWPM' and customerid=bc.customerid and operateorgid=bc.operateorgid )<8000000 " +
		"and  (select sum(usebalance) from business_contract where businesskind='SWPM' and customerid=bc.customerid and operateorgid=bc.operateorgid )>3000000 " +
		"and bc.businesstype<>'2110100010' ) "+
		"or (bc.vouchtype  in ('010','030') ) " +
		"or (bc.occurtype in ('020','030')) "+
		"or (gi.guarantytype in ('010010','030010')) "+
		"or((bc.usebalance/gi.reevaluatevalue>0.8 and bc.businesstype='2110100030' ) "+
		"or (bc.businesstype='2110100020' and bc.usebalance/gi.reevaluatevalue>0.6) )) ";
		
		PreparedStatement psTempSql = connection.prepareStatement(selectSql);
		ResultSet rsSN = psTempSql.executeQuery();
		while(rsSN.next()){
			serialNo = DataConvert.toString(rsSN.getString("serialno"));
			customerid = DataConvert.toString(rsSN.getString("customerid"));
			customername = DataConvert.toString(rsSN.getString("customername"));
			businesstype = DataConvert.toString(rsSN.getString("businesstype"));
			usebalance=DataConvert.toDouble(rsSN.getString("usebalance"));
			vouchtype=DataConvert.toString(rsSN.getString("vouchtype"));
			userid=DataConvert.toString(rsSN.getString("operateuserid"));
			orgid=DataConvert.toString(rsSN.getString("operateorgid"));
			telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
			familyadd=DataConvert.toString(rsSN.getString("familyadd"));
			posionlevel=DataConvert.toString(rsSN.getString("offical"));
			String Serialno= createSerialNo();
		//	System.out.println("ÿ���ͻ���"+Serialno);

			psSql1.setString(1,Serialno);	
			psSql1.setString(2,customerid);
			psSql1.setString(3,customername);
			psSql1.setDouble(4, usebalance);
			psSql1.setString(5,orgid);
			psSql1.setString(6,posionlevel);
			psSql1.setString(7,familyadd);
			psSql1.setString(8,telphone);
			psSql1.addBatch();
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount>=300){
				psSql1.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount = 0;
				}
			icount++;
		}
		rsSN.close();
		psTempSql.close();
		psSql1.executeBatch();
		psSql1.close();
		psFTSql.executeBatch();
	//	psFTSql.close();
		psFOSql.executeBatch();
	//	psFOSql.close();

		
			
	
//------------------------------------------------------------------����-----------------------------------------------------------------------------			
		
		//-----------------------------δ����Ѻ���	-------------------------------------------------------------

		String selectSq2 = " select distinct bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.usebalance,bc.vouchtype,bc.relativeserialno,bc.operateuserid,bc.operateorgid,,cw.posionlevel,cf.familyadd,cf.mobiletelephone "+
		" from business_contract bc,guaranty_relative gr,guaranty_info gi,loan_balance lb, customer_work cw,customer_finance cf" +
		" where bc.serialno=gr.objectno and gr.guarantyid=gi.guarantyid and bc.serialno=lb.contractserialno and cw.customerid=cf.customerid and bc.customerid=cw.customerid" +
		"and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1' " +
		" and gr.objecttype like 'SW%'"+
		" and (gi.status ='01' or gi.status is null) " ;
		PreparedStatement psTempSq2 = connection.prepareStatement(selectSq2);
		ResultSet rsSNG = psTempSq2.executeQuery();
		while(rsSNG.next()){
			serialNo = DataConvert.toString(rsSNG.getString("serialno"));

			customerid = DataConvert.toString(rsSNG.getString("customerid"));
			customername = DataConvert.toString(rsSNG.getString("customername"));
			businesstype = DataConvert.toString(rsSNG.getString("businesstype"));
			usebalance=DataConvert.toDouble(rsSNG.getString("usebalance"));
			vouchtype=DataConvert.toString(rsSNG.getString("vouchtype"));
			userid=DataConvert.toString(rsSNG.getString("operateuserid"));
			orgid=DataConvert.toString(rsSNG.getString("operateorgid"));
			telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
			familyadd=DataConvert.toString(rsSN.getString("familyadd"));
			posionlevel=DataConvert.toString(rsSN.getString("offical"));

			String Serialno= createSerialNo();
		//	System.out.println("δ���Ȩ֤��"+Serialno);

			psSql5.setString(1,Serialno);	
			psSql5.setString(2,customerid);
			psSql5.setString(3,customername);
			psSql5.setString(4,businesstype);
			psSql5.setString(5,serialNo);
			psSql5.setString(6,deductDate);
			psSql5.setDouble(7, usebalance);
			psSql5.setString(8,vouchtype);
			psSql5.setString(9,userid);
			psSql5.setString(10,orgid);
			psSql5.setString(11,posionlevel);
			psSql5.setString(12,familyadd);
			psSql5.setString(13,telphone);
			psSql5.addBatch();
		
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount==300){
				psSql6.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount = 0;
				}
			icount++;
		} 
		rsSNG.close();
		psTempSq2.close();
		psSql5.executeBatch();
		psSql5.close();
		if(psFTSql!=null&&psFOSql!=null){
		psFTSql.executeBatch();
	//	psFTSql.close();
		psFOSql.executeBatch();
		//psFOSql.close();
		}
		//-----------------------------ѺƷ��ֵ������-------------------------------------------------------------
		String selectSql3="select distinct bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.usebalance,bc.vouchtype,bc.relativeserialno,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone" +
				" from business_contract bc,guaranty_relative gr,guaranty_change gc,customer_work cw,customer_finance cf  "+
		"where bc.serialno=gr.objectno and gr.guarantyid=gc.guarantyid and cw.customerid=cf.customerid and bc.customerid=cw.customerid" +
		"and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1' " +
		" and gr.objecttype like 'SW%'"+
		"and ((gc.inputconfirmvalue is not null and gc.inputconfirmvalue <>gc.oldconfirmvalue) "+
		"or (gc.inputconfirmvalue is null and gc.newconfirmvalue<>gc.oldconfirmvalue)) " ;
		PreparedStatement psTempSq3 = connection.prepareStatement(selectSql3);
		ResultSet rsSNC = psTempSq3.executeQuery();
			int count=rsSNC.getRow();
			createRand(count,0.2);
			int i = 0;
		while(rsSNC.next()){
			if(!isRan(i++))continue;
			serialNo = DataConvert.toString(rsSNC.getString("serialno"));

			customerid = DataConvert.toString(rsSNC.getString("customerid"));
			customername = DataConvert.toString(rsSNC.getString("customername"));
			businesstype = DataConvert.toString(rsSNC.getString("businesstype"));
			usebalance=DataConvert.toDouble(rsSNC.getString("usebalance"));
			vouchtype=DataConvert.toString(rsSNC.getString("vouchtype"));
			userid=DataConvert.toString(rsSNC.getString("operateuserid"));
			orgid=DataConvert.toString(rsSNC.getString("operateorgid"));
			telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
			familyadd=DataConvert.toString(rsSN.getString("familyadd"));
			posionlevel=DataConvert.toString(rsSN.getString("offical"));
			String Serialno= createSerialNo();
		//	System.out.println("ѺƷ��ֵ�����"+Serialno);

			psSql6.setString(1,Serialno);	
			psSql6.setString(2,customerid);
			psSql6.setString(3,customername);
			psSql6.setString(4,businesstype);
			psSql6.setString(5,serialNo);
			psSql6.setString(6,deductDate);
			psSql6.setDouble(7, usebalance);
			psSql6.setString(8,vouchtype);
			psSql6.setString(9,userid);
			psSql6.setString(10,orgid);
			psSql6.setString(11,posionlevel);
			psSql6.setString(12,familyadd);
			psSql6.setString(13,telphone);
			psSql6.addBatch();

			
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount==300){
				psSql6.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount = 0;
				}
			icount++;
		}
		
			
		
			rsSNC.close();
			psTempSq3.close();
			psFTSql.executeBatch();
			psFTSql.close();
			psFOSql.close();
			psFOSql.executeBatch();
			psSql6.executeBatch();
			psSql6.close();
		
	}

	//-----------------------------------------------------����ִ������------------------------------------------------------
	private void insertYear() throws Exception{
		// System.out.println("insertYear");

		String serialNo="",customerid="",customername="",businesstype="",vouchtype="",userid="",orgid="",telphone="",familyadd="",posionlevel="";
		double usebalance=0.0;
		//����ͻ����
		String Sql1="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,CREATEDATE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,'010','010','4','1',?,?,?,? )  ";
		PreparedStatement psSql1 = connection.prepareStatement(Sql1);
		//Ŀ��ͻ�Ⱥ���
		String Sql2="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATEDATE,BALANCE,GUARANTEETYPE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,? ,?,?,?,'010','010','2','2',?,?,?,?,? )  ";
		PreparedStatement psSql2 = connection.prepareStatement(Sql2);
		//����������
		String Sql7=" Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATEDATE,BALANCE,GUARANTEETYPE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG,TELPHONE,OFFICAL,CONTCTADD)values(?,?,?,?,? ,?,?,?,'010','010','4','7',?,?,?,?,? )  ";
		PreparedStatement psSql7 = connection.prepareStatement(Sql7);
		//�������̱�FT
		String SqlInsertFT = "insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,relativeserialno) " +
		" values(?,'FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?,?)";
		PreparedStatement psFTSql = connection.prepareStatement(SqlInsertFT);
		//����FO
		String sqlInsertFO = "insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,Inputdate) " +
		" values ('FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?)";
		PreparedStatement psFOSql = connection.prepareStatement(sqlInsertFO);


		//�����������������������������������������������󡪡�������������������������������������������������������������
		String selectSql = " select  bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.occurtype,bc.vouchtype,bc.usebalance,bc.relativeserialno,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone "+
		   " from business_contract bc,customer_work cw,customer_finance cf where cw.customerid=cf.customerid and bc.customerid=cw.customerid and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1' and bc.putouttype in ('030','040') " ;
		PreparedStatement psTempSql = connection.prepareStatement(selectSql);
		ResultSet rsSN = psTempSql.executeQuery();
		while(rsSN.next())
		{   
			serialNo = DataConvert.toString(rsSN.getString("serialno"));
			customerid = DataConvert.toString(rsSN.getString("customerid"));
			customername = DataConvert.toString(rsSN.getString("customername"));
			businesstype = DataConvert.toString(rsSN.getString("businesstype"));
			usebalance=DataConvert.toDouble(rsSN.getString("usebalance"));
			vouchtype=DataConvert.toString(rsSN.getString("vouchtype"));
			userid=DataConvert.toString(rsSN.getString("operateuserid"));
			orgid=DataConvert.toString(rsSN.getString("operateorgid"));
			telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
			familyadd=DataConvert.toString(rsSN.getString("familyadd"));
			posionlevel=DataConvert.toString(rsSN.getString("offical"));
			String Serialno= createSerialNo();
		//	System.out.println("����"+Serialno);

			psSql7.setString(1,Serialno);	
			psSql7.setString(2,customerid);
			psSql7.setString(3,customername);
			psSql7.setString(4,businesstype);
			psSql7.setString(5,serialNo);
			psSql7.setString(6,deductDate);
			psSql7.setDouble(7, usebalance);
			psSql7.setString(8,vouchtype);
			psSql7.setString(9,userid);
			psSql7.setString(10,orgid);
			psSql7.setString(11,posionlevel);
			psSql7.setString(12,familyadd);
			psSql7.setString(13,telphone);
			psSql7.addBatch();
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount>=300){
			psSql7.executeBatch();
			psFTSql.executeBatch();
			psFOSql.executeBatch();
			icount=0;
			}
			icount++;
		}
			rsSN.close();
			psTempSql.close();
			psSql7.executeBatch();
			psSql7.close();
			psFTSql.executeBatch();
		//	psFTSql.close();
			psFOSql.executeBatch();
		//	psFOSql.close();
			
			
			
		//-----------------------����ִ�еĿͻ����--------------------------------------
				String selectSql2="select  bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.occurtype,bc.vouchtype,bc.usebalance,bc.relativeserialno,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone" +
						"from business_contract bc,customer_work cw,customer_finance cf where cw.customerid=cf.customerid and bc.customerid=cw.customerid " +
						"and bc.businesstype='2110100010' or ( (select sum(usebalance) from business_contract where businesskind='SWPM' and customerid=bc.customerid and operateorgid=bc.operateorgid )<3000000 " +
						"and bc.businesstype<>'2110100010') and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1' " ;
			PreparedStatement psTempSql2 = connection.prepareStatement(selectSql2);
			ResultSet rsSN2 = psTempSql2.executeQuery();
			while(rsSN2.next()){
				serialNo = DataConvert.toString(rsSN2.getString("serialno"));
				customerid = DataConvert.toString(rsSN2.getString("customerid"));
				customername = DataConvert.toString(rsSN2.getString("customername"));
				businesstype = DataConvert.toString(rsSN2.getString("businesstype"));
				usebalance=DataConvert.toDouble(rsSN2.getString("usebalance"));
				vouchtype=DataConvert.toString(rsSN2.getString("vouchtype"));
				userid=DataConvert.toString(rsSN2.getString("operateuserid"));
				orgid=DataConvert.toString(rsSN2.getString("operateorgid"));
				telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
				familyadd=DataConvert.toString(rsSN.getString("familyadd"));
				posionlevel=DataConvert.toString(rsSN.getString("offical"));
				String Serialno= createSerialNo();
			//	System.out.println("ÿ��ͻ�"+Serialno);

				psSql1.setString(1,Serialno);	
				psSql1.setString(2,customerid);
				psSql1.setString(3,customername);
				psSql1.setString(4,deductDate);
				psSql1.setString(5,orgid);
				psSql1.setString(6,posionlevel);
				psSql1.setString(7,familyadd);
				psSql1.setString(8,telphone);
				psSql1.addBatch();
				String Serialno2= createSerialNo();
				psFTSql.setString(1,Serialno2);
				psFTSql.setString(2,Serialno);
				psFTSql.setString(3,deductDate);
				psFTSql.setString(4,Serialno2);
				psFTSql.addBatch();
				
				psFOSql.setString(1,Serialno);
				psFOSql.setString(2,deductDate);
				psFOSql.addBatch();
				if(icount>=500){
				psSql1.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount=0;
				}
				icount++;
			}
			rsSN2.close();
			psTempSql2.close();
			psSql1.executeBatch();
			psSql1.close();
			psFTSql.executeBatch();
		//	psFTSql.close();
			psFOSql.executeBatch();
			//psFOSql.close();
				
			

//-----------------------------------------------------Ŀ��ͻ�Ⱥ���----------------------------------------------------------
				String selectSql3="select  bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.occurtype,bc.vouchtype,bc.usebalance,bc.relativeserialno,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone " +
						"from business_contract bc,customer_info ci, customer_work cw,customer_finance cf" +
						"where cw.customerid=cf.customerid and bc.customerid=cw.customerid " +
						" and bc.customerid=ci.customerid and ci.customertype like '07%' and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1' " ;
				PreparedStatement psTempSql3 = connection.prepareStatement(selectSql3);
				ResultSet rsSN3 = psTempSql3.executeQuery();
				while(rsSN3.next()){
					serialNo = DataConvert.toString(rsSN3.getString("serialno"));

					customerid = DataConvert.toString(rsSN3.getString("customerid"));
					customername = DataConvert.toString(rsSN3.getString("customername"));
					businesstype = DataConvert.toString(rsSN3.getString("businesstype"));
					usebalance=DataConvert.toDouble(rsSN3.getString("usebalance"));
					vouchtype=DataConvert.toString(rsSN3.getString("vouchtype"));
					userid=DataConvert.toString(rsSN3.getString("operateuserid"));
					orgid=DataConvert.toString(rsSN3.getString("operateorgid"));
					telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
					familyadd=DataConvert.toString(rsSN.getString("familyadd"));
					posionlevel=DataConvert.toString(rsSN.getString("offical"));
					String Serialno= createSerialNo();
				//	System.out.println("Ŀ��ͻ�Ⱥ��"+Serialno);

					psSql2.setString(1,Serialno);	
					psSql2.setString(2,customerid);
					psSql2.setString(3,customername);
					psSql2.setString(4,businesstype);
					psSql2.setString(5,serialNo);
					psSql2.setString(6,deductDate);
					psSql2.setDouble(7, usebalance);
					psSql2.setString(8,vouchtype);
					psSql2.setString(9,userid);
					psSql2.setString(10,orgid);
					psSql2.setString(11,posionlevel);
					psSql2.setString(12,familyadd);
					psSql2.setString(13,telphone);
					psSql2.addBatch();
				//	System.out.println("Ŀ��ͻ�Ⱥ"+Serialno);
					String Serialno2= createSerialNo();
					psFTSql.setString(1,Serialno2);
					psFTSql.setString(2,Serialno);
					psFTSql.setString(3,deductDate);
					psFTSql.setString(4,Serialno2);
					psFTSql.addBatch();
					
					psFOSql.setString(1,Serialno);
					psFOSql.setString(2,deductDate);
					psFOSql.addBatch();
					if(icount>=500){
						psSql2.executeBatch();
						psFTSql.executeBatch();
						psFOSql.executeBatch();
						icount=0;
						}
					icount++;
				}
			
			
				
				
				rsSN3.close();
				psTempSql3.close();
				psSql2.executeBatch();
				psSql2.close();
				psFTSql.executeBatch();
				psFTSql.close();
				psFOSql.executeBatch();
				psFOSql.close();
	}
	
//-------------------------------------------------------ÿ��ִ������------------------------------------------------------------------	
		private void insertDay() throws Exception{
			// System.out.println("insertDay");

			String serialNo="",customerid="",customername="",businesstype="",vouchtype="",objectno="",userid="",orgid="",telphone="",familyadd="",posionlevel="";
			double usebalance=0.0;
		//-------------------------------------�ʽ���;���-----------------------------------------------------
//			String Sql3="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING)values(?,?,?,?,? ,'010','010','1','3' ) ";
//			PreparedStatement psSql3 = connection.prepareStatement(Sql3);
			String Sql4="Insert into FXCHECK_INFO(SERIALNO,CUSTOMERNO,CUSTOMERNAME,BUSINESSTYPE,CONTRACTNO,CREATEDATE,BALANCE,GUARANTEETYPE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG,cw.posionlevel,cf.familyadd,cf.mobiletelephone)values(?,?,?,?,? ,?,?,?,'010','010','1','4',?,?,?,?,? )  ";
			PreparedStatement psSql4 = connection.prepareStatement(Sql4);
			//�������̱�FT
			String SqlInsertFT = "insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,relativeserialno) " +
			" values(?,'FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?,?)";
			PreparedStatement psFTSql = connection.prepareStatement(SqlInsertFT);
			//����FO
			String sqlInsertFO = "insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,Inputdate) " +
			" values ('FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?)";
			PreparedStatement psFOSql = connection.prepareStatement(sqlInsertFO);

		//ȡ��ͬ��Ϣ
		String selectSql = " select  bc.serialno, bc.customerid, bc.customername,bc.businesstype,bc.occurtype,bc.vouchtype,bc.usebalance,bc.operateuserid,bc.operateorgid,cw.posionlevel,cf.familyadd,cf.mobiletelephone "+
		" from business_contract bc, loan_balance lb,customer_work cw,customer_finance cf "+
		"where cw.customerid=cf.customerid and bc.customerid=cw.customerid and bc.serialno=lb.contractserialno  and lb.putoutdate='"+lastDate+"'  and bc.businesskind='SWPM' and bc.businesstype like '2%' and bc.freezeflag='1'" ;
		PreparedStatement psTempSql = connection.prepareStatement(selectSql);
		ResultSet rsSN = psTempSql.executeQuery();
	
		while(rsSN.next())
		{   
			serialNo = DataConvert.toString(rsSN.getString("serialno"));

			customerid = DataConvert.toString(rsSN.getString("customerid"));
			customername = DataConvert.toString(rsSN.getString("customername"));
			businesstype = DataConvert.toString(rsSN.getString("businesstype"));
			usebalance=DataConvert.toDouble(rsSN.getString("usebalance"));
			vouchtype=DataConvert.toString(rsSN.getString("vouchtype"));
			userid=DataConvert.toString(rsSN.getString("operateuserid"));
			orgid=DataConvert.toString(rsSN.getString("operateorgid"));	
			telphone=DataConvert.toString(rsSN.getString("mobiletelephone"));
			familyadd=DataConvert.toString(rsSN.getString("familyadd"));
			posionlevel=DataConvert.toString(rsSN.getString("offical"));
			String Serialno= createSerialNo();
			//System.out.println("���ż�⣺"+Serialno);

			
			psSql4.setString(1,Serialno);	
			psSql4.setString(2,customerid);
			psSql4.setString(3,customername);
			psSql4.setString(4,businesstype);
			psSql4.setString(5,serialNo);
			psSql4.setString(6,deductDate);
			psSql4.setDouble(7, usebalance);
			psSql4.setString(8,vouchtype);
			psSql4.setString(9,userid);
			psSql4.setString(10,orgid);
			psSql4.setString(11,posionlevel);
			psSql4.setString(12,familyadd);
			psSql4.setString(13,telphone);
			psSql4.addBatch();

			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount>=500){
				psSql4.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount=0;
				}
			icount++;

		}
		rsSN.close();
		psTempSql.close();
		psSql4.executeBatch();
		psSql4.close();
		psFTSql.executeBatch();
		//psFTSql.close();
		psFOSql.executeBatch();
	//	psFOSql.close();
	
		//------------------------------------------------�ӷ���Ԥ���е���-----------------------------------------------
		String selectSql2 ="select rs.serialno,rs.inputuserid,rs.inputorgid from risk_signal rs Where rs.actiontype Like '%@1@%' And rs.signalstatus = '20'";
		PreparedStatement psTempSq2 = connection.prepareStatement(selectSql2);
		ResultSet rsSN2 = psTempSq2.executeQuery();
			String Sql3="Insert into FXCHECK_INFO(SERIALNO,RISKNO,CREATEDATE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG)values(?,?,?,'010','030','1','3',?,? ) ";
			PreparedStatement psSql3 = connection.prepareStatement(Sql3);
	
		while(rsSN2.next()){
			//if(!isRan(i++))continue;
			objectno=DataConvert.toString(rsSN2.getString("serialno"));
			userid=DataConvert.toString(rsSN2.getString("inputuserid"));
			orgid=DataConvert.toString(rsSN2.getString("inputorgid"));
			String Serialno= createSerialNo();
		//	System.out.println("����Ԥ����"+Serialno);

			psSql3.setString(1,Serialno);
			psSql3.setString(2,objectno);
			psSql3.setString(3,deductDate);
			psSql3.setString(4,userid);
			psSql3.setString(5,orgid);
			psSql3.addBatch();
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			
			if(icount>=500){
				psSql3.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount=0;
				}
			icount++;
		}
			rsSN2.close();
			psTempSq2.close();
			psTempSq2.close();
			psSql3.executeBatch();
			psSql3.close();
		
			psFTSql.executeBatch();
			psFTSql.close();
			psFOSql.executeBatch();
			psFOSql.close();		
			}

		//----------------------------------------------------------------˾����������---------------------------------------------------------------------------
	private void insertCheck() throws Exception{
		// System.out.println("insertCheck");

//		out
		String RiskNo="",userid="",orgid="";
		//���ż�¼
		String Sql8="Insert into FXCHECK_INFO(SERIALNO,RiskNo,CREATEDATE,CREATESTATE,CREATEMETHOD,WATCHMETHOD,WATCHTHING,CREATEUSER,CREATEORG)values(?,?,?,'010','010','3','8',?,? ) ";
		PreparedStatement psSql8 = connection.prepareStatement(Sql8);
		//�������̱�FT
		String SqlInsertFT = "insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,relativeserialno) " +
		" values(?,'FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?,?)";
		PreparedStatement psFTSql = connection.prepareStatement(SqlInsertFT);
		//����FO
		String sqlInsertFO = "insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,inputdate) " +
		" values ('FXCheckType',?,'010010','FXCheckApply','FXCheckFlow','�˹����ռ����������','0010','������','1','OPS','OPS','ƽ������',?)";
		PreparedStatement psFOSql = connection.prepareStatement(sqlInsertFO);
		
		String selectSql = "select ci.customerid,ci.customername,rs.objectno,rs.inputuserid,rs.inputorgid from customer_info ci,risk_signal rs where rs.signalchannel='auto' and ci.customerid=rs.objectno " ;
		PreparedStatement psTempSql = connection.prepareStatement(selectSql);		
		ResultSet rsSN = psTempSql.executeQuery();

		while(rsSN.next()){
			//if(!isRan(i++))continue;
			RiskNo= DataConvert.toString(rsSN.getString("RiskNo"));
			userid= DataConvert.toString(rsSN.getString("inputuserid"));
			orgid= DataConvert.toString(rsSN.getString("inputorgid"));
			String Serialno= createSerialNo();
		//	System.out.println("˾�����룺"+Serialno);

			psSql8.setString(1,Serialno);	
			psSql8.setString(2,RiskNo);
			psSql8.setString(3,deductDate);
			psSql8.setString(4,userid);
			psSql8.setString(5,orgid);
			
			psSql8.addBatch();
			String Serialno2= createSerialNo();
			psFTSql.setString(1,Serialno2);
			psFTSql.setString(2,Serialno);
			psFTSql.setString(3,deductDate);
			psFTSql.setString(4,Serialno2);
			psFTSql.addBatch();
			
			psFOSql.setString(1,Serialno);
			psFOSql.setString(2,deductDate);
			psFOSql.addBatch();
			if(icount>=500){
				psSql8.executeBatch();
				psFTSql.executeBatch();
				psFOSql.executeBatch();
				icount=0;
				}
			icount++;
		}
			rsSN.close();
			psTempSql.close();
			psSql8.executeBatch();
			psSql8.close();
			psFTSql.executeBatch();
			psFTSql.close();
			psFOSql.executeBatch();
			psFOSql.close();
			
	}

	//----------------------------------------------ȡ�����-----------------------------------------------------
   static int[] ran;
    static boolean reversal = false;
    static int arrayL = 1000;
    private static int[] createRand(int countA,double probability) throws Exception{
    if(probability<0)probability = 0;
    if(probability>1)probability = 1;
    if(probability>0.5){
        probability = 1-probability;
        reversal = true;
    }
    if(countA>arrayL)countA = arrayL;
    int count = (int)(countA*probability);
    ran = new int[count];
       for(int i=0;i<ran.length;i++){
          ran[i] = (int)(countA*Math.random());
          for(int j=0;j<i;j++){
              if(ran[i] == ran[j]){
                 i--;
                 break;
              }
          }
       }
       return ran;
   }
    private static boolean isRan(int p) throws Exception{
    boolean boo = false;
    for(int i=0;i<ran.length;i++){
        if(p%arrayL == ran[i]){
            boo = true;
            break;
        }
       }
    if(reversal)
        boo = !boo;
       return boo;
   }


    public String createSerialNo() throws Exception {
		iSerialCount++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = "00000000"+iSerialCount;
		String Re = "HP";
		return Re + sDate + sSortNo;
	}
}



