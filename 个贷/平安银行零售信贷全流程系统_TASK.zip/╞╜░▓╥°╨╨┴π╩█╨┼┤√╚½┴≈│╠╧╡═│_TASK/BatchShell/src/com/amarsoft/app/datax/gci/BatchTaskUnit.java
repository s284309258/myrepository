package com.amarsoft.app.datax.gci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.log.Log;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.Task;
import com.amarsoft.task.TaskBuilder;

public class BatchTaskUnit extends ExecAbstract{
	
	public synchronized void run(){
		
		String are = "etc/are.xml";
		String task_batch = "../sys-config/batch_task.xml";
		String task_deduct = "../sys-config/deduct_task.xml";
		String task_of = "../sys-config/of_pre.xml";
		String task_rushpayone = "../sys-config/rushpayone_task.xml";
		String task_rushpaytwo = "../sys-config/rushpaytwo_task.xml";

		long lInterval = this.ti.getInterval();
	
        ARE.init(are);
        
        Log logger = ARE.getLog();
        Connection connection = null;
        try {
        	DBConnection dc = new DBConnection();
			connection =dc.getConn("Loan");
			updateBatchFlag(lInterval,connection);
			updateDeductFlag(lInterval,connection);
			
			String sOFPreFlag = "0";
		    String sBatchDealFlag = "0";
		    String sDeductDealFlag="0";
		    String sRushPayOneFlag = "0";
		    String sRushPayTwoFlag = "0";
		    String selectSql = " select OFPreFlag,BatchDealFlag,RushPayOneFlag,RushPayTwoFlag,DeductDealFlag from ploan_setup ";
		    PreparedStatement psInserSql = connection.prepareStatement(selectSql);
			ResultSet rs = psInserSql.executeQuery();
			if(rs.next())
			{
				sOFPreFlag = rs.getString("OFPreFlag");
				sBatchDealFlag = rs.getString("BatchDealFlag");
				sDeductDealFlag = rs.getString("DeductDealFlag");
				sRushPayOneFlag = rs.getString("RushPayOneFlag");
				sRushPayTwoFlag = rs.getString("RushPayTwoFlag");
			}
			rs.close();
			psInserSql.close();
			
			
			//�Ϻ�������廹��One
			if("1".equals(sRushPayOneFlag) && !"1".equals(sBatchDealFlag)&&!"1".equals(sDeductDealFlag))
			{
				logger.info("�Ϻ�������廹����һ��ִ��.....");
				execute(task_rushpayone);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
				return;
			}
			
			//�Ϻ�������廹��Two
			if("1".equals(sRushPayTwoFlag) && !"1".equals(sBatchDealFlag)&&!"1".equals(sDeductDealFlag))
			{
				logger.info("�Ϻ�������廹���ڶ���ִ��.....");
				execute(task_rushpaytwo);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
				return;
			}
			
			logger.info("̽������������־.....");
			if(sOFPreFlag.equals("1")){
				logger.info("��ʼִ��OFԤ��������");
				logger.info("����ϴ�Ԥ���ۼ�¼.....");
				String delLastSource = " delete from batchtask_status where TargetName = 'Of_pre' and DateFlag = '1' ";
				logger.info("sql = "+delLastSource);
				PreparedStatement psDelLastSourceSql =connection.prepareStatement(delLastSource);
				psDelLastSourceSql.execute();
				psDelLastSourceSql.close();
				logger.info("����ϴ�Ԥ���ۼ�¼��ɣ�");
				execute(task_of);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
			}
				
			if("1".equals(sBatchDealFlag) && !"1".equals(sRushPayOneFlag) && !"1".equals(sRushPayTwoFlag)&&!"1".equals(sDeductDealFlag)){
				logger.info("��ʼִ���ռ���������");
				execute(task_batch);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
			}
			
			if("1".equals(sDeductDealFlag) && !"1".equals(sRushPayOneFlag) && !"1".equals(sRushPayTwoFlag)&&!"1".equals(sBatchDealFlag)){
				logger.info("��ʼִ�����տۿ�����");
				execute(task_deduct);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
			}
			
		}
        catch (Exception e) {
        	logger.error("�������󣡴�����Ϣ��"+e.getMessage());
			e.printStackTrace();
		}
        finally
        {
        	clearResource(connection);
        }
	}

	//add by dxu ,�����º���esb����
	private void executeEsbFlag(Connection connection ) throws Exception {
		// TODO Auto-generated method stub
		OCIConfig.initEsbFlag(connection);
	}

	private void execute(String s) throws Exception
	{
		//String taskFile = ARE.getProperty();
		ARE.getLog().fatal("taskFile="+s);
		
		OCIConfig.loadOCIConfig(true);
		OCIConfig.setEnvironment("Cycle");
		OCIConfig.setDataSourceName("Loan");
		//OCIConfig.setEnvironment("Batch");
		//OCIConfig.setDataSourceName("ploan");
		Task task = TaskBuilder.buildTaskFromXML(s);
		if (task != null) {
			task.start();
		}
		else
			ARE.getLog().fatal("��������ʧ�ܣ�");

	}
	
	private void clearResource(Connection connection) {
		// �ر����ݿ�����
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				ARE.getLog().warn(e);
			}
			connection = null;
		}
	}
	
	/*
	 * �����ǰʱ��ﵽ������ִ��ʱ�䣬���±�ploan_setup�е�����ִ�б�־
	 * */
	private void updateBatchFlag(long lInterval,Connection connection) throws Exception
	{
		String sBatchExexuteTime = "";
		String sNextBatchExecuteDate = "";
		String sBatchDealFlag="";
		String sDeductDealFlag="";
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String sDate = formatter.format(cal.getTime());
		
		String selectSql = " select BatchBeginTime,NextBatchExecuteDate,BatchDealFlag,DeductDealFlag from ploan_setup ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		if(rs.next())
		{
			sBatchExexuteTime=rs.getString("BatchBeginTime");
			sNextBatchExecuteDate = rs.getString("NextBatchExecuteDate");
			sBatchDealFlag = rs.getString("BatchDealFlag");
			sDeductDealFlag = rs.getString("DeductDealFlag");
		}
		rs.close();
		psSelectSql.close();
		
		if(sBatchExexuteTime==null || sBatchExexuteTime.length()==0)
			throw new Exception("ploan_setup������ִ��ʱ��δ���壡");
		if(sNextBatchExecuteDate==null || sNextBatchExecuteDate.length()==0)
			throw new Exception("ploan_setup���´�����ִ������δ���壡");
		
		String[] timeArray = sBatchExexuteTime.split(":");
		Calendar calendar = Calendar.getInstance();
		Calendar calendar1 = Calendar.getInstance();
		calendar.set(calendar.get(calendar.YEAR), calendar
				.get(calendar.MONTH), calendar.get(calendar.DATE), Integer
				.parseInt(timeArray[0]), Integer.parseInt(timeArray[1]),
				Integer.parseInt(timeArray[2]));
		
		if(calendar1.getTimeInMillis()>=calendar.getTimeInMillis() && sNextBatchExecuteDate.equals(sDate))
		{
			if("1".equals(sDeductDealFlag)){
				System.out.println("���տۿ����������У����ٴ����ճ�����");
			}else{
				String updateSql = " update ploan_setup set BatchDealFlag = '1' ";
				PreparedStatement psInserSql = connection.prepareStatement(updateSql);
				psInserSql.execute();
				psInserSql.close();
			}
		}
		
	}
	
	private void updateDeductFlag(long lInterval,Connection connection) throws Exception
	{
		String sDeductBeginTime = "";
		String sNextDeductExecuteDate = "";
		String sBatchDealFlag="";
		String sDeductDealFlag="";
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String sDate = formatter.format(cal.getTime());
		
		String selectSql = " select DeductBeginTime,NextDeductExecuteDate,BatchDealFlag,DeductDealFlag from ploan_setup ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		if(rs.next())
		{
			sDeductBeginTime = rs.getString("DeductBeginTime");
			sNextDeductExecuteDate = rs.getString("NextDeductExecuteDate");
			sBatchDealFlag = rs.getString("BatchDealFlag");
			sDeductDealFlag = rs.getString("DeductDealFlag");
		}
		rs.close();
		psSelectSql.close();
		
		if(sDeductBeginTime==null || sDeductBeginTime.length()==0)
			throw new Exception("ploan_setup��������������ִ��ʱ��δ���壡");
		if(sNextDeductExecuteDate==null || sNextDeductExecuteDate.length()==0)
			throw new Exception("ploan_setup���´�������������ִ������δ���壡");
		
		String[] timeArray = sDeductBeginTime.split(":");
		Calendar calendar = Calendar.getInstance();
		Calendar calendar1 = Calendar.getInstance();
		calendar.set(calendar.get(calendar.YEAR), calendar
				.get(calendar.MONTH), calendar.get(calendar.DATE), Integer
				.parseInt(timeArray[0]), Integer.parseInt(timeArray[1]),
				Integer.parseInt(timeArray[2]));
		
		if(calendar1.getTimeInMillis()>=calendar.getTimeInMillis() && sNextDeductExecuteDate.equals(sDate))
		{
			if("1".equals(sBatchDealFlag)){
				System.out.println("�ճ����������У����ٴ������տۿ�����");
			}else{
				String updateSql = " update ploan_setup set DeductDealFlag = '1' ";
				PreparedStatement psInserSql = connection.prepareStatement(updateSql);
				psInserSql.execute();
				psInserSql.close();
			}
		}
	}

}
