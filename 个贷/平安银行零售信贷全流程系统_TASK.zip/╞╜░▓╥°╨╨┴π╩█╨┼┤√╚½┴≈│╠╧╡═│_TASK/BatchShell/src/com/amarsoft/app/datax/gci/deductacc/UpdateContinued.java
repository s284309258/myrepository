package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;

public class UpdateContinued extends CommonExecuteUnit{

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int aheadDays =0;
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ���д��󱣵�״̬��������......");
				batchUpdateContinued();
				logger.info("һ������"+icount+"������");
				logger.info("���󱣵�״̬����������ɣ�");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void batchUpdateContinued() throws Exception
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		aheadDays = 0-Integer.parseInt(getProperty("aheadDays", "1")); 
		
		String updateSql = " Update guaranty_info set Continued = '0' where GuarantyID = ? ";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		String sDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,aheadDays);
		//�д�
		String selectSql = " select gi.GuarantyID "
						 + " from guaranty_info gi,guaranty_relative gr,Business_Contract bc "
						 + " where gi.GuarantyID = gr.GuarantyID and gr.objectno = bc.SerialNo and gr.ObjectType in('CBContractApply','SWContractApply') "
						 + "  and gi.date2 = '"+sDate+"' and to_date('"+deductDate+"','YYYY/MM/DD')<to_date(bc.MaturityDate,'YYYY/MM/DD')  ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psUpdateSql.setString(1,rs.getString("GuarantyID"));
			psUpdateSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"����");
			}
		}
		psUpdateSql.executeBatch();
		rs.close();
		psSelectSql.close();
		psUpdateSql.close();
		
	}
}
