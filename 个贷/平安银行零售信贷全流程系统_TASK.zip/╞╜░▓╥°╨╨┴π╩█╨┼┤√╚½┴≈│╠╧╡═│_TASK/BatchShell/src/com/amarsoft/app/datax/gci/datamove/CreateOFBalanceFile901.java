package com.amarsoft.app.datax.gci.datamove;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class CreateOFBalanceFile901 extends CommonExecuteUnit{
	
	private String sFileUrl;
	private String NASUrl;
	
	public int execute() {
			
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{	
					String pDate="";
					String flage="";
					String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
					PreparedStatement lps=connection.prepareStatement(lockSql);
					ResultSet rs =lps.executeQuery();
					while(rs.next()){
						pDate=rs.getString("attribute1");
						flage=rs.getString("attribute2");
					}
					rs.close();
					if(deductDate.equals(pDate)&&"0".equals(flage)){
						logger.info("����OF 901��������ļ�......");
						sFileUrl=getProperty("FileUrl");
						
						CreateFile();
						logger.info("����OF 901��������ļ����!");
					}else{
						logger.info("...............���첻��Ҫ����.............");
					}
					
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 

		}
	
	public void CreateFile() throws SQLException, IOException, ParseException
	{
		String selectSql1=" select sb.Currency,sb.OrgID,sb.SubjectNo,0.0 as DebitBalance,0.0 as CreditBalance,oi.MainFrameOrgID "
			 +" from Subject_Balance sb,org_info oi "
			 +" where sb.OrgID = oi.OrgID and (oi.RelativeOrgID = ? or oi.OrgID = ? ) and sb.OccurDate = ? and sb.SubjectNo <> '49990102' ";
		PreparedStatement psSelectSql1 = connection.prepareStatement(selectSql1);
		
		String selectSql2=" select count(*) as icount,0.0 as OrgSumDebitBalance,0.0 as OrgSumCreditBalance  "
			 +" from Subject_Balance sb,org_info oi "
			 +" where sb.orgid = oi.OrgID and (oi.RelativeOrgID = ? or oi.OrgID = ? ) and sb.OccurDate = ?  and sb.SubjectNo <> '49990102'   ";
		PreparedStatement psSelectSql2 = connection.prepareStatement(selectSql2);
		
		String tempSql = " select OrgID,MainFrameOrgID from Org_Info where OrgLevel = '3'  and MainFrameOrgID is not null  ";
		PreparedStatement psTempSql =connection.prepareStatement(tempSql);
		ResultSet rsTemp=psTempSql.executeQuery();
		//�������ɲ�ͬ�ļ�
		while(rsTemp.next())
		{
			NASUrl = ARE.getProperty("NASUrl");
			sFileUrl=getProperty("FileUrl");
			String sDate = StringFunction.replace(deductDate,"/","");
			String lasDatas=StringFunction.replace(lastDate,"/","");
			String sMonth = StringFunction.replace(currentMonth,"/","");
			sFileUrl=StringFunction.replace(sFileUrl,"{$CurrentDate}",sDate);
			sFileUrl=StringFunction.replace(sFileUrl,"{$CurrentMonth}",sMonth);
			sFileUrl = NASUrl+sFileUrl;
			File file = new File(sFileUrl);
			if(!file.exists())
			{
				file.mkdirs();
			}
			
			//String sDate = deductDate.substring(0,4)+deductDate.substring(5,7)+deductDate.substring(8,10);
			String sFName = sFileUrl+"A3_RCN_"+sDate+"_"+rsTemp.getString("MainFrameOrgID")+".dat";
			FileWriter fw = new FileWriter(sFName);
			psSelectSql1.setString(1,rsTemp.getString("OrgID"));
			psSelectSql1.setString(2,rsTemp.getString("OrgID"));
			psSelectSql1.setString(3,lastDate);
			ResultSet rs1 = psSelectSql1.executeQuery();
			while(rs1.next())
			{
				String sWriteFileRow = "10|"+rs1.getString("Currency")+"|"+rs1.getString("MainFrameOrgID")+"||"+rs1.getString("SubjectNo")+"|||||0.0|0.0|||||"+"\n";
				fw.write(sWriteFileRow);
			}
			
			rs1.close();
			
			psSelectSql2.setString(1,rsTemp.getString("OrgID"));
			psSelectSql2.setString(2,rsTemp.getString("OrgID"));
			psSelectSql2.setString(3,deductDate);
			ResultSet rs2 = psSelectSql2.executeQuery();
			while(rs2.next())
			{	
				String sWriteFileRow = "20|"+rs2.getInt("icount")+"|"+sDate+"|0.0|0.0|";
				fw.write(sWriteFileRow);			
			}
			
			fw.close();
			rs2.close();
		}
		rsTemp.getStatement().close();
		psTempSql.close();
		psSelectSql1.close();
		psSelectSql2.close();
	}

}
