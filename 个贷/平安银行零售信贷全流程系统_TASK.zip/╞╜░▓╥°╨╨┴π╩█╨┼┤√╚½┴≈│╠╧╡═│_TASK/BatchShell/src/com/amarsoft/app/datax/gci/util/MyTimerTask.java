package com.amarsoft.app.datax.gci.util;

public class MyTimerTask extends Thread{
	public MyExcuteUnit excuteUnit;
	public MyTimerTask(MyExcuteUnit excuteUnit){
		this.excuteUnit=excuteUnit;
	}
	public String  CycleRun() throws Exception{
		String returnResult="continue";
		while(returnResult.equals("continue")){

			returnResult=excuteUnit.run();
			if(returnResult.equals("continue")){
				Thread.sleep(20000);
				continue;
			}
			else{
				break;
			}
		}
		return returnResult;
	}

}
