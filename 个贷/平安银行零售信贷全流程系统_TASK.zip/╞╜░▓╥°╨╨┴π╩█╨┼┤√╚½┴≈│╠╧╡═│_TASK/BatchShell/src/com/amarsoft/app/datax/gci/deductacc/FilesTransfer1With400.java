package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement; 
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;


/**
 * ����FCR�ļ�ESB��Ϣ
 * @author WANGWEIXING492
 *
 */
 
public class FilesTransfer1With400 extends CommonExecuteUnit{
	
	//�ļ���
	private String fileNo;
	//�����ļ�·��
	private String localGetFileUrl;
	//�ļ�����
	private String localGetFileName;
	//������·��
	private String serverSaveFileUrl;
	//�ļ�����
	private String fileType;
	//��Ϣ����
	private String megType;
	private String NASUrl;
	//������IP��ַ
	private String serverIP;
	//FTPS�˿ں�
	private String serverFtpsPort;

	private String sFileCount="";
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPare();
				//���ҽ�BIFMFBAJUP���Ƿ�ִ���ж�
				if(fileType.equals("BIFMFBAJUP"))
				{
					sendFileTOFCR();
				}
				else
					sendFileTOFCR();
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void initPare() throws Exception
	{
		NASUrl = ARE.getProperty("NASUrl");
		fileNo = this.getProperty("FileNo");
		localGetFileUrl = NASUrl + this.getProperty("LocalGetFileUrl");
		localGetFileName = this.getProperty("LocalGetFileName");
		serverSaveFileUrl = this.getProperty("ServerSaveFileUrl");
		fileType = this.getProperty("FileType");
		alterFileName();
		megType = this.getProperty("MegType");
		serverIP = this.getProperty("ServerIP");
		serverFtpsPort = this.getProperty("ServerFtpsPort");
		
		serverSaveFileUrl = "ftps://"+serverIP+":"+serverFtpsPort+serverSaveFileUrl;
		
		String sDate = StringFunction.replace(deductDate,"/","");
		localGetFileUrl = StringFunction.replace(localGetFileUrl,"{$CurrentDate}",sDate);
		
		localGetFileName = StringFunction.replace(localGetFileName,"{$FileCount}",sFileCount);
		localGetFileName = StringFunction.replace(localGetFileName,"{$SixCurrentDate}",sDate.substring(2, 8));
		fileNo = StringFunction.replace(fileNo,"{$FileCount}",sFileCount);
		fileNo = StringFunction.replace(fileNo,"{$SixCurrentDate}",sDate.substring(2, 8));
		
		
		serverSaveFileUrl = StringFunction.replace(serverSaveFileUrl, "{$CurrentDate}", sDate);
	}
	
	//����ESB����FCR�����ļ� 
	public void sendFileTOFCR() throws Exception
	{
		FCRESBInstance FCResbInstance = new FCRESBInstance();
		
		// �ļ��ϴ�֪ͨ�ӿ�,�������Ϊ���ļ��� ģ���� �ļ����� �ļ�����·�� �ļ�������·�� �ļ��㷨
		CompositeData compositeData = FCResbInstance.filesTransfer("system", "batch", fileNo, localGetFileName, localGetFileUrl, serverSaveFileUrl,"FCR039");//�ļ�����
		
		String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF
		String ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");//�������������׳ɹ�����ʧ��ԭ��
		if(ret_status.startsWith("S")){
			logger.info("��FCR����"+megType+"��Ϣ�ɹ���");
		}else{
			throw new Exception("FCR����"+megType+"��Ϣʧ�ܣ�ʧ��ԭ��"+ret_msg);
		}
	}
	
	public void alterFileName() throws Exception{
		String selectSql = "";
		selectSql = "select cl.attribute4,cl.attribute7 from code_library cl where codeno = 'DownloadFileFromFCR' and itemno = '001'";
		PreparedStatement psQuery = connection.prepareStatement(selectSql);
		ResultSet rs = psQuery.executeQuery();
		if (rs.next()) {
			if("BIFMFBATUP".equals(fileType)){
				sFileCount = rs.getString("attribute4").trim();
			}else{
				sFileCount = rs.getString("attribute7").trim();
			}
		}else{
			rs.close();
			psQuery.close();
			throw new Exception("�ļ����ʹ�����ѯʧ�ܣ�");
		}
		rs.close();
		psQuery.close();
	}
}
