package com.amarsoft.app.datax.gci.ofpre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class UpdateOFPreData extends CommonExecuteUnit {

	private int commitNum ;
	private int dealNum = 0;
	boolean ok = true; 
	
	public int execute() {
		
		try{
			super.init();

			commitNum=Integer.parseInt(getProperty("commitNum", "1"));
			
			logger.info("������ϸ��Subject_OccurAmt�н��յ���Ϣ......");
			String delSql = " delete from Subject_OccurAmt where OccurDate = '"+deductDate+"'";
			logger.info("sql = "+delSql);
			PreparedStatement psDelSql =connection.prepareStatement(delSql);
			psDelSql.execute();
			psDelSql.close();
			logger.info("����Subject_OccurAmt���!");
			
			logger.info("������ϸ�ʱ��е���Ԥ��������......");
			insertOccurAmt();
			logger.info("��ϸ�ʱ��е���Ԥ��������������ɣ�");
			
			
			unitStatus= TaskConstants.ES_SUCCESSFUL;
			clearResource();
			return unitStatus;
			
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void insertOccurAmt() throws SQLException
	{
		
		String insertSql = " INSERT INTO Subject_OccurAmt(Currency,OrgID,SubjectNo,DebitAmt,CreditAmt,OccurDate,AccAcountFlag) VALUES(?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql=connection.prepareStatement(insertSql);
		
		String selectSql = " select OrgID,Currency,SubjectNo,sum(DebitAmt) as DebitAmt,sum(CreditAmt) as CreditAmt "
		      + " from ledger_detail "
		      + " where OccurDate = '"+deductDate+"' and (HandStatus = '1' or HandStatus = '2')"
		      + " group by OrgID,Currency,SubjectNo ";
		PreparedStatement psSelectSql=connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			psInsertSql.setString(1,rs.getString("Currency"));
			psInsertSql.setString(2,rs.getString("OrgID"));
			psInsertSql.setString(3,rs.getString("SubjectNo"));
			psInsertSql.setDouble(4,rs.getDouble("DebitAmt"));
			psInsertSql.setDouble(5,rs.getDouble("CreditAmt"));
			psInsertSql.setString(6,deductDate);
			psInsertSql.setString(7,"0");
			psInsertSql.addBatch();
			dealNum++;
			
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		psInsertSql.executeBatch();
		rs.getStatement().close();
		psSelectSql.close();
		psInsertSql.close();
		dealNum=0;
	}
}
