package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import com.amarsoft.account.entity.OrgInfo;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.task.TaskConstants;

public class CalcFinacing extends CommonExecuteUnit{
	
	
	//��������
	private double CurrentRate;
	
	//���α���
	private double CalcProportion;
	//����ϵ��
	private double modulus;
	private double baseAmt;
	private String rateFormula;//�����Ӧ�Ĵ��������ʼ��㹫ʽ
	private double quickDeduct;//����۳���
	
	private String[][] ConfigArray;

	
	private int commitNum ;
	private int dealNum = 0;
	boolean ok = true; 
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" delete from Finacing_Record where CalcDate = '"+deductDate+"' and FinacingType='PAB'";
				logger.info("��� Finacing_Record:sql="+delSql);
				PreparedStatement psDeleteData = connection.prepareStatement(delSql);
				psDeleteData.execute();
				logger.info("���Finacing_Record�������! ");
				psDeleteData.close();
				
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				if(deductDate.substring(8,10).equals("05"))
				{	
					logger.info("��ʼ���㰴��ִ�������......");
					FinacingCalc();
					logger.info("�����ִ�����������ɣ�");
				}
				else
				{
					logger.info("���ղ�����д�ִ�����");
				}
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void initSavingConfig() throws Exception
	{
		//ȥ���ñ��������Ϣ
		int ilength = 0; 
		String countSql = " select count(*) as icount from  Code_library where CodeNo = 'SavingConfig' and IsInUse = '1' ";
		PreparedStatement psCountSql = connection.prepareStatement(countSql);
		ResultSet countRs = psCountSql.executeQuery();
		if(countRs.next())
		{
			ilength = countRs.getInt("icount");
		}
		countRs.close();
		psCountSql.close();
		
		ConfigArray = new String[ilength][9];
		
		int j = 0;
		String tempSql = " select nvl(ItemDescribe, 0.0) as CalcProportion, " +
				" nvl(ItemAttribute, 0.0) as modulus, " +
				" nvl(Attribute4, 0.0) as BaseAmt, " +
				" nvl(Attribute1, 0.0) as minAmt, " +
				" nvl(Attribute2, 0.0) as maxAmt, " +
				" Attribute3 as BeginDate, " +
				" RelativeCode as RateFormula, " +
				" Attribute5 as quickDeduct " +
				" from Code_library " +
				" where CodeNo = 'SavingConfig' " +
				" and IsInUse = '1' ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		ResultSet tempRs = psTempSql.executeQuery();
		while(tempRs.next())
		{
			ConfigArray[j][0] = tempRs.getString("CalcProportion"); //���μ������
			ConfigArray[j][1] = tempRs.getString("modulus"); //����ϵ��
			ConfigArray[j][2] = tempRs.getString("BaseAmt");   //��׼���
			ConfigArray[j][3] = tempRs.getString("minAmt");   //��ʼ���
			ConfigArray[j][4] = tempRs.getString("maxAmt");   //����������
			ConfigArray[j][5] = tempRs.getString("BeginDate");   //������Чʱ��
			ConfigArray[j][6] = tempRs.getString("RateFormula");   //�ù����´��������ʼ��㹫ʽ
			ConfigArray[j][7] = tempRs.getString("quickDeduct");   //����۳���
			j++;
		}
		tempRs.close();
		psTempSql.close();
		
		//ȡ�����ڴ������
		String tempSql1 = " select RateValue from rate_info where RateType = '510' and Status = '1'  ";
		PreparedStatement psTempSql1 = connection.prepareStatement(tempSql1);
		ResultSet tempRs1 = psTempSql1.executeQuery();
		if(tempRs1.next())
		{
			CurrentRate=tempRs1.getDouble("RateValue");	
		}
		else
		{
			throw new Exception("����ϵͳ���Ƿ��Ѿ������˻������ʣ�");
		}
		tempRs1.close();
		psTempSql1.close();
	}
	public void FinacingCalc() throws Exception
	{
		//��ʼ��
		initSavingConfig();
		String insertSql = " insert into Finacing_Record(RepayAccNo,Corp,Lucre,CalcDate,Currency,SavingAmount,CalcProportion,SumLoanBalance,Rate,CurrentRate,Modulus,DeductAccNo,BusinessSerialNo,TransSerialNo,OrgID,MOrgID,FinacingType)"
			      + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String tempSqlPart1 = " select  nvl(sum(getERateAmount(lr.monthendloanbalance,lb.currency,'RMB')),0) as LoanBalance, ";
		String tempSqlPart2 = " as Rate from Finacing_Relative fr,Loan_Balance lb,Loanbalance_Relative lr" +
				" where fr.savingaccno = lb.Putoutno and lb.Putoutno = lr.putoutno and lb.STerm > 1 and lr.monthendloanbalance>0 " +
				" and fr.finacingaccno = ? and fr.accounttype = '02' and fr.status = '1' " ;
		PreparedStatement psTempSql = null;
		
		String singleSavingAmtSql = " select fr.SavingAccNo,oi.OrgID as OrgID,Srm.OrgID as MOrgID,sum(getERateAmount(Srm.balance,Srm.Currency,'RMB')) as balance" +
				" from finacing_relative fr,Saving_Record_Month Srm,org_info oi " +
				" where  fr.SavingAccNo = Srm.DeductAccNo and fr.FinacingAccNo=? and fr.Status = '1' and oi.MAINFRAMEORGID=Srm.orgid and fr.AccountType = '01' and Srm.InputDate = '"+currentMonth+"/01' and Srm.balanceway = '0' " +
				" group by  fr.SavingAccNo,oi.OrgID,Srm.OrgID";
		PreparedStatement psSingleSavingAmtSql = connection.prepareStatement(singleSavingAmtSql);
		
		String selectSql = " select fa.FinacingAccNo,fa.CustomerID,fa.BeginDate,sum(getERateAmount(Srm.Balance,Srm.Currency,'RMB')) as SavingBalance  "
				  		 + " from  Finacing_Account fa,Finacing_Relative fr,Saving_Record_Month Srm "
				  		 + " where fa.FinacingAccNo = fr.FinacingAccNo "
				  		 + " and fr.SavingAccNo = Srm.DeductAccNo and fa.Status = '1' and fr.accounttype = '01' and Srm.InputDate = '"+currentMonth+"/01' " 
				  		 + " and fr.status = '1' and Srm.balanceway = '0' "
				  		 + " and fa.finacingtype = 'PAB'"
				  		 + " group by fa.FinacingAccNo,fa.CustomerID,fa.BeginDate ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sCustomerID=rs.getString("CustomerID");
			//���ж�׼������
			boolean b = IsCalcCondition(rs.getDouble("SavingBalance"),rs.getString("CustomerID"));
			if(!b) continue;
			
			//��һ���������������汾��
			double savingCorp = calcCorp(rs.getDouble("SavingBalance"),rs.getString("BeginDate"));
			//System.out.println("����" + savingCorp);
			if(savingCorp<=0)
				continue;
			
			psTempSql = connection.prepareStatement(mixSqlString(tempSqlPart1, rateFormula, tempSqlPart2));
			
			psTempSql.setString(1,rs.getString("FinacingAccNo"));
			
			ResultSet tempRs = psTempSql.executeQuery();
			if(tempRs.next())
			{
				double sumNormalBalance = tempRs.getDouble("LoanBalance");
				
				
				//��һ���������������汾��
				//double savingCorp = calcCorp(rs.getDouble("SavingBalance"),rs.getString("BeginDate"));
				//if(savingCorp<=0)
				//	continue;
				//�ڶ������жϼ������ƽ�Ĵ���� ���ܴ��ڴ��������
				double calcCorp = returnCalcAmount(savingCorp,sumNormalBalance);
				//System.out.println("��Ч����" + calcCorp);
				//�������������Ȩ����
				double rate = tempRs.getDouble("Rate"); 
				//System.out.println("���ʣ�" + rate);
				//���Ĳ������㰴�ҽ���������
				double lucre = calcLucre(calcCorp,rate);
				//System.out.println("���棺" + lucre);
				
				if(lucre == 0)
					continue;
				psSingleSavingAmtSql.setString(1,rs.getString("FinacingAccNo"));
				ResultSet rsTemp2 = psSingleSavingAmtSql.executeQuery();
				while(rsTemp2.next())
				{
					String sOrgID = rsTemp2.getString("OrgID");
					String sMorgID = rsTemp2.getString("MOrgID");
					if(sOrgID==null)sOrgID="";
					String sRelativeAccNo = "";
					try
					{
						sRelativeAccNo = OrgInfoConfig.getAccountNo(sOrgID,AccountConstants.Finacing_SUBJECTNO,"RMB",AccountConstants.Org_Account_Type_Finacing);
						if(sRelativeAccNo == "" || sRelativeAccNo.length()==0)
						{
							throw new Exception();
						}
					}
					catch(Exception ex)
					{
						BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
						batchErrorRecord.setObjectNo(rs.getString("FinacingAccNo"));
						batchErrorRecord.setObjectType("FinacingAccount");
						batchErrorRecord.setTargetName(getTarget().getName());
						batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
						batchErrorRecord.setTaskName(getName());
						batchErrorRecord.setTaskDescribe(getDescribe());
						batchErrorRecord.setInputDate(deductDate);
						batchErrorRecord.setErrorDescribe("δ����û����Ĵ�ִ������˺ţ����ѯ�û������ʺ����ã� ������Ϊ��"+sOrgID);
						batchErrorRecord.errorRecord(connection);
						continue;
					}
					double dSingleLucre = calcSingleReturnAmt(lucre,rsTemp2.getDouble("balance"),rs.getDouble("SavingBalance"));
					psInsertSql = this.setPsPamas(psInsertSql,rsTemp2.getString("SavingAccNo"),calcCorp,dSingleLucre,rsTemp2.getDouble("balance"),sumNormalBalance,rate,sRelativeAccNo,sOrgID,sMorgID);
					dealNum++;
				}
				rsTemp2.close();
				
			}
			tempRs.close();
			psTempSql.close();
			if(dealNum>commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
			}
		}
		rs.close();
		psInsertSql.executeBatch();
		
		psSingleSavingAmtSql.close();
		psSelectSql.close();
		
	}
	
	/*
	 * ׼�������ж�: �ÿͻ����д������δ����
	 * pamas: �ͻ����
	 * */
	public boolean IsCalcCondition(double SavingBalance,String sCustomerID) throws SQLException
	{
		//���д���������ڵ�
		int iSumOverDays = 0;
		String tempSql = " select sum(OverDays) as sumOverDays from loan_balance lb,loanBalance_relative lr where lb.PutOutNo = lr.PutOutNo and lb.CustomerID = '"+sCustomerID+"' group by lb.CustomerID ";
		PreparedStatement psTempSql = connection.prepareStatement(tempSql);
		ResultSet tempRs = psTempSql.executeQuery();
		if(tempRs.next())
		{
			iSumOverDays=tempRs.getInt("sumOverDays");	
		}
		tempRs.getStatement().close();
		if(iSumOverDays>0)
			return false;
			
		return true;
	}
	
	/*
	 * �жϼ������ƽ�Ĵ����ܴ��� ����ʣ���ܽ��
	 * */
	public double returnCalcAmount(double corp,double sumNormalBalance) throws SQLException
	{
		if(sumNormalBalance>=corp)
			return corp;
		else
			return sumNormalBalance;
	}
	
	/*
	 * �����������汾��
	 * */
	public double calcCorp(double savingAmount,String sBeginDate)
	{
		
		
		String sConfigDate = returnConfigDate(sBeginDate);
		if(sConfigDate == null || sConfigDate.length() == 0 )
		{
			return 0.0;
		}
		else
		{
			initSingleFinPara(savingAmount,sConfigDate);
			return (savingAmount-baseAmt)*CalcProportion*modulus*0.01 + quickDeduct;
		}
	}
	
	/*
	 * ���ݰ��ҽ�����ʱ�䣬�жϸð��ҽ�������׹���
	 * */
	public String returnConfigDate(String sBeginDate)
	{
		String sReturnDate = "";
		// 2011��3��1��������ִ���Ʒ����ǰ��ͨ�Ĵ��ͨ���¹��򲻵ó�����Ч����Ϊ2011��2��28����һ��
		if (DateTools.getDays(sBeginDate,"2011/03/01")>0) {
			sReturnDate = getProximalDate("2011/02/28");
		} else {
			sReturnDate = getProximalDate(sBeginDate);
		}
		return sReturnDate;
	}
	
	/** ������baseDate����Ĺ�����Ч���� */
	private String getProximalDate(String baseDate) {
		String sReturnDate = "";
		for (int i = 0; i < ConfigArray.length; i++) {
			if (DateTools.getDays(ConfigArray[i][5], baseDate) > 0) {
				if (sReturnDate.length() == 0 || sReturnDate == null) {
					sReturnDate = ConfigArray[i][5];
				} else {
					if (DateTools.getDays(sReturnDate, ConfigArray[i][5]) > 0) {
						sReturnDate = ConfigArray[i][5];
					}
				}
			}
		}
		return sReturnDate;
	}
	
	/*
	 * ���� �ñʰ��ҽ�Ĵ����������� �õ�������ز���
	 */
	private void initSingleFinPara(double savingAmount,String sConfigDate)
	{
		CalcProportion = 0.0;
		modulus = 0.0;
		baseAmt = 0.0;
		rateFormula = "";
		quickDeduct = 0.0;
		
		for(int i=0;i<ConfigArray.length;i++)
		{
			//�жϸ������������ �Ƿ����Ҫ��
			if(ConfigArray[i][5].equals(sConfigDate))
			{
				double minAmt = Double.valueOf(ConfigArray[i][3]);
				double maxAmt = Double.valueOf(ConfigArray[i][4]);
				//�жϴ�����Ƿ����Ҫ��
				if(savingAmount>minAmt&&savingAmount<=maxAmt)
				{
					CalcProportion = Double.valueOf(ConfigArray[i][0]);
					modulus = Double.valueOf(ConfigArray[i][1]);
					baseAmt = Double.valueOf(ConfigArray[i][2]);
					rateFormula = String.valueOf(ConfigArray[i][6]);
					quickDeduct = Double.valueOf(ConfigArray[i][7]);
				}
			}
		}
	}
	
	
	/*
	 * ���㰴�ҽ���������
	 * */
	public double calcLucre(double corp,double rate) throws SQLException
	{
		double lucre = corp*(rate-CurrentRate)*0.01/12;
		return lucre;
	}
	
	/*
	 * ���㵥���ʻ�������
	 * pamas: �����桢�����ʻ������ܴ����
	 * */
	public double calcSingleReturnAmt(double dLucre,double dSingleSavingAmt,double dSavingAmt)
	{
		return NumberTools.round(dLucre*dSingleSavingAmt/dSavingAmt,2);
	}
	
	/*
	 * �滻PreparedStatement�е�ռλ��
	 * */
	public PreparedStatement setPsPamas(PreparedStatement psInsert,String sRepayAccNo,double dCalcCorp,double dLucre,double dSavingBalance,double dNormalBalance,double dRate,String sDeductAccNo,String sOrgID,String sMOrgID) throws Exception
	{
		
		String businessSerialNo = ESBTransaction.getBZSerialNo(connection);//ҵ����ˮ
		String transSerialNo = businessSerialNo;//������ˮ
		psInsert.setString(1,sRepayAccNo);
		psInsert.setDouble(2,dCalcCorp);
		psInsert.setDouble(3,dLucre);
		psInsert.setString(4,deductDate);
		psInsert.setString(5,"RMB");
		psInsert.setDouble(6,dSavingBalance);
		psInsert.setDouble(7,CalcProportion);
		psInsert.setDouble(8,dNormalBalance);
		psInsert.setDouble(9,dRate);
		psInsert.setDouble(10,CurrentRate);
		psInsert.setDouble(11,modulus);
		psInsert.setString(12,sDeductAccNo);
		psInsert.setString(13,businessSerialNo);
		psInsert.setString(14,transSerialNo);
		psInsert.setString(15,sOrgID);
		psInsert.setString(16,sMOrgID);
		psInsert.setString(17,"PAB");//���֣�ԭ������ִ�ΪPAB���´�ִ�ΪSDB
		psInsert.addBatch();
		
		return psInsert;
	}
	
	/*
	 * ����400�����Ų��Ҹ���ϵͳ������
	 * */
	public String findOrgID(String sMFOrgID)
	{
		String returnOrgName = "";
		HashMap<String, OrgInfo> orgHashMap = OrgInfoConfig.getOrgInfoHashMap();
		for (Iterator<String> iter = orgHashMap.keySet().iterator(); iter.hasNext();)
		{
			String key = iter.next();
			OrgInfo orgInfo = orgHashMap.get(key);
			if(orgInfo.getMainFrameOrgId() == null)
				continue;
			if(orgInfo.getMainFrameOrgId().equalsIgnoreCase(sMFOrgID))
			{
				returnOrgName = orgInfo.getOrgID();
				break;
			}
		}
		return returnOrgName;
	}

	private String mixSqlString(String part1, String formula, String part2) {
		return new StringBuffer(part1).append(formula).append(part2).toString();
	}
}