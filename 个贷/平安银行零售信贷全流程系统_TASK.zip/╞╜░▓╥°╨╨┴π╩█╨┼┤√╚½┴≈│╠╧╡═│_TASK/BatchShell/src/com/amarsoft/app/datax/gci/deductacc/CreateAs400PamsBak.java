package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

	public class CreateAs400PamsBak extends CommonExecuteUnit{
		
			
		public int execute() {
			try{
				String sInit = super.init();
				if(sInit.equalsIgnoreCase("skip"))
				{
					return TaskConstants.ES_SUCCESSFUL;
				}
				else
				{
					String timeFlag=getProperty("timeFlag", "AM");
					
					String delSql=" delete from as400_pams_bak where inputdate = '"+deductDate+"' and TimeFlag = '"+timeFlag+"'";
					logger.info("��� as400_pams_bak:sql="+delSql);
					PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
					psDeleteDeductData.execute();
					psDeleteDeductData.close();
					logger.info("���as400_pams_bak������� ");
					
					logger.info("��ʼ���ݽ��տۿ�����.....");

	
					String bakSql=" insert into as400_pams_bak(inputdate,putoutno,currency,payType,PayAmount,ActualAmount,ActualAmount1,ActualAmount2,ActualAmount3,Deductaccno,Deductaccno1,Deductaccno2, " +
							" RelativeAccNo,SerialNo,AheadSerialNo,DealFlag,Digest,SplitType,AmountAttribute,Sterm,TransSerialno,BusinessSerialno,BankFlag,TimeFlag)" +
							" (select '"+deductDate+"',putoutno,currency,payType,PayAmount,ActualAmount,ActualAmount1,ActualAmount2,ActualAmount3,Deductaccno,Deductaccno1,Deductaccno2," +
							" RelativeAccNo,SerialNo,AheadSerialNo,DealFlag,Digest,SplitType,AmountAttribute,Sterm,TransSerialno,BusinessSerialno,BankFlag,'"+timeFlag+"' from as400_pams) ";
					PreparedStatement psBakSql = connection.prepareStatement(bakSql);
					psBakSql.execute();
					psBakSql.close();
					
					logger.info("���ݽ��տۿ�˳����ɣ�");
					logger.info("���ձ��ݱ����������ݴ���.....");
					SpecialDeal(timeFlag);
					logger.info("�������ݴ������.....");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
					clearResource();
					return unitStatus;
				}
			}catch(Exception ex){
				logger.error(ex);
				ex.printStackTrace();
				unitStatus= TaskConstants.ES_FAILED;
				clearResource();
				return unitStatus;
			} 
		}
		
		private void SpecialDeal(String timeFlag) throws Exception
		{
			int i = 0;
			
			int icountSerialNo = 0;
			
			String insertSql = " insert into as400_pams_bak(inputdate,serialno,putoutno,currency,PayType,PayAmount,actualamount,actualamount1,actualamount2,actualamount3,amountattribute,BankFlag,TimeFlag) " +
					" values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			PreparedStatement psinsertSql = connection.prepareStatement(insertSql);
			
			String tmpSql = " select max(serialno) as iserianocount from as400_pams_bak where inputdate = '"+deductDate+"' ";
			PreparedStatement psTmpSql = connection.prepareStatement(tmpSql);
			ResultSet rsTmp = psTmpSql.executeQuery();
			if(rsTmp.next())
			{
				icountSerialNo =  rsTmp.getInt("iserianocount");
			}
			rsTmp.close();
			psTmpSql.close();
			
			String selectSql = "  select ap.PutOutNo,ap.Currency,ap.BankFlag,sum(ap.payamount) as Payamount,sum(ap.actualamount) as ActualAmount," +
					"sum(ap.actualamount1) as ActualAmount1,sum(ap.actualamount2) as ActualAmount2,sum(ap.actualamount3) as ActualAmount3 " +
					" from as400_pams_bak ap " +
					" where ap.inputdate = '"+deductDate+"' " +
							" and ap.amountattribute in ('"+BatchConstant.AMOUNTATTRIBUTE_XBFARE+"','"+BatchConstant.AMOUNTATTRIBUTE_FINE+"'," +
						" '"+BatchConstant.AMOUNTATTRIBUTE_INTE+"','"+BatchConstant.AMOUNTATTRIBUTE_CORP+"') " +
					" group by ap.PutOutNo,ap.Currency,ap.BankFlag ";
			PreparedStatement psBakSql = connection.prepareStatement(selectSql);
			ResultSet rs = psBakSql.executeQuery();
			while(rs.next())
			{
				i++;
				icountSerialNo++;
				psinsertSql.setString(1,deductDate);
				psinsertSql.setLong(2,icountSerialNo);
				psinsertSql.setString(3,rs.getString("PutOutNo"));
				psinsertSql.setString(4,rs.getString("Currency"));
				psinsertSql.setString(5,"1");
				psinsertSql.setDouble(6,rs.getDouble("Payamount"));
				psinsertSql.setDouble(7,rs.getDouble("ActualAmount"));
				psinsertSql.setDouble(8,rs.getDouble("ActualAmount1"));
				psinsertSql.setDouble(9,rs.getDouble("ActualAmount2"));
				psinsertSql.setDouble(10,rs.getDouble("ActualAmount3"));
				psinsertSql.setString(11,"4");
				psinsertSql.setString(12,rs.getString("BankFlag"));
				psinsertSql.setString(13,timeFlag);
				
				psinsertSql.addBatch();
				
				if(i>=1000)
				{
					psinsertSql.executeBatch();
					i=0;
				}
				
			}
			psinsertSql.executeBatch();
			psBakSql.close();
			psinsertSql.close();
		}
	
	}
	
