package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.account.write.execute.FreezeDeposit;
import com.amarsoft.account.write.execute.SWFreezeDeposit;
import com.amarsoft.account.write.execute.TransDepositAcc;
import com.amarsoft.account.write.execute.TransDepositAccBF;
import com.amarsoft.account.write.execute.TransDepositAccSW;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

public class BatchSavingBillRepay extends CommonExecuteUnit{
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��������һ���º�浥�ⶳ���ʼ......");
				savingBillRepay30();
				logger.info("�浥�ⶳ�������!");
				
				logger.info("�浥�ⶳ��ʼ......");
				freezeDeposit();
				logger.info("�浥�ⶳ���......");
				

				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//�浥�ⶳ����
	private void savingBillRepay30() throws Exception
	{
		Transaction Sqlca = StringTools.getSqlca();
		try{
			int sDate = 90;
			String sqlDate = "select ITEMATTRIBUTE from code_library where codeno='DespiotTime' and itemno='10'";
			PreparedStatement psDate = connection.prepareStatement(sqlDate);
			ResultSet rsDate = psDate.executeQuery();
			if(rsDate.next()){
				sDate =Integer.parseInt(rsDate.getString("ITEMATTRIBUTE"));
			}
			
			//����δ��������90��󣨺�90�죩ͨ����ѯ���ĺ�ͬ���ҳ���ݺ�
			String sqlLB = " select lb.PutOutNo " +
								" from loan_balance lb,business_contract bc,loanbalance_relative lr  " +
								" where lb.ContractSerialNo = bc.SerialNo and lb.putoutno = lr.putoutno " +
								" and lr.overdays>="+sDate+" " +
								" and lb.LoanStatus in ('0','1','4','5') " +
								" and lb.FinishDate is null "+
								" and bc.SerialNo = ? ";
			PreparedStatement psLB = connection.prepareStatement(sqlLB);
			
			//��ѯ����ͬ�ţ�������
			String sqlBC = " select bc.SerialNo,gr.GuarantyID " +
						" from business_contract bc,guaranty_relative gr,guaranty_info gi " +
						" where bc.SerialNo = gr.ObjectNo " +
						"  and gr.guarantyid = gi.guarantyid" +
						" and gi.guarantytype = '030010'" +
						" and gr.ObjectType in ('CBContractApply','SWContractApply') " +
						" and bc.FinishDate is null and bc.CustomerType <>'05' and bc.BankFlag <> 'SDB' and bc.BusinessType <> '1130050' ";
			PreparedStatement psBC = connection.prepareStatement(sqlBC);
			ResultSet rsBC = psBC.executeQuery();
			while(rsBC.next()){
				String bcSerialNo = rsBC.getString("SerialNo");
				String guaranytID = rsBC.getString("GuarantyID");
				
				psLB.setString(1,bcSerialNo);
				ResultSet rsLB = psLB.executeQuery();
				while(rsLB.next())
				{
					String putOutNo = rsLB.getString("PutOutNo");
					try
					{
						LoanBalance loanBalance = new LoanBalance();
						loanBalance.SetLoanBalance(putOutNo,connection);
						Sqlca.conn.setAutoCommit(false); 
						//�浥���ֻ��ֻ�軹���ڱ�����
						TransDepositAccBF transDepositAccBF = new TransDepositAccBF();
						//CompositeData compositeData = transDepositAcc.GetTransDeposit(loanBalance,guaranytID,"batch",loanBalance.getOrgID(),Sqlca);
						//FCR�ӿ�
						CompositeData compositeData = transDepositAccBF.GetTransDeposit(loanBalance,guaranytID,OCIConfig.getUserID(),loanBalance.getOrgID(),Sqlca);
						String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");
						String ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");
						if(ret_status.equals("F")){
							this.errorRecord(putOutNo, "�浥�ⶳ����"+ret_msg+"ʧ��");
							Sqlca.conn.rollback();
							//throw new Exception(ret_msg);
						}
						Sqlca.conn.commit();
					}
					catch(Exception ex)
					{
						ex.printStackTrace();
						errorRecord(putOutNo,"�浥����ʧ��");
						Sqlca.conn.rollback();
					}
				}
				rsLB.close();
			}
			rsDate.close();
			psDate.close();
			rsBC.close();
			psBC.close();

			psLB.close();
			
			Sqlca.disConnect();
		}
		catch(Exception e){
			Sqlca.disConnect();
			throw e;
		}
		
		
	}

	//���������浥
	private void freezeDeposit() throws SQLException, ParseException{
		String sSqlTmp = " select count(*) as icount " +
				" from Loan_Balance " +
				" where ContractSerialNo = ?" +
				" and FinishDate is null" +
				" and loanStatus in ('0','1','4','5')";
		PreparedStatement psQueryTmp = connection.prepareStatement(sSqlTmp);
		
		String selectSql = " select distinct lb.ContractSerialNo as SerialNO,lb.bankflag" +
						   " from Guaranty_Info gi,Loan_Balance lb, Guaranty_Relative gr" +
						   " where gr.ObjectNO = lb.ContractSerialNo and gr.ObjectType in('CBContractApply','SWContractApply') " +
						   " and gr.GuarantyID = gi.GuarantyID and lb.FinishDate is not null" +
						   " and lb.FinishDate <='" +deductDate+"'" +
						   " and lb.FinishDate > '2009/10/10'"+
						   " and gi.GuarantyType = '030010' and gi.Attribute5 = '01' and lb.businesstype <> '1130050'";//�ų�����Ĵ浥
		PreparedStatement psQuery = connection.prepareStatement(selectSql);
		ResultSet rs = psQuery.executeQuery();
		while(rs.next()){
			//��ͬ���
			int icount = 0;
			String sSerialNO = DataConvert.toString(rs.getString("SerialNO"));
			String sBankFlag = DataConvert.toString(rs.getString("bankflag"));
			psQueryTmp.setString(1, sSerialNO);
			ResultSet rsTmp = psQueryTmp.executeQuery();
			if(rsTmp.next())
			{
				icount = rsTmp.getInt("icount");
			}
			rsTmp.close();
			
			if(icount>0)
				continue;
			//�ⶳ��ʶ
			String sFreezeFlag = "02";;
			SWFreezeDeposit freezeDeposit;
			try {
				freezeDeposit = new SWFreezeDeposit();
				CompositeData compositeData =  freezeDeposit.freezeDeposit(sSerialNO, sFreezeFlag, OCIConfig.getUserID(),OCIConfig.getBranchID(),sBankFlag);
				String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF
				String ret_msg = (String)ESBInstance.getValue(compositeData, "RET_MSG");//�������������׳ɹ�����ʧ��ԭ��
				
				if("F".equalsIgnoreCase(ret_status))
				{
					logger.error("����ʧ��ret_status="+ret_status+"@ret_msg="+ret_msg);
					errorRecord(rs.getString("SerialNO"),"�浥�ⶳʧ��:"+ret_msg);
					//throw new Exception();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				errorRecord(rs.getString("SerialNO"),"�浥�ⶳʧ��");
			}	
			
		}
		rs.close();
		psQuery.close();
		psQueryTmp.close();
	}
	
	//�����¼��
	public void errorRecord(String sNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sNo);
		batchErrorRecord.setObjectType("LoanBalance");
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
}
