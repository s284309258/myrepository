package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

public class FilesTransfer2WithDC extends CommonExecuteUnit{

	private String sSeq_id; 
	private String sFile_path; 
	private String sMegType;
	private String NASUrl ;
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPare();
				getFileWithDC();
				clearResource();
				
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void initPare()
	{
		sSeq_id = this.getProperty("Seq_id");
		String sDate = StringFunction.replace(deductDate,"/","");
		String sLastDate = StringFunction.replace(lastDate,"/","");
		String sMonth = StringFunction.replace(currentMonth,"/","");
		String sTime = StringFunction.replace(StringFunction.getNow(), ":", "");
		sSeq_id=StringFunction.replace(sSeq_id,"{$CurrentDate}",sDate);
		sSeq_id=StringFunction.replace(sSeq_id,"{$CurrentMonth}",sMonth);
		sSeq_id=StringFunction.replace(sSeq_id,"{$LastDate}",sLastDate);
		sSeq_id=StringFunction.replace(sSeq_id,"{$Time}",sTime);
		
		sFile_path = this.getProperty("File_path");
		
		sMegType = this.getProperty("MegType");
		NASUrl = ARE.getProperty("NASUrl");
	}
	
	//�ȴ�V+�����ļ�ֱ���ɹ�
	private void getFileWithDC() throws Exception {
//		OCIConfig.loadOCIConfig(true);
//		OCIConfig.setEnvironment("Cycle");
//		OCIConfig.setDataSourceName("Loan");
		
		String sDate= StringFunction.replace(deductDate,"/","");
		 
		String sSql = " select tl.Ret_Status as Ret_Status,tl.Remark" +
					  " from TransAction_Log tl" +
					  " where tl.ReceiveSystem = 'FROM_ESB'" +
					  " and tl.Service_Code = '11005000002@01'  and substr(tl.Remark,12,8)='"+sDate+"' and tl.Remark like '" +sFile_path+"%' ";
		System.out.println(sSql);
		//substr(tl.Remark,11,8)='"+sDate+"' and tl.Remark like '" +sFile_path+"%'
		PreparedStatement psQuery = connection.prepareStatement(sSql);
		//��ѯV+�����ļ��Ƿ�ɹ�
		ResultSet rs = psQuery.executeQuery();
		
		if(rs.next()){
			if(rs.getString("Ret_Status").startsWith("S")){
				logger.info("V+�ļ����ճɹ�...��");
				ESBInstance esbInstance = new ESBInstance();
				//�ļ����Ͳ�ѯ,�������Ϊ�����������������û������α�š��ļ�·���������������ϵͳ���
//				String sFile_path1 = NASUrl+"/BATCHFILE/VDCFILE/"+sDate+"_Cr2LoanFile/"+sFile_path;
				String sFile_path2 = sFile_path+"_"+sDate+"_0001";
				CompositeData compositeData = esbInstance.queryFilesTransferForDC("", "",sSeq_id,sFile_path2, "0","947444","790162");
				
				String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF

				if(ret_status.endsWith("S")){
					logger.info("����V+�����ļ�"+sMegType+"�ɹ�!");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}else{
					logger.error("����V+�����ļ�"+sMegType+"��Ϣʧ��!");
					unitStatus= TaskConstants.ES_FAILED;
				}
			}else{
				logger.error("����"+sMegType+"��Ϣʧ��!");
				unitStatus= TaskConstants.ES_FAILED;
			}
		}
		else
		{
			logger.error("ESBδ��Ӧ��");
			unitStatus= TaskConstants.ES_FAILED;
		}
		rs.close();
		psQuery.close();
	}
}
