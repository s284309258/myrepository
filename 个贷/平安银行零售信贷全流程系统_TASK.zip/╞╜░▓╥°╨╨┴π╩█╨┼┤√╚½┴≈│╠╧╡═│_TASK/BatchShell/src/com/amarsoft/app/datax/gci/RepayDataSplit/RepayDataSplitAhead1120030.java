package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;

public class RepayDataSplitAhead1120030 extends BasicRepayDataSplit{

	@Override
	public ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		//���ÿ���������
		String CreditCardFAccNo = accountMap.get("CreditCardFAccNo").getAccountNo();
		String sDeductSerialNo = createDeductSerialNo();
		
		String sAheadPaydate = "";
		for(int i=0;i<aheadDeductdataList.size();i++)
		{
			AheadDeductData aheadDeductData = aheadDeductdataList.get(i);
			
			sAheadPaydate = aheadDeductData.getPayDate();
			
			//��Ϣ
			double inteAmount = returnAheadInte(aheadDeductData);
			if(inteAmount>0)
			{
				ErrorRecord(aheadDeductData.getPutOutNo(),"���ÿ���������Ϊ0��������Ϣ���ܴ���0��");
			}
			//��ǰ������
			double amount = returnAheadCorp(aheadDeductData)+returnPoundage(aheadDeductData);
			if(amount>0)
			{
				PamsAs400 pamsAs400 = new PamsAs400(aheadDeductData.getPutOutNo(),aheadDeductData.getCurrency(),amount,
						CreditCardFAccNo,RelativeAccNo,sDeductSerialNo,
						BatchConstant.AMOUNTATTRIBUTE_AHEAD,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_ALL,aheadDeductData.getChangeSerialNo(),"","");
				pamsAs400ArrayList.add(pamsAs400);
			}

		}
		/*if(aheadDeductdataList.size()>0)
		{
			for(int i=0;i<fareDetailList.size();i++)
			{
				FareDetaill fareDetail = fareDetailList.get(i);
				
				double fareAmount = fareDetail.getPayMoney()-fareDetail.getActualMoney();
				
				
				//�����ǰ����Ϊ��Ϣ�գ�����ý��
				for(int j=0;j<deductDateList.size();j++)
				{
					if(fareDetail.getPayDate().equals(deductDateList.get(j).getPayDate()))
					{
						fareAmount = 0;
					}
				}
				
				if(fareAmount>0&&sAheadPaydate.compareTo(fareDetail.getPayDate())<0)
				{
					int ipaydate = Integer.valueOf(fareDetail.getPayDate().substring(0,4)+fareDetail.getPayDate().substring(5,7)+fareDetail.getPayDate().substring(8,10));
					PamsAs400 pamsAs400 = new PamsAs400(fareDetail.getPutOutNo(),fareDetail.getCurrency(),fareAmount,
							CreditCardFAccNo,RelativeAccNo,sDeductSerialNo,
							BatchConstant.AMOUNTATTRIBUTE_CDFAREAHEAD,ipaydate,
							BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"");
					
					pamsAs400ArrayList.add(pamsAs400);
				}
			}
		}*/
		
		
		return pamsAs400ArrayList;
	}

	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		String sPutOutNo = "";
		boolean dReturn = true;
		
		if(aheadDeductdataList.size()>0)
			sPutOutNo = aheadDeductdataList.get(0).getPutOutNo();
		else 
			dReturn = false;
		//���ÿ���������
		String CreditCardFAccNo = accountMap.get("CreditCardFAccNo").getAccountNo();
		if(CreditCardFAccNo == null||CreditCardFAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"���ÿ����������������ڣ�");
			dReturn = false;
		}
		//��400������
		String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
		if(RelativeAccNo==null||RelativeAccNo.length()==0)
		{
			ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
			dReturn = false;
		}
		return dReturn;
	
	}
	
}
