package com.amarsoft.app.datax.gci.deductacc.thread;

import java.sql.Connection;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.*;
import com.amarsoft.are.log.*;


/**
 * ���̴߳����� ����
 *     ʹ���̵߳�����ThreadScheduler���õ��߳��࣬��̳б��࣡
 * @author ZHANGQINGYONG688
 *
 */
public abstract class BatchThread extends Thread {
	protected CommonExecuteUnit mainProcess = null;	//�������߳�
	protected int threadID = -1; //�߳�ID��0~�����С��0��ʾδ��ʼ��
	
	protected Log logger = null;//��־
	protected String deductDate = null;//��������
	protected String nextMonth;
	protected String lastMonth;
	protected String currentMonth;
	protected String nextDate;
	protected String nextYear;
	protected String lastDate;
	protected String currentYear;
	protected String lastYear;
	protected String createDate;//��չ���� ��Ԥ������

	protected int mod = -1; //���ݿ����ݷ�ҳmodֵ
	protected int modvalue = -1;//���ݿ����ݷ�ҳmodvalueֵ
	
	protected Connection connection = null;//ÿ���̶߳��������ݿ�����
	protected String procedure = null;//ִ�еĴ洢����SQL����������Ԫ
	
	
	/**
	 * �̳߳�ʼ��
	 * @param runningProcess
	 * @param threadID
	 * @param mod
	 * @param deductDate
	 * @throws Exception
	 */
	public void init(CommonExecuteUnit mainProcess, int threadID,int mod,int modvalue,String deductDate) throws Exception {
		this.setName("p" + mainProcess.getName() + "-" + threadID + "-����MOD��Χ["+mod+","+modvalue+"]");
		this.mainProcess = mainProcess;	//��Ϣ�̵߳�����
		this.threadID = threadID;
		this.mod = mod;
		this.modvalue = modvalue;
		this.deductDate = deductDate;
		
		nextMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,1).substring(0,7);
		lastMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,-1).substring(0,7);
		currentMonth=deductDate.substring(0,7);
		currentYear = deductDate.substring(0,4);
		lastYear = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,-1).substring(0,4);
		nextDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
		lastDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,-1);;
		nextYear=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,1).substring(0,4);
		this.logger = ARE.getLog();
		//��������
		DBConnection dc = new DBConnection();
		this.connection =dc.getConn("Loan");
		if ( connection == null ) {
			throw new Exception("��ȡ���ݿ�����ʧ�ܣ����ݿ�����[Loan]");
		}
	}
	/**
	 * �̳߳�ʼ��
	 * @param runningProcess
	 * @param threadID
	 * @param deductDate
	 * @throws Exception
	 */
	public void init(CommonExecuteUnit mainProcess,int threadID,int mod,int modvalue,String deductDate,String createDate) throws Exception {
		this.createDate=createDate;
		this.init(mainProcess, threadID, mod, modvalue, deductDate);
	}
	
	/**
	 * �̳߳�ʼ��
	 * @param runningProcess
	 * @param procedure
	 * @throws Exception
	 */
	public void init(CommonExecuteUnit mainProcess, int threadID,String procedure, String deductDate) throws Exception {
		this.setName("p" + mainProcess.getName() + "-" + procedure);
		this.mainProcess = mainProcess;	//��Ϣ�̵߳�����
		this.threadID = threadID;
		this.procedure = procedure;
		this.deductDate = deductDate;
		
		nextMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,1).substring(0,7);
		lastMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,-1).substring(0,7);
		currentMonth=deductDate.substring(0,7);
		currentYear = deductDate.substring(0,4);
		lastYear = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,-1).substring(0,4);
		nextDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
		lastDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,-1);;
		nextYear=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,1).substring(0,4);
		this.logger = ARE.getLog();
		//��������
		DBConnection dc = new DBConnection();
		this.connection =dc.getConn("Loan");
		if ( connection == null ) {
			throw new Exception("��ȡ���ݿ�����ʧ�ܣ����ݿ�����[Loan]");
		}
	}
	
	/**
	 * �رճ�����Դ
	 */
	protected void close() {
		try {
			this.connection.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	public CommonExecuteUnit getMainProcess() {
		return mainProcess;
	}
	public void setMainProcess(CommonExecuteUnit mainProcess) {
		this.mainProcess = mainProcess;
	}
	public int getThreadID() {
		return threadID;
	}
	public void setThreadID(int threadID) {
		this.threadID = threadID;
	}
	public Log getLogger() {
		return logger;
	}
	public void setLogger(Log logger) {
		this.logger = logger;
	}
	public String getDeductDate() {
		return deductDate;
	}
	public void setDeductDate(String deductDate) {
		this.deductDate = deductDate;
	}
	public String getNextMonth() {
		return nextMonth;
	}
	public void setNextMonth(String nextMonth) {
		this.nextMonth = nextMonth;
	}
	public String getLastMonth() {
		return lastMonth;
	}
	public void setLastMonth(String lastMonth) {
		this.lastMonth = lastMonth;
	}
	public String getCurrentMonth() {
		return currentMonth;
	}
	public void setCurrentMonth(String currentMonth) {
		this.currentMonth = currentMonth;
	}
	public String getNextDate() {
		return nextDate;
	}
	public void setNextDate(String nextDate) {
		this.nextDate = nextDate;
	}
	public String getNextYear() {
		return nextYear;
	}
	public void setNextYear(String nextYear) {
		this.nextYear = nextYear;
	}
	public String getLastDate() {
		return lastDate;
	}
	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}
	public String getCurrentYear() {
		return currentYear;
	}
	public void setCurrentYear(String currentYear) {
		this.currentYear = currentYear;
	}
	public String getLastYear() {
		return lastYear;
	}
	public void setLastYear(String lastYear) {
		this.lastYear = lastYear;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public int getMod() {
		return mod;
	}
	public void setMod(int mod) {
		this.mod = mod;
	}
	public int getModvalue() {
		return modvalue;
	}
	public void setModvalue(int modvalue) {
		this.modvalue = modvalue;
	}
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public String getProcedure() {
		return procedure;
	}
	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}
	
}
