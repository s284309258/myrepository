package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.account.entity.BaseRateInfo;
import com.amarsoft.account.sysconfig.InterestRateConfig;

public class BatchInsertBaseRateChange extends CommonExecuteUnit{
	
	private String selectSql;
	private PreparedStatement psSelectSql;
	private String insertSql;
	private PreparedStatement psInsertSql;
	private String deleteSql;
	private PreparedStatement psDeleteSql;
	private String updateSql;
	private PreparedStatement psUpdateSql;
	
	private static HashMap<String,ArrayList<BaseRateInfo>> baseRateInfoHashMap;
	
	int icount = 0;
	private int commitNum ;
	
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{

				String sChangeType = BatchConstant.CHANGE_TYPE_BASERATE;
				String sDate = DateTools.getStringDate(deductDate);
				String sChangeSerialNoHead = "B"+sDate+sChangeType;
				
				String delSql=" delete from Loan_Change where ChangeSerialNo like '"+sChangeSerialNoHead+"%' ";
				logger.info("��ʼ���loan_change�н�������������׼���ʱ������.....");
				PreparedStatement psDeleteData = connection.prepareStatement(delSql);
				psDeleteData.execute();
				logger.info("���loan_change�н�������������׼���ʱ���������! ");
				psDeleteData.close();
				
				baseRateInfoHashMap = InterestRateConfig.getBaseRateInfoHashMap();
				
				boolean bb = true;
				
				for (Iterator<String> iter = baseRateInfoHashMap.keySet().iterator(); iter.hasNext();) 
				{
					String key = iter.next();
					ArrayList<BaseRateInfo> rateInfoArrayList = baseRateInfoHashMap.get(key);
					for(int j=0;j<rateInfoArrayList.size();j++)
					{
						BaseRateInfo bRateInfo = rateInfoArrayList.get(j);
						if(bRateInfo.getEffectDate().equals(deductDate))
						{
							bb = false;
						}
					}
				}
				
				
				if(bb)
				{
					logger.info("����û�н��л�׼���ʵ�����");
				}
				else
				{
					
					logger.info("�������в���������׼���ʱ������...");
					insertBaseRateChange();
					logger.info("������������׼���ʱ������"+icount+"����");
					logger.info("����������׼���ʱ������ִ����ɣ�");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	

	public void insertBaseRateChange() throws Exception
	{
		int dealNum = 0;
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		
		
		updateSql = " UPDATE loan_change SET newvalue = ? where ChangeType='"+BatchConstant.CHANGE_TYPE_BASERATE+"' and ObjectType='LoanBalance' and ObjectNo=? and ChangeDate =? And Status = '1'";
		PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
		
		insertSql = " insert into Loan_Change(ObjectType,ObjectNo,ChangeDate,Status,ChangeType,OldValue,NewValue,ColName,ChangeSerialNo,RelativeSerialNo) "
			      + " values(?,?,?,?,?,?,?,?,?,?) ";
		psInsertSql = connection.prepareStatement(insertSql);
		
		deleteSql = " delete from Loan_Change where ChangeType='"+BatchConstant.CHANGE_TYPE_BASERATE+"' and ObjectType='LoanBalance' and ObjectNo=? and ChangeDate =? And Status = '1'";
		psDeleteSql = connection.prepareStatement(deleteSql);
		
		String temSql = " select ChangeDate from Loan_Change where ChangeType = '"+BatchConstant.CHANGE_TYPE_BASERATE+"' and ObjectType='LoanBalance' and ObjectNo=? And Status = '1'";
		PreparedStatement psTempSql = connection.prepareStatement(temSql);
		
		selectSql = " select PutOutNo,BaseRate,PutOutDate,decode(LastInteDate,'"+deductDate+"',LastInteDate,'"+nextDate+"',LastInteDate,NextPayDate) as NextPayDate,RateAdjustType,PutOutDate,MaturityDate,ReturnPeriod,BaseRateType "
				  + " from loan_balance "
				  + " where LoanStatus in ('0','1','4','5') and ratemode = '01' and (NormalBalance > 0 or (NormalBalance = 0 and FineRateMode = '01')) ";
		psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			//��øô���Ĵ�������
			int loanTerm = DateTools.getMonths(rs.getString("PutOutDate"),rs.getString("MaturityDate"));
			
			//���ظ��������µĻ�׼���� ��û������ �򷵻�0
			double newBaseRate = returnNewBaseRate(loanTerm,rs.getString("BaseRateType"));
			if(newBaseRate==0)
			{
				continue;
			}
			
			//ԭ��������������ȵ�
			if(newBaseRate==rs.getDouble("BaseRate"))
			{
				continue;
			}
			
			//ɸѡ�����ʵ������� Ϊ ��������
			if(rs.getString("RateAdjustType").equals(BatchConstant.RATEADJUCT_CHANGE_NOCHANGE))
			{
				continue;
			} 
			
			//�������ʵ����������´λ����� ���ػ�׼���ʱ������
			String sChangeDate = returnbaseRateChangeDate(rs.getString("PutOutDate"),rs.getString("NextPayDate"),rs.getString("RateAdjustType"),rs.getString("ReturnPeriod"));
			
			if(sChangeDate.length()>10)
			{
				continue;
			}
			psTempSql.setString(1,rs.getString("PutOutNo"));
			ResultSet rsTemp = psTempSql.executeQuery();
			if(rsTemp.next())
			{
				if(DateTools.getDays(deductDate,rsTemp.getString("ChangeDate"))<=0)
				{
					continue;
				}else{
					//Ӧ���Ǹ���
					psUpdateSql.setDouble(1, newBaseRate);
					psUpdateSql.setString(2,rs.getString("PutOutNo"));
					psUpdateSql.setString(3,rsTemp.getString("ChangeDate"));
					psUpdateSql.addBatch();
				}
				
			}else{
				String sChangeSerialNo = createSerialNo();
				psInsertSql.setString(1,"LoanBalance");
				psInsertSql.setString(2,rs.getString("PutOutNo"));
				psInsertSql.setString(3,sChangeDate);
				psInsertSql.setString(4,BatchConstant.CHANGE_STATUS_CHANGING);
				psInsertSql.setString(5,BatchConstant.CHANGE_TYPE_BASERATE);
				psInsertSql.setDouble(6,rs.getDouble("BaseRate"));
				psInsertSql.setDouble(7,newBaseRate);
				psInsertSql.setString(8,"BaseRate");
				psInsertSql.setString(9,sChangeSerialNo);
				psInsertSql.setString(10,sChangeSerialNo);
				psInsertSql.addBatch();
				dealNum++;
				icount++;
			}
			rsTemp.close();
			
			
			
			if(dealNum>=commitNum)
			{
				if(psDeleteSql!=null) psDeleteSql.executeBatch();
				if(psUpdateSql!=null) psUpdateSql.executeBatch();
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"��!");
			}
		}
		if(psUpdateSql!=null) psUpdateSql.executeBatch();
	    psInsertSql.executeBatch();
		rs.getStatement().close();
		psInsertSql.close();
		psTempSql.close();
		psSelectSql.close();
		psUpdateSql.close();
		
	}
	
	//���ظ��������µĻ�׼���� ��û������ �򷵻�0
	public double returnNewBaseRate(int loanTerm,String sBaseRateType)
	{
		double returnNewBaseRate = 0.0;
		
		ArrayList<BaseRateInfo> rateInfoArrayList = baseRateInfoHashMap.get(sBaseRateType);	
		if(rateInfoArrayList==null)
			return returnNewBaseRate;
		for(int i=0;i<rateInfoArrayList.size();i++)
		{
			BaseRateInfo baseRateInfo = rateInfoArrayList.get(i);
			if(loanTerm>baseRateInfo.getMinTerm() && loanTerm<=baseRateInfo.getMaxTerm() && baseRateInfo.getEffectDate().equals(deductDate))
			{
				returnNewBaseRate = baseRateInfo.getRateValue();
			}
		}
		
		return returnNewBaseRate;
	}
	
	// ���ػ�׼���ʱ������
	public String returnbaseRateChangeDate(String sPutOutDate,String sNextPayDate,String RateAdjustType,String sReturnPeriod) throws Exception
	{
		String sReturn = "";
		//--���⣺sNextPayDate ������ˣ��Ƿ�Ӧ����putoutdate
		//������������������Ч����Ϊ��Ч���ڱ�����ڵ���
		if(RateAdjustType.equals(BatchConstant.RateAdjustChange_Type_Tense)){
			sReturn = nextDate;
		}
		//�����
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_NEXTYEARFIRST)){
			sReturn = nextYear+"/01/01";
		}
		//������¶���
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_NEXTYEARTODATE))
		{
			//��������Ϊ����
			if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_MONTH))
			{
				sReturn = nextYear+"/"+sPutOutDate.substring(5,7)+"/"+sNextPayDate.substring(8,10);
			}
			//��������Ϊ����
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_SEASON))
			{
				sReturn = nextYear+"/"+sPutOutDate.substring(5,7)+"/"+sNextPayDate.substring(8,10);
			}
			//��������Ϊ��˫��
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_TWOWEEK))
			{
				String d = nextYear+"/"+sPutOutDate.substring(5,7)+"/01";
				int num = (int) Math.ceil(DateTools.getDays(sNextPayDate,d)/14);
				sReturn = DateTools.getRelativeDate(sNextPayDate,AccountConstants.TERM_UNIT_DAY,14*num);
			}
			else
			{
				sReturn = nextYear+"/"+sPutOutDate.substring(5,7)+"/"+sNextPayDate.substring(8,10);
			}
		}
		//����
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_MONTH))
		{
			//��������Ϊ����
			if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_MONTH))
			{
				//--���⣺sNextPayDate ������ˣ�
				sReturn = sNextPayDate;
			}
			//��������Ϊ����
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_SEASON))
			{
				if(sNextPayDate.substring(0,7).equals(currentMonth))
					sReturn = sNextPayDate;
				else
					sReturn = nextMonth+sNextPayDate.subSequence(7,10);
			}
			//��������Ϊ��˫��
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_TWOWEEK))
			{
				String d = nextMonth+"/01";
				int num = (int) Math.ceil(DateTools.getDays(sNextPayDate,d)/14);
				if(num<0) num=0;
				sReturn = DateTools.getRelativeDate(sNextPayDate,AccountConstants.TERM_UNIT_DAY,14*num);
			}
			else
			{
				sReturn = nextMonth+sNextPayDate.subSequence(7,10);
			}
		}
		//����
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_SEASON))
		{
			//��������Ϊ����
			if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_MONTH))
			{
				//String sPutOutDate,String sNextPayDate,String RateAdjustType,String sReturnPeriod
				int i = (int) Math.ceil(DateTools.getMonths(sPutOutDate,deductDate)/3.0);
				String sDate = DateTools.getRelativeDate(sPutOutDate,AccountConstants.TERM_UNIT_MONTH,i*3).substring(0,8)+sNextPayDate.substring(8,10);
				if (sDate.compareTo(deductDate)<0) 
					sDate=DateTools.getRelativeDate(sDate,AccountConstants.TERM_UNIT_MONTH,3);
				
				sReturn = sDate;
			}
			//��������Ϊ����
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_SEASON))
			{
				sReturn = sNextPayDate;
			}
			//��������Ϊ��˫��
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_TWOWEEK))
			{
				String d = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,3).substring(0,7)+"/01";
				int num = (int) Math.ceil(DateTools.getDays(sNextPayDate,d)/14);
				sReturn = DateTools.getRelativeDate(sNextPayDate,AccountConstants.TERM_UNIT_DAY,14*num);
			}
			else
			{
				String sDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,3).substring(0,8)+sNextPayDate.substring(8,10);
				sReturn = sDate;
			}
		}
		//�´ν�Ϣ�� ��˫�ܹ��ã�
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_NEXTPAYDATE)){
			sReturn = sNextPayDate;
		}
		//���������
		else if(RateAdjustType.equals(BatchConstant.RATEADJUCT_CHANGE_HALFYEAR)){
			//��������Ϊ���ºͰ�����ͳһ����
			if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_MONTH)||sReturnPeriod.equals(BatchConstant.RETURNPERIOD_SEASON))
			{
				//String sPutOutDate,String sNextPayDate,String RateAdjustType,String sReturnPeriod
				int i = (int) Math.ceil(DateTools.getMonths(sPutOutDate,deductDate)/6.0);
				String sDate = DateTools.getRelativeDate(sPutOutDate,AccountConstants.TERM_UNIT_MONTH,i*6).substring(0,8)+sNextPayDate.substring(8,10);
				if (sDate.compareTo(deductDate)<0) 
					sDate=DateTools.getRelativeDate(sDate,AccountConstants.TERM_UNIT_MONTH,6);
				
				sReturn = sDate;
			}
			//��������Ϊ��˫��
			else if(sReturnPeriod.equals(BatchConstant.RETURNPERIOD_TWOWEEK))
			{
				String d = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,6).substring(0,7)+"/01";
				int num = (int) Math.ceil(DateTools.getDays(sNextPayDate,d)/14);
				sReturn = DateTools.getRelativeDate(sNextPayDate,AccountConstants.TERM_UNIT_DAY,14*num);
			}
			else
			{
				String sDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,6).substring(0,8)+sNextPayDate.substring(8,10);
				sReturn = sDate;
			}
		}
		String sDate = DateTools.getEndDateOfMonth(sReturn.substring(0,7)+"/01");
		return sDate.compareTo(sReturn)<0?sDate:sReturn;
			
	}
	

	public String createSerialNo() throws Exception
	{
		icount++;
		String sChangeType = BatchConstant.CHANGE_TYPE_BASERATE;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(icount,8,'0');
		return "B"+sDate+sChangeType+sSortNo;
	}
	
}
