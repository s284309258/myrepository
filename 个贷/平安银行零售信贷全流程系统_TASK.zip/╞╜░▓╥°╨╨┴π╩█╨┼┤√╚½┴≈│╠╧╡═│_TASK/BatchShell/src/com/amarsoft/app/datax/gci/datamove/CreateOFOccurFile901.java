package com.amarsoft.app.datax.gci.datamove;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.task.TaskConstants;

public class CreateOFOccurFile901 extends CommonExecuteUnit {	
	
	private String sFileUrl;	
	private String NASUrl;
	
	public int execute() {
				
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("����OF 901���ʷ������ļ�......");
					CreateFile();
					logger.info("����OF 901���ʷ������ļ���ɣ�");
				}else{
					logger.info("...............���첻��Ҫ����.............");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}

	}
	
	public void CreateFile() throws SQLException, IOException, ParseException
	{
		/**
		 * �˴������������ʱ������ֱ����relativeOrgid����Ҫ��org_belong��ȡ��
		 */
		String selectSql1="  select so.Currency,oi.OrgID,so.SubjectNo, nvl(so.debitbalance,0.0)*(-1) as DebitAmt, nvl(so.creditbalance,0.0)*(-1) as CreditAmt,oi.MainFrameOrgID "
					     +"   from Subject_Balance so,org_info oi "
					     +"     where so.orgid = oi.OrgID  "
					     +"    and (oi.relativeOrgID =? or oi.OrgID =? )  "
					     +"     and so.OccurDate = ?  ";
		PreparedStatement psSelectSql1 = connection.prepareStatement(selectSql1);
		
		String selectSql2 = "   select count(*) as icount,nvl(sum(so.debitbalance),0.0)*(-1) as OrgSumDebitAmt, nvl(sum(so.creditbalance),0.0)*(-1) as OrgSumCreditAmt "
							 +"     from Subject_Balance so,org_info oi   "
							 +"    where so.orgid = oi.OrgID   "
							 +"    and (oi.relativeOrgID = ? or oi.OrgID = ? )   "
							 +"    and so.OccurDate = ?  ";
		PreparedStatement psSelectSql2 = connection.prepareStatement(selectSql2);
		
		String tempSql = " select OrgID,MainFrameOrgID from Org_Info where OrgLevel = '3'  and MainFrameOrgID is not null ";
		PreparedStatement psTempSql =  connection.prepareStatement(tempSql);
		ResultSet rsTemp = psTempSql.executeQuery();
		//�������ɲ�ͬ�ļ�
		while(rsTemp.next())
		{
			NASUrl = ARE.getProperty("NASUrl");
			sFileUrl=getProperty("FileUrl");
			String sDate = StringFunction.replace(deductDate,"/","");
			String sMonth = StringFunction.replace(currentMonth,"/","");
			sFileUrl=StringFunction.replace(sFileUrl,"{$CurrentDate}",sDate);
			sFileUrl=StringFunction.replace(sFileUrl,"{$CurrentMonth}",sMonth);
			sFileUrl = NASUrl+sFileUrl;
			File file = new File(sFileUrl);
			if(!file.exists())
			{
				file.mkdirs();
			}
			
			//String sDate = deductDate.substring(0,4)+deductDate.substring(5,7)+deductDate.substring(8,10);
			String sFName = sFileUrl+"A3_ADD_"+sDate+"_"+rsTemp.getString("MainFrameOrgID")+".dat";
			FileWriter fw = new FileWriter(sFName);
			psSelectSql1.setString(1,rsTemp.getString("OrgID"));
			psSelectSql1.setString(2,rsTemp.getString("OrgID"));
			psSelectSql1.setString(3,lastDate);
			ResultSet rs1 = psSelectSql1.executeQuery();
			while(rs1.next())
			{
				String sWriteFileRow = "10|"+rs1.getString("Currency")+"|"+rs1.getString("MainFrameOrgID")+"||"+rs1.getString("SubjectNo")+"|||||"+rs1.getString("DebitAmt")+"|"+rs1.getString("CreditAmt")+"|||||"+"\n";
				fw.write(sWriteFileRow);
			}
			rs1.close();
			
			psSelectSql2.setString(1,rsTemp.getString("OrgID"));
			psSelectSql2.setString(2,rsTemp.getString("OrgID"));
			psSelectSql2.setString(3,lastDate);
			ResultSet rs2 = psSelectSql2.executeQuery();
			while(rs2.next())
			{
				String sWriteFileRow = "20|"+rs2.getInt("icount")+"|"+sDate+"|"+rs2.getString("OrgSumDebitAmt")+"|"+rs2.getString("OrgSumCreditAmt")+"|";
				fw.write(sWriteFileRow);
			}
			fw.close();
			rs2.close();
		}
		rsTemp.getStatement().close();
		psTempSql.close();
		psSelectSql1.close();
		psSelectSql2.close();
	}

}
