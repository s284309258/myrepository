package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

/**
 * �ж�FCR216�Ƿ�ɹ�
 * 
 * @author WANGWEIXING492
 * 
 */
public class DeductFileTransferFromESB extends CommonExecuteUnit {

	// �ļ�����
	private String sFileType;

	public int execute() {
		try {
			String sInit = super.init();
			
			/*��ʼ������*/
			initPare();
			
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} 
			
			//��ѯ����216��Ϣ
			queryFileinfo();
			
			if(!checkfinished()){
				throw new Exception("���ļ�δ�յ�FCR216ESB��Ϣ��FCR����216�����ļ�ʧ��!");
			}	

			unitStatus = TaskConstants.ES_SUCCESSFUL;
			clearResource();
			return unitStatus;

		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	/**
	 * ��ʼ������
	 * @throws Exception
	 */
	private void initPare() throws Exception {
		sFileType = this.getProperty("FileType");
	}

	// �ȴ�FCR�����ļ�ֱ���ɹ�
	private void getFileESBWithFCR(String fileNo) throws Exception {
		String filename = "EXT-" + fileNo + ".txt";
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			String sSql = "";
			sSql = "select tl.Ret_Status as Ret_Status,tl.describe as describe"
					+ " from TransAction_Log tl"
					+ " where tl.ReceiveSystem = 'FROM_ESB'"
					+ " and tl.Service_Code = '11005000002@51'"
					+ " and tl.describe like '%" + fileNo
					+ ".txt@status_code:0000@%'";
			logger.info(sSql);
			psQuery = connection.prepareStatement(sSql);
			// ��ѯFCR�����ļ��Ƿ�ɹ�
			rs = psQuery.executeQuery();
			if(rs.next()){
				if (rs.getString("Ret_Status").startsWith("S")) {
					logger.info("�ļ���" + filename + " FCR���ճɹ���");
					updateLog(filename);
				} else {
					logger.info("�ļ���" + filename + " FCR����ʧ�ܣ� ");
				}
			}else{
				logger.info("�ļ���" + filename + " FCR����ʧ�ܣ� ");
			}
		} catch (SQLException e) {
			throw new Exception("��ѯTransAction_Log��������");
		} finally {
			rs.close();
			psQuery.close();
		}
	}
	
	/**
	 * ��ѯ��Щ�ļ�������Ҫ��ѯ216
	 * @throws Exception
	 */
	public void queryFileinfo() throws Exception{
		String selectSql = "";
		String fileno = "";
		selectSql = "select fileno from FILESTATUS_INFO where transferesbstatus = 'S' and  (FCR216STATUS <> 'S' or FCR216STATUS is null ) and filetype = '"
			+ sFileType + "' and inputdate = '" + deductDate + "'";
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			psQuery = connection.prepareStatement(selectSql);
			rs = psQuery.executeQuery();
			while(rs.next()){
				fileno = rs.getString("fileno");
				getFileESBWithFCR(fileno);
			}
		}catch (Exception e) {
			e.printStackTrace();
			throw new Exception("��ѯ�����216��Ϣ�ļ��쳣��");
		}finally{
			rs.close();
			psQuery.close();
		}  
	}
	
	/**
	 * ��ѯ�ļ��Ƿ�ȫ������ESB�ɹ����Ƿ���true���񷵻�false
	 * @return
	 * @throws Exception
	 */
	public Boolean checkfinished() throws Exception{
		String num;
		String selectSql = "";
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			selectSql = "select 1 as num from FILESTATUS_INFO where transferesbstatus = 'S' and  (FCR216STATUS <> 'S' or  FCR216STATUS is null ) and filetype = '"
					+ sFileType + "' and inputdate = '" + deductDate + "'";
			psQuery = connection.prepareStatement(selectSql);
			rs = psQuery.executeQuery();
			if (rs.next()) {
				num = rs.getString("num");
				if("1".equals(num)){
					return false;
				}
			}
			return true;
		} catch (Exception e) {
			throw new Exception("��ѯ�ļ�����216��Ϣ״̬ʧ�ܣ�");
		} finally {
			rs.close();
			psQuery.close();
		}
	}
	
	/**
	 * ����������־��
	 * @param filename
	 * @param status
	 * @throws Exception
	 */
	public void updateLog(String filename) throws Exception{
		String sSql;
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			sSql = "update FILESTATUS_INFO  set FCR216STATUS = 'S' where extfilename = '"+filename+"'";
			psQuery = connection.prepareStatement(sSql);
			rs = psQuery.executeQuery();
		} catch (SQLException e) {
			throw new Exception("����FILESTATUS_INFO��������");
		} finally {
			rs.close();
			psQuery.close();
		}
	}

}
