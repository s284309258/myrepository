package com.amarsoft.app.datax.gci;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

/**
 * ����ƽ���ػ�Ͷ���嵥�ļ�
 * 
 * @author EX-GONGYITAO002
 * 
 */
public class ExpFileSH extends CommonExecuteUnit {

    private String sql;
    private String fileName; // �ļ�����
    private String localFileName;  //�����ļ���
    private PrintWriter outputstreamwriter;
    private String separator;
    private String NASUrl;
    private String fileUrl;
    private String sDate;
    private String sNextDate;//Ͷ����Ч����
    private String sMaturityDate;//Ͷ��������
    private boolean fileFlage=true;  //���������ļ����������ļ���־
 	private static String defaultKeyFileName = ""; // Ĭ�ϵĹ�Կ�ļ���
 	private String keyUrl;

   

    /**
     * ����ƽ���ػ��ļ�
     */
    @SuppressWarnings("finally")
    public int execute() {
	try {
	    String sInit = super.init();
	    /**------������----------------------*/
        /**-----------------------������----------------------*/
	    if (sInit.equalsIgnoreCase("skip")) {
	    	unitStatus = TaskConstants.ES_SUCCESSFUL;
	    } else {
		fileName = this.getProperty("unit.fileName");
		/* �ж��ļ����� */
		if (!isTodayEx(fileName)) {
		    unitStatus = TaskConstants.ES_SUCCESSFUL;
		} else {
		    /*ȡ�����ļ���ַ*/
		    NASUrl = ARE.getProperty("NASUrl");
		    fileUrl = this.getProperty("unit.fileUrl");
		    keyUrl = getProperty("keyUrl");
		    
		    defaultKeyFileName=NASUrl+keyUrl+"TOAkey.dat";
		    
		    sNextDate = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
		    sMaturityDate = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,1).substring(0,10);
		    
		    
		    sDate = StringFunction.replace(deductDate, "/", "");
		    fileName = StringFunction.replace(fileName, "{$CurrentDate}", sDate);
		    fileUrl = StringFunction.replace(fileUrl, "{$CurrentDate}", sDate);
		    localFileName=fileName;
		    
		    /* ƴ�ӱ����ļ�·�� */
		    fileUrl = NASUrl + fileUrl;
		    File file = new File(fileUrl);
		    if (!file.exists()) {
			file.mkdirs();
		    }
		    /* ƴ�ӱ����ļ�·�����ļ��� */
		    fileName = fileUrl + fileName;
		    outputstreamwriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "UTF-8")), true);

		    for (int i = 1; !(getProperty("unit.recordSet" + i) == null || getProperty("unit.recordSet" + i).trim().equals("")); i++) {

			sql = this.getProperty("unit.recordSet" + i);
			sql = StringFunction.replace(sql, "{$CurrentDate}", deductDate);
			sql = StringFunction.replace(sql, "{$NextDate}", sNextDate);
			sql = StringFunction.replace(sql, "{$MaturityDate}", sMaturityDate);  

			String[] s = sql.trim().split(":");
			sql = sql.substring(sql.indexOf(s[1]) + s[1].length() + 1);
			String sql1=s[2];
			logger.info("��ӡ��ǰ������sql=" + sql.replaceAll("   ", ""));
			logger.info("��ӡ��ǰ������sql1=" + sql1.replaceAll("   ", ""));
			exportResultSet(sql1, ARE.getMetaData(s[0]).getTable(s[1]), outputstreamwriter);
		    }
		    outputstreamwriter.close();
		    inserFileName();
		    unitStatus = TaskConstants.ES_SUCCESSFUL;
		}
	    }
	} catch (Exception e) {
	    logger.error(e.toString());
	    e.printStackTrace();
	    unitStatus = TaskConstants.ES_FAILED;
	} finally {
	    clearResource();
	    return unitStatus;
	}
    }
    
    //���ļ������뵽SHFILE_LIST���У��Ա�ȡ�ļ���ʱ����ѯ��
    public void inserFileName() throws SQLException{
    	String deleteSql="delete from SHFILE_LIST sl where sl.inputdate= ? ";
    	PreparedStatement delSql;
    	delSql=connection.prepareStatement(deleteSql);
    	delSql.setString(1, deductDate);
    	delSql.execute();
    	delSql.close();
    	
    	
    	String returnFileName=localFileName.replace("_REQ", "_RSP");
    	logger.info("�����ļ��� " +localFileName+"  �����ļ���"+returnFileName);
    	String insertSql="insert into SHFILE_LIST (SENDFILENAME, INPUTDATE, RETURNFILENAME, FILESTATUS)values (?, ?, ?, ? ) ";
		PreparedStatement intSql;
		intSql=connection.prepareStatement(insertSql);
		intSql.setString(1, localFileName);
		intSql.setString(2, deductDate);
		intSql.setString(3, returnFileName);
		intSql.setString(4, "0");
		intSql.execute();
		intSql.close();
    }
    
    /**
     * ��������
     * @param sql
     * @param tableMetaData
     * @param outputstreamwriter
     * @throws Exception
     */
    public void exportResultSet(String sql, TableMetaData tableMetaData, PrintWriter outputstreamwriter) throws Exception {
	separator = this.getProperty("separator");
	Statement stm = connection.createStatement();
	TOAPasswordUtil passfile= new TOAPasswordUtil();
	
	ResultSet rs = stm.executeQuery(sql);

	while (rs.next()) {
	    String s = "";
	    String tmp="";
	    int lineNum = 0;

	    for (int i = 1; i <= tableMetaData.getColumnCount(); i++) {

		lineNum++;
		ColumnMetaData columnMetaData = tableMetaData.getColumn(i);
		String columnName = columnMetaData.getName();
		String rsString = rs.getString(columnName);
		if (rsString == null || "".equals(rsString))
		    rsString = "";
		rsString = rsString.replaceAll("\n", "");
		rsString = rsString.replaceAll("\t", "");
		rsString = rsString.trim();
		if (lineNum == 1) {
		    s = rsString;
		} else {
		    s = s.concat(separator).concat(rsString);
		}

	    }
	    if(fileFlage){
	    	tmp  = passfile.encryptPassword(defaultKeyFileName,s);
	    	tmp +="\r\n";
	    	outputstreamwriter.write(tmp);
	    }else{
	    	s += "\r\n";
	    	outputstreamwriter.write(s);
	    }

	}
	rs.close();
	stm.close();
    }

    private boolean isTodayEx(String sfileType) {
	if (sfileType.equalsIgnoreCase("BIFMFBAJUP")) {
	    if (deductDate.substring(8, 10).equals("05")) {
		return true;
	    } else {
		return false;
	    }
	} else
	    return true;
    }

}