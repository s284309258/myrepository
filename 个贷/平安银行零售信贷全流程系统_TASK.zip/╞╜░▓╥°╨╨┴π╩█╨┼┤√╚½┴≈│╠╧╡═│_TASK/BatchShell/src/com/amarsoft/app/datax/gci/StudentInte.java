package com.amarsoft.app.datax.gci;

public class StudentInte {
	
	private String PutOutNo;         
	private int STerm;
	private int AheadNum;
	private double Interest;
	private String DsDate;
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public int getSTerm() {
		return STerm;
	}
	public void setSTerm(int term) {
		STerm = term;
	}
	public int getAheadNum() {
		return AheadNum;
	}
	public void setAheadNum(int aheadNum) {
		AheadNum = aheadNum;
	}
	public double getInterest() {
		return Interest;
	}
	public void setInterest(double interest) {
		Interest = interest;
	}
	public String getDsDate() {
		return DsDate;
	}
	public void setDsDate(String dsDate) {
		DsDate = dsDate;
	}

}
