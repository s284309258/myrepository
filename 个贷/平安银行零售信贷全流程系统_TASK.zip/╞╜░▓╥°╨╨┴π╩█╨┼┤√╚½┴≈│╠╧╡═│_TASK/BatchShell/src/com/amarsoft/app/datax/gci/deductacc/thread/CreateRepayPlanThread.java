package com.amarsoft.app.datax.gci.deductacc.thread;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.repay.jbo.IRepayScheduleEngine;
import com.amarsoft.account.repay.jbo.RepaymentSchedule;
import com.amarsoft.account.sysconfig.RepayTypeConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.account.util.PayPlan;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class CreateRepayPlanThread extends BatchThread{

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int preDays = 5;
	
	
	public void run() {
		try {
			batchCreateRepayPlan();
			this.connection.commit();
			//�ɹ�ע���߳�
			mainProcess.threadLogOff( this, TaskConstants.ES_SUCCESSFUL);//���̳߳ɹ�ִ��
		} catch (Exception e) {
			e.printStackTrace();
			try {
				this.connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			// �̱߳����쳣���������ȱ����������󣬲�ע���߳�
			this.logger.error("��Ϣ�̡߳�" + this.getName() + "�������쳣����������ƻ�ʧ�ܣ���������ȳ��򱨸����...");
			mainProcess.threadLogOff(this, TaskConstants.ES_FAILED);//��ʧ�ܷ�ʽ�����߳�״̬
		} finally {
			this.close();
		}
		return;
	}
	
	public void batchCreateRepayPlan() throws Exception
	{
		commitNum=Integer.parseInt(this.mainProcess.getProperty("commitNum", "1"));
		preDays = Integer.parseInt(this.mainProcess.getProperty("preDays", "5"));
		String CreateDate = DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY, preDays);
		String sDate = DateTools.getRelativeDate(deductDate, AccountConstants.TERM_UNIT_YEAR, 3);
		String selectTemp = " Select ChangeSerialNo,ObjectNo,ObjectType,ChangeType,ChangeDate,Status,OldValue,NewValue,nvl(ColName,' ') as ColName "
						  + " From loan_change Where ObjectNo = ? and ObjectType='LoanBalance' and Status='1' " 
						  + " order by ChangeDate,ChangeSerialNo ";
		PreparedStatement psSelectTemp = connection.prepareStatement(selectTemp);
		//ResultSet rsTemp = null;
		String insertSql = " insert into Repay_Plan(PutOutNo,Currency,Term,RepayDate,RepayAmount,RepayCorpus,RepayInterest,CorpusAmount,remark,FareAmount,BankFlag) "
			 + " values(?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		
		String insertPreSql = "insert into PreDeduct_Data(PreDeductDate,PutOutNo,Sterm,AheadNum,PayDate," +
							"PayCorp,PayInte,PayFine,GracePeriod,OrgID,LoanAccNo,Balance,PAYFARE) " +
							"Values(?,?,?,?,?," +
							"?,?,?,?,?,?,?,?)";
		PreparedStatement psInsertPreSql = connection.prepareStatement(insertPreSql);
		
		String selectSql = "select * from loan_balance where NormalBalance > 0 and nextPayDate is not null and maturitydate is not null " +
		" and MOD(Dbms_Rowid.Rowid_Relative_Fno(ROWID)||Dbms_Rowid.Rowid_Block_Number(ROWID),?) = ? ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		psSelectSql.setInt(1, this.mod);
		psSelectSql.setInt(2, this.modvalue);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			ArrayList<RepaymentSchedule> repaymentScheduleArray = new ArrayList<RepaymentSchedule>();
			
			LoanBalance loanBalance = LoanBalance.getLoanBalance(rs);
			loanBalance.initLoanRateAlter(connection);//��ʼ���������ʱ��
			loanBalance.SetFareAccount(loanBalance.getPutOutNo(),connection);
			//ex-shengxiaopan001  ����ODS�����չ��ƽ����ʶ
			String bankFlag = loanBalance.getBankFlag();
		
			if("22".equals(loanBalance.getMainReturnType())){
				String sReturnMethod="",StartDate="",sEndDate="",sReturnPeriod="",realMaturityDate="";
				String ObjectNo=loanBalance.getPutOutNo();
				double monthPay = 0d;
				double dsum = 0d;
				realMaturityDate=loanBalance.getMaturityDate();//��ʵ������
				loanBalance.setConnection(connection);
				try {
					
					StartDate=deductDate;
					String sql="select SerialNo,returnmethod,EndDate,ReturnPeriod,BusinessSum,MonthPay from LOAN_RPT_PLAN where ObjectNo='"+ObjectNo+"' " +
							" and status='20' and EndDate>='2012/06/30' order by EndDate";
					
					PreparedStatement psSql = connection.prepareStatement(sql);
					ResultSet rsSql = psSql.executeQuery();
					while(rsSql.next()){
						sReturnMethod=DataConvert.toString(rsSql.getString("returnmethod"));
						sEndDate=DataConvert.toString(rsSql.getString("EndDate"));
						sReturnPeriod=DataConvert.toString(rsSql.getString("ReturnPeriod"));
						dsum=rsSql.getDouble("BusinessSum");
						monthPay = rsSql.getDouble("MonthPay");
						
						loanBalance.setReturnPeriod(sReturnPeriod);
						loanBalance.setReturnType(sReturnMethod);
						loanBalance.setRealMaturityDate(realMaturityDate);//��ʵ������
						loanBalance.setEndDate(sEndDate);
						IRepayScheduleEngine repayScheduleEngine = RepayTypeConfig.getRepaymentType(loanBalance.getReturnType()).getRepayScheduleEngine();
						loanBalance.setMonthPay(monthPay);
						
						if(StartDate.compareTo(realMaturityDate)>0){
							break;
						}
						
						loanBalance = PayPlan.buildPayPlan(loanBalance,loanBalance.getLastInteDate(),sEndDate,connection);
						repaymentScheduleArray = loanBalance.getRepaymentScheduleArray();
						
						StartDate=sEndDate;
						

					}
					rsSql.close();
					for(int i=0;i<repaymentScheduleArray.size();i++)
					{
						RepaymentSchedule repaymentSchedule = repaymentScheduleArray.get(i);
						psInsertSql.setString(1,loanBalance.getPutOutNo());
						psInsertSql.setString(2,loanBalance.getCurrency());
						psInsertSql.setInt(3,repaymentSchedule.getSeqID());
						psInsertSql.setString(4,repaymentSchedule.getRepaymentDate());
						psInsertSql.setDouble(5,repaymentSchedule.getRepayAmount());
						psInsertSql.setDouble(6,repaymentSchedule.getRepayCorpus());
						psInsertSql.setDouble(7,repaymentSchedule.getRepayInterest());
						psInsertSql.setDouble(8,repaymentSchedule.getCorpusAmount());
						psInsertSql.setString(9,repaymentSchedule.getRemark());
						psInsertSql.setDouble(10,repaymentSchedule.getFareAmount());
						psInsertSql.setString(11,bankFlag);
						psInsertSql.addBatch();
						
						if(CreateDate.equals(repaymentSchedule.getRepaymentDate()))
						{
							if(repaymentSchedule.getRepayCorpus()+repaymentSchedule.getRepayInterest() <= 0.0d) continue;
							psInsertPreSql.setString(1, repaymentSchedule.getRepaymentDate());
							psInsertPreSql.setString(2, loanBalance.getPutOutNo());
							psInsertPreSql.setInt(3, repaymentSchedule.getSeqID());
							psInsertPreSql.setInt(4, 0);
							psInsertPreSql.setString(5, repaymentSchedule.getRepaymentDate()); 
							psInsertPreSql.setDouble(6, repaymentSchedule.getRepayCorpus());
							psInsertPreSql.setDouble(7, repaymentSchedule.getRepayInterest());
							psInsertPreSql.setDouble(8, 0.0);
							psInsertPreSql.setInt(9, loanBalance.getGracePeriod());
							psInsertPreSql.setString(10, loanBalance.getOrgID());
							psInsertPreSql.setString(11, loanBalance.getLoanAccNo());
							psInsertPreSql.setDouble(12, NumberTools.round(loanBalance.getNormalBalance()+loanBalance.getOverDueBalance(),AccountConstants.MONEY_PRECISION));
							//�����
							if(loanBalance.getLrFeeMethod().equals("03") && loanBalance.getLrFareMoneyType().equals("01"))
							{
								psInsertPreSql.setDouble(13, loanBalance.getLrAmount());
							}
							else
								psInsertPreSql.setDouble(13, 0.0d);
							psInsertPreSql.addBatch();
						}
						dealNum++;
						icount++;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else{
				loanBalance = PayPlan.buildPayPlan(loanBalance,loanBalance.getLastInteDate(),
						sDate,connection);
				repaymentScheduleArray = loanBalance.getRepaymentScheduleArray();
			
				for(int i=0;i<repaymentScheduleArray.size();i++)
				{
					RepaymentSchedule repaymentSchedule = repaymentScheduleArray.get(i);
					psInsertSql.setString(1,loanBalance.getPutOutNo());
					psInsertSql.setString(2,loanBalance.getCurrency());
					psInsertSql.setInt(3,repaymentSchedule.getSeqID());
					psInsertSql.setString(4,repaymentSchedule.getRepaymentDate());
					psInsertSql.setDouble(5,repaymentSchedule.getRepayAmount());
					psInsertSql.setDouble(6,repaymentSchedule.getRepayCorpus());
					psInsertSql.setDouble(7,repaymentSchedule.getRepayInterest());
					psInsertSql.setDouble(8,repaymentSchedule.getCorpusAmount());
					psInsertSql.setString(9,repaymentSchedule.getRemark());
					psInsertSql.setDouble(10,repaymentSchedule.getFareAmount());
					psInsertSql.setString(11,bankFlag);
					psInsertSql.addBatch();
					
					if(CreateDate.equals(repaymentSchedule.getRepaymentDate()))
					{
						if(repaymentSchedule.getRepayCorpus()+repaymentSchedule.getRepayInterest() <= 0.0d) continue;
						psInsertPreSql.setString(1, repaymentSchedule.getRepaymentDate());
						psInsertPreSql.setString(2, loanBalance.getPutOutNo());
						psInsertPreSql.setInt(3, repaymentSchedule.getSeqID());
						psInsertPreSql.setInt(4, 0);
						psInsertPreSql.setString(5, repaymentSchedule.getRepaymentDate()); 
						psInsertPreSql.setDouble(6, repaymentSchedule.getRepayCorpus());
						psInsertPreSql.setDouble(7, repaymentSchedule.getRepayInterest());
						psInsertPreSql.setDouble(8, 0.0);
						psInsertPreSql.setInt(9, loanBalance.getGracePeriod());
						psInsertPreSql.setString(10, loanBalance.getOrgID());
						psInsertPreSql.setString(11, loanBalance.getLoanAccNo());
						psInsertPreSql.setDouble(12, NumberTools.round(loanBalance.getNormalBalance()+loanBalance.getOverDueBalance(),AccountConstants.MONEY_PRECISION));
						//�����
						if(loanBalance.getLrFeeMethod().equals("03") && loanBalance.getLrFareMoneyType().equals("01"))
						{
							psInsertPreSql.setDouble(13, loanBalance.getLrAmount());
						}
						else
							psInsertPreSql.setDouble(13, 0.0d);
						psInsertPreSql.addBatch();
					}
					dealNum++;
					icount++;
				}
			}
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				psInsertPreSql.executeBatch();
				logger.info(this.getName()+"�����ɻ���ƻ�"+icount+"����");
				dealNum =0;
			}
		}
		psInsertSql.executeBatch();
		psInsertPreSql.executeBatch();
		rs.close();
		psInsertSql.close();
		psInsertPreSql.close();
		psSelectTemp.close();
		psSelectSql.close();
		logger.info(this.getName()+"�ܹ����ɻ���ƻ�"+icount+"����");
	}
	
}
