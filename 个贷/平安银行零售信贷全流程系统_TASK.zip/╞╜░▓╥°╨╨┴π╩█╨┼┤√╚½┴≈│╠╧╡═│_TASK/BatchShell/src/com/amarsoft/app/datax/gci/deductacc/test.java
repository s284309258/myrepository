package com.amarsoft.app.datax.gci.deductacc;

import java.sql.*;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;


public class test {
	
	private static Connection getConnection() throws Exception {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    String url = "jdbc:oracle:thin:@172.18.252.48:1521:PAMS";

	    return DriverManager.getConnection(url, "pams", "amars0ft");
	}


	public static void main(String[] args)throws Exception
	{
		/*
		String a="53";
		String b="aaaaaaabsfdsaaa53aaaabbbbbbbbbbbb";
		int i = b.indexOf(a);
		//int days = DateTools.getDays("2010/11/27","2010/12/26");
        
        System.out.println("i = "+i);
        */
		
		String s = "|17    |130037469000010001            |310227560812001   |20120413|1 |02|";
		String[] sa = s.split("\\|");
		for(String a:sa)
		{
			System.out.println(a);
		}
	}

}

