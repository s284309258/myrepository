package com.amarsoft.app.datax.gci;

public class RateInfo {
	
	private String RateNo;
	private int MinTerm;
	private int MaxTerm;
	private double RateValue;
	public String getRateNo() {
		return RateNo;
	}
	public void setRateNo(String rateNo) {
		RateNo = rateNo;
	}
	
	public int getMinTerm() {
		return MinTerm;
	}
	public void setMinTerm(int minTerm) {
		MinTerm = minTerm;
	}
	public int getMaxTerm() {
		return MaxTerm;
	}
	public void setMaxTerm(int maxTerm) {
		MaxTerm = maxTerm;
	}
	public double getRateValue() {
		return RateValue;
	}
	public void setRateValue(double rateValue) {
		RateValue = rateValue;
	}
	
	

}
