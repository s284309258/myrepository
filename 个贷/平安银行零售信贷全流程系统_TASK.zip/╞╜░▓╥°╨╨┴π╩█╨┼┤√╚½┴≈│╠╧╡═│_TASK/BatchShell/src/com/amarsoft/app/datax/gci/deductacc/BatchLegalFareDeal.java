package com.amarsoft.app.datax.gci.deductacc;

import com.amarsoft.account.Deal.BatchRepayLegalFare;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class BatchLegalFareDeal extends CommonExecuteUnit{


	public int execute() {
			
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
//				OCIConfig.loadOCIConfig(true);
//				OCIConfig.setEnvironment("Cycle");
//				OCIConfig.setDataSourceName("Loan");
				
				SystemConfig.getBusinessDate(connection);
				logger.info("��ʼ���ϷѼ���...");
				BatchRepayLegalFare batchRepay = new BatchRepayLegalFare();
				//��ˮ�Ų���
				batchRepay.initSerialCount(deductDate,connection);
				//ɾ������
				batchRepay.delLoanBill(connection, deductDate);
				//���ɵ���
				batchRepay.initData(connection, deductDate);
				//����
				batchRepay.batchRepay(connection, deductDate);
				logger.info("���ϷѼ������");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
