package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.impl.szpab.esb.SWESBInstance;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

/**
 * �չ�����ļ�����
 * 
 * @author SHISHENGHUA001	
 * 
 */
public class SendICSFile extends CommonExecuteUnit {
	
	//�ļ�·��
	private String homeFileUrl="";
	//�ļ�����
	private String sFileName="";
	private String sServerIP="";  
	private int sPort=0;
	private String sUserName="";
	private String sPsw="";
	private String sBFTSFileUrl="";   //BFTS·��
	private String NASUrl="";
	private boolean chkfile=true;
	private boolean pkfile=true;
	private boolean isSendFlag=false;
	private String RGBZ="";

	public int execute() {
		try {
			String sInit = super.init();

			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("============��ʼ��ʼ���ϴ�SDB�ļ�·�ɣ�=============");
				initPara();
				chickFile();
				logger.info("============��ʼ����ɣ�===============");
				
				logger.info("============�˶�ICSӪҵ���ڿ�ʼ������=============");
				while(true){
					if(checkICSDate()==true){
						break;
					}else{
						throw new Exception("�����ȴ���ICSӪҵ����һ�º����ļ���������");
					}
				}
				logger.info("============�˶�ICSӪҵ���ڽ�����=============");
				
				logger.info("============��ʼ�ϴ������ļ���===============");
				sendSDBFile();
				logger.info("============�ϴ������ļ���ɣ�===============");
				
				logger.info("============��ʼ�ϴ�chk�ļ���===============");
				sendCHKFile();
				logger.info("============�ϴ�chk�ļ���ɣ�===============");
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}



	/**
	 * ��ʼ������ģ�������õĲ���
	 */
	public void initPara() throws Exception {
		Statement stmt=connection.createStatement();
		ResultSet rs = stmt.executeQuery("select ITEMNAME,Attribute2 from code_library cl where cl.codeno='SDBDateFile' and cl.itemno='20'");
		if (rs.next()) {
			sFileName = rs.getString(1);
			RGBZ=rs.getString(2);
		}
		rs.close();
		stmt.close();
		
		sFileName=	StringFunction.replace(sFileName, ".chk", "");
		NASUrl = ARE.getProperty("NASUrl");
		String sDate ="";
		sDate=	StringFunction.replace(deductDate, "/", "");				
		homeFileUrl=getProperty("homeFileUrl");
		homeFileUrl =StringFunction.replace(homeFileUrl, "{$CurrentDate}", sDate);
		sServerIP = getProperty("ServerIP");
		sPort = Integer.parseInt(getProperty("ServerFtpsPort", "2990"));;
		sUserName = getProperty("UserName");
		sPsw = getProperty("PassWord");
		sBFTSFileUrl = getProperty("BFTSFileUrl");
		sBFTSFileUrl =StringFunction.replace(sBFTSFileUrl, "{$CurrentDate}", sDate);
	}
	
	/**
	 * ���������ļ�
	 * @throws Exception 
	 */
	public void sendSDBFile() throws Exception{
		if(pkfile==false && chkfile==false){
			FileTransmitTools fileTool = new FileTransmitTools(); 
			boolean sendStatusFile  = true;   //ȡ�����ļ���־λ
			sendStatusFile=fileTool.transfer(sServerIP, sPort, sUserName ,sPsw,NASUrl+homeFileUrl+sFileName,"ftps://"+sServerIP+":"+sPort+sBFTSFileUrl);
			if(sendStatusFile==false){
				throw new Exception("�ϴ������ļ�ʧ�ܣ�");
			}
		}
	}

	/**
	 * ����CHK�ļ�
	 * @throws Exception 
	 */
	public void sendCHKFile() throws Exception{
		if(pkfile==false && chkfile==false){
			FileTransmitTools fileTool = new FileTransmitTools(); 
			boolean sendStatusCHKFile  = true; //ȡCHK�ļ���־λ
			sendStatusCHKFile=fileTool.transfer(sServerIP, sPort, sUserName ,sPsw,NASUrl+homeFileUrl+sFileName+".chk","ftps://"+sServerIP+":"+sPort+sBFTSFileUrl);
			if(sendStatusCHKFile==false){
				throw new Exception("�ϴ�chk�ļ�ʧ�ܣ�");
			}
		}
	}
	
	public void chickFile() throws Exception{
		
		String fileName = NASUrl+homeFileUrl + sFileName;
		String chkFileName = NASUrl+homeFileUrl + sFileName+".chk";

		File inputFile = new File(fileName);
		
		File chkInputFile = new File(chkFileName);
		
		pkfile=checkFileIsNull(inputFile);
		chkfile=checkFileIsNull(chkInputFile);
				
		
		if(pkfile==false && chkfile==true){
			Statement stmt=connection.createStatement();
			stmt.executeUpdate("update code_library cl set cl.attribute1='N' where cl.codeno='SDBDateFile' and cl.itemno='20'");
			stmt.close();
			throw new Exception("�����ļ�Ϊ�գ�chk�ļ���Ϊ�գ����飡");
		}else if(pkfile==true && chkfile==false) {
			Statement stmt=connection.createStatement();
			stmt.executeUpdate("update code_library cl set cl.attribute1='N' where cl.codeno='SDBDateFile' and cl.itemno='20'");
			stmt.close();
			throw new Exception("�����ļ���Ϊ�գ�chk�ļ����գ����飡");
		}else if(pkfile==true && chkfile==true) {
			Statement stmt=connection.createStatement();
			stmt.executeUpdate("update code_library cl set cl.attribute1='N' where cl.codeno='SDBDateFile' and cl.itemno='20'");
			stmt.close();
		}else{
			Statement stmt=connection.createStatement();
			stmt.executeUpdate("update code_library cl set cl.attribute1='Y' where cl.codeno='SDBDateFile' and cl.itemno='20'");
			stmt.close();
		}
		
	}
	
	/**
	 * У���ļ��Ƿ�Ϊ��
	 * 
	 * @param file  
	 * @return ���ļ�����true ���ǿ� ����false
	 * @throws IOException
	 */
	private Boolean checkFileIsNull(File file) throws IOException {
		String sLine;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file)));
			if ((sLine = reader.readLine()) != null) {
					return false;
			} else {
				return true;
			}
		} catch (IOException ex) {
			throw new IOException();
		} finally {
			if (reader != null)
				reader.close();
		}
	}
	

	/**
	 * ת������
	 * @param sDate
	 * @return
	 */
	public String turnDateFormat(String sDate){
		String sReturn = sDate.substring(0,4)+"/"+sDate.substring(4,6)+"/"+sDate.substring(6,8);
		return sReturn;
	}
	
/**
 * �˶�ICSӪҵ����
 * @author EX-WANLONG001
 * @throws Exception
 * */	
	public boolean checkICSDate() throws Exception{
		if("Y".equals(RGBZ)){
			isSendFlag=true;
			logger.info("============�˹���������У�飬�����ļ���=============");
		}else{
			SWESBInstance esb=new SWESBInstance();
			CompositeData compositeData=esb.selectBusinessDate();
			String status = DataConvert.toString((String)ESBInstance.getValue(compositeData, "RET_STATUS"));//����״̬,�ɹ�ΪS,ʧ��ΪF
			String msg = DataConvert.toString((String)ESBInstance.getValue(compositeData, "RET_MSG"));//�������������׳ɹ�����ʧ��ԭ��
			if(!"S".equals(status)){
				throw new Exception("��ȡICSӪҵ����ʧ�ܣ�������ʾ����"+msg+"����");
			}else{
				String sICSdate = DataConvert.toString((String)ESBInstance.getValue(compositeData, "BOOKING_DATE"));//�������� YYYYMMDD
				String sRCPMDate=DateTools.getStringDate(deductDate);
				if(sICSdate.equals(sRCPMDate)) isSendFlag=true;
			}
		}
		return isSendFlag;
	}
}
