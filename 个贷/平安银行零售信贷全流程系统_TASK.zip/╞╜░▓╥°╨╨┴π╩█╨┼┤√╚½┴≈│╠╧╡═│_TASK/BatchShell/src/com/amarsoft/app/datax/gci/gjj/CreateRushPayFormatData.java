package com.amarsoft.app.datax.gci.gjj;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.BatchConstant;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.LoanAccount;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.impl.szpab.esb.ESBTransaction;
import com.amarsoft.app.datax.gci.RepayDataSplit.IRepayDataSplit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class CreateRushPayFormatData extends CommonExecuteUnit{

	private int commitNum ;
	private int deductDateNum = 0;
	private int icount = 0;
	HashMap<String ,IRepayDataSplit> repayDataSplitMap;
	private PreparedStatement psSelectSql1;
	private PreparedStatement psSelectSql2;
	private PreparedStatement psSelectSql3;
	private PreparedStatement psSelectSql4;
	private PreparedStatement psSelectSql5;
	private PreparedStatement psSelectSql6;//��ʼ�����õ��ڴ�
	private PreparedStatement psSelectSql7;//��ʼ��С΢����
	
	
	
	
	public int execute() {
		
		try{
			String sInit = super.init();

			//��̬���������������Ŵ���ˮ��
			BatchConstant.DEDUCT_SERIAL_NO = 0;

			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String delSql="call dbmgr.truncate_table ('RCPMDATA','PAMS_AS400') ";
//			String delSql="delete from PAMS_AS400";
				logger.info("��� PAMS_AS400:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("���PAMS_AS400������� ");
				psDelSql.close();
				initPs();
				logger.info("����һ�㻹����������......");
				initFormatPara();
				formatDeductData();
				logger.info("������һ�㻹����������"+icount+"����");
				logger.info("����һ�㻹������������ɣ�");

				logger.info("������ǰ������������......");
				formatAheadDeductData();
				logger.info("������ǰ��������������ɣ�"); 
				
				closePs();
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}

	public void initFormatPara() throws Exception{
		
		repayDataSplitMap=new HashMap<String ,IRepayDataSplit>();
		Statement stmt=connection.createStatement();
		ResultSet rs=stmt.executeQuery("select codeNo,ItemNo,ItemName,SortNo,IsInUse,ItemAttribute " +
				" from Code_Library where CodeNo = 'SplitData' and IsInuse='1' ");
		while(rs.next()){
			String className = rs.getString("ItemAttribute");//������
			String transType= rs.getString("ItemNo");//������������
			className = className.trim();
			Class c=Class.forName(className);
			repayDataSplitMap.put(transType,(IRepayDataSplit)c.newInstance());
		}
		rs.close();
		stmt.close();
	}
	
	private void formatDeductData() throws Exception
	{
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,BusinessSerialno,TransSerialno,BankFlag,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		
		String selectSql = "select lb.putoutno,lb.orgid,lb.businesstype,nvl(bc.PayType,'0') as PayType,nvl(lb.disdate,'2009/10/10') as disdate,nvl(lb.bankflag,'PAB') as bankflag ,bt.decisionscript5,gc.PayAmt"+
         " from loan_balance lb,business_contract bc,business_type bt , ( select LoanNo,sum(PayAmt) as PayAmt from ( select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') union all select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_ZTOB where inputdate = '"+this.deductDate+"' )where 1=1 group by LoanNo) gc "+
         " where lb.contractserialno=bc.serialno  and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'1')"+
         " and lb.businesstype = bt.typeno and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) "+
         " and exists (select 1 from deduct_data dd where lb.putoutno = dd.putoutno)"+
         " union all"+
         " select lb.putoutno,lb.orgid,lb.businesstype,nvl(bc.PayType,'0') as PayType,nvl(lb.disdate,'2009/10/10') as disdate,nvl(lb.bankflag,'PAB') as bankflag  ,bt.decisionscript5,gc.PayAmt"+
         " from loan_balance lb,business_contract bc,business_type bt , ( select LoanNo,sum(PayAmt) as PayAmt from ( select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') union all select LoanNo,PayAmt-nvl(UseAmt,0.0) as PayAmt from GJJ_ZTOB where inputdate = '"+this.deductDate+"' )where 1=1 group by LoanNo) gc "+
         " where lb.contractserialno=bc.serialno  and getLoanNo(LB.PutOutNo) = getGjjLoanNo(GC.LoanNo,'2')"+
         " and lb.businesstype = bt.typeno and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null)"+
         " and exists (select 1 from deduct_data dd where lb.putoutno = dd.putoutno)"+
         " order by decisionscript5";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			
			String sPutOutNo = rs.getString("putoutno");			
			String sOrgid = rs.getString("orgid");	
			String sBankFlag = rs.getString("bankflag");
			double PayAmt= DataConvert.toDouble(rs.getString("PayAmt"));
			LoanAccount loanAccount = new LoanAccount();	
			loanAccount.setSPutOutNo(sPutOutNo);
			loanAccount.setOrgID(OrgInfoConfig.getMainFrameOrgId(sOrgid));
            

			initAllDeductList(loanAccount);
			
			String sKey = getSkey("DeductData",rs.getString("businesstype"),rs.getString("PayType"),rs.getString("disdate"),sBankFlag);
			IRepayDataSplit iRepayDataSplit =  repayDataSplitMap.get(sKey);			
			
			ArrayList<PamsAs400>  pamsAs400List =iRepayDataSplit.execute(loanAccount);
			for(int i=0;i<pamsAs400List.size();i++)
			{
				PamsAs400 pamsAs400 = pamsAs400List.get(i);
				String temp=ESBTransaction.getBZSerialNo(connection);
				String transSerialno=temp;
				String businessSerialno=transSerialno;
				if(PayAmt==0) break;
				if(PayAmt>=pamsAs400.getAmount())
				{
				 psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,pamsAs400.getSPutOutNo(),pamsAs400.getSCurrency(),pamsAs400.getSPayType(),pamsAs400.getAmount(),
						pamsAs400.getSDudectAccNo(),pamsAs400.getSRelativeAccNo(),pamsAs400.getDeductSerialNo(),pamsAs400.getAmountAttribute(),pamsAs400.getSterm(),pamsAs400.getSaheadSerialNo(),loanAccount.getOrgID(),businessSerialno,transSerialno,sBankFlag,"1");
				 PayAmt-=pamsAs400.getAmount();
				}else
				{
				 psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,pamsAs400.getSPutOutNo(),pamsAs400.getSCurrency(),pamsAs400.getSPayType(),PayAmt,
								pamsAs400.getSDudectAccNo(),pamsAs400.getSRelativeAccNo(),pamsAs400.getDeductSerialNo(),pamsAs400.getAmountAttribute(),pamsAs400.getSterm(),pamsAs400.getSaheadSerialNo(),loanAccount.getOrgID(),businessSerialno,transSerialno,sBankFlag,"1");
				 PayAmt=0;
				}
			}
			
			ArrayList<BatchErrorRecord>  batchErrorRecordList =iRepayDataSplit.getErrorList();
			for(int i=0;i<batchErrorRecordList.size();i++)
			{
				BatchErrorRecord batchErrorRecord = batchErrorRecordList.get(i);
				batchErrorRecord.setInputDate(deductDate);
				batchErrorRecord.errorRecord(connection);
			}
			
			
			 if(deductDateNum>=commitNum)
			 {
				 psInsertPamsAs400.executeBatch();
				 deductDateNum=0;
				 logger.info("�ѻ���һ�㻹������"+icount+"����");
				 
			 }
		}
		 psInsertPamsAs400.executeBatch();
		 rs.close();
		 psInsertPamsAs400.close();
		 psSelectSql.close();
	}
	
	private void dealFareList(LoanAccount loanAccount, Connection connection) throws SQLException {
		//���û�����۱�����Ϣ����
		if(loanAccount.getDeductdataList().size() == 0){
			if(loanAccount.getFareDetailList().size() !=0 || loanAccount.getFareDetailList() != null){
				ArrayList<FareDetaill> fareDetailList = loanAccount.getFareDetailList();
				//ѭ��������ö�Ӧ���ڴ�
				for(int i=0;i<fareDetailList.size();i++){
					FareDetaill fareDetail = fareDetailList.get(i);
					psSelectSql6.setString(1,fareDetail.getPutOutNo() );
					psSelectSql6.setString(2,fareDetail.getPayDate());
					ResultSet rs = psSelectSql6.executeQuery();
					while(rs.next()){
						fareDetail.setSterm(rs.getInt("sterm"));
					}
					rs.close();
				}
			}
		}
		
	}
	
	private void dealAcctFeeInfoList(LoanAccount loanAccount, Connection connection) throws SQLException {
		//���û�����۱�����Ϣ����
		if(loanAccount.getDeductdataList().size() == 0){
			if(loanAccount.getFareDetailList().size() !=0 || loanAccount.getFareDetailList() != null){
				ArrayList<AcctFeeInfoBatch> acctFeeInfoList = loanAccount.getAcctFeeInfoList();
				//ѭ��������ö�Ӧ���ڴ�
				for(int i=0;i<acctFeeInfoList.size();i++){
					AcctFeeInfoBatch acctFeeInfo = acctFeeInfoList.get(i);
					psSelectSql6.setString(1,acctFeeInfo.getObjectNo() );
					psSelectSql6.setString(2,acctFeeInfo.getPayDate());
					ResultSet rs = psSelectSql6.executeQuery();
					while(rs.next()){
						acctFeeInfo.setSterm(rs.getInt("sterm"));
					}
					rs.close();
				}
			}
		}
		
	}

	
	private String getSkey(String KeyType,String sBusinessType,String sPayType,String sDisDate,String sBankFlag)
	{
		String sReturn = "";
		if("1150020".equals(sBusinessType)&&DateTools.getDays(sDisDate,deductDate)<=0){
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "GJZX";
			else
				sReturn = "GJZXTQHK";
		}
		else if("1190030".equals(sBusinessType))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "WTDK";
			else
				sReturn = "WTTQHK";
		}
		else if("1150060".equals(sBusinessType) && "Q02".equals(sPayType))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "XB36HK";
			else
				sReturn = "XB36TQHK";
		}
		else if("1120030".equals(sBusinessType))
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "CDHK";
			else
				sReturn = "CDTQHK";
		}
		else if("1140100".equals(sBusinessType))
		{
			if("DeductData".equalsIgnoreCase(KeyType)){
				sReturn = "XYDHK";
			}else if("AheadDeductData".equalsIgnoreCase(KeyType)&&"SDB".equals(sBankFlag)){
				sReturn = "SDBXYDTQHK";
			}else{
				sReturn = "XYDTQHK";
			}
		}
		else
		{
			if("DeductData".equalsIgnoreCase(KeyType))
				sReturn = "YBHK";
			else
				sReturn = "YBTQHK";
		}
		return sReturn;
	}
	
	public PreparedStatement insertPsPamsAs400(PreparedStatement psInsertSql,String sPutOutNo,String sCurrency,String sPayType,double amount,String sDudectAccNo,String sRelativeAccNo,String deductSerialNo,String sAmountAttribute,int Sterm,String sAheadSerialNo,String orgid,String sBusinessSerialno,String sTransSerialno,String BankFlag,String DeductAccno2) throws SQLException
	{
		icount++;
		//SerialNo
		psInsertSql.setInt(1,icount);
		//PutOutNo
		psInsertSql.setString(2,sPutOutNo);
		//Currency
		psInsertSql.setString(3,sCurrency);
		//PayType
		psInsertSql.setString(4,sPayType);
		//PayAmount
		psInsertSql.setDouble(5,amount);
		//DeductAccNo
		psInsertSql.setString(6,sDudectAccNo);
		//RelativeAccNo
		psInsertSql.setString(7,sRelativeAccNo);
		//AheadSerialNo
		psInsertSql.setString(8,sAheadSerialNo);
		//DeductSerialNo
		psInsertSql.setString(9,deductSerialNo);
		//AmountAttribute
		psInsertSql.setString(10,sAmountAttribute);
		//Sterm
		psInsertSql.setInt(11,Sterm);
		psInsertSql.setString(12,orgid);
		psInsertSql.setString(13,sBusinessSerialno);
		psInsertSql.setString(14,sTransSerialno);
		psInsertSql.setString(15, BankFlag);
		psInsertSql.setString(16, "");
		psInsertSql.addBatch();
		deductDateNum++;
		
		return psInsertSql;
	}

	
	private void initPs() throws SQLException
	{
		String selectSql1 = " select PutOutNo,STerm,Currency,PayCurrentCorp,ActualCurrentCorp," +
		"  PayDefaultCorp,ActualDefaultCorp,PayOverDueCorp,ActualOverDueCorp, " +
		"  PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, " +
		"  PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,DeductAccNo,PayDate" +
		" FROM DEDUCT_DATA " +
		" where putoutno = ? " +
		" order by sterm ";
		psSelectSql1 = connection.prepareStatement(selectSql1);
				
		String selectSql2 = " select ChangeSerialNo,PutOutNo,Currency,DeductAccNo,PayDate,PayCurrentCorp, " +
		"  PayInte,PayPoundage,DealFlag " +
		" from ahead_deduct_data " +
		" where putoutno = ? " +
		" order by sterm ";
		psSelectSql2 = connection.prepareStatement(selectSql2);
				
		String selectSql3 = " select PutOutNo,PayDate,PayMoney,ActualMoney,AccDate,Currency  " +
		"  from fare_detail " +
		" where putoutno = ? and offFlag = '0' " +
		" order by PayDate ";
		psSelectSql3 = connection.prepareStatement(selectSql3);
		
		String selectSql4 = "  select lb.OrgID,lb.putoutno,lb.LoanAccNo,lb.TrustAccNo,nvl(bp.TransFerAccNo,'') as TransFerAccNo,lb.Currency,lb.BusinessType,nvl(lb.DisDate,'2009/09/10') as DisDate  " +
		" from loan_balance lb,business_putout bp "+
		" where lb.putoutno = ? and lb.putoutno = bp.serialno(+) ";
		psSelectSql4 = connection.prepareStatement(selectSql4);
		
		
		String selectSql5 = "  select nvl(ii.TrustBankNo,'') as TrustBankNo " +
		" from loan_balance lb,business_contract bc,business_applicant bap,ind_info ii " +
		" where lb.contractserialno = bc.serialno " +
		" and bc.relativeserialno = bap.objectno and bap.objecttype = 'CBCreditApply' " +
		" and bap.applicantid = ii.customerid and ii.isUseBankNo = '1' " +
		" and lb.putoutno = ? ";
		psSelectSql5 = connection.prepareStatement(selectSql5);

		//�¼ӣ����С�����ȿ��˱�����Ϣ��û�п۷��õ����,��ʼ����ȥ�ڴΣ������������������
		String selectSql6 = " SELECT sterm FROM loanback_status WHERE putoutno = ? AND paydate = ? AND aheadnum = 0";
		psSelectSql6 = connection.prepareStatement(selectSql6);
		//�˴����ܽ�ȥ�ķ��ÿ϶��Ǳ��ڴ����������û�У��ʸ������ʻ�һ����һ��
		String selectSql7 = "select afi.SerialNo,afi.FeeAccountNo,afi.ObjectNo,fd.PayDate,afi.FeeType,fd.PayMoney,fd.ActualMoney,fd.AccDate,fd.Currency " +
				" from Fare_Detail fd,Acct_Fee_Info afi where fd.PutOutNo = afi.SerialNo and afi.objectNo = ? " +
				" and offFlag = '0' and afi.AccountFlag = '1' order by fd.PayDate,afi.SerialNo";
		psSelectSql7 = connection.prepareStatement(selectSql7);
		
	}
	
	private void closePs() throws SQLException
	{
		psSelectSql1.close();
		psSelectSql2.close();
		psSelectSql3.close();
		psSelectSql4.close();
		psSelectSql5.close();
		psSelectSql6.close();
		psSelectSql7.close();
	}
	
	private void initAllDeductList(LoanAccount loanAccount) throws SQLException
	{
		//����ۿ�����
		initDeductList(loanAccount);
		//��ǰ����ۿ�����
		initAheadDeductList(loanAccount);
		//δ����������
		initFareDetailList(loanAccount);
		//δ��С΢��������
		initAcctFeeInfo(loanAccount);
		//����˻�Map
		initAccountInfoMap(loanAccount);
	}
	
	/*
	 * ��ʼ��һ�㻹������
	 * */
	private void initDeductList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<DeductData> deductdataList = new ArrayList<DeductData>();
		
		psSelectSql1.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql1.executeQuery();
		while(rs.next())
		{
			DeductData deductData = new DeductData();
			deductData.setPutOutNo(rs.getString("PutOutNo"));
			deductData.setSTerm(rs.getInt("STerm"));
			deductData.setCurrency(rs.getString("Currency"));
			deductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			deductData.setActualCurrentCorp(rs.getDouble("ActualCurrentCorp"));
			deductData.setPayDefaultCorp(rs.getDouble("PayDefaultCorp"));
			deductData.setActualDefaultCorp(rs.getDouble("ActualDefaultCorp"));
			deductData.setPayOverDueCorp(rs.getDouble("PayOverDueCorp"));
			deductData.setActualOverDueCorp(rs.getDouble("ActualOverDueCorp"));
			deductData.setPayInte(rs.getDouble("PayInte"));
			deductData.setActualInte(rs.getDouble("ActualInte"));
			deductData.setPayInnerInte(rs.getDouble("PayInnerInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualInnerInte"));
			deductData.setPayOutInte(rs.getDouble("PayOutInte"));
			deductData.setActualInnerInte(rs.getDouble("ActualOutInte"));
			deductData.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
			deductData.setActualInnerInteFine(rs.getDouble("ActualInnerInteFine"));
			deductData.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
			deductData.setActualOutInteFine(rs.getDouble("ActualOutInteFine"));
			deductData.setDeductAccNo(rs.getString("DeductAccNo"));
			deductData.setPayDate(rs.getString("PayDate"));
			deductdataList.add(deductData);		
		}
		rs.close();

		loanAccount.setDeductdataList(deductdataList);
	}

	/*
	 * ��ʼ����ǰ����ۿ�����
	 * */
	private void initAheadDeductList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<AheadDeductData> aheadDeductdataList = new ArrayList<AheadDeductData>();
		
		psSelectSql2.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql2.executeQuery();
		while(rs.next())
		{
			AheadDeductData aheadDeductData = new AheadDeductData();
			aheadDeductData.setPutOutNo(rs.getString("PutOutNo"));
			aheadDeductData.setPayDate(rs.getString("PayDate"));
			aheadDeductData.setCurrency(rs.getString("Currency"));
			aheadDeductData.setDeductAccNo(rs.getString("DeductAccNo"));
			aheadDeductData.setPayCurrentCorp(rs.getDouble("PayCurrentCorp"));
			aheadDeductData.setActualCurrentCorp(0);
			aheadDeductData.setPayInte(rs.getDouble("PayInte"));
			aheadDeductData.setActualInte(0);
			aheadDeductData.setPayPoundage(rs.getDouble("PayPoundage"));
			aheadDeductData.setActualPoundage(0);
			aheadDeductData.setChangeSerialNo(rs.getString("ChangeSerialNo"));
			aheadDeductData.setDeductDate(deductDate);
			aheadDeductdataList.add(aheadDeductData);
		}
		rs.close();
		
		loanAccount.setAheadDeductdataList(aheadDeductdataList);
	}

	/*
	 * ��ʼ����������
	 * */
	private void initFareDetailList(LoanAccount loanAccount) throws SQLException
	{
		ArrayList<FareDetaill> fareDetailList = new ArrayList<FareDetaill>();
		
		psSelectSql3.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql3.executeQuery();
		while(rs.next())
		{
			FareDetaill fareDetail = new FareDetaill();
			fareDetail.setPutOutNo(rs.getString("PutOutNo"));
			fareDetail.setPayDate(rs.getString("PayDate"));
			fareDetail.setCurrency(rs.getString("Currency"));
			fareDetail.setPayMoney(rs.getDouble("PayMoney")-rs.getDouble("ActualMoney"));
			fareDetail.setActualMoney(0);
			fareDetailList.add(fareDetail);
		}
		rs.close();
		
		loanAccount.setFareDetailList(fareDetailList);
		//���޸Ĳ����������ݣ����ֻ�з���(ҵ���ϲ�����֣���ΪС���Ŀۿ�˳���Ǳ���->��Ϣ->���𣬵���400�Ķ��̲߳������ƻᵼ��������ǧ����ʱ������ȿ۱�����Ϣ�����)����
		//��deductDateListû�����ݣ���Ҫ��������ã��ӷ��ö�Ӧ���ڴμ��ϡ�modify dxu1 2011-05-17
		dealFareList(loanAccount,connection);
	}
	//С΢����
	private void initAcctFeeInfo(LoanAccount loanAccount) throws SQLException{
		ArrayList<AcctFeeInfoBatch> acctFeeInfoList = new ArrayList<AcctFeeInfoBatch>();
		psSelectSql7.setString(1, loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql7.executeQuery();
		while(rs.next()){
			AcctFeeInfoBatch acctFeeInfoBatch = new AcctFeeInfoBatch();
			acctFeeInfoBatch.setSerialNo(rs.getString("SerialNo"));
			acctFeeInfoBatch.setObjectNo(rs.getString("ObjectNo"));
			acctFeeInfoBatch.setPayDate(rs.getString("PayDate"));
			acctFeeInfoBatch.setPayMoney(rs.getDouble("PayMoney")-rs.getDouble("ActualMoney"));
			acctFeeInfoBatch.setCurrency(rs.getString("Currency"));
			acctFeeInfoBatch.setFeeAccountNo(rs.getString("FeeAccountNo"));
			acctFeeInfoBatch.setActualMoney(0);
			acctFeeInfoList.add(acctFeeInfoBatch);
		}
		rs.close();
		loanAccount.setAcctFeeInfoList(acctFeeInfoList);
		
		dealAcctFeeInfoList(loanAccount,connection);
	}
	/*
	 * ��ʼ������˻�
	 * */
	private void initAccountInfoMap(LoanAccount loanAccount) throws SQLException
	{
		HashMap<String,DeductAccountInfo> accountInfoMap = new HashMap<String,DeductAccountInfo>();
		
		psSelectSql4.setString(1,loanAccount.getSPutOutNo());
		ResultSet rs = psSelectSql4.executeQuery();
		while(rs.next())
		{
			//������ʽ��˻�
			accountInfoMap.put("DeductAccNo",new DeductAccountInfo("DeductAccNo",rs.getString("LoanAccNo")));
			
			//400�м��˻�
			String sRelativeAccNo = "";
			try
			{
				sRelativeAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),AccountConstants.Ahead_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type);
			}
			catch(Exception ex)
			{
				sRelativeAccNo = "";
			}
			accountInfoMap.put("RelativeAccNo",new DeductAccountInfo("RelativeAccNo",sRelativeAccNo));
			
			//ί�д��������ȫ��
			String sOrgTrustAccNo = "";
			try
			{
				sOrgTrustAccNo = OrgInfoConfig.getAccountNo(rs.getString("OrgID"),"",rs.getString("Currency"),AccountConstants.Org_Save_Type);
			}
			catch(Exception ex)
			{
				sOrgTrustAccNo = "";
			}
			accountInfoMap.put("OrgTrustAccNo",new DeductAccountInfo("OrgTrustAccNo",sOrgTrustAccNo));
			
			//������ѧ������Ϣ�˻�
			String sDsInteAccNo = "";
			try
			{
			//	logger.info("====XINX=== "+rs.getString("putoutno")+"===="+rs.getString("DisDate").compareTo(deductDate)+"==="+deductDate+"====="+rs.getString("DisDate"));
				if("1150020".equalsIgnoreCase(rs.getString("BusinessType")) && rs.getString("DisDate").compareTo(deductDate)>0){
					sDsInteAccNo = OrgInfoConfig.getAccountNo(rs.getString("orgID"),AccountConstants.Student_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Account_Type_Student);
					logger.info("��Ϣ�����˺ţ�"+sDsInteAccNo);
				}else{
					sDsInteAccNo = rs.getString("deductAccNo");
					logger.info("��Ϣ�����˺ţ�"+sDsInteAccNo);
				}
			}
			catch(Exception ex)
			{
				sDsInteAccNo = "";
			}
			accountInfoMap.put("DsInteAccNo",new DeductAccountInfo("DsInteAccNo",sDsInteAccNo));		
			
			
			//ί�����ʽ�
			String sTrustorAccNo = rs.getString("TrustAccNo");
			accountInfoMap.put("TrustorAccNo",new DeductAccountInfo("TrustorAccNo",sTrustorAccNo));
			String sTrustBankAccNo = "";
			
			psSelectSql5.setString(1,loanAccount.getSPutOutNo());
			ResultSet rsTmp = psSelectSql5.executeQuery();
			if(rsTmp.next())
			{
				sTrustBankAccNo = rsTmp.getString("TrustBankNo");
			}
			rsTmp.close();
			accountInfoMap.put("TrustBankAccNo",new DeductAccountInfo("TrustBankAccNo",sTrustBankAccNo));
			
			//������ȡ�˺�
			String sXBFareAccNo = rs.getString("TransFerAccNo");
			accountInfoMap.put("XBFareAccNo",new DeductAccountInfo("XBFareAccNo",sXBFareAccNo));
			
			//���ÿ����������˻�
			String sCreditCardFAccNo = "";
			try
			{
				sCreditCardFAccNo = OrgInfoConfig.getAccountNo("100200",AccountConstants.CREDIT_SUBJECTNO,rs.getString("Currency"),AccountConstants.Org_Credit_Type);
			}
			catch(Exception ex)
			{
				sCreditCardFAccNo = "";
			}
			accountInfoMap.put("CreditCardFAccNo",new DeductAccountInfo("CreditCardFAccNo",sCreditCardFAccNo));
			
			
		}
		rs.close();
		
		loanAccount.setAccountInfoMap(accountInfoMap);
	}
	
	
	

	
	/**
	 * ��ѯ����PAB��SDB�����ֱ�־
	 * @param  PutOutNo
	 * @return sBankFlag
	 * @throws Exception
	 */
	public String selectBankFlag(String ObjectNo)throws Exception{
		String sBankFlag="";
		String sSql=" select bc.bankflag From business_contract bc where bc.serialno in(select lr.objectno From lawcase_relative lr where lr.relativeserialno " +
				  " =(select serialno From law_case lc where lc.serialno =(select objectno From account_receivable ar where ar.serialno= ?))) ";
		PreparedStatement ps = connection.prepareStatement(sSql);
		ps.setString(1, ObjectNo);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			sBankFlag = rs.getString("bankflag");
		}
		ps.close();
		rs.close();
		return sBankFlag;
	}
	
	private void formatAheadDeductData() throws Exception
	{
	        String sDeductAccno2="";
		String insertSql = " INSERT INTO pams_as400(SerialNo,PutOutNo,Currency,PayType,PayAmount,DeductAccNo,RelativeAccNo,AheadSerialNo,DeductSerialNo,AmountAttribute,Sterm,orgid,businessSerialno,transSerialno,BankFlag,DeductAccno2)"
			+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement psInsertPamsAs400 = connection.prepareStatement(insertSql);
		
		String selectSql = " select lb.putoutno,lb.orgid,lb.businesstype,nvl(bc.PayType,'0') as PayType,nvl(lb.disdate,'2009/10/10') as disdate ,nvl(lb.bankflag,'PAB') as bankflag " +
				" from loan_balance lb,business_contract bc,business_type bt " +
				" where lb.contractserialno=bc.serialno " +
				"  and lb.businesstype = bt.typeno and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) " +
				"  and exists (select 1 from ahead_deduct_data ad where lb.putoutno = ad.putoutno) " +
				" order by bt.decisionscript2 ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			
			ArrayList<PamsAs400> pamsAs400List = new ArrayList<PamsAs400>();
			String sPutOutNo = rs.getString("putoutno");
			String sBankFlag = rs.getString("bankflag");//����PAB��SDB�����ֱ�־  modify by jxie  2011-09-27	
			String sOrgid = rs.getString("orgid");	
			LoanAccount loanAccount = new LoanAccount();	
			loanAccount.setSPutOutNo(sPutOutNo);
			loanAccount.setOrgID(OrgInfoConfig.getMainFrameOrgId(sOrgid));


			initAllDeductList(loanAccount);

			
			String sKey = getSkey("AheadDeductData",rs.getString("businesstype"),rs.getString("PayType"),rs.getString("disdate"),sBankFlag);
			IRepayDataSplit iRepayDataSplit =  repayDataSplitMap.get(sKey);	
			
			pamsAs400List = iRepayDataSplit.execute(loanAccount);
			for(int i=0;i<pamsAs400List.size();i++)
			{
				PamsAs400 pamsAs400 = pamsAs400List.get(i);
				String temp=ESBTransaction.getBZSerialNo(connection);
				String transSerialno=temp;
				String businessSerialno=transSerialno;
				psInsertPamsAs400 = insertPsPamsAs400(psInsertPamsAs400,pamsAs400.getSPutOutNo(),pamsAs400.getSCurrency(),pamsAs400.getSPayType(),pamsAs400.getAmount(),
						pamsAs400.getSDudectAccNo(),pamsAs400.getSRelativeAccNo(),pamsAs400.getDeductSerialNo(),pamsAs400.getAmountAttribute(),pamsAs400.getSterm(),pamsAs400.getSaheadSerialNo(),loanAccount.getOrgID(),businessSerialno,transSerialno,sBankFlag,sDeductAccno2);
			}
			
			
			ArrayList<BatchErrorRecord>  batchErrorRecordList =iRepayDataSplit.getErrorList();
			for(int i=0;i<batchErrorRecordList.size();i++)
			{
				BatchErrorRecord batchErrorRecord = batchErrorRecordList.get(i);
				batchErrorRecord.setInputDate(deductDate);
				batchErrorRecord.errorRecord(connection);
			}
			
			 if(deductDateNum>=commitNum)
			 {
				 psInsertPamsAs400.executeBatch();
				 deductDateNum=0;
				 logger.info("�ѻ���һ�㻹������"+icount+"����");
				 
			 }
		}
		 psInsertPamsAs400.executeBatch();
		 rs.close();
		 psInsertPamsAs400.close();
		 psSelectSql.close();
	}
	
}