package com.amarsoft.app.datax.gci.deductdata;


import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class Init extends CommonExecuteUnit {

	private int commitNum ;
	private String insertSql;
	private PreparedStatement psInsertSql;
	private int deductDateNum = 0;
	
	
	boolean ok = true; 
	

	
	public int execute() {
		
		try{
			super.init();
	
			logger.info("���ɲ�������.....");
			insertData();
			logger.info("��ʼ����");
		}catch(Exception ex){
			logger.debug(ex);
			ex.printStackTrace();
			ok = false;
		} 
		finally{
			clearResource();
			if(connection!=null)
				try {
					connection.close();
				} catch (SQLException e) {
					logger.debug(e);
				}
				connection = null;
		}
		
		if(ok){
			logger.info("������������ִ�гɹ���");
			return TaskConstants.ES_SUCCESSFUL;
		}else{
			logger.fatal("�����������ݣ�ִ�����ݿ����ʧ�ܣ�");
			return TaskConstants.ES_FAILED;
		}
	}

	private void insertData() throws SQLException
	{
		int i=0;
		insertSql = " insert into Finacing_Record(DeductAccNo,Lucre,CalcDate,Currency)"
		      + " values(?,?,?,?) ";
		psInsertSql = connection.prepareStatement(insertSql);
		while(i<100000)
		{
			i++;
			double dd = 1.0;
			dd += 0.1;
			String acountNo = "100"+i;
			psInsertSql.setString(1,acountNo);
			psInsertSql.setDouble(2,dd);
			psInsertSql.setString(3,deductDate);
			psInsertSql.setString(4,"01");
			psInsertSql.addBatch();
			
			if(deductDateNum>commitNum)
			{
				psInsertSql.executeBatch();
				connection.commit();
				deductDateNum=0;
			}
		}
		psInsertSql.executeBatch();
		connection.commit();
	}

}
