package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.app.datax.gci.BatchConstant;

public class RepayDataSplit1140100 extends BasicRepayDataSplit {
	@Override
	public boolean preCheck(ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String,DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
			//���޸�ȡ��ݺŷ�ʽ�����ֻ�з��ã�deductDateListû�����ݣ�������modify dxu1 2010-11-27
			String sPutOutNo = "";
			if(deductDateList.size()==0 ){
				if(fareDetailList!=null && fareDetailList.size()!=0){
					sPutOutNo = fareDetailList.get(0).getPutOutNo();
				}
				else
				{
					return false;
				}
			}else{
				sPutOutNo = deductDateList.get(0).getPutOutNo();
			}
			boolean dReturn = true;
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			if(DeductAccNo == null||DeductAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"�ý�ݿۿ��˺Ų����ڣ�");
				dReturn = false;
			}
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			if(RelativeAccNo==null||RelativeAccNo.length()==0)
			{
				ErrorRecord(sPutOutNo,"�ý��400�����˻������ڣ�");
				dReturn = false;
			}
			return dReturn;
		
	}


	@Override
	public ArrayList<PamsAs400> executeSplit(
			ArrayList<DeductData> deductDateList,
			ArrayList<AheadDeductData> aheadDeductdataList,
			ArrayList<FareDetaill> fareDetailList,
			ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
			HashMap<String, DeductAccountInfo> accountMap) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<PamsAs400> pamsAs400ArrayList = new ArrayList<PamsAs400>();
		if(!preCheck(deductDateList,aheadDeductdataList,fareDetailList,acctFeeInfoList,accountMap))
			return pamsAs400ArrayList;
		else
		{
				
			//�ͻ������ʽ��˻�
			String DeductAccNo = accountMap.get("DeductAccNo").getAccountNo();
			String DeductAccNo1 = accountMap.get("DeductAccNo1")==null?"":accountMap.get("DeductAccNo1").getAccountNo();
			String DeductAccNo2 = accountMap.get("DeductAccNo2")==null?"":accountMap.get("DeductAccNo2").getAccountNo();
			//��400������
			String RelativeAccNo = accountMap.get("RelativeAccNo").getAccountNo();
			//�˺Ź�����
			double fareAmount = returnFareAmount(fareDetailList);
			if(fareAmount >0){
				String putoutno = "";
				String currency = "";
				for(int i=0;i <fareDetailList.size();i++ ){
					FareDetaill fareDetail = fareDetailList.get(i);
					putoutno = fareDetail.getPutOutNo();
					currency = fareDetail.getCurrency();
					if(putoutno!=null &&currency!=null) break;
				}
				
				PamsAs400 pamsAs400 = new PamsAs400(putoutno,currency,fareAmount,
						DeductAccNo,RelativeAccNo,createDeductSerialNo(),
						BatchConstant.AMOUNTATTRIBUTE_XYDFARE,0,
						BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL,"",DeductAccNo1,DeductAccNo2);
				
				pamsAs400ArrayList.add(pamsAs400);
			}
			//���������
			PamsAs400 pamsAs400 = new PamsAs400();		
			double amount = 0;
			for(int i=0;i<deductDateList.size();i++)
			{
				DeductData deductData = deductDateList.get(i);
				amount = amount
					+returnCorp(deductData)
					+returnInte(deductData)
					+returnFine(deductData);
				
				pamsAs400.setSPutOutNo(deductData.getPutOutNo());
				pamsAs400.setSCurrency(deductData.getCurrency());	
			}
			if(amount>0)
			{
				pamsAs400.setSterm(0);
				pamsAs400.setSPayType(BatchConstant.DEDUCTDATA_REPAYTYPE_NOALL);
				pamsAs400.setAmountAttribute(BatchConstant.AMOUNTATTRIBUTE_CUR);
				pamsAs400.setSDudectAccNo(DeductAccNo);
				pamsAs400.setSRelativeAccNo(RelativeAccNo);
				pamsAs400.setDeductSerialNo(createDeductSerialNo());
				pamsAs400.setAmount(amount);
				pamsAs400.setDeductAccNo1(DeductAccNo1);
				pamsAs400.setDeductAccNo2(DeductAccNo2);
			}
			if(amount > 0)
			{
				pamsAs400ArrayList.add(pamsAs400);
			}
			return pamsAs400ArrayList;
		}
	}

	//�����ܵ�Ӧ���˻������ѽ��
	private double returnFareAmount(ArrayList<FareDetaill> fareDetailList) {
		double fareAmount = 0.0;
		for(int i=0;i<fareDetailList.size();i++){
			FareDetaill fareDetail = fareDetailList.get(i);
			fareAmount += fareDetail.getPayMoney()-fareDetail.getActualMoney();
		}
		return fareAmount;
	}

}
