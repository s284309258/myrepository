package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;

import com.amarsoft.account.util.StringTools;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.app.mail.MailSend;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

public class BatchSendMsg extends CommonExecuteUnit{

	private int dealNum = 0;
	private int commitNum;
	private int icount = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{	
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				
				logger.info("���ͻ������Ѷ���.....");
				awokeDeduct();
				logger.info("���ͻ������Ѷ�����ɣ�");
				
				logger.info("���ͻ���ɹ����Ѷ���.....");
				awokeReturnSucceed();
				logger.info("���ͻ���ɹ����Ѷ�����ɣ�");
				
				logger.info("����Ƿ�����Ѷ���.....");
				awokeOverDueBalance();
				logger.info("����Ƿ�����Ѷ�����ɣ�");

				logger.info("�������ʱ������.....");
				awokeNewRate();
				logger.info("�������ʱ��������ɣ�");
				
				//logger.info("������ǰ����ʧ�ܶ���.....");
				//awokeAheadDeductFalse();//��ʱͣ�ò�ֳɲ��ֺ�ȫ������ɹ����ַ�ʽ
				//logger.info("������ǰ����ʧ�ܶ�����ɣ�");
				
				
	
				logger.info("����[ȫ��������]��ǰ����ʧ�ܶ���.....");
				aheadDeductFalse();
				logger.info("����[ȫ��������]��ǰ����ʧ�ܶ�����ɣ�");
				
				logger.info("����ȫ����ǰ����ɹ�����.....");
				allAheadDeductSucceed();
				logger.info("����ȫ����ǰ����ɹ�������ɣ�");
				
				logger.info("���Ͳ�����ǰ����ɹ�����.....");
				partAheadDeductSucceed();
				logger.info("���Ͳ�����ǰ����ɹ�������ɣ�");
				
				logger.info("���ͻ���ɹ������ڻ���ɹ��״���ʾ������.....");
				awokeReturnFalse();
				logger.info("���ͻ���ɹ������ڻ���ɹ��״���ʾ��������ɣ�");
				
				logger.info("������ǰ�������Ѷ���.....");
				awokeAheadDeduct();
				logger.info("������ǰ�������Ѷ��Ŷ�����ɣ�");
				
				
				
				/****���滹��δ���������ʼ�Ҳ���ڷ����ŵ�Ԫ*******/
				logger.info("���滹��δ���������ʼ���ʼ......");
				sendMailForManger();
				logger.info("���滹��δ���������ʼ����!");
				/****���滹��δ���������ʼ�Ҳ���ڷ����ŵ�Ԫ*******/
				
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//���ͻ������Ѷ���
	public void awokeDeduct() throws SQLException{

		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
						   " CustomerName,MobileTelephone,Attribute1,Attribute2,ExTime,EndTime" +
						   " from Message_Info where ModeNo = 'YX_LS09072901' and SucFlag = '0' ";
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = "YX_LS09072901";
			String sCustomerName = rs.getString("CustomerName");
			String sOrgName = rs.getString("OrgName");
			String sMonthpay = rs.getString("Attribute1");
			String sDeductDate = rs.getString("Attribute2");
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			paraHash.put("name", sCustomerName);
			paraHash.put("subbranch", sOrgName);
			paraHash.put("corpus", sMonthpay);
			paraHash.put("date", sDeductDate);
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		psSelectSql.close();
		dealNum=0;
	}

	//���ͻ���ɹ����Ѷ���
	private void awokeReturnSucceed() throws SQLException {
		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
				   " CustomerName,MobileTelephone,Attribute1,Attribute2,ExTime,EndTime" +
				   " from Message_Info where ModeNo = 'YX_LS09072902' and SucFlag = '0' ";
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = "YX_LS09072902";
			String sCustomerName = rs.getString("CustomerName");
			String sOrgName = rs.getString("OrgName");
			String sBalance = rs.getString("Attribute1");
			String sPatBalance = rs.getString("Attribute2");
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			paraHash.put("name", sCustomerName);
			paraHash.put("subbranch", sOrgName);
			paraHash.put("repayment", sPatBalance);
			paraHash.put("corpus", sBalance);
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		psSelectSql.close();
		dealNum=0;
	}
	
	//����Ƿ�����Ѷ���
	private void awokeOverDueBalance() throws SQLException {

		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
				   " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime" +
				   " from Message_Info where ModeNo = 'YX_LS09072903' and SucFlag = '0' ";
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = "YX_LS09072903";
			String sCustomerName = rs.getString("CustomerName");
			String sOrgName = rs.getString("OrgName");
			String sBalance = rs.getString("Attribute1");
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			paraHash.put("name", sCustomerName);
			paraHash.put("subbranch", sOrgName);
			paraHash.put("sum", sBalance);
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psSelectSql.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		dealNum=0;
	
	}
	
	//�������ʱ������
	private void awokeNewRate() throws SQLException {
		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
				   " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime" +
				   " from Message_Info where ModeNo = 'YX_LS09072904' and SucFlag = '0' ";
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = "YX_LS09072904";
			String sCustomerName = rs.getString("CustomerName");
			String sOrgName = rs.getString("OrgName");
			String sNewRate = rs.getString("Attribute1");
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			paraHash.put("name", sCustomerName);
			paraHash.put("subbranch", sOrgName);
			paraHash.put("newrate", sNewRate);
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psSelectSql.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		dealNum=0;
		
	}
	
	//������ǰ����ʧ�ܶ���
	private void awokeAheadDeductFalse() throws SQLException {
		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
				   " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime" +
				   " from Message_Info where ModeNo = 'YH_LS10090703' and SucFlag = '0' ";
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = "YH_LS10090703";
			String sCustomerName = rs.getString("CustomerName");
			String sOrgName = rs.getString("OrgName");
		
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psSelectSql.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		dealNum=0;
		
	}
	
	
	//������ǰ����ɹ�����[ȫ��������]
	private void aheadDeductFalse() throws SQLException {

		String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
		PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
		
		String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
				   " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime,ModeNo,InputDate" +
				   " from Message_Info where ModeNo in('YH_DK120529011','YH_DK120529003') and SucFlag = '0' ";
		System.out.println("������ǰ����ɹ�����[ȫ��������]:"+sQuerySql);
		PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next()){
			String sSerialNo = rs.getString("SerialNo");
			String sOrgID=rs.getString("OrgID");
			String sCustomerID=rs.getString("CustomerID");
			String sMobileTelephone=rs.getString("MobileTelephone");
			String sEndTime=rs.getString("EndTime");
			String sExTime=rs.getString("ExTime");
			String sMode = rs.getString("ModeNo");
			String sCustomerName = rs.getString("CustomerName");
			String sInputDate = rs.getString("InputDate");
			
			HashMap<String,String> paraHash = new HashMap<String,String>();
			paraHash.put("name", sCustomerName);
			paraHash.put("date", sInputDate);
			
			boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
			if(isSuc){
				psUpdateSqlSuc.setString(1,"1");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
				
			}else{
				psUpdateSqlSuc.setString(1,"2");
				psUpdateSqlSuc.setString(2, sSerialNo);
				psUpdateSqlSuc.addBatch();
			}
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psUpdateSqlSuc.executeBatch();
				dealNum = 0;
				logger.info("�Ѵ���"+icount+"����");
			}
			
		}
		rs.close();
		psSelectSql.close();
		psUpdateSqlSuc.executeBatch();
		psUpdateSqlSuc.close();
		dealNum=0;
	
	}
	
	//����ȫ����ǰ����ɹ�����[ȫ��]
	private void allAheadDeductSucceed() throws SQLException {
	    
	    String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
	    PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
	    
	    String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
                    	       " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime,ModeNo,InputDate" +
                    	       " from Message_Info where ModeNo ='YH_DK120529012' and SucFlag = '0' ";
	    System.out.println("����ȫ����ǰ����ɹ�����[ȫ��]:"+sQuerySql);
	    PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
	    ResultSet rs = psSelectSql.executeQuery();
	    while(rs.next()){
		String sSerialNo = rs.getString("SerialNo");
		String sOrgID=rs.getString("OrgID");
		String sCustomerID=rs.getString("CustomerID");
		String sMobileTelephone=rs.getString("MobileTelephone");
		String sEndTime=rs.getString("EndTime");
		String sExTime=rs.getString("ExTime");
		String sMode = rs.getString("ModeNo");
		String sCustomerName = rs.getString("CustomerName");
		String sInputDate = rs.getString("InputDate");
		
		HashMap<String,String> paraHash = new HashMap<String,String>();
		paraHash.put("name", sCustomerName);
		paraHash.put("date", sInputDate);
		
		boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
		if(isSuc){
		    psUpdateSqlSuc.setString(1,"1");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		    
		}else{
		    psUpdateSqlSuc.setString(1,"2");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		}
		dealNum++;
		icount++;
		
		if(dealNum>=commitNum)
		{
		    psUpdateSqlSuc.executeBatch();
		    dealNum = 0;
		    logger.info("�Ѵ���"+icount+"����");
		}
		
	    }
	    rs.close();
	    psSelectSql.close();
	    psUpdateSqlSuc.executeBatch();
	    psUpdateSqlSuc.close();
	    dealNum=0;
	    
	}
	
	//���Ͳ�����ǰ����ɹ�����[����]
	private void partAheadDeductSucceed() throws SQLException {
	    
	    String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
	    PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
	    
	    String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
                    	       " CustomerName,MobileTelephone,Attribute1,ExTime,EndTime,ModeNo,InputDate" +
                    	       " from Message_Info where ModeNo ='YH_DK120529004' and SucFlag = '0' ";
	    System.out.println("���Ͳ�����ǰ����ɹ�����[����]:"+sQuerySql);
	    PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
	    ResultSet rs = psSelectSql.executeQuery();
	    while(rs.next()){
		String sSerialNo = rs.getString("SerialNo");
		String sOrgID=rs.getString("OrgID");
		String sCustomerID=rs.getString("CustomerID");
		String sMobileTelephone=rs.getString("MobileTelephone");
		String sEndTime=rs.getString("EndTime");
		String sExTime=rs.getString("ExTime");
		String sMode = rs.getString("ModeNo");
		String sCustomerName = rs.getString("CustomerName");
		String sInputDate = rs.getString("InputDate");
		String sBalance = rs.getString("Attribute1");
		
		HashMap<String,String> paraHash = new HashMap<String,String>();
		paraHash.put("name", sCustomerName);
		paraHash.put("date", sInputDate);
		paraHash.put("balance", sBalance);
		
		boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
		if(isSuc){
		    psUpdateSqlSuc.setString(1,"1");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		    
		}else{
		    psUpdateSqlSuc.setString(1,"2");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		}
		dealNum++;
		icount++;
		
		if(dealNum>=commitNum)
		{
		    psUpdateSqlSuc.executeBatch();
		    dealNum = 0;
		    logger.info("�Ѵ���"+icount+"����");
		}
		
	    }
	    rs.close();
	    psSelectSql.close();
	    psUpdateSqlSuc.executeBatch();
	    psUpdateSqlSuc.close();
	    dealNum=0;
	    
	}
	
	//���ʹ����ɹ������ڻ���ɹ��״���ʾ������
	private void awokeReturnFalse() throws SQLException {
	    
	    String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
	    PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
	    
	    String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
                	       " CustomerName,MobileTelephone,Attribute1,Attribute3,ExTime,EndTime,ModeNo,InputDate" +
                	       " from Message_Info where ModeNo ='YH_DK120529005' and SucFlag = '0' ";
	    PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
	    ResultSet rs = psSelectSql.executeQuery();
	    while(rs.next()){
		String sSerialNo = rs.getString("SerialNo");
		String sOrgID=rs.getString("OrgID");
		String sOrgName=rs.getString("OrgName");
		String sCustomerID=rs.getString("CustomerID");
		String sMobileTelephone=rs.getString("MobileTelephone");
		String sEndTime=rs.getString("EndTime");
		String sExTime=rs.getString("ExTime");
		String sMode = rs.getString("ModeNo");
		String sCustomerName = rs.getString("CustomerName");
		String sBalance = rs.getString("Attribute3");
		
		HashMap<String,String> paraHash = new HashMap<String,String>();
		paraHash.put("name", sCustomerName);
		paraHash.put("subbranch", sOrgName);
		paraHash.put("arrears", sBalance);
		
		boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,sEndTime,sExTime,sMode,paraHash);
		if(isSuc){
		    psUpdateSqlSuc.setString(1,"1");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		    
		}else{
		    psUpdateSqlSuc.setString(1,"2");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		}
		dealNum++;
		icount++;
		
		if(dealNum>=commitNum)
		{
		    psUpdateSqlSuc.executeBatch();
		    dealNum = 0;
		    logger.info("�Ѵ���"+icount+"����");
		}
		
	    }
	    rs.close();
	    psSelectSql.close();
	    psUpdateSqlSuc.executeBatch();
	    psUpdateSqlSuc.close();
	    dealNum=0;
	    
	}
	
	
	//��ǰ�������Ѷ���
	private void awokeAheadDeduct() throws Exception {
	    String sUpdateSqlSuc = " update Message_Info set SucFlag = ? where serialno= ?";
	    PreparedStatement psUpdateSqlSuc = connection.prepareStatement(sUpdateSqlSuc);
	    
	    String sQuerySql = " select SerialNo,CustomerName,ModeNo,OrgID,OrgName,CustomerID," +
                    	       " CustomerName,MobileTelephone,Attribute1,Attribute2,Attribute3,Attribute4,Attribute5,ExTime,EndTime,ModeNo,InputDate" +
                    	       " from Message_Info where ModeNo in ('YH_DK120529010','YH_DK120529009','YH_DK120529002','YH_DK120529001' )and SucFlag = '0'";
	    System.out.println("��ǰ�������Ѷ���:"+sQuerySql);
	    PreparedStatement psSelectSql = connection.prepareStatement(sQuerySql);
	    ResultSet rs = psSelectSql.executeQuery();
	    while(rs.next()){
		String sSerialNo = rs.getString("SerialNo");
		String sOrgID=rs.getString("OrgID");
		//String sOrgName=rs.getString("OrgName");
		String sCustomerID=rs.getString("CustomerID");
		String sMobileTelephone=rs.getString("MobileTelephone");
		String sChangeDate=rs.getString("EndTime");//ȡ��ʵ������ǰ������Ч����
		String sExTime=rs.getString("ExTime");
		String sMode = rs.getString("ModeNo");
		String sCustomerName = rs.getString("CustomerName");
		String sAheadCorp = rs.getString("Attribute1");
		String sPrincipal = rs.getString("Attribute2");
		String sPoundage = rs.getString("Attribute3");
		String sCalcPayinte = rs.getString("Attribute4");
		String sFarePayinte = rs.getString("Attribute5");
		
		HashMap<String,String> paraHash = new HashMap<String,String>();
		paraHash.put("name", sCustomerName);// �ͻ�����
		paraHash.put("date", sChangeDate);// ��Ч����
		paraHash.put("debit", String.valueOf(sAheadCorp));// �ۿ���
		paraHash.put("principal", String.valueOf(sPrincipal));// ����
		paraHash.put("interest", String.valueOf(sCalcPayinte));// ��Ϣ
		paraHash.put("fee", String.valueOf(sFarePayinte));// �ʻ�������
		paraHash.put("default", String.valueOf(sPoundage));// ΥԼ��	
		
		boolean isSuc = sendMsg(sOrgID,sCustomerID,sMobileTelephone,"",sExTime,sMode,paraHash);
		if(isSuc){
		    psUpdateSqlSuc.setString(1,"1");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		    
		}else{
		    psUpdateSqlSuc.setString(1,"2");
		    psUpdateSqlSuc.setString(2, sSerialNo);
		    psUpdateSqlSuc.addBatch();
		}
		dealNum++;
		icount++;
		
		if(dealNum>=commitNum)
		{
		    psUpdateSqlSuc.executeBatch();
		    dealNum = 0;
		    logger.info("�Ѵ���"+icount+"����");
		}
		
	    }
	    rs.close();
	    psSelectSql.close();
	    psUpdateSqlSuc.executeBatch();
	    psUpdateSqlSuc.close();
	    dealNum=0;
	    
	}
	
	
	/*
	 *  ����ESB�� esbInstance �����Ͷ���
	 *  ����paras: �����ţ��ͻ��ţ��ֻ��ţ�����ʱ�䣬����ʱ�䣬ģ��ţ���������HASHMAP
	 *  return: �ɹ����� true    ʧ�ܷ��� false
	 * */
	private boolean sendMsg(String sOrgID,String sCustomerID,String sMobileTelephone,String sEndTime,String sExTime,String sMode,HashMap<String,String> sHashMap)
	{
		boolean bReturn = true;
		ESBInstance esbInstance = new ESBInstance();	
		try {
			
			CompositeData compositeData = esbInstance.signalMessage(sOrgID,sCustomerID, sMobileTelephone, "", "", sMode, sHashMap);
			String ret_status = (String)ESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF
			if("F".equalsIgnoreCase(ret_status))
			{
				bReturn =false;
			}	
		} catch (Exception e) {
			bReturn = false;
			e.printStackTrace();
		}
		return bReturn;
	}
	
	
	
	/**
	 * ������浽�ں���������δ���壬������ҵ����Ա���ʼ�֪ͨ
	 * add by ytgong 2012.09.13
	 * @throws Exception
	 */
	public void sendMailForManger() throws Exception {
		Transaction Sqlca = StringTools.getSqlca();
		String sSqlStatus = " Select LB.PutoutNo as PutoutNo,LB.CustomerName as CustomerName from Loan_Balance LB  where LB.Loanstatus in ('0','1','4','5') and LB.BusinessType = '1130050' and LB.MaturityDate = ?";
		PreparedStatement psSqlStatus = Sqlca.conn.prepareStatement(sSqlStatus);
		psSqlStatus.setString(1, deductDate);
		ResultSet rsSqlStatus = psSqlStatus.executeQuery();
		while (rsSqlStatus.next()) {
			try {
				HashMap<String, String> hMap = new HashMap<String, String>();
				StringBuffer sb = new StringBuffer();
				ASResultSet rsUser = Sqlca.getASResultSet(" select distinct UI.UserID from USER_INFO UI,USER_ROLE UR where UI.UserID = UR.UserID and UR.RoleID = 'RC001'");
				while (rsUser.next()) {
					String sTempUserID = DataConvert.toString(rsUser.getString("UserID"));
					if (!"".equals(sTempUserID)) {
						sb.append(sTempUserID + "@pingan.com.cn,");
					}
				}
				String sCustomerName = DataConvert.toString(rsSqlStatus.getString("CustomerName"));
				String sPutOutNo = DataConvert.toString(rsSqlStatus.getString("PutoutNo"));
				rsUser.close();
				hMap.put("Subject", "���滹����Ϣ");
				hMap.put("Description", "�ͻ�:" + sCustomerName + "������������δȫ����ݺţ�" + sPutOutNo + ",���ֶ�����δ������<br>");
				hMap.put("toList", sb.toString());
				System.out.println("������Ϣ��" + sb.toString());
				// �����ʼ�
				MailSend mailSend = new MailSend(hMap);
				String sReturn = mailSend.mailSend();
				if("failure".equals(sReturn)){
					this.errorRecord(sPutOutNo, "����浥֧ȡʧ�ܣ������ʼ�ʧ��","SendAgilityMail");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		rsSqlStatus.close();
		psSqlStatus.close();
		Sqlca.disConnect();
	}

	// �����¼��
	public void errorRecord(String sNo, String sErrorDescribe, String sObjectType) throws SQLException, ParseException {
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sNo);
		batchErrorRecord.setObjectType(sObjectType);
		batchErrorRecord.setTargetName(getTarget().getName());
		batchErrorRecord.setTargetDescribe(getTarget().getDescribe());
		batchErrorRecord.setTaskName(getName());
		batchErrorRecord.setTaskDescribe(getDescribe());
		batchErrorRecord.setInputDate(deductDate);
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		batchErrorRecord.errorRecord(connection);
	}
	
}
