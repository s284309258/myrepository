package com.amarsoft.app.datax.gci;

public class AutoExecuteSQL {

}
