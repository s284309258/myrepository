package com.amarsoft.app.datax.gci.deductacc;

import java.sql.Connection;
import java.util.HashMap;

import com.amarsoft.account.Deal.TransProvider;
import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.LedgerGeneral;
import com.amarsoft.account.util.DateTools;

/**
 * ��Ϣ�޸�
 * @throws Exception 
 * */
public class DealYZInteTrans extends TransProvider{	

	public void RepairInte(double inte,LoanBalance loanBalance,Connection Conn,String deductDate) throws Exception{
		String sDate = DateTools.getStringDate(deductDate);//�������е�б��ȥ��
		String sSerialno="TX"+sDate + loanBalance.getPutOutNo();
			
		LedgerDetail ledgerDetail = new LedgerDetail();
		LedgerGeneral ledgerGeneral = new LedgerGeneral();
		loanBalance.OpenUpdateLoanBalance(Conn);
		ledgerDetail.OpenInsertLedgerDetail(Conn);
		ledgerGeneral.OpenInsertLedgerGeneral(Conn);
		ledgerGeneral.OpenUpdateLedgerGeneral(Conn);
		
		HashMap<String,AttributeField> inputPara = new HashMap<String,AttributeField>();
		inputPara = SetInputPara(inputPara,"PayInnerInte",0);
		inputPara = SetInputPara(inputPara,"PayOutInte",0);				
		inputPara = SetInputPara(inputPara,"PayInnerInteFine",0);
		inputPara = SetInputPara(inputPara,"PayOutInteFine",0);
		inputPara = SetInputPara(inputPara,"DayInte",inte);
		
		inputPara = SetInputPara(inputPara,"BusinessType",loanBalance.getBusinessType());
		inputPara = SetInputPara(inputPara,"LoanTerm",loanBalance.getLoanTerm());
		
		inputPara = SetInputPara(inputPara,"TransNo","7001",false);//���ύ��
		inputPara = SetInputPara(inputPara,"BillNo",sSerialno,false);
		inputPara = SetInputPara(inputPara,"SerialNo",sSerialno,false);//������ˮ��
		inputPara = SetInputPara(inputPara,"AccDate",deductDate);
		inputPara = SetInputPara(inputPara,"PutOutNo",loanBalance.getPutOutNo(),false);			
		inputPara = SetInputPara(inputPara,"Currency",loanBalance.getCurrency(),false);//����
		inputPara = SetInputPara(inputPara,"OrgID",loanBalance.getOrgID(),false);			
		inputPara = SetInputPara(inputPara,"DisDate",loanBalance.getDisDate());
		inputPara = SetInputPara(inputPara,"CustomerType",loanBalance.getCustomerType());
		
		LedgerDeal(ledgerDetail,ledgerGeneral,inputPara,LoanBalance.getAccountSubjectHashMap(getStringInputPara(inputPara,"PutOutNo"), Conn));
		
		loanBalance.UpdateLoanBalance();
		loanBalance.executeBatch();
		ledgerDetail.executeBatch();
		ledgerGeneral.executeBatch();
		Conn.commit();
		
		loanBalance.close();
		ledgerDetail.close();
		ledgerGeneral.close();
			
	}
}
