package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import sun.misc.BASE64Encoder;

import com.amarsoft.are.ARE;
import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.bis.middle.MD5WithRSA;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

import filetrans.BankFileHandleServiceImp;
import filetrans.ResultBean;

public class SendGuardianShipFile extends CommonExecuteUnit {
    private String sLocalFileUrl;// �����ļ���������·��
    private String sFileNameOffer;// ƽ�������ļ�����
    private String sBISFrontIp;// ǰ�û�IP
    private String sBISFrontPort;// ǰ�ö˿�
    private String NASUrl;// NAS�ռ��ַ
    private String sUserName; // �û�����
    private String sPassword; // �û�����
    private String sKeyStore; // ������

    public int execute() {
	try {
	    String sInit = super.init();
	    /**------������----------------------*/
        /**-----------------------������----------------------*/
	    if (sInit.equalsIgnoreCase("skip")) {
		return TaskConstants.ES_SUCCESSFUL;
	    } else {
		logger.info("��ʼ����ƽ���ػ�Ͷ���嵥�ļ�......");
		initPara();
		sendShouHuFile();
		logger.info("����ƽ���ػ�Ͷ���嵥�ļ���ɣ�");
		unitStatus = TaskConstants.ES_SUCCESSFUL;
		clearResource();
		return unitStatus;
	    }
	} catch (Exception ex) {
	    logger.error(ex);
	    ex.printStackTrace();
	    unitStatus = TaskConstants.ES_FAILED;
	    clearResource();
	    return unitStatus;
	}
    }

    /*
     * ��ʼ��������Ϣ
     */
    public void initPara() {
	String sDate = StringFunction.replace(deductDate, "/", "");
	NASUrl = ARE.getProperty("NASUrl");
	sLocalFileUrl = StringFunction.replace(NASUrl + getProperty("LocalFileUrl"), "{$CurrentDate}", sDate);
	sFileNameOffer = StringFunction.replace(getProperty("FileNameOffer"), "{$CurrentDate}", sDate);
	sBISFrontIp = getProperty("BISFrontIp");
	sBISFrontPort = getProperty("BISFrontPort");
	sUserName = getProperty("UserName");
	sPassword = getProperty("Password");
    }

    /**
     * ����ƽ���ػ�Ͷ���嵥�ļ�����
     * 
     * @throws Exception
     */
    public void sendShouHuFile() throws Exception {
	File file = new File(sLocalFileUrl);
	if (!file.exists()) {
	    logger.error(sLocalFileUrl + "�����ڣ�");
	    return;
	}
	if (!file.isDirectory()) {
	    logger.error("����ϵͳ�����ļ�Ŀ¼(sLocalFileUrl)��" + sLocalFileUrl + "����Ŀ¼��");
	    return;
	}
	ResultBean bean = BankFileHandleServiceImp.sendBankFile(sLocalFileUrl + sFileNameOffer, sFileNameOffer, sBISFrontIp, Integer.parseInt(sBISFrontPort), "in");
	if(bean != null){
	    String codeSend = bean.getPA_RSLT_CODE();
	    String msgSend = bean.getPA_RSLT_MESG();
	    if ("999999".equals(codeSend)) {
		inserttencent_monitor("S");
		logger.info("�ļ���" + sFileNameOffer + "���ͳɹ���");
	    } else {
		inserttencent_monitor("F");
		logger.info("�����ļ�ʧ��,"+msgSend);
	    }
	}else{
	    inserttencent_monitor("F");
	    logger.info("�����ļ�ʧ�ܣ������·��͡�������");
	}
    }

    /**
     * ������־����
     * @param status
     */
    private void inserttencent_monitor(String status)
	{
		String SerialNo = "";
		PreparedStatement prepareStatement = null;
		try {
			SerialNo = DBFunction.getSerialNo("TENCENT_MONITOR", "SERIALNO","RL",null);
			prepareStatement = connection.prepareStatement("insert into TENCENT_MONITOR(Serialno,Objecttype,Oper_Date,Batch_Flag) values(?,?,?,?)");
			prepareStatement.setString(1, SerialNo);
			prepareStatement.setString(2, "SEND");
			prepareStatement.setString(3, deductDate);
			prepareStatement.setString(4, status);
			prepareStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				if(prepareStatement!=null)prepareStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
    

    
//    public void appendToFile(String fullFileName,String Key) throws Exception {
//        BufferedReader reader = new BufferedReader(new FileReader(fullFileName));
//        String line = "";
//        while ((line = reader.readLine()) != null) {
//            if (line.startsWith("sign,")) {
//           return;
//            }
//        }
//        MD5WithRSA md5 = new MD5WithRSA();
//        byte[] t = md5.sigFile(fullFileName, KEYALIAS, Key, KEYSTOREPATH);
//        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fullFileName, true)));
//        out.write("sign," + new BASE64Encoder().encode(t));
//        out.close();
//    }

}
