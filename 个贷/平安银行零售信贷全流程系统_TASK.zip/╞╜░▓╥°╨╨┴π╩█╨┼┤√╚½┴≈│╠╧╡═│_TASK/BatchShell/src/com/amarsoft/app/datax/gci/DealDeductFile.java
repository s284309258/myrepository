package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.util.FileMD5Tools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.Array;
import com.dc.eai.data.CompositeData;

/**
 * ����FCR���͵��ļ�
 * 
 * @author WANGWEIXING492
 * 
 */
public class DealDeductFile extends CommonExecuteUnit {

	// �ļ�����
	private String sFileType;
	// ������IP��ַ
	private String sServerIP;
	// FTPS�˿ں�
	private int sServerFtpsPort;
	// �������û���
	private String sUserName;
	// ����������
	private String sPassWord;
	// �����ļ�·��
	private String sLocalSaveFileUrl;
	// �����ļ�ģ���ʽ
	private String sFileMode;
	// ִ��SQL���� update
	private String sSqlType;
	// �ָ���
	private String sSeparator;
	private String sCheckLine;
	// �������
	private String sTableName;
	// SQL����Ϊupdateʱ ������Ϣ
	private String sUpdateColumns;
	// SQL����Ϊupdateʱ where �����Ϣ
	private String sUpdateWhereName;
	// ����У��Sql���
	private String sCheckSql;
	private String sSql;
	private PreparedStatement psSql;
	private int[] iUpdateArray;
	private int[] iUpdateWhereArray;
	private int commitNum;
	private String NASUrl;
	private String status_code = "";
	private String notice_type = "";
	private String sCheckFileMode;
	private String sCheckColumns;
	private int[] iCheckArray;
	private int iDateLocal = 0;
	private String sDateIsRepace;
	private String sRepaceDateName;
    private Boolean checkOrNot = true;
	private String sDate = "";
	
	// FCR���͵��ļ���
	private String sFileName = "";
	// FCR���͵�MD5ֵ
	private String sMD5 = "";
	// FCR���͵��ļ�·��
	private String sFilePath = "";
	//�ļ���
	private String fileno = "";
	
    private Boolean dealStatus = true;


	public int execute() {
		try {
			String sInit = super.init();
			
			/* ��ʼ������ */
			initPara();
			
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} 
			
			// ��ѯ�����ļ�
			queryFileinfo();
			
			
			if(!checkfinished()){
				
				throw new Exception("���ļ�FCRδ�����������ȴ��´���ѯ��");
				
			}	
			
			unitStatus = TaskConstants.ES_SUCCESSFUL;
			clearResource();
			return unitStatus;
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}

	/**
	 * 
	 * ��ʼ������ģ�������õĲ���
	 * 
	 * @throws Exception
	 */
	public void initPara() throws Exception {
		sDate = StringFunction.replace(deductDate, "/", "");
		sFileType = this.getProperty("FileType");
		sServerIP = this.getProperty("ServerIP");
		sServerFtpsPort = Integer.parseInt(getProperty("ServerFtpsPort", "0"));
		sUserName = this.getProperty("UserName");
		sPassWord = this.getProperty("PassWord");
		NASUrl = ARE.getProperty("NASUrl");
		sLocalSaveFileUrl = NASUrl + this.getProperty("LocalSaveFileUrl");
		sLocalSaveFileUrl = StringFunction.replace(sLocalSaveFileUrl,
				"{$CurrentDate}", sDate);
		sFileMode = this.getProperty("FileMode");
		sSqlType = this.getProperty("SqlType");
		sUpdateColumns = this.getProperty("UpdateColumns");
		sUpdateWhereName = this.getProperty("UpdateWhereName");
		sSeparator = this.getProperty("Separator");
		sTableName = this.getProperty("TableName");
		sCheckFileMode = this.getProperty("CheckFileMode");
		sCheckColumns = this.getProperty("CheckColumns");
		sDateIsRepace = this.getProperty("DateIsRepace");
		sRepaceDateName = this.getProperty("RepaceDateName");
	}
	
	
	/**
	 * FCR218��ѯ�ļ�״̬
	 * 
	 * @throws Exception
	 */
	public void getFileStatusFromFCR(String sFileNo) throws Exception {
		FCRESBInstance FCREsbInstance = new FCRESBInstance();
		// FCR218�ļ�״̬��ѯ
		CompositeData compositeData = FCREsbInstance.FileStatusFromFCR(sFileNo,"FCR041");
		String ret_status = (String) FCRESBInstance.getValue(compositeData,
				"RET_STATUS");// ����״̬,�ɹ�ΪS,ʧ��ΪF
		if ("S".equalsIgnoreCase(ret_status)) {
			Array array = (Array) FCRESBInstance.getValue(compositeData,
					"FILE_ARRAY");
			if (array != null && array.size() != 0) {
				CompositeData arrayCompositeData = array.getStruct(0);
				notice_type = DataConvert.toString((String) FCRESBInstance
						.getValue(arrayCompositeData, "NOTICE_TYPE"));
				status_code = DataConvert.toString((String) FCRESBInstance
						.getValue(arrayCompositeData, "STATUS_CODE"));
				if("13".equals(status_code.trim())){
					if("N".equalsIgnoreCase(notice_type.trim())){
						update218status(sFileNo,"F","FCR�ļ�û���ϴ���bfts��");
					}else if("F".equalsIgnoreCase(notice_type.trim())){
						update218status(sFileNo,"F","FCR�ļ��ϴ���bftsʧ��");
					}else if("S".equalsIgnoreCase(notice_type.trim())){
						update218status(sFileNo,"F","FCR�ļ��Ѿ��ϴ���BFTS��");
					}else{
						update218status(sFileNo,"F","FCR����֪ͨ״̬����ȷ��");
					}
				}else{
					update218status(sFileNo,"F","FCR�����ļ���״̬Ϊ"+status_code);
				}			
			} 
		} else {
			update218status(sFileNo,"F","��ѯ�ļ�״̬������");
		}
	}

	/**
	 * ȡ�ļ�
	 * 
	 * @throws Exception
	 */
	public Boolean getFileFromFCR() throws Exception {
		
		boolean sendStatus = false;
		String sServerUrl = sFilePath + sFileName;
		logger.info("FCR�����ļ���" + sServerUrl);
		logger.info("����·����" + sLocalSaveFileUrl);
		sendStatus = FileTransmitTools.transfer(sServerIP, sServerFtpsPort,
						sUserName, sPassWord, sServerUrl, sLocalSaveFileUrl);
		if (sendStatus) {
				logger.info("============�ӷ�������ȡ�ļ�" + sFileName
							+ "�ɹ���===============");
		} else {
				logger.error("============���ӷ�������ȡ�ļ�" + sFileName
							+ "ʧ�ܣ���===============");
				updatestatus(fileno,"F","�ӷ�������ȡ�ļ�ʧ��");
		}
		
		return  sendStatus;

	}

	
	/**
	 * У���ļ�MD5ֵ
	 * 
	 * @throws Exception
	 */
	public Boolean checkFileMD5() throws Exception {
		File file = new File(sLocalSaveFileUrl + sFileName);
		String strMD5 = FileMD5Tools.getFileMD5String(file);
		logger.info("�Ŵ�ϵͳ�����"+sFileName+"�ļ�MD5ֵΪ:" + strMD5);
		if (!strMD5.equals(sMD5)) {
				logger.error("============�ļ�У�鲻��ȷ��ɾ���ļ���===============");
				if (file.isFile()){
					file.delete();
				}
				updatestatus(fileno,"F","�ļ�MD5ֵУ�鲻��ȷ!");
				dealStatus = false;
		}
		return dealStatus;
		
	}
	
	
	/**
	 * �����ļ�
	 * 
	 * @throws Exception
	 */
	public Boolean dealExpFile() throws Exception {
		int icount = 0;
		int iLineCount = 0;
		int dealNum = 0;
		String strtmp = null;

		commitNum = Integer.parseInt(getProperty("commitNum", "1"));
		File inputFile = new File(sLocalSaveFileUrl + sFileName);
		if (!inputFile.exists()) {
			updatestatus(fileno, "F", "�ļ�������");
			logger.error("�ļ������ڣ�");
			dealStatus = false;
		} else if (checkFileIsNull(inputFile)) {
			logger.info("���ļ�Ϊ���ļ�");
			checkOrNot = false;
		} else {
			// ��ʼ��fileMode�����Ϣ
			initPsArray();
			// ��ʼ��SQL���
			createSql();
			// ��Ԥ����
			psSql = connection.prepareStatement(sSql);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(inputFile), "UTF-8"));

			String sLine;
			while ((sLine = reader.readLine()) != null) {
				iLineCount++;
				String[] str = sLine.split(sSeparator);
				// �жϸü�¼�Ƿ����ݼ����¼
				if ("0".equals(str[0])) {
					sCheckLine = sLine;
				} else if ("1".equals(str[0])) {
					if ("1".equals(sDateIsRepace)) {
						str[iDateLocal] = turnDateFormat(str[iDateLocal]);
					}
					setPsSql(psSql, str);
					dealNum++;
					icount++;
					if (dealNum >= commitNum) {
						psSql.executeBatch();
						dealNum = 0;
						logger.info("�Ѿ�����" + icount + "�����ݣ�");
					}
				} else {
					strtmp = "�ļ��е�" + iLineCount + "������ʵ���ļ���ʽ����ͬ��";
					logger.error(strtmp);
					updatestatus(fileno,"F", strtmp);
					dealStatus = false;
				}
			}
			psSql.executeBatch();
			psSql.close();
			logger.info("�����ļ�������" + icount + "�����ݣ�");
		}
		
		return dealStatus;

	}	
		

	/**
	 * У���ļ��Ƿ�Ϊ��
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private Boolean checkFileIsNull(File file) throws IOException {
		String sLine;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file)));
			if ((sLine = reader.readLine()) != null) {
				if (reader.readLine() != null) {
					return false;
				} else {
					sCheckLine = sLine;
					return true;
				}
			} else {
				return true;
			}
		} catch (IOException ex) {
			throw new IOException();
		} finally {
			if (reader != null)
				reader.close();
		}
	}

	/**
	 * ��ʼ��fileMode�����Ϣ
	 * 
	 * @throws Exception
	 */
	public void initPsArray() throws Exception {
		String[] fileMond = sFileMode.split(",");

		for (int i = 0; i < fileMond.length; i++) {
			if (sRepaceDateName.equalsIgnoreCase(fileMond[i])) {
				iDateLocal = i;
			}
		}

		if (sSqlType.equalsIgnoreCase("update")) {
			String[] sUpdateColumnsArray = sUpdateColumns.split(",");
			iUpdateArray = new int[sUpdateColumnsArray.length];

			// ȷ���ļ���ʽ�У������ֶε�λ��
			for (int i = 0; i < sUpdateColumnsArray.length; i++) {
				String sSingleName = sUpdateColumnsArray[i];
				for (int j = 0; j < fileMond.length; j++) {
					if ((fileMond[j].trim()).equalsIgnoreCase(sSingleName)) {
						iUpdateArray[i] = j;
						break;
					}

				}
			}
			// ȷ���ļ���ʽ�У�where�������ֶε�λ��
			String[] sUpdateWhereNameArray = sUpdateWhereName.split(",");
			iUpdateWhereArray = new int[sUpdateWhereNameArray.length];
			for (int i = 0; i < iUpdateWhereArray.length; i++) {
				String sSingleName = sUpdateWhereNameArray[i];
				for (int j = 0; j < fileMond.length; j++) {
					if ((fileMond[j].trim()).equalsIgnoreCase(sSingleName)) {
						iUpdateWhereArray[i] = j;
						break;
					}
				}
			}
		} else {
			throw new Exception("����SqlTypeû�����û����ô���");
		}
	}

	/**
	 * ���ݸ�ģ�����ò��� ���ɸ�ģ��Sql���
	 * 
	 * @throws Exception
	 */
	public void createSql() throws Exception {
		String[] ss;
		if (sSqlType.equalsIgnoreCase("update")) {
			ss = sUpdateColumns.split(",");
			String[] sUpdateNameArray = sUpdateWhereName.split(",");

			sSql = " update " + sTableName + " set ";
			for (int i = 0; i < ss.length; i++) {
				sSql = sSql + ss[i] + "=?";
				if (i != ss.length - 1) {
					sSql = sSql + ",";
				}
			}
			sSql = sSql + " where ";
			for (int j = 0; j < sUpdateNameArray.length; j++) {
				sSql = sSql + sUpdateNameArray[j] + "=?";
				if (j != sUpdateNameArray.length - 1) {
					sSql = sSql + " and ";
				}
			}
		} else {
			throw new Exception("����SqlTypeû�����û����ô���");
		}
	}

	/**
	 * ���ļ��е�һ������SET��update�����.
	 * 
	 * @throws Exception
	 */
	public void setPsSql(PreparedStatement psSql, String[] str)
			throws Exception {
		if (sSqlType.equalsIgnoreCase("update")) {
			for (int i = 0; i < iUpdateArray.length; i++) {
				psSql.setString(i + 1, str[iUpdateArray[i]].trim());
			}
			for (int j = 0; j < iUpdateWhereArray.length; j++) {
				psSql.setString(iUpdateArray.length + j + 1,
						str[iUpdateWhereArray[j]].trim());
			}
			psSql.addBatch();
		} else {
			throw new Exception("����SqlTypeû�����û����ô���");
		}
	}

	/**
	 * �ļ�У��
	 * 
	 * @throws Exception
	 */
	public Boolean fileCheck() throws Exception {
		initCheckfileModePsArray();
		String[] slineArray = sCheckLine.split(sSeparator);
		logger.info("sCheckSql:" + sCheckSql);
		PreparedStatement psCheckSql = connection.prepareStatement(sCheckSql);
		ResultSet rs = psCheckSql.executeQuery();
		while (rs.next()) {
			for (int i = 0; i < iCheckArray.length; i++) {
				int j = iCheckArray[i];
				logger.info("��"+(i+1)+"ge���������ݿ�ֵ: "+rs.getString(i + 1) + " �ļ�ֵΪ�� " + slineArray[j]);
				if (!slineArray[j].trim().equals(rs.getString(i + 1))) {
					updatestatus(fileno,"F","�ļ�У��ʧ�ܣ�");
					dealStatus = false;
				}
			}
		}
		rs.close();
		psCheckSql.close();
		return dealStatus;
	}

	/**
	 * ��ʼ��CheckfileMode�����Ϣ
	 * 
	 * @throws Exception
	 */
	public void initCheckfileModePsArray() throws Exception {
		String[] CheckfileModefileMond = sCheckFileMode.split(",");
		String[] CheckColumnsArray = sCheckColumns.split(",");
		iCheckArray = new int[CheckColumnsArray.length];
		// ȷ���ļ���ʽ�У�У���ֶε�λ��
		for (int i = 0; i < CheckColumnsArray.length; i++) {
			for (int j = 0; j < CheckfileModefileMond.length; j++) {
				if ((CheckfileModefileMond[j].trim())
						.equalsIgnoreCase(CheckColumnsArray[i])) {
					iCheckArray[i] = j;
					break;
				}
			}
		}
	}

	/**
	 * ����FCR217֪ͨFCR���
	 * 
	 * @param code
	 * @param status
	 * @throws Exception
	 */
	public Boolean sendESBToFCR() throws Exception {
		String code = "000000";
		String status = "S";
		FCRESBInstance FCREsbInstance = new FCRESBInstance();
		// ��Χϵͳ�ļ�����״̬֪ͨ
		CompositeData compositeData = FCREsbInstance.FileTransferNoticeToFCR(
				"system", "batch", sFileName, code, status);
		String ret_status = DataConvert.toString((String) FCRESBInstance
				.getValue(compositeData, "RET_STATUS"));// ����״̬,�ɹ�ΪS,ʧ��ΪF
		if (!"S".equalsIgnoreCase(ret_status)) {
			updatestatus(fileno,"F","����FCR217ʧ�ܣ�");
			dealStatus = false;
		} 
		return dealStatus;
	}

	public String turnDateFormat(String sDate) {
		String sReturn = sDate.substring(0, 4) + "/" + sDate.substring(4, 6)
				+ "/" + sDate.substring(6, 8);
		return sReturn;
	}

	
	/**
	 * �ļ�����
	 * 
	 * @throws Exception
	 */
	public void queryFileinfo() throws Exception{
		String selectSql = "";
		String aExphandlingflag = "";		// �Ƿ������쳣����
		String clause = "";
		
		selectSql = "select fileno, fcrfilename, fcrmd5, fcrurl, EXPHANDLINGFLAG, whereClause from FILESTATUS_INFO where dealflag = 'S' and  (filestatus <> 'S' or filestatus is null ) and filetype = '"
			+ sFileType + "' and inputdate = '" + deductDate + "'";
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			psQuery = connection.prepareStatement(selectSql);
			rs = psQuery.executeQuery();
			while(rs.next()){	
				//ȡ��У��sql
				sCheckSql = this.getProperty("CheckSql");
			    fileno = rs.getString("fileno");
			    sFileName = rs.getString("fcrfilename");
				sMD5 = rs.getString("fcrmd5");
				sFilePath = rs.getString("fcrurl");
				aExphandlingflag = rs.getString("EXPHANDLINGFLAG"); 
				clause = rs.getString("whereClause");
				sCheckSql = StringFunction.replace(sCheckSql, "{$whereClause}",clause);
				
				if("1".equals(aExphandlingflag)){
					// ������쳣������ƴ��FCR�����ļ���
					sFileName = "FCR-"+fileno+".txt";
				}
				
				//������״̬��Ϊtrue
				dealStatus = true;
				
				// ȡ�ļ�
				dealStatus = getFileFromFCR();
				
				if(dealStatus){
					
					if(!"1".equals(aExphandlingflag)){
						// ���ȡ�ļ��ɹ����Ҳ����쳣������У��MD5ֵ��
						dealStatus = checkFileMD5();
					}
					
					if(dealStatus){
						// �ļ�У��ɹ��������ļ�
						dealStatus = dealExpFile();
						
						if(dealStatus && checkOrNot){
							//�ļ����سɹ����Ҳ��ǿ��ļ���У���ļ�
							dealStatus = fileCheck();
							
							if(dealStatus){
								//����FCR217
								dealStatus = sendESBToFCR();
								
								if(dealStatus){
									//�������ݿ�
									updatestatus(fileno,"S","");
								}
							}
						}
					}
				}
			
			}

		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			rs.close();
			psQuery.close();
		}  
	}
		
	
	/**
	 * �����ļ�����״̬
	 * 
	 * @param filename
	 * @param mesg
	 * @throws Exception
	 */
	public void updatestatus (String fileno, String Status,String mesg) throws Exception{
		String sSql;
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			sSql = "update FILESTATUS_INFO  set FILESTATUS = '"+Status+"', ATTRIBUTE2 = '"+mesg+"' where FILENO = '"+fileno+"'";
			psQuery = connection.prepareStatement(sSql);
			rs = psQuery.executeQuery();
		} catch (SQLException e) {
			throw new Exception("����FILESTATUS_INFO��������");
		} finally {
			rs.close();
			psQuery.close();
		}
	}
	
	
	/**
	 * �����ļ�����״̬
	 * 
	 * @param filename
	 * @param mesg
	 * @throws Exception
	 */
	public void update218status (String fileno, String Status,String mesg) throws Exception{
		String sSql;
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		try {
			sSql = "update FILESTATUS_INFO  set FILESTATUS = '"+Status+"', FCR218STATUS = '"+mesg+"' where FILENO = '"+fileno+"'";
			psQuery = connection.prepareStatement(sSql);
			rs = psQuery.executeQuery();
		} catch (SQLException e) {
			throw new Exception("����FILESTATUS_INFO��������");
		} finally {
			rs.close();
			psQuery.close();
		}
	}
	

	
	/**
	 * ��ѯ�ļ��Ƿ�ȫ��������ɣ��Ƿ���true���񷵻�false
	 * 
	 * @return
	 * @throws Exception
	 */
	public Boolean checkfinished() throws Exception{
		Boolean status = true;
		String sSql = "";
		String fileno = "";
		PreparedStatement psQuery = null;
		ResultSet rs = null;
		sSql = "select fileno from FILESTATUS_INFO where (dealflag <> 'S'or filestatus <> 'S'or dealflag is null or filestatus is null ) and filetype = '"
			+ sFileType + "' and inputdate = '" + deductDate + "'";
		
		try {
			psQuery = connection.prepareStatement(sSql);
			rs = psQuery.executeQuery();
			while(rs.next()){
				status = false;
				fileno = rs.getString("fileno");
				// ��ѯ218
				getFileStatusFromFCR(fileno);
			}
			
		return status;
		} catch (SQLException e) {
			throw new Exception("��ѯ�ļ�״̬������");
		} finally {
			rs.close();
			psQuery.close();
		}
	}
}
