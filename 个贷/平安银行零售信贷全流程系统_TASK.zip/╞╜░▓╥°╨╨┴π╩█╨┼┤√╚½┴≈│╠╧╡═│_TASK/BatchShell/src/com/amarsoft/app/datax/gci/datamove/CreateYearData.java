package com.amarsoft.app.datax.gci.datamove;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateYearData extends CommonExecuteUnit  {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				String pDate="";
				String flage="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if(deductDate.equals(pDate)&&"0".equals(flage)){
					logger.info("................��ʼ��ʼ��������.............");
					initData();
					logger.info("................��ʼ������������..............");
	
					logger.info("................��ʼ���������������1��.............");
					CreateYearDatas1();
					logger.info("................���������������1��ɣ�..............");
					
					logger.info("................��ʼ����ί�д����������������ݣ�.............");
					CreateWTData();
					logger.info("................����ί�д�������������������ɣ�..............");
					
					logger.info("................���뽫���ռ�÷�ת��Ϊ������������ݣ�.............");
					otherData();
					logger.info("................���뽫���ռ�÷�ת��Ϊ���������������ɣ�..............");
					
					
					logger.info("................���뷨��ʵ���ծ�ʲ����ݣ�.............");
					otherData1();
					otherData2();
					logger.info("................���뷨��ʵ���ծ�ʲ�������ɣ�..............");
				}else{
					logger.info("................���첻��Ҫ���У�..............");
				}
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void initData() {
		commitNum = getProperty("commitNum", 1);
	}
	
	/**
	 * ���������������1
	 * @throws SQLException
	 */
	public void CreateYearDatas1() throws SQLException{
		String al=" insert into ledger_general(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+"  select lg.putoutno,'4990102' as subjectno, lg.orgid,lg.currency,lg.creditbalance,lg.debitbalance,lg.accountno,'AA'||lg.serialno as serialno," +
				" lg.direction,'����������Ŀ' from QY_LEDGER_GENERAL_BAK901 lg where lg.accountno='AA' and (lg.debitbalance <> 0 or lg.creditbalance <> 0) " +
				" and lg.putoutno not like 'YZ%' and lg.putoutno not like 'A%' ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	/**
	 * ���������������2
	 * @throws SQLException
	 */
//	public void CreateYearDatas2() throws SQLException{
//		String al="insert into ledger_general(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
//			+" select ql.putoutno,ql.subjectno,ql.orgid,ql.currency,ql.creditbalance,ql.debitbalance,'133' as accountno, "
//			+" 'DM'||ql.serialno as serialno,ql.direction,'����ֹ���������' as subjectname from QY_LEDGER_GENERAL_BAK901 ql " 
//			+" where ql.putoutno ='0219999998' and ql.accountno<>'AA'    ";
//		PreparedStatement ps=connection.prepareStatement(al);
//		ps.execute();
//		connection.commit();
//	}
	
	/**
	 * ����ί�д�����������������
	 * @throws SQLException
	 */
	public void CreateWTData()  throws SQLException{
		String al="insert into ledger_general(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+" select qb.putoutno,'5100207' as subjectno,qb.orgid,qb.currency,qb.creditbalance,qb.debitbalance,'511' as accountno,'DM901RLA00001'||qb.serialno,'C' as direction,'����ί�д�������������' as subjectname  "
				+"   from qy_ledger_general_bak901 qb, loan_balance lb  "
				+"  where qb.putoutno = lb.putoutno  "
				+"   and lb.putoutdate <'2012/07/07' "
				+"   and lb.businesstype in ('1190030', '1190010')  "
				+"   and (qb.creditbalance <>0 or qb.debitbalance <> 0)  "
				+"   and qb.accountno='53' "
				+"   order by qb.putoutno,qb.subjectno ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	/**
	 * ���뽫���ռ�÷�ת��Ϊ�������������
	 * @throws SQLException
	 */
	public void otherData()  throws SQLException{
		String al=" insert into ledger_general ( "
			+"select lg.putoutno,'5100599' as subjectno,lg.orgid,lg.currency,lg.creditbalance,lg.debitbalance,'510' as accountno,'DM901RLA00002'||lg.serialno,'C' as direction, '���������˻�������' as  subjectname "
			+" from fare_detail fd, loan_balance lb,qy_ledger_general_bak901 lg "
			+" where fd.putoutno = lb.putoutno "
			+" and lg.putoutno=lb.putoutno "
			+" and lb.putoutdate <'2012/07/07' "
			+" and lg.accountno='51' "
			+" and lb.businesstype <> '1140100' "
			+" and (lg.creditbalance <>0 or lg.debitbalance <>0) "
			+" and fd.paydate = lb.putoutdate )";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	/**
	 * @throws SQLException 
	 * 
	 */
	public void otherData1() throws SQLException{
		String al="insert into ledger_general(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+" select lg.putoutno, "
				+" 	case when lg.subjectno='40310203' "
				+" 	  then '4031504' "
				+" 	else case when lg.subjectno='49990102' "
				+" 	  then '4990102' "
				+" 	    else case when lg.subjectno='40310402'  " 
				+" 	      then '4031503' "
				+" 	      end "
				+" 	   end "
				+" 	end as subjectno     "
				+" 	  ,lg.orgid,lg.currency,lg.creditbalance,lg.debitbalance,lg.accountno,'F901'||lg.serialno,lg.direction,lg.subjectname from qy_ledger_general_bak901 lg  "
				+" 	where (lg.putoutno like 'AR%' or lg.putoutno like 'YZ%') "
				+" 	and lg.subjectno in ('40310203','49990102','40310402') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	/**
	 * @throws SQLException 
	 * 
	 */
	public void otherData2() throws SQLException{
		String al="insert into ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno) "
				+" select lg.putoutno,'','9999','0','','"+deductDate+"',lg.currency,case when lg.subjectno='40310203' "
				+"   then '4031504' "
				+" else case when lg.subjectno='49990102' "
				+"   then '4990102' "
				+"     else case when lg.subjectno='40310402'   "
				+"       then '4031503' "
				+"       end "
				+"    end "
				+" end as subjectno ,lg.creditbalance,lg.debitbalance,'1',lg.orgid,'F'||lg.serialno from qy_ledger_general_bak901 lg  "
				+" where (lg.putoutno like 'AR%' or lg.putoutno like 'YZ%') "
				+" and lg.subjectno in ('40310203','49990102','40310402') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
