package com.amarsoft.app.datax.gci.RepayDataSplit;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;


import com.amarsoft.app.datax.gci.AcctFeeInfoBatch;
import com.amarsoft.app.datax.gci.BatchErrorRecord;
import com.amarsoft.app.datax.gci.DeductAccountInfo;
import com.amarsoft.app.datax.gci.AheadDeductData;
import com.amarsoft.app.datax.gci.DeductData;
import com.amarsoft.app.datax.gci.FareDetaill;
import com.amarsoft.app.datax.gci.LoanAccount;
import com.amarsoft.app.datax.gci.PamsAs400;
import com.amarsoft.app.datax.gci.BatchConstant;

public abstract class BasicRepayDataSplit implements IRepayDataSplit {

	public ArrayList<PamsAs400> execute(LoanAccount loanAccount) throws Exception
	{
		arrayListErrorRecord.clear();
		return executeSplit(loanAccount.getDeductdataList(),
				loanAccount.getAheadDeductdataList(),
				loanAccount.getFareDetailList(),
				loanAccount.getAcctFeeInfoList(),
				loanAccount.getAccountInfoMap());
	}
	
	public abstract ArrayList<PamsAs400> executeSplit(ArrayList<DeductData> deductDateList,
				ArrayList<AheadDeductData> aheadDeductdataList,
				ArrayList<FareDetaill> fareDetailList,
				ArrayList<AcctFeeInfoBatch> acctFeeInfoList,
				HashMap<String,DeductAccountInfo> accountMap) throws Exception;
	
	public static String createDeductSerialNo()
	{
		return String.valueOf(++BatchConstant.DEDUCT_SERIAL_NO);
	}
	
	/*
	 * ���ݴ���deductDate���󣬷��ظ���Ӧ��������
	 * */
	public double returnCorp(DeductData deductData)
	{
		double dReturn = 0 ;
		if(deductData!= null)
		{
			dReturn = deductData.getPayOverDueCorp()-deductData.getActualOverDueCorp();
		}
		return dReturn;
	}
	
	/*
	 * ���ݴ���deductDate���󣬷��ظ���Ӧ����Ϣ���
	 * */
	public double returnInte(DeductData deductData)
	{
		double dReturn = 0 ;
		if(deductData!= null)
		{
			dReturn = deductData.getPayInte()+deductData.getPayInnerInte()+deductData.getPayOutInte()
			-deductData.getActualInte()-deductData.getActualInnerInte()-deductData.getActualOutInte();
		}
		return dReturn;
	}
	
	/*
	 * ���ݴ���deductDate���󣬷��ظ���Ӧ���������
	 * */
	public double returnFine(DeductData deductData)
	{
		double dReturn = 0 ;
		if(deductData!= null)
		{
			dReturn = deductData.getPayInnerInteFine()+deductData.getPayOutInteFine()
			-deductData.getActualInnerInte()-deductData.getActualOutInte();
		}
		return dReturn;
	}
	
	/*
	 * ���ݴ���aheadDeductDate���󣬷��ظ���ǰ����Ӧ����Ϣ
	 * */
	public double returnAheadInte(AheadDeductData aheadDeductDate)
	{
		double dReturn = 0 ;
		if(aheadDeductDate!= null)
		{
			dReturn = aheadDeductDate.getPayInte();
		}
		return dReturn;
	}
	
	/*
	 * ���ݴ���aheadDeductDate���󣬷��ظ���ǰ����Ӧ������
	 * */
	public double returnAheadCorp(AheadDeductData aheadDeductData)
	{
		double dReturn = 0 ;
		if(aheadDeductData!=null)
		{
			dReturn = aheadDeductData.getPayCurrentCorp();
		}
		return dReturn;
	}
	
	/*
	 * ���ݴ���aheadDeductDate���󣬷��ظ���ǰ����ΥԼ��
	 * */
	public double returnPoundage(AheadDeductData aheadDeductDate)
	{
		double dReturn = 0 ;
		if(aheadDeductDate!= null)
		{
			dReturn = aheadDeductDate.getPayPoundage();
		}
		return dReturn;
	}
	
	public void ErrorRecord(String sChangeSerialNo,String sErrorDescribe) throws SQLException, ParseException
	{
		BatchErrorRecord batchErrorRecord = new BatchErrorRecord();
		batchErrorRecord.setObjectNo(sChangeSerialNo);
		batchErrorRecord.setObjectType("LoanBalance");
		batchErrorRecord.setTargetName("DeductData");
		batchErrorRecord.setTargetDescribe("");
		batchErrorRecord.setTaskName("FormatData");
		batchErrorRecord.setTaskDescribe("��ʽ����������");
		batchErrorRecord.setErrorDescribe(sErrorDescribe);
		arrayListErrorRecord.add(batchErrorRecord);
	}
	
	public ArrayList<BatchErrorRecord> getErrorList()
	{
		return arrayListErrorRecord;
	}
}
