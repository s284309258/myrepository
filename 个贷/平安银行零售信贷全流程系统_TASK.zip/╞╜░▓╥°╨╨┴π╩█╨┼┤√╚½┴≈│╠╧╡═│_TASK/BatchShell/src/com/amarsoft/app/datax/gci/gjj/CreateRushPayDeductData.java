package com.amarsoft.app.datax.gci.gjj;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;

public class CreateRushPayDeductData extends CommonExecuteUnit {

	private int commitNum ;
	private int deductDataNum = 0;
	private int icount = 0;

	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','DEDUCT_DATA') ";
				logger.info("��� DEDUCT_DATA:sql="+delSql);
				PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
				psDeleteDeductData.execute();
				logger.info("���DEDUCT_DATA������� ");
				psDeleteDeductData.close();
				
				logger.info("�����Ϻ�������廹��һ�㻹����������......");
				insertDeductData();
				logger.info("�����ɺ�������廹��һ�㻹����������"+icount+"����");
				logger.info("�����Ϻ�������廹��һ�㻹�������������");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//�廹��һ�㻹������
	private void insertDeductData() throws SQLException,Exception
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		String sql = " INSERT INTO Deduct_Data(PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,ActualCurrentCorp,PayDefaultCorp,ActualDefaultCorp, "
			+" PayOverDueCorp,ActualOverDueCorp,PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, "
			+" PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,AccountFlag,PayDate,DeductAccNo,DeductAccNo1,DeductAccNo2,OverDueInte) "
			+" VALUES(?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?)";
		PreparedStatement psInsertDeductData = connection.prepareStatement(sql);
		String sqlStatus=" select distinct ls.PutOutNo,ls.Sterm,ls.AheadNum,ls.Currency,ls.PayCurrentCorp,ls.ActualCurrentCorp,ls.PayDefaultCorp,ls.ActualDefaultCorp, "
				 +" ls.PayOverDueCorp,ls.ActualOverDueCorp,ls.PayInte,ls.ActualInte,ls.PayInnerInte,ls.ActualInnerInte,ls.PayOutInte,ls.ActualOutInte, "
				 +" ls.PayInnerInteFine,ls.ActualInnerInteFine,ls.PayOutInteFine,ls.ActualOutInteFine,ls.PayDate,lb.LoanAccNo,ls.PayOverDueCorpInte,lb.BusinessType "
				 +" from LOANBACK_STATUS ls,Loan_Balance lb,(select * from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') union all select * from GJJ_ZTOB where inputdate = '"+this.deductDate+"' ) gc "
				 +" where ls.PutOutNo = Lb.PutOutNo and ls.PayOffFlag = '"+BatchConstant.PAYOFFFLAG_FALSE+"'"
				 +" and ls.PayDate <= lb.CalcDayInteDate "
				 +" and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) "
				 +" and getLoanNo(lb.PutOutNo) = getGjjLoanNo(gc.LoanNo,'1') "
				 +" union "
				 +" select distinct ls.PutOutNo,ls.Sterm,ls.AheadNum,ls.Currency,ls.PayCurrentCorp,ls.ActualCurrentCorp,ls.PayDefaultCorp,ls.ActualDefaultCorp, "
				 +" ls.PayOverDueCorp,ls.ActualOverDueCorp,ls.PayInte,ls.ActualInte,ls.PayInnerInte,ls.ActualInnerInte,ls.PayOutInte,ls.ActualOutInte, "
				 +" ls.PayInnerInteFine,ls.ActualInnerInteFine,ls.PayOutInteFine,ls.ActualOutInteFine,ls.PayDate,lb.LoanAccNo,ls.PayOverDueCorpInte,lb.BusinessType "
				 +" from LOANBACK_STATUS ls,Loan_Balance lb,(select * from GJJ_CTOB where inputdate = '"+this.deductDate+"' and LoanType in('02','04') union all select * from GJJ_ZTOB where inputdate = '"+this.deductDate+"' ) gc "
				 +" where ls.PutOutNo = Lb.PutOutNo and ls.PayOffFlag = '"+BatchConstant.PAYOFFFLAG_FALSE+"'"
				 +" and ls.PayDate <= lb.CalcDayInteDate "
				 +" and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) "
				 +" and getLoanNo(lb.PutOutNo) = getGjjLoanNo(gc.LoanNo,'2') "
				 +" order by PutOutNo,Sterm,AheadNum ";
		PreparedStatement psStatus=connection.prepareStatement(sqlStatus);
		ResultSet rs = psStatus.executeQuery();
		while(rs.next()){
			//�������������ǰ�������������״̬����Ӧ������ʵ�����򲻼������ۣ���������ֻ������⡣��modify dxu1 2010-11-30
			double calMoney = rs.getDouble("PayCurrentCorp")-rs.getDouble("ActualCurrentCorp")+rs.getDouble("PayDefaultCorp")-rs.getDouble("ActualDefaultCorp")
							+ rs.getDouble("PayOverDueCorp")-rs.getDouble("ActualOverDueCorp")+rs.getDouble("PayInte")-rs.getDouble("ActualInte")
							+ rs.getDouble("PayInnerInte")-rs.getDouble("ActualInnerInte") + rs.getDouble("PayOutInte")-rs.getDouble("ActualOutInte")
							+ rs.getDouble("PayInnerInteFine")-rs.getDouble("ActualInnerInteFine") + rs.getDouble("PayOutInteFine")-rs.getDouble("ActualOutInteFine");
			if(rs.getInt("AheadNum")>0 && calMoney>0.0) continue;
			psInsertDeductData.setString(1,rs.getString("PutOutNo"));
			psInsertDeductData.setInt(2,rs.getInt("Sterm"));
			psInsertDeductData.setInt(3,rs.getInt("AheadNum"));
			psInsertDeductData.setString(4,rs.getString("Currency"));
			psInsertDeductData.setDouble(5,rs.getDouble("PayCurrentCorp")-rs.getDouble("ActualCurrentCorp"));
			psInsertDeductData.setDouble(6,0.0);
			psInsertDeductData.setDouble(7,rs.getDouble("PayDefaultCorp")-rs.getDouble("ActualDefaultCorp"));
			psInsertDeductData.setDouble(8,0.0);
			psInsertDeductData.setDouble(9,rs.getDouble("PayOverDueCorp")-rs.getDouble("ActualOverDueCorp"));
			psInsertDeductData.setDouble(10,0.0);
			psInsertDeductData.setDouble(11,rs.getDouble("PayInte")-rs.getDouble("ActualInte"));
			psInsertDeductData.setDouble(12,0.0);
			psInsertDeductData.setDouble(13,rs.getDouble("PayInnerInte")-rs.getDouble("ActualInnerInte"));
			psInsertDeductData.setDouble(14,0.0);
			psInsertDeductData.setDouble(15,rs.getDouble("PayOutInte")-rs.getDouble("ActualOutInte"));
			psInsertDeductData.setDouble(16,0.0);
			psInsertDeductData.setDouble(17,rs.getDouble("PayInnerInteFine")-rs.getDouble("ActualInnerInteFine"));
			psInsertDeductData.setDouble(18,0.0);
			psInsertDeductData.setDouble(19,rs.getDouble("PayOutInteFine")-rs.getDouble("ActualOutInteFine"));
			psInsertDeductData.setDouble(20,0.0);
			psInsertDeductData.setString(21,BatchConstant.ACCOUNTFLAG_CURRENTLY);
			psInsertDeductData.setString(22,rs.getString("PayDate"));
			psInsertDeductData.setString(23,rs.getString("LoanAccNo"));
			psInsertDeductData.setString(24,"");
			psInsertDeductData.setString(25,"");
			psInsertDeductData.setDouble(26,rs.getDouble("PayOverDueCorpInte"));
			
			psInsertDeductData.addBatch();
			deductDataNum++;
			icount++;
			
			if(deductDataNum>=commitNum){
				psInsertDeductData.executeBatch();
				deductDataNum=0;
				logger.info("��ִ��"+icount+"����");
			}
		}
		psInsertDeductData.executeBatch();
		rs.close();
		psInsertDeductData.close();
		psStatus.close();
	}
}
