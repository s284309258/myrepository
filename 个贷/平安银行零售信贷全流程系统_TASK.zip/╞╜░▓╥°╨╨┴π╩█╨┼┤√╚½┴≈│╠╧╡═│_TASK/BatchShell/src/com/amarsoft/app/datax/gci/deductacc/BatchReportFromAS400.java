package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;

public class BatchReportFromAS400 extends CommonExecuteUnit{

	private int icount = 0;
	private int insertNum = 0;
	private int commitNum = 0;
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum = Integer.parseInt(getProperty("commitNum", "1"));
				
				String delSql=" call dbmgr.truncate_table ('ICRDATA','report_fromas400') ";
				logger.info("���report_fromas400:sql="+delSql);
				PreparedStatement psDelSql = connection.prepareStatement(delSql);
				psDelSql.execute();
				logger.info("���Report_Fromas400����������� ");
				psDelSql.close();
				
				logger.info("��ʼ����AS400����.....");
				createReportFromAS400();
				logger.info("AS400�����������...��");
				
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	//��ʼ����AS400����
	private void createReportFromAS400() throws SQLException {
		System.out.println("deductDate=" + deductDate);
		//AccountMonth�ֶ�
		String sAccountMonth = deductDate.substring(5, 7);
		System.out.println("sAccountMonth=" +sAccountMonth);
		//�ۿ������ֶ�
		String sDate = deductDate.substring(0,7);
		System.out.println("sDate = " + sDate);
		
		String sInsertSql = " insert into report_fromas400(" +
						   " LOANACCOUNT,ACCOUNTMONTH,DFFLAG,MONTHPAYDAY,PAYTIMES,LEFTPAYTIMES,LASTPAYDAY," +
						   " THISMONTHPAYBALANCE,INFACTPAYBALANCE,LCABALANCE,NOTPAYBALANCE1,NOTPAYBALANCE2," +
						   " NOTPAYBALANCE3,NOTPAYBALANCE4,TATIMES,LCATIMES,IFPAYTHISMONTH,GENTIME,VALIDFLAG)" +
						   " values(?,?,?,?,?," +
						   " ?,?,?,?,?," +
						   " ?,?,?,?,?," +
						   " ?,?,?,?)" ;
		PreparedStatement psInsertSql = connection.prepareStatement(sInsertSql);
		
		String sQuerySql=  " SELECT lb.putoutno,'"+sAccountMonth+"' AS AccountMonth,lb.���ֱ�־ AS DFFlag," +
						   " CASE WHEN MonthPayDay LIKE '"+sDate+"%' THEN MonthPayDay ELSE '' END MonthPayDay," +
						   " �������� AS PayTimes ,ʣ�໹������ AS LeftPayTimes,���һ��ʵ�ʻ����� AS LastPayDay," +
						   " nvl(ʵ�ʻ�����,0)+nvl(balance1,0) AS ThisMonthPayBalance," +
						   " nvl(ʵ�ʻ�����,0) AS InFactPayBalance,nvl(��ǰ���ڱ����ܶ�,0) AS  LcaBalance," +
						   " nvl(����1_2����,0) AS NotPayBalance1," +
						   " nvl(����2_3����,0) AS NotPayBalance2," +
						   " nvl(����3_6����,0) AS NotPayBalance3," +
						   " nvl(����6��������,0) AS NotPayBalance4," +
						   " nvl(TaTimes,0) AS TaTimes," +
						   " nvl(LcaTimes,0) LcaTimes," +
						   " �����Ƿ��ѻ� AS IfPayThisMonth," +
						   " '' AS GenTime,'' AS ValidFlag" +
						   " FROM(" +
						   " SELECT putoutno ,  MATURITYDATE,CASE WHEN MAINRETURNTYPE  in ('4','3')  THEN 'l' ELSE 'i' END AS ���ֱ�־," +
						   " ceil(Months_between(to_date(MATURITYDATE,'yyyy/mm/dd'),to_date(putoutdate,'yyyy/mm/dd'))) AS ��������," +
						   " ceil(Months_between(to_date(MATURITYDATE,'yyyy/mm/dd'),SYSDATE)) AS ʣ�໹������," +
						   " OVERDUEBALANCE+PAYINTE+PAYINNERINTE+PAYOUTINTE+PAYINNERINTEFINE+PAYOUTINTEFINE AS balance1 ," +
						   " overdueBalance AS ��ǰ���ڱ����ܶ�" +
						   " FROM loan_balance " +
						   " ) lb," +
						   " (" +
						   " select putoutno," +
						   " NVL(MAX(case when accdate like '"+sDate+"%'" +
						   		" then '1' else '0' end),0) AS �����Ƿ��ѻ�," +
						   " max(accdate) AS ���һ��ʵ�ʻ�����," +
						   " SUM(CASE WHEN    accdate LIKE '"+sDate+"%' THEN  ACTUALPay ELSE 0 END) AS ʵ�ʻ����� " +
						   " from" +
						   " (" +
						   " SELECT  putoutno,accdate,BILLSTATUS," +
						   " ACTUALOVERDUECORP+ACTUALINTE+ACTUALINNERINTE+ACTUALOUTINTE+ACTUALINNERINTEFINE+ACTUALOUTINTEFINE AS ACTUALPay" +
						   " FROM back_bill   WHERE   BillStatus='1' AND  billtype IN ('20','21','22','23','24')" +
						   " )" +
						   " GROUP BY putoutno" +
						   " ) bb," +
						   " (" +
						   " SELECT A.putoutno," +
						   " Max(PayDate) AS MonthPayDay," +
						   " SUM(LcaTimes) AS LcaTimes," +
						   " SUM(TaTimes) AS TaTimes," +
						   " SUM(CASE WHEN MonthBetween<2 THEN PayBalance ELSE 0 END ) AS ����1_2����," +
						   " SUM(CASE WHEN MonthBetween>=2 AND  MonthBetween<3 THEN PayBalance ELSE 0 END ) AS ����2_3����," +
						   " SUM(CASE WHEN MonthBetween>=3 AND  MonthBetween<6 THEN PayBalance ELSE 0 END ) AS ����3_6����," +
						   " SUM(CASE WHEN MonthBetween>6 THEN PayBalance ELSE 0 END ) AS ����6�������� " +
						   " FROM(" +
						   " SELECT putoutno," +
						   " PayDate," +
						   " (CASE WHEN paydate<accdate THEN 1 ELSE 0 END ) AS TaTimes," +
						   " (CASE WHEN  payoffflag='0' THEN 1 ELSE 0 END) AS LcaTimes," +
						   " (CASE WHEN payoffflag='0' AND aheadnum='0' THEN ceil(months_between(sysdate,to_date(paydate,'yyyy/mm/dd')))  ELSE 0 END) AS MonthBetween ," +
						   " (CASE WHEN payoffflag='0' AND aheadnum='0' THEN PAYOVERDUECORP-ACTUALOVERDUECORP  ELSE 0 END) AS PayBalance " +
						   " FROM  loanback_status" +
						   " ) A" +
						   "  GROUP BY A.putoutno" +
						   " ) ls2" +
						   " WHERE lb.putoutno = bb.putoutno(+)" +
						   " AND lb.putoutno = ls2.putoutno(+) ";
		PreparedStatement psQuerySql =  connection.prepareStatement(sQuerySql);
		System.out.println(sQuerySql);
		ResultSet rs = psQuerySql.executeQuery();
		while(rs.next()){
			psInsertSql.setString(1,rs.getString("putoutno"));
			psInsertSql.setString(2,rs.getString("AccountMonth"));
			psInsertSql.setString(3,rs.getString("DFFlag"));
			psInsertSql.setString(4,rs.getString("MonthPayDay"));
			psInsertSql.setDouble(5, rs.getDouble("PayTimes"));
			psInsertSql.setDouble(6, rs.getDouble("LeftPayTimes"));
			psInsertSql.setString(7, rs.getString("LastPayDay"));
			psInsertSql.setDouble(8, rs.getDouble("ThisMonthPayBalance"));
			psInsertSql.setDouble(9, rs.getDouble("InFactPayBalance"));
			psInsertSql.setDouble(10, rs.getDouble("LcaBalance"));
			psInsertSql.setDouble(11, rs.getDouble("NotPayBalance1"));
			psInsertSql.setDouble(12, rs.getDouble("NotPayBalance2"));
			psInsertSql.setDouble(13, rs.getDouble("NotPayBalance3"));
			psInsertSql.setDouble(14, rs.getDouble("NotPayBalance4"));
			psInsertSql.setDouble(15, rs.getDouble("TaTimes"));
			psInsertSql.setDouble(16, rs.getDouble("LcaTimes"));
			psInsertSql.setString(17, rs.getString("IfPayThisMonth"));
			psInsertSql.setString(18, rs.getString("GenTime"));
			psInsertSql.setString(19, rs.getString("ValidFlag"));
			psInsertSql.addBatch();
			insertNum++;
			icount++;
			if(insertNum > commitNum){
				psInsertSql.executeBatch();
				insertNum = 0;
				logger.info("�Ѿ�����"+icount +"������...");
			}
			
		}
		rs.close();
		psQuerySql.close();
		psInsertSql.executeBatch();
		psInsertSql.close();
	}

}
