package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.task.TaskConstants;

public class BatchGuarantyTrack extends CommonExecuteUnit{

	private int commitNum ;
	private int dealNum = 0;
	private int icount = 0;
	private int iSerialCount = 0;
	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				commitNum=Integer.parseInt(getProperty("commitNum", "1"));
				String sSerialNo = "B"+DateTools.getStringDate(deductDate)+"%";
				String delSql=" delete from guaranty_track where SerialNo like '"+sSerialNo+"' ";
				logger.info("��� guaranty_track:sql="+delSql);
				PreparedStatement psDeleteData = connection.prepareStatement(delSql);
				psDeleteData.execute();
				logger.info("���guaranty_track�������! ");
				psDeleteData.close();
				
				logger.info("��ʼ��������С΢����Ѻ�ﻻ֤������Ϣ......");
				guarantyTrackSW();
				logger.info("��������С΢����Ѻ�ﻻ֤������Ϣ!");
				
				if(nextDate.substring(8,10).equals("01"))
				{
					logger.info("��ʼ�������µ���Ѻ�ﻻ֤������Ϣ......");
					guarantyTrack();
					logger.info("�������µ���Ѻ�ﻻ֤������Ϣ!");
				}
				else
				{
					logger.info("���ղ���ִ�е���Ѻ�ﻻ֤����ģ�飡");
				}
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	public void guarantyTrack() throws Exception
	{
		
		String insertSql = "insert into guaranty_track(SerialNo,GuarantyID,TrackDate,InputOrgID,InputUserID,Status) values(?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select GI.GuarantyID,GI.InputorgID,GI.InputUserID "
						 + " from BUSINESS_CONTRACT BC, GUARANTY_RELATIVE GR, GUARANTY_INFO GI "
						 + " where BC.SerialNo = GR.ObjectNo and GR.ObjectType in('CBContractApply','SWContractApply') and GR.GuarantyID = GI.GuarantyID "
						 + " and (GI.ManStatus = '04' or GI.ManStatus = '05') and GI.GuarantyType = '020010' and GI.GuarantySubType = '20' "
						 + " and BC.PutOutDate is not null  and BC.PutOutDate <> ' ' "
						 + " and BC.FinishDate is null "
						 + " and substr(Bc.Putoutdate,1,7) <> '"+currentMonth+"'";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{
			String sNewSerialNo = createSerialNo();
			psInsertSql.setString(1,sNewSerialNo);
			psInsertSql.setString(2,rs.getString("GuarantyID"));
			psInsertSql.setString(3,deductDate);
			psInsertSql.setString(4,rs.getString("InputorgID"));
			psInsertSql.setString(5,rs.getString("InputUserID"));
			psInsertSql.setString(6,"01");
			psInsertSql.addBatch();
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"����");
	}
	
	
	public void guarantyTrackSW() throws Exception
	{
		String sDate = DateTools.getRelativeDate(lastDate, "Y", -1);
		String insertSql = "insert into guaranty_track(SerialNo,GuarantyID,TrackDate,InputOrgID,InputUserID,Status,ExchangeFlag) values(?,?,?,?,?,?,?)";
		PreparedStatement psInsertSql = connection.prepareStatement(insertSql);
		
		String selectSql = " select GI.GuarantyID,GI.InputorgID,GI.InputUserID,GI.GuarantyDate,BC.PutOutDate "
						 + " from BUSINESS_CONTRACT BC, GUARANTY_RELATIVE GR, GUARANTY_INFO GI "
						 + " where BC.SerialNo = GR.ObjectNo and GR.ObjectType in('CBContractApply','SWContractApply') and GR.GuarantyID = GI.GuarantyID "
						 + " and (GI.ManStatus = '04' or GI.ManStatus = '05') and GI.GuarantyType = '020010' and GI.GuarantySubType = '20' "
						 + " and BC.PutOutDate is not null  and BC.PutOutDate <> ' ' "
						 + " and BC.FinishDate is null ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		while(rs.next())
		{	
			String guarantyDate = DataConvert.toString(rs.getString("GuarantyDate"));
			String putoutDate = DataConvert.toString(rs.getString("PutOutDate"));
			if("".equals(guarantyDate)||guarantyDate == null){
				if(sDate.equals(putoutDate)){
					String sNewSerialNo = createSerialNo();
					psInsertSql.setString(1,sNewSerialNo);
					psInsertSql.setString(2,rs.getString("GuarantyID"));
					psInsertSql.setString(3,deductDate);
					psInsertSql.setString(4,rs.getString("InputorgID"));
					psInsertSql.setString(5,rs.getString("InputUserID"));
					psInsertSql.setString(6,"03");
					psInsertSql.setString(7,"1");
					psInsertSql.addBatch();
				}else{
					continue;
				}
			}else{
				int month = DateTools.getMonths(putoutDate, guarantyDate);
				//������������ڷſ����ڲ�����12���£���ȡ�������ڵĴ��²�������
				if(month<=12&&month>=-12){
					if(deductDate.equals(DateTools.getRelativeDate(DateTools.getRelativeDate(guarantyDate, "M", 1),"D",1))){
						String sNewSerialNo = createSerialNo();
						psInsertSql.setString(1,sNewSerialNo);
						psInsertSql.setString(2,rs.getString("GuarantyID"));
						psInsertSql.setString(3,deductDate);
						psInsertSql.setString(4,rs.getString("InputorgID"));
						psInsertSql.setString(5,rs.getString("InputUserID"));
						psInsertSql.setString(6,"03");
						psInsertSql.setString(7,"1");
						psInsertSql.addBatch();
					}else{
						continue;
					}
					//�������ھ��ͬ���´�������������ڳ���12���µģ�������������ں��13���¿�ʼÿ�²�����������
				}else if(month>12||month<-12){
					if(deductDate.equals(DateTools.getRelativeDate((DateTools.getRelativeDate(putoutDate, "Y", 1)),"D",1))){
						String sNewSerialNo = createSerialNo();
						psInsertSql.setString(1,sNewSerialNo);
						psInsertSql.setString(2,rs.getString("GuarantyID"));
						psInsertSql.setString(3,deductDate);
						psInsertSql.setString(4,rs.getString("InputorgID"));
						psInsertSql.setString(5,rs.getString("InputUserID"));
						psInsertSql.setString(6,"03");
						psInsertSql.setString(7,"1");
						psInsertSql.addBatch();
					}else{
						continue;
					}
				}
			}
			
			dealNum++;
			icount++;
			
			if(dealNum>=commitNum)
			{
				psInsertSql.executeBatch();
				dealNum=0;
				logger.info("�Ѿ�����"+icount+"����");
			}
		}
		psInsertSql.executeBatch();
		rs.close();
		rs.getStatement().close();
		psInsertSql.close();
		psSelectSql.close();
		logger.info("һ������"+icount+"����");
	}
	
	public String createSerialNo() throws Exception
	{
		iSerialCount++;
		String sDate = DateTools.getStringDate(deductDate);
		String sSortNo = NumberTools.lPad(iSerialCount,8,'0');
		return "B"+sDate+sSortNo;
	}
	
}
