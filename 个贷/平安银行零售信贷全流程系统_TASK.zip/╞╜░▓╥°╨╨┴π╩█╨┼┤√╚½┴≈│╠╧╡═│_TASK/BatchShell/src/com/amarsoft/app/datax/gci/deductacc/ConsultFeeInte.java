package com.amarsoft.app.datax.gci.deductacc;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.Deal.TransScheduler;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.account.ledger.UpdateLedgerGeneral;

public class ConsultFeeInte extends CommonExecuteUnit{

	
	public int execute() {
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				logger.info("��ʼ����̯������......");
				//��������+1
				String sDate =  DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
				TransScheduler transScheduler = new TransScheduler(connection);
				//��������̯��
				transScheduler.BatchTransScheduler("7012",sDate);
				//����֧��̯��
				transScheduler.BatchTransScheduler("7013",sDate);
				
				//���·���˫���Ŀ�����ֵ
				UpdateLedgerGeneral.BatchLedgerGeneral(connection);
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
}
