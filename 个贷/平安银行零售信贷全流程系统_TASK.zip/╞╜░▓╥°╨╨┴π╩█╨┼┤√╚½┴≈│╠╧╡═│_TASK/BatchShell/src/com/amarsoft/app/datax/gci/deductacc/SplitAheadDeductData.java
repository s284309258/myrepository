package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;

public class SplitAheadDeductData extends CommonExecuteUnit{

	
		public int execute() {
				
				try{
					String sInit = super.init();
					if(sInit.equalsIgnoreCase("skip"))
					{
						return TaskConstants.ES_SUCCESSFUL;
					}
					else
					{	
						logger.info("��ʼ�����ǰ������������......");
						batchSplitAheadDeductData();
						logger.info("��ǰ�����������ݲ����ɣ�");
						
						unitStatus= TaskConstants.ES_SUCCESSFUL;
						clearResource();
						return unitStatus;
					}
				}catch(Exception ex){
					logger.error(ex);
					ex.printStackTrace();
					unitStatus= TaskConstants.ES_FAILED;
					clearResource();
					return unitStatus;
				} 
		}
		
		public void batchSplitAheadDeductData() throws SQLException
		{
			String updateSql = " update Ahead_Deduct_Data set ActualCurrentCorp=PayCurrentCorp,ActualInte=PayInte,ActualPoundage=PayPoundage where ChangeSerialNo=? ";
			PreparedStatement psUpdateSql = connection.prepareStatement(updateSql);
			
			String deleteSql = " delete from AS400_PAMS where SerialNo = ? ";
			PreparedStatement psDeleteSql = connection.prepareStatement(deleteSql); 
			
			String selectSql = " select SerialNo,PutOutNo,AheadSerialNo from as400_pams where (AmountattriBute = '"+BatchConstant.AMOUNTATTRIBUTE_AHEAD+"' or AmountattriBute='"+BatchConstant.AMOUNTATTRIBUTE_SDB_AHEADAMOUNT+"')  and ActualAmount > 0 ";
			PreparedStatement psSelectSql = connection.prepareStatement(selectSql); 
			ResultSet rs = psSelectSql.executeQuery();
			while(rs.next())
			{
				psUpdateSql.setString(1,rs.getString("AheadSerialNo"));
				psUpdateSql.addBatch();
				
				psDeleteSql.setString(1,rs.getString("SerialNo"));
				psDeleteSql.addBatch();
				
			}
			psUpdateSql.executeBatch();
			psDeleteSql.executeBatch();
			rs.close();
			psDeleteSql.close();
			psUpdateSql.close();
			psSelectSql.close();
		}

}
