package com.amarsoft.app.datax.gci.deductdata;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.task.TaskConstants;
import com.amarsoft.app.datax.gci.BatchConstant;

public class BatchDeductData extends CommonExecuteUnit {

	private int commitNum ;
	private int deductDataNum = 0;
	private int icount = 0;

	public int execute() {
		
		
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				String delSql=" call dbmgr.truncate_table ('RCPMDATA','DEDUCT_DATA') ";
				logger.info("��� DEDUCT_DATA:sql="+delSql);
				PreparedStatement psDeleteDeductData = connection.prepareStatement(delSql);
				psDeleteDeductData.execute();
				logger.info("���DEDUCT_DATA������� ");
				psDeleteDeductData.close();
				
				logger.info("����һ�㻹����������......");
				insertDeductData();
				logger.info("������һ�㻹����������"+icount+"����");
				logger.info("����һ�㻹�������������");
				unitStatus= TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
		/*finally{
			clearResource();
			return unitStatus;
		}*/
	}
	private void insertDeductData() throws SQLException
	{
		commitNum=Integer.parseInt(getProperty("commitNum", "1"));
		String sql = " INSERT INTO Deduct_Data(PutOutNo,Sterm,AheadNum,Currency,PayCurrentCorp,ActualCurrentCorp,PayDefaultCorp,ActualDefaultCorp, "
			+" PayOverDueCorp,ActualOverDueCorp,PayInte,ActualInte,PayInnerInte,ActualInnerInte,PayOutInte,ActualOutInte, "
			+" PayInnerInteFine,ActualInnerInteFine,PayOutInteFine,ActualOutInteFine,AccountFlag,PayDate,DeductAccNo,DeductAccNo1,DeductAccNo2,OverDueInte,ActualAmount1,ActualAmount2,ActualAmount3) "
			+" VALUES(?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?,?," +
					"?,?,?,?)";
		PreparedStatement psInsertDeductData = connection.prepareStatement(sql);
		String sqlStatus="select /*+RULE*/ls.PutOutNo,ls.Sterm,ls.AheadNum,ls.Currency,ls.PayCurrentCorp,ls.ActualCurrentCorp,ls.PayDefaultCorp,ls.ActualDefaultCorp, "
				 +" ls.PayOverDueCorp,ls.ActualOverDueCorp,ls.PayInte,ls.ActualInte,ls.PayInnerInte,ls.ActualInnerInte,ls.PayOutInte,ls.ActualOutInte, "
				 +" ls.PayInnerInteFine,ls.ActualInnerInteFine,ls.PayOutInteFine,ls.ActualOutInteFine,ls.PayDate,lb.DeductAccNo,lb.DeductAccNo1,lb.DeductAccNo2,ls.PayOverDueCorpInte,lb.BusinessType "
				 +" from LOANBACK_STATUS ls,Loan_Balance lb "
				 +" where ls.PutOutNo = Lb.PutOutNo and ls.PayOffFlag = '"+BatchConstant.PAYOFFFLAG_FALSE+"' and ls.PayDate <= '"+this.deductDate+"' and (lb.BatchPaymentFlag = '1' or lb.BatchPaymentFlag is null) ";
		PreparedStatement psStatus=connection.prepareStatement(sqlStatus);
		ResultSet rs = psStatus.executeQuery();
		while(rs.next()){
			//�������������ǰ�������������״̬����Ӧ������ʵ�����򲻼������ۣ���������ֻ������⡣��modify dxu1 2010-11-30
			double calMoney = rs.getDouble("PayCurrentCorp")-rs.getDouble("ActualCurrentCorp")+rs.getDouble("PayDefaultCorp")-rs.getDouble("ActualDefaultCorp")
							+ rs.getDouble("PayOverDueCorp")-rs.getDouble("ActualOverDueCorp")+rs.getDouble("PayInte")-rs.getDouble("ActualInte")
							+ rs.getDouble("PayInnerInte")-rs.getDouble("ActualInnerInte") + rs.getDouble("PayOutInte")-rs.getDouble("ActualOutInte")
							+ rs.getDouble("PayInnerInteFine")-rs.getDouble("ActualInnerInteFine") + rs.getDouble("PayOutInteFine")-rs.getDouble("ActualOutInteFine");
			if(rs.getInt("AheadNum")>0 && calMoney>0.0) continue;
			psInsertDeductData.setString(1,rs.getString("PutOutNo"));
			psInsertDeductData.setInt(2,rs.getInt("Sterm"));
			psInsertDeductData.setInt(3,rs.getInt("AheadNum"));
			psInsertDeductData.setString(4,rs.getString("Currency"));
			//����ί�д����ж�
/*if(rs.getString("BusinessType").equals("1190010"))
{
	psInsertDeductData.setDouble(5,0.0);
	psInsertDeductData.setDouble(6,0.0);
	psInsertDeductData.setDouble(7,0.0);
	psInsertDeductData.setDouble(8,0.0);
	psInsertDeductData.setDouble(9,0.0);
	psInsertDeductData.setDouble(10,0.0);
}
else
{*/
				psInsertDeductData.setDouble(5,rs.getDouble("PayCurrentCorp")-rs.getDouble("ActualCurrentCorp"));
				psInsertDeductData.setDouble(6,0.0);
				psInsertDeductData.setDouble(7,rs.getDouble("PayDefaultCorp")-rs.getDouble("ActualDefaultCorp"));
				psInsertDeductData.setDouble(8,0.0);
				psInsertDeductData.setDouble(9,rs.getDouble("PayOverDueCorp")-rs.getDouble("ActualOverDueCorp"));
				psInsertDeductData.setDouble(10,0.0);
/*}*/
			psInsertDeductData.setDouble(11,rs.getDouble("PayInte")-rs.getDouble("ActualInte"));
			psInsertDeductData.setDouble(12,0.0);
			psInsertDeductData.setDouble(13,rs.getDouble("PayInnerInte")-rs.getDouble("ActualInnerInte"));
			psInsertDeductData.setDouble(14,0.0);
			psInsertDeductData.setDouble(15,rs.getDouble("PayOutInte")-rs.getDouble("ActualOutInte"));
			psInsertDeductData.setDouble(16,0.0);
			psInsertDeductData.setDouble(17,rs.getDouble("PayInnerInteFine")-rs.getDouble("ActualInnerInteFine"));
			psInsertDeductData.setDouble(18,0.0);
			psInsertDeductData.setDouble(19,rs.getDouble("PayOutInteFine")-rs.getDouble("ActualOutInteFine"));
			psInsertDeductData.setDouble(20,0.0);
			psInsertDeductData.setString(21,BatchConstant.ACCOUNTFLAG_CURRENTLY);
			psInsertDeductData.setString(22,rs.getString("PayDate"));
			psInsertDeductData.setString(23,rs.getString("DeductAccNo"));
			psInsertDeductData.setString(24,rs.getString("DeductAccNo1"));
			psInsertDeductData.setString(25,rs.getString("DeductAccNo2"));
			psInsertDeductData.setDouble(26,rs.getDouble("PayOverDueCorpInte"));
			psInsertDeductData.setDouble(27,0.0);
			psInsertDeductData.setDouble(28,0.0);
			psInsertDeductData.setDouble(29,0.0);
			psInsertDeductData.addBatch();
			deductDataNum++;
			icount++;
			
			if(deductDataNum>=commitNum){
				psInsertDeductData.executeBatch();
				deductDataNum=0;
				logger.info("��ִ��"+icount+"����");
			}
		}
		psInsertDeductData.executeBatch();
		rs.close();
		psInsertDeductData.close();
		psStatus.close();
	}

}
