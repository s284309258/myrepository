package com.amarsoft.app.datax.gci.util;

public interface MyExcuteUnit {
	public String  run() throws Exception;
}
