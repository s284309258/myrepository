package com.amarsoft.app.datax.gci.deductacc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.ESBInstance;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.CompositeData;

/**
 * ����FCR�ļ�ESB��Ϣ 
 * @author WANGWEIXING492
 * ����
 */
public class FilesTransfer2With400 extends CommonExecuteUnit {

	//�ļ��ţ������ж��Ƿ��յ��յ����ͽӿ�ESB��Ϣ
	private String fileNo;
	//�ļ����� 
	private String fileType;
	//��Ϣ���� 
	private String megType;
	
	public int execute() {
		try{
			String sInit = super.init();
			if(sInit.equalsIgnoreCase("skip"))
			{
				return TaskConstants.ES_SUCCESSFUL;
			}
			else
			{
				initPare();
				//FCR���ذ��ҽ��ļ���BIFMFBAJDW��
				if(fileType.equals("BIFMFBAJDW"))
				{
					if(deductDate.substring(8,10).equals("05"))
						getFileWith400();
					else
					{
						logger.info("���ղ���"+megType);
						unitStatus= TaskConstants.ES_SUCCESSFUL;
					}
				}
				//��ĩ��������ļ�
				else if(fileType.equals("BIFMBBATDW"))
				{
					if(deductDate.substring(8,10).equals("02"))
						getFileWith400();
					else
					{
						logger.info("���ղ���"+megType);
						unitStatus= TaskConstants.ES_SUCCESSFUL;
					}
				}
				else
					getFileWith400();
				
				clearResource();
				return unitStatus;
			}
		}catch(Exception ex){
			logger.error(ex);
			ex.printStackTrace();
			unitStatus= TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		} 
	}
	
	private void initPare()
	{
		fileNo = this.getProperty("FileNo");
		fileType = this.getProperty("FileType");
		megType = this.getProperty("MegType");
		
		String sDate= StringFunction.replace(deductDate,"/","");
		String sLastDate = StringFunction.replace(lastDate,"/","");

		fileNo = StringFunction.replace(fileNo,"{$CurrentDate}",sDate);
		fileNo = StringFunction.replace(fileNo,"{$SixCurrentDate}",sDate.substring(2, 8));
		fileNo = StringFunction.replace(fileNo, "{$CurrentLastDate}", sLastDate.substring(2, 8));
	}
	
	
	//�ȴ�FCR�����ļ�ֱ���ɹ�
	private void getFileWith400() throws Exception {

		String sSql = "";
		
//		if(fileType.equals("BIFMBBATDW"))
//		{
//			sSql = "select tl.Ret_Status as Ret_Status,tl.describe"
//				+ "from TransAction_Log tl"
//				+ "where tl.ReceiveSystem = 'FROM_ESB'"
//				+ "and tl.Service_Code = '11005000002@52'"
//				+ "and tl.describe like %" + fileNo
//				+ "%'"; 
//		}else{
			sSql = "select tl.Ret_Status as Ret_Status,tl.describe"
					+ " from TransAction_Log tl"
					+ " where tl.ReceiveSystem = 'FROM_ESB'"
					+ " and tl.Service_Code = '11005000002@52'"
					+ " and tl.describe like '%" + fileNo
					+ "%'"; 
//		}	
			
			System.out.println(sSql);
		PreparedStatement psQuery = connection.prepareStatement(sSql);
		//��ѯFCR�����ļ��Ƿ�ɹ�
		ResultSet rs = psQuery.executeQuery();
		
		if(rs.next()){
			if(rs.getString("Ret_Status").startsWith("S")){
				logger.info("FCR�ļ����ճɹ�...��");
				FCRESBInstance FCResbInstance = new FCRESBInstance();
				
				// ��Χϵͳ�ļ�����״̬֪ͨ,�������Ϊ���ļ����� ״̬ ��ע
				CompositeData compositeData = FCResbInstance.FileTransferNoticeToFCR("system", "batch", rs.getString("describe"), "0000", fileType);
				
				
				System.out.println("���ر��ģ�"+compositeData);
				String ret_status = (String)FCRESBInstance.getValue(compositeData, "RET_STATUS");//����״̬,�ɹ�ΪS,ʧ��ΪF

				
				System.out.println("����״̬��"+ret_status);
				if(ret_status.endsWith("S")){
					logger.info("����FCR�����ļ�"+megType+"�ɹ�!");
					unitStatus= TaskConstants.ES_SUCCESSFUL;
				}else{
					logger.error("����FCR�����ļ�"+megType+"��Ϣʧ��!");
					unitStatus= TaskConstants.ES_FAILED;
				}
			}else{
				logger.error("����"+megType+"��Ϣʧ��!");
				unitStatus= TaskConstants.ES_FAILED;
			}
		}
		else
		{
			logger.error("ESBδ��Ӧ��");
			unitStatus= TaskConstants.ES_FAILED;
		}
		rs.close();
		psQuery.close();
	}

}
