package com.amarsoft;

import java.io.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.amarsoft.Biz.*;
import com.amarsoft.DESTask.InitializeFlow;
import com.amarsoft.DESTask.Biz.getBusinessApply;
import com.amarsoft.DESTask.Biz.getFlowTask;
import com.amarsoft.DESTask.datasplit.SplitInfo;

public class DesTools {
	private static Process p;

	private static boolean done = false;
    
	/**Ӱ�����ݿ�������*/
	public static final String  IMS_DataSource = "IMS";
	/**Ӱ�����ݿ�������*/
	public static  String  DB_FILE = "";
	
	public static void ExecCommand(String sCommand) {
		try {

			Process p = Runtime.getRuntime().exec("cmd.exe /c " + sCommand);
			BufferedReader input = new BufferedReader(new InputStreamReader(p
					.getInputStream()));
			String line;
			while ((line = input.readLine()) != null) {
				System.out.println(line);
			}
			input.close();
		} catch (java.io.IOException e) {
			// System.out.print(e.toString());
			e.printStackTrace();
		}
	}

	public static String getNow() {
		return new Date().toString();
	}

	public static String getNowTime() {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm"); // �Զ��������ʽ
		String sz_date = format.format(date);
		return sz_date;
	}

	/**
	 * 
	 */
	public static String diffYear(String sDate, int Years) throws Exception {
		if (Years == 0)
			return sDate;
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		cal.setTime(formatter.parse(sDate));
		cal.add(Calendar.YEAR, Years);
		return formatter.format(cal.getTime());
	}

	/**
	 * �ƶ���������,������Ӧ����,��BA��,FLOW����������
	 * 
	 * @throws Exception
	 */
	public static void SendFlowAndBusinessApply(String sObjectType,
			String FlowNo, String sApplyType, String sPhaseNo, String UserID,
			String OrgID, java.sql.Connection conn) throws Exception {
		AbstractBiz cb = new getFlowTask();
		cb.setValue(null, conn);
		String sFlowTaskSerialNo = cb.getReturn();

		cb = new getBusinessApply();
		cb.setValue(null, conn);
		String sObjectNo = cb.getReturn();
		SendFlowAndBusinessApply(sFlowTaskSerialNo, sObjectNo, sObjectType,
				FlowNo, sApplyType, sPhaseNo, UserID, OrgID, conn);
	}

	/**
	 * �ƶ���������,������Ӧ����,��BA��,FLOW����������
	 * 
	 * @param sFlowTaskSerialNo
	 * @param sObjectNo
	 * @param sObjectType
	 * @param sFlowNo
	 * @param sApplyType
	 * @param sPhaseNo
	 * @param sUserID
	 * @param sOrgID
	 */
	public static void SendFlowAndBusinessApply(String sFlowTaskSerialNo,
			String sObjectNo, String sObjectType, String sFlowNo,
			String sApplyType, String sPhaseNo, String sUserID, String sOrgID,
			java.sql.Connection conn) {
		java.sql.Statement stat = null;
		try {
			// ������Business_Apply
			String sSql = "Insert Into Business_Apply (SerialNo) values('"
					+ sObjectNo + "')";
			stat.executeUpdate(sSql);
			// ��������
			InitializeFlow InitializeFlow = new InitializeFlow();
			InitializeFlow.run(conn, sFlowTaskSerialNo, sObjectType, sObjectNo,
					sApplyType, sFlowNo, sPhaseNo, sUserID, sOrgID);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static String ReplaceAll(String s1, String s2, String s3) {
		if (s1 == null || s2 == null || s3 == null)
			return s1;
		while (s1.indexOf(s2) > -1) {
			s1 = s1.substring(0, s1.indexOf(s2)) + s3
					+ s1.substring(s1.indexOf(s2) + s2.length());
		}
		return s1;
	}

	public static SplitInfo getSplitInfo(ArrayList SplitInfo,
			String SplitColumnName) {
		SplitInfo sReturn = null;
		for (int i = 0; i < SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) SplitInfo.get(i);
			if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
				sReturn = si;
				break;
			}
		}
		return sReturn;
	}

	// ��ȡ���ݿ�����

	public static String getBusinessDate(java.sql.Connection con)
			throws Exception {

		// TODO Auto-generated method stub
		java.sql.Statement stat = null;

		String sReturn = "";

		try

		{

			stat = con.createStatement();

			String sql = "select curdeductdate from ploan_setup";

			java.sql.ResultSet rs = stat.executeQuery(sql);

			if (rs.next())

				sReturn = rs.getString(1);

		}

		catch (Exception ex)

		{

			ex.printStackTrace();

		}

		finally

		{

			if (stat != null)

				stat.close();

		}

		return sReturn;

	}

	/*
	 * 
	 * �õ������ʽ�������ַ���
	 * 
	 */

	public static String getDateTime(Date date, String format) {

		SimpleDateFormat sdfTempDate = new SimpleDateFormat(format);

		String prev = sdfTempDate.format(date);

		return prev;

	}

	/**
	 * 
	 * ������ݿ�����б��
	 * 
	 */

	public static String getSequence(java.sql.Connection connection,
			String SequenceName)

	throws Exception {

		String sReturn = "";

		String sSql = "Select " + SequenceName + ".NEXTVAL From dual";

		java.sql.ResultSet rs = null;

		try

		{

			java.sql.Statement stmt = connection.createStatement();

			rs = stmt.executeQuery(sSql);

			if (rs.next())

				sReturn = rs.getString(1);

			rs.close();

			stmt.close();

		}

		catch (Exception ex)

		{

			ex.printStackTrace();

			sReturn = "999999999999999";

		}

		return sReturn;

	}

}
