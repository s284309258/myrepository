package com.amarsoft.Biz;

import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.amarsoft.DESTask.datasplit.SplitInfo;



/**
 * ���Biz��������
 * */
public abstract class AbstractBiz {
	protected  String sSerialNo="";
	protected String sFlag = "true";
	protected ArrayList SplitInfo = null;
	
     public AbstractBiz()
     {
    	 
     }
      
     public abstract void setValue(ArrayList  SplitInfo,java.sql.Connection con) throws Exception;
     
     protected SplitInfo getSplitInfo(String SplitColumnName) {
 		SplitInfo sReturn = null;
 		for (int i = 0; i < this.SplitInfo.size(); i++) {
 			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
 			if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
 				sReturn = si;
 				break;
 			}
 		}
 		return sReturn;
 	}
     
 	public static String getSerialNo(String sTableName, String sColumnName,
 			String sDateFormat, String sNoFormat, Date dateToday,String preName,
 			Connection con) throws Exception {
 		
 		int iMaxNo = 0;
 		preName = "RL";
 		sNoFormat = "000000";
 		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
 		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
 		String sDate = simpledateformat.format(dateToday);
 		int iDateLen = sDate.length();
 		String sNewSerialNo = "";

 		sTableName = sTableName.toUpperCase();
 		sColumnName = sColumnName.toUpperCase();
 		java.sql.Statement stat = null; 

 		try {
 			stat = con.createStatement();
 			String sOld = "update OBJECT_MAXSN set MaxSerialNo =MaxSerialNo "
 					+ " where TableName='" + sTableName + "' and ColumnName='"
 					+ sColumnName + "' ";
 			
 			stat.executeUpdate(sOld);
 			
 			String sSql = "select MaxSerialNo from OBJECT_MAXSN "
 					+ " where TableName='" + sTableName + "' and ColumnName='"
 					+ sColumnName + "' ";

 			java.sql.ResultSet asresultset = stat.executeQuery(sSql);
 			
 			if (asresultset.next()) {
 				// �����ˮ�Ŵ��ڣ���������ˮ�š�
 				String sMaxSerialNo = asresultset.getString(1);
 				if(sMaxSerialNo.startsWith(preName))
 				sMaxSerialNo = sMaxSerialNo.substring(preName.length());  //ȡ��ǰ׺
 				// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
 				iMaxNo = 0;
 				if((sMaxSerialNo.length()-iDateLen)>sNoFormat.length())
 				{
 					sMaxSerialNo = sDate + sMaxSerialNo.substring(iDateLen+(sMaxSerialNo.length()-iDateLen-sNoFormat.length()));
 				}
 				
 				iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
 							.intValue();
 				
 				int tmp = iMaxNo+1;
 				sMaxSerialNo = sDate + decimalformat.format(tmp);
 				
 				sNewSerialNo = preName + sMaxSerialNo;
 				// ��������ˮ��
 				String s9 = "update OBJECT_MAXSN set MaxSerialNo ='"
 						+ sNewSerialNo + "' " + " where TableName='"
 						+ sTableName + "' and ColumnName='" + sColumnName
 						+ "' ";
 				stat.executeUpdate(s9);
 			} else {
 				// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
 				sNewSerialNo = sDate+"000001";
 				String s8 = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
 						+ " values( '"
 						+ sTableName
 						+ "','"
 						+ sColumnName
 						+ "','" + sNewSerialNo +sNewSerialNo + "')";
 				
 				stat.executeUpdate(s8);
 			}

 		} catch (Exception e) {
 			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
 		} finally {
 			stat.close();
 		}
 		return sNewSerialNo;
 	}
 	

	public String getReturn() {
		// TODO Auto-generated method stub
		return sSerialNo;
	}
	
	public String getFlag()
	{
		return sFlag;
	}
}
