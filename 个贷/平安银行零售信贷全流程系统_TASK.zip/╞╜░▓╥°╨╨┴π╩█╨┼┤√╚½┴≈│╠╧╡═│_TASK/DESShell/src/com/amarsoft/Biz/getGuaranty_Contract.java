package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;
/**
 * @deprecated
 * */

public class getGuaranty_Contract   extends AbstractBiz {
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("GUARANTY_CONTRACT","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"DB",con);
	}
}
