package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;

public class test  extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		sSerialNo =  getSerialNo("Test_INFO","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"KH",con);
	}
	
	public static void main(String args[])
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection condb= java.sql.DriverManager.getConnection("jdbc:oracle:thin:@172.18.254.19:1528:hsproduc","productmid","temp1234");

			AbstractBiz cb = new test();
			cb.setValue(null, condb);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}