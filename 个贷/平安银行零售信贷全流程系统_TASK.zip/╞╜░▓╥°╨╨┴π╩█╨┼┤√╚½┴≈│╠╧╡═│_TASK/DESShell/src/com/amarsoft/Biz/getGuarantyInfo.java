package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;
/**@deprecated*/
public class getGuarantyInfo  extends AbstractBiz{
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("GUARANTY_INFO","GUARANTYID","yyyyMMdd","000000", new java.util.Date(),"GI",con);
	}
}
