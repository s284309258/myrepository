package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;
/**@deprecated*/
public class getGuarantyContract1   extends AbstractBiz {

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("GUARANTY_CONTRACT","SERIALNO","yyyyMMdd","00000", new java.util.Date(),"DB",con);
		
	}
}
