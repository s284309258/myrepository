package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;
/**
 * @deprecated com.amarsoft.Biz.Customer.getCoBorrowerOrWarrantor
 * */
public class getCoBorrowerOrWarrantor  extends AbstractBiz{
	/**
	 * ��ÿͻ����,����֤������,֤�����ͻ�����û�в�ѯ��,����¿ͻ���
	 * */
	protected String sCertID = "";
	protected String sCertType = "";
	
	
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
			this.SplitInfo = SplitInfo;		
			
			//�ж� ����ͬ�����/�����˱�֤��	IsCoBorrowerOrWarrantorFlag �Ƿ�ѡ,��δ��ѡ������
			if(getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData().equals(""))
				return;
			
			boolean exsitFlag = false;
			String sSql = "";
		    String sSqlOne =  "select /*+ FIRST_ROWS +*/ CustomerID from ind_info " +
    		" where certid='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
			if(getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData().equals("Ind01"))//����֤
			{
				 sSql = "select CustomerID from ind_info " +
		    		" where certid='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"' and certid is not null ";
				java.sql.ResultSet rs1 = con.createStatement().executeQuery(sSql);
			    if(rs1.next())
			    {
			    	exsitFlag = true;
			    	sSerialNo = rs1.getString("CustomerID");
			    }
			    rs1.getStatement().close();
			    if(!exsitFlag)
			    {
					if(getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData().length()==15)
					{
						
						sSql = "select CustomerID from ind_info " +
			    		" where certid=getNewID('"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"') and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
						rs1 = con.createStatement().executeQuery(sSql);
						if(rs1.next())
					    {
					    	exsitFlag = true;
					    	sSerialNo = rs1.getString("CustomerID");
					    }
					    rs1.getStatement().close();
					}
					else
					{
						sSql = "select CustomerID from ind_info " +
			    		" where getNewID(certid)='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
						rs1 = con.createStatement().executeQuery(sSql);
						if(rs1.next())
					    {
					    	exsitFlag = true;
					    	sSerialNo = rs1.getString("CustomerID");
					    }
					    rs1.getStatement().close();
					}
			    }
			}
			
//			System.out.println(sSql);
		    java.sql.ResultSet rs = con.createStatement().executeQuery(sSqlOne);
		    if(rs.next())
		    {
		    	if(!exsitFlag)
		    	{
		    		sSerialNo = rs.getString("CustomerID");
		    	}
		    }
		    else
		    {
		    	sSerialNo =  getSerialNo("CUSTOMER_INFO","CUSTOMERID","yyyyMMdd","000000", new java.util.Date(),"kh",con);
		    
		    }
		    
		    rs.getStatement().close();
		    
	}
}
