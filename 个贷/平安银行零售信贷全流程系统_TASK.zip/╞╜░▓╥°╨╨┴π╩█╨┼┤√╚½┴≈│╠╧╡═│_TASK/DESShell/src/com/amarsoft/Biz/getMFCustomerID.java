package com.amarsoft.Biz;

import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.amarsoft.DESTask.datasplit.SplitInfo;
import com.amarsoft.account.write.execute.GetMFCustomerAction;
import com.amarsoft.account.entity.IndInfo;
/**
 * 
 * @deprecated
 *
 */
public abstract class getMFCustomerID {
	protected  String sMFCustomerID="";
	protected ArrayList SplitInfo = null;
	
     public getMFCustomerID()
     {
    	 
     }
      
     public abstract void setValue(ArrayList  SplitInfo,java.sql.Connection con) throws Exception;
     
     protected SplitInfo getSplitInfo(String SplitColumnName) {
 		SplitInfo sReturn = null;
 		for (int i = 0; i < this.SplitInfo.size(); i++) {
 			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
 			if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
 				sReturn = si;
 				break;
 			}
 		}
 		return sReturn;
 	}
     
 	public static String getECIFCustomerID(String sFullName, String sCertType,
 			String sCertID, String sSex, String sBirthDay) throws Exception {
 			String sNewMFCustomerID = "";
 		try {
 			IndInfo ii = new IndInfo();
 			ii.setFullName(sFullName);
 			ii.setCertType(sCertType);
 			ii.setCertID(sCertID);
 			ii.setSex(sSex);
 			ii.setBirthDay(sBirthDay);
 			
 			GetMFCustomerAction getmf = new GetMFCustomerAction();
 			getmf.calcMFCustomerID(ii,"des","des");
 			ArrayList<IndInfo>  arrReturn  = getmf.getArrayList(); 
 			
 			IndInfo iii = new IndInfo();
 			
 			if(arrReturn.size() == 0) { 
 				iii  = arrReturn.get(0);
 				sNewMFCustomerID = iii.getMfCustomerID();
 			}

 		} catch (Exception e) {
 			throw new Exception("��ȡ���Ŀͻ���...ʧ�ܣ�" + e.getMessage());
 		} finally {
 			
 		}
 		return sNewMFCustomerID;
 	}
 	

	public String getReturn() {
		// TODO Auto-generated method stub
		return sMFCustomerID;
	}
}
