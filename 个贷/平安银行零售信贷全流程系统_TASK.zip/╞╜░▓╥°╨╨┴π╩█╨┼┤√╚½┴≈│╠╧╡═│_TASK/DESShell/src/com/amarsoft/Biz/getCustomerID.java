package com.amarsoft.Biz;

import java.sql.Connection;
import java.util.ArrayList;
/**
 * @deprecated com.amarsoft.Biz.Customer.getCustomerID
 * */
public class getCustomerID extends AbstractBiz {
	/**
	 * ��ÿͻ����,����֤������,֤�����ͻ�����û�в�ѯ��,����¿ͻ���
	 * */
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
			this.SplitInfo = SplitInfo;
			

			System.out.println("SplitInfo"+SplitInfo.toString());
			
			boolean exsitFlag = false;
			String sSql = "";
		    String sSqlOne = "select /*+ FIRST_ROWS +*/CustomerID from ind_info where certid='"+getSplitInfo("Main_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Main_CertType").getSplitData()+"'";
		    System.out.println("certtyp="+getSplitInfo("Main_CertType").getSplitData());
		    if(getSplitInfo("Main_CertType").getSplitData().equals("Ind01")) //����֤
			{
		    	 sSql = "select CustomerID from ind_info " +
		    		" where certid='"+getSplitInfo("Main_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Main_CertType").getSplitData()+"' and certid is not null ";
				java.sql.ResultSet rs1 = con.createStatement().executeQuery(sSql);
			    if(rs1.next())
			    {
			    	exsitFlag = true;
			    	sSerialNo = rs1.getString("CustomerID");
			    }
			    rs1.getStatement().close();
			    if(!exsitFlag)
			    {
					if(getSplitInfo("Main_CertID").getSplitData().length()==15)
					{				    
					    	sSql = "select CustomerID from ind_info " +
				    		" where certid=getNewID('"+getSplitInfo("Main_CertID").getSplitData()+"') and certtype='"+getSplitInfo("Main_CertType").getSplitData()+"' and certid is not null ";
							rs1 = con.createStatement().executeQuery(sSql);
						    if(rs1.next())
						    {
						    	exsitFlag = true;
						    	sSerialNo = rs1.getString("CustomerID");
						    }
						    rs1.getStatement().close();
					}
					else
					{
						sSql = "select CustomerID from ind_info " +
			    		" where getNewID(certid)='"+getSplitInfo("Main_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Main_CertType").getSplitData()+"' and certid is not null ";
						rs1 = con.createStatement().executeQuery(sSql);
					    if(rs1.next())
					    {
					    	exsitFlag = true;
					    	sSerialNo = rs1.getString("CustomerID");
					    }
					    rs1.getStatement().close();
					}
			    }
			}
		    
		    System.out.println(sSql);
		    java.sql.ResultSet rs = con.createStatement().executeQuery(sSqlOne);
		    if(rs.next())
		    {
		    	if(!exsitFlag)
		    	{
		    		sSerialNo = rs.getString("CustomerID");
		    	}
		    }
		    else
		    {
		    	sSerialNo =  getSerialNo("CUSTOMER_INFO","CUSTOMERID","yyyyMMdd","000000", new java.util.Date(),"kh",con);
		    	//sSerialNo = "kh"+sSerialNo;
		    }
		    
		    rs.getStatement().close();
		    
	}
    


}
