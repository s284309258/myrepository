package com.amarsoft.are.sql;

import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.amarsoft.DBConnection.DBConnection;
/**
 * ��дDBFunction 
 * �Ѵ���������ĵ���
 * @author 
 *
 */
public class DBFunction  {

	
	
	public static int iChange = 2;
	
	public static int iDebugMode = 0;//0 for none, 1 for all, 2 only for excuteSql

	public static String dbname = "Loan";
	
	public static String Pre = "RL";//ƽ���������е���ˮ��ͳһ��RL
	
	public DBFunction() {
	}

	/**
	 * ����ָ����ʽ�����ˮ�� String sTableName ָ�����ݱ� String sColumnName ָ�����ݱ����ֶ� String
	 * sWhereClause ָ�����ݱ��������� String sDateFormat ָ������ǰ׺��ʽ������Java
	 * SimpleDateFormat��׼ String sNoFormat ָ����ŵĸ�ʽ ����Java DecimalFormat��׼ Date
	 * dateToday ָ��������
	 */

	// ex:getSerialNo("BUSINESS_APPLY","SERIALNO")
	// ex:getSerialNo("BUSINESS_WASTEBOOK","SERIALNO","yyyyMMdd","00000000",new
	// java.util.Date(),null)
	public static String getSerialNo(String sTableName, String sColumnName,
			Transaction transSql) throws Exception {
		// modify by hxd in 205/03/29 : from 0000 to 000000
		// modify by zywei in 208/03/03 : from 000000 to 0000
		//return getSerialNo(sTableName, sColumnName, "yyyyMMdd", "0000",
				//new java.util.Date(), transSql);
		return getSerialNo(sTableName, sColumnName,Pre,transSql);
	}

	// Ŀǰû���ṩprefix,��'prefix'+'yyyyMMdd', java
	// err:java.lang.IllegalArgumentException
	// /*
	static public String getSerialNo(String sTableName, String sColumnName,
			String sPrefix, Transaction transSql) throws Exception {
		//add by byhu 20050805
		if(sPrefix==null || sPrefix.equals(""))
			sPrefix = "'"+Pre+"'";
		else sPrefix = "'"+sPrefix+"'"; 
			

		// modify by hxd in 205/03/29 : from 0000 to 000000
		// modify by zywei in 208/03/03 : from 000000 to 0000
		return getSerialNo(sTableName, sColumnName,
				sPrefix + "yyyyMMdd", "000000", new java.util.Date(),
				transSql);
	}
	private static boolean containsProductName(String s, String s1) {
		return s.indexOf(s1) != -1;
	}

	public static String getSerialNo(String sTableName, String sColumnName,
			String sDateFormat, String sNoFormat, Date dateToday,
			Transaction transSql) throws Exception {
		
		Transaction Sqlca = null;
		try {
			DBConnection dc = new DBConnection();
			Sqlca= new Transaction(dc.getConn(dbname));
			
		} catch (Exception e) {
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		}

		int iMaxNo = 0;
		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
		String sDate = simpledateformat.format(dateToday);
		int iDateLen = sDate.length();
		String sNewSerialNo = "";

		sTableName = sTableName.toUpperCase();
		sColumnName = sColumnName.toUpperCase();

		Sqlca.conn.setAutoCommit(false);

		try {
			String sOld = "update OBJECT_MAXSN set MaxSerialNo =MaxSerialNo "
					+ " where TableName='" + sTableName + "' and ColumnName='"
					+ sColumnName + "' ";
			Sqlca.executeSQL(sOld);
			String sSql = "select MaxSerialNo from OBJECT_MAXSN "
					+ " where TableName='" + sTableName + "' and ColumnName='"
					+ sColumnName + "' ";

			ASResultSet asresultset = Sqlca.getResultSet(sSql);
			if (asresultset.next()) {
				// �����ˮ�Ŵ��ڣ���������ˮ�š�
				String sMaxSerialNo = asresultset.getString(1);
				asresultset.getStatement().close();

				// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
				iMaxNo = 0;
				if (sMaxSerialNo != null
						&& sMaxSerialNo.indexOf(sDate, 0) != -1) {
					iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
							.intValue();
					sNewSerialNo = sDate + decimalformat.format(iMaxNo + 1);
				} else // modify by hxd in 2004/08/02 for ���ܴ�1��ʼ����ֹ�������ڵ���...
				{
					sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName,
							"", sDateFormat, sNoFormat, dateToday, Sqlca);
				}

				// ��������ˮ��
				String s9 = "update OBJECT_MAXSN set MaxSerialNo ='"
						+ sNewSerialNo + "' " + " where TableName='"
						+ sTableName + "' and ColumnName='" + sColumnName
						+ "' ";
				Sqlca.executeSQL(s9);
			} else {
				// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
				asresultset.getStatement().close();
				sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName, "",
						sDateFormat, sNoFormat, dateToday, Sqlca);
				String s8 = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
						+ " values( '"
						+ sTableName
						+ "','"
						+ sColumnName
						+ "','" + sNewSerialNo + "')";
				Sqlca.executeSQL(s8);
			}

			Sqlca.conn.commit();
		} catch (Exception e) {
			Sqlca.conn.rollback();
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		} finally {
			Sqlca.disConnect(); //jacky hao 2005-07-28 , closed by caller
		}

		//System.out.println("getSerialNo(�Źܹ���)..." + sNewSerialNo);

		return sNewSerialNo;
	}

	// add for �����ӿڣ�ֱ�ӽ������ݿ����ӣ���ʹ��conn pool
	public static String getSerialNoXD(String sTableName, String sColumnName,
			String sDateFormat, String sNoFormat, Date dateToday,
			Transaction transSql) throws Exception {

		// ���»��һ�����ݿ�����
		Transaction Sqlca = null;

		try {
			DBConnection dc = new DBConnection();
			Sqlca= new Transaction(dc.getConn(dbname));
			
			
		} catch (Exception e) {
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		}
		Sqlca.conn.setAutoCommit(false);

		int iMaxNo = 0;
		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
		String sDate = simpledateformat.format(dateToday);
		int iDateLen = sDate.length();
		String sNewSerialNo = "";

		sTableName = sTableName.toUpperCase();
		sColumnName = sColumnName.toUpperCase();

		try {
			// ȡ�������ˮ�ű��д�ŵĶ�Ӧ��ˮ��
			String sSql = "select MaxSerialNo from OBJECT_MAXSN "
					+ " where TableName='" + sTableName + "' and ColumnName='"
					+ sColumnName + "' " + " for update ";
			if (containsProductName(Sqlca.conn.getMetaData()
					.getDatabaseProductName().toUpperCase(),
					"ADAPTIVE SERVER ENTERPRISE"))
				sSql = "select MaxSerialNo from OBJECT_MAXSN holdlock "
						+ " where TableName='" + sTableName
						+ "' and ColumnName='" + sColumnName + "' ";

			ASResultSet asresultset = Sqlca.getResultSet(sSql);
			if (asresultset.next()) {
				// �����ˮ�Ŵ��ڣ���������ˮ�š�
				String sMaxSerialNo = asresultset.getString(1);
				asresultset.getStatement().close();

				// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
				iMaxNo = 0;
				if (sMaxSerialNo != null
						&& sMaxSerialNo.indexOf(sDate, 0) != -1) {
					iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
							.intValue();
					sNewSerialNo = sDate + decimalformat.format(iMaxNo + 1);
				} else // modify by hxd in 2004/08/02 for ���ܴ�1��ʼ����ֹ�������ڵ���...
				{
					sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName,
							"", sDateFormat, sNoFormat, dateToday, Sqlca);
				}

				// ��������ˮ��
				String s9 = "update OBJECT_MAXSN set MaxSerialNo ='"
						+ sNewSerialNo + "' " + " where TableName='"
						+ sTableName + "' and ColumnName='" + sColumnName
						+ "' ";
				Sqlca.executeSQL(s9);
			} else {
				// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
				asresultset.getStatement().close();
				sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName, "",
						sDateFormat, sNoFormat, dateToday, Sqlca);
				String s8 = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
						+ " values( '"
						+ sTableName
						+ "','"
						+ sColumnName
						+ "','" + sNewSerialNo + "')";
				Sqlca.executeSQL(s8);
			}

			Sqlca.conn.commit();
		} catch (Exception e) {
			Sqlca.conn.rollback();
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		} finally {
			Sqlca.disConnect();
		}

		return sNewSerialNo;
	}

	// ��ͳ��ȡ���������ˮ��
	// �÷���ֱ�Ӵ����ݱ���ȡ�������ˮ�ţ�Ч�ʽϵͣ��ڲ�����������¿��ܻᷢ���غţ������Ƽ�ʹ��
	static public String getSerialNoFromDB(String sTableName,
			String sColumnName, String sWhereClause, String sDateFormat,
			String sNoFormat, java.util.Date dateToday, Transaction transSql)
			throws Exception {
		System.out.println("**********�������ȡ��ˮ�ŵķ�ʽ(getSerialNoFromDB)**********");

		int iDateLen, iMaxNo = 0;
		String sSql, sMaxSerialNo, sDate, sNewSerialNo;
		SimpleDateFormat sdfTemp;
		DecimalFormat dfTemp;
		ASResultSet rsTemp;

		sdfTemp = new SimpleDateFormat(sDateFormat);
		dfTemp = new DecimalFormat(sNoFormat);

		sDate = sdfTemp.format(dateToday);
		iDateLen = sDate.length();

		sSql = "select max(" + sColumnName + ") from " + sTableName + " where "
				+ sColumnName + " like '" + sDate + "%' ";
		if (sWhereClause.length() > 0)
			sSql += " and " + sWhereClause;

		rsTemp = transSql.getResultSet(sSql);
		if (rsTemp.next()) {
			sMaxSerialNo = rsTemp.getString(1);
			if (sMaxSerialNo != null)
				iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
						.intValue();
		}

		sNewSerialNo = sDate + dfTemp.format(iMaxNo + 1);
		rsTemp.getStatement().close();
		System.out.println("..." + sNewSerialNo + "...");
		return sNewSerialNo;
	}

	public static String getSerialNo(String s, String s1, String s2, String s3,
			String s4, Date dateToday, Transaction transaction)
			throws Exception {
		return getSerialNo(s, s1, s3, s4, dateToday, transaction);
	}
	

	// ����ʹ��
	public static void main(String[] argv) {
		try {
			String sSerialNo = DBFunction.getSerialNo("BUSINESS_WASTEBOOK",
					"SERIALNO", "yyyyMMdd", "00000000", new java.util.Date(),
					null);

			System.out.println("-----------------begin--------------------");
			System.out.println(sSerialNo);
			System.out.println("-----------------end--------------------");
		} catch (Exception e) {
			System.out.println("main:" + e.toString());
		}
	}
	//for alarm module 
	public static String getSerialNo_for_alarm(String s, String s1, String s2, String s3,
			String s4, Date dateToday, Transaction transaction)
			throws Exception {
		return getSerialNo_for_alarm(s, s1, s3, s4, dateToday, transaction);
	}
	// ���ⲿ�� connection
//	 �������ˮ�ű���ȡ��Ӧ��ˮ��
	// ex:getSerialNo("BUSINESS_WASTEBOOK","SERIALNO","yyyyMMdd","00000000",new
	// java.util.Date(),null)
	public static String getSerialNo_for_alarm(String sTableName, String sColumnName,
			String sDateFormat, String sNoFormat, Date dateToday,
			Transaction transSql) throws Exception {

	
		Transaction Sqlca = null;

		try {
			DBConnection dc = new DBConnection();
			Sqlca= new Transaction(dc.getConn(dbname));
			
		} catch (Exception e) {
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		}
	 
		int iMaxNo = 0;
		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
		String sDate = simpledateformat.format(dateToday);
		int iDateLen = sDate.length();
		String sNewSerialNo = "";

		sTableName = sTableName.toUpperCase();
		sColumnName = sColumnName.toUpperCase();

		Sqlca.conn.setAutoCommit(false);

		try {
			String sOld = "update OBJECT_MAXSN set MaxSerialNo =MaxSerialNo "
					+ " where TableName='" + sTableName + "' and ColumnName='"
					+ sColumnName + "' ";
			Sqlca.executeSQL(sOld);
			String sSql = "select MaxSerialNo from OBJECT_MAXSN "
					+ " where TableName='" + sTableName + "' and ColumnName='"
					+ sColumnName + "' ";

			ASResultSet asresultset = Sqlca.getResultSet(sSql);
			if (asresultset.next()) {
				// �����ˮ�Ŵ��ڣ���������ˮ�š�
				String sMaxSerialNo = asresultset.getString(1);
				asresultset.getStatement().close();

				// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
				iMaxNo = 0;
				if (sMaxSerialNo != null
						&& sMaxSerialNo.indexOf(sDate, 0) != -1) {
					iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
							.intValue();
					sNewSerialNo = sDate + decimalformat.format(iMaxNo + 1);
				} else // modify by hxd in 2004/08/02 for ���ܴ�1��ʼ����ֹ�������ڵ���...
				{
					sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName,
							"", sDateFormat, sNoFormat, dateToday, Sqlca);
				}

				// ��������ˮ��
				String s9 = "update OBJECT_MAXSN set MaxSerialNo ='"
						+ sNewSerialNo + "' " + " where TableName='"
						+ sTableName + "' and ColumnName='" + sColumnName
						+ "' ";
				Sqlca.executeSQL(s9);
			} else {
				// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
				asresultset.getStatement().close();
				sNewSerialNo = getSerialNoFromDB(sTableName, sColumnName, "",
						sDateFormat, sNoFormat, dateToday, Sqlca);
				String s8 = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
						+ " values( '"
						+ sTableName
						+ "','"
						+ sColumnName
						+ "','" + sNewSerialNo + "')";
				Sqlca.executeSQL(s8);
			}

			Sqlca.conn.commit();
		} catch (Exception e) {
			Sqlca.conn.rollback();
			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
		} finally {
			//Sqlca.disConnect(); //jacky hao 2005-07-28 , closed by caller
		}

		return sNewSerialNo;
	}
	/**
	 * ƽ��������������
	 * @param sTableName
	 * @param sColumnName
	 * @param sDateFormat
	 * @param sNoFormat
	 * @param dateToday
	 * @param preName
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public static String getSerialNo(String sTableName, String sColumnName,
 			String sDateFormat, String sNoFormat, Date dateToday,String preName,
 			Connection con) throws Exception {
 		
 		int iMaxNo = 0;
 		SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFormat);
 		DecimalFormat decimalformat = new DecimalFormat(sNoFormat);
 		String sDate = simpledateformat.format(dateToday);
 		int iDateLen = sDate.length();
 		String sNewSerialNo = "";

 		sTableName = sTableName.toUpperCase();
 		sColumnName = sColumnName.toUpperCase();
 		java.sql.Statement stat = null; 

 		try {
 			stat = con.createStatement();
 			String sOld = "update OBJECT_MAXSN set MaxSerialNo =MaxSerialNo "
 					+ " where TableName='" + sTableName + "' and ColumnName='"
 					+ sColumnName + "' ";
 			
 			stat.executeUpdate(sOld);
 			
 			String sSql = "select MaxSerialNo from OBJECT_MAXSN "
 					+ " where TableName='" + sTableName + "' and ColumnName='"
 					+ sColumnName + "' ";

 			java.sql.ResultSet asresultset = stat.executeQuery(sSql);
 			
 			if (asresultset.next()) {
 				// �����ˮ�Ŵ��ڣ���������ˮ�š�
 				String sMaxSerialNo = asresultset.getString(1);
 				if(sMaxSerialNo.startsWith(preName))
 				sMaxSerialNo = sMaxSerialNo.substring(preName.length());  //ȡ��ǰ׺
 				// �����ˮ�Ŵ�����Ϊͬһ�죬����ˮ�Ŵӵ�ǰ��������У������1��ʼ��
 				iMaxNo = 0;
 				if((sMaxSerialNo.length()-iDateLen)>sNoFormat.length())
 				{
 					sMaxSerialNo = sDate + sMaxSerialNo.substring(iDateLen+(sMaxSerialNo.length()-iDateLen-sNoFormat.length()));
 				}
 				
 				iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen))
 							.intValue();
 				
 				int tmp = iMaxNo+1;
 				sMaxSerialNo = sDate + decimalformat.format(tmp);
 				
 				sNewSerialNo = preName + sMaxSerialNo;
 				// ��������ˮ��
 				String s9 = "update OBJECT_MAXSN set MaxSerialNo ='"
 						+ sNewSerialNo + "' " + " where TableName='"
 						+ sTableName + "' and ColumnName='" + sColumnName
 						+ "' ";
 				stat.executeUpdate(s9);
 			} else {
 				// �����ˮ�Ų����ڣ���ֱ�Ӵ�ָ�������ݱ��л�ã����������ˮ�ű��в�����Ӧ��¼��
 				sNewSerialNo = sDate+"0001";
 				String s8 = "insert into OBJECT_MAXSN (tablename,columnname,maxserialno) "
 						+ " values( '"
 						+ sTableName
 						+ "','"
 						+ sColumnName
 						+ "','" + sNewSerialNo +sNewSerialNo + "')";
 				
 				stat.executeUpdate(s8);
 			}

 		} catch (Exception e) {
 			throw new Exception("getSerialNo...ʧ�ܣ�" + e.getMessage());
 		} finally {
 			stat.close();
 		}
 		return sNewSerialNo;
 	}
	
	public static String getSerialNoForInterface(String TableName,String sColumnName,Transaction transSql)throws Exception
	{
		return getSerialNo(TableName, sColumnName,"947444" + "yyMMdd", "0000000000", new java.util.Date(),transSql);
	}
	
 	
}