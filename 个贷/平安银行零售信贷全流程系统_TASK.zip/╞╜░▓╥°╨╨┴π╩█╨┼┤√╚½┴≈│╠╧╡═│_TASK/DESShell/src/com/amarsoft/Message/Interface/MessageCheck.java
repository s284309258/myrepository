package com.amarsoft.Message.Interface;

import com.amarsoft.Message.MessageBody;
public interface MessageCheck {
     void doCheck(MessageBody message);
}
