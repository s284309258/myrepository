package com.amarsoft.Message;

import com.amarsoft.Message.Interface.Message;
import com.amarsoft.Message.Interface.MessageCheck;

/**
 * ���ݿ���Դ���� ����ʱ���޸�
 * 
 * */
public abstract class DBMessageAbstract implements Message,MessageCheck{
	public abstract void parseMessage() ;
	public abstract void setMessage();
    public void doCheck(MessageBody message) {
		
	}
}
