package com.amarsoft.Message.Interface;

public interface  Message { 
	public void parseMessage(); 
	public void setMessage(); 
}
