package com.amarsoft.Message;

public class MessageBody {
}
