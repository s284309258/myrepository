package com.amarsoft.DataCheck;

import java.util.regex.*;

public class EMailCheck  extends DataCheck{

	public boolean Check() {
		 if(!this.si.isNulls()&&this.Data.equals(""))
			 return true;
		 this.Data = this.Data.toLowerCase();
		 Pattern p = Pattern.compile("(\\w+.)+@(\\w+.)+[a-zA-Z]{2,3}");
	     Matcher m = p.matcher(this.Data);
	     boolean b = m.matches();
	     if(b) {
	            return true;
	     } else {
	    	    this.AddReturnMsg("��"+si.getColumnGBName()+"�����ǺϷ����ʼ���ַ!");
	            return false;
	     }
	}
    
}
