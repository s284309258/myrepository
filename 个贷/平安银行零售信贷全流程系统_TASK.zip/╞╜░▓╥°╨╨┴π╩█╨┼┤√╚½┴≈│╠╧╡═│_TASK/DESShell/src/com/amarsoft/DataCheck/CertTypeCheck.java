package com.amarsoft.DataCheck;

/**@deprecated*/
public class CertTypeCheck  extends DataCheck{

	public boolean Check() {
		String CountryName = "";
//		if(this.si.getColumnName().equals("Main_CertType"))
//		{
//			CountryName = this.getSplitInfo("Main_CountryName").getSplitData();
//		}
//		else if(this.si.getColumnName().equals("Mate_CertType"))
//		{
//			CountryName = this.getSplitInfo("Mate_CountryName").getSplitData();
//		}
//		else if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_CertType"))
//		{
//			CountryName = this.getSplitInfo("CoBorrowerOrWarrantor_CountryName").getSplitData();
//		}
//		else if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_CertType_2"))
//		{
//			CountryName = this.getSplitInfo("CoBorrowerOrWarrantor_CountryName_2").getSplitData();
//		}
		
		setCertType(CountryName);
		return true;
	}
	
	
	private void setCertType(String CountryName)
	{
		if(this.Data.equals("1")) //����֤
	    {
	    	this.si.setSplitData("Ind01");
	    }
		else if(this.Data.equals("2"))//�۰ľ��������ڵ�ͨ��֤
		{
			this.si.setSplitData("Ind06");
		}
		else if(this.Data.equals("3"))//̨����������ڵ�ͨ��֤
		{
			this.si.setSplitData("Ind07");
		}

		else if(this.Data.equals("4"))//����
		{
			this.si.setSplitData("Ind03");
		}
		else if(this.Data.equals("0")) //����
		{
			this.si.setSplitData("Ind11");
		}
		//����֤
		else if(this.Data.indexOf("��")>-1&&(this.Data.indexOf("ʿ��")==-1&&this.Data.indexOf("��")==-1))
		{
			this.si.setSplitData("Ind04");
		}
//		ʿ��֤
		else if(this.Data.indexOf("ʿ��")>-1&&(this.Data.indexOf("��")==-1&&this.Data.indexOf("��")==-1))
		{
			this.si.setSplitData("Ind05");
		}
		//����֤
		else if(this.Data.indexOf("��")>-1)
		{
			this.si.setSplitData("Ind10");
		}
		else //����
		{
			this.si.setSplitData("Ind11");
		}
	}
}
