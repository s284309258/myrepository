package com.amarsoft.DataCheck;

import java.util.ArrayList;

import com.amarsoft.DESTask.datasplit.DataSplit;
import com.amarsoft.DESTask.datasplit.SplitInfo;


public abstract class DataCheck {
	protected String Data = "";
	protected String ReturnMsg = "";
	protected SplitInfo si = null;
	protected DataSplit  ds = null;
	protected ArrayList  SplitInfo= new ArrayList();
	protected java.sql.Connection conn = null; 
	public DataCheck()
    {
    	
    }
	
	public  void AddReturnMsg(String msg)
	{
		if(ReturnMsg.lastIndexOf(";")==ReturnMsg.length())
			ReturnMsg += msg;
		else	
			ReturnMsg += ";"+msg;
	}
	
	public  String getReturnMsg()
	{
		return ReturnMsg;
	}
	
    public  void setSplitData(DataSplit ds,SplitInfo si)
    {
    	 this.Data = si.getSplitData();
    	 this.si = si;
    	 this.ds = ds;
    	 this.SplitInfo = ds.getMapArray();
    }
    
    
    public  void setConnection(java.sql.Connection conn)
    {
    	 this.conn = conn;
    }
    
    public abstract boolean Check();
    
    protected SplitInfo getSplitInfo(String SplitColumnName) {
		SplitInfo sReturn = null;
		for (int i = 0; i < this.SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
			if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
				sReturn = si;
				break;
			}
		}
		return sReturn;
	}
    
    // added by 53	2009-12-02
    protected SplitInfo getSplitInfo(String projectNo,String SplitColumnName) {
		SplitInfo sReturn = null;
		for (int i = 0; i < this.SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
			if (si.getColumnName().equalsIgnoreCase(SplitColumnName) && projectNo.equals(si.getProjectNo())) {
				sReturn = si;
				break;
			}
		}
		return sReturn;
	}
}
