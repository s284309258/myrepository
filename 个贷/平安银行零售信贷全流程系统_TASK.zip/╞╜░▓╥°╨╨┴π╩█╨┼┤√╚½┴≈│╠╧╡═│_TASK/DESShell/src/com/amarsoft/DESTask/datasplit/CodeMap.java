package com.amarsoft.DESTask.datasplit;

public class CodeMap {
    private String DesName = "";
    private String DesItemNo = "";
    private String DesItemName = "";
    private String LoanItemCode = "";
    private String OtherCode = "";
    private String KeyValue = "";
	private String KeySeq = ","; //�ؼ��ַָ���
	private String MulCheckSeq = "/";//��ѡ��ָ���
	private String OtherColumn = "";//��ѡ��ָ���
    public CodeMap(String DesItemNo)
    {
    	this.DesItemNo = DesItemNo;
    }
    
    public final String getDesItemNo()
    {
    	return this.DesItemNo;
    }
    
	/**
	 * @return Returns the desItemName.
	 */
	public final String getDesItemName() {
		return DesItemName;
	}
	/**
	 * @param desItemName The desItemName to set.
	 */
	public final void setDesItemName(String desItemName) {
		DesItemName = desItemName;
	}

	/**
	 * @param desItemNo The desItemNo to set.
	 */
	public final void setDesItemNo(String desItemNo) {
		DesItemNo = desItemNo;
	}
	/**
	 * @return Returns the desName.
	 */
	public final String getDesName() {
		return DesName;
	}
	/**
	 * @param desName The desName to set.
	 */
	public final void setDesName(String desName) {
		DesName = desName;
	}
	/**
	 * @return Returns the loanItemCode.
	 */
	public final String getLoanItemCode() {
		return LoanItemCode;
	}
	/**
	 * @param loanItemCode The loanItemCode to set.
	 */
	public final void setLoanItemCode(String loanItemCode) {
		LoanItemCode = loanItemCode;
	}
	/**
	 * @return Returns the otherCode.
	 */
	public final String getOtherCode() {
		if(OtherCode==null) return "0";
		else return OtherCode;
	}
	/**
	 * @param otherCode The otherCode to set.
	 */
	public final void setOtherCode(String otherCode) {
		if(OtherCode==null) this.OtherCode = "0";
		else OtherCode = otherCode;
	}

	/**
	 * @return Returns the keySeq.
	 */
	public final String getKeySeq() {
		return KeySeq;
	}

	/**
	 * @param keySeq The keySeq to set.
	 */
	public final void setKeySeq(String keySeq) {
		KeySeq = keySeq;
	}

	/**
	 * @return Returns the keyValue.
	 */
	public final String getKeyValue() {
		return KeyValue;
	}

	/**
	 * @param keyValue The keyValue to set.
	 */
	public final void setKeyValue(String keyValue) {
		KeyValue = keyValue;
	}

	/**
	 * @return Returns the mulCheckSeq.
	 */
	public final String getMulCheckSeq() {
		return MulCheckSeq;
	}

	/**
	 * @param mulCheckSeq The mulCheckSeq to set.
	 */
	public final void setMulCheckSeq(String mulCheckSeq) {
		MulCheckSeq = mulCheckSeq;
	}

	/**
	 * @return Returns the otherColumn.
	 */
	public final String getOtherColumn() {
		return OtherColumn;
	}

	/**
	 * @param otherColumn The otherColumn to set.
	 */
	public final void setOtherColumn(String otherColumn) {
		OtherColumn = otherColumn;
	}
    
    
    
}
