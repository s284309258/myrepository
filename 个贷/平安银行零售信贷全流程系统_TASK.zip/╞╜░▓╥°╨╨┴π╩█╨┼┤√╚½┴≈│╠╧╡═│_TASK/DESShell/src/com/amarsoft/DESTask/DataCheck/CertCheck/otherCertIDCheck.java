package com.amarsoft.DESTask.DataCheck.CertCheck;

/**
 * ��ͬ�����/���˱�֤�� 
 * */
public class otherCertIDCheck  extends AbstractCertCheck{

	@Override
	protected void setValues() {
		// TODO Auto-generated method stub
		 
		this.CertID = this.Data;
		this.CERTID_AREANAME = this.si.getColumnName();
		if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_CertID"))
		{
			this.CERTTYPE_AREANAME = "CoBorrowerOrWarrantor_CertType";
			this.CertType = this.getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData();
			this.Sex = this.getSplitInfo("CoBorrowerOrWarrantor_Sex").getSplitData();
			this.Birthday = this.getSplitInfo("CoBorrowerOrWarrantor_Birthday").getSplitData();
			this.CheckSex = true;
			this.CheckBirthday = true;
		}
		else if(this.si.getColumnName().equals("CoBorrowerOrWarrantor2_CertID"))
		{
			this.CERTTYPE_AREANAME = "CoBorrowerOrWarrantor2_CertType";
			this.CertType = this.getSplitInfo("CoBorrowerOrWarrantor2_CertType").getSplitData();
			this.Sex = this.getSplitInfo("CoBorrowerOrWarrantor2_Sex").getSplitData();
			this.Birthday = this.getSplitInfo("CoBorrowerOrWarrantor2_Birthday").getSplitData();
			this.CheckSex = true;
			this.CheckBirthday = true;
		}
		else if(this.si.getColumnName().equals("Mate_CertID"))
		{
			this.CERTTYPE_AREANAME = "Mate_CertType";
			this.CertType = this.getSplitInfo("Mate_CertType").getSplitData();
			this.Sex = this.getSplitInfo("Mate_Sex").getSplitData();
			this.Birthday = this.getSplitInfo("Mate_Birthday").getSplitData();
			this.CheckSex = true;
			this.CheckBirthday = true;
		}
		//��������Ϣ
		else if(this.si.getColumnName().equals("Deputy_CertID"))
		{
			this.CERTTYPE_AREANAME = "Deputy_CertType";
			this.CertType = this.getSplitInfo("Deputy_CertType").getSplitData();
			this.Sex = this.getSplitInfo("Deputy_Sex").getSplitData();
			this.CheckSex = true;
			this.CheckBirthday = false;
		}
		//��˾��֤����Ϣ
		else if(this.si.getColumnName().equals("CorpWarrantor_CertID"))
		{
			this.CERTTYPE_AREANAME = "CorpWarrantor_CertType";
			this.CertType = this.getSplitInfo("CorpWarrantor_CertType").getSplitData();
			this.Sex = this.getSplitInfo("Deputy_Sex").getSplitData();
			this.CheckSex = false;
			this.CheckBirthday = false;
		}
		
		//��������Ϣ
		else if(this.si.getColumnName().equals("Deputy_CertID"))
		{
			this.CERTTYPE_AREANAME = "Deputy_CertType";
			this.CertType = this.getSplitInfo("Deputy_CertType").getSplitData();
			this.Sex = this.getSplitInfo("Deputy_Sex").getSplitData();
			this.CheckSex = true;
			this.CheckBirthday = false;
		}
		
		//Ȩ����
		else if(this.si.getColumnName().indexOf("OwnerCertID")>-1)
		{
			
			String[] array = this.si.getColumnName().split("_");
			String lastnum = com.amarsoft.AppTools.ReplaceAll(this.si.getColumnName(),array[0]+"_"+"OwnerCertID","");
			this.CERTTYPE_AREANAME = array[0]+"_OwnerCertType"+lastnum;
			this.CertType = this.getSplitInfo(array[0]+"_OwnerCertType"+lastnum).getSplitData();
			this.CheckSex = false;
			this.CheckBirthday = false;
		}
		this.CertID = this.Data;
		
	}
	
}
