package com.amarsoft.DESTask.DataCheck.CheckSumNumber;

public class CoBorrowerNumberCheck extends CheckSumNumber{

	
	@Override
	protected int setNoteCount() {
		// TODO Auto-generated method stub
		int iReturn = 0;
		
		if(this.getSplitInfo("IsCoBorrowerOrWarrantorFlag").getSplitData().equals("1"))
			iReturn++;
		
		if(this.getSplitInfo("IsCoBorrowerOrWarrantorFlag1").getSplitData().equals("1"))
			iReturn++;
		return iReturn;
	}
	

}
