package com.amarsoft.DESTask.Biz.Customer;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.Biz.AbstractBiz;

/*******************************************************************************
 * add by xjqin 20090706
 * <p>
 * ��Ҫ���ڻ�ȡ�ͻ����
 * 
 */
public abstract class getCustomerIDAbstract extends AbstractBiz {
	
	/** ��������֤���� */
	protected final String IDCART_TYPE = "Ind01";

	/** �Ƿ�ת��15λ����֤ */
	protected boolean TransLen15 = true;
	
	protected String sCertID = "";

	protected String sCertType = "";
	
	protected String sSex = "";
	
	protected String sCustomerName = "";
	
	protected String sBirthDay = "";
	
	/**
	 * �����Ƿ����㷵������,������ �򷵻���ˮ�� ��������㷵�������򷵻�Ϊ��
	 */
	protected abstract boolean isReturn();
    
	protected abstract void setCertAttributeName() ;
	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		this.SplitInfo = SplitInfo;
        this.setCertAttributeName();
        
		if (!this.isReturn())
			return;
		
		/******************��ȡ�ͻ���,����Ѿ���ȡ��ֱ�ӷ���*********************/
		/*
		String tmp = CustomerID.getCustomerIDFromMemory(this.sCertID,this.sCertType);
		if(!tmp.equals(""))
		{
			this.sSerialNo = tmp;
			return ;
		}
		*/
		/*****************************************************************/
		String sSqlOne = "";
		if("Ent01".equals(this.sCertType))
		{
			sSqlOne = "select /*+ FIRST_ROWS +*/ CustomerID from Customer_Info "
				+ " where certid='"
				+ this.sCertID
				+ "' and certtype='"
				+ this.sCertType + "'";
		}
		else
		{
			sSqlOne = "select /*+ FIRST_ROWS +*/ CustomerID,FullName,Sex,BirthDay,FN_GET_TransDate('"+this.sBirthDay+"','YYYYMMDD','YYYY/MM/DD') as NewBirthDay,FN_GET_CODEMAP('Sex','"+this.sSex+"') as NewSex from IND_INFO "
					+ " where certid='"
					+ this.sCertID
					+ "' and certtype='"
					+ this.sCertType + "'";
	
			// ���Ϊ����֤,����Ҫ����15λת18λ����к˶�
			if (this.sCertType.equals(this.IDCART_TYPE) && this.TransLen15) {
				sSqlOne = "select /*+ FIRST_ROWS +*/ CustomerID,FullName,Sex,BirthDay,FN_GET_TransDate('"+this.sBirthDay+"','YYYYMMDD','YYYY/MM/DD') as NewBirthDay,FN_GET_CODEMAP('Sex','"+this.sSex+"') as NewSex from IND_INFO "
						+ " where (certid=getNewID('"
						+ this.sCertID
						+ "') or certid='"+this.sCertID+"') and certtype='" + this.sCertType + "'";
			}
		}

		java.sql.ResultSet rs = null;
		java.sql.Statement Stat = null;
		try {
			System.out.println(sSqlOne);
			Stat = con.createStatement();
			rs = Stat.executeQuery(sSqlOne);
			if (rs.next()) {
				this.sSerialNo = rs.getString("CustomerID");
				if(!"Ent01".equals(this.sCertType))
				{
					String sFullName = rs.getString("FullName");
					String sSex = rs.getString("Sex");
					String sBirthDay = rs.getString("BirthDay");
					String sNewFullName = this.sCustomerName;
					String sNewSex = rs.getString("NewSex");
					String sNewBirthDay = rs.getString("NewBirthDay");
					if(sFullName == null) sFullName = "";
					if(sSex == null) sSex = "";
					if(sBirthDay == null) sBirthDay = "";
					if(sNewFullName == null) sNewFullName = "";
					if(sNewSex == null) sNewSex = "";
					if(sNewBirthDay == null) sNewBirthDay = "";
					
					
					if(sFullName.equals(sNewFullName) && sNewSex.equals(sSex) && sNewBirthDay.equals(sBirthDay))
					{
						sFlag = "true";
					}
					else
					{
						sFlag = "false";
					}
				}
				
			} else // û���ҵ�����Ҫ�����µĿͻ���
			{
				sSerialNo = getSerialNo("CUSTOMER_INFO", "CUSTOMERID",
						"yyyyMMdd", "000000", new java.util.Date(), "", con);
			}
			rs.close();
			Stat.close();

		} catch (Exception ex) {
              ex.printStackTrace();
		} finally {
			if (rs != null)	rs.close();
			if(Stat != null) Stat.close();
				
			//add by xjqin 20090902
			System.out.println("sCertID="+this.sCertID+",sCertType="+this.sCertType+",sSerialNo="+this.sSerialNo);
			String tmp = CustomerID.getCustomerIDFromMemory(this.sCertID,this.sCertType);
			if(tmp.equals(""))
			{
				System.out.println("sCertID="+this.sCertID+",sCertType="+this.sCertType+",sSerialNo="+this.sSerialNo);
				CustomerID.addCustomerID(this.sSerialNo,this.sCertID,this.sCertType);
			}
			else
			{
				sSerialNo = tmp;
			}
			
			
		}
	}



}
