package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public class getGuarantyType1 extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		this.SplitInfo = SplitInfo;
		String sGuarantyType = this.getSplitInfo("GuarantyType").getSplitData();
		
		if(sGuarantyType.equals("1")||sGuarantyType.equals("3"))
		{
			sSerialNo = "";
		}
	}
    
}
