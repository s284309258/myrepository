package com.amarsoft.DESTask.DataCheck;

import com.amarsoft.DataCheck.DataCheck;


public class MobilePhoneCheck extends DataCheck{
	@Override
	public boolean Check() {
		// TODO Auto-generated method stub
		if(!this.si.isNulls()&&this.Data.equals(""))
			return true;
		String phoneNumberPattern = "([\\d]{8,13})";
		try
		{
			return this.Data.matches(phoneNumberPattern);
		}
		catch(Exception ex)
		{

			return false;
		}
		finally
		{
			
		}
	}

}
