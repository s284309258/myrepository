package com.amarsoft.DESTask.DataCheck.DBDataCheck;

import java.sql.SQLException;

/**
 * �жϵ�ַ�Ƿ���ȷ
 * **/
public class DBAreaCodeCheck  extends DBDataCheck{
    String[] areaArray = null;
	@Override
	protected void init() {
		// TODO Auto-generated method stub
	}
	
	
	@Override
	public boolean Check() {
	    if(this.si.isNulls()||this.Data.equals(""))
	    	return true;
	    
	    java.sql.Statement stat = null;
	    try
	    { 
	    	stat = conn.createStatement();
	    	java.sql.ResultSet rs = stat.executeQuery("select fn_get_areacode('"+this.Data+"') from dual");
	    	if(rs.next()&&!rs.getString(1).equals(this.Data))
	    	{
	    		String MarkIndexColumnName = "";
	    		String AreaCode = rs.getString(1);
	    		/**��ѯѺƷ����ָ��*/
	    		if(this.si.getColumnName().startsWith("house_place"))
	    		{
	    			MarkIndexColumnName = "House_MarkIndex";
	    		}
	    		else if(this.si.getColumnName().startsWith("house_place1"))
	    		{
	    			MarkIndexColumnName = "House1_MarkIndex";
	    		}
	    		else if(this.si.getColumnName().startsWith("house_place2"))
	    		{
	    			MarkIndexColumnName = "House2_MarkIndex";
	    		}
	    		
	    		java.sql.Statement stat1 = null;
	    		java.sql.ResultSet rs1 = null;
	    		try
	    		{
		    		stat1 = conn.createStatement();
		    		
		    		String sSql = "select ATTRIBUTE2 from Code_library where CodeNo='AreaCode' And ItemNo = '"+AreaCode+"'";
		    		rs1 = stat.executeQuery(sSql);
		    		if(rs1.next())
		    		{
		    			this.getSplitInfo(MarkIndexColumnName).setSplitData(rs1.getString(1));
		    		}
	    		}
	    		catch(Exception ex)
	    		{
	    			ex.printStackTrace();
	    		}
	    		finally
	    		{
	    			if(rs!=null) rs1.close();
	    			if(stat1!=null) stat1.close();
	    		}
	    		
	    		return true;
	    	}
	    	else
	    	{
	    		this.AddReturnMsg("��"+this.si.getColumnGBName()+"������У��ʧ�ܣ����ʵ��");
	    		return false;
	    	}
	    }
	    catch(Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    finally
	    {
	    	if(stat!=null)
				try {
					stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    }
	    return true;
	}

}
