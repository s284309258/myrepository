/*
 * @(#)filename 2005-4-10
 *
 * Copyright 2001-2004 Amarsoft, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Amarsoft, Inc.  
 * Use is subject to license terms.
 * 
 * Author:byhu
 */
package com.amarsoft.DESTask.scen.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import com.amarsoft.config.loader.IConfigLoader;

/**
 * ���� ade ��Ŀ.
 * @author William
 * @since 2005-4-10 12:02:02
 */
public class ASConfigLoaderFactory
{
    private static ASConfigLoaderFactory instance = null;
    private static Properties setting; // ����

    private void init()
    {
        try
        {  
            InputStream in = this.getClass().getResourceAsStream("/SysConfig.properties");
           
            setting = new Properties();
            setting.load(in);
        } catch (IOException e)
        {
            System.out.println("Error: Read SysConfig.properties file failed!!!");
            e.printStackTrace();
        }
    }

    public static synchronized ASConfigLoaderFactory getInstance()
    {
        // ��һ��ʹ��ʱ����ʵ��
        if (instance == null)
        {
            instance = new ASConfigLoaderFactory();
            instance.init();
        }
        return instance;
    }

    public IConfigLoader createLoader(String sType) throws Exception
    {
        String sClassName = null;
        IConfigLoader ioConfig;
        try
        {
            sClassName = (String) setting.get(sType);
        } catch (Exception e)
        {
            throw new Exception("δ��������[" + sType + "]��Ӧ������������/SysConfig.properties�ļ���");
        }
        if (sClassName == null || sClassName.trim().length() == 0)
            throw new Exception("δ�ҵ�[" + sType + "]��Ӧ������������/SysConfig.properties�ļ���");
        try
        {
            Class tClass = Class.forName(sClassName);
            ioConfig = (IConfigLoader) tClass.newInstance();
        } catch (Exception e)
        {
            throw new Exception("��̬��" + sClassName + "�ļ��س���:" + e);
        }
        return ioConfig;
    }
}
