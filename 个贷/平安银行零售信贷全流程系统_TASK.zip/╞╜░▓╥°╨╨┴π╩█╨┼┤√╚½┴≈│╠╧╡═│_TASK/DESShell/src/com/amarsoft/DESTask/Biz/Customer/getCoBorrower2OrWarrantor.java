package com.amarsoft.DESTask.Biz.Customer;

import java.sql.Connection;
import java.util.ArrayList;

/**
 * ��õڶ���ͬ����˻��ߵڶ���֤����Ϣ
 * */
public class getCoBorrower2OrWarrantor  extends getCustomerIDAbstract{
	/**
	 * ��ÿͻ����,����֤������,֤�����ͻ�����û�в�ѯ��,����¿ͻ���
	 * */
	@Override
	protected void setCertAttributeName() {
		// TODO Auto-generated method stub
		this.sCertID = getSplitInfo("CoBorrowerOrWarrantor1_CertID").getSplitData();
		this.sCertType = getSplitInfo("CoBorrowerOrWarrantor1_CertType").getSplitData();
		this.sCustomerName = getSplitInfo("CoBorrowerOrWarrantor1_FullName").getSplitData();
		this.sSex = getSplitInfo("CoBorrowerOrWarrantor1_Sex").getSplitData();
		this.sBirthDay = getSplitInfo("CoBorrowerOrWarrantor1_Birthday").getSplitData();
	}

	@Override
	protected boolean isReturn() {
		// TODO Auto-generated method stub
		String type = getSplitInfo("IsCoBorrowerOrWarrantorFlag1").getSplitData();
		if(type.equals("1")||type.equals("2"))
			return true;
		return false;
	}
	
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
			super.setValue(SplitInfo,con);
//			this.SplitInfo = SplitInfo;		
//			boolean exsitFlag = false;
//			String sSql = "";
//		    String sSqlOne =  "select /*+ FIRST_ROWS +*/ CustomerID from ind_info " +
//    		" where certid='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
//			if(getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData().equals("Ind01"))//����֤
//			{
//				 sSql = "select CustomerID from ind_info " +
//		    		" where certid='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"' and certid is not null ";
//				java.sql.ResultSet rs1 = con.createStatement().executeQuery(sSql);
//			    if(rs1.next())
//			    {
//			    	exsitFlag = true;
//			    	sSerialNo = rs1.getString("CustomerID");
//			    }
//			    rs1.getStatement().close();
//			    if(!exsitFlag)
//			    {
//					if(getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData().length()==15)
//					{
//						
//						sSql = "select CustomerID from ind_info " +
//			    		" where certid=getNewID('"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"') and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
//						rs1 = con.createStatement().executeQuery(sSql);
//						if(rs1.next())
//					    {
//					    	exsitFlag = true;
//					    	sSerialNo = rs1.getString("CustomerID");
//					    }
//					    rs1.getStatement().close();
//					}
//					else
//					{
//						sSql = "select CustomerID from ind_info " +
//			    		" where getNewID(certid)='"+getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData()+"' and certtype='"+getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData()+"'";
//						rs1 = con.createStatement().executeQuery(sSql);
//						if(rs1.next())
//					    {
//					    	exsitFlag = true;
//					    	sSerialNo = rs1.getString("CustomerID");
//					    }
//					    rs1.getStatement().close();
//					}
//			    }
//			}
//			
////			System.out.println(sSql);
//		    java.sql.ResultSet rs = con.createStatement().executeQuery(sSqlOne);
//		    if(rs.next())
//		    {
//		    	if(!exsitFlag)
//		    	{
//		    		sSerialNo = rs.getString("CustomerID");
//		    	}
//		    }
//		    else
//		    {
//		    	sSerialNo =  getSerialNo("CUSTOMER_INFO","CUSTOMERID","yyyyMMdd","000000", new java.util.Date(),"kh",con);
//		    
//		    }
//		    
//		    rs.getStatement().close();
		    
	}

	
}
