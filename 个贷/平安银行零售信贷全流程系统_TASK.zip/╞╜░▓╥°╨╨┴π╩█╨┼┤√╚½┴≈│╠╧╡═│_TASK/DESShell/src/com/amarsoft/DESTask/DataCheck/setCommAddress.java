package com.amarsoft.DESTask.DataCheck;

import com.amarsoft.DataCheck.DataCheck;


public class setCommAddress   extends DataCheck {

	public boolean Check() {
		//////////���⴦�� ���¹�ͬ����� 
		if(this.si.getColumnName().equals("Main_CommAddress"))
		{
			String sMain_CommAdd = this.getSplitInfo("Main_CommAdd").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("Main_FamilyAdd").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("Main_WorkAdd").getSplitData());
			}
			else if(this.Data.startsWith("0"))
			{
				//��specialcheck�������˶�Ӧ��ֵ
			}
			else this.si.setSplitData("");	
		}
		
		if(this.si.getColumnName().equals("Main_CommZip1"))
		{
			String sMain_CommAdd = this.getSplitInfo("Main_CommAdd").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("Main_FamilyZIP").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("Main_WorkZip").getSplitData());
			}
			else this.si.setSplitData("");	
		}
		
		
		
//////////���⴦�� ���¹�ͬ����� 
		if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_CommAddress"))
		{
			String sMain_CommAdd = this.getSplitInfo("CoBorrowerOrWarrantor_CommAdd").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_WorkAdd").getSplitData());
			}
			else if(this.Data.startsWith("0"))
			{
			     this.si.setSplitData(this.Data.substring(1));
			}
			else this.si.setSplitData("");	
		}
		
		if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_FamilyAdd_CommZip1"))
		{
			String sMain_CommAdd = this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_CommAdd").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_FamilyZIP").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_WorkZip").getSplitData());
			}
			else this.si.setSplitData("");	
		}
		
		if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_CommAddress_2"))
		{
			String sMain_CommAdd = this.getSplitInfo("CoBorrowerOrWarrantor_CommAdd_2").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_2").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_WorkAdd_2").getSplitData());
			}
			else if(this.Data.startsWith("0"))
			{
			     this.si.setSplitData(this.Data.substring(1));
			}
			else this.si.setSplitData("");	
		}
		
		if(this.si.getColumnName().equals("CoBorrowerOrWarrantor_FamilyAdd_CommZip1_2"))
		{
			String sMain_CommAdd = this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_CommAdd_2").getSplitData();
			if(sMain_CommAdd.equals("1")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_FamilyZIP_2").getSplitData());
			}
			else if(sMain_CommAdd.equals("2")) //��ס�ص�
			{
				 this.si.setSplitData(this.getSplitInfo("CoBorrowerOrWarrantor_FamilyAdd_WorkZip_2").getSplitData());
			}
			else this.si.setSplitData("");	
		}
		
		return true;
	}

}
