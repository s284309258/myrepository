package com.amarsoft.DESTask.Biz.Customer;

import java.sql.Connection;
import java.util.ArrayList;


/**
 * ��ù�ͬ����˻��߱�֤����Ϣ
 * */
public class getCoBorrowerOrWarrantor  extends getCustomerIDAbstract{
 
	@Override
	protected void setCertAttributeName() {
		// TODO Auto-generated method stub
		this.sCertID = getSplitInfo("CoBorrowerOrWarrantor_CertID").getSplitData();
		this.sCertType = getSplitInfo("CoBorrowerOrWarrantor_CertType").getSplitData();
		this.sCustomerName = getSplitInfo("CoBorrowerOrWarrantor_FullName").getSplitData();
		this.sSex = getSplitInfo("CoBorrowerOrWarrantor_Sex").getSplitData();
		this.sBirthDay = getSplitInfo("CoBorrowerOrWarrantor_Birthday").getSplitData();
		
	}

	@Override
	protected boolean isReturn() {
		// TODO Auto-generated method stub
		String type = getSplitInfo("IsCoBorrowerOrWarrantorFlag").getSplitData();
		if(type.equals("1")||type.equals("2"))
			return true;
		return false;
	}
	
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
			super.setValue(SplitInfo,con);
	}
}
