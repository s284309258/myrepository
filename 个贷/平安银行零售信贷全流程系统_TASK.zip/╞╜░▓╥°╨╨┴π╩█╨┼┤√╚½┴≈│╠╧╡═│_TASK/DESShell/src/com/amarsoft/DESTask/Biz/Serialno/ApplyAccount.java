package com.amarsoft.DESTask.Biz.Serialno;

import java.sql.Connection;
import java.util.ArrayList;

public class ApplyAccount extends getSerialNo{
	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("BUSINESS_APPLY_ACCOUNT","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"",con);
	}
}
