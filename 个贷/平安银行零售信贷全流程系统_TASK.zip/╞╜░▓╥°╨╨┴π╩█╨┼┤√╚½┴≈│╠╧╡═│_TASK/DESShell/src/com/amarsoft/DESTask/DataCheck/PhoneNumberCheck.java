package com.amarsoft.DESTask.DataCheck;

import com.amarsoft.DataCheck.DataCheck;


public class PhoneNumberCheck  extends DataCheck{

	public boolean Check() {
		if(!this.si.isNulls()&&this.Data.equals(""))
			return true;
	    
		try
		{
			Double.parseDouble(com.amarsoft.AppTools.ReplaceAll(this.Data,"-",""));
			return true;
		}
		catch(Exception ex)
		{
			 this.AddReturnMsg("��"+this.si.getColumnGBName()+"��������Ч�ĵ绰����!");
			 return false;
		}
		
	}

}
