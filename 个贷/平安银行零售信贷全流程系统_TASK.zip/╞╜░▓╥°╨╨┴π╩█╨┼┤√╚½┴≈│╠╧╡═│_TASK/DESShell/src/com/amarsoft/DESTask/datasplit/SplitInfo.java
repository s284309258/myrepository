package com.amarsoft.DESTask.datasplit;

public class SplitInfo {
	
	private String projectNo = "";// added by 53	2009-12-02
    private int orderID = 0;
    private String ColumnName = "";
    private String ColumnGBName = "";
    private String NextColumnName = "";
    private String DataType = "";
    private String SplitData = "";
    private String DefaultValue = "";
    private int CodeChcek = 0;
    private String CodeMap = "";
    private String CheckClassName = "";
    private boolean Nulls = false;
    private DesCodeMap codemaps = null;
    private boolean Error = false;
    private String ErrorMessage = "";
    
    public SplitInfo(int orderID )
    {
    	this.orderID = orderID;
    }
    
	/**
	 * @return Returns the columnName.
	 */
	public final String getColumnName() {
		return ColumnName;
	}
	/**
	 * @param columnName The columnName to set.
	 */
	public final void setColumnName(String columnName) {
		ColumnName = columnName;
	}
	/**
	 * @return Returns the dataType.
	 */
	public final String getDataType() {
		return DataType;
	}
	/**
	 * @param dataType The dataType to set.
	 */
	public final void setDataType(String dataType) {
		DataType = dataType;
	}
	/**
	 * @return Returns the nextColumnName.
	 */
	public final String getNextColumnName() {
		return NextColumnName;
	}
	/**
	 * @param nextColumnName The nextColumnName to set.
	 */
	public final void setNextColumnName(String nextColumnName) {
		NextColumnName = nextColumnName;
	}
	/**
	 * @return Returns the orderID.
	 */
	public final int getOrderID() {
		return orderID;
	}
	/**
	 * @param orderID The orderID to set.
	 */
	public final void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	/**
	 * @return Returns the splitData.
	 */
	public final String getSplitData() {
		if(SplitData==null) SplitData = "";
		return SplitData;
	}
	/**
	 * @param splitData The splitData to set.
	 */
	public final void setSplitData(String splitData) {
		SplitData = splitData;
	}
	/**
	 * @return Returns the defaultValue.
	 */
	public final String getDefaultValue() {
		return DefaultValue;
	}
	/**
	 * @param defaultValue The defaultValue to set.
	 */
	public final void setDefaultValue(String defaultValue) {
		if(defaultValue==null) DefaultValue = "";
		else DefaultValue = defaultValue;
	}
	/**
	 * @return Returns the codeChcek.
	 */
	public final int getCodeChcek() {
		return CodeChcek;
	}
	/**
	 * @param codeChcek The codeChcek to set.
	 */
	public final void setCodeChcek(int codeChcek) {
        this.CodeChcek = codeChcek;
	}
	/**
	 * @return Returns the codeMap.
	 */
	public final String getCodeMap() {
		return CodeMap;
	}
	/**
	 * @param codeMap The codeMap to set.
	 */
	public final void setCodeMap(String codeMap) {
		CodeMap = codeMap;
	}
	/**
	 * @return Returns the columnGBName.
	 */
	public final String getColumnGBName() {
		return ColumnGBName;
	}
	/**
	 * @param columnGBName The columnGBName to set.
	 */
	public final void setColumnGBName(String columnGBName) {
		ColumnGBName = columnGBName;
	}
	/**
	 * @return Returns the nulls.
	 */
	public final boolean isNulls() {
		return Nulls;
	}
	/**
	 * @param nulls The nulls to set.
	 */
	public final void setNulls(String nulls) {
		if(nulls==null) Nulls = false;
		else if(nulls.equals("0")) Nulls = false;
		else Nulls = true;
	}
	/**
	 * @return Returns the checkClassName.
	 */
	public final String getCheckClassName() {
		return CheckClassName;
	}
	/**
	 * @param checkClassName The checkClassName to set.
	 */
	public final void setCheckClassName(String checkClassName) {
		CheckClassName = checkClassName;
	}
	/**
	 * @return Returns the codemap.
	 */
	public final DesCodeMap getCodemaps() {
		return codemaps;
	}
	/**
	 * @param codemap The codemap to set.
	 */
	public final void setCodemaps(DesCodeMap codemap) {
		this.codemaps = codemap;
	}
	/**
	 * @return Returns the error.
	 */
	public final boolean isError() {
		return Error;
	}
	/**
	 * @param error The error to set.
	 */
	public final void setError(boolean error) {
		Error = error;
	}
	/**
	 * @return Returns the errorMessage.
	 */
	public final String getErrorMessage() {
		return ErrorMessage;
	}
	/**
	 * @param errorMessage The errorMessage to set.
	 */
	public final void setErrorMessage(String errorMessage) {
		this.setError(true);
		ErrorMessage += ";"+errorMessage;
	}
	public String getProjectNo() {
		return projectNo;
	}
	
	public String setProjectNo(String projectNo) {
		return this.projectNo = projectNo;
	}
    
}
