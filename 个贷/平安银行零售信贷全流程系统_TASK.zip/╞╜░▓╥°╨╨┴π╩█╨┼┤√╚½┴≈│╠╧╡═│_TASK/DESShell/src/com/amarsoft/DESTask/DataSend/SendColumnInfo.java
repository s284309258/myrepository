package com.amarsoft.DESTask.DataSend;

import com.amarsoft.DESTask.datasplit.SplitInfo;


public class SendColumnInfo {
     private String TableID = "";
     private String SplitColumnName = "";
     private String ColumnName = "";
     private String ColumnGBName = "";
     private int FormatType = 1 ; //1 ֱ�Ӳ��� 2.�����Լ��ű����� 3.Ĭ��ֵ���� 
     private String FormatExpression = "";
     private SplitInfo SplitInfo = null;
     
     public SendColumnInfo(String TableID ,String ColumnName)
     {
    	 this.TableID = TableID;
    	 this.ColumnName = ColumnName;
     }
	/**
	 * @return Returns the columnGBName.
	 */
	public final String getColumnGBName() {
		return ColumnGBName;
	}
	/**
	 * @param columnGBName The columnGBName to set.
	 */
	public final void setColumnGBName(String columnGBName) {
		ColumnGBName = columnGBName;
	}
	/**
	 * @return Returns the columnName.
	 */
	public final String getColumnName() {
		return ColumnName;
	}
	/**
	 * @param columnName The columnName to set.
	 */
	public final void setColumnName(String columnName) {
		ColumnName = columnName;
	}
	/**
	 * @return Returns the formatExpression.
	 */
	public final String getFormatExpression() {
		return FormatExpression;
	}
	/**
	 * @param formatExpression The formatExpression to set.
	 */
	public final void setFormatExpression(String formatExpression) {
		FormatExpression = formatExpression;
	}
	/**
	 * @return Returns the formatType.
	 */
	public final int getFormatType() {
		return FormatType;
	}
	/**
	 * @param formatType The formatType to set.
	 */
	public final void setFormatType(int formatType) {
		FormatType = formatType;
	}
	/**
	 * @return Returns the si.
	 */
	public final SplitInfo getSplitInfo() {
		return this.SplitInfo;
	}
	/**
	 * @param si The si to set.
	 */
	public final void setSplitInfo(SplitInfo si) {
		this.SplitInfo = si;
	}
	/**
	 * @return Returns the splitColumnName.
	 */
	public final String getSplitColumnName() {
		return SplitColumnName;
	}
	/**
	 * @param splitColumnName The splitColumnName to set.
	 */
	public final void setSplitColumnName(String splitColumnName) {
		SplitColumnName = splitColumnName;
	}
	/**
	 * @return Returns the tableID.
	 */
	public final String getTableID() {
		return TableID;
	}
	/**
	 * @param tableID The tableID to set.
	 */
	public final void setTableID(String tableID) {
		TableID = tableID;
	}
}
