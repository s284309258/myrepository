package com.amarsoft.DESTask.DataCheck.CheckSumNumber;

public class WarrantorNumber extends CheckSumNumber {

	@Override
	protected int setNoteCount() {
//		 TODO Auto-generated method stub
		int iReturn = 0;
		
		if(this.getSplitInfo("IsCoBorrowerOrWarrantorFlag").getSplitData().equals("2"))
			iReturn++;
		
		if(this.getSplitInfo("IsCoBorrowerOrWarrantorFlag1").getSplitData().equals("2"))
			iReturn++;
		return iReturn;
	}

}
