package com.amarsoft.DESTask.Biz.MFCustomer;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.getMFCustomerID;
/**
 * 
 * @deprecated
 *
 */
public class getMainMFCustomerID extends getMFCustomerID{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		String sFullName = getSplitInfo("Main_FullName").getSplitData();
		String sCertType = getSplitInfo("Main_CertID").getSplitData();
		String sCertID = getSplitInfo("Main_CertType").getSplitData();
		String sSex = getSplitInfo("Main_Sex").getSplitData();
		String sBirthDay = getSplitInfo("Main_Birthday").getSplitData();
		
		sMFCustomerID =  getECIFCustomerID( sFullName,  sCertType, sCertID, sSex, sBirthDay);
		
	}
	
}
