package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

/**
 * 
 * @author: 	--53 2009-11-30
 * @describe:	��ȡ������
 *
 */
public class getBusinessSum extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		this.SplitInfo = SplitInfo;
		String businessSum = getSplitInfo("Loan_BusinessSum").getSplitData();
		double doubleSum = 0;
		try{
			doubleSum = Double.parseDouble(businessSum);
		} catch(Exception e){
			sSerialNo = "0";
		}
		this.sSerialNo = String.valueOf(doubleSum);
	}

}
