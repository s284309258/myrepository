package com.amarsoft.DESTask.Biz.Customer;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public class getCreditApply   extends AbstractBiz  {

	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		sSerialNo =  getSerialNo("CREDIT_APPLY","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"",con);

	}

	 
}
