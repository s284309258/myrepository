package com.amarsoft.DESTask.Biz.Customer;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public class getGuarantyOwner   extends AbstractBiz  {

	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		sSerialNo =  getSerialNo("GUARANTY_OWNER","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"",con);

	}

	 
}
