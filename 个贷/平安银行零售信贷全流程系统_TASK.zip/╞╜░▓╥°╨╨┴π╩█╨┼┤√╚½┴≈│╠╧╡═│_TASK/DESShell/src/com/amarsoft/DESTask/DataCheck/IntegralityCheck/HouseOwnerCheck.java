package com.amarsoft.DESTask.DataCheck.IntegralityCheck;
/**
 * ���ݵ�Ѻ��Ȩ����1 У��
 * */
public class HouseOwnerCheck  extends AbstractIntegralityCheck{

	@Override
	protected void setColumnList() {
		// TODO Auto-generated method stub
		this.sFlag = this.si.getColumnName();
		
		String[] temp = new String[]{
				"Ownershare",
				"OwnerCertType",
				"OwnerCertID",
		};
		
		String[] temp2 = this.sFlag.split("_");
		String c = temp2[1].substring(temp2[1].length()-1);
		for(int i=0;i<temp.length;i++)
		{
		    this.addColumn(temp2[0]+"_"+temp[i]+c);
		}
	}

}
