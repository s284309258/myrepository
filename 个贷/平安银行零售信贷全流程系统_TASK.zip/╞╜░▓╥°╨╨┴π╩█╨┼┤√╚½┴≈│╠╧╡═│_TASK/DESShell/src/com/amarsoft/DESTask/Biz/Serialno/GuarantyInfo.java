package com.amarsoft.DESTask.Biz.Serialno;
import java.sql.Connection;
import java.util.ArrayList;

public class GuarantyInfo extends getSerialNo{

	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		sSerialNo =  getSerialNo("GUARANTY_INFO","GUARANTYID","yyyyMMdd","000000", new java.util.Date(),"",con);
	}

}
