package com.amarsoft.DESTask.DataCheck.DBDataCheck;

import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.DataCheck.DataCheck;

public abstract class DBDataCheck extends DataCheck{
    protected String CheckSQL = ""; //
    protected String findMsg = "";  //�ҵ�����Ϣ
    protected String notFindMsg = ""; //û�ҵ�����ʾ��Ϣ
    
      
    protected abstract void init();
	@Override
	/**
	 * ֻ��У���Ƿ����,���������У��,����Ҫ��������
	 * */
	public boolean Check() {
	    this.init();
	    
	    if(!si.isNulls()&&this.Data.equals("")) return true;
	    //����SQLΪ��,�򲻲���У��
	    if(this.CheckSQL.equals("")) return true;
	    Statement stat = null;
	    
	    try {
			stat = conn.createStatement();
			java.sql.ResultSet rs = stat.executeQuery(CheckSQL);

			if(!rs.next())
			{
			   this.AddReturnMsg(notFindMsg);
			   return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    return false;
		}
		finally
		{
			if(stat!=null)
			{
				try {
					stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return true;
	}

}
