package com.amarsoft.DESTask.DataSend;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.AppTools;
import com.amarsoft.Biz.*;
import com.amarsoft.DESTask.datasplit.SplitInfo;
import com.amarsoft.Log.logger;
import com.amarsoft.Task.CommonValues;

public class DataSend {
	private java.sql.Connection con = null;
	private java.util.ArrayList SplitInfo = null;
	private java.util.ArrayList TableInfo = null;
	private String sSequence = "";
	private CommonValues CommonValues = new CommonValues();
	private String ErrorMessage = "";
	private boolean ErrorFlag = false;
	private String TaskType = "";
	
	
	public DataSend(java.sql.Connection con, String sSequence,
			java.util.ArrayList SplitInfo,String TaskType) {
		this.con = con;
		this.SplitInfo = SplitInfo;
		this.sSequence = sSequence;
		this.TaskType = TaskType;
        
		TableInfo = new java.util.ArrayList();
		try {
//			CommonValues();
			this.setTableInfo();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setErrorMessage();
	}

	/**
	 * ������Ҫ�������͵ĸ���ģ�͵���Ϣ
	 * */
	private void setTableInfo() throws SQLException {
		String sSql = "select * from T_CONF_SENDTABLE  where ProjectNo='"+this.TaskType+"' and status=1 order by orderid";
		java.sql.ResultSet rs_table = con.createStatement().executeQuery(sSql);

		while (rs_table.next()) {
			SendTableInfo sti = new SendTableInfo(rs_table.getString("TableID"));
			sti.setTableName(rs_table.getString("TableName"));
			sti.setTableGBName(rs_table.getString("TableGBName"));
			sti.setExistCheck(rs_table.getInt("ExistCheck"));
			sti.setExceptionAction(rs_table.getString("ExceptionAction"));
			sti.setExistAction(rs_table.getString("ExistAction"));
			sti.setCheckColumns(rs_table.getString("KeyColumn"));
			sti.setCheckStatement(rs_table.getString("CheckStatement"));
			sti.setHistoryTable(rs_table.getString("HISTORYTABLE"));
			sti.setExecExpression(rs_table.getString("ExecExpression"));
            sti.setSplitInfo(this.SplitInfo);
			sSql = "select * from T_CONF_SENDCOLUMN where ProjectNo='"+this.TaskType+"' AND TableID='"
					+ rs_table.getString("TableID") + "' and status='1'";
			java.sql.ResultSet rs_column = con.createStatement().executeQuery(sSql);

			while (rs_column.next()) {
				SendColumnInfo sci = new SendColumnInfo(sti.getTableID(),rs_column.getString("ColumnName"));
				sci.setSplitColumnName(rs_column.getString("SplitColumnName"));
				sci.setColumnGBName(rs_column.getString("ColumnGBName"));
				sci.setFormatType(rs_column.getInt("FormatType"));
				sci.setFormatExpression(rs_column.getString("FormatExpression"));
				sci.setSplitInfo(getSplitInfo(sci.getSplitColumnName()));
				sti.addColumnList(sci);
			}
			rs_column.getStatement().close();

			TableInfo.add(sti);
		}
		rs_table.getStatement().close();
	}


	// ִ����� �޸Ļ��� ���쳣��¼����־����
	public void SendSplitData() throws Exception {
		java.sql.Statement stat = null;
		// /���Statement �Լ����������Զ��ύΪ��

		//this.con.setAutoCommit(false);
		stat = this.con.createStatement();
        try
        {
			// ������������η�������
			for (int i = 0; i < TableInfo.size(); i++) {
				SendTableInfo sti = (SendTableInfo) TableInfo.get(i);
				sti.setCheckSql(); // ����У�����
				if (CheckExecExpression(sti)) {
					logger.info("���ݱ���"+sti.getTableGBName()+"�������������в���");
					com.amarsoft.DESTask.DataUnit.UpdateLOG(con, this.sSequence, 1, ";���㡾"+ sti.getTableGBName() + ":" + sti.getTableName()+ "��ִ������,��ʼ����");
					if (!ExistCheckAction(sti));
					else {
						String sSql = this.getSql(sti);
						logger.info(sSql);
						try
						{
							stat.executeUpdate(sSql);
						}
						catch(Exception ex)
						{
							this.setErrorMessage("���ݱ���"+sti.getTableGBName()+"��¼��ʧ�ܣ�");
							logger.warn("���ݱ���"+sti.getTableGBName()+"��¼��ʧ�ܣ�\n\t"+ex.getMessage());
							// added by 53	2009.12	�ڲ�������ʱ�������,Ҳ����errorFlag = true
							// ��������¼���޴�,���ǿ�����Ϊ���ݳ��ȳ����������ݲ������,��ֱ�ӵ����Ž׶�
							this.setErrorFlag(true);
							ex.printStackTrace();
						}
						//stat.addBatch(sSql);
					}
				} else {
					com.amarsoft.DESTask.DataUnit.UpdateLOG(con, this.sSequence, 1, ";�����㡾"+ sti.getTableGBName() + ":" + sti.getTableName()+ "��ִ������,�����в���");
					logger.info("���ݱ���"+sti.getTableGBName()+"�������㲻���в���");
				}
			}
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        	throw new Exception(ex.getMessage());
        }
        finally
        {
        	stat.close();
        }
		// ���������ó��Զ��ύ
		//this.con.setAutoCommit(true);

	}

	public boolean CheckExecExpression(SendTableInfo sti) throws SQLException {
		String sEE = sti.getExecExpression();
		boolean sReturn = true;
		if (sti.getExecExpression() == null
				|| sti.getExecExpression().equals(""))
			return true;
		else {
			java.util.ArrayList stc = sti.getColumnList();
			for (int i = 0; i < SplitInfo.size(); i++) {
				SplitInfo si = (SplitInfo) SplitInfo.get(i);
				sEE = AppTools.ReplaceAll(sEE, "@" + si.getColumnName() + "#",si.getSplitData());
			}
			
			sEE = this.CommonValues.ReplaceValue(sEE);
			ResultSet rs = this.con.createStatement().executeQuery(sEE);
			
			if (rs.next())
				sReturn = true;
			else
				sReturn = false;

			rs.getStatement().close();
			return sReturn;
		}

	}
    
	/**
	 * ����������ϢУ�������Ƿ����
	 * */
	private boolean ExistCheckAction(SendTableInfo sti) throws SQLException {
		java.sql.Statement stat = this.con.createStatement();
		try {
			if (sti.getExistCheck() == 0) // ��У���Ƿ����
				return true;
			else // ���ݴ���У��
			{
				String sSql = sti.getCheckSql();
				//add by xjqin 2009 �滻
				sSql = this.CommonValues.ReplaceValue(sSql);
				if(sSql.equals("")) return true; //��У��
				sSql = this.CommonValues.ReplaceValue(sSql);
				logger.info("���ݴ���У��ű� : " + sSql);
				java.sql.ResultSet rs = con.createStatement().executeQuery(sSql);
				if (rs.next()) {
					sti.setDataExists(true);
					if (sti.getExistAction().equals("NOACTION")) // ���ѡ�񲻲�������false
						return false;
					else if (sti.getExistAction().equals("DELETE_INSERT")) // ɾ��
					{
						// ɾ������ ���ȼ������ӱ�
						sSql = "Insert Into " + sti.getHistoryTable()
								+ " select t.*" + ",'"
								+ this.CommonValues.getValue("BUSINESSAPPLY")
								+ "'," + "to_char(sysdate,'yyyy/mm/dd'),"
								+ "to_char(sysdate,'hh24:mi:ss'),"
								+ "'���ݴ��ڱ�ɾ��������ɾ��ǰ����'," + "'" + this.sSequence
								+ "'" + " from " + sti.getTableName() + " t "
								+ " where 1=1 " + sti.getCheckWhereClause();
						sSql = this.CommonValues.ReplaceValue(sSql);
						stat.executeUpdate(sSql);

						sSql = "Delete " + sti.getTableName() + " Where 1=1 "
								+ sti.getCheckWhereClause();
						sSql = this.CommonValues.ReplaceValue(sSql);
						logger.info("ɾ���ظ�������:"+sSql);
						stat.executeUpdate(sSql);
					} else if (sti.getExistAction().equals("UPDATE")) // �����²���
					{
						// ɾ������ ���ȼ������ӱ�
						sSql = "Insert Into " + sti.getHistoryTable()
								+ " select t.*" + ",'"
								+ this.CommonValues.getValue("BUSINESSAPPLY")
								+ "'," + "to_char(sysdate,'yyyy/mm/dd'),"
								+ "to_char(sysdate,'hh24:mi:ss'),"
								+ "'���ݴ��ڱ�����,���ݸ���ǰ����'," + "'" + this.sSequence
								+ "'" + " from " + sti.getTableName() + " t "
								+ " where 1=1 " + sti.getCheckWhereClause();

						sSql = this.CommonValues.ReplaceValue(sSql);
						
						stat.executeUpdate(sSql);
						return true;
					}

				} else
					return true;
			}
		} catch (Exception ex) {

		} finally {
			stat.close();
		}
		return true;
	}
    
	/**
	 * ƴ��Sql
	 * */
	private String getSql(SendTableInfo sti) throws Exception {
		String sSql1 = "", sSql2 = "", sReturn = "";
		java.util.ArrayList ColumnList = sti.getColumnList();
		for (int i = 0; i < ColumnList.size(); i++) {
			SendColumnInfo sci = (SendColumnInfo) ColumnList.get(i);
			SplitInfo si = sci.getSplitInfo();

			// ���籨��,ִ�в�����߸��²���,ֱ�ӽ���
			// if(si!=null)
			// {
			// if(si.isError())
			// continue;
			// }

			String tmp = "";
			sSql1 += "," + sci.getColumnName();
			
            //��formattype=2 �� 4 ��ʱ�� 
			if (si == null && sci.getFormatType() != 4 && sci.getFormatType()!=2) // Ϊ�մ���
			{
				if (sci.getFormatType() == 3)
					tmp = "'" + sci.getFormatExpression() + "'";
				else
					tmp += "''";
			} else if (sci.getFormatType() == 4) // java��ʽ��÷���ֵ
			{
				String ClassName = sci.getFormatExpression();
				AbstractBiz ab = (AbstractBiz) Class.forName(ClassName)
						.newInstance();
				ab.setValue(SplitInfo, con);
				tmp = "'" + ab.getReturn() + "'";
			} else {
				if (sci.getFormatType() == 1) // ֱ�Ӳ���
					tmp = si.getSplitData();
				else if (sci.getFormatType() == 2) // �����Լ��ű�����
				{
					tmp = sci.getFormatExpression();
					if(si!=null)
					{
						tmp = AppTools.ReplaceAll(tmp,"@DATA#", si.getSplitData());
						tmp = AppTools.ReplaceAll(tmp, "@SplitName#", sci.getSplitColumnName());
					}
				} else if (sci.getFormatType() == 3)
					tmp = sci.getFormatExpression(); // Ĭ��ֵ �������ϼ���ʱû��
				else
					tmp = si.getSplitData();

				// ������Ǻ�������Ҫǰ�󶼼�''
				if (sci.getFormatType() != 2)
					tmp = "'" + tmp + "'";
			}
			sSql2 += "," + tmp;
		}

		if (sSql1.length() > 0)
			sSql1 = sSql1.substring(1);
		if (sSql2.length() > 0)
			sSql2 = sSql2.substring(1);
		if (sti.getExistAction().equals("UPDATE") && sti.isDataExists())// ��UPDATE��������δ�ظ�
			sReturn = "UPDATE " + sti.getTableName() + " SET (" + sSql1
					+ ") = (select " + sSql2 + " from dual ) WHERE 1=1 "
					+ sti.getCheckWhereClause()+" and rownum<2";
		else
			// ���²���
			sReturn = "INSERT INTO " + sti.getTableName() + "(" + sSql1
					+ ") values (" + sSql2 + ")";

		sReturn = this.CommonValues.ReplaceValue(sReturn);
		//ȡ��~
		sReturn = AppTools.ReplaceAll(sReturn,"~","");
		//�滻SQL�еı���
		sReturn = replaceMessage(sReturn,sti);
		return sReturn;
	}
	
	private final String replaceMessage(String sSql,SendTableInfo sti)
	{
		String sReturn = sSql;
		java.util.ArrayList stc = sti.getColumnList();
		for (int i = 0; i < SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) SplitInfo.get(i);
			sReturn = AppTools.ReplaceAll(sReturn, "@" + si.getColumnName() + "#",
					si.getSplitData());
		}
		return sReturn;
		

	}
	/**
	 * �����������ȥ���ĳ����Ķ�����Ϣ
	 * */
	private SplitInfo getSplitInfo(String SplitColumnName) {
		SplitInfo sReturn = null;
		for (int i = 0; i < this.SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
				if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
					sReturn = si;
					break;
				}
		}
		return sReturn;
	}

	/**
	 * @return Returns the commonValues.
	 */
	public final CommonValues getCommonValues() {
		return CommonValues;
	}

	/**
	 * @param commonValues The commonValues to set.
	 */
	public final void setCommonValues(CommonValues commonValues) {
		CommonValues = commonValues;
	}
	
	
	public final void addCommonValues(String Name,String Value) {
		CommonValues.addValue(new String[] { Name,Value});
	}
    
	public final void addCommonValues(String[] Values) {
		CommonValues.addValue(Values);
	}
	
	public final void setErrorMessage()
	{
		for(int i=0;i<this.SplitInfo.size();i++)
		{
			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
			if(si.isError())
			{
				String error = si.getErrorMessage();
				//��Ҫ�滻�����а��� ;;�����ķ���
				
				this.setErrorMessage(si.getErrorMessage());
				this.setErrorFlag(true);
			}
		}
		
	}
	/**
	 * @return Returns the errorFlag.
	 */
	public final boolean isErrorFlag() {
		return ErrorFlag;
	}

	/**
	 * @param errorFlag The errorFlag to set.
	 */
	public final void setErrorFlag(boolean errorFlag) {
		ErrorFlag = errorFlag;
	}

	/**
	 * @return Returns the errorMessage.
	 */
	public final String getErrorMessage() {
		return ErrorMessage;
	}

	/**
	 * @param errorMessage The errorMessage to set.
	 */
	public final void setErrorMessage(String errorMessage) {
		ErrorMessage += errorMessage+"\n";
	}
	
}
