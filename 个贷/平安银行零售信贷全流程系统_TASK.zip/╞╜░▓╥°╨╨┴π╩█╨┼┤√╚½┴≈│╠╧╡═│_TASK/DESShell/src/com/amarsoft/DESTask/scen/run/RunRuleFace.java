package com.amarsoft.DESTask.scen.run;
/**
 * @author yyduan
 * �ⲿ���ù������
 */
import com.amarsoft.are.sql.ConnectionManager;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.script.AmarInterpreter;
import com.amarsoft.script.Anything;
import com.amarsoft.DESTask.scen.config.ASConfigure;
import com.amarsoft.DESTask.scen.run.RunRuleFace;
import com.amarsoft.Log.logger;

public class RunRuleFace {
	private AmarInterpreter interpreter = null;
	private Transaction Sqlca=null;
	private String SerialNo="";
	
	public RunRuleFace(Transaction tranca,String sScriptScenario,String sSerialNo) throws Exception{
		//loadConfig(tranca);
		this.interpreter = new AmarInterpreter();
		this.SerialNo=sSerialNo;
		this.Sqlca=tranca;
		logger.info("��ʼ��������ʼ "+sScriptScenario);
		this.interpreter.initMemory(this.Sqlca,sScriptScenario,"TaskNo="+this.SerialNo);
		logger.info("��ʼ���������� "+sScriptScenario);
	}
	public void initRuleFace() throws Exception{
		
		
	}
	public String runRule(String sDecisionScript) throws Exception {
		Anything aLogID = interpreter.explain(Sqlca,"!������.ִ��("+sDecisionScript+")");
		String sLogID = aLogID.toStringValue();
		String sOutCome = "",sLogType = "",sSql = "";
		sSql = "update FLOW_TASK set AutoDecision='"+sLogID+"' where SerialNo='"+this.SerialNo+"'";
		Sqlca.executeSQL(sSql);
		//������ؽ����"OutCome=xxx;LogType=xxx;LogID=xxx;"��ʽ
		if(sLogID.indexOf("OutCome=")>=0){
			sOutCome = StringFunction.getProfileString(sLogID,"OutCome");
			sLogType = StringFunction.getProfileString(sLogID,"LogType");
			sLogID = StringFunction.getProfileString(sLogID,"LogID");
		}else{
			sOutCome = sLogID;
		}
		//this.interpreter.commitBinding(Sqlca);
		Sqlca.conn.commit();
		
		return "OutCome="+sOutCome+";LogType=DECISION_TREE;LogID="+sLogID;
	}
	public String runRuleResult(String sDecisionScript) throws Exception {
		String sOutCome = "",sLogType = "",sSql = "";
		try{
		Anything aLogID = interpreter.explain(Sqlca,"!������.ִ��("+sDecisionScript+")");
		String sLogID = aLogID.toStringValue();
		sSql = "update FLOW_TASK set AutoDecision='"+sLogID+"' where SerialNo='"+this.SerialNo+"'";
		Sqlca.executeSQL(sSql);
		//������ؽ����"OutCome=xxx;LogType=xxx;LogID=xxx;"��ʽ
		if(sLogID.indexOf("OutCome=")>=0){
			sOutCome = StringFunction.getProfileString(sLogID,"OutCome");
			sLogType = StringFunction.getProfileString(sLogID,"LogType");
			sLogID = StringFunction.getProfileString(sLogID,"LogID");
		}else{
			sOutCome = sLogID;
		}
		//this.interpreter.commitBinding(Sqlca);
		Sqlca.conn.commit();
		}catch(Exception e){
			logger.error("������"+e);
			return "REJECT";
		}
		return sOutCome;
	}
	// װ�ػ������ڴ�
    public static void loadConfig(Transaction Sqlca)
    {
        try
        {
        	logger.info("��ʼ����Ϣ��ʼ");
        	/**
            ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_CODE, Sqlca);
            logger.info("0 "+ASConfigure.SYSCONFIG_CODE);
            ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_COMP, Sqlca);
            logger.info("1 "+ASConfigure.SYSCONFIG_COMP);
            ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_FUNC, Sqlca);
            logger.info("2 "+ASConfigure.SYSCONFIG_FUNC);
            ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_ROLE, Sqlca);
            logger.info("3 "+ASConfigure.SYSCONFIG_ROLE);
            */
            ASConfigure.getSysConfig("SYSCONF_BO_TYPE", Sqlca);
            logger.info("4 "+"SYSCONF_BO_TYPE");
            ASConfigure.getSysConfig("SYSCONF_DTREE", Sqlca);
            logger.info("5 "+"SYSCONF_DTREE");
            ASConfigure.getSysConfig("SYSCONF_RULESET", Sqlca);
            logger.info("6 "+"SYSCONF_RULESET");
            ASConfigure.getSysConfig("SYSCONF_POLICY", Sqlca);
            logger.info("7 "+"SYSCONF_POLICY");
            logger.info("��ʼ����Ϣ����");
            logger.error("loadConfig()]����ϵͳ����ʱ������" );
        } catch (Exception e)
        {
            e.printStackTrace();
            logger.error("loadConfig()]����ϵͳ����ʱ������" + e);
            throw new RuntimeException("loadConfig()]����ϵͳ����ʱ������" + e);
        }
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sUrl = "jdbc:oracle:thin:@10.25.17.102:1521:pams";
		String sDriverName = "oracle.jdbc.driver.OracleDriver";
		String sUserName = "pams";
		String sUserPass = "amars0ft";
		Transaction Sqlcas=null;
		try{
		
		Sqlcas= ConnectionManager.getTransaction(sUrl, sDriverName, sUserName, sUserPass);
		Sqlcas.iChange=2;
		Sqlcas.iDebugMode=1;
		
		RunRuleFace face = new RunRuleFace(Sqlcas,"CB_CREDIT_WORKFLOW_PRESCRIPT","200906270016");
		System.out.print("���������н��"+face.runRule("RS_145"));
		
		}catch(Exception e){e.printStackTrace();}
		
	}

}
