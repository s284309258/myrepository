package com.amarsoft.DESTask.Biz.Serialno;

import java.sql.Connection;
import java.util.ArrayList;

public class GuarantyContract extends getSerialNo{
	@Override
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("GUARANTY_CONTRACT","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"",con);
	}
}
