package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public class getBusinessApplicant extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("BUSINESS_APPLICANT","SERIALNO","yyyyMMdd","000000", new java.util.Date(),"",con);
	}

}
