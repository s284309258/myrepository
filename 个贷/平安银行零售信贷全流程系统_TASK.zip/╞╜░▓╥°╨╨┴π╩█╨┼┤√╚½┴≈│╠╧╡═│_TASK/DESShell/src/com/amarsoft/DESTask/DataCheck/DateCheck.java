package com.amarsoft.DESTask.DataCheck;

  
import java.text.*;
import java.util.Date;

import com.amarsoft.DataCheck.DataCheck;

public class DateCheck extends DataCheck {

	public boolean Check() {
		if(!si.isNulls()&&this.Data.equals("")) return true;
		return this.checkDate(this.Data);
	}
	
	
    public  boolean checkDate(String sourceDate){
        if(sourceDate==null){
            return false;
        }
        try {
               SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
               dateFormat.setLenient(false);
               dateFormat.parse(sourceDate);
               return true;
        } catch (Exception e) {
        }
         return false;
    }
    
    /**
     * �������ڻ������(��������κ����),�ϸ�Ҫ��������ȷ��,��ʽ:yyyy-MM-dd HH:mm
     * @param sourceDate
     * @return
     * @throws ParseException 
     */
    public  Date getDate(String sourceDate) throws ParseException{
         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
         dateFormat.setLenient(false);
          return dateFormat.parse(sourceDate);
    }

}
