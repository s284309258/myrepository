package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public class getFlowTask extends AbstractBiz{
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		sSerialNo =  getSerialNo("FLOW_TASK","SERIALNO","yyyyMMdd","0000", new java.util.Date(),"",con);
	}

}
