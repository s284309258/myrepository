package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

/**
 * ��ÿͻ���������
 * */
public class getCustomerType   extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		// TODO Auto-generated method stub
		this.SplitInfo = SplitInfo;
		String sMain_LoginYear = this.getSplitInfo("Main_LoginYear").getSplitData();
		String sMain_LoginCapital = this.getSplitInfo("Main_LoginCapital").getSplitData();
		String sMain_AnnualTaking = this.getSplitInfo("Main_AnnualTaking").getSplitData();
		String sMain_AnnualRetainedProfit = this.getSplitInfo("Main_AnnualRetainedProfit").getSplitData();
		String sMain_IsTradeCorp = this.getSplitInfo("Main_IsTradeCorp").getSplitData();
		String sMain_UnitType =  this.getSplitInfo("Main_UnitType").getSplitData();
		
		
		if("".equals(sMain_LoginYear+sMain_LoginCapital+sMain_AnnualTaking+sMain_AnnualRetainedProfit+sMain_IsTradeCorp))
		{
			this.sSerialNo = "10"; //��н�ײ�
		}	
		else if(sMain_UnitType.equals("2")||sMain_UnitType.equals("4"))
		{
			this.sSerialNo = "20"; //��н�ײ�
		}
		if(sMain_UnitType.equals("0"))
		{
			this.sSerialNo = "30";
		}
		
		
	}

}
