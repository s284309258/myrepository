package com.amarsoft.DESTask.Biz.Serialno;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;

public abstract class getSerialNo extends AbstractBiz{
   
	@Override
	public abstract void setValue(ArrayList SplitInfo, Connection con) throws Exception ;

}
