package com.amarsoft.DESTask;

import java.io.StringReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import com.amarsoft.AppTools;
import com.amarsoft.DesTools;
import com.amarsoft.Biz.AbstractBiz;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.DESTask.Biz.getBusinessApplicant;
import com.amarsoft.DESTask.Biz.getFlowTask;
import com.amarsoft.DESTask.Biz.Customer.CustomerID;
import com.amarsoft.DESTask.Biz.Customer.DeputyCustomerID;
import com.amarsoft.DESTask.Biz.Customer.getAccountPlan;
import com.amarsoft.DESTask.Biz.Customer.getCoBorrower2OrWarrantor;
import com.amarsoft.DESTask.Biz.Customer.getCoBorrowerOrWarrantor;
import com.amarsoft.DESTask.Biz.Customer.getCorpWarrantorCustomerID;
import com.amarsoft.DESTask.Biz.Customer.getCreditApply;
import com.amarsoft.DESTask.Biz.Customer.getCustomerID;
import com.amarsoft.DESTask.Biz.Customer.getGuarantyOwner;
import com.amarsoft.DESTask.Biz.Customer.getMateCustomerID;
import com.amarsoft.DESTask.Biz.Serialno.ApplyAccount;
import com.amarsoft.DESTask.Biz.Serialno.GuarantyContract;
import com.amarsoft.DESTask.Biz.Serialno.GuarantyInfo;
import com.amarsoft.DESTask.DataSend.DataSend;
import com.amarsoft.DESTask.datasplit.DataSplit;
import com.amarsoft.DESTask.rule.DESRule;
import com.amarsoft.DESTask.scen.config.ASConfigure;
import com.amarsoft.Log.logger;
import com.amarsoft.Task.CommonValues;
import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.XBLoan.ECIFCustomerUnit;
import com.amarsoft.account.entity.IndInfo;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.biz.bizlet.Bizlet;
import com.amarsoft.impl.bank.bizlets.GetFlowPool;
import com.amarsoft.impl.szpab.ei.CCFTools;
import com.amarsoft.impl.szpab.esb.OCIConfig;

public class DataUnit extends ExecAbstract{
	private java.sql.Connection Loan = null;
	private java.sql.Connection Des = null;
	private int DATA_ROW_COUNT = 0;
	private int DATA_ERROR_COUNT = 0;
	private int DATA_SUCESS_COUNT = 0;
	private int DATA_EXIST_COUNT = 0;
	private static Transaction sqlca = null;
	
	private java.sql.Connection LoanRptConn = null;
	private Transaction sqlcaRpt = null;
	
	/**
	 *  ������,�������ݿ����ӵ�
	 * */
	public  synchronized void run() {
		logger.info("DES���뿪ʼ");
		try {
			String DbFile = this.ti.getAttribute("DataFilePath");
			String ConnectionLoan = this.ti.getAttribute("ConnectionLoan");
			String ConnectionDes = this.ti.getAttribute("ConnectionDes");
			String sTaskType = this.ti.getAttribute("TaskType");
			
			DesTools.DB_FILE = DbFile;
			DBConnection dc = new DBConnection(DbFile);
			java.sql.Statement statDes = null;
			try
			{
				Loan = dc.getConn(ConnectionLoan);
				this.LoanRptConn = dc.getConn(this.ti.getAttribute("ConnectionLoanRpt"));	
				sqlca = new Transaction(Loan);
				this.sqlcaRpt = new Transaction(this.LoanRptConn);
				loadConfig(Loan);//��ʼ���ӿڶ����ļ�
				Des = dc.getConn(ConnectionDes);
				statDes = Des.createStatement();
				String phaseNo="";//���ؽ׶κ�
				// ��ѯ��DES����������
				// ���ȴ���KB0004��
				String sSql = " select * from DES_CONTENTS_INFO where status='0' and Business_Type='KB' and UPDATE_DATE > to_char(sysdate-15,'yyyy-mm-dd hh24:mi:ss')  order by Bar_Code desc   "; 
				
				java.sql.ResultSet rs = statDes.executeQuery(sSql);
				logger.info("ȡ����:��"+sSql+"��");
				while (rs.next()) {
					DATA_ROW_COUNT++;
					String BarCode = rs.getString("Bar_Code");
					/** *******************��ȡBusiness_Apply��ˮ�ſ�ʼ********************************************************* */
					// modify by xjqin 2009
					// �°�DES��Ҫ�����жϲ��������Ƿ��Ѿ�ץȡ���������û��ץ��������������
					String ObjectNo = this.getBusinessApplySerialNO(BarCode);
					
					if(ObjectNo.equals(""))
					{
						logger.info("��"+BarCode+"������û�б��Ŵ�ϵͳ��ץ��,���β���������");
						continue;
					}
					/** *******************��ȡBusiness_Apply��ˮ�Ž���********************************************************* */
			
					
					/** *******************��ȡFLOW_TASK��ˮ�ſ�ʼ********************************************************* */
					// modify by xjqin 2009
					// �жϸñ������Ƿ��Ѿ���ҵ����Ա��ȡ
					String FlowTaskNo = this.getFlowTaskNo(ObjectNo);
					
					if(FlowTaskNo.equals("")) {
						logger.info("��"+BarCode+"�������Ѿ���¼��ڻ�ȡ����,DES����������");
						sSql = "Update DES_CONTENTS_INFO set status='1' where Bar_Code='"+BarCode+"'";
						DATA_EXIST_COUNT++;
						java.sql.Statement stat = Des.createStatement();
						stat.executeUpdate(sSql);
						stat.close();
						continue;
					}
						
					/** *******************��ȡFLOW_TASK��ˮ�Ž���********************************************************* */
					java.io.Reader reader = (java.io.Reader) rs.getCharacterStream("CONTENTS_INFO");
					String content = this.getLargerString(reader); // ���LONG�е�����
					/** *******************��ʼ��������********************************************************* */
					logger.info("��ʼ�������ݡ�"+BarCode+"��");
					String sSequence = getSequence(Loan, "SEQ_DES_CONTENTS_INFO_LOG");// ��ô˴���������к�
					InsertLOG(Loan, sSequence, BarCode, content);// У����
					
					Loan.setAutoCommit(false); // �����Զ��ύ����
					
					/**
					DataSplit ds = new DataSplit(Loan, content,sTaskType);// ��ʼ�����Լ�У�鴫������
					DataSend datasend = new DataSend(Loan, sSequence,ds.getMapArray(),sTaskType); // ��ʼ�����ݷ���
					*/
					
					/*------	modified by 53	2009.11---start-----*/
					// ���������ͳһ�������������������,���ð�����ǰ�Ĺ��̱����������
					String sKBType = "";
					if("Des2009".equals(sTaskType)){
						if(BarCode.length() >= 6) sKBType = BarCode.substring(0, 6);
					}
					DataSplit ds = new DataSplit(Loan, content,sKBType);// ��ʼ�����Լ�У�鴫������
					DataSend datasend = new DataSend(Loan, sSequence,ds.getMapArray(),sKBType); // ��ʼ�����ݷ���
					/*------	modified by 53	2009.11---end-----/
					
					/** *******************���ù���������ʼ********************************************************* */
					datasend.addCommonValues("BARCODE",BarCode);
					datasend.addCommonValues("BUSINESSAPPLY", ObjectNo);
					datasend.addCommonValues("FLOWTASK", FlowTaskNo);
					// �������һ��,��set��һ���Ĺ�������
					if(BarCode.startsWith("KB0004")){
						this.setCommonValues0004(datasend,ds.getMapArray(),Loan);
					}
					else{
						this.setCommonValues(datasend,ds.getMapArray(),Loan);
					}
					
					/** ********************���ù�����������****************************************************** */
//								
					try {
					/************************��ʼ��������*****************************************************************/
						//��ֹ�����ظ�����,����ɾ������
					    this.clearFlowData(Loan,ObjectNo);
						datasend.SendSplitData();
						if(datasend.isErrorFlag()) // ���뱨��
						{
							SendTaskError(BarCode,datasend.getErrorMessage(),datasend.getCommonValues(),Loan);
						}
						UpdateLOG(Loan, sSequence, 1, "�����ɹ�"); // �ɹ�
						
						// added by 53	2009.11.24
						//�޸��������ֱ�ʶ add by ytgong
						//String sBankFlag = this.SpiltBank(Loan, BarCode);
						String sBankFlag = this.updateFlag_PAB(Loan, "PAB", BarCode);//���������Ϻ󣬸�����ҵ������ȫ����ʼ��Ϊ��PAB��--2012.09.14��
						
						/*********************������թ���ֻ����һ���������ſ�ʼ********************************************************* */
						String customercolumntype = sqlca.getString("select ba.customercolumntype from business_apply ba where ba.serialno='"+ObjectNo+"'");
						String businesstype = sqlca.getString("select ba.businesstype from business_apply ba where ba.serialno='"+ObjectNo+"'");
						customercolumntype = DataConvert.toString(customercolumntype);
						if("1140100".equals(businesstype) && !"".equals(customercolumntype))
						{
							
							try{
								//�������Ϊ��������թ���
								String cnt = sqlca.getString("select count(1) from ind_info ii where ii.customerid=(select customerid from business_apply ba where ba.serialno='"+ObjectNo+"') and (ii.fullname is null or ii.fullname='')");
								if("0".equals(cnt))
								{
									com.amarsoft.app.logicCheck.AntiFraudCheckModel acf = new com.amarsoft.app.logicCheck.AntiFraudCheckModel(sqlca,ObjectNo,"CBCreditApply","","0");
									Object iCount = (Object)acf.run(sqlca,sqlcaRpt);
									if(iCount.toString().startsWith("failure")) {
										System.out.println("�ǵ�����թ��ⷢ������");
									}
									System.out.println("�ǵ�����թ�����:"+ObjectNo+"--iCount:"+iCount.toString());
								}
								
							}catch(Exception ex){
								System.out.println("�ǵ�����թ��ⷢ������");
							}
							sqlca.executeSQL("UPDATE BUSINESS_APPLY SET ISCHEATCHECK='1' WHERE SERIALNO='"+ObjectNo+"'");
			             
			                //ex-chenjinbing002 ���������Զ�����--ƽ���ػ�- 20120406 ���뿪ʼ
			                if("SDB".equals(sBankFlag)){
			                	sqlca.executeSQL("update BUSINESS_APPLY set PINGANGUARD='' WHERE SERIALNO='"+ObjectNo+"'");
			                }
			                //ex-chenjinbing002 ���������Զ�����--ƽ���ػ�- 20120406 �������
						}
						/*********************������թ���ֻ����һ���������Ž���********************************************************* */
						
					/***************************************************************************************/
					
						//String BankFlag = this.SpiltBank(Loan, BarCode);
						//�ҵ�������������ֱ�ӳ�ʼ�����������
//						if("0040".equals(phaseNo)&&"SDB".equals(BankFlag)){
//						    sSql = "Update BUSINESS_APPLY set SchemeNoFalg='1' where Bar_Code_No='"+BarCode+"'";
//						    java.sql.Statement stat = Loan.createStatement();
//						    stat.executeUpdate(sSql);
//						    stat.close();
//						}
						
						// �������̱�
						 phaseNo = this.sendFlows(datasend);
						
						logger.info("�����������");
						Loan.commit();
						DATA_SUCESS_COUNT++;
					/*************************���ݴ�������****************************************************************/
						
					} catch (Exception ex) // �쳣����¼��־����Ϣ
					{
						UpdateLOG(Loan, sSequence, 2, "��������,������Ϣ��" + ex.getMessage()+ "��"); // ����ʧ��
						logger.warn("��������,������Ϣ "+ex.getMessage());
						DATA_ERROR_COUNT++;
						Loan.rollback();				
						ex.printStackTrace();
					}
					finally
					{
						Loan.setAutoCommit(true);
					}
					
					//ECIF���׿��� add by xjqin 20090925
					this.setECIFCustomerID();
					// add end
					logger.info("��"+BarCode+"���������");
					
					sSql = "Update DES_CONTENTS_INFO set status='1' where Bar_Code='"+BarCode+"'";
					java.sql.Statement stat = Des.createStatement();
					stat.executeUpdate(sSql);
					stat.close();
					/***************************************************************************************/
				}
				Loan.commit();
				Des.commit(); 
			} catch (Exception ex) {
				logger.warn("���й����г��� "+ex.getMessage());
				ex.printStackTrace();
			}
			finally {
				if(statDes!=null) statDes.close();
				Loan.setAutoCommit(true);
				if(Loan!=null) Loan.close();
				if(Des!=null) Des.close();
				if(sqlca !=null )sqlca.disConnect();
				if(sqlcaRpt!=null){sqlcaRpt.disConnect();sqlcaRpt =null;}
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		String Message = "�˴β������ݹ�:"+this.DATA_ROW_COUNT+"�� ";
			   Message += "�ɹ���������:"+this.DATA_SUCESS_COUNT+"�� ";
			   Message += "����ʧ������:"+this.DATA_ERROR_COUNT+"�� ";
			   Message += "����δ��������:"+this.DATA_EXIST_COUNT+"�� ";
		logger.info(Message);
	}
	

	/**
	 * 
	 * @author: 	--53 2009-11-24
	 * @describe:	DES����֮��������̽׶�
	 *
	 */
	private String sendFlows( DataSend datasend ) throws Exception{
		
		// ֱ�ӷ��
		boolean reject = false;
		String barCode = datasend.getCommonValues().getValue("BARCODE");
		String sSerialNoBA = datasend.getCommonValues().getValue("BUSINESSAPPLY");
		String sSerialNoFT = datasend.getCommonValues().getValue("FLOWTASK");
		String flowNo = "CB0010";
		String phaseNo = "2000";
		// �������һ��,��Ҫ���Զ��ܾ��ж�
		if(barCode.startsWith("KB0004")){
			flowNo = "CB0050";
			reject = doReject( sSerialNoBA, barCode );
		}
		// �������ͨ��,��ֱ�Ӿܾ�
		if( reject ){
			phaseNo = "2000";
		}
		// ����д�,����뵽�ʿؽ׶�
		else if(datasend.isErrorFlag()){
			phaseNo = "0030";
		}
		// ���û������,��ֱ�ӵ����Ž׶�
		else{
			
			String sSql = "";
			String sOutCome = "",sLogType = "",sLogID = "";
			//��������ҵ��,û��ֵ���ǣ���ֵ����
			String CustomeRcolumnType = "";
			sSql = "select ba.customercolumntype from business_apply ba where ba.serialno='"+sSerialNoBA+"'";
			CustomeRcolumnType = DataConvert.toString(sqlca.getString(sSql));
			//�ж��Ƿ��������ţ����������Զ�������������ԭ����
			if(CustomeRcolumnType !=null && !"".equals(CustomeRcolumnType)){
				if(sSerialNoFT!=null&&sSerialNoFT.length()>0){
					try{
						//�������������Ų�ѯ��Ӧ�Ĺ�����
						System.out.println("��һ���������ŵ��ù�����RS_165��ʼ");
						com.amarsoft.DESTask.scen.run.RunRuleFace RuleFace = new com.amarsoft.DESTask.scen.run.RunRuleFace(sqlca,"CB_CREDIT_WORKFLOW_PRESCRIPT",sSerialNoFT);
						sLogID = RuleFace.runRule("RS_165");//У�鷵��ֵ���֣�
						System.out.println("��һ���������ŵ��ù�����RS_165�������ؽ��: "+sLogID);
						//----�ܹ�����
						logger.info("��������ִ����ɣ�"+sLogID);
						//���¹�������L1,PASS,REJECT
						sSql = "update FLOW_TASK set AutoDecision='"+sLogID+"' where SerialNo='"+sSerialNoFT+"'";
						sqlca.executeSQL(sSql);
						sOutCome = StringFunction.getProfileString(sLogID,"OutCome");
						sLogType = StringFunction.getProfileString(sLogID,"LogType");
						sLogID = StringFunction.getProfileString(sLogID,"LogID");
						//���øñ�ҵ�����������
						sSql = "update business_apply set APPROVELEVEL='"+sOutCome+"' where SerialNo='"+sSerialNoBA+"'";
						sqlca.executeSQL(sSql);
					}
					catch(Exception e){
						System.out.println("��һ���������ŵ��ù�����RS_165У���׳��쳣Ĭ��ִ�н��L1: "+e.getMessage());
						logger.error("-----------����У���׳��쳣��  Ĭ��ִ�н��L1-----------"+e.getMessage());
						sOutCome = "L1";//���ǹ���У����������Զ������������
						e.printStackTrace();
					}
					finally{
						//���ݹ���У��ķ���ֵȷ�����̽�����������������Զ����������
							if(sOutCome.equals("PASS")){
								phaseNo = "1000";
								logger.info("�Զ��ſ---com.amarsoft.app.lending.bizlets.DataCopyApplytoAutoByNew.java---"+sOutCome);
								Bizlet toAuto = new com.amarsoft.app.lending.bizlets.DataCopyApplytoAutoByNew();
								toAuto.setAttribute("UserID","admin"); 
								toAuto.setAttribute("DESResult","PASS"); 
								toAuto.setAttribute("ObjectNo",sSerialNoBA);
								toAuto.run(sqlca);
							
							}else if(sOutCome.equals("REJECT")){//�������������
								logger.info("���������������"+sOutCome);
								phaseNo = "2000";
							}
							else{//��������������
								logger.info("����������������"+sOutCome);
								phaseNo = "0050";
							}
						
					}
				}
			}else{
				phaseNo = "0040";
			}
			
		}
		this.sendFlowTask(datasend.getCommonValues(), flowNo, phaseNo);
		return phaseNo;
	}

	
	/**
	 * 
	 * @author: 	--53 2009-11-25
	 * @param barCode 
	 * @throws Exception 
	 * @describe:	���ݹ���У���Ƿ�ֱ�Ӿܾ�������
	 *
	 */
	private boolean doReject( String serialNoBA, String barCode) throws Exception {
		boolean reject = false;
		double businesssum = 0;
		String sSchemeno="";
		String sql = " select businesssum , SaleMode,schemeno from business_apply where serialno='"+serialNoBA+"' ";
		ASResultSet rs = sqlca.getResultSet(sql);
		if(rs.next()){
			businesssum = rs.getDouble(1);
			sSchemeno = DataConvert.toString(rs.getString("schemeno"));
		}
		rs.close();
		
//		// ���������� > 300000��ϵͳֱ�Ӿܾ�
//		if(businesssum > 300000 ){
//			reject = true;
//			logger.info("�� ���������� > 300,000��ϵͳֱ�Ӿܾ� ��");
//		}
//		// ���������� < 30000��ϵͳֱ�Ӿܾ�
//		else 
		//415:��ѶС�����ô�	
		if( (businesssum < 30000) && !"415".equals(sSchemeno) ){
			reject = true;
			logger.info("������������ < 30,000��ϵͳֱ�Ӿܾ� ��");
		}
		if("415".equals(sSchemeno)&& businesssum > 30000){
			reject = true;
			logger.info("����������Ϊ��ѶС��,���������� > 30,000��ϵͳֱ�Ӿܾ� ��");
		}
		
		return reject;
	}


	/**
	 * 
	 * @author: 	--53 2009-11-27
	 * @describe:	���ǵ����ٴ�����,ͳһд�ڸ÷�����
	 *
	 */
	private void sendFlowTask(CommonValues CommonValues,String flowNo,String phaseNo ) throws Exception {
		//�������
		String sql = "";
		String serialNo = CommonValues.getValue("FLOWTASK");
		String objectNo = CommonValues.getValue("BUSINESSAPPLY");
		String sendSerialNo = "";
		String flowName="",phaseName="",phaseType="",FMStandardTime1="",FMStandardTime2="";
		java.sql.Statement stat = null;
		ResultSet rsFlowModel = null;
			
		try {
			stat = Loan.createStatement();
			
			/*------------1.��ѯFLOW_MODEL��FLOW_CATALOG-------*/
			sql = "select fc.flowname,fm.phasename,fm.phasetype,fm.standardtime1,fm.standardtime2 from flow_catalog fc, flow_model fm " +
					" where fm.flowno=fc.flowno and fc.flowno='"+flowNo+"' and fm.phaseno='"+phaseNo+"'";
			rsFlowModel = stat.executeQuery(sql);
			if (rsFlowModel.next()) {
				flowName = DataConvert.toString(rsFlowModel.getString(1));
				phaseName = DataConvert.toString(rsFlowModel.getString(2));
				phaseType = DataConvert.toString(rsFlowModel.getString(3));
				FMStandardTime1 = DataConvert.toString(rsFlowModel.getString(4));
				FMStandardTime2 = DataConvert.toString(rsFlowModel.getString(5));
			}
			
			/*-----------2.�ر�ԭ��������----------------*/
			sql =  " UPDATE FLOW_TASK SET userid='admin', ENDTIME=to_char(sysdate,'YYYY/MM/DD HH24:MI:SS') where SERIALNO = '"+serialNo+"' ";
			logger.debug(sql);
			stat.executeUpdate(sql);
			
			/*-------3.����FLOW_OBJECT-------------*/
			sql =  " UPDATE FLOW_OBJECT SET (PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,PhaseName, "+
					" OrgID,OrgName,UserID,UserName,InputDate) = "+
					" (select '"+phaseType+"','DESApply','"+flowNo+"','"+flowName+"','"+phaseNo+"','"+phaseName+"', "+
					" '1','ƽ������','OPS','OPS',to_char(sysdate,'YYYY/MM/DD') from dual) where OBJECTNO = '"+objectNo+"' and OBJECTTYPE = 'CBCreditApply' ";
			logger.debug(sql);
			stat.executeUpdate(sql);
			
			/*----------------------4.���뵽�µĽ׶�-----------------------*/
			/*--------4.1��ȡ�µ���ˮ��-------------*/
			AbstractBiz cb = new getFlowTask();
			cb.setValue(null, Loan);
			sendSerialNo = cb.getReturn();
			
			/*--------4.2�����µ�����--------------*/
			String sFlag = "020";
			if("CB0050".equals(flowNo))  sFlag = "010";
			
			sql =  " insert into FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,FlowNo,FlowName,PhaseNo,PhaseName, "+
					" PhaseType,ApplyType,BeginTime,UserID,UserName,OrgID,OrgName,StandardTime1,StandardTime2,PhaseOpinion3) values "+
					" ('"+sendSerialNo+"','"+serialNo+"','CBCreditApply','"+objectNo+"','"+flowNo+"','"+flowName+"','"+phaseNo+"','"+phaseName+"', "+
					" '"+phaseType+"','DESApply',to_char(sysdate,'YYYY/MM/DD HH24:MI:SS'),'OPS','OPS','1','ƽ������','"+FMStandardTime1+"','"+FMStandardTime2+"','"+sFlag+"') ";
			logger.debug(sql);
			stat.executeUpdate(sql);
			
			/*--------4.3��ͬ�׶�ִ�е��������----------*/
			//4.3.1���Ž׶�
			if("0040".equals(phaseNo)){
				
				//----������Ȩ����
				Bizlet toPa = new GetFlowPool();
				toPa.setAttribute("ObjectType","CBCreditApply"); 
				toPa.setAttribute("ObjectNo",objectNo);
				toPa.setAttribute("SerialNo",sendSerialNo);
				toPa.setAttribute("Role","A02");
				toPa.run(sqlca);
				
				//----�ܹ�����
				new DESRule().runRule(serialNo, objectNo, sqlca);
			}
			//4.3.1�����׶�
			if("0050".equals(phaseNo)){
				
				//----������Ȩ����
				Bizlet toPa = new GetFlowPool();
				toPa.setAttribute("ObjectType","CBCreditApply"); 
				toPa.setAttribute("ObjectNo",objectNo);
				toPa.setAttribute("SerialNo",sendSerialNo);
				toPa.setAttribute("Role","A03");
				toPa.run(sqlca);
			}
			
			// 4.3.2�������
			else if("2000".equals(phaseNo)){
				
				//����BA���ֶ�
				sql = " update BUSINESS_APPLY set APPROVERESULT='R' where serialno = '"+objectNo+"'";
				stat.executeUpdate(sql);
			}
			
			System.out.println("�ɹ����뵽 "+phaseName+" ������ "+objectNo);
			logger.info("�ɹ����뵽 "+phaseName+" ������ "+objectNo);
			
		} catch (SQLException e) {
			logger.warn("������Ϣ "+e.getMessage());
			e.printStackTrace();
		} finally {
			if( rsFlowModel != null ) rsFlowModel.close();
			if( stat != null ) stat.close();
		}
	}
	

	/****
	 * ��ȡ�Լ����º��Ŀͻ���
	 * @author xjqin 20090925
	 * @throws SQLException 
	 * **/
	private final void setECIFCustomerID() throws Exception
	{
		//add by xjqin 20090902 ������֤ͬ�����Լ�֤��������Ա������ͬһ��������� ,��� ��ż�빲ͬ�����Ϊͬһ��
		HashMap<String,CustomerID> CustomerMap = CustomerID.getCustomerIDMap();
		for(Iterator<String> it=CustomerMap.keySet().iterator();it.hasNext();)
		 {
			String key = (String)it.next();
		    CustomerID CustomerIDTmp = CustomerMap.get(key);
		    //���CustomerID 
		    String sql = "select ii.FullName,ii.CertType,ii.CertID,ii.Sex,ii.BirthDay,ci.mfcustomerid from ind_info ii,customer_info ci where ii.customerid = ci.customerid and  ii.CustomerID = '"+CustomerIDTmp.getCustomerID()+"'";
		    logger.info(sql);
		    java.sql.Statement stat = Loan.createStatement();
		    java.sql.ResultSet rs = stat.executeQuery(sql);
		    //������
		    if(rs.next())
		    {
		    	//������ 
		    	try {
		 			IndInfo ii = new IndInfo();
		 			ii.setCustomerID(CustomerIDTmp.getCustomerID());
		 			ii.setFullName(rs.getString("FullName"));
		 			ii.setCertType(rs.getString("CertType"));
		 			ii.setCertID(rs.getString("CertID"));
		 			ii.setSex(rs.getString("Sex"));
		 			ii.setBirthDay(rs.getString("BirthDay"));
					if(rs.getString("mfcustomerid") == null) ECIFCustomerUnit.dealECIF(ii,sqlca);//����ECIF�ͻ�������
					
		 		} catch (Exception e) {
		 			logger.info("��ȡ���Ŀͻ���...ʧ�ܣ�CertID=" +CustomerIDTmp.getCertID()+";CertType="+CustomerIDTmp.getCertType()+
		 					";CustomerID="+CustomerIDTmp.getCustomerID()
		 					+ e.getMessage());
		 			logger.error("��ȡ���Ŀͻ���...ʧ�ܣ�CertID=" +CustomerIDTmp.getCertID()+";CertType="+CustomerIDTmp.getCertType()+
		 					";CustomerID="+CustomerIDTmp.getCustomerID()
		 					+ e.getMessage());
		 		} 
		    }
		    rs.close();
		    stat.close();
		 }
		CustomerID.clearCustomerMap();
	}
	
	public static void loadConfig(java.sql.Connection conn) {
		try {
			//��ʼ������,�ܹ���
			ASConfigure.getSysConfig("SYSCONF_BO_TYPE", sqlca);
			logger.info("4 "+"SYSCONF_BO_TYPE");
			ASConfigure.getSysConfig("SYSCONF_DTREE", sqlca);
			logger.info("5 "+"SYSCONF_DTREE");
			ASConfigure.getSysConfig("SYSCONF_RULESET", sqlca);
			logger.info("6 "+"SYSCONF_RULESET");
			ASConfigure.getSysConfig("SYSCONF_POLICY", sqlca);
			logger.info("7 "+"SYSCONF_POLICY");
			logger.info("��ʼ����Ϣ����");
			OCIConfig.loadOCIConfig(true);
			OCIConfig.setEnvironment("Cycle");
			OCIConfig.setDataSourceName("Loan");
			OCIConfig.setImageDataSourceName("IMS");
			SystemConfig.loadSystemConfig(true, conn);
			  
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            throw new RuntimeException("loadConfig()]����ϵͳ����ʱ������" + e);
        }
	}
	 
   /**
    * ���������ˮ��
    * */
	private String getBusinessApplySerialNO(String barCode)
	{
		//���������ˮ��
		String sReturn = "";
		java.sql.Statement stat = null;
		try
		{
			stat = this.Loan.createStatement();
			String sSql = "select serialno from business_apply where bar_code_no='"+barCode+"'";
			ResultSet rs = stat.executeQuery(sSql);
			if(rs.next())
				sReturn = rs.getString("serialNo");
		}
		catch(Exception ex)
		{
			
		}
		finally
		{
			if(stat!=null)
				try {
					stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return sReturn;
	}
	
	/**
	 * @author lenovo 
	 * ���Ŵ�ϵͳ����ȡ�������ˮ������
	 * */
	private String getFlowTaskNo(String ObjectNo)
	{
		//���������ˮ��
		String sReturn  = "";
		java.sql.Statement stat = null;
		try
		{
			stat = this.Loan.createStatement();
			String sSql = "select serialno from flow_task where objectno='"+ObjectNo+"' AND objecttype='CBCreditApply' and  phaseno='0010' and userid='OPS'";
			ResultSet rs = stat.executeQuery(sSql);
			if(rs.next())
				sReturn = rs.getString("serialNo");
		}
		catch(Exception ex)
		{
			
		}
		finally
		{
			if(stat!=null)
				try {
					stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return sReturn;
		
	}
	
	
	/**
	 * ����ǰ��ɾ��һ������
	 * */
	private final void clearFlowData(java.sql.Connection conn,String ObjectNO)
	{
		String sObjectType = "CBCreditApply";
		java.sql.Statement stat = null;
		try {
			stat = conn.createStatement();
			//BUSINESS_APPLICANT
			stat.addBatch("delete from BUSINESS_APPLICANT where ObjectType = '"+sObjectType+"'  and ObjectNo = '"+ObjectNO+"'");
			
			stat.addBatch("delete from GUARANTY_OWNER where GuarantyID in " +
			 	      "(select GuarantyID  from GUARANTY_RELATIVE where ObjectType = '"+sObjectType+"'  " +
				      " and ObjectNo = '"+ObjectNO+"' and Channel = 'New')  ");
			
			//GUARANTY_INFO
			stat.addBatch("delete from GUARANTY_INFO where GuarantyID in " +
				 	      "(select GuarantyID  from GUARANTY_RELATIVE where ObjectType = '"+sObjectType+"'  " +
					      " and ObjectNo = '"+ObjectNO+"' and Channel = 'New')  " +
					      " and Status = '01' ");
			//GUARANTY_RELATIVE
			stat.addBatch("delete from GUARANTY_RELATIVE where ObjectType = '"+sObjectType+"'  and ObjectNo = '"+ObjectNO+"' ");
			//GUARANTY_CONTRACT
			stat.addBatch("delete from GUARANTY_CONTRACT  where SerialNo " +
					"in (select ObjectNo  from APPLY_RELATIVE  " +
					"where ObjectType = 'GuarantyContract'  and SerialNo = '"+ObjectNO+"')");
			
			stat.addBatch("delete from APPLY_RELATIVE where SerialNo = '"+ObjectNO+"' ");
			
			stat.addBatch("delete from FLOW_TASK where ObjectType = 'CBCreditApply'  and ObjectNo = '"+ObjectNO+"' and ( phaseno='0030' or phaseno='0040' or phaseno='2000') ");
			
			// BUSINESS_IND_RELA
			stat.addBatch("delete from BUSINESS_IND_RELA where ObjectType = 'CBCreditApply'  and ObjectNo = '"+ObjectNO+"' ");
			
			stat.executeBatch();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stat!=null)
			{
				try {
					stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		//BUSINESS_APPLICANT
		
		// 
		
	}
	
	    /**
	     * ��ʼ���滻����[��ˮ��]
	     * ����ȫ�ֹ���ֵͳһ�滻,���������Ժ�����������ԣ����ڸ�����������
	     * �������ò����滻��������Ҫ�滻�ġ�@code#������ʽ
	     */
	    public static void setCommonValues0004(DataSend datasend, java.util.ArrayList SplitInfo, java.sql.Connection con) throws Exception {
		AbstractBiz cb = null;

		cb = new getCustomerID();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues("CUSTOMERID", cb.getReturn());
		datasend.addCommonValues("CUSTOMERIDFLAG", cb.getFlag());

		// ����ʱ�ķſ��뻹����Ȩ��Ϣ
		cb = new ApplyAccount();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues("APPLY_ACCOUNT_SERIALNO", cb.getReturn());

		// �ÿ�ƻ���ˮ�� ***********add by ytgong 2012/03/19 ***************
		String[][] array = new String[][] { { "Account_Account_Plan1", "Account_GatheringBank" }, { "Account_Account_Plan2", "Account_GatheringBank1" }, { "Account_Account_Plan3", "Account_GatheringBank2" }, { "Account_Account_Plan4", "Account_GatheringBank3" }, { "Account_Account_Plan5", "Account_GatheringBank4" } };
		for (int i = 0; i < array.length; i++) {
		    if (!DesTools.getSplitInfo(SplitInfo, array[i][1]).getSplitData().equals("")) {
			cb = new getAccountPlan();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { array[i][0], cb.getReturn() });
		    } else {
			datasend.addCommonValues(new String[] { array[i][0], "" });
		    }
		}
		// ��ʼ�������뵽�ÿ�ƻ���
		String barCode = datasend.getCommonValues().getValue("BARCODE");
		String[][] array_barcodeno = new String[][] { { "Account_Plan1_BarcodeNo1", "Account_GatheringBank" }, { "Account_Plan2_BarcodeNo2", "Account_GatheringBank1" }, { "Account_Plan3_BarcodeNo3", "Account_GatheringBank2" }, { "Account_Plan4_BarcodeNo4", "Account_GatheringBank3" }, { "Account_Plan5_BarcodeNo5", "Account_GatheringBank4" } };
		for (int i = 0; i < array_barcodeno.length; i++) {
		    if (!DesTools.getSplitInfo(SplitInfo, array_barcodeno[i][1]).getSplitData().equals("")) {
//			cb = new getAccountPlan();
//			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { array_barcodeno[i][0], barCode });
		    } else {
			datasend.addCommonValues(new String[] { array_barcodeno[i][0], "" });
		    }
		}
		//���ÿ��������ˮ�ų�ʼ�� 
		cb = new getCreditApply();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues("CREDITAPPLYSERIALNO", cb.getReturn());
		//��ʼ��������ˮ��
		String sRetiverSerialno = datasend.getCommonValues().getValue("BUSINESSAPPLY");
		datasend.addCommonValues("CREDITAPPLYRELTIVESERIALNO", sRetiverSerialno);
	    }
	
	
	/**
	 * ����ȫ�ֹ���ֵͳһ�滻 ��ǰ���� CustomerID BusinessApply�е���ˮ�� FlowTask�е���ˮ��
	 * ���� ���������Ժ�����������ԣ����ڸ�����������
	 */
	private void setCommonValues(DataSend datasend,java.util.ArrayList SplitInfo,java.sql.Connection con) throws Exception {
		AbstractBiz cb = null;
		
		cb = new getCustomerID();
		cb.setValue(SplitInfo,con);
		datasend.addCommonValues( "CUSTOMERID", cb.getReturn());
		datasend.addCommonValues( "CUSTOMERIDFLAG", cb.getFlag());
        
		/////add by xjqin 20080730 ������żCustomerID 
		cb = new getMateCustomerID();
		cb.setValue(SplitInfo,con);
		datasend.addCommonValues(new String[] { "MATECUSTOMERID", cb.getReturn() });
		datasend.addCommonValues(new String[] { "MATECUSTOMERIDFLAG", cb.getFlag() });
		
		//��ͬ����˱��
		cb = new getCoBorrowerOrWarrantor();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues(new String[] { "COBORROWERORWARRANTOR", cb.getReturn() });
		datasend.addCommonValues(new String[] { "COBORROWERORWARRANTORFLAG", cb.getFlag() });
//		��ͬ�����2���
		cb = new getCoBorrower2OrWarrantor();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues(new String[] { "COBORROWERORWARRANTOR2", cb.getReturn() });
		datasend.addCommonValues(new String[] { "COBORROWERORWARRANTOR2FLAG", cb.getFlag() });
		
//		��ͬ�����2���
		cb = new DeputyCustomerID();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues(new String[] { "DEPUTYCUSTOMERID", cb.getReturn() });
		datasend.addCommonValues(new String[] { "DEPUTYCUSTOMERIDFLAG", cb.getFlag() });
		
		// ����ʱ�ķſ��뻹����Ȩ��Ϣ
		cb = new ApplyAccount();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues(new String[] { "APPLY_ACCOUNT_SERIALNO", cb.getReturn() });
		
		
		//��Ѻ�������
        if(!DesTools.getSplitInfo(SplitInfo,"House_GuarantyLocation").getSplitData().equals(""))
        {
        	cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_1", cb.getReturn() });
			
			cb = new GuarantyInfo();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_1", cb.getReturn() });
        }
        else
        {
        	datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_1", ""}); 
        	datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_1", ""}); 
        }


        //��Ѻ�������
        if(!DesTools.getSplitInfo(SplitInfo,"House1_GuarantyLocation").getSplitData().equals(""))
        {
        	cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_2", cb.getReturn() });
			
			cb = new GuarantyInfo();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_2", cb.getReturn() });
        }
        else
        {
        	datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_2", ""}); 
        	datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_2", ""}); 
        }
        
//      ��Ѻ�������
        if(!DesTools.getSplitInfo(SplitInfo,"House2_GuarantyLocation").getSplitData().equals(""))
        {
        	cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_3", cb.getReturn() });
			
			cb = new GuarantyInfo();
			cb.setValue(SplitInfo, con);

			datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_3", cb.getReturn() });
        }
        else
        {
        	datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_HOUSE_3", ""}); 
        	datasend.addCommonValues(new String[] { "GUARANTY_INFO_HOUSE_3", ""}); 
        }
        
        
//      ��Ѻ�������
        if(!DesTools.getSplitInfo(SplitInfo,"Car_Band").getSplitData().equals(""))
        {
        	cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_CAR_1", cb.getReturn() });
			
			cb = new GuarantyInfo();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTY_INFO_CAR_1", cb.getReturn() });
			
			cb = new getGuarantyOwner(); 
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "GUARANTY_CAR_OWNER_1", cb.getReturn() });
        }
        else
        {
        	datasend.addCommonValues(new String[] { "GUARANTYCONTRACT_CAR_1", ""}); 
        	datasend.addCommonValues(new String[] { "GUARANTY_INFO_CAR_1", ""}); 
        	datasend.addCommonValues(new String[] { "GUARANTY_CAR_OWNER_1", ""}); 
        }
        

		cb = new getBusinessApplicant();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues(new String[] { "BUSINESS_APPLICATION", cb.getReturn() });
		
		
		/***********************************************************************************/
		//Ȩ�����ж�
		 String[][] array = new String[][]{
				                             {"GUARANTY_HOUSE_1_OWNER_1","House_OwnerName1"},
											 {"GUARANTY_HOUSE_1_OWNER_2","House_OwnerName2"},
											 {"GUARANTY_HOUSE_1_OWNER_3","House_OwnerName3"},
											 {"GUARANTY_HOUSE_2_OWNER_1","House1_OwnerName1"},
											 {"GUARANTY_HOUSE_2_OWNER_2","House1_OwnerName2"},
											 {"GUARANTY_HOUSE_2_OWNER_3","House1_OwnerName3"},
											 {"GUARANTY_HOUSE_3_OWNER_1","House2_OwnerName1"},
											 {"GUARANTY_HOUSE_3_OWNER_2","House2_OwnerName2"},
											 {"GUARANTY_HOUSE_3_OWNER_3","House2_OwnerName3"},		
											 
		 
		 };
		 for(int i=0;i<array.length;i++)
		 {
			if(!DesTools.getSplitInfo(SplitInfo,array[i][1]).getSplitData().equals(""))
			 {
				 cb = new getGuarantyOwner(); 
				 cb.setValue(SplitInfo, con);
				 datasend.addCommonValues(new String[] {array[i][0], cb.getReturn() });
			 }
			else
				datasend.addCommonValues(new String[] {array[i][0], "" });
		 }
		
		/************************************************************************************/
		//������˾����
		if(!DesTools.getSplitInfo(SplitInfo,"Bank_GuarantyCorp").getSplitData().equals("")) 
		{
			cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "BankGuarantyCorp", cb.getReturn() });
		}
		else 
			datasend.addCommonValues(new String[] { "BankGuarantyCorp", "" });
		//һ��¥�����̵���
		if(!DesTools.getSplitInfo(SplitInfo,"Bank_ThirdParty1").getSplitData().equals("")) 
		{
			cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "CreditAggreement2SerialNO", cb.getReturn() });
		}
		else 
			datasend.addCommonValues(new String[] { "CreditAggreement2SerialNO", "" });
		
		//���������̶�Ⱥ�
		if(!DesTools.getSplitInfo(SplitInfo,"Bank_ThirdParty2").getSplitData().equals("")) 
		{
			cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "CreditAggreement3SerialNO", cb.getReturn() });
		}
		else 
			datasend.addCommonValues(new String[] { "CreditAggreement3SerialNO", "" });
		
		//��˾��֤�˵�Ѻ��ͬ��
		if(!DesTools.getSplitInfo(SplitInfo,"CorpWarrantor_FullName").getSplitData().equals("")) 
		{
			cb = new GuarantyContract();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "CorpWarrantorGCNO", cb.getReturn() });
			
//			��˾��֤��
			cb = new getCorpWarrantorCustomerID();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { "CorpWarrantorCustomerID", cb.getReturn() });
		}
		else 
		{
			datasend.addCommonValues(new String[] { "CorpWarrantorCustomerID", ""});
			datasend.addCommonValues(new String[] { "CorpWarrantorGCNO", "" });
		}
		
		// �ÿ�ƻ���ˮ�� ***********add by ytgong 2012/03/19 ***************
		String[][] arrayplan = new String[][] { { "Account_Account_Plan1", "Account_GatheringBank" }, { "Account_Account_Plan2", "Account_GatheringBank1" }, { "Account_Account_Plan3", "Account_GatheringBank2" }, { "Account_Account_Plan4", "Account_GatheringBank3" }, { "Account_Account_Plan5", "Account_GatheringBank4" } };
		for (int i = 0; i < arrayplan.length; i++) {
		    if (!DesTools.getSplitInfo(SplitInfo, arrayplan[i][1]).getSplitData().equals("")) {
			cb = new getAccountPlan();
			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { arrayplan[i][0], cb.getReturn() });
		    } else {
			datasend.addCommonValues(new String[] { arrayplan[i][0], "" });
		    }
		}
		// ��ʼ�������뵽�ÿ�ƻ���
		String barCode = datasend.getCommonValues().getValue("BARCODE");
		String[][] array_barcodeno = new String[][] { { "Account_Plan1_BarcodeNo1", "Account_GatheringBank" }, { "Account_Plan2_BarcodeNo2", "Account_GatheringBank1" }, { "Account_Plan3_BarcodeNo3", "Account_GatheringBank2" }, { "Account_Plan4_BarcodeNo4", "Account_GatheringBank3" }, { "Account_Plan5_BarcodeNo5", "Account_GatheringBank4" } };
		for (int i = 0; i < array_barcodeno.length; i++) {
		    if (!DesTools.getSplitInfo(SplitInfo, array_barcodeno[i][1]).getSplitData().equals("")) {
//			cb = new getAccountPlan();
//			cb.setValue(SplitInfo, con);
			datasend.addCommonValues(new String[] { array_barcodeno[i][0], barCode });
		    } else {
			datasend.addCommonValues(new String[] { array_barcodeno[i][0], "" });
		    }
		}
		//���ÿ��������ˮ�ų�ʼ�� 
		cb = new getCreditApply();
		cb.setValue(SplitInfo, con);
		datasend.addCommonValues("CREDITAPPLYSERIALNO", cb.getReturn());
		//��ʼ��������ˮ��
		String sRetiverSerialno = datasend.getCommonValues().getValue("BUSINESSAPPLY");
		datasend.addCommonValues("CREDITAPPLYRELTIVESERIALNO", sRetiverSerialno);
		
		
	}
	
    /**
     * ������ݿ�����б��
     * */
	public static String getSequence(Connection con, String SequenceName)
			throws SQLException {
		String sReturn = "";
		String sSql = "Select " + SequenceName + ".NEXTVAL From dual";
		java.sql.ResultSet rs = con.createStatement().executeQuery(sSql);
		try
		{
		if (rs.next())
			sReturn = rs.getString(1);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			sReturn = "999999999999999";
		}
		finally
		{
			rs.getStatement().close();
		}
		
		return sReturn;

	}

	/**
	 * ������־����Ϣ
	 */
	private static void InsertLOG(Connection con, String SerialNO,
			String BarCode, String content) throws SQLException {
		String sSql = "Insert Into DES_CONTENTS_INFO_LOG (SerialNo,BAR_CODE,CONTENTS_INFO,execResult) values('"
				+ SerialNO + "','" + BarCode + "',?,'0')";// ���ڲ���
		java.sql.PreparedStatement stm = con.prepareStatement(sSql);
		try
		{
			stm.setCharacterStream(1, new StringReader(content), content.length());
			stm.executeUpdate();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			stm.close();	
		}
		
	}

	/**
	 * ������־����Ϣ
	 */
	public static void UpdateLOG(Connection con, String SerialNO, int Result,
			String Remark) throws SQLException {
//		String Remark1 = AppTools.ReplaceAll(Remark,"'","��");
//		String sSql = "Update DES_CONTENTS_INFO_LOG set execResult='" + Result
//				+ "',Remark=substr(Remark||'" + Remark1 + "',0,3000) where SerialNO='"
//				+ SerialNO + "'";// ���ڲ���
//		java.sql.Statement stat = con.createStatement();
//		try
//		{
//			stat = con.createStatement();
//			stat.executeUpdate(sSql);
//		}
//		catch(Exception ex)
//		{
//			ex.printStackTrace();
//		}
//		finally
//		{
//			stat.close();	
//		}
		
	}
	
    /**
    * ���LONG�ֶε����ݣ���Long���ݵ�����ת�����ַ���
    * */
	public static String getLargerString(java.io.Reader reader)
			throws Exception {
		char[] content = new char[1024000];
		char[] buffer = new char[1024];
		int len = 0;
		int off = 0;
		int contentLen = 1024000;
		
		while (true) {
			len = reader.read(buffer);
			if (len == -1)
				break;
			if (off + len > contentLen) {
				char[] tmp = new char[contentLen + 1024000];
				System.arraycopy(content, 0, tmp, 0, off);
				content = tmp;
				contentLen = contentLen + 1024000;
			}
			System.arraycopy(buffer, 0, content, off, len);
			off = off + len;
		}
		return new String(content, 0, off);
	}
    
	
//	public  void sendFlowTask(String BarCode,com.amarsoft.Task.CommonValues CommonValues,java.sql.Connection con) throws Exception
//	{
//		String sFlowTaskSerialNo = CommonValues.getValue("FLOWTASK");
//		String sObjectNo = CommonValues.getValue("BUSINESSAPPLY");
//		String sObjectType = "CreditApply";
//		String sFlowNo = "CreditFlowDES";
//		String sApplyType = "DESApply";
//		String sPhaseNo = "0030";
//		String sUserID = "DES";
//		String sOrgID = "";
//		
//		java.sql.Statement stat = null;
//		try
//		{
//			stat = con.createStatement();
//			String sSql = "select  * from des_list where bar_code_no='"+BarCode+"'"; //�ж��Ŵ��Ƿ��Ѿ�¼���˴�Bar_Code
//			
//			java.sql.ResultSet rsx = stat.executeQuery(sSql);
//			if(rsx.next())
//			{
//				//String inputType = rsx.getString("InputType");
//				String sSerialNo = rsx.getString("SerialNo");
//				if(sSerialNo==null) sSerialNo = "";
//				
//				if(sSerialNo.equals(""))//δ����ִ�и���
//				{
//				   sSql = "update des_list set serialno='"+sObjectNo+"',LastUser='DES',InputType='050' where bar_code_no='"+BarCode+"'";
//				   logger.info("�����Ѿ�������,���������б��е���ˮ��!");	
//				}
//				else
//				{
//					logger.info("�����Ѿ���ִ��,��������!");	
//					throw new Exception("�����Ѿ���ִ��,��������!");
//				}
//			}
//			else
//			{
//				sSql = "select * from DOCUMENT_KB where  Bar_Code_NO='"+BarCode+"' and document_type='KB00'"; 
//				java.sql.ResultSet rsy = Des.createStatement().executeQuery(sSql);
//				String sScan_Time = AppTools.getNowTime();
//				String sScan_Site = "";
//				String Scan_Operator = "DES";
//				if(rsy.next())
//				{
//					sScan_Time = rsy.getString("Scan_Time");
//					sScan_Site = rsy.getString("Scan_Site");
//				}
//				rsy.getStatement().close();
//				
//				sSql = "Insert Into des_list (Bar_Code_No,Scan_Site,Scan_Operator,Scan_Time,InputType,SerialNo,Lastuser)" +
//				" values ('"+BarCode+"','"+sScan_Site+"','','"+sScan_Time+"','050','"+sObjectNo+"','"+Scan_Operator+"')";
//			}
//			
//			rsx.close();
//			
//			logger.debug(sSql);
//			
//			stat.executeUpdate(sSql);
//			stat.close();
//			InitializeFlow InitializeFlow = new InitializeFlow();
//			
//			try {
//				InitializeFlow.run(con,sFlowTaskSerialNo,sObjectType,sObjectNo,sApplyType,sFlowNo,sPhaseNo,sUserID,sOrgID);
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}	
//		}
//		catch(Exception ex)
//		{
//			ex.printStackTrace();
//		}
//		finally
//		{
//			stat.close();
//		}
//	}
    
	public static void SendTaskError(String BarCode,String Error,com.amarsoft.Task.CommonValues CommonValues,java.sql.Connection con) throws SQLException
	{
		java.sql.Statement stat = null;
		java.sql.PreparedStatement stm = null;//con.prepareStatement(sSql);
		try
		{
			logger.info(Error);
//			System.out.println(Error);
			Error = AppTools.ReplaceAll(Error,"\"","��");
			//Error = AppTools.ReplaceAll(Error,";;","\n");
			Error = AppTools.ReplaceAll(Error,";","");
			Error = Error.replaceAll("\n","\n\t");
			String sFlowTaskSerialNo = CommonValues.getValue("BUSINESSAPPLY");
			stat = con.createStatement();
			String sql = "select /*+ FIRST_ROWS */1 from DES_CheckError where BarCodeNo='"+BarCode+"'";
			ResultSet rs = stat.executeQuery(sql);
			
//			if(!rs.next())
//			{
//				sql = "Insert into DES_CheckError (BARCODENO,Remark,DesType,SerialNo) values ('"+BarCode+"','"+Error+"','1','"+sFlowTaskSerialNo+"')";
//			}
//			else
//			{
//				sql = "update DES_CheckError set Remark='"+Error+"' where BarCodeNo='"+BarCode+"'";
//			}
//			System.out.println(sql);
			//stat.executeUpdate(sql);
			
			if(!rs.next())
			{
				sql = "Insert into DES_CheckError (BARCODENO,Remark,DesType,SerialNo) values ('"+BarCode+"',?,'1','"+sFlowTaskSerialNo+"')";
			}
			else
			{
				sql = "update DES_CheckError set Remark=? where BarCodeNo='"+BarCode+"'";
			}
			
			try
			{
				stm = con.prepareStatement(sql);
				stm.setCharacterStream(1, new StringReader(Error), Error.length());
				stm.executeUpdate();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			finally
			{
				if(stm!=null)
					stm.close();	
			}
			

		}
		catch(Exception ex)
		{

			ex.printStackTrace();
		}
		finally
		{
			if(stat!=null)
				stat.close();
		}
	}
	
	    // �������б�ʶ
	    public String SpiltBank(Connection conn, String BarCode) throws SQLException {
			java.sql.PreparedStatement ps = null;
			ResultSet rs = null;
			String BankFlag = "PAB";
			try {
				String sSql = "select PaymentCardID from business_apply where bar_code_no ='" + BarCode + "'";
				ps = conn.prepareStatement(sSql);
				rs = ps.executeQuery();
				if (rs.next()) {
					String PaymentCardID = rs.getString("PaymentCardID");
					if (PaymentCardID != null && !"".equals(PaymentCardID)) {
						BankFlag = DataUnit.selectFlag(ps, rs, conn, PaymentCardID, BarCode);
					} else {
						// ��һ�������ҵ���ʼ��
						DataUnit.updateFlag(ps, rs, conn, BankFlag, BarCode);
					}
				}
				rs.close();
				ps.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			}
			return BankFlag;
	   }

	    // ���ݲ�ѯ�Ŀ���ƥ����ƽ�����������
	    public static String selectFlag(java.sql.PreparedStatement ps, ResultSet rs, Connection conn, String PaymentCardID,String BarCode) throws SQLException {
		String BankFlag = "SDB";
		try {
		    String sSql = "select 1 from code_library where codeno='AcctBin' and itemno='" + PaymentCardID.substring(0, 6) + "'";
		    ps = conn.prepareStatement(sSql);
		    rs = ps.executeQuery();
		    if (rs.next()) BankFlag = "PAB";
		    if(!"".equals(BarCode))updateFlag(ps, rs, conn, BankFlag,BarCode);
		    rs.close();
		    ps.close();
		} catch (SQLException e) {
		    e.printStackTrace();
		} finally {
		    if (rs != null)
			rs.close();
		    if (ps != null)
			ps.close();
		}
		return BankFlag;
	    }

	    // �޸�BA����BankFlag�ֶΣ�ƽ����PAB,���SDB��
	    public static void updateFlag(java.sql.PreparedStatement ps, ResultSet rs, Connection conn, String BankFlag, String BarCode) throws SQLException {
			String sSql = "";
			try {
				sSql = "update business_apply set bankflag='" + BankFlag + "' where bar_code_no='" + BarCode + "'";
				ps = conn.prepareStatement(sSql);
				ps.executeQuery();
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			}
	   }
	    
	    // �޸�BA����BankFlag�ֶΣ�ƽ����PAB,���SDB�������Ϻ󣬸�������ҵ�����ͳ�ʼΪ��PAB����
	    public String  updateFlag_PAB(Connection conn, String BankFlag, String BarCode) throws SQLException {
	    	java.sql.PreparedStatement ps = null;
	    	try {
	    		String sSql = "update business_apply set bankflag='" + BankFlag + "' where bar_code_no='" + BarCode + "'";
	    		ps = conn.prepareStatement(sSql);
	    		ps.executeQuery();
	    		ps.close();
	    	} catch (SQLException e) {
	    		e.printStackTrace();
	    	} finally {
	    		if (ps != null)ps.close();
	    	}
	    	return BankFlag;
	    }
}
