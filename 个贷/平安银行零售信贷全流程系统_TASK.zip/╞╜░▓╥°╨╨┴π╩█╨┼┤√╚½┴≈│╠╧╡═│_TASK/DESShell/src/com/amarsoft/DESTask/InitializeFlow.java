package com.amarsoft.DESTask;


public class InitializeFlow
{

    public InitializeFlow()
    {
    }

    public Object run(java.sql.Connection con,
    				  String sFlowTaskSerialNo,
    				  String sObjectType,
    				  String sObjectNo,
    				  String sApplyType,
    				  String sFlowNo,
    				  String sPhaseNo,
    				  String sUserID,
    				  String sOrgID
                     )
        throws Exception
    {

        String sUserName = "";
        String sOrgName = "";
        String sFlowName = "";
        String sPhaseName = "";
        String sPhaseType = "";
        String sSql = "";
        java.sql.Statement stat = con.createStatement();
        java.sql.ResultSet rs = null;
        try
        {
	        sSql = " select UserName from USER_INFO where UserID = '" + sUserID + "' ";  
	        rs = stat.executeQuery(sSql); 
	        if(rs.next()) sUserName = rs.getString("sUserName");
	        if(sUserName == null)sUserName = "";
	    
	        rs.close();
	        sSql = " select OrgName from ORG_INFO where OrgID = '" + sOrgID + "' ";
	        rs = stat.executeQuery(sSql); 
	        
	        if(rs.next()) sOrgName = rs.getString("OrgName");
	        if(sOrgName == null)sOrgName = "";
	        rs.close();    
	        
	        sSql = " select FlowName from FLOW_CATALOG where FlowNo = '" + sFlowNo + "' ";
	        
	        rs = stat.executeQuery(sSql); 
	        if(rs.next()) sFlowName = rs.getString("FlowName");
	        if(sFlowName == null)sFlowName = "";
	        rs.close();
	        
	        sSql = " select PhaseName,PhaseType from FLOW_MODEL where FlowNo = '" + sFlowNo + "' and PhaseNo = '" + sPhaseNo + "' ";
	        rs = stat.executeQuery(sSql); 
	        if(rs.next())
	        {
	            sPhaseName = rs.getString("PhaseName");
	            sPhaseType = rs.getString("PhaseType");
	            if(sPhaseName == null)
	                sPhaseName = "";
	            if(sPhaseType == null)
	                sPhaseType = "";
	        }
	        rs.close();
	        
	        if(sOrgName == null)
	            sOrgName = "";
	        
	        sSql = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,  PhaseName,OrgID,OrgName,UserID,UserName,InputDate)  values ('" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "', " + " '" + sFlowName + "','" + sPhaseNo + "','" + sPhaseName + "','" + sOrgID + "','" + sOrgName + "','" + sUserID + "', " + " '" + sUserName + "',to_char(sysdate,'yyyy/mm/dd')) ";
	        stat.executeUpdate(sSql);
	        sSql = " insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime)  values ('" + sFlowTaskSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "', " + " '" + sFlowNo + "','" + sFlowName + "','" + sPhaseNo + "','" + sPhaseName + "','" + sOrgID + "','" + sUserID + "', " + " '" + sUserName + "','" + sOrgName + "',to_char(sysdate,'yyyy/mm/dd hh24:mi:ss') )";
	        stat.executeUpdate(sSql);
        }
        catch(Exception ex)
        {}
        finally
        {
        	 stat.close();
        }
       
        return "1";
    }
}