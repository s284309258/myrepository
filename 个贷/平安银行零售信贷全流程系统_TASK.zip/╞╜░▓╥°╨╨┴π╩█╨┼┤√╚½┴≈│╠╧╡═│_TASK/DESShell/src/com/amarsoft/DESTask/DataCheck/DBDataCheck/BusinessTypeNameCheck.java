package com.amarsoft.DESTask.DataCheck.DBDataCheck;
public class BusinessTypeNameCheck extends DBDataCheck {

	@Override
	protected void init() {
	       this.CheckSQL  = "select /*+ FIRST_ROWS +*/1  from business_type where typeno='"+this.Data+"'";
	       this.notFindMsg = "��"+this.si.getColumnGBName()+"����"+this.Data+"�� û���ҵ�,���ʵ!";
	}
}
