package com.amarsoft.DESTask.DataSend;
import com.amarsoft.AppTools;
import com.amarsoft.DESTask.datasplit.SplitInfo;

public class SendTableInfo {
	private String TableID = "";

	private String TableName = "";

	private String TableGBName = "";

	private int ExistCheck = 0;

	private String ExistAction = "";

	private String ExceptionAction = "";

	private String CheckColumns = "";

	private String CheckStatement = "";

	private String CheckSql = "";

	private String CheckWhereClause = "";

	private String HistoryTable = "";

	private String ExecExpression = "";

	private boolean DataExists = false;

	private java.util.ArrayList ColumnList = new java.util.ArrayList();

	private java.util.ArrayList SplitInfo = null;
	public SendTableInfo(String TableID) {
		this.TableID = TableID;
	}

	/**
	 * @return Returns the exceptionAction.
	 */
	public final String getExceptionAction() {
		return ExceptionAction;
	}

	/**
	 * @param exceptionAction
	 *            The exceptionAction to set.
	 */
	public final void setExceptionAction(String exceptionAction) {
		ExceptionAction = exceptionAction;
	}

	/**
	 * @return Returns the existAction.
	 */
	public final String getExistAction() {
		return ExistAction;
	}

	/**
	 * @param existAction
	 *            The existAction to set.
	 */
	public final void setExistAction(String existAction) {
		ExistAction = existAction;
	}

	/**
	 * @return Returns the existCheck.
	 */
	public final int getExistCheck() {
		return ExistCheck;
	}

	/**
	 * @param existCheck
	 *            The existCheck to set.
	 */
	public final void setExistCheck(int existCheck) {

		ExistCheck = existCheck;
	}

	/**
	 * @return Returns the tableGBName.
	 */
	public final String getTableGBName() {
		return TableGBName;
	}

	/**
	 * @param tableGBName
	 *            The tableGBName to set.
	 */
	public final void setTableGBName(String tableGBName) {
		TableGBName = tableGBName;
	}

	/**
	 * @return Returns the tableID.
	 */
	public final String getTableID() {
		return TableID;
	}

	/**
	 * @param tableID
	 *            The tableID to set.
	 */
	public final void setTableID(String tableID) {
		TableID = tableID;
	}

	/**
	 * @return Returns the tableName.
	 */
	public final String getTableName() {
		return TableName;
	}

	/**
	 * @param tableName
	 *            The tableName to set.
	 */
	public final void setTableName(String tableName) {
		TableName = tableName;
	}

	/**
	 * @return Returns the columnList.
	 */
	public final java.util.ArrayList getColumnList() {
		return ColumnList;
	}

	/**
	 * @param columnList
	 *            The columnList to set.
	 */
	public final void setColumnList(java.util.ArrayList columnList) {
		ColumnList = columnList;
	}

	public final void addColumnList(SendColumnInfo sci) {
		this.ColumnList.add(sci);
	}

	/**
	 * @return Returns the checkColumns.
	 */
	public final String getCheckColumns() {
		return CheckColumns;
	}

	/**
	 * @param checkColumns
	 *            The checkColumns to set.
	 */
	public final void setCheckColumns(String checkColumns) {
		CheckColumns = checkColumns;

	}

	/**
	 * @return Returns the checkStatement.
	 */
	public final String getCheckStatement() {
		return CheckStatement;
	}

	/**
	 * @param checkStatement
	 *            The checkStatement to set.
	 */
	public final void setCheckStatement(String checkStatement) {
		CheckStatement = checkStatement;
	}

	public final void setCheckSql() {
		if (this.CheckColumns == null&&this.ExistCheck==1) {
			this.CheckSql = "";
			return;
		}

		if (this.ExistCheck == 1) // ����У��
		{
			if (this.getCheckColumns() == "") {
				this.ExistCheck = 0; // ���ó���У��
				this.CheckSql = "";
			} else {
				String[] Columns = this.CheckColumns.split(",");
				if (this.CheckColumns.length() == 0) {
					this.ExistCheck = 0;
					this.CheckSql = "";
				} else {
					// ƴ��Check���
					for (int i = 0; i < Columns.length; i++) {
						for (int j = 0; j < ColumnList.size(); j++) {
							SendColumnInfo sci = (SendColumnInfo) ColumnList
									.get(j);
							if (sci.getColumnName().equals(Columns[i])
									&& sci.getFormatType() != 4) {
								// this.CheckSql += " and
								// "+sci.getColumnName()+" =
								// '"+sci.getSplitInfo().getSplitData()+"'";
								if (sci.getFormatType() == 1) // ֱ������
									this.CheckSql += " and "
											+ sci.getColumnName() + " = '"
											+ sci.getSplitInfo().getSplitData()
											+ "'";
								else if (sci.getFormatType() == 2)// ����ʽ
								{
									this.CheckSql += " and "
											+ sci.getColumnName() + " = "
											+ sci.getFormatExpression() + "";
									this.CheckSql = AppTools.ReplaceAll(
											this.CheckSql, "@DATA#", sci
													.getSplitInfo()
													.getSplitData());
									this.CheckSql = AppTools.ReplaceAll(
											this.CheckSql, "@SplitName#", sci
													.getSplitColumnName());
								} else if (sci.getFormatType() == 3)// Ĭ��ֵ
								{
									this.CheckSql += " and "
											+ sci.getColumnName() + " = '"
											+ sci.getFormatExpression() + "'";
								}

							}
						}
					}

					if (this.CheckSql.length() > 0) {
						this.CheckWhereClause = this.CheckSql;
						this.CheckSql = "select /*+ FIRST_ROWS +*/1 from " + this.getTableName()
								+ " where 1=1 " + this.CheckSql;
					}
				}
			}
		} else if (this.ExistCheck == 2) // �ű�У��
		{
			if (this.getCheckStatement() == null) {
				this.ExistCheck = 0; // ���ó���У��
				this.CheckSql = "";
			} else
				this.CheckSql = this.getCheckStatement();
			for (int j = 0; j < this.SplitInfo.size(); j++) {
				SplitInfo si = (SplitInfo) this.SplitInfo.get(j);
				
				this.CheckSql = AppTools.ReplaceAll(this.CheckSql, "@"
						+ si.getColumnName() + "#", si.getSplitData());
			}
			
			this.CheckWhereClause = " and "+this.CheckSql;
			this.CheckSql = "select /*+ FIRST_ROWS +*/ 1 from "+this.getTableName()+" where 1=1 and "+this.CheckSql;
		}
	}

	public final String getCheckWhereClause() {
		return this.CheckWhereClause;
	}

	public final String getCheckSql() {
		return this.CheckSql;
	}

	/**
	 * @return Returns the dataExists.
	 */
	public final boolean isDataExists() {
		return DataExists;
	}

	/**
	 * @param dataExists
	 *            The dataExists to set.
	 */
	public final void setDataExists(boolean dataExists) {
		DataExists = dataExists;
	}

	/**
	 * @return Returns the historyTable.
	 */
	public final String getHistoryTable() {
		return HistoryTable;
	}

	/**
	 * @param historyTable
	 *            The historyTable to set.
	 */
	public final void setHistoryTable(String historyTable) {
		HistoryTable = historyTable;
	}

	/**
	 * @return Returns the execExpression.
	 */
	public final String getExecExpression() {
		return ExecExpression;
	}

	/**
	 * @param execExpression
	 *            The execExpression to set.
	 */
	public final void setExecExpression(String execExpression) {
		ExecExpression = execExpression;
	}

	/**
	 * @return Returns the splitInfo.
	 */
	public final java.util.ArrayList getSplitInfo() {
		return SplitInfo;
	}

	/**
	 * @param splitInfo The splitInfo to set.
	 */
	public final void setSplitInfo(java.util.ArrayList splitInfo) {
		SplitInfo = splitInfo;
	}
	
	
}
