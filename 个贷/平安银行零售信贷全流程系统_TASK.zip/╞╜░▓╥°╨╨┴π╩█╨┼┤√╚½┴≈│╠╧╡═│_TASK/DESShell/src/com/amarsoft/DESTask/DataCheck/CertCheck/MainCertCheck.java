package com.amarsoft.DESTask.DataCheck.CertCheck;

/**
 * �������֤������У��
 * */
public class MainCertCheck extends AbstractCertCheck{

	@Override
	protected void setValues() {
		this.CERTID_AREANAME = "Main_CertID";
		this.CERTTYPE_AREANAME = "Main_CertType";
		this.CertID = this.getSplitInfo("Main_CertID").getSplitData();
		this.CertType = this.getSplitInfo("Main_CertType").getSplitData();
		this.Sex = this.getSplitInfo("Main_Sex").getSplitData();
		this.Birthday = this.getSplitInfo("Main_Birthday").getSplitData();
		this.CheckSex = true;
		this.CheckBirthday = true;
	}
}
