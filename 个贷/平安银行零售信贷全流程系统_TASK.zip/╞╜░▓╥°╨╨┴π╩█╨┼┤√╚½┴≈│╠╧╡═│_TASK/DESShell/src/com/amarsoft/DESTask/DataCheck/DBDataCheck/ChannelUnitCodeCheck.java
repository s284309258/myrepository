package com.amarsoft.DESTask.DataCheck.DBDataCheck;

public class ChannelUnitCodeCheck  extends DBDataCheck{

	@Override
	protected void init() {
		// TODO Auto-generated method stub
		String Business_ChannelCode = this.getSplitInfo("Business_ChannelCode").getSplitData();//03  �н�  04 ������
		if(Business_ChannelCode.equals("04")||Business_ChannelCode.equals("03"))
		{       
		       this.CheckSQL  = "select /*+ FIRST_ROWS +*/1  FROM sale_channel where channelcode='"+this.Data+"' and ChannelType in ('03', '04', '06')";
		       this.notFindMsg = "��"+this.si.getColumnGBName()+"����"+this.Data+"�� û���ҵ�,���ʵ!"; 
		}
	}

	

}
