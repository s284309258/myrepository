package com.amarsoft.DESTask.DataCheck.ImgIntegralityCheck;

import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.DesTools;
import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.DataCheck.DataCheck;

public abstract class ImgIntegralityCheck extends DataCheck {
    
	protected java.sql.Connection IMS = null;
	protected java.util.ArrayList<String> SqlArray = new java.util.ArrayList<String>();
	
	protected abstract boolean isCheck();
	protected void init() throws Exception
	{
		if(DesTools.DB_FILE.equals(""))
		{
			throw new Exception("�Ҳ������ݿ������ļ�!");
		}
		
		if(DesTools.IMS_DataSource.equals(""))
		{
			throw new Exception("�Ҳ���Ӱ�����ݿ����ӷ�!");
		}
		
		DBConnection dc = new DBConnection(DesTools.DB_FILE);
		IMS = dc.getConn(DesTools.IMS_DataSource);
	}
	
	@Override
	public boolean Check() {
		if(this.si.isNulls()&&this.Data.equals(""))
			return true;
		
		if(!isCheck())
			return true;
		
		for(int i = 0 ;i < this.SqlArray.size();i++)
		{
			String sql = this.SqlArray.get(i);
			if(!IntegralityCheck(sql))
			{
				this.AddReturnMsg("��"+this.si.getColumnGBName()+"��δ�ҵ����Ӱ��!");
				return false;
			}
		}
		return true;
	}

	
	/**
	 * �ж����ݴ��ڲ�����
	 * */
	protected final boolean IntegralityCheck(String sSql)
	{
		Statement stat = null;
		java.sql.ResultSet rs = null;
		try
		{
			stat = IMS.createStatement();
			rs = stat.executeQuery(sSql);
			return rs.next();
		}
		catch(Exception ex)
		{
			return false;
		}finally
		{
				try {
					if(rs!=null) rs.close();
					if(stat!=null) stat.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
}
