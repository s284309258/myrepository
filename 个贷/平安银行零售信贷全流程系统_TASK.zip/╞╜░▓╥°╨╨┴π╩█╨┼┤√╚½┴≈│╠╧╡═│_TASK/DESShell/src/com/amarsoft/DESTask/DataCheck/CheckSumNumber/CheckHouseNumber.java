package com.amarsoft.DESTask.DataCheck.CheckSumNumber;

public class CheckHouseNumber extends CheckSumNumber {

	@Override
	protected int setNoteCount() {
		int iReturn = 0;
		String[] OwnerColumn = new String[]{"House_GuarantyName",
											"House1_GuarantyName",
											"House2_GuarantyName",
											
		};
		 
		for(int i=0;i<OwnerColumn.length;i++)
		{
			if(!this.getSplitInfo(OwnerColumn[i]).getSplitData().equals(""))
				iReturn++;
		}
		return iReturn;
	}
    
}
