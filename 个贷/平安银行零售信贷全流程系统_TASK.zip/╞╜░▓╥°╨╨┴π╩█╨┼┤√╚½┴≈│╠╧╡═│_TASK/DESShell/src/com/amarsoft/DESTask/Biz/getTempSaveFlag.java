package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;
import com.amarsoft.DESTask.datasplit.SplitInfo;

public class getTempSaveFlag extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		this.SplitInfo = SplitInfo;
		sSerialNo =  "2";
		boolean error = false;
		for(int i = 0 ; i < SplitInfo.size() ; i ++){
			SplitInfo splitInfo = (SplitInfo)SplitInfo.get(i);
			error = splitInfo.isError();
			if( ( splitInfo.getColumnName().startsWith("Inside_") || splitInfo.getColumnName().startsWith("Loan_") 
					|| splitInfo.getColumnName().startsWith("Business_")) && error ) {
				sSerialNo = "1";
				break;
			}
		}
	}

}
