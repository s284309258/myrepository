package com.amarsoft.DESTask.DataCheck.CheckSumNumber;

public class CheckSumOwnerNumber  extends CheckSumNumber {

	@Override
	protected int setNoteCount() {
		// TODO Auto-generated method stub
		int iReturn = 0;
		//��һ�׷�
		String[] OwnerColumn = null;
		if(this.si.getColumnName().equals("House_OwnerNumber"))
		{
			OwnerColumn = new String[]{"House_OwnerName1",
					"House_OwnerName2",
					"House_OwnerName3"};
		}
		else if(this.si.getColumnName().equals("House1_OwnerNumber"))
		{
			OwnerColumn = new String[]{"House1_OwnerName1",
					"House1_OwnerName2",
					"House1_OwnerName3"};
		}
		else if(this.si.getColumnName().equals("House2_OwnerNumber"))
		{
			OwnerColumn = new String[]{"House2_OwnerName1",
					"House2_OwnerName2",
					"House2_OwnerName3"};
		}
		if(OwnerColumn==null) return 0 ;
		for(int i=0;i<OwnerColumn.length;i++)
		{
			
			if(!this.getSplitInfo(OwnerColumn[i]).getSplitData().equals(""))
				iReturn++;
		}
		return iReturn;
	}
}
