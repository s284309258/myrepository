package com.amarsoft.DESTask.datasplit;
import java.util.ArrayList;

public class DesCodeMap {
	 private String DesName = "";
	 private String DesCode = "";
     java.util.ArrayList CodeMaps = new java.util.ArrayList();
     java.util.ArrayList SplitInfo = null;
     public  DesCodeMap(String DesCode)
     {
    	 CodeMaps = new java.util.ArrayList();
    	 this.DesCode = DesCode;
     }
     
     
	/**
	 * @return Returns the desCode.
	 */
	public final String getDesCode() {
		return DesCode;
	}


	/**
	 * @param desCode The desCode to set.
	 */
	public final void setDesCode(String desCode) {
		DesCode = desCode;
	}
    

	/**
	 * @return Returns the splitInfo.
	 */
	public final java.util.ArrayList getSplitInfo() {
		return SplitInfo;
	}


	/**
	 * @param splitInfo The splitInfo to set.
	 */
	public final void setSplitInfo(java.util.ArrayList splitInfo) {
		SplitInfo = splitInfo;
	}


	/**
	 * @return Returns the desName.
	 */
	public final String getDesName() {
		return DesName;
	}


	/**
	 * @return Returns the codeMap.
	 */
	public final java.util.ArrayList getCodeMap() {
		return CodeMaps;
	}
	/**
	 * @param codeMap The codeMap to set.
	 */
	public final void setCodeMap(java.util.ArrayList codeMap) {
		CodeMaps = codeMap;
	}
	
	/**
	 * @param desName The desName to set.
	 */
	public final void setDesName(String desName) {
		DesName = desName;
	}
     
	public final void addCodeMap(CodeMap cm)
	{
		CodeMaps.add(cm);
	}
	/**
	 * ��ϸУ��У��ֵ����ͱ�У��ֵ��ȫ��ͬ��ͨ��
	 * */
	public final boolean isExistInCodeMap(String Code)
	{
		   boolean sReturn = false;
		   for(int i=0;i<this.CodeMaps.size();i++)
		   {
		         CodeMap cm = (CodeMap) this.CodeMaps.get(i);
		         //������������
		         if(cm.getOtherCode().equals("0"))
		         {
		        	 if(cm.getDesItemNo().equals(Code))
		        	 {
		        		  sReturn = true;
		        		  break;
		        	 }
		         }
		         else
		         {
		        	 if(Code.startsWith(cm.getDesItemNo()))
		        	 {
		        		  String tmp = Code.substring(cm.getDesItemNo().length());
		        		  {
		        			  if(!cm.getOtherColumn().equals(""))
		        			  {
		        				  SplitInfo si = getSplitInfo(cm.getOtherColumn());
		        				  if(si==null)
		        				  {
		        					  si = new SplitInfo(this.SplitInfo.size());
		        					  si.setColumnName(cm.getOtherColumn());
		        					  si.setColumnGBName(cm.getOtherColumn());
		        					  si.setCodeChcek(0);
		        					  si.setDataType("STRING");
		        					  
		        				  }
		        				  si.setSplitData(tmp);
		        				  this.SplitInfo.add(si);
		        				  sReturn = true;
		        				  break;
		        			  }
		        		  }
		        	 }
		        	
		         }
		   }
	       return sReturn;	
	}
    
	/**
	 * ģ��У��ֻҪ���ֹؼ��־ͷ���
	 * */
	public final boolean isExistInKey(String Code)
	{
		   boolean sReturn = false;
		   for(int i=0;i<this.CodeMaps.size()&&!sReturn;i++)
		   {
			   CodeMap cm = (CodeMap) this.CodeMaps.get(i);
			   if(cm.getKeyValue().equals(""))  continue; //��ֵ��У��
			   else 
			   {
				   String[] KeyValues = cm.getKeyValue().split(cm.getKeySeq());
				   for(int j=0;j<KeyValues.length;j++)
				   {
					   if(Code.indexOf(KeyValues[j])>-1)
					   {
						   sReturn = true;
			        	   break;
					   }
				   }
			   }
				   
		   }
		return sReturn;
	}
    
	
	/**
	 * ��ѡ���ѯ�Ƿ������Code��
	 * */
	public final boolean isExistsMulChoice(String Code)
	{
		   boolean sReturn = true;
		   ArrayList arrayList = new ArrayList();
		   String[] values = Code.split("/");

		   for(int m=0;m<values.length;m++)
		   {
			   boolean tmp = this.isExistInCodeMap(values[m]);
			   if(tmp==false)//��һ��ûƥ�䷵��
			   {
				   sReturn =  false;
				   break;
			   }
		   }
		   
		   return sReturn;
	}
	
	
	/**
	 * ��ѡ��ģ����ѯCode��
	 * */
	public final boolean isExistsLikeMulChoice(String Code)
	{
		   boolean sReturn = true;
		   ArrayList arrayList = new ArrayList();
		   String[] values = Code.split("/");

		   for(int m=0;m<values.length;m++)
		   {
			   boolean tmp = this.isExistInKey(values[m]);
			   if(tmp==false)//��һ��ûƥ�䷵��
			   {
				   sReturn =  false;
				   break;
			   }
		   }
		   
		   return sReturn;
	}
	
	
    protected SplitInfo getSplitInfo(String SplitColumnName) {
		SplitInfo sReturn = null;
		for (int i = 0; i < this.SplitInfo.size(); i++) {
			SplitInfo si = (SplitInfo) this.SplitInfo.get(i);
			if (si.getColumnName().equalsIgnoreCase(SplitColumnName)) {
				sReturn = si;
				break;
			}
		}
		return sReturn;
	}
}
