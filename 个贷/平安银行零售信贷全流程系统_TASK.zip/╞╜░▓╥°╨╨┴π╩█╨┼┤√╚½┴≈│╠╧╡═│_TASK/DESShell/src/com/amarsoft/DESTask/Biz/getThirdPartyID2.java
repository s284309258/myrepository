package com.amarsoft.DESTask.Biz;

import java.sql.Connection;
import java.util.ArrayList;

import com.amarsoft.Biz.AbstractBiz;
/**
 * ����׸������
 * 
 * */
public class getThirdPartyID2 extends AbstractBiz{

	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		this.SplitInfo = SplitInfo;
		String sHouse_GuarantyPrice = this.getSplitInfo("House_GuarantyPrice").getSplitData();
		if(sHouse_GuarantyPrice==null||sHouse_GuarantyPrice.equals(""))
			sHouse_GuarantyPrice = "0";
		
		String sHouse_GuarantyPrePay = this.getSplitInfo("House_GuarantyPrePay").getSplitData();
		if(sHouse_GuarantyPrePay==null||sHouse_GuarantyPrePay.equals(""))
			sHouse_GuarantyPrePay = "0";
		
		double tmp = 0;
		try
		{
			 tmp = (Double.parseDouble(sHouse_GuarantyPrePay)/Double.parseDouble(sHouse_GuarantyPrice))*100;
		}
		catch(Exception ex)
		{
			
		}
		this.sSerialNo = tmp+"";
	}

}
