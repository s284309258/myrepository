package com.amarsoft.DESTask.Biz.Customer;

import java.sql.Connection;
import java.util.ArrayList;

public class getMateCustomerID extends getCustomerIDAbstract{
	/**
	 * ��ÿͻ����,����֤������,֤�����ͻ�����û�в�ѯ��,����¿ͻ���
	 * */
	@Override
	protected void setCertAttributeName() {
		// TODO Auto-generated method stub
		this.sCertID = getSplitInfo("Mate_CertID").getSplitData();
		this.sCertType = getSplitInfo("Mate_CertType").getSplitData();
		this.sCustomerName = getSplitInfo("Mate_FullName").getSplitData();
		this.sSex = getSplitInfo("Mate_Sex").getSplitData();
		this.sBirthDay = getSplitInfo("Mate_Birthday").getSplitData();
	}

	@Override
	protected boolean isReturn() {
		// TODO Auto-generated method stub
		if(getSplitInfo("Mate_FullName").getSplitData().equals(""))
			return false;
		return true;
	}
	
	public void setValue(ArrayList SplitInfo, Connection con) throws Exception {
		super.setValue(SplitInfo,con);
//			this.SplitInfo = SplitInfo;
//			boolean exsitFlag = false;
//			String sSql = "";
//		    String sSqlOne = "select /*+ FIRST_ROWS +*/CustomerID from ind_info where certid='"+getSplitInfo("Mate_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Mate_CertType").getSplitData()+"'";
//		    
//		    if(getSplitInfo("Mate_CertType").getSplitData().equals("Ind01"))//����֤
//			{
//		    	 sSql = "select CustomerID from ind_info " +
//		    		" where certid='"+getSplitInfo("Mate_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Mate_CertType").getSplitData()+"' and certid is not null ";
//				java.sql.ResultSet rs1 = con.createStatement().executeQuery(sSql);
//			    if(rs1.next())
//			    {
//			    	exsitFlag = true;
//			    	sSerialNo = rs1.getString("CustomerID");
//			    }
//			    rs1.getStatement().close();
//			    if(!exsitFlag)
//			    {
//					if(getSplitInfo("Mate_CertID").getSplitData().length()==15)
//					{
//						
//						sSql = "select CustomerID from ind_info " +
//			    		" where certid=getNewID('"+getSplitInfo("Mate_CertID").getSplitData()+"') and certtype='"+getSplitInfo("Mate_CertType").getSplitData()+"' and certid is not null ";
//						rs1 = con.createStatement().executeQuery(sSql);
//					    if(rs1.next())
//					    {
//					    	exsitFlag = true;
//					    	sSerialNo = rs1.getString("CustomerID");
//					    }
//					    rs1.getStatement().close();
//					}
//					else
//					{
//						sSql = "select CustomerID from ind_info " +
//			    		" where getNewID(certid)='"+getSplitInfo("Mate_CertID").getSplitData()+"' and certtype='"+getSplitInfo("Mate_CertType").getSplitData()+"' and certid is not null ";
//						rs1 = con.createStatement().executeQuery(sSql);
//					    if(rs1.next())
//					    {
//					    	exsitFlag = true;
//					    	sSerialNo = rs1.getString("CustomerID");
//					    }
//					    rs1.getStatement().close();
//					}
//			    }
//			}
//		    
//		    java.sql.ResultSet rs = con.createStatement().executeQuery(sSqlOne);
//		    if(rs.next())
//		    {
//		    	if(!exsitFlag)
//		    	{
//		    		sSerialNo = rs.getString("CustomerID");
//		    	}
//		    }
//		    else
//		    {
//		    	sSerialNo =  getSerialNo("CUSTOMER_INFO","CUSTOMERID","yyyyMMdd","000000", new java.util.Date(),"kh",con);
//		    	//sSerialNo = "kh"+sSerialNo;
//		    }
//		    
//		    rs.getStatement().close();
		    
	}

	
}
