package com.amarsoft.DESTask.DataCheck.DBDataCheck;

import java.sql.SQLException;
import java.sql.Statement;

public class CreditAggreementCheck  extends DBDataCheck{
    
	protected String CustomerColumnName = "";
	protected String CustomerNameColumnName = "";
	@Override
	protected void init() {
		this.CheckSQL = "select /*+ FIRST_ROWS +*/LineID,CustomerID,CustomerName from cl_info where LINECONTRACTNO='"+this.Data+"'";
		if(this.si.getColumnName().equals("Bank_CreditAggreement1"))
		{
			CustomerColumnName  = "Bank_CreditAggreementCustomerID";
			CustomerNameColumnName  = "Bank_CreditAggreementCustomerName";
		}
		//���쵥λ����������̶�Ⱥ�
		else if(this.si.getColumnName().equals("Bank_CreditAggreement2"))
		{
			CustomerColumnName  = "Bank_CreditAggreement2CustomerID";
			CustomerNameColumnName  = "Bank_CreditAggreement2CustomerName";
		}
//		���쵥λ���������������
		else if(this.si.getColumnName().equals("Bank_CreditAggreement3"))
		{
			CustomerColumnName  = "Bank_CreditAggreement3CustomerID";
			CustomerNameColumnName  = "Bank_CreditAggreement3CustomerName";
		}
	
	}
	
		@Override
		public boolean Check() {
		    this.init();
		    //���쵥λ����������̶�Ⱥ�  һ��¥��������ֵʱ��¼ ҵ��Ʒ��Ϊһ��§ʱ��¼
		    if(this.si.getColumnName().equals("Bank_CreditAggreement2"))
		    {
			    if((!si.isNulls()&&this.Data.equals(""))&&this.getSplitInfo("Bank_BusinessTypeName").getSplitData().equals("1110020"))
			    {
			    	this.AddReturnMsg("ҵ��Ʒ��Ϊһ��¥,��"+this.si.getColumnGBName()+"������Ϊ��!");
					return false;
			    }
		    }
		    else if(this.si.getColumnName().equals("Bank_CreditAggreement3"))
		    {
		    	if(!this.getSplitInfo("Bank_BusinessTypeName").getSplitData().startsWith("1120")&&this.si.isNulls())
			    {
			    	//this.AddReturnMsg("ҵ��Ʒ��Ϊ��������,["+this.si.getColumnGBName()+"]����Ϊ��!");
					return true;
			    }
		    	
		    }
		    
		    if(!si.isNulls()&&this.Data.equals("")) return true;
		    	
		    Statement stat = null;
		    try {
				stat = conn.createStatement();
				java.sql.ResultSet rs = stat.executeQuery(CheckSQL);
				
				if(rs.next())
				{
					//�������¼�������Ϊ LINECONTRACTNO ,������ת��Ϊ LineID
					/*********************�ǳ������*******************************/
					this.si.setSplitData(rs.getString("LineID"));
					/***********************************************************/
					
					this.getSplitInfo(CustomerColumnName).setSplitData(rs.getString("CustomerID"));
					this.getSplitInfo(CustomerNameColumnName).setSplitData(rs.getString("CustomerName"));
				}
				else
				{
					this.AddReturnMsg("��"+this.si.getColumnGBName()+"�� ��"+this.Data+"��û���ҵ� ,���ʵ!");
					return false;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
			finally
			{
				if(stat!=null)
				{
					try {
						stat.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return true;
		}

}
