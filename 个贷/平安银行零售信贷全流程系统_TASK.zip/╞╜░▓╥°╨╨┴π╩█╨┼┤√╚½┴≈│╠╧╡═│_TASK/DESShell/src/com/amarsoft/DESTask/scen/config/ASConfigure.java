/*
 * @(#)ASConfigure.java	2003.08.03
 *
 * Copyright 2001-2003 Amarsoft, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Amarsoft, Inc.
 * Use is subject to license terms.
 *
 * Author:XDHou
 */
package com.amarsoft.DESTask.scen.config;

import java.io.InputStream;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.ASValuePool;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.are.util.XmlDocument;

/** ����amarsoft.xml�õ�ϵͳ���� */
public class ASConfigure
{
    private static XmlDocument xmlConfigure = null;
    private static boolean isInitConfig = false;
    private static boolean isReqInit = false;
    private static ASValuePool vpConfigure = new ASValuePool();
    public static String sWebRootPath = null;
    public static String sCurSlash = System.getProperty("file.separator");
    public static String sXMLFile = "WEB-INF" + sCurSlash + "amarsoft.xml";
    private static ASValuePool vpSysConfig = new ASValuePool();
    public final static String SYSCONFIG_ROLE = "ASRoleSet";
    public final static String SYSCONFIG_COMP = "ASCompSet";
    public final static String SYSCONFIG_PAGE = "ASPageSet";
    public final static String SYSCONFIG_FUNC = "ASFuncSet";
    public final static String SYSCONFIG_PREF = "ASPrefSet";
    public final static String SYSCONFIG_CODE = "ASCodeSet";

    public ASConfigure(ServletContext sc)
    {
        if (!checkReqInit())
        {
            System.out.println("ServerInfo    = [" + sc.getServerInfo() + "]");
            System.out.println("WebRealPath   = [" + sc.getRealPath("") + "]");
            InputStream fs = sc.getResourceAsStream(sXMLFile);
            isReqInit = true;
            if (!checkInit())
            {
                init(fs);
                isInitConfig = true;
            }
        }
    }

    public ASConfigure(HttpServletRequest request)
    {
        String content_root = "//";
        if (!checkReqInit())
        {
            content_root = request.getRealPath(request.getContextPath());
            String[] c = StringFunction.toStringArray(content_root, sCurSlash);
            if (c.length == 1)
            {
                sCurSlash = "\\"; // windows��ʽ�µ�Slash
            }
            isReqInit = true;
            if (!checkInit())
            {
                sXMLFile = getConfigPath(content_root);
                init(sXMLFile);
                isInitConfig = true;
                System.out.println(sXMLFile);
            }
        }
    }

    public ASConfigure(String content_root)
    {
        if (!checkInit())
        {
            sXMLFile = getConfigPath(content_root);
            init(sXMLFile);
            isInitConfig = true;
            System.out.println(sXMLFile);
        }
    }

    public ASConfigure(String sXMLPath, String sFlag)
    {
        if (!checkInit())
        {
            String[] c = StringFunction.toStringArray(sXMLPath, sCurSlash);
            if (c.length == 1)
            {
                sCurSlash = "\\"; // windows��ʽ�µ�Slash
                c = StringFunction.toStringArray(sXMLPath, sCurSlash);
            }
            sXMLFile = sXMLPath;
            init(sXMLFile);
            isInitConfig = true;
            System.out.println(sXMLFile);
        }
    }

    /**
     * @param content_root
     * @return
     */
    private String getConfigPath(String content_root)
    {
        String[] c = StringFunction.toStringArray(content_root, sCurSlash);
        if (c.length == 1)
        {
            sCurSlash = "\\"; // windows��ʽ�µ�Slash
            c = StringFunction.toStringArray(content_root, sCurSlash);
        }
        String xmlPath = "";
        for (int i = 0; i < (c.length - 1); i++)
        {
            xmlPath = xmlPath + c[i] + sCurSlash;
        }
        sXMLFile = xmlPath + "WEB-INF" + sCurSlash + "amarsoft.xml";
        return sXMLFile;
    }

    public void setWebRootPath(String sContextPath)
    {
        if (sWebRootPath == null)
        {
            sWebRootPath = sContextPath;
            System.out.println("WebRootPath   = [" + sWebRootPath + "]");
        }
    }

    synchronized private boolean checkInit()
    {
        return isInitConfig;
    }

    synchronized private boolean checkReqInit()
    {
        return isReqInit;
    }

    private void init(String sPath)
    {
        xmlConfigure = new XmlDocument(sPath);
        initXml(xmlConfigure);
    }

    private void init(InputStream is)
    {
        xmlConfigure = new XmlDocument(is);
        initXml(xmlConfigure);
    }

    private void initXml(XmlDocument xmlConfigure)
    {
        try
        {
            NodeList nlnodes = xmlConfigure.getRootNode().getChildNodes();
            Node node = null;
            String sNodeName = null;
            String sNodeValue = null;
            for (int i = 0; i < nlnodes.getLength(); i++)
            {
                node = nlnodes.item(i);
                sNodeName = node.getNodeName();
                if ("#text".equals(sNodeName))
                    continue;
                try
                {
                    sNodeValue = node.getChildNodes().item(0).getNodeValue();
                } catch (NullPointerException e1)
                {
                    // ������Ϊ��
                    // System.out.println("�����ļ����пս��"+sNodeName);
                    sNodeValue = null;
                }
                vpConfigure.setAttribute(sNodeName, sNodeValue);
            }
        } catch (Exception e)
        {
            System.out.println("ϵͳ���������ļ�ʱʧ�ܣ�" + e);
            e.printStackTrace();
        }
    }

    /** ����sItem�õ���Ӧ������ */
    public String getConfigure(String sItem) throws Exception
    {
        // String sConfig =
        // xmlConfigure.getNode(sItem,xmlConfigure.getRootNode()).getChildNodes().item(0).getNodeValue();
        String sConfig = (String) vpConfigure.getAttribute(sItem);
        if (sConfig != null && sConfig.equals("/"))
            sConfig = "";
        return sConfig;
    }

    public static ASValuePool getSysConfig(String sKey, Transaction Sqlca) throws Exception
    {
        Object oTmp = vpSysConfig.getAttribute(sKey);
        if (oTmp == null)
        {
            return (ASConfigLoaderFactory.getInstance().createLoader(sKey)).loadConfig(Sqlca);
        } else
            return (ASValuePool) oTmp;
    }

    /**
     * ȡ����
     * @param sKey �ؼ�����
     * @return Object �Լ�ת������
     * @throws Exception
     */
    public static Object getSysConfig(String sKey) throws Exception
    {
        return vpSysConfig.getAttribute(sKey);
    }

    /**
     * ��ʼ���ö�������õ�ϵͳ��������
     * @param sKey �ؼ�����
     * @param oValue ��ʼ���õ�ʵ������
     * @throws Exception
     */
    public static void setSysConfig(String sKey, Object oValue) throws Exception
    {
        vpSysConfig.setAttribute(sKey, oValue);
    }

    public static void clearXDoc()
    {
        xmlConfigure = null;
        isInitConfig = false;
        isReqInit = false;
        try
        {
            vpConfigure.resetPool();
        } catch (Exception e)
        {
            System.out.println("Reset SysConfigure is Error:" + e.toString());
        }
    }

    public static void reloadAllConfig(Transaction Sqlca) throws Exception
    {
        (ASConfigLoaderFactory.getInstance().createLoader(ASConfigure.SYSCONFIG_CODE)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[SYSCONFIG_CODE] .......... Success!" + StringFunction.getNow());
        (ASConfigLoaderFactory.getInstance().createLoader(ASConfigure.SYSCONFIG_COMP)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[SYSCONFIG_COMP] .......... Success!" + StringFunction.getNow());
        (ASConfigLoaderFactory.getInstance().createLoader(ASConfigure.SYSCONFIG_FUNC)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[SYSCONFIG_FUNC] .......... Success!" + StringFunction.getNow());
        (ASConfigLoaderFactory.getInstance().createLoader(ASConfigure.SYSCONFIG_ROLE)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[SYSCONFIG_ROLE] .......... Success!" + StringFunction.getNow());
        (ASConfigLoaderFactory.getInstance().createLoader(ASConfigure.SYSCONFIG_PREF)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[SYSCONFIG_PREF] .......... Success!" + StringFunction.getNow());
    }

    public static void reloadConfig(String ConfigCode, Transaction Sqlca) throws Exception
    {
        System.out.println("Init Cache Data[" + ConfigCode + "] .......... Begin!" + StringFunction.getNow());
        (ASConfigLoaderFactory.getInstance().createLoader(ConfigCode)).loadConfig(Sqlca);
        System.out.println("Init Cache Data[" + ConfigCode + "] .......... Success!" + StringFunction.getNow());
    }
}
