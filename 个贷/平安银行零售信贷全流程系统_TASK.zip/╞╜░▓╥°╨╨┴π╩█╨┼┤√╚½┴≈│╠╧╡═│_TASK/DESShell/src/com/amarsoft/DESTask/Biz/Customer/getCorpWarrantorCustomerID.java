package com.amarsoft.DESTask.Biz.Customer;

public class getCorpWarrantorCustomerID extends getCustomerIDAbstract{
 
	protected void setCertAttributeName() {
		// TODO Auto-generated method stub
		this.sCertID = getSplitInfo("CorpWarrantor_GuarantorNo").getSplitData();
		this.sCertType = "Ent01";
	}
	@Override
	protected boolean isReturn() {
		// TODO Auto-generated method stub
		if(getSplitInfo("CorpWarrantor_GuarantorNo").getSplitData().equals(""))
			return false;
		return true;
	}
	

}
