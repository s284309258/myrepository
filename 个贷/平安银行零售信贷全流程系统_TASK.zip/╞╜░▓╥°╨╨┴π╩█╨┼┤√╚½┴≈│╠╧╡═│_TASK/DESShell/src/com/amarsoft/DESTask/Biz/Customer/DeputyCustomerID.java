package com.amarsoft.DESTask.Biz.Customer;

/**
 * ���Ȩ���˱��
 * */
public class DeputyCustomerID extends getCustomerIDAbstract{

	@Override
	protected void setCertAttributeName() {
		// TODO Auto-generated method stub
		this.sCertID = getSplitInfo("CorpWarrantor_CertID").getSplitData();
		this.sCertType = getSplitInfo("CorpWarrantor_CertType").getSplitData();
	}

	@Override
	protected boolean isReturn() {
		if(getSplitInfo("CorpWarrantor_DeputyName").getSplitData().equals(""))
			return false;
		return true;
	}

	

}
