package com.amarsoft.DESTask.DataCheck.IntegralityCheck;

/**
 * ���ݵ�Ѻ������У��
 * */
public class HouseIntegralityCheck extends AbstractIntegralityCheck{

	@Override
	protected void setColumnList() {
		// TODO Auto-generated method stub
		
		String HouseFlag = this.si.getColumnName().split("_")[0];
		this.sFlag = HouseFlag+"_"+"GuarantyName";
		//this.addColumn(HouseFlag+"_"+"GuarantyRightID");
		this.addColumn(HouseFlag+"_"+"RealtyType");
		this.addColumn(HouseFlag+"_"+"GuarantyLocation");
		this.addColumn(HouseFlag+"_"+"OwnerTime");
		//this.addColumn(HouseFlag+"_"+"OwnerTimeBegin");
		//this.addColumn(HouseFlag+"_"+"OwnerTimeEnd");
		this.addColumn(HouseFlag+"_"+"ConstructionArea");
		//this.addColumn(HouseFlag+"_"+"EnterPrice");
		this.addColumn(HouseFlag+"_"+"SingleEvalNetValue");
		this.addColumn(HouseFlag+"_"+"SingleConfirmValue");
		this.addColumn(HouseFlag+"_"+"Use");
		this.addColumn(HouseFlag+"_"+"Type");
		this.addColumn(HouseFlag+"_"+"CompleteDate");
	}

	
}
