package com.amarsoft.DESTask.DataCheck.CheckSumNumber;

import com.amarsoft.DataCheck.DataCheck;

public abstract class CheckSumNumber extends DataCheck {
	protected abstract int setNoteCount();
	
	@Override
	public boolean Check() {
		int data = 0 ; 
		int data1 = this.setNoteCount();
		try
		{
			if(this.Data.equals("")) this.Data = "0";
			
		    data = Integer.parseInt(this.Data);	
		}
		catch(Exception ex)
		{
			return false;
		}
		
		
		if(data!=data1)
		{
			this.AddReturnMsg("��"+this.si.getColumnGBName()+"��������¼�������!");
			return false;
		}
		// TODO Auto-generated method stub
		return true;
	}

}
