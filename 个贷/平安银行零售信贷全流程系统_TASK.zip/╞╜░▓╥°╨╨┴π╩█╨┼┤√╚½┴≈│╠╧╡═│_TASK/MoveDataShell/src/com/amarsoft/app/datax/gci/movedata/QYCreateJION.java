package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateJION extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼǨ�����������ݣ�.............");

				logger.info("................��ʼ����Ǩ�����ݵ�����ͻ�ΪС΢�����壡.............");
				CreateJionData1();
				logger.info("................��ʼ���ݹ�����ϵ��ʼ��������-������Ա������.............");
				CreateJionData2();
				logger.info("................��ʼ����BC�Ĺܻ���MANAGEUSERID��.............");
				CreateJionData3();
				logger.info("................��ʼ����OPERATEUSERIDΪӪ����Ա���룡.............");
				CreateJionData4();
				logger.info("................��ʼ����BC��������BA��.............");
				CreateJionData5();
				logger.info("................��ʼ����BA��SERIALNO��BC��RELATIVESERIALNO��.............");
				CreateJionData6();
				logger.info("................��ʼ����BA����FLOW_TASK,FLOW_OBJECTNO��.............");
				CreateJionData7();
				logger.info("................��ʼ����JOINTGUARANTY_INFO�����������ϵ����.............");
				CreateJionData8();
				logger.info("................��ʼ����CONTRACT_RELATIVE������ϵ����.............");
				CreateJionData9();
				logger.info("................�޸�����������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	// ����Ǩ�����ݵ�����ͻ�ΪС΢������
	public void CreateJionData1() throws SQLException {
		String al = "Update Customer_Info "
				+ " Set Customertype = '0704', Corptype = '04'"
				+ "  Where Customerid In"
				+ "        (Select Customerid From Qy_Cl_Info Where Cltypeid = 'JOIN') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ���ݹ�����ϵ��ʼ��������-������Ա����
	public void CreateJionData2() throws SQLException {
		String al = "Insert Into Customer_Relative   (Serialno, "
				+ "    Customerid,    Relativeid, "
				+ "    Relationship,    Customername, "
				+ "    Certtype,    Certid) "
				+ "   Select 'QY2012101' ||SEQ_CLEAN.NEXTVAL, "
				+ "          Ci2.Customerid,        Ci1.Customerid, "
				+ "          '9999',        Ci1.Customername, "
				+ "          Ci.Certtype,        Ci.Certid "
				+ "    From Cl_Info Ci1, Cl_Info Ci2, Customer_Info Ci "
				+ "   Where Ci1.Parentlineid = Ci2.Lineid "
				+ "     And Ci1.Customerid = Ci.Customerid "
				+ "     And Ci2.Cltypeid = 'JOIN' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����BC�Ĺܻ���MANAGEUSERID
	public void CreateJionData3() throws SQLException {
		String al = "Update Business_Contract Bc  "
				+ "   Set Bc.Manageuserid =  " + "       (Select Lb.Userid  "
				+ "         From Loan_Balance Lb  "
				+ "         Where Lb.Contractserialno = Bc.Serialno  "
				+ "          And Lb.Putoutno Like 'QY%'  "
				+ "          And Lb.Businesstype = '2120200010'  "
				+ "          And Rownum = 1)  "
				+ "   Where Bc.Serialno Like 'QY%'  "
				+ "     And Exists (Select 1  "
				+ "            From Loan_Balance Lb  "
				+ "          Where Lb.Contractserialno = Bc.Serialno  "
				+ "             And Lb.Putoutno Like 'QY%'  "
				+ "          And Lb.Businesstype = '2120200010') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����OPERATEUSERIDΪӪ����Ա����,SELECT SM.SERIALNO FROM SALE_MANAGER SM WHERE
	// WORKID = LB.USERID
	public void CreateJionData4() throws SQLException {
		String al = " Update Business_Contract Bc "
				+ "      Set Bc.Operateuserid = "
				+ "          (Select Sm.Serialno "
				+ "             From Loan_Balance Lb, Sale_Manager Sm "
				+ "            Where Sm.Workid = Lb.Userid "
				+ "              And Lb.Contractserialno = Bc.Serialno "
				+ "            And Lb.Putoutno Like 'QY%' "
				+ "            And Lb.Businesstype = '2120200010' "
				+ "            And Rownum = 1) "
				+ "     Where Bc.Serialno Like 'QY%' "
				+ "       And Exists (Select 1 "
				+ "             From Loan_Balance Lb, Sale_Manager Sm "
				+ "            Where Sm.Workid = Lb.Userid "
				+ "             And Lb.Contractserialno = Bc.Serialno "
				+ "             And Lb.Putoutno Like 'QY%' "
				+ "            And Lb.Businesstype = '2120200010')";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����BC��������BA
	public void CreateJionData5() throws SQLException {
		String al = " insert into BUSINESS_APPLY  "
				+ " (SERIALNO,CUSTOMERID,CUSTOMERNAME,CUSTOMERTYPE,OCCURTYPE,APPLYTYPE,BUSINESSSUM,OPERATEUSERID,BUSINESSTYPE,BUSINESSSUBTYPE,CURRENCY,OPERATEORGID,INPUTORGID,BANKFLAG,BUSINESSKIND,PUTOUTTYPE)  "
				+ " select  'QY'||SEQ_CLEAN.NEXTVAL||LINECONTRACTNO,CUSTOMERID,CUSTOMERNAME,CUSTOMERTYPE,OCCURTYPE,APPLYTYPE,BUSINESSSUM,OPERATEUSERID,BUSINESSTYPE, "
				+ " BUSINESSSUBTYPE,CURRENCY,OPERATEORGID,INPUTORGID,BANKFLAG,BUSINESSKIND,PUTOUTTYPE  from ( "
				+ " Select DISTINCT CI.LINECONTRACTNO,CI.CUSTOMERID,CI.CUSTOMERNAME,'0704' as CUSTOMERTYPE,'010' AS OCCURTYPE,'SWCreditApply' as APPLYTYPE,CI.LINESUM1 as BUSINESSSUM, "
				+ "      BC.OPERATEUSERID,BC.BUSINESSTYPE,BC.BUSINESSSUBTYPE,BC.CURRENCY,BC.OPERATEORGID,BC.INPUTORGID,BC.BANKFLAG,BC.BUSINESSKIND,BC.PUTOUTTYPE "
				+ " 				 From  BUSINESS_CONTRACT BC,CL_INFO CI Where BC.BUSINESSTYPE = '2120200010' AND BC.SERIALNO LIKE 'QY%' And BC.ARTIFICIALNO = Substr(CI.LINECONTRACTNO,3,5)) ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����BA��SERIALNO��BC��RELATIVESERIALNO
	public void CreateJionData6() throws SQLException {
		String al = "Update BUSINESS_CONTRACT BC Set BC.RELATIVESERIALNO = (SELECT SERIALNO From BUSINESS_APPLY BA Where Substr(BA.SERIALNO,13,5) = BC.ARTIFICIALNO and ba.operateuserid=bc.operateuserid ) "
				+" Where BC.BUSINESSTYPE = '2120200010' AND BC.SERIALNO LIKE 'QY%' And Exists (Select 1 From BUSINESS_APPLY BA Where Substr(BA.SERIALNO,13,5) = BC.ARTIFICIALNO and ba.operateuserid=bc.operateuserid) ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����BA����FLOW_TASK,FLOW_OBJECTNO
	public void CreateJionData7() throws SQLException {
		String al = "Insert Into FLOW_TASK(SERIALNO,OBJECTNO,OBJECTTYPE,FLOWNO,FLOWNAME,PHASENO,PHASENAME,PHASETYPE,APPLYTYPE) "
				+ " Select BA.SERIALNO,BA.SERIALNO,'SWCreditApply','SW0010','С΢ҵ����������','1000','����ͨ��','0500','SWCreditApply' From BUSINESS_APPLY BA Where BA.BUSINESSTYPE='2120200010' And BA.SERIALNO Like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

		al = "Insert Into FLOW_OBJECT(OBJECTNO,OBJECTTYPE,FLOWNO,FLOWNAME,PHASENO,PHASENAME,PHASETYPE,APPLYTYPE) "
				+ " Select BA.SERIALNO,'SWCreditApply','SW0010','С΢ҵ����������','1000','����ͨ��','0500','SWCreditApply' From BUSINESS_APPLY BA Where BA.BUSINESSTYPE='2120200010' And BA.SERIALNO Like 'QY%' ";
		ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����BA����FLOW_TASK,FLOW_OBJECTNO
	public void CreateJionData8() throws SQLException {
		String al = "INSERT INTO JOINTGUARANTY_INFO (SERIALNO,OBJECTNO,OBJECTTYPE,CUSTOMERID,CUSTOMERNAME,BUSINESSSUM,INPUTORGID,INPUTUSERID,INPUTDATE,UPDATEDATE,CUSTOMERTYPE,BANKFLAG)  "
				+ "  SELECT 'QY201211' || SEQ_CLEAN.NEXTVAL, BA.SERIALNO,'SWCreditApply',BC.CUSTOMERID,BC.CUSTOMERNAME,BC.BUSINESSSUM,BC.INPUTORGID,BC.INPUTUSERID,BC.INPUTDATE,BC.UPDATEDATE,BC.CUSTOMERTYPE,BC.BANKFLAG  "
				+ "      FROM BUSINESS_CONTRACT BC, BUSINESS_APPLY BA   "
				+ "    WHERE BC.RELATIVESERIALNO = BA.SERIALNO   "
				+ "      AND BC.BUSINESSTYPE = '2120200010'  "
				+ "      AND BC.SERIALNO LIKE 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����CONTRACT_RELATIVE������ϵ��
	public void CreateJionData9() throws SQLException {
		String al = "INSERT INTO CONTRACT_RELATIVE (SERIALNO, OBJECTTYPE, OBJECTNO, RELATIVESUM) "
				+ "  SELECT BA.SERIALNO, 'JointContract', BC.SERIALNO, BC.BUSINESSSUM "
				+ "    FROM BUSINESS_CONTRACT BC, BUSINESS_APPLY BA "
				+ "  WHERE BC.RELATIVESERIALNO = BA.SERIALNO "
				+ "    AND BC.BUSINESSTYPE = '2120200010' "
				+ "    AND BC.SERIALNO LIKE 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

}
