package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCheckBaseData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼУ��ҵ�����ݣ�.............");
				checkData0();
				logger.info("................У��������ɣ�..............");
				
				logger.info("................У������.............");
				
				logger.info("................У������.............");
				checkDataResoutlt();
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void checkDataResoutlt() throws Exception{
		int i=0;
		String al="select rd.tablename,rd.tablerow,rd.errcount,rd.remark from qy_error_record rd where rd.remark='1' and rd.errcount>0 ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			logger.info("....����"+rs.getString("tablename")+"  �ֶΣ�"+rs.getString("tablerow")+"    ������"+rs.getString("errcount")+"  ��������.......");
		}
		rs.close();
		
		if(i>0){
			throw new Exception(" ���ڲ���ͨ��У������ݣ��뿴qy_error_record���� ");
		}
	}
	
	//У���ڴ�
	public void checkData0() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) "
				+" select 'qy_loan_balance','loanterm',count(1),'1' from qy_loan_balance lb where lb.loanterm <0 and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	public void checkData1() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) "
				+" select 'qy_loan_balance','GRACEPERIOD',count(1),'1' from qy_loan_balance lb where GRACEPERIOD  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData2() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PUTOUTDATE',count(1),'1' from qy_loan_balance lb where PUTOUTDATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData3() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','MATURITYDATE',count(1),'1' from qy_loan_balance lb where MATURITYDATE  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData4() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','BEGINDATE',count(1),'1' from qy_loan_balance lb where BEGINDATE  is  null   and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData5() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','MONTHENDFLAG',count(1),'1' from qy_loan_balance lb where MONTHENDFLAG  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData6() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','LOANTERM',count(1),'1' from qy_loan_balance lb where LOANTERM  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData7() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','NEXTPAYDATE',count(1),'1' from qy_loan_balance lb where NEXTPAYDATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData8() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','CTERM',count(1),'1' from qy_loan_balance lb where CTERM  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData9() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','SCTERM',count(1),'1' from qy_loan_balance lb where SCTERM  is  null   and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData10() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','STERM',count(1),'1' from qy_loan_balance lb where STERM  is  null   and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData11() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','GAINAMOUNT',count(1),'1' from qy_loan_balance lb where GAINAMOUNT  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData12() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','GAINCYC',count(1),'1' from qy_loan_balance lb where GAINCYC  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData13() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','LASTTERM',count(1),'1' from qy_loan_balance lb where LASTTERM  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData14() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','BASEDAYS',count(1),'1' from qy_loan_balance lb where BASEDAYS  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData15() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','BASERATE',count(1),'1' from qy_loan_balance lb where BASERATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData16() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','RATEFLOAT',count(1),'1' from qy_loan_balance lb where RATEFLOAT  is  null   and lb.loanstatus in ('0','1','4','5')";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	public void checkData17() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PUTOUTRATE',count(1),'1' from qy_loan_balance lb where PUTOUTRATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData18() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','EXECUTERATE',count(1),'1' from qy_loan_balance lb where EXECUTERATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData19() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','FINERATEFLOAT',count(1),'1' from qy_loan_balance lb where FINERATEFLOAT  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData20() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','FINERATE',count(1),'1' from qy_loan_balance lb where FINERATE  is  null   and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData21() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','LASTINTEDATE',count(1),'1' from qy_loan_balance lb where LASTINTEDATE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData22() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','BUSINESSSUM',count(1),'1' from qy_loan_balance lb where BUSINESSSUM  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData23() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','NORMALBALANCE',count(1),'1' from qy_loan_balance lb where NORMALBALANCE  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	public void checkData24() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','CURRENTBALANCE',count(1),'1' from qy_loan_balance lb where CURRENTBALANCE  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData25() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','DEFAULTBALANCE',count(1),'1' from qy_loan_balance lb where DEFAULTBALANCE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData26() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','OVERDUEBALANCE',count(1),'1' from qy_loan_balance lb where OVERDUEBALANCE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData27() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PAYINTE',count(1),'1' from qy_loan_balance lb where PAYINTE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData28() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PAYINNERINTE',count(1),'1' from qy_loan_balance lb where PAYINNERINTE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData29() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PAYOUTINTE',count(1),'1' from qy_loan_balance lb where PAYOUTINTE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData30() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PAYINNERINTEFINE',count(1),'1' from qy_loan_balance lb where PAYINNERINTEFINE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData31() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PAYOUTINTEFINE',count(1),'1' from qy_loan_balance lb where PAYOUTINTEFINE  is  null  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData32() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PERIODINTEBASE',count(1),'1' from qy_loan_balance lb where PERIODINTEBASE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData33() throws SQLException{
		String al="insert into qy_error_record(tablename,tablerow,errcount,remark) select  'qy_loan_balance','PERIODINTE',count(1),'1' from qy_loan_balance lb where PERIODINTE  is  null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData34() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData35() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData36() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData37() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData38() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData39() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void checkData40() throws SQLException{
		String al="";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	
}
