package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.amarsoft.account.exception.LoanException;

public class QYLedgerGeneral {
	private String PutOutNo; 		//��ݱ��
	private String AccountNo;		//�˺�
	private String Currency;		//����
	private String SubjectNo;		//��Ŀ��
	private double CreditBalance=0; //�������������
	private double DebitBalance=0; 	//�跽���գ����
	private String OrgID;			//��֯����
	private String SerialNo;
	private String Direction;       //��Ŀ����
	
	
	private String SubjectName ; //������Ŀ����
	
	private String SqlUpdateQYLedgerGeneral;
	private String SqlInsertQYLedgerGeneral;
	private String SqlDeleteQYLedgerGeneral;
	private PreparedStatement psUpdateQYLedgerGeneral = null;
	private PreparedStatement psInsertQYLedgerGeneral = null;
	private PreparedStatement psDeleteQYLedgerGeneral = null;
		
	public void OpenDeleteQYLedgerGeneral(Connection Conn) throws Exception{
		SqlDeleteQYLedgerGeneral = "Delete From qy_ledger_general WHERE PutOutNo = ? And AccountNo=?";
		psDeleteQYLedgerGeneral = Conn.prepareStatement(SqlDeleteQYLedgerGeneral);
	}
	public void DeleteQYLedgerGeneral() throws Exception{
		psDeleteQYLedgerGeneral.setString(1, this.PutOutNo);
		psDeleteQYLedgerGeneral.setString(2, this.AccountNo);
		psDeleteQYLedgerGeneral.addBatch();
	}
	
	public void OpenUpdateQYLedgerGeneral(Connection Conn) throws Exception{
		SqlUpdateQYLedgerGeneral = "UPDATE qy_ledger_general SET CreditBalance=CreditBalance+?," +
			"DebitBalance=DebitBalance+? WHERE PutOutNo = ? And AccountNo=?";

		psUpdateQYLedgerGeneral = Conn.prepareStatement(SqlUpdateQYLedgerGeneral);
	}
	public void UpdateQYLedgerGeneral() throws Exception{
		psUpdateQYLedgerGeneral.setDouble(1, this.CreditBalance);
		psUpdateQYLedgerGeneral.setDouble(2, this.DebitBalance);
		psUpdateQYLedgerGeneral.setString(3, this.PutOutNo);
		psUpdateQYLedgerGeneral.setString(4, this.AccountNo);
		psUpdateQYLedgerGeneral.addBatch();
	}
	
	//�ſ��ʼ�����˱�
	public void OpenInsertQYLedgerGeneral(Connection Conn) throws Exception{
		SqlInsertQYLedgerGeneral = " Insert Into qy_Ledger_General(PutOutNo,AccountNo,SubjectNo,Currency,CreditBalance,DebitBalance,OrgID,SerialNo,SubjectName,DIRECTION) " +
				"VALUES(?,?,?,?,?,?,?,?,?,?)";

		psInsertQYLedgerGeneral = Conn.prepareStatement(SqlInsertQYLedgerGeneral);
	}
	public void InsertQYLedgerGeneral() throws Exception{
		psInsertQYLedgerGeneral.setString(1, this.PutOutNo);
		psInsertQYLedgerGeneral.setString(2, this.AccountNo);
		psInsertQYLedgerGeneral.setString(3, this.SubjectNo);
		psInsertQYLedgerGeneral.setString(4, this.Currency);
		psInsertQYLedgerGeneral.setDouble(5, this.CreditBalance);
		psInsertQYLedgerGeneral.setDouble(6, this.DebitBalance);
		psInsertQYLedgerGeneral.setString(7, this.OrgID);
		psInsertQYLedgerGeneral.setString(8, this.SerialNo);
		psInsertQYLedgerGeneral.setString(9, this.SubjectName);
		psInsertQYLedgerGeneral.setString(10, this.Direction);
		psInsertQYLedgerGeneral.addBatch();
	}
	
	public void executeBatch() throws Exception,LoanException{
		if (psUpdateQYLedgerGeneral!=null) psUpdateQYLedgerGeneral.executeBatch();
		if (psDeleteQYLedgerGeneral!=null) psDeleteQYLedgerGeneral.executeBatch();
		if (psInsertQYLedgerGeneral!=null) psInsertQYLedgerGeneral.executeBatch();
	}
	
	public void close() throws Exception,LoanException{
		if(psUpdateQYLedgerGeneral!=null) psUpdateQYLedgerGeneral.close();
		if(psInsertQYLedgerGeneral!=null) psInsertQYLedgerGeneral.close();
		if(psDeleteQYLedgerGeneral!=null) psDeleteQYLedgerGeneral.close();
	}

	
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getSubjectNo() {
		return SubjectNo;
	}
	public void setSubjectNo(String subjectNo) {
		SubjectNo = subjectNo;
	}
	public double getCreditBalance() {
		return CreditBalance;
	}
	public void setCreditBalance(double creditBalance) {
		CreditBalance = creditBalance;
	}
	public double getDebitBalance() {
		return DebitBalance;
	}
	public void setDebitBalance(double debitBalance) {
		DebitBalance = debitBalance;
	}
	public String getOrgID() {
		return OrgID;
	}
	public void setOrgID(String orgID) {
		OrgID = orgID;
	}
	public String getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public String getSubjectName() {
		return SubjectName;
	}
	public void setSubjectName(String subjectName) {
		SubjectName = subjectName;
	}
	
	public String getDirection() {
		return Direction;
	}
	public void setDirection(String direction) {
		Direction = direction;
	}
	
}
