package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.NumberTools;

public abstract class QYTransProvider {
	ArrayList<QYLedgerDetail> qyLedgerDetailList = new ArrayList<QYLedgerDetail>();
	QYLedgerDetail Ld = new QYLedgerDetail();
	//
	public void LedgerDeal(QYLedgerDetail qyLedgerDetail,QYLedgerGeneral qyLedgerGeneral,
			HashMap<String,AttributeField> inputPara,HashMap<String,String> LedgerSubjectHashMap) throws Exception{
		qyLedgerDetailList = QYCreateLedger.getLedgerList(inputPara,LedgerSubjectHashMap);			
		for(int k=0;k<qyLedgerDetailList.size();k++){
			Ld = qyLedgerDetailList.get(k);
			qyLedgerDetail.setSerialNo(Ld.getSerialNo());
			qyLedgerDetail.setPutOutNo(Ld.getPutOutNo());
			qyLedgerDetail.setBillNo(Ld.getBillNo());
			qyLedgerDetail.setHandStatus(Ld.getHandStatus());
			qyLedgerDetail.setOccurDate(Ld.getOccurDate());
			qyLedgerDetail.setOccurTime(Ld.getOccurTime());
			qyLedgerDetail.setOrgID(Ld.getOrgID());
			qyLedgerDetail.setCurrency(Ld.getCurrency());					
			qyLedgerDetail.setTransID(Ld.getTransID());
			qyLedgerDetail.setSortID(Ld.getSortID());
			qyLedgerDetail.setSubjectNo(Ld.getSubjectNo());			
			qyLedgerDetail.setDebitAmt(Ld.getDebitAmt());
			qyLedgerDetail.setCreditAmt(Ld.getCreditAmt());
			qyLedgerDetail.InsertQYLedgerDetail();
			
			qyLedgerGeneral.setPutOutNo(Ld.getPutOutNo());
			qyLedgerGeneral.setAccountNo(Ld.getAccountNo());
			if(Ld.getLoanWay().equalsIgnoreCase("D")) {//�跽���
				qyLedgerGeneral.setDebitBalance(NumberTools.round(Ld.getDebitAmt()-Ld.getCreditAmt(),AccountConstants.MONEY_PRECISION));
				qyLedgerGeneral.setCreditBalance(0);
			}else if(Ld.getLoanWay().equalsIgnoreCase("C")){//�������
				qyLedgerGeneral.setDebitBalance(0);
				qyLedgerGeneral.setCreditBalance(NumberTools.round(Ld.getCreditAmt()-Ld.getDebitAmt(),AccountConstants.MONEY_PRECISION));
			}else{
				qyLedgerGeneral.setDebitBalance(Ld.getDebitAmt());
				qyLedgerGeneral.setCreditBalance(Ld.getCreditAmt());
			}			
			qyLedgerGeneral.UpdateQYLedgerGeneral();
		}
	}
	

	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,String stringValue){
		AttributeField attributeField = new AttributeField(fieldName,stringValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,double doubleValue){
		AttributeField attributeField = new AttributeField(fieldName,doubleValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,int intValue){
		AttributeField attributeField = new AttributeField(fieldName,intValue);
		attributeField.setFieldStatus(true);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,String stringValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,stringValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,double doubleValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,doubleValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static HashMap<String,AttributeField> SetInputPara(HashMap<String,AttributeField> inputPara,String fieldName,int intValue,boolean fieldStatus){
		AttributeField attributeField = new AttributeField(fieldName,intValue);
		attributeField.setFieldStatus(fieldStatus);
		inputPara.put(fieldName.toUpperCase(), attributeField);		
		return inputPara;
	}
	
	public static double getDoubleInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return 0;
		else return inputPara.get(fieldName.toUpperCase()).getFieldDoubleValue();
	}
	
	public static String getStringInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return "";
		else return inputPara.get(fieldName.toUpperCase()).getFieldStringValue();
	}
	 
	public static int getIntInputPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return 0;
		else return inputPara.get(fieldName.toUpperCase()).getFieldIntegerValue();
	}
	
	public static boolean getSubjectPara(HashMap<String,AttributeField> inputPara,String fieldName){
		if(inputPara.get(fieldName.toUpperCase())==null) return true;
		else return inputPara.get(fieldName.toUpperCase()).isFieldStatus();
	}
}
