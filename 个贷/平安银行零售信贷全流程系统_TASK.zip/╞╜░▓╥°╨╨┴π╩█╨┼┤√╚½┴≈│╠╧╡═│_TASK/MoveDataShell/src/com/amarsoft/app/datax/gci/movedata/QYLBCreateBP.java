package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYLBCreateBP extends CommonExecuteUnit {

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("============��ʼ����QYBP���ݣ�===============");
				deleteData();
				CreateBC1();
				logger.info("============����QYBP������ɣ�===============");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	
	public void deleteData() throws SQLException{
		String deleteSql="delete from qy_business_putout ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(deleteSql);
		selectSql.execute();
		connection.commit();
	}

	public void CreateBC1() throws SQLException{
		  CallableStatement   cs =connection.prepareCall("call CREATE_QY_BP_106PR()");    
		  //ִ�д洢����   
		  cs.execute();      
		  cs.close();   
	}
}
