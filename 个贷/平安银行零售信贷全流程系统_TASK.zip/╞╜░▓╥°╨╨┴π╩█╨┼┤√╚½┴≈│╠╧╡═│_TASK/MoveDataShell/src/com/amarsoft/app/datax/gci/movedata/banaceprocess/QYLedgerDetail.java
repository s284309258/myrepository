package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.amarsoft.account.exception.LoanException;

public class QYLedgerDetail {
	private String SerialNo; 		//��ˮ��
	private String PutOutNo; 		//��ݱ��
	private String BillNo;			//���ݱ��
	private String TransID; 		//���ױ��
	private String SortID;			//�������
	private String OccurTime;		//����ʱ��
	private String OccurDate;		//��������
	private String Currency;		//����
	private String SubjectNo;		//��Ŀ��
	private double CreditAmt=0; 	//����������������
	private double DebitAmt=0; 		//�跽���գ�������
	private String HandStatus;		//
	private String OrgID;			//��֯����
	private String AccountNo;
	private String LoanWay;			//����
	
	private String subjectname;//������Ŀ����

	private String SqlInsertQYLedgerDetail;
	private String sqlUpdateQYLedgerDetail;
	private PreparedStatement psInsertQYLedgerDetail = null;
	private PreparedStatement psUpdateQYLedgerDetail = null;
	
	public void OpenUpdateQYLedgerDetail(Connection Conn) throws Exception,LoanException{
		sqlUpdateQYLedgerDetail = "Update QY_Ledger_Detail set HandStatus = ? WHERE BillNo = ?";	
		psUpdateQYLedgerDetail = Conn.prepareStatement(sqlUpdateQYLedgerDetail);
	}
	
	public void UpdateQYLedgerDetail() throws Exception,LoanException{
		psUpdateQYLedgerDetail.setString(1, this.HandStatus);
		psUpdateQYLedgerDetail.setString(2, this.BillNo);		
		psUpdateQYLedgerDetail.addBatch();
	}
	
	public void OpenInsertQYLedgerDetail(Connection Conn) throws Exception{
		SqlInsertQYLedgerDetail = " Insert Into QY_Ledger_Detail(SerialNo,PutOutNo,BillNo,TransID,SortID,OccurTime,"+
			" OccurDate,Currency,SubjectNo,CreditAmt,DebitAmt,HandStatus,OrgID) "+
			" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,? )";
		psInsertQYLedgerDetail = Conn.prepareStatement(SqlInsertQYLedgerDetail);
	}
	
	public void InsertQYLedgerDetail() throws Exception{
		psInsertQYLedgerDetail.setString(1, this.SerialNo);
		psInsertQYLedgerDetail.setString(2, this.PutOutNo);
		psInsertQYLedgerDetail.setString(3, this.BillNo);		
		psInsertQYLedgerDetail.setString(4, this.TransID);
		psInsertQYLedgerDetail.setString(5, this.SortID);
		psInsertQYLedgerDetail.setString(6, this.OccurTime);
		psInsertQYLedgerDetail.setString(7, this.OccurDate);
		psInsertQYLedgerDetail.setString(8, this.Currency);
		psInsertQYLedgerDetail.setString(9, this.SubjectNo);
		psInsertQYLedgerDetail.setDouble(10, this.CreditAmt);
		psInsertQYLedgerDetail.setDouble(11, this.DebitAmt);
		psInsertQYLedgerDetail.setString(12, this.HandStatus);
		psInsertQYLedgerDetail.setString(13, this.OrgID);

		psInsertQYLedgerDetail.addBatch();
	}
	
	public void executeBatch() throws Exception,LoanException{
		if (psUpdateQYLedgerDetail!=null) psUpdateQYLedgerDetail.executeBatch();
		if (psInsertQYLedgerDetail!=null) psInsertQYLedgerDetail.executeBatch();
	}
	
	public void close() throws Exception,LoanException{
		if(psUpdateQYLedgerDetail!=null) psUpdateQYLedgerDetail.close();
		if(psInsertQYLedgerDetail!=null) psInsertQYLedgerDetail.close();
	}

	public String getBillNo() {
		return BillNo;
	}

	public void setBillNo(String billNo) {
		BillNo = billNo;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	public String getHandStatus() {
		return HandStatus;
	}

	public void setHandStatus(String handStatus) {
		HandStatus = handStatus;
	}

	public double getCreditAmt() {
		return CreditAmt;
	}

	public void setCreditAmt(double creditAmt) {
		CreditAmt = creditAmt;
	}

	public double getDebitAmt() {
		return DebitAmt;
	}

	public void setDebitAmt(double debitAmt) {
		DebitAmt = debitAmt;
	}

	public String getOccurDate() {
		return OccurDate;
	}

	public void setOccurDate(String occurDate) {
		OccurDate = occurDate;
	}

	public String getOccurTime() {
		return OccurTime;
	}

	public void setOccurTime(String occurTime) {
		OccurTime = occurTime;
	}

	public String getOrgID() {
		return OrgID;
	}

	public void setOrgID(String orgID) {
		OrgID = orgID;
	}

	public String getPutOutNo() {
		return PutOutNo;
	}

	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}

	public String getSortID() {
		return SortID;
	}

	public void setSortID(String sortID) {
		SortID = sortID;
	}

	public String getSubjectNo() {
		return SubjectNo;
	}

	public void setSubjectNo(String subjectNo) {
		SubjectNo = subjectNo;
	}

	public String getTransID() {
		return TransID;
	}

	public void setTransID(String transID) {
		TransID = transID;
	}

	public String getSerialNo() {
		return SerialNo;
	}

	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}

	public String getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}

	public String getLoanWay() {
		return LoanWay;
	}

	public void setLoanWay(String loanWay) {
		LoanWay = loanWay;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}
}
