package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCFreezeAcct extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���±�֤���б���ʺ����ݣ�.............");
				CreateData();
				logger.info("................���±�֤���б���ʺ�������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0;
		String al=" select lq.ls_project_seq,lq.guar_ac_no,lg.fcrmacaccno,lg.fcraccnodes " +
				" from ics_hold_gm_catd lg, qy_ls_proj_guar lq " +
				" where lg.icsmacaccno = lq.guar_ac_no " +
				" and lg.icsdaaccno = lq.guar_ac_branch_no " +
				" and lg.icsaccnodes = lq.guar_ac_des ";
		String insertSql="update qy_ls_proj_guar lq set lq.fcr_mac_no = ? , lq.fcr_ac_des = ? where lq.ls_project_seq = ? and lq.guar_ac_no = ?";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("fcrmacaccno"));
			inps.setString(2, rs.getString("fcraccnodes"));
			inps.setString(3, rs.getString("ls_project_seq"));
			inps.setString(4, rs.getString("guar_ac_no"));
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		ps.close();
		inps.close();
		rs.close();
	}
	
	
	
}
