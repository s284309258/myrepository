package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFeeLGData1 extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��������̯������LG�������ݣ�.............");
				CreateLGData1();
				CreateLGData2();
				logger.info("................�����������LG����������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateLGData1() throws SQLException{
		String al=" insert into qy_ledger_general(PUTOUTNO,SUBJECTNO,ORGID,CURRENCY,CREDITBALANCE,DEBITBALANCE,ACCOUNTNO,SERIALNO,DIRECTION,SUBJECTNAME) " 
				+ " select 'QYF'||f.serialno  as putoutno,qr.subjectno as subjectn,(select oi.orgid from org_info oi where oi.mainframeorgid=f.orgid) as orgid,f.currency,nvl(f.amount,0)-nvl(f.finishamt,0)  as creditbalance, 0.0 as debitbalance, "
		        +" qr.teamflag as accountno ,'QYF'||f.serialno||qr.subjectno as serialno,qr.direction,qr.digest as subjectname from qy_acct_fee_detail f,QY_FEE_SDB_PAB_SUBJECT q,qy_loan_subject_rule qr   "
		        +" where f.csubjectno=q.sdbsubject and qr.subjectno=q.pabsubject    "
		        +" and f.feetype in ('210','220')               "
		        +" union "
		        +" select 'QYF'||f.serialno as putoutno,'4031503' as subjectno,(select oi.orgid from org_info oi where oi.mainframeorgid=f.orgid) as orgid,f.currency, 0.0  as creditbalance,  nvl(f.amount,0)-nvl(f.finishamt,0) as debitbalance,'404' as accountno,   "
		        +" 'QYF'||f.serialno||'4031503' as serialno, 'C' as direction,'�����Ŵ�-ICSϵͳ������' as subjectname from qy_acct_fee_detail f,QY_FEE_SDB_PAB_SUBJECT q,qy_loan_subject_rule qr            "
		        +" where f.csubjectno=q.sdbsubject and qr.subjectno=q.pabsubject    "
		        +" and f.feetype in ('210','220')          ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
		
	
	public void CreateLGData2() throws SQLException{
		String al="insert into qy_ledger_general(PUTOUTNO,SUBJECTNO,ORGID,CURRENCY,CREDITBALANCE,DEBITBALANCE,ACCOUNTNO,SERIALNO,DIRECTION,SUBJECTNAME) "
				+"select 'QYF'||lb.serialno  as putoutno,qr.subjectno,lb.orgid,lb.currency,0.0 as creditbalance,0.0 as debitbalance,   "
				+"qr.teamflag as accountno,'QYFRT'||lb.serialno||qr.subjectno as serialno,qr.direction,qr.digest "
				+"from qy_loan_subject_rule qr,"
				+"       (select f.serialno,   "
				+" qc.putoutno,  "
				+" qc.loan_typ as businesstype,      "
				+" qc.businesssubtype,   "
				+" case when qc.loanterm=0 then 1      "
				+" else nvl(qc.loanterm,1)     "
				+" end  as loanterm,     "
				+" qc.loanstatus,"
				+" oi.orgid,     "
				+" qc.currency,  "
				+" case  "
				+"   when qc.customertype = '05' then  "
				+"    '010'      "
				+"   else"
				+"    '020'      "
				+" end as customertype,  "
				+" qc.bankflag   "
				+"  from qy_loan_balance qc, org_info oi,qy_acct_fee_detail f      "
				+" where qc.orgid = oi.mainframeorgid"
				+"   and  qc.putoutno = f.objectno   "
				+"    and f.feetype in ('210', '220')"
				+"  ) lb "
				+"   where ((qr.businesstype like '%' || lb.businesstype || '%') or"
				+"       (qr.businesstype = 'all'))    "
				+" and ((qr.businesssubtype like '%' || lb.businesssubtype || '%') or      "
				+"       (qr.businesssubtype = 'all')) "
				+"   and lb.loanterm > qr.minloanterm  "
				+"   and lb.loanterm <= qr.maxloanterm "
				+"   and (qr.customertype = lb.customertype or qr.customertype = 'all')    "
				+"   and qr.teamflag='501'     "
				+"   and qr.status = '1'     ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	
}
