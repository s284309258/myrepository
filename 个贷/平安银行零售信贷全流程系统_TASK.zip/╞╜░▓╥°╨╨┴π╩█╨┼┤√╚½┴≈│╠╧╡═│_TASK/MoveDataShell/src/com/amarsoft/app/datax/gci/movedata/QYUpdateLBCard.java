package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateLBCard extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ���µ�һ�����ʺţ�.............");
				CreateData1();
				logger.info("................���µ�һ�����ʺ���ɣ�..............");

				logger.info("................��ʼ���µڶ������ʺţ�.............");
				CreateData2();
				logger.info("................���µڶ������ʺ���ɣ�..............");

				logger.info("................��ʼ���µ��������ʺţ�.............");
				CreateData3();
				logger.info("................���µ��������ʺ���ɣ�..............");

				logger.info("................��ʼ���´�ִ��ʺţ�.............");
				updateFRData();
				logger.info("................���´�ִ��ʺ���ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateData1() throws SQLException {
		CallableStatement cs = connection
				.prepareCall("call QY_UPDATELBCARD_106PR_1()");
		// ִ�д洢����
		cs.execute();
		cs.close();
	}

	public void CreateData2() throws SQLException {
		CallableStatement cs = connection
				.prepareCall("call QY_UPDATELBCARD_106PR_2()");
		// ִ�д洢����
		cs.execute();
		cs.close();
	}

	public void CreateData3() throws SQLException {
		CallableStatement cs = connection
				.prepareCall("call QY_UPDATELBCARD_106PR_3()");
		// ִ�д洢����
		cs.execute();
		cs.close();
	}

	public void updateFRData() throws SQLException {
		String al = "select fr.finacingaccno ,  case "
				+ "     when am.acctno = '' or am.acctno is null then "
				+ "      fr.finacingaccno     else      am.acctno "
				+ "    end as cardno,   fr.begindate "
				+ "    from qy_finacing_account fr, acctno_macno am "
				+ "   where fr.finacingaccno = am.macno(+) ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		String update="update finacing_account fr set fr.finacingacccard=? where fr.finacingaccno=? and fr.begindate=? ";
		PreparedStatement ups=connection.prepareStatement(update);
		int i=0,j=0;
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("cardno"));
			ups.setString(2, rs.getString("finacingaccno"));
			ups.setString(3, rs.getString("begindate"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"����¼.............");
			}
		}
		rs.close();
		ups.executeBatch();
		connection.commit();
	}

}
