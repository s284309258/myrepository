package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCLINFO extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ������Ŀҵ�����ݣ�.............");
				CreatCLINFO();
				CreatCLINFO1();
				logger.info("................������Ŀҵ��������ɣ�..............");
				
				logger.info("................��ʼ������Ŀ����ͻ�1���ݣ�.............");
				CreateCLCustomer1();
				logger.info("................������Ŀ����ͻ�������ɣ�..............");
				
				logger.info("................��ʼ������Ŀ����ͻ�2���ݣ�.............");
				CreateCLCustomer2();
				logger.info("................������Ŀ����ͻ�������ɣ�..............");
			
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	/**
	 * ������Ŀ����
	 * @throws SQLException
	 */
	public void CreatCLINFO() throws SQLException{
		String al="insert into qy_cl_info ql "
				+"   (ql.LINEID,     " 
				+"    ql.CLTYPEID,   " 
				+"    ql.CLTYPENAME, " 
				+"    ql.CUSTOMERID, " 
				+"    ql.CUSTOMERNAME, " 
				+"    ql.LINESUM1,   " 
				+"    ql.LINESUM2,   " 
				+"    ql.LINESUM3,   " 
				+"    ql.CURRENCY,   " 
				+"    ql.LINEEFFDATE," 
				+"    ql.LINEEFFFLAG," 
				+"    ql.CYCLEFLAG,  " 
				+"    ql.FREEZEFLAG, " 
				+"    ql.INPUTUSER,  " 
				+"    ql.INPUTORG,   " 
				+"    ql.UPDATETIME, " 
				+"    ql.BEGINDATE,  " 
				+"    ql.ENDDATE,    " 
				+"    ql.BAILRATIO,  " 
				+"    ql.USEDSUM,    " 
				+"    ql.USABLESUM,  " 
				+"    ql.TERMMONTH,  " 
				+"    ql.BUSINESSPROP, " 
				+"    ql.BAILACCOUNT," 
				+"    ql.FOOTACCOUNT,"
				+"    ql.belong_org) "
				+"select 'QY' || LS_PROJECT_SEQ,"
				+"   PROJ_COLL_TYPE,  "
				+"(select cl.itemname from code_library cl where cl.codeno='LSPROJECT' and cl.itemno=PROJ_COLL_TYPE), "
				+"   'QYCL' || LS_PROJECT_SEQ, "
				+"   PROJ_PROJECT_PRI_DESC,    "
				+"   PROJ_EST_COMMITMENT,      "
				+"   PROJ_EST_COMMITMENT,      "
				+"   PROJ_EST_COMMITMENT,      "
				+"   PROJ_CCY_CODE,     "
				+"substr(to_char(PROJ_START_DATE),0,4)||'/'||substr(to_char(PROJ_START_DATE),6,2)||'/'||substr(to_char(PROJ_START_DATE),9,2),  " 
				+"   case when PROJ_STATUS='COMP'"
				+"     then '1' else      "
				+"'0'"
				+"end,      "
				+"   case when PROJ_AMT_ALLOW_CYC='Y' then "
				+"     '1' else		"
				+"     '2' "
				+"     end ,      " 
				+"   case when PROJ_STATUS='COMP'   "
				+"     then '1' else "
				+"      '0'   "
				+"      end , "
				+"   PROJ_LEND_OFFICER,     "   
				+"   PROJ_GUAR_AC_BANK_BCH, "
				+"substr(to_char(LAST_UPD_DT),0,4)||'/'||substr(to_char(LAST_UPD_DT),6,2)||'/'||substr(to_char(LAST_UPD_DT),9,2),      "
				+"substr(to_char(PROJ_START_DATE),0,4)||'/'||substr(to_char(PROJ_START_DATE),6,2)||'/'||substr(to_char(PROJ_START_DATE),9,2), "
				+"substr(to_char(PROJ_EXP_DATE),0,4)||'/'||substr(to_char(PROJ_EXP_DATE),6,2)||'/'||substr(to_char(PROJ_EXP_DATE),9,2),"   
				+"   PROJ_GUARANTEE_RATIO,"
				+"   PROJ_TOTAL_APPR_AMT, "
				+"   PROJ_EARMARK_AMT - PROJ_TOTAL_APPR_LOAN,  " 
				+"   to_char(PROJ_MAX_TNR),      "
				+"   0.0,   "
				+"   PROJ_GUAR_AC_NO,     "
				+"   PROJ_CREDIT_BANK_AC, "
				+"(select oi.orgid from org_info oi where oi.mainframeorgid=PROJ_REGR_BCH)    "
				+"     from qy_LS_PROJECT      ";

		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	public void CreatCLINFO1() throws SQLException {
			String al=" update qy_cl_info cl set cl.linecontractno=cl.lineid where  cl.parentlineid is null ";
			PreparedStatement ps=connection.prepareStatement(al);
			ps.execute();
			connection.commit();
	}
	
	/**
	 * ���ɿͻ���������
	 * @throws SQLException
	 */
	public void CreateCLCustomer1() throws SQLException {
		String al="insert into qy_customer_info(customerid,customername,customertype,CERTID,remark,status,corptype,SDB_ID_TYPE,SDB_ISS_CTRY,SOURCE_ID) "
        +" select  'QYCL' || LS_PROJECT_SEQ,PROJ_PROJECT_PRI_DESC,'05',LS_PROJECT_SEQ,PROJ_PROJECT_PRI_DESC,'1','199','01','CHN', 'QYCL' || LS_PROJECT_SEQ   from qy_LS_PROJECT ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	/**
	 * ���ɿͻ���ҵ�ͻ���Ϣ
	 * @throws SQLException
	 */
	public void CreateCLCustomer2() throws SQLException{
		String al="insert into qy_ent_info(customerid,enterprisename) "
				+" select  'QYCL'||LS_PROJECT_SEQ,PROJ_PROJECT_PRI_DESC from qy_LS_PROJECT ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
}
