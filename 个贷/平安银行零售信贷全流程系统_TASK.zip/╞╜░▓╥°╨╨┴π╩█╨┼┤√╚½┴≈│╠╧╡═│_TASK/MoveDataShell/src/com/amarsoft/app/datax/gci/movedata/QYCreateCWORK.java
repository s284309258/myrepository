package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCWORK extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateData();
				logger.info("................����ҵ��������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
//	public void CreateData() throws SQLException{
//		CallableStatement   cs =connection.prepareCall("call QY_CWORK_106PR()");    
//		  //ִ�д洢����   
//		  cs.execute();      
//		  cs.close();   
//	}
	
	public void CreateData() throws SQLException{
		String al="           insert into qy_customer_work  "+
               " (SERIALNO,OBJECTNO,OBJECTTYPE,CUSTOMERID, "+
                "    EMPLOYEETYPE,DEPARTMENT,SPECIALQUALIFICATIONTYPE,INDUSTRYAGE, "+
                "     UNITKIND,WORKCORP,WORKADD,WORKTEL,OCCUPATION,WORKZIP,HEADSHIP, "+
                "      WORKBEGINDATE,WORKNATURE,WAGEOFFFLAG,POSIONLEVEL,CORPZONE, "+
                "       CORPAREA,CORPEXTENSION, ALLWORKYEAR) "+
                "        select 'QY20121030'||SEQ_CLEAN.NEXTVAL as SERIALNO, bc.serialno as OBJECTNO,'SWContractApply' as OBJECTTYPE,  "+
                "        ii.CUSTOMERID,ii.EMPLOYEETYPE, "+
              "   ii.DEPARTMENT,ii.SPECIALQUALIFICATIONTYPE,ii.INDUSTRYAGE,ii.UNITKIND,ii.WORKCORP, "+
              "   ii.WORKADD,ii.WORKTEL,ii.OCCUPATION,ii.WORKZIP, ii.HEADSHIP,ii.WORKBEGINDATE,ii.WORKNATURE, "+
              "   ii.WAGEOFFFLAG,ii.POSIONLEVEL,ii.CORPZONE,ii.CORPAREA,ii.CORPEXTENSION,ii.ALLWORKYEAR from qy_ind_info ii,qy_business_contract bc  "+
              "   where bc.customerid=ii.customerid and bc.businesstype like '2%' AND bc.businesskind='SWPM' ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
		
	}
	
}
