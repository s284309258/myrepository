package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateBPData extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����BP���ݣ�.............");
				UpdateData();
				logger.info("................����BP������ɣ�..............");

				logger.info("................��ʼ����BC�ܻ��������ݣ�.............");
				UpdateBCData();
				logger.info("................����BC�ܻ�����������ɣ�..............");

				logger.info("................��ʼ���·����������ݣ�.............");
				UpdateAccFareData();
				logger.info("................���·�������������ɣ�..............");
				
				logger.info("................����С��������ȡ��ʽ���ݣ�.............");
				UpdateBCPayType();
				logger.info("................����С��������ȡ��ʽ��ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void UpdateData() throws Exception {
		int i = 0, j = 0;
		String al = " select lb.contractserialno,lb.putoutno,lb.orgid from loan_balance lb where lb.putoutno like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		String updateSql = "update business_putout  set contractserialno=?,operateorgid=?,INPUTORGID=?,PUTOUTSTATUS='1' where serialno=? ";
		PreparedStatement ups = connection.prepareStatement(updateSql);

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			i++;
			j++;
			ups.setString(1, rs.getString("contractserialno"));
			ups.setString(2, rs.getString("orgid"));
			ups.setString(3, rs.getString("orgid"));
			ups.setString(4, rs.getString("putoutno"));
			ups.addBatch();
			if (i > 1000) {
				ups.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".............����" + j + "������.............");
			}
		}
		ups.executeBatch();
		connection.commit();
		rs.close();
	}

	public void UpdateBCData() throws Exception {
		int i = 0, j = 0;
		String al = " select bc.manageorgid, lb.orgid, bc.serialno "
				+ "  from business_contract bc, loan_balance lb "
				+ "  where bc.serialno = lb.contractserialno "
				+ "  and lb.putoutno like 'QY%' "
				+ "   and bc.manageorgid is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		String updateSql = "update business_contract bc  set bc.manageorgid =? where bc.serialno = ? ";
		PreparedStatement ups = connection.prepareStatement(updateSql);

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			i++;
			j++;
			ups.setString(1, rs.getString("orgid"));
			ups.setString(2, rs.getString("serialno"));
			ups.addBatch();
			if (i >= 1000) {
				ups.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".............����" + j + "������.............");
			}
		}
		rs.close();
		ups.executeBatch();
		connection.commit();
		logger.info(".............����" + j + "������.............");
	}

	// ���·�������
	public void UpdateAccFareData() throws Exception {
		String al = "update acct_fee_detail bf  set bf.occurdate=bf.begindate where bf.occurdate is null and bf.serialno like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	//����С��������ȡ��ʽ
	public void UpdateBCPayType()  throws Exception {
		String al = "update (select bc.serialno, bc.paytype "
				+ "  from qy_loan_balance lb, business_contract bc "
				+ "   where lb.paytype = 'Q02' "
				+ "     and bc.serialno = lb.putoutno) dd "
				+ "    set dd.paytype = 'Q02' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
