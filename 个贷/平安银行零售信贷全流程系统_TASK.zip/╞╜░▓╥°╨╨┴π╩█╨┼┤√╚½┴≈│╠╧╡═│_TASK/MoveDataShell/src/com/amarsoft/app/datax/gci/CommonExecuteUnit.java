package com.amarsoft.app.datax.gci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.are.ARE;
import com.amarsoft.are.log.Log;
import com.amarsoft.task.ExecuteUnit;
import com.amarsoft.task.TaskConstants;

public abstract class CommonExecuteUnit extends ExecuteUnit {
	protected final String PROPERTY_DATABASE = "ploan";
	protected Connection connection;
	protected Log logger;
	protected String deductDate = null;
	protected String nextMonth;
	protected String lastMonth;
	protected String currentMonth;
	protected String nextDate;
	protected String nextYear;
	protected int unitStatus=TaskConstants.ES_FAILED;
	protected String lastDate;
	protected String currentYear;
	protected String lastYear;

	// ��ʼ��
	protected String init() throws Exception {
		
		// ��־
		logger = ARE.getLog();
		
		DBConnection dc = new DBConnection();
		connection =dc.getConn("Loan");
		//connection = ARE.getDBConnection(PROPERTY_DATABASE);
		Statement stmt=connection.createStatement();
		
		ResultSet rs = stmt.executeQuery("select curdeductdate from ploan_setup");
		if (rs.next()) {
			deductDate = rs.getString(1);
		}
		rs.close();
		stmt.close();

		nextMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,1).substring(0,7);
		lastMonth=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_MONTH,-1).substring(0,7);
		currentMonth=deductDate.substring(0,7);
		currentYear = deductDate.substring(0,4);
		lastYear = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,-1).substring(0,4);
		nextDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
		lastDate=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,-1);;
		nextYear=com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,1).substring(0,4);
		
		String delSql = "delete from BATCHTASK_STATUS where InputDate='"+deductDate+"' and TARGETNAME='"+getTarget().getName()+"' "+
			" and TASKNAME='"+getName()+"'   and (Status is null or Status<>'1')";
		PreparedStatement psDelSql = connection.prepareStatement(delSql);
		psDelSql.execute();
		psDelSql.close();
		logger.info("TARGETNAMe="+getTarget().getName());
		logger.info("TASKNAME="+getName());
		Statement selectPS=connection.createStatement();
		String sSql = "select count(*) from BATCHTASK_STATUS where (InputDate='"+deductDate+"' or InputDate='"+lastDate+"') and TARGETNAME='"+getTarget().getName()+"' "+
		" and TASKNAME='"+getName()+"'   and Status='1' and DateFlag = '0' ";
		logger.info(sSql);
		ResultSet rs1=selectPS.executeQuery(sSql);
		if(rs1.next()){
			if(rs1.getInt(1)>0) {
				unitStatus=TaskConstants.ES_SUCCESSFUL;
				logger.warn("��ִ�У�������");
				rs1.close();
				selectPS.close();
				clearResource();
				return "skip";
			}
		}
		rs1.close();
		selectPS.close();
		
		String sql = "insert into BATCHTASK_STATUS (TARGETNAME,INPUTDATE,TASKNAME,TARGETDESCRIBE,TASKDESCRIBE,BEGINTIME,DATEFLAG)"+
		" values('"+getTarget().getName()+"','"+deductDate+"','"+getName()+"','"+getTarget().getDescribe()+"','"+getDescribe()+"',to_char(sysdate,'YYYY-MON-DD  HH24:MI:SS'),'0')";
		logger.info(sql);
		PreparedStatement psInsertSql = connection.prepareStatement(sql);
		psInsertSql.execute();
		psInsertSql.close();
		SystemConfig.loadSystemConfig(true,connection);
		return "exexute";
	}

	// �������ͷ����й����д򿪵���Դ�����ݿ����ӡ��ļ����ӵ�
	protected void clearResource() {
		// �ر����ݿ�����
		if (connection != null) {
			try {
				PreparedStatement psInsertSql = connection.prepareStatement("update BATCHTASK_STATUS set Status='"+unitStatus+"',EndTime=to_char(sysdate,'YYYY-MON-DD  HH24:MI:SS') "+
						" where  TARGETNAME='"+getTarget().getName()+"' and   INPUTDATE='"+deductDate+"'  and  TASKNAME='"+getName()+"'   " );
				psInsertSql.execute();
				psInsertSql.close();
				connection.close();
			} catch (SQLException e) {
				logger.warn(e);
			}
			connection = null;
		}
	}

}
