package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateGRelative extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����icsѺƷ������ϵ���ݣ�.............");
				CreateCI();
				logger.info("................����icsѺƷ������ϵ������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = "insert into guaranty_relative (OBJECTTYPE, OBJECTNO, CONTRACTNO, GUARANTYID, CHANNEL, STATUS) "
				+ " select distinct 'CBContractApply', 'QYICS00' || substr(lg.lb_putout_no, 8, length(lg.lb_putout_no)),  "
				+ " 'QYICS00' || substr(lg.lb_putout_no, 8, length(lg.lb_putout_no)), "
				+ " replace(lg.gi_guarantyid, 'QY', 'QYICS'),'NEW','1'      "
				+ " from qy_guar_loan_cr_ics lg, qy_guaranty_info_ics gi "
				+ "  where lg.qytype = 'LN' and lg.gi_guarantyid=gi.guarantyid00";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
