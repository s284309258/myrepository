package com.amarsoft.app.datax.gci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.amarsoft.account.sysconfig.OrgInfoConfig;
import com.amarsoft.account.util.AccountConstants;

public class LoanAccount {

	private String sPutOutNo;
	//һ�㻹��ۿ�����
	private ArrayList<DeductData> deductdataList = new ArrayList<DeductData>();
	//��ǰ����ۿ�����
	private ArrayList<AheadDeductData> aheadDeductdataList = new ArrayList<AheadDeductData>();
	//δ����������
	private ArrayList<FareDetaill> fareDetailList = new ArrayList<FareDetaill>();
	//����˻�Map
	private HashMap<String,DeductAccountInfo> accountInfoMap = new HashMap<String,DeductAccountInfo>();
	//modify 2011=05-23��dxu �º��������ļ���Ҫ�������
	//�������
	private String orgID = "";
		
	public String getSPutOutNo() {
		return sPutOutNo;
	}
	public void setSPutOutNo(String putOutNo) {
		sPutOutNo = putOutNo;
	}
	public ArrayList<DeductData> getDeductdataList() {
		return deductdataList;
	}
	public void setDeductdataList(ArrayList<DeductData> deductdataList) {
		this.deductdataList = deductdataList;
	}
	public ArrayList<AheadDeductData> getAheadDeductdataList() {
		return aheadDeductdataList;
	}
	public void setAheadDeductdataList(
			ArrayList<AheadDeductData> aheadDeductdataList) {
		this.aheadDeductdataList = aheadDeductdataList;
	}
	public ArrayList<FareDetaill> getFareDetailList() {
		return fareDetailList;
	}
	public void setFareDetailList(ArrayList<FareDetaill> fareDetailList) {
		this.fareDetailList = fareDetailList;
	}
	public HashMap<String, DeductAccountInfo> getAccountInfoMap() {
		return accountInfoMap;
	}
	public void setAccountInfoMap(HashMap<String, DeductAccountInfo> accountInfoMap) {
		this.accountInfoMap = accountInfoMap;
	}
	public String getOrgID() {
		return orgID;
	}
	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}
	
	
	
	
}
