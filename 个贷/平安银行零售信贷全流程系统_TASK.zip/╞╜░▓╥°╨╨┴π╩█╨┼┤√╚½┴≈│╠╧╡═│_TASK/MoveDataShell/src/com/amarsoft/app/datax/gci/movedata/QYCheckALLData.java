package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCheckALLData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				deleteData();
				
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ���������������ݣ�.............");
				checkALLData();
				CheckResulet();
				logger.info("................������������������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	
	public void deleteData() throws SQLException{
		String al=" delete from QY_CHECK_LOAN ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	
	public void checkALLData() throws SQLException{
		String al="insert into QY_CHECK_LOAN "
				+"  (select dd.orgid, "
				+"   dd.T as incount, "
				+"   ql.ln_no outcount, "
				+"   dd.allsum, "
				+"   ql.ln_prcp, "
				+"   dd.allsum - ql.ln_prcp differencesum, "
				+"   dd.bansum intbansum, "
				+"   ql.os_prcp, "
				+"   dd.bansum - ql.os_prcp differenceos "
				+"   from (select count(1) as T, "
				+"              sum(lb.businesssum) allsum, "
				+"              sum(lb.normalbalance + lb.overduebalance) bansum, "
				+"              lb.orgid "
				+"         from qy_loan_balance lb "
				+"        group by lb.orgid) dd, "
				+"      QY_CHK_SUB_LOAN ql "
				+"   where dd.orgid = ql.BCH_CDE "
				+"    and (dd.T <> ql.ln_no or dd.allsum <> ql.ln_prcp or "
				+"        dd.bansum <> ql.os_prcp)) ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void CheckResulet() throws Exception{
		int i=0;
		String al=" select count(1) as T from QY_CHECK_LOAN ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs =ps.executeQuery();
		while(rs.next()){
			i=rs.getInt("T");
		}
		rs.close();
		if(i>0){
			logger.info("���������˶Բ�ƽ�����QY_CHECK_LOAN����");
		}
	}
}
