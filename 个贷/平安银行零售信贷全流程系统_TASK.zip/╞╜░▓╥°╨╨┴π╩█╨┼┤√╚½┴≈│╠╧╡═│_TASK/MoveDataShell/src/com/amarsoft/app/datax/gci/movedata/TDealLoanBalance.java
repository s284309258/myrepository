package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.entity.LoanBackStatus;
import com.amarsoft.account.Deal.*;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.LedgerGeneral;
import com.amarsoft.account.repay.jbo.IRepayScheduleEngine;
import com.amarsoft.account.repay.jbo.RepaymentSchedule;
import com.amarsoft.account.repay.jbo.RepaymentType;
import com.amarsoft.account.sysconfig.RepayTypeConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.CalInterest;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.BatchTransProvider;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class TDealLoanBalance extends CommonExecuteUnit {
	private int commitNum=500;
	private int dealNum=0;
	private int icount=0;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���� Ǩ�ƹ�����T�յĴ������ݣ�.............");
				dealLoanBalance();
				logger.info("................����Ǩ�ƹ�����T�յĴ�������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void dealLoanBalance() throws Exception{
		String TransNo="7001";
		String sDate = DateTools.getStringDate(deductDate);
		int i = 0,j=0;;
		String sSerialno = "";
		//ArrayList<LedgerDetail> LedgerDetailList = new ArrayList<LedgerDetail>();
				
		LoanBackStatus loanBackStatus = new LoanBackStatus();
		LoanBackStatus loanBackStatus1 = new LoanBackStatus();
		LoanBalance loanBalance = new LoanBalance();
		LedgerDetail ledgerDetail = new LedgerDetail();
		//LedgerDetail Ld = new LedgerDetail();
		LedgerGeneral ledgerGeneral = new LedgerGeneral();
		//�򿪸������(1006Ǩ�ƺ���죬ls���е�Ӧ������С�ڵ��ڵ�ǰҵ�����ڵĲż�����Ϣ����������ʵ��ҵ������+1��������С��)
		
		loanBackStatus.OpenUpdateLoanBackStatus(connection);
		loanBackStatus1.OpenInsertLoanBackStatus(connection);
		loanBackStatus1.OpenSelectLoanBackStatus(connection);
		loanBalance.OpenUpdateLoanBalance(connection);
		ledgerDetail.OpenInsertLedgerDetail(connection);
		ledgerGeneral.OpenUpdateLedgerGeneral(connection);
		
		PreparedStatement psSelectLoanBalance = null;
		ResultSet rs = null;
		
		
		String SqlSelectLoanBalance = "SELECT  * FROM Loan_Balance Lb "+
										" WHERE Lb.Loanstatus in ('0','1','4','5') and "+ 
										" Lb.Nextpaydate='"+deductDate+"'";
		psSelectLoanBalance= connection.prepareStatement(SqlSelectLoanBalance);
		rs = psSelectLoanBalance.executeQuery();
		try{
			while(rs.next()){
				loanBalance.setPutOutNo(rs.getString("PutOutNo"));
				loanBalance.setCurrency(rs.getString("Currency")); 
				loanBalance.setBusinessType(rs.getString("BusinessType"));
				loanBalance.setBusinessSubType(rs.getString("BusinessSubType"));
				loanBalance.setCustomerID(rs.getString("CustomerID"));
				loanBalance.setCustomerName(rs.getString("CustomerName"));
				loanBalance.setMainReturnType(rs.getString("MainReturnType"));
				loanBalance.setReturnType(rs.getString("ReturnType"));
				loanBalance.setReturnPeriod(rs.getString("ReturnPeriod"));
				loanBalance.setGainAmount(rs.getDouble("GainAmount"));
				loanBalance.setGracePeriodCode(rs.getString("GracePeriodCode"));
				loanBalance.setGracePeriod(rs.getInt("GracePeriod"));
				loanBalance.setLoanTerm(rs.getInt("LoanTerm"));
				loanBalance.setPutOutDate(rs.getString("PutOutDate"));
				loanBalance.setMaturityDate(rs.getString("MaturityDate"));
				loanBalance.setBeginDate(rs.getString("BeginDate"));
				loanBalance.setMonthEndFlag(rs.getString("MonthEndFlag"));
				loanBalance.setLastInteDate(rs.getString("LastInteDate"));
				loanBalance.setNextPayDate(rs.getString("NextPayDate"));
				loanBalance.setSTerm(rs.getInt("STerm"));
				loanBalance.setCTerm(rs.getInt("CTerm"));
				loanBalance.setSCTerm(rs.getInt("SCTerm"));
				loanBalance.setAheadNum(rs.getInt("AheadNum"));
				loanBalance.setLastTerm(rs.getInt("LastTerm"));
				loanBalance.setGainCyc(rs.getInt("GainCyc"));
				loanBalance.setMonthPay(rs.getDouble("MonthPay"));
				loanBalance.setRateCode(rs.getString("RateCode"));
				loanBalance.setRateMode(rs.getString("RateMode"));
				loanBalance.setRateFloatType(rs.getString("RateFloatType"));
				loanBalance.setBaseDays(rs.getInt("BaseDays"));
				loanBalance.setRateFloat(rs.getDouble("RateFloat"));
				loanBalance.setBaseRate(rs.getDouble("BaseRate"));					
				loanBalance.setPutOutRate(rs.getDouble("PutOutRate"));
				loanBalance.setExecuteRate(rs.getDouble("ExecuteRate"));
				loanBalance.setFineRateMode(rs.getString("FineRateMode"));
				loanBalance.setFineRateFloat(rs.getDouble("FineRateFloat"));
				loanBalance.setFineRateCode(rs.getString("FineRateCode"));
				loanBalance.setFineRateType(rs.getString("FineRateType"));
				loanBalance.setFineRateFloat(rs.getDouble("FineRateFloat"));
				loanBalance.setFineRate(rs.getDouble("FineRate"));
				loanBalance.setBusinessSum(rs.getDouble("BusinessSum"));
				loanBalance.setNormalBalance(rs.getDouble("NormalBalance"));
				loanBalance.setCurrentBalance(rs.getDouble("CurrentBalance"));
				loanBalance.setDefaultBalance(rs.getDouble("DefaultBalance"));
				loanBalance.setOverDueBalance(rs.getDouble("OverDueBalance"));
				loanBalance.setPayInte(rs.getDouble("PayInte"));
				loanBalance.setPayInnerInte(rs.getDouble("PayInnerInte"));
				loanBalance.setPayOutInte(rs.getDouble("PayOutInte"));
				loanBalance.setPayInnerInteFine(rs.getDouble("PayInnerInteFine"));
				loanBalance.setPayOutInteFine(rs.getDouble("PayOutInteFine"));
				loanBalance.setCalcDayInteDate(rs.getString("CalcDayInteDate"));
				loanBalance.setPeriodInteBase(rs.getDouble("PeriodInteBase"));
				loanBalance.setPeriodInte(rs.getDouble("PeriodInte"));
				loanBalance.setInteFineFlag(rs.getString("InteFineFlag"));
				loanBalance.setCorpFineFlag(rs.getString("CorpFineFlag"));
				loanBalance.setFinishDate(rs.getString("FinishDate"));
				loanBalance.setLoanStatus(rs.getString("LoanStatus"));
				loanBalance.setUpDateDate(rs.getString("UpDateDate"));
				loanBalance.setDeDuctAccNo(rs.getString("DeDuctAccNo"));
				loanBalance.setDeDuctAccNo1(rs.getString("DeDuctAccNo1"));
				loanBalance.setDeDuctAccNo2(rs.getString("DeDuctAccNo2"));
				loanBalance.setOrgID(rs.getString("OrgID"));
				loanBalance.setUserID(rs.getString("UserID"));					
				loanBalance.setRateFloatFlag(rs.getString("RateFloatFlag"));
				loanBalance.setHoldBalance(rs.getDouble("HoldBalance"));
				loanBalance.setCalcMaturityDate(rs.getString("CalcMaturityDate"));
				loanBalance.setRateAlterDate(rs.getString("RateAlterDate"));
				loanBalance.setDisDate(rs.getString("DisDate"));
				loanBalance.setLoanAccNo(rs.getString("LoanAccNo"));
				loanBalance.setAccordInteBase(rs.getDouble("AccordInteBase"));
				loanBalance.setInteBase(rs.getDouble("InteBase"));
				loanBalance.setCustomerType(rs.getString("CustomerType"));//�����ͻ�����
				loanBalance.setAnalyspar(DataConvert.toString(rs.getString("Analyspar")));//���ռ�Ȩ����
				loanBalance.initLoanRateAlter(connection);
				
				sSerialno = TransNo+sDate + loanBalance.getPutOutNo()+"T";
				
				HashMap<String,AttributeField> inputPara = new HashMap<String,AttributeField>();			

				inputPara = BatchTransProvider.SetInputPara(inputPara,"PayInnerInte",0);
				inputPara = BatchTransProvider.SetInputPara(inputPara,"PayOutInte",0);				
				inputPara = BatchTransProvider.SetInputPara(inputPara,"PayInnerInteFine",0);
				inputPara = BatchTransProvider.SetInputPara(inputPara,"PayOutInteFine",0);
				
				
				
				//ÿ����Ϣ����
				calcInte(deductDate,loanBalance,loanBackStatus1,inputPara,connection);
				
				//����ί�д���ϸ���ί�д�����˹�������С΢ί�д���ڲ��ⲿ��������
				if(loanBalance.getBusinessType().startsWith("1190") || loanBalance.getBusinessType().startsWith("1200")
					|| loanBalance.getBusinessType().startsWith("2170") || loanBalance.getLoanStatus().equals("4")
					|| loanBalance.getLoanStatus().equals("5"))
				{
					inputPara = BatchTransProvider.SetInputPara(inputPara,"PayInnerInte",0);
					inputPara = BatchTransProvider.SetInputPara(inputPara,"PayOutInte",0);				
					inputPara = BatchTransProvider.SetInputPara(inputPara,"PayInnerInteFine",0);
					inputPara = BatchTransProvider.SetInputPara(inputPara,"PayOutInteFine",0);
					inputPara = BatchTransProvider.SetInputPara(inputPara,"DayInte",0);
				}
				
				//��������				
				loanBalance.UpdateLoanBalance();
				
				//���������жϹ���������
				inputPara = BatchTransProvider.SetInputPara(inputPara,"BusinessType",loanBalance.getBusinessType());
				inputPara = BatchTransProvider.SetInputPara(inputPara,"LoanTerm",loanBalance.getLoanTerm());
				
				inputPara = BatchTransProvider.SetInputPara(inputPara,"TransNo",TransNo,false);//���ύ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"BillNo",sSerialno,false);
				inputPara = BatchTransProvider.SetInputPara(inputPara,"SerialNo",sSerialno,false);//������ˮ��
				//inputPara = SetInputPara(inputPara,"AccDate",sDeductDate);//����������һ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"AccDate",
						deductDate);//����������һ��
				
				inputPara = BatchTransProvider.SetInputPara(inputPara,"PutOutNo",loanBalance.getPutOutNo(),false);			
				inputPara = BatchTransProvider.SetInputPara(inputPara,"Currency",loanBalance.getCurrency(),false);//����
				
				inputPara = BatchTransProvider.SetInputPara(inputPara,"OrgID",loanBalance.getOrgID(),false);			
				inputPara = BatchTransProvider.SetInputPara(inputPara,"DisDate",loanBalance.getDisDate());
				//С΢����γ��
				inputPara = BatchTransProvider.SetInputPara(inputPara,"CustomerType",loanBalance.getCustomerType());
				
				BatchTransProvider batTransP = new BatchTransProvider();
				batTransP.LedgerDeal(ledgerDetail, ledgerGeneral, inputPara, LoanBalance.getAccountSubjectHashMap(rs.getString("PutOutNo"),connection));
																
				i++;
				j++;
				if (i==1){
					i = 0;
					loanBackStatus.executeBatch();
					loanBackStatus1.executeBatch();
					loanBalance.executeBatch();
					ledgerDetail.executeBatch();
					ledgerGeneral.executeBatch();
					connection.commit();
				}
			}		
			loanBackStatus.executeBatch();
			loanBackStatus1.executeBatch();
			loanBalance.executeBatch();
			ledgerDetail.executeBatch();
			ledgerGeneral.executeBatch();
			connection.commit();
			
			loanBackStatus.close();
			loanBackStatus1.close();
			loanBalance.close();
			ledgerDetail.close();
			ledgerGeneral.close();
			if (rs!=null) rs.close();
			if (psSelectLoanBalance!=null) psSelectLoanBalance.close();	
		} catch (Exception e) {
			connection.rollback();
			throw e;
		}
	}
	
	public void calcInte(String sDeductDate,LoanBalance loanBalance,LoanBackStatus loanBackStatus1,
			HashMap<String,AttributeField> inputPara,Connection Conn) throws Exception{			
		double inte = 0;
		double lastInte = 0;		
		//double currentCorp = 0;
		//��Ϣ�ֶ�
		double payInteBase = loanBalance.getInteBase();
		//�������ʵ������Ϊ��Ϣ�յ��죬��LASTINTE=0;
		String sDate = DateTools.getRelativeDate(sDeductDate, AccountConstants.TERM_UNIT_DAY, -1);
		if(sDate.equals(loanBalance.getLastInteDate())){
			lastInte = payInteBase;
		}else{
			lastInte = loanBalance.getPeriodInte();
		}
		loanBalance.setCalcDayInteDate(sDeductDate);
		if(loanBalance.getNormalBalance()>0 && sDeductDate.compareTo(loanBalance.getMaturityDate())<=0){
			if (loanBalance.getReturnType().equals("11")) {//Э��
				double inteBase = NumberTools.round(CalInterest.getBaseInterest(AccountConstants.REPAY_AMOUNT_TYPE_CORPUS,
					loanBalance.getNormalBalance(),1,loanBalance.getRateCode(),loanBalance.getExecuteRate(),
					loanBalance.getBaseDays())*10000,AccountConstants.MONEY_PRECISION);
				inte = NumberTools.round((loanBalance.getAccordInteBase()+inteBase)/10000,AccountConstants.MONEY_PRECISION);
				loanBalance.setAccordInteBase(NumberTools.round(loanBalance.getAccordInteBase()+inteBase,AccountConstants.MONEY_PRECISION));
			}else if(loanBalance.getReturnType().equals("20")){
				inte = NumberTools.round(CalInterest.getInterest(loanBalance, AccountConstants.REPAY_AMOUNT_TYPE_CORPUS,
				loanBalance.getBusinessSum(), sDeductDate),AccountConstants.MONEY_PRECISION);
			}else{
				inte = NumberTools.round(CalInterest.getInterest(loanBalance, AccountConstants.REPAY_AMOUNT_TYPE_CORPUS,
				loanBalance.getNormalBalance(), sDeductDate),AccountConstants.MONEY_PRECISION);
			}
		}
		
		if (loanBalance.getLoanStatus().equals("0")){//Ӧ�ƴ���ż���							
			loanBalance.setPeriodInte(inte+payInteBase);	
		}else{
			loanBalance.setPeriodInte(0);			
		}
		
		double nowInte = loanBalance.getPeriodInte();//��ǰ������Ϣ
		loanBackStatus1.clear();
		if (loanBalance.getNormalBalance()>0 && sDeductDate.equals(loanBalance.getNextPayDate())){//�ۿ������´λ����գ�������Ϣ
			//����״̬��
			//�õ����ڱ��� ���ǵݱ�Ļ��ʽ
			loanBackStatus1.setPutOutNo(loanBalance.getPutOutNo());
			loanBackStatus1.setSTerm(loanBalance.getSTerm());
			loanBackStatus1.setAheadNum(0);
			loanBackStatus1.setPayDate(sDeductDate);
			if(!loanBackStatus1.SelectLoanBackStatus())//���������
			{
				loanBackStatus1.setCurrency(loanBalance.getCurrency());
				loanBackStatus1.setAccDate(sDeductDate);
				loanBackStatus1.setPayOffFlag(AccountConstants.NO);
				//�������ж��Ƿ���������
				loanBackStatus1.setGracePeriod(loanBalance.getGracePeriod());
				loanBackStatus1.setOrgid(loanBalance.getOrgID());
				loanBackStatus1.setFineBaseDate(sDeductDate);
				RepaymentSchedule repaymentSchedule=new RepaymentSchedule();
				
				RepaymentType repaymentType = RepayTypeConfig.getRepaymentType(loanBalance.getReturnType());
				IRepayScheduleEngine repayScheduleEngine=repaymentType.getRepayScheduleEngine();
				repaymentSchedule = repayScheduleEngine.getRepaymentSchedule(loanBalance);
				
				loanBackStatus1.setPayOverdueCorp(repaymentSchedule.getRepayCorpus());
				//Ӧ����Ϣ�����˹�Ϣ�ֶ�
				if("21".equals(loanBalance.getMainReturnType())){//���ռ�Ȩ������⴦��
					 String  sAnalyspar= loanBalance.getAnalyspar();
					 Double dAnalyspar= DataConvert.toDouble(sAnalyspar);//���ռ�Ȩ����
					 Double addsum=(repaymentSchedule.getRepayCorpus()+repaymentSchedule.getRepayInterest())*(dAnalyspar-1);//��۽�
					 addsum=Double.parseDouble(NumberTools.numberFormat(addsum,0 ,2));//��ʽ��
					 loanBackStatus1.setPayInte(repaymentSchedule.getRepayInterest()+payInteBase+addsum);//��۽���Ӧ����Ϣ
					if (loanBalance.getLoanStatus().equals("0")){//Ӧ�ƴ���ż���							
					     loanBalance.setPeriodInte(loanBalance.getPeriodInte()+addsum);//��۽��������Ϣ
					}else{
						 loanBalance.setPeriodInte(0);			
					}
					 nowInte=loanBalance.getPeriodInte();//��۽���μ� ������Ϣ����
					 loanBalance.setPayInte(repaymentSchedule.getRepayInterest()+addsum);//����Ӧ����Ϣ
					
				}else
				{
				     loanBackStatus1.setPayInte(repaymentSchedule.getRepayInterest()+payInteBase);	
				}
				loanBackStatus1.InsertLoanBackStatus();
			}
			else
			{
				//��������ڱ������ȡ�Ѿ����ڵĻ����¼����
				loanBalance.setNormalBalance(loanBalance.getNormalBalance()-loanBackStatus1.getPayOverdueCorp()+loanBackStatus1.getActualOverdueCorp());
				loanBalance.setOverDueBalance(loanBackStatus1.getPayOverdueCorp()-loanBackStatus1.getActualOverdueCorp()+loanBalance.getOverDueBalance());
				nowInte = loanBackStatus1.getPayInte()+loanBackStatus1.getPayInnerInte()+loanBackStatus1.getPayOutInte()
						-loanBackStatus1.getActualInte()+loanBackStatus1.getActualInnerInte()-loanBackStatus1.getActualOutInte();
				
				double lastMonthPay = loanBackStatus1.getPayCurrentCorp()+loanBackStatus1.getPayDefaultCorp()+loanBackStatus1.getPayOverdueCorp()
									+loanBackStatus1.getPayInte()+loanBackStatus1.getPayInnerInte()+loanBackStatus1.getPayOutInte();
				
				//Ҫ����LOAN_BALANCE��������������ڱ���
				loanBalance.setLastInteDate(loanBackStatus1.getPayDate());
				//������һ�ڻ���ƻ�
				loanBackStatus1.clear();
				loanBackStatus1.setPutOutNo(loanBalance.getPutOutNo());
				loanBackStatus1.setSTerm(loanBalance.getSTerm()+1);
				loanBackStatus1.setAheadNum(0);
				loanBackStatus1.setPayDate(sDeductDate);
				if(!loanBackStatus1.SelectLoanBackStatus()) //��������ڣ�����ϵͳ�������
				{
					LoanBalance loanBalance1 =loanBalance.clone();
					RepaymentSchedule repaymentSchedule1=new RepaymentSchedule();
						
					RepaymentType repaymentType1 = RepayTypeConfig.getRepaymentType(loanBalance1.getReturnType());
					IRepayScheduleEngine repayScheduleEngine1=repaymentType1.getRepayScheduleEngine();
					repaymentSchedule1 = repayScheduleEngine1.getRepaymentSchedule(loanBalance1);
					
					loanBalance.setNextPayDate(loanBalance1.getNextPayDate());
					loanBalance.setSCTerm(loanBalance1.getSCTerm());
					loanBalance.setSTerm(loanBalance1.getSTerm());
					loanBalance.setLastTerm(loanBalance1.getLastTerm());
					loanBalance.setMonthPay(loanBalance1.getMonthPay());
				}
				else
				{
					loanBalance.setNextPayDate(loanBackStatus1.getPayDate());
					loanBalance.setSCTerm(loanBalance.getSCTerm()+1);
					loanBalance.setSTerm(loanBalance.getSTerm()+1);
					
					double nowMonthPay = loanBackStatus1.getPayCurrentCorp()+loanBackStatus1.getPayDefaultCorp()+loanBackStatus1.getPayOverdueCorp()
										+loanBackStatus1.getPayInte()+loanBackStatus1.getPayInnerInte()+loanBackStatus1.getPayOutInte();
					if(Math.abs(lastMonthPay - nowMonthPay) > 0.000001)
						loanBalance.setLastTerm(loanBalance.getSTerm()-1);
				}
				loanBalance.setPayInte(loanBalance.getPayInte()+nowInte-payInteBase);
			}
			
			loanBalance.setPayInte(loanBalance.getPayInte()+payInteBase);
			loanBalance.setInteBase(0);
			loanBalance.setPeriodInte(0);
			
		}else if (loanBalance.getNormalBalance()>0 && sDeductDate.compareTo(loanBalance.getMaturityDate())>0){//������
			//����״̬��
			//�õ����ڱ��� ���ǵݱ�Ļ��ʽ
			loanBackStatus1.setPutOutNo(loanBalance.getPutOutNo());
			loanBackStatus1.setSTerm(loanBalance.getSTerm());
			loanBackStatus1.setAheadNum(0);
			loanBackStatus1.setPayDate(sDeductDate);
			if(!loanBackStatus1.SelectLoanBackStatus())//���������
			{
				loanBackStatus1.setCurrency(loanBalance.getCurrency());
				loanBackStatus1.setAccDate(sDeductDate);
				loanBackStatus1.setPayOffFlag(AccountConstants.NO);
				loanBackStatus1.setGracePeriod(loanBalance.getGracePeriod());
				loanBackStatus1.setOrgid(loanBalance.getOrgID());
				loanBackStatus1.setFineBaseDate(sDeductDate);
				loanBackStatus1.setPayOverdueCorp(loanBalance.getNormalBalance());
				loanBackStatus1.setPayInte(0);
				loanBackStatus1.InsertLoanBackStatus();
			}
			loanBalance.setLastInteDate(sDeductDate);
			loanBalance.setSTerm(loanBalance.getSTerm()+1);//�������۵�ǰ�ڴΣ���һ
			loanBalance.setOverDueBalance(NumberTools.round(loanBalance.getOverDueBalance()+loanBalance.getNormalBalance(),AccountConstants.MONEY_PRECISION));
			loanBalance.setNormalBalance(0);//�������			
		}			
		inputPara = BatchTransProvider.SetInputPara(inputPara,"DayInte",NumberTools.round(nowInte-lastInte,AccountConstants.MONEY_PRECISION));
	}
	
	
	
}
