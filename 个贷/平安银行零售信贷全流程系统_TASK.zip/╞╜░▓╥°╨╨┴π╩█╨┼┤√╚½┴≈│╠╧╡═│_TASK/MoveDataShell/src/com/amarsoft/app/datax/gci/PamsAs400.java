package com.amarsoft.app.datax.gci;

public class PamsAs400 {

	//��ݱ��
	private String sPutOutNo;
	//����
	private String sCurrency;
	//���
	private double amount;
	//�ۿ��˺ţ���������
	private String sDudectAccNo;
	//�տ��˺ţ����뷽��
	private String sRelativeAccNo;
	//������ˮ��ͬʱ��Ч��־��
	private String deductSerialNo;
	//�������(������Ϣ����Ϣ������)
	private String amountAttribute;
	//�ڴ�
	private int Sterm;
	//��������
	private String sPayType;
	//��ǰ������ˮ��
	private String sAheadSerialNo;
	
	
	
	public PamsAs400()
	{}
	public PamsAs400(String sPutOutNo,String sCurrency,double amount,String sDudectAccNo,String sRelativeAccNo,
			String deductSerialNo,String amountAttribute,int Sterm,String sPayType,String sAheadSerialNo)
	{
		this.sPutOutNo=sPutOutNo;
		this.sCurrency=sCurrency;
		this.amount=amount;
		this.sDudectAccNo=sDudectAccNo;
		this.sRelativeAccNo=sRelativeAccNo;
		this.deductSerialNo=deductSerialNo;
		this.amountAttribute=amountAttribute;
		this.Sterm=Sterm;
		this.sPayType=sPayType;
		this.sAheadSerialNo = sAheadSerialNo;
	}
	
	
	public String getSPayType() {
		return sPayType;
	}
	public void setSPayType(String payType) {
		sPayType = payType;
	}
	public String getSPutOutNo() {
		return sPutOutNo;
	}
	public void setSPutOutNo(String putOutNo) {
		sPutOutNo = putOutNo;
	}
	public String getSCurrency() {
		return sCurrency;
	}
	public void setSCurrency(String currency) {
		sCurrency = currency;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getSDudectAccNo() {
		return sDudectAccNo;
	}
	public void setSDudectAccNo(String dudectAccNo) {
		sDudectAccNo = dudectAccNo;
	}
	public String getSRelativeAccNo() {
		return sRelativeAccNo;
	}
	public void setSRelativeAccNo(String relativeAccNo) {
		sRelativeAccNo = relativeAccNo;
	}
	public String getDeductSerialNo() {
		return deductSerialNo;
	}
	public void setDeductSerialNo(String deductSerialNo) {
		this.deductSerialNo = deductSerialNo;
	}
	public String getSaheadSerialNo() {
		return sAheadSerialNo;
	}
	public void setAheadSerialNo(String sAheadSerialNo) {
		this.sAheadSerialNo = sAheadSerialNo;
	}
	public String getAmountAttribute() {
		return amountAttribute;
	}
	public void setAmountAttribute(String amountAttribute) {
		this.amountAttribute = amountAttribute;
	}
	public int getSterm() {
		return Sterm;
	}
	public void setSterm(int sterm) {
		Sterm = sterm;
	}
	
	
}
