package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCopyLedgerDetail extends CommonExecuteUnit  {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
       //     OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����QY_ledger_detail_icsҵ�����ݣ�.............");
				CreateData();
				logger.info("................����QY_ledger_detail_icsҵ��������ɣ�..............");
							
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateData() throws SQLException{
		String al="insert into ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate," +
				"currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno) "
				+" select putoutno,billno,transid,sortid,occurtime,occurdate,currency," +
				"subjectno,creditamt,debitamt,handstatus,orgid,serialno from qy_ledger_detail_ics ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
