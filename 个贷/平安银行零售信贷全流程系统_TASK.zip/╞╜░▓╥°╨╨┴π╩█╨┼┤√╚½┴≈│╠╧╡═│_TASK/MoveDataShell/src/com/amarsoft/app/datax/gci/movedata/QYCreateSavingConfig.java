package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateSavingConfig extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ�����ִ��������ݣ�.............");
				deleteData();
				checkALLData();
				logger.info("................�����ִ�����������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	// �����ִ����ñ�
	public void deleteData() throws SQLException {
		String al = "delete from saving_credit_config sc where sc.serialno like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// �����ִ����ñ�
	public void checkALLData() throws SQLException {
		String al = "insert into saving_credit_config( SERIALNO,CALRATE,SAVINGLIMAMT,SAVINGUPLIMAMT,QUICKDEDUCT, "
				+ "  STATUS,BEGINDATE,INPUTDATE,FINACINGTYPE,MAXSAVINGBALANCE,orgid,maxrate)  "
				+ "    select 'QY2012'||SEQ_CLEAN.NEXTVAL as  SERIALNO,CALRATE,SAVINGLIMAMT,SAVINGUPLIMAMT,QUICKDEDUCT,  "
				+ "    STATUS, BEGINDATE, INPUTDATE, FINACINGTYPE, MAXSAVINGBALANCE,'1', getbaserate(61,'010')*1.1 as Rates from qy_saving_credit_config  ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
