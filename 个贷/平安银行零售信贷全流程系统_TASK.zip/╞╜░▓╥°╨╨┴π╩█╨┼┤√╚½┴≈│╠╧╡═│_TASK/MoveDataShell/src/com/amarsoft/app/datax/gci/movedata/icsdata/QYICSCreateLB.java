package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateLB extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ics�������LB���ݣ�.............");
				CreateCI();
				logger.info("................����ics�����������LB��ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = "insert into LOAN_BALANCE(		"
				+ "PUTOUTNO,CONTRACTSERIALNO,CUSTOMERID,CUSTOMERNAME,BUSINESSTYPE,BUSINESSSUBTYPE,CURRENCY,	"
				+ "ORGID,MAINRETURNTYPE,RETURNTYPE,RETURNPERIOD,DEDUCTACCNO,DEDUCTACCNO1,DEDUCTACCNO2,	"
				+ "GRACEPERIODCODE,GRACEPERIOD,PUTOUTDATE,MATURITYDATE,BEGINDATE,MONTHENDFLAG,	"
				+ "LOANTERM,NEXTPAYDATE,CTERM,SCTERM,STERM,AHEADNUM,GAINAMOUNT,GAINCYC,LASTTERM,	"
				+ "BASEDAYS,BASERATE,RATECODE,RATEMODE,RATEFLOATTYPE,RATEFLOAT,PUTOUTRATE,EXECUTERATE,	"
				+ "FINERATEMODE,FINERATEFLOATTYPE,FINERATECODE,FINERATETYPE,FINERATEFLOAT,FINERATE,	"
				+ "LASTINTEDATE,LOANSTATUS,MONTHPAY,BUSINESSSUM,NORMALBALANCE,CURRENTBALANCE,DEFAULTBALANCE,	"
				+ "OVERDUEBALANCE,PAYINTE,PAYINNERINTE,PAYOUTINTE,PAYINNERINTEFINE,PAYOUTINTEFINE,PERIODINTEBASE,	"
				+ "PERIODINTE,CORPFINEFLAG,INTEFINEFLAG,UPDATEDATE,CALCDAYINTEDATE,USERID,FINISHDATE,APPVIPRATEDATE,	"
				+ "RATEFLOATFLAG,HOLDBALANCE,CALCMATURITYDATE,RATEALTERDATE,RATEADJUSTTYPE,DISDATE,LOANACCNO,FAREFALG,	"
				+ "CLASSIFYRESULT,BASERATETYPE,ACCORDINTEBASE,DSINTEPROPORTION,TRUSTACCNO,INTEBASE,BANKFLAG,	"
				+ "BATCHPAYMENTFLAG,BUSINESSKIND,CUSTOMERTYPE)	"
				+ "  select  replace(PUTOUTNO11,'QY','QYICS00'),replace(PUTOUTNO11,'QY','QYICS00'),replace(CUSTOMERID11,'QY','QYICS'),CUSTOMERNAME11,          "
				+ "  case when BUSINESSTYPE11='99999' then '1190030' " 
				+ "  else (select cc.businesstype from qy_ics_businesstype_map cc where cc.orgid=orgid11) end,    "
				+ "   BUSINESSSUBTYPE11,CURRENCY11,oi.orgid,MAINRETURNTYPE11,RETURNTYPE11,RETURNPERIOD11,DEDUCTACCNO11,'',  '',          "
				+ "   GRACEPERIODCODE11,GRACEPERIOD11,        "
				+ "   substr(PUTOUTDATE11,0,4)||'/'||substr(PUTOUTDATE11,5,2)||'/'||substr(PUTOUTDATE11,7,2),   "
				+ "   substr(MATURITYDATE11,0,4)||'/'||substr(MATURITYDATE11,5,2)||'/'||substr(MATURITYDATE11,7,2),     "
				+ "   substr(BEGINDATE11,0,4)||'/'||substr(BEGINDATE11,5,2)||'/'||substr(BEGINDATE11,7,2),      "
				+ "   nvl(MONTHENDFLAG11,0), LOANTERM11,      "
				+ "   case when NEXTPAYDATE11='00000000' then '2012/10/21' else        "
				+ "   substr(NEXTPAYDATE11,0,4)||'/'||substr(NEXTPAYDATE11,5,2)||'/'||substr(NEXTPAYDATE11,7,2) end,    "
				+ "   CTERM11,SCTERM11,STERM11,AHEADNUM11,GAINAMOUNT11,GAINCYC11,LASTTERM11,   "
				+ "   case when BASEDAYS11=0 then 360 else BASEDAYS11 end,BASERATE11,RATECODE11,                "
				+ "   RATEMODE11,    "
				+ "   case when RATEFLOATTYPE11='00' then '01' else RATEFLOATTYPE11 end,RATEFLOAT11,PUTOUTRATE11,EXECUTERATE11,FINERATEMODE11,   "
				+ "   case when FINERATEFLOATTYPE11='00' then '01' else FINERATEFLOATTYPE11 end,                "
				+ "   case when FINERATECODE11='00' then '01' else FINERATECODE11 end, "
				+ "   nvl(FINERATETYPE11,'L'),FINERATEFLOAT11,FINERATE11,              "
				+ "   substr(LASTINTEDATE11,0,4)||'/'||substr(LASTINTEDATE11,5,2)||'/'||substr(LASTINTEDATE11,7,2),     "
				+ "   LOANSTATUS11,  " 
				+ " MONTHPAY11,BUSINESSSUM11,NORMALBALANCE11,CURRENTBALANCE11,DEFAULTBALANCE11,OVERDUEBALANCE11,PAYINTE11,       "
				+ "   PAYINNERINTE11+PAYOUTODINT11,PAYOUTINTE11+PAYOUTOINTS11,PAYINNERINTEFINE11,PAYOUTINTEFINE11,PERIODINTEBASE11,      "
				+ "   PERIODINTE11+INTEBASE11,CORPFINEFLAG11,INTEFINEFLAG11,     "
				+ "   case when UPDATEDATE11='00000000' then (select CURDEDUCTDATE from ploan_setup ) else      "
				+ "   substr(UPDATEDATE11,0,4)||'/'||substr(UPDATEDATE11,5,2)||'/'||substr(UPDATEDATE11,7,2) end,       "
				+ "   case when CALCDAYINTEDATE11='00000000' then (select CURDEDUCTDATE from ploan_setup ) else "
				+ "   substr(CALCDAYINTEDATE11,0,4)||'/'||substr(CALCDAYINTEDATE11,5,2)||'/'||substr(CALCDAYINTEDATE11,7,2) end,         "
				+ "   USERID11,      "
				+ "   case when FINISHDATE11='00000000' then '' else  "
				+ "    substr(FINISHDATE11,0,4)||'/'||substr(FINISHDATE11,5,2)||'/'||substr(FINISHDATE11,7,2) end,      "
				+ "   '',nvl(RATEFLOATFLAG11,0),              "
				+ "   HOLDBALANCE11,(select CURDEDUCTDATE from ploan_setup ),          "
				+ "   case when RATEALTERDATE11='00000000' then '2012/01/01'           "
				+ "   else  substr(RATEALTERDATE11,0,4)||'/'||substr(RATEALTERDATE11,5,2)||'/'||substr(RATEALTERDATE11,7,2) end,         "
				+ "   '5',  '','',FAREFALG11,'',BASERATETYPE11,ACCORDINTEBASE11,DSINTEPROPORTION11,             "
				+ "   '',INTEBASE11,'PAB','1','RCPM','03'     "
				+ "   from qy_loan_balance_ics ci,org_info oi "
				+ "   where ci.orgid11=oi.mainframeorgid      ";

		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
