package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateBAPP extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ������ż�����������ݣ�.............");
				CreateData();
				logger.info("................������ż��������������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0;
		String al="select distinct lb.putoutno,case when lb.businesskind='RCPM' then 'CBContractApply' "
				+" else 'SWContractApply' end as objecttype,lb.customerid,lb.customername from QY_LS_APPT_SPOUSE ls,qy_loan_balance lb where  lb.LS_APPL_SEQ=to_char(ls.LS_APPL_SEQ) ";
		String insertSql="insert into qy_business_applicant(putoutno,objecttype,objectno," +
					" applicantid,applicantname,relationship,applicanttype,status) "
					+" values (?,?,?,?,?,?,?,?) ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("putoutno"));
			inps.setString(2, rs.getString("objecttype"));
			inps.setString(3, "");
			inps.setString(4, rs.getString("customerid"));
			inps.setString(5, rs.getString("customername"));
			inps.setString(6, "0301");
			inps.setString(7, "020");
			inps.setString(8, "1");
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		rs.close();
	}
	
	
	
}
