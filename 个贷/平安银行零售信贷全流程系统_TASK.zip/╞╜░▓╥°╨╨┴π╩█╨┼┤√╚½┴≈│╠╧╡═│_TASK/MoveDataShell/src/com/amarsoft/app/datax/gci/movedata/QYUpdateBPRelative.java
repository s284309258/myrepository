package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateBPRelative extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ���´浥�������Ŀͻ������ݣ�.............");
				updateBPRelatives();
				logger.info("................���´浥�������Ŀͻ���������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void updateBPRelatives() throws SQLException{
		int i=0,j=0;
		String al="select bp.serialno,qb.becif_no from business_putout_relative bp,tempintf.retail_perloan_mapping  qb " +
				"where bp.mfcustomerid=qb.CUST_NO and bp.putoutno like 'QY%' ";
		PreparedStatement ps=connection.prepareStatement(al);
		String up="update business_putout_relative bp set bp.mfcustomerid=? where bp.serialno=?";
		PreparedStatement ups=connection.prepareStatement(up);
		ResultSet rs =ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("becif_no"));
			ups.setString(2, rs.getString("serialno"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"��������ɣ�..............");
			}
		}
		rs.close();
		ups.executeBatch();
		connection.commit();
		logger.info("................����"+j+"��������ɣ�..............");
	
	}
	
}
