package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSInitCustomer extends CommonExecuteUnit {


	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
							
				logger.info("................��ʼ����ICS����ͻ����ݣ�.............");
				UpdateICSData();
				logger.info("................����ICS����ͻ�������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
	
	public void UpdateICSData() throws SQLException{
		String mfid="";
		String newBECIFNO="";
		String sCustomerID="";
		String al="select qi.customerid11,qi.mfcustomerid11 from qy_customer_info_ics qi where qi.al11 is null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		
		ResultSet rd=null;
		String selectCI="select ql.BECIF_NO from tempintf.retail_ics_mapping ql where ql.CI_NO=? ";
		PreparedStatement pd=connection.prepareStatement(selectCI);
		
		String updateSql="update qy_customer_info_ics qi set qi.al11=? where qi.customerid11=? ";
		PreparedStatement pf=connection.prepareStatement(updateSql);
		
		while(rs.next()){
			mfid="";
			newBECIFNO="";
			sCustomerID="";
			mfid=rs.getString("mfcustomerid11");
			sCustomerID=rs.getString("customerid11");
			pd.setString(1, mfid);
			rd=pd.executeQuery();
			while(rd.next()){
				newBECIFNO=rd.getString("BECIF_NO");
			}
			rd.close();
			
			pf.setString(1, newBECIFNO);
			pf.setString(2, sCustomerID);
			pf.execute();			
		}
		rs.close();
		
		connection.commit();
	}
	

}
