package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreatContractRelative extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ������Ŀ������ϵQYҵ�����ݣ�.............");
				CreateData();
				logger.info("................������Ŀ������ϵQYҵ��������ɣ�..............");

				logger.info("................��ʼ������Ŀ������ϵҵ�����ݣ�.............");
				CreateData1();
				logger.info("................������Ŀ������ϵҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateData() throws SQLException {
		String al = "insert into qy_contract_relative(serialno,objecttype,objectno,relativesum) "
				+ " select lc.contractserialno,'GuarantyContract',gc.serialno,lc.businesssum from qy_guaranty_contract gc,loan_balance lc "
				+ " where lc.putoutno=gc.serialno ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}

	public void CreateData1() throws SQLException {
		String al = " insert into contract_relative(serialno,objecttype,objectno,relativesum) "
				+ " select lc.contractserialno,'GuarantyContract',gc.serialno,lc.businesssum from qy_guaranty_contract gc,loan_balance lc  "
				+ " where lc.putoutno=gc.serialno  ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}

}
