package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class DealQQDBAK extends CommonExecuteUnit {
	private int commitNum=100;
	private int dealNum=0;
	private int icount=0;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����SDBǨ�ƹ�����������ݣ�.............");
				dealQQD();
				logger.info("................����SDBǨ�ƹ��������������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void dealQQD() throws SQLException{
		//ֻ����SDBǨ�ƹ��������������Ҵ���ʵ�ʵ�����С��̯��������
		String sql = "select * from qy_loan_balance where MainReturnType='15' "+
                     " and loanstatus='0' and maturitydate<calcmaturitydate ";
		PreparedStatement ps = connection.prepareStatement(sql);
		
		String sqlLoan = "select sum(payoverduecorp) as corp,sum(payinte) as inte,MIN(STERM) as sterm,min(paydate) as paydate,putoutno " +
				" from loanback_status where paydate>=? and putoutno = ?  group by putoutno";
		PreparedStatement psSqlLoan = connection.prepareStatement(sqlLoan);
		
		//���������ʵ�ʵ����յĻ���ƻ�����һ��
		String sqlLoan1 = "select paydate,payoverduecorp " +
		" from loanback_status where sterm=? and putoutno = ? and AHEADNUM=0";
		PreparedStatement psSqlLoan1 = connection.prepareStatement(sqlLoan1);
		
		//ɾ��SDB�����������ʵ�ʵ����յĻ���ƻ�
		String slqDelete = "delete from loanback_status where putoutno=?  and paydate>?";
		PreparedStatement psSqlDelete = connection.prepareStatement(slqDelete);
		//����Ϊ�µĻ���ƻ�(��paydateΪ�����յ������)
		String sqlUpdate = "update loanBack_status set payoverduecorp = payoverduecorp+? " +
				" where putoutno=? and sterm=? AND AHEADNUM=0";
		PreparedStatement psUpdate = connection.prepareStatement(sqlUpdate);
		
		String SqlInsectLoanBackStatus = "Insert Into LoanBack_Status(PutOutNo,STerm,AheadNum,PayDate," +
		"PayCurrentCorp,PayInte,ActualCurrentCorp,ActualInte,PayDefaultCorp," +
		"PayInnerInte,ActualDefaultCorp,ActualInnerInte,PayOverdueCorp,PayOutInte," +
		"ActualOverdueCorp,ActualOutInte,PayOverdueCorpInte,PayInnerInteFine,PayOutInteFine," +
		"ActualInnerInteFine,ActualOutInteFine,OverdueCorpInteBase,InteFineBase," +
		"AccDate,PayOffFlag,GracePeriod,Orgid,FineBaseDate,Currency) " +
		" Values(?,?,?,?,?," +
		"?,?,?,?,?," +
		"?,?,?,?,?," +
		"?,?,?,?,?," +
		"?,?,?,?,?," +
		"?,?,?,?) ";
		PreparedStatement psInsectLoanBackStatus = connection.prepareStatement(SqlInsectLoanBackStatus); 
		int rd=0;
		ResultSet rs = ps.executeQuery();
		
		String putoutno="";
		String maturityDate = "";
		String orgid = "";
		String currency = "";
		String date ="";
		double inte =0;
		double paycorp=0;
		double executerate = 0.0;
		double corp = 0.0;
		int sterm = 0;
		String paydate = "";
		int days = 0;
		int calday =0;
		
		logger.info("..........."+commitNum+"....");
		
		while(rs.next()){
			rd++;
			date ="";
			inte =0;
			paycorp=0;
			putoutno = rs.getString("PutOutNo");
			maturityDate = rs.getString("maturityDate");
			orgid = rs.getString("Orgid");
			currency = rs.getString("currency");
			executerate = rs.getDouble("executerate");
			psSqlLoan.setString(1, maturityDate);
			psSqlLoan.setString(2, putoutno);
			ResultSet rsSqlLoan = psSqlLoan.executeQuery();
		//	logger.info(".........."+putoutno+".."+rd+"....");
			while(rsSqlLoan.next()){
				corp = rsSqlLoan.getDouble("corp");
				sterm = rsSqlLoan.getInt("sterm");
				paydate = rsSqlLoan.getString("paydate");
				//ȥ����������������Ϊ0�������Ϊ���һ�ڣ�������ڣ���Ĭ��Ϊ������Ϊ���һ��
				
			//	logger.info(".........."+maturityDate+".."+paydate+"....");
				days = DateTools.getDays(maturityDate, paydate);
				if(days==0){
					psUpdate.setDouble(1, corp);
					psUpdate.setString(2, putoutno);
					psUpdate.setInt(3, sterm);
					psUpdate.addBatch();
					
					psSqlDelete.setString(1, putoutno);
					psSqlDelete.setString(2, paydate);
					psSqlDelete.addBatch();
					
				}else{//������ڣ���ɾ�����ڴ��ڵ����յĻ���ƻ� ͬʱ����һ�ڻ����յ���Ļ���ƻ�
					psSqlLoan1.setInt(1, sterm-1);
					psSqlLoan1.setString(2, putoutno);
					ResultSet rsSqlLoan1 = psSqlLoan1.executeQuery();
					while(rsSqlLoan1.next()){
						date = rsSqlLoan1.getString("paydate");
						paycorp = rsSqlLoan1.getDouble("payoverduecorp");
					}
					rsSqlLoan1.close();
					calday = DateTools.getDays(date, maturityDate);
					//ʣ�౾���Լ�������Ϣ
					inte = NumberTools.round(corp*executerate/365/100*calday,2);
					
					psSqlDelete.setString(1, putoutno);
					psSqlDelete.setString(2, maturityDate);
					psSqlDelete.addBatch();
					
					psInsectLoanBackStatus.setString(1, putoutno);
					psInsectLoanBackStatus.setInt(2, sterm);
					psInsectLoanBackStatus.setInt(3, 0);
					psInsectLoanBackStatus.setString(4, maturityDate);
					psInsectLoanBackStatus.setDouble(5, 0); 
					psInsectLoanBackStatus.setDouble(6, inte);
					psInsectLoanBackStatus.setDouble(7, 0);
					psInsectLoanBackStatus.setDouble(8, 0);
					psInsectLoanBackStatus.setDouble(9, 0);
					psInsectLoanBackStatus.setDouble(10, 0);
					psInsectLoanBackStatus.setDouble(11, 0);
					psInsectLoanBackStatus.setDouble(12, 0);		
					psInsectLoanBackStatus.setDouble(13, corp);
					psInsectLoanBackStatus.setDouble(14, 0);
					psInsectLoanBackStatus.setDouble(15, 0);
					psInsectLoanBackStatus.setDouble(16, 0);		
					psInsectLoanBackStatus.setDouble(17, 0);
					psInsectLoanBackStatus.setDouble(18, 0);
					psInsectLoanBackStatus.setDouble(19, 0);
					psInsectLoanBackStatus.setDouble(20, 0);
					psInsectLoanBackStatus.setDouble(21, 0);
					psInsectLoanBackStatus.setDouble(22, 0);
					psInsectLoanBackStatus.setDouble(23, 0);
					psInsectLoanBackStatus.setString(24, maturityDate);			
					psInsectLoanBackStatus.setString(25, "0");
					psInsectLoanBackStatus.setInt(26, 3);
					psInsectLoanBackStatus.setString(27, orgid);
					psInsectLoanBackStatus.setString(28, maturityDate);
					psInsectLoanBackStatus.setString(29, currency);
					psInsectLoanBackStatus.addBatch();
					
				}
			}
			rsSqlLoan.close();
			dealNum++;
			icount++;
			logger.info("====="+icount+"��");
			if(dealNum>=commitNum){
				psUpdate.executeBatch();
				psSqlDelete.executeBatch();
				psInsectLoanBackStatus.executeBatch();
				dealNum=0;
				connection.commit();
				logger.info("�Ѿ�����SDBǨ�ƹ������������"+icount+"��");
				
			}
		}
		psUpdate.executeBatch();
		psSqlDelete.executeBatch();
		psInsectLoanBackStatus.executeBatch();
		
		psSqlLoan.close();
		psSqlLoan1.close();
		psUpdate.close();
		psInsectLoanBackStatus.close();
		psSqlDelete.close();
		rs.close();
		ps.close();
		
	}
	
	
}
