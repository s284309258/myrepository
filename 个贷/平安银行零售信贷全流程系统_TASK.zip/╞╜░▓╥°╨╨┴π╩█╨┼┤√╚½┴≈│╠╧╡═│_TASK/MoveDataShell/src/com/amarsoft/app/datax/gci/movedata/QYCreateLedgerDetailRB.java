package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateLedgerDetailRB extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				DeleteLD();
				DeleteLD1();
				
				CreateQYLD();
				CreateLD();
				logger.info("................����ҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void DeleteLD() throws Exception {
		String al = "delete from qy_ledger_detail ld where exists (select * from qy_loan_balance lb where lb.loanstatus in ('4','5') and ld.putoutno=lb.putoutno) ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void DeleteLD1() throws Exception {
		String al = "delete from ledger_detail ld where exists (select * from qy_loan_balance lb where lb.loanstatus in ('4','5') and ld.putoutno=lb.putoutno) ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	//�����м������
	public void CreateQYLD() throws Exception {
		String al = "insert into qy_ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno)   "
				+ " select 'QYRB'||oi.orgid,'','99999','99','','"
				+ deductDate
				+ "' ,substr(rd.rdata,6,3),substr(rd.rdata,15,7) as subjectno,substr(rd.rdata,28,13)/100 as atm,0.0,'1',oi.orgid,   "
				+ " 'QYRB'||oi.orgid||SEQ_CLEAN.NEXTVAL from ics_rloan_data rd,org_info oi where substr(rd.rdata,6,3)='RMB'   "
				+ " and (substr(rd.rdata,15,7)='6080201' or substr(rd.rdata,15,7)='6080202')   "
				+ " and oi.mainframeorgid=substr(rd.rdata,0,4) ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	//���м����������ʽ��
	public void CreateLD() throws Exception {
		String al = "insert into ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno)   "
				+ " select putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno from qy_ledger_detail lg "
				+ " where lg.subjectno in('6080201','6080202') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
