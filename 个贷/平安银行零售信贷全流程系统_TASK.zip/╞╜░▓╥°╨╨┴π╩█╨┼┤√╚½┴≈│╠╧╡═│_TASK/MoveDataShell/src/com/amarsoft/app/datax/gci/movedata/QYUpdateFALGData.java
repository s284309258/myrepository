package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateFALGData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................���´�ִ�LG��Ŀ���ݣ�.............");
				UpdateLGData();
				logger.info("................���´�ִ�LG��Ŀ��ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
	
	public void UpdateLGData() throws SQLException{
		int i=0,j=0;
		String al="  select l.financing_act_no,sum(nvl(l.income,0)) as amt  "
				+"   from qy_lnfin_list l  "
				+"   where l.make_dt > '2012-07-01'  "
				+"   and l.paym_dt is null  "
				+"   and l.succ_ind is null  "
				+"   and l.paym_ind is null  "
				+"   group by l.financing_act_no ";
		String updateSql1=" update qy_ledger_general set creditbalance=?,debitbalance=? where putoutno=? and subjectno=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inst=connection.prepareStatement(updateSql1);

			
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inst.setDouble(1, rs.getDouble("amt"));
			inst.setDouble(2, 0.0);
			inst.setString(3, "DL"+rs.getString("financing_act_no"));
			inst.setString(4, "2600201");
			inst.addBatch();
			
			inst.setDouble(1, 0.0);
			inst.setDouble(2, rs.getDouble("amt"));
			inst.setString(3, "DL"+rs.getString("financing_act_no"));
			inst.setString(4, "5380201");
			inst.addBatch();
						
			if(i>500){
				inst.executeBatch();
				connection.commit();
				i=0;
				logger.info("...........���� "+j+" ������..............");
			}
		}
		inst.executeBatch();
		connection.commit();
		rs.close();
		
	}
	

}
