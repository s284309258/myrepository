package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFeeLDData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����̯������LD�������ݣ�.............");
				CreateLGData1();
				logger.info("................���ɷ���LG����������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateLGData1() throws SQLException{
		String al=" insert into qy_ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate,currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno)    " 
				+" select lg.putoutno,'' as BILLNO ,99999 as TRANSID,99 as SORTID,'' as OCCURTIME,'"+deductDate+"' as OCCURDATA,lg.currency,lg.subjectno,    " 
				+" lg.creditbalance ,lg.debitbalance,'1' as HANDSTATUS,lg.orgid,lg.serialno  as serialno     " 
				+" from qy_ledger_general lg where (lg.creditbalance<>0 or lg.debitbalance<>0) " 
				+" and lg.putoutno like 'QYF%' ";;
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
			
}
