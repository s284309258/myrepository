package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateLBR extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����icsloanbalance_relative���ݣ�.............");
				CreateCI();
				logger.info("................����icsloanbalance_relative������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = "insert into loanbalance_relative(PUTOUTNO,ORIRATEFLOAT,OVERDAYS,ADDOVERTERMS, "
				+ " SERIESOVERTERMS,SERIESFLOATNORTERM,SERIESNORTERM,FIRSTOVERDATE,LASTMONTHAVGBALANCE, "
				+ " PRODUCTBALANCE,FEETYPE,FEEMETHOD,FAREMONEYTYPE,AMOUNT,MONEYPROPORTION,TURNNORMALSERIALTERMS, "
				+ " ISFLOATASQRATE,MONTHENDLOANBALANCE,PAYSEQ,PAYSUBJECTSEQ,ISTRANSFER,GETINTEBASE,TOOVERDUECORP, "
				+ " TRANSFERFLAG,OPENVIPDATE,ISBATCHSTATUS) "
				+ " select distinct replace(PUTOUTNO11,'QY','QYICS00'),ORIRATEFLOAT11, "
				+ " OVERDAYS11,ADDOVERTERMS11,SERIESOVERTERMS11,SERIESFLOATNORTERM11,SERIESNORTERM11, "
				+ " '',LASTMONTHAVGBALANCE11,PRODUCTBALANCE11,FEETYPE11,FEEMETHOD11, "
				+ " FAREMONEYTYPE11,AMOUNT11,0,TURNNORMALSERIALTERMS11,ISFLOATASQRATE11,MONTHENDLOANBALANCE11, "
				+ " PAYSEQ11,PAYSUBJECTSEQ11,ISTRANSFER11,GETINTEBASE11,TOOVERDUECORP11,'','',ISBATCHSTATUS11 "
				+ " from qy_loanbalance_relative_ics ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
