package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateLSReportData extends CommonExecuteUnit {
	private int commitNum = 1;
	private String orgData = "";

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");

				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateData();
				logger.info("................����ҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void initData() {
		commitNum = getProperty("commitNum", 1);
		orgData = getProperty("OrgData");
	}

	public void CreateData() throws SQLException {
		int i=0,j=0;
		
		String ad="select lb.putoutno from qy_loan_balance lb where lb.orgid in("+orgData+") "
				+" and lb.loanstatus in ('0','1','4','5')";
		PreparedStatement ps2 = connection.prepareStatement(ad);
		
		String al = "select ls.orgid,ls.putoutno, ls.sterm ,ls.paydate , "
				+ "  ls.paycurrentcorp+ls.payoverduecorp  as duecorp, "
				+ "   ls.actualcurrentcorp+ls.actualoverduecorp  as aduecorp, "
				+ "    ls.PAYINTE + ls.PAYINNERINTE + ls.PAYOUTINTE + ls.PAYINNERINTEFINE + "
				+ "   ls.PAYOUTINTEFINE + ls.PAYINNERINTOD + ls.PAYOUTINTEFOD  as a, "
				+ "    ls.ACTUALINTE+ls.ACTUALINNERINTE+ls.ACTUALOUTINTE+ls.ACTUALINNERINTEFINE+ls.ACTUALOUTINTEFINE+ls.ACTUALINNERINTOD+ls.ACTUALOUTINTEFOD as b  "
				+ "   from qy_loanback_status ls "
				+ "   where  ls.paydate>='"+deductDate+"'"
				+ " and ls.putoutno=? ";
		PreparedStatement ps = connection.prepareStatement(al);
		
		String insertSql = "insert into qy_loanback_status_tmp(putoutno,sterm,paydate,duecorp,aduecorp,a,b,orgid) values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps1 = connection.prepareStatement(insertSql);
		
		ResultSet rs1=ps2.executeQuery();
		while(rs1.next()){
			j++;
			ps.setString(1, rs1.getString("putoutno"));
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				i++;
				ps1.setString(1, rs.getString("putoutno"));
				ps1.setInt(2, rs.getInt("sterm"));
				ps1.setString(3, rs.getString("paydate"));
				ps1.setDouble(4, rs.getDouble("duecorp"));
				ps1.setDouble(5, rs.getDouble("aduecorp"));
				ps1.setDouble(6, rs.getDouble("a"));
				ps1.setDouble(7, rs.getDouble("b"));
				ps1.setString(8, rs.getString("orgid"));
				ps1.addBatch();
				if(i>1000){
					i=0;
					ps1.executeBatch();
					connection.commit();
				}
			}
			rs.close();
			ps1.executeBatch();
			connection.commit();
			logger.info("................����"+j+"��������ɣ�..............");
		}
		rs1.close();
	}

}
