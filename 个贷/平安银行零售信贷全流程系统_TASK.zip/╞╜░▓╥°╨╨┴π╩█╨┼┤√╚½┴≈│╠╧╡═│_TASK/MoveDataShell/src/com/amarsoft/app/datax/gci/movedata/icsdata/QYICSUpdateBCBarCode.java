package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSUpdateBCBarCode extends CommonExecuteUnit {
	
	//������ǰ׺
    private static String barNOPrefix ="KB00029";
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ICS�����ͬ�����������ݣ�.............");
				CreateCI();
				logger.info("................����ICS�����ͬ��������������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		int bar=9000001;
		String al = "select bc.serialno from business_contract bc where bc.serialno like 'QYICS%'";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		String barcode="";
		String ups = "update business_contract bc set bc.bar_code_no=? where bc.serialno=? ";
		PreparedStatement upps = connection.prepareStatement(ups);
		
		for(int i=0;i<500;i++){
			bar++;
			barcode=getBarCodeNo(bar);
			logger.info("......."+barcode+".......");
		}
		
//		while(rs.next()){
//			bar++;
//			barcode=getBarCodeNo(bar);
//			upps.setString(1, "");
//			upps.setString(2, "");
//		}
//		rs.close();


	}
	
	
	//����µ�������
		public static String getBarCodeNo(int startI){
			String barNO = "";
			int startILength = String.valueOf(startI).length();
			
			barNO = getZero(7-startILength) + startI;
			
			return barNOPrefix+barNO;
		}
		
		//���ǰ��0
		public static String getZero(int len){
			String str = "";
			for(int i=0;i<len;i++){
				str=str+"0";
			}
			return str;
		}
}
