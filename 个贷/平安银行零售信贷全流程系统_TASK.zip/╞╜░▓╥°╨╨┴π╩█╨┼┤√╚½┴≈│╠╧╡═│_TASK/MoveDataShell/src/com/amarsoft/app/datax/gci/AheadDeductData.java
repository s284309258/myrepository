package com.amarsoft.app.datax.gci;

public class AheadDeductData {

	private String PutOutNo;
	private int Sterm;
	private int Term;
	private String PayDate;
	private String DeductAccNo;
	private String DeductAccNo1;
	private String DeductAccNo2;
	private double PayCurrentCorp;
	private double PayInte;
	private double ActualCurrentCorp;
	private double ActualInte;
	private String Currency;
	private double PayPoundage;
	private double ActualPoundage;
	private double DealFlag;
	private String ChangeSerialNo;
	public String getPutOutNo() {
		return PutOutNo;
	}
	public void setPutOutNo(String putOutNo) {
		PutOutNo = putOutNo;
	}
	public int getSterm() {
		return Sterm;
	}
	public void setSterm(int sterm) {
		Sterm = sterm;
	}
	public int getTerm() {
		return Term;
	}
	public void setTerm(int term) {
		Term = term;
	}
	public String getPayDate() {
		return PayDate;
	}
	public void setPayDate(String payDate) {
		PayDate = payDate;
	}
	public String getDeductAccNo() {
		return DeductAccNo;
	}
	public void setDeductAccNo(String deductAccNo) {
		DeductAccNo = deductAccNo;
	}
	public String getDeductAccNo1() {
		return DeductAccNo1;
	}
	public void setDeductAccNo1(String deductAccNo1) {
		DeductAccNo1 = deductAccNo1;
	}
	public String getDeductAccNo2() {
		return DeductAccNo2;
	}
	public void setDeductAccNo2(String deductAccNo2) {
		DeductAccNo2 = deductAccNo2;
	}
	public double getPayCurrentCorp() {
		return PayCurrentCorp;
	}
	public void setPayCurrentCorp(double payCurrentCorp) {
		PayCurrentCorp = payCurrentCorp;
	}
	public double getPayInte() {
		return PayInte;
	}
	public void setPayInte(double payInte) {
		PayInte = payInte;
	}
	public double getActualCurrentCorp() {
		return ActualCurrentCorp;
	}
	public void setActualCurrentCorp(double actualCurrentCorp) {
		ActualCurrentCorp = actualCurrentCorp;
	}
	public double getActualInte() {
		return ActualInte;
	}
	public void setActualInte(double actualInte) {
		ActualInte = actualInte;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public double getPayPoundage() {
		return PayPoundage;
	}
	public void setPayPoundage(double payPoundage) {
		PayPoundage = payPoundage;
	}
	public double getActualPoundage() {
		return ActualPoundage;
	}
	public void setActualPoundage(double actualPoundage) {
		ActualPoundage = actualPoundage;
	}
	public double getDealFlag() {
		return DealFlag;
	}
	public void setDealFlag(double dealFlag) {
		DealFlag = dealFlag;
	}
	public String getChangeSerialNo() {
		return ChangeSerialNo;
	}
	public void setChangeSerialNo(String changeSerialNo) {
		ChangeSerialNo = changeSerialNo;
	}
	
	
}
