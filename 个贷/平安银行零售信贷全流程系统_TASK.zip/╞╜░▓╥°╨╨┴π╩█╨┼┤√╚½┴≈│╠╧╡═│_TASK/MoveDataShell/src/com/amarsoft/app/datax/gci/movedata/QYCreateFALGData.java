package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFALGData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼɾ���������ݣ�.............");
				DeleteALLData();				
				logger.info("................ɾ���������ݽ�����..............");
				
				logger.info("................��ʼ���ɴ�ִ�LG��Ŀ���ݣ�.............");
				CreateLGData();
				logger.info("................���ɴ�ִ�LG��Ŀ��ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
	public void DeleteALLData() throws SQLException{
		String al="delete from qy_ledger_general lg where lg.putoutno like 'DL%' ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void CreateLGData() throws SQLException{
		int i=0,j=0;
		String al=" select fr.savingaccno,oi.orgid as inputorg from qy_finacing_relative fr,org_info oi where fr.accounttype='01' and fr.inputorg is not null "
				+" and fr.inputorg=oi.mainframeorgid ";
		String insert=" insert into qy_ledger_general(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno," +
				" serialno,direction,subjectname) "
					 +" values(?,?,?,?,?,?,?,?,?,?) "	;
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inst=connection.prepareStatement(insert);
			
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inst.setString(1, "DL"+rs.getString("savingaccno"));
			inst.setString(2, "2600201");
			inst.setString(3, rs.getString("inputorg"));
			inst.setString(4, "RMB");
			inst.setDouble(5, 0.0);
			inst.setDouble(6, 0.0);
			inst.setString(7, "260");
			inst.setString(8, "F"+"DL"+rs.getString("savingaccno")+"2600201");
			inst.setString(9, "C");
			inst.setString(10, "Ӧ�����˷������Ʋ�Ʒ֧��");
			inst.addBatch();
			
			inst.setString(1, "DL"+rs.getString("savingaccno"));
			inst.setString(2, "5380201");
			inst.setString(3, rs.getString("inputorg"));
			inst.setString(4, "RMB");
			inst.setDouble(5, 0.0);
			inst.setDouble(6, 0.0);
			inst.setString(7, "538");
			inst.setString(8, "F"+"DL"+rs.getString("savingaccno")+"5380201");
			inst.setString(9, "C");
			inst.setString(10, "���˷������Ʋ�Ʒ֧��");
			inst.addBatch();
			
			inst.setString(1, "DL"+rs.getString("savingaccno"));
			inst.setString(2, "4031504");
			inst.setString(3, rs.getString("inputorg"));
			inst.setString(4, "RMB");
			inst.setDouble(5, 0.0);
			inst.setDouble(6, 0.0);
			inst.setString(7, "403");
			inst.setString(8, "F"+"DL"+rs.getString("savingaccno")+"4031504");
			inst.setString(9, "C");
			inst.setString(10, "�����Ŵ�-FCRϵͳ������");
			inst.addBatch();
			
			if(i>400){
				inst.executeBatch();
				connection.commit();
				i=0;
				logger.info("...........���� "+j+" ������..............");
			}
		}
		inst.executeBatch();
		connection.commit();
		rs.close();
		
	}
	

}
