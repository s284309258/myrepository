package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateLoanbackStatus extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����loanback_status���ݣ�.............");
				CreateCI();
				logger.info("................����loanback_status������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = "insert into loanback_status(PUTOUTNO,                                                         "
				+ "   STERM,AHEADNUM,PAYDATE,CURRENCY,GRACEPERIOD,                                               "
				+ "   PAYCURRENTCORP,ACTUALCURRENTCORP,PAYDEFAULTCORP,                                           "
				+ "   ACTUALDEFAULTCORP,PAYOVERDUECORP,ACTUALOVERDUECORP,                                        "
				+ "   PAYINTE,ACTUALINTE,PAYINNERINTE,ACTUALINNERINTE,                                           "
				+ "   PAYOUTINTE,ACTUALOUTINTE,ACTUALINNERINTEFINE,ACTUALOUTINTEFINE,                            "
				+ "   PAYINNERINTEFINE,PAYOUTINTEFINE,ACCDATE,PAYOFFFLAG,INTEFINEBASE,                           "
				+ "   UPDATEDATE,PAYOVERDUECORPINTE,OVERDUECORPINTEBASE,ORGID,FINEBASEDATE,                      "
				+ "   WAITOVERDUECORPINTE)"
				+ "    select PUTOUTNO,STERM,AHEADNUM,      "
				+ "     case when PAYDATE like '0%' then '2009/09/01' else PAYDATE end,      "
				+ "     CURRENCY11, GRACEPERIOD11, PAYCURRENTCORP11,ACTUALCURRENTCORP11,      "
				+ "     PAYDEFAULTCORP11, ACTUALDEFAULTCORP11, PAYOVERDUECORP11, ACTUALOVERDUECORP11,      "
				+ "     PAYINTE11, ACTUALINTE11, PAYINNERINTE, ACTUALINNERINTE,PAYOUTINTE, ACTUALOUTINTE,      "
				+ "     ACTUALINNERINTEFINE11,ACTUALOUTINTEFINE11, PAYINNERINTEFINE11, PAYOUTINTEFINE11,      "
				+ "       case when ACCDATE like '0%' then '2009/09/01' else ACCDATE end,      "
				+ "      PAYOFFFLAG11,INTEFINEBASE11,      "
				+ "       case when UPDATEDATE like '0%' then '2009/09/01' else UPDATEDATE end,      "
				+ "                  PAYOVERDUECORPINTE11, OVERDUECORPINTEBASE11, ORGID11,      "
				+ "        case when  FINEBASEDATE11  like '0%' then '2009/09/01' else FINEBASEDATE11 end,      "
				+ "                   WAITOVERDUECORPINTE11      "
				+ "      from (select replace(PUTOUTNO11, 'QY', 'QYICS00') as PUTOUTNO,      "
				+ "                 STERM11 as STERM,      "
				+ "                 AHEADNUM11 as AHEADNUM,      "
				+ "                 case      "
				+ "                   when PAYDATE11 like '0%' then      "
				+ "                    '2009/09/01'      "
				+ "                   else      "
				+ "                    substr(PAYDATE11, 0, 4) || '/' ||      "
				+ "                    substr(PAYDATE11, 5, 2) || '/' ||      "
				+ "                   substr(PAYDATE11, 7, 2)      "
				+ "                end as PAYDATE,      "
				+ "               CURRENCY11,      "
				+ "              GRACEPERIOD11,      "
				+ "                PAYCURRENTCORP11,      "
				+ "                ACTUALCURRENTCORP11,      "
				+ "                PAYDEFAULTCORP11,      "
				+ "                ACTUALDEFAULTCORP11,      "
				+ "                PAYOVERDUECORP11,      "
				+ "                ACTUALOVERDUECORP11,      "
				+ "                PAYINTE11,      "
				+ "                ACTUALINTE11,      "
				+ "                PAYINNERINTE11 + PAYINNERINTOD11 as PAYINNERINTE,      "
				+ "                ACTUALINNERINTE11 + ACTUALINNERINTOD11 as ACTUALINNERINTE,      "
				+ "               PAYOUTINTE11 + PAYOUTINTEFOD11 as PAYOUTINTE,      "
				+ "                ACTUALOUTINTE11 + ACTUALOUTINTEFOD11 as ACTUALOUTINTE,      "
				+ "                ACTUALINNERINTEFINE11,      "
				+ "                ACTUALOUTINTEFINE11,      "
				+ "                PAYINNERINTEFINE11,      "
				+ "                PAYOUTINTEFINE11,      "
				+ "                case      "
				+ "                  when ACCDATE11 like '0%' then      "
				+ "                   '2009/09/01'      "
				+ "                  else      "
				+ "                   substr(ACCDATE11, 0, 4) || '/' ||      "
				+ "                   substr(ACCDATE11, 5, 2) || '/' ||      "
				+ "                    substr(ACCDATE11, 7, 2)      "
				+ "                end as ACCDATE,      "
				+ "                 PAYOFFFLAG11,      "
				+ "                INTEFINEBASE11,      "
				+ "                case      "
				+ "                   when UPDATEDATE11 like '0%' then      "
				+ "                    '2009/09/01'      "
				+ "                   else      "
				+ "                    substr(UPDATEDATE11, 0, 4) || '/' ||      "
				+ "                    substr(UPDATEDATE11, 5, 2) || '/' ||      "
				+ "                    substr(UPDATEDATE11, 7, 2)      "
				+ "                 end as UPDATEDATE,      "
				+ "                 PAYOVERDUECORPINTE11,      "
				+ "                 OVERDUECORPINTEBASE11,      "
				+ "                 ORGID11,      "
				+ "                 case      "
				+ "                    when FINEBASEDATE11 like '0%' then      "
				+ "                     '2009/09/01'      "
				+ "                    else      "
				+ "                     substr(ACCDATE11, 0, 4) || '/' ||      "
				+ "                    substr(ACCDATE11, 5, 2) || '/' ||      "
				+ "                     substr(ACCDATE11, 7, 2)      "
				+ "                 end as FINEBASEDATE11,      "
				+ "                 WAITOVERDUECORPINTE11      "
				+ "             from qy_loanback_status_ics ls      "
				+ "            where ls.sterm11 <> 0      "
				+ "            and ls.paydate11<=(select replace(ploan_setup.curdeductdate,'/','') from ploan_setup)) dd ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
