package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.TransEntry;
import com.amarsoft.account.ledger.TransactionCode;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.NumberTools;
import com.amarsoft.amarscript.Any;
import com.amarsoft.amarscript.Expression;


public class QYCreateLedger extends QYTransProvider {
		
	//��ȡ����inputPara������Ӧ�Ľ��ױ�ţ���ȡ���ý�������ط�¼������ ���ɻ�Ʒ�¼
	public static ArrayList<QYLedgerDetail> getLedgerList(HashMap<String,AttributeField> inputPara,
			HashMap<String,String> LedgerSubjectHashMap) throws Exception{
		Any any = null;
		ArrayList<QYLedgerDetail> qyLedgerDetailList = new ArrayList<QYLedgerDetail>();
		//ȡ��inputPara�еĽ��׺�
		String TransNo = getTransNo(inputPara); //getStringInputPara(inputPara,"TransNo");
		//ȡ�����׺Ŷ�Ӧ�Ľ���
		TransactionCode transactionCode = new TransactionCode();
		transactionCode = LedgerSubjectConfig.getTransactionCode(TransNo);
		//ȡ���ý�����صķ�¼����
		HashMap<String, TransEntry> transEntryHashMap = transactionCode.getTransEntryHashMap();
		if (transEntryHashMap==null) return qyLedgerDetailList;
		for (Iterator<String> iter = transEntryHashMap.keySet().iterator(); iter.hasNext();){
			String key = iter.next();
			TransEntry transEntry=transEntryHashMap.get(key);		
			any = null;
			
			any = Expression.getExpressionValue(getExpression(inputPara,transEntry.getValidExpression()),null);			
			if (any.booleanValue()){
				Any any1 = Expression.getExpressionValue(getExpression(inputPara,transEntry.getAmount()),null);
				
				if(any1.doubleValue()!=0){
					QYLedgerDetail qyLedgerDetail = new QYLedgerDetail();
					qyLedgerDetail.setSerialNo(getStringInputPara(inputPara,"SerialNo")+transEntry.getSortID());
					qyLedgerDetail.setPutOutNo(getStringInputPara(inputPara,"PutOutNo"));
					qyLedgerDetail.setBillNo(getStringInputPara(inputPara,"BillNo"));
					//qyLedgerDetail.setHandStatus("1");
					qyLedgerDetail.setOccurDate(getStringInputPara(inputPara,"AccDate"));
					qyLedgerDetail.setOccurTime(DateTools.getDateTime(new Date(),"HH:mm:ss"));
					qyLedgerDetail.setOrgID(getStringInputPara(inputPara,"OrgID"));
					qyLedgerDetail.setCurrency(getStringInputPara(inputPara,"Currency"));					
					qyLedgerDetail.setTransID(transEntry.getTransID());
					qyLedgerDetail.setSortID(transEntry.getSortID());
					qyLedgerDetail.setAccountNo(transEntry.getTeamFlag());
					qyLedgerDetail.setSubjectname(transEntry.getDigest());//������Ŀ����
					if(LedgerSubjectHashMap.get(transEntry.getTeamFlag())==null)
						throw new Exception("��ݺţ�"+getStringInputPara(inputPara,"PutOutNo")+"|"+transEntry.getTeamFlag()+" û�н�����صĿ�Ŀ��");
					
					qyLedgerDetail.setSubjectNo(LedgerSubjectHashMap.get(transEntry.getTeamFlag()));
					if(qyLedgerDetail.getSubjectNo()==null)
						throw new Exception("��ݺţ�"+getStringInputPara(inputPara,"PutOutNo")+"|"+transEntry.getTeamFlag()+" �ڷֻ�����û�н�����صĿ�Ŀ��");
									
					qyLedgerDetail.setLoanWay(LedgerSubjectConfig.getSubjectLoanWay(qyLedgerDetail.getSubjectNo()));
					if(qyLedgerDetail.getLoanWay()==null)
						throw new Exception("��ݺţ�"+getStringInputPara(inputPara,"PutOutNo")+"|"+qyLedgerDetail.getSubjectNo()+" ��subject_info���д������⣡");
					
					
					if(transEntry.getDirection().equalsIgnoreCase("D")||transEntry.getDirection().equalsIgnoreCase("A")) 
						qyLedgerDetail.setDebitAmt(any1.doubleValue());
					else qyLedgerDetail.setCreditAmt(any1.doubleValue());
					
					if(transEntry.getDirection().equalsIgnoreCase("D")||transEntry.getDirection().equalsIgnoreCase("C"))
						qyLedgerDetail.setHandStatus("1");
					else qyLedgerDetail.setHandStatus("2");
					
					qyLedgerDetailList.add(qyLedgerDetail);
				}
			}
		}
		
		if(!check(qyLedgerDetailList)) throw new Exception("��ݺţ�"+getStringInputPara(inputPara,"PutOutNo")+" ��Ŀ�ʽ�������ƽ���������ñ��������Ϣ��");
		return qyLedgerDetailList;
	}
	
	public static String getTransNo(HashMap<String,AttributeField> inputPara) throws Exception{
		String TransNo = getStringInputPara(inputPara,"TransNo");
		String BusinessType = getStringInputPara(inputPara,"BusinessType");
		if("7001".equals(TransNo) || "3001".equals(TransNo))
		{
			TransNo=TransNo+"01";//���ᡢ��ת����һ������
		}
		else
		{
				TransNo=TransNo+"01";   //һ��Ľ���
		}
			
		return TransNo;
	}
	
	public static ArrayList<QYLedgerDetail> getLedgerSubjectList(HashMap<String,AttributeField> inputPara) throws Exception{
		Any any = null;
		ArrayList<QYLedgerDetail> qyLedgerDetailList = new ArrayList<QYLedgerDetail>();
		//ȡ���ý�����صķ�¼����
		HashMap<String, TransEntry> transEntryHashMap = LedgerSubjectConfig.getLedgerSubjectHashMap();
		for (Iterator<String> iter = transEntryHashMap.keySet().iterator(); iter.hasNext();){
			String key = iter.next();
			TransEntry transEntry=transEntryHashMap.get(key);		
			any = null;
			
			any = Expression.getExpressionValue(getExpression(inputPara,transEntry.getValidExpression()),null);			
			if (any.booleanValue()){
				QYLedgerDetail qyLedgerDetail = new QYLedgerDetail();
				qyLedgerDetail.setPutOutNo(getStringInputPara(inputPara,"PutOutNo"));
				qyLedgerDetail.setAccountNo(transEntry.getTeamFlag());
				qyLedgerDetail.setOrgID(getStringInputPara(inputPara,"OrgID"));
				qyLedgerDetail.setCurrency(getStringInputPara(inputPara,"Currency"));
				qyLedgerDetail.setDebitAmt(0);
				qyLedgerDetail.setCreditAmt(0);
				qyLedgerDetail.setSubjectNo(transEntry.getSubjectNo());		
				qyLedgerDetail.setSubjectname(transEntry.getDigest());//������Ŀ����
				qyLedgerDetail.setLoanWay(transEntry.getDirection());
				qyLedgerDetailList.add(qyLedgerDetail);
			}
		}		
		return qyLedgerDetailList;
	}
	
	public static String getExpression(HashMap<String,AttributeField> inputPara,String sExpression) throws Exception{
		if(sExpression==null || sExpression.equals("")) return "1=1";
		if(inputPara==null) throw new Exception("=============��");
				
		for (Iterator<String> iter = inputPara.keySet().iterator(); iter.hasNext();) {//����У�������Ȼ��У�黹�ʽ�����ĺϷ���
    	    String key = iter.next();
    	    if(!inputPara.get(key).isFieldStatus()) continue;
    	    //System.out.println("type="+inputPara.get(key).getFieldType());
    	    if(inputPara.get(key).getFieldType().equalsIgnoreCase(AccountConstants.ATTRIBUTE_FIELD_TYPE_INTEGER))
    	    	sExpression = sExpression.toUpperCase().replaceAll("#"+inputPara.get(key).getFieldID()+"#", 
    	    			String.valueOf(inputPara.get(key).getFieldIntegerValue()));
    	    else if(inputPara.get(key).getFieldType().equalsIgnoreCase(AccountConstants.ATTRIBUTE_FIELD_TYPE_DOUBLE))
    	    	sExpression = sExpression.toUpperCase().replaceAll("#"+inputPara.get(key).getFieldID()+"#", 
    	    			String.valueOf(inputPara.get(key).getFieldDoubleValue()));
    	    else if(inputPara.get(key).getFieldType().equalsIgnoreCase(AccountConstants.ATTRIBUTE_FIELD_TYPE_STRING))
    	    	sExpression = sExpression.toUpperCase().replaceAll("#"+inputPara.get(key).getFieldID()+"#", 
    	    			inputPara.get(key).getFieldStringValue());
    	    else throw new Exception("��������Ϊ"+inputPara.get(key).getFieldType()+"�Ҳ�����Ӧ�������ͣ�");
    	    
    	    if(sExpression.indexOf("#")<0) break;
    	}
		return sExpression;
	}
		
	public static boolean check(ArrayList<QYLedgerDetail> qyLedgerDetailList) throws Exception{
		QYLedgerDetail Ld = new QYLedgerDetail();
		double DebitAmt = 0;
		double CreditAmt = 0;
		String subjectNo = "";
		for(int k=0;k<qyLedgerDetailList.size();k++){
			Ld = qyLedgerDetailList.get(k);
			if(Ld.getHandStatus().equals("1")){
				subjectNo=Ld.getSubjectNo();
				if(subjectNo.startsWith("6")) continue;
				DebitAmt += Ld.getDebitAmt();
				CreditAmt += Ld.getCreditAmt();
			}
		}
		
		if(NumberTools.round(DebitAmt-CreditAmt,AccountConstants.MONEY_PRECISION)==0){ 
			return true;
		}else{
			return false;
		}
	}	
}
