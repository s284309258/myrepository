package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateBackBill extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����back_bill���ݣ�.............");
				CreateCI();
				logger.info("................����back_bill������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = " insert into back_bill  "
				+ " (PUTOUTNO,BILLNO,STERM,AHEADNUM,          "
				+ "  BILLTYPE,BILLKIND,TERM,PAYDATE,ACCDATE,  "
				+ "  CURRENCY,PAYCURRENTCORP,ACTUALCURRENTCORP,                  "
				+ "  PAYDEFAULTCORP,ACTUALDEFAULTCORP,PAYOVERDUECORP,            "
				+ "  ACTUALOVERDUECORP,PAYINTE,ACTUALINTE,PAYINNERINTE,          "
				+ "  ACTUALINNERINTE,PAYOUTINTE,ACTUALOUTINTE,PAYINNERINTEFINE,  "
				+ "  PAYOUTINTEFINE,ACTUALINNERINTEFINE,ACTUALOUTINTEFINE,POUNDAGE,                 "
				+ "  DEDUCTACCNO1,DEDUCTACCNO2,DEDUCTACCNO,SERIALNO,SENDDATE,    "
				+ "  RELATIVEBILLNO,BILLSTATUS,OPERATEUSERID,ORGID,RETURNCHANNEL,"
				+ "  ACCOUNTFLAG,OVERDUEINTE,LOANBALANCE,ACCOUNTFEE,             "
				+ "  ACCOUNTOPENFEE,LOANTRUSTFEE,ACTUALINTEFINE)                 "
				+ " select replace(PUTOUTNO11,'QY','QYICS00'),'QYICS00'||SEQ_CLEAN.NEXTVAL,              "
				+ "        STERM11,AHEADNUM11,BILLTYPE11,BILLKIND11,TERM11,      "
				+ "        substr(PAYDATE11,0,4)||'/'||substr(PAYDATE11,5,2)||'/'||substr(PAYDATE11,7,2),              "
				+ "        substr(ACCDATE11,0,4)||'/'||substr(ACCDATE11,5,2)||'/'||substr(ACCDATE11,7,2),              "
				+ "        CURRENCY11,PAYCURRENTCORP11,ACTUALCURRENTCORP11,PAYDEFAULTCORP11,        "
				+ "        ACTUALDEFAULTCORP11,PAYOVERDUECORP11,ACTUALOVERDUECORP11,PAYINTE11,      "
				+ "        ACTUALINTE11,PAYINNERINTE11,ACTUALINNERINTE11,PAYOUTINTE11,ACTUALOUTINTE11,                 "
				+ "        PAYINNERINTEFINE11,PAYOUTINTEFINE11,ACTUALINNERINTEFINE11,ACTUALOUTINTEFINE11,              "
				+ "        POUNDAGE11,DEDUCTACCNO111,DEDUCTACCNO211,DEDUCTACCNO11,SERIALNO11,SENDDATE11,               "
				+ "        RELATIVEBILLNO11,BILLSTATUS11,OPERATEUSERID11,oi.orgid,RETURNCHANNEL11,ACCOUNTFLAG11,       "
				+ "        OVERDUEINTE11,LOANBALANCE11,ACCOUNTFEE11,ACCOUNTOPENFEE11,LOANTRUSTFEE11,"
				+ "        ACTUALINTEFINE11 from qy_back_bill_ics,org_info oi where ORGID11=oi.mainframeorgid         ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
