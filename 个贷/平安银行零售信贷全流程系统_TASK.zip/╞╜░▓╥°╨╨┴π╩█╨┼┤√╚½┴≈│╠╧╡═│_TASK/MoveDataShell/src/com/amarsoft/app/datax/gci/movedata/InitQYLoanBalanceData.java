package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class InitQYLoanBalanceData extends CommonExecuteUnit {
	
	private String sDate="";
	private String sNextDate ="";
	private String sMaturityDate="";
	private String sLastDate="";
	private String createData="";
	private int commitNum=1;
	private int initnumber=0;
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������...............");
				initData();
				logger.info(".................��ʼ������������...............");
				
				logger.info(".................��ʼ��ʼ��qy_loan_balance���ݣ�...............");
				initQYBCSerialNo();
				logger.info(".................��ʼ��qy_loan_balance���ݽ�����...............");
							
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
			
	//��ʼ������QYLB����ͬ��ˮ��
	public void initQYBCSerialNo() throws Exception{
		String selMax ="update qy_loan_balance lb set lb.initqybcno=lb.putoutno ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(selMax);	
		selectSql.execute();
		
		connection.commit();
	}
	
	//���¿�ʼ����
	public void intitBegingData()throws Exception{
		String al="update loan_balance  lb set lb.begindate='0'||lb.begindate where length(begindate)=1";
		
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(al);	
		selectSql.execute();
		
		connection.commit();
	}
	
	
}
