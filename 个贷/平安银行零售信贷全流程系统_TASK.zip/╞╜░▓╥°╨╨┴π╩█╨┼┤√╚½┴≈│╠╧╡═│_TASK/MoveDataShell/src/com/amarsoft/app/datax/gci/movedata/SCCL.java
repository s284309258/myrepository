package com.amarsoft.app.datax.gci.movedata;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.lang.StringEscapeUtils;

import com.amarsoft.account.util.StringTools;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class SCCL extends CommonExecuteUnit {

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ���ļ���.............");
				Cdata1();
		
				Cdata();
				//Cdata();
				//transCodeFromRCPM("ESB","CertType","Ind05");
				logger.info("................�����ļ���ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	
	public  void CdataICS2() throws Exception{
		String fileName="D:\\ics\\04_ICS_TYPE_ACCT.TXT";
		String sLine="";
		String insertSql="insert into ics_type_acct (ACCOUNT_NO1, DEP_SEQNO1, VOUCHER_NO, DEP_TYPE, ACCOUNT_NO2) "
				+" values (?, ?, ?, ?, ?) ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(insertSql);
		
		String a1="";
		
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName),"GBK"));
		String [] lin;
		int i=0;
		int j=0;
		while((sLine = reader1.readLine())!= null){
			i++;
			lin=sLine.split("\\|");
			j++;
			logger.info("===="+j);
			for(int k=0;k<lin.length;k++){
				a1=lin[k];
				if(lin[k]!=null){
					a1=lin[k].replaceAll(" ", "");
				}else{
					a1="";				
				}
				selectSql.setString(k+1, a1);
			}
			selectSql.addBatch();
			if(i>500){
				selectSql.executeBatch();
				connection.commit(); 
				i=0;
			}
		}
		reader1.close();
		selectSql.executeBatch();
		connection.commit(); 
	}
	
	
	public  void CdataICS1() throws Exception{
		String fileName="D:\\ics\\06_ICS_HOLD_GM_CATD.TXT";
		String sLine="";
		String insertSql="insert into ics_hold_gm_catd(ICSMACACCNO,icsdaaccno,ICSACCNODES, FCRMACACCNO)values(?,?,?,?) ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(insertSql);
		
		String a1="";
		
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName),"GBK"));
		String [] lin;
		int i=0;
		int j=0;
		while((sLine = reader1.readLine())!= null){
			i++;
			lin=sLine.split("\\|");
			j++;
			logger.info("===="+j);
			for(int k=0;k<lin.length;k++){
				a1=lin[k];
				if(lin[k]!=null){
					a1=lin[k].replaceAll(" ", "");
				}else{
					a1="";				
				}
				selectSql.setString(k+1, a1);
			}
			selectSql.addBatch();
			if(i>500){
				selectSql.executeBatch();
				connection.commit(); 
				i=0;
			}
		}
		reader1.close();
		selectSql.executeBatch();
		connection.commit(); 
	}
	
	public  void Cdata1() throws Exception{
		String fileName="D:\\fcr\\CONV_OTHER_HOLD.txt";
		String sLine="";
		String insertSql="insert into fcr_conv_other_hold (COD_HOLD_NO, COD_HOLD_REF_NO, TXT_EVENT_TYPE, COD_HOLD_STATUS, COD_EVENT_ID) "
				+" values (?, ?, ?, ?, ?) ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(insertSql);
		
		String a1="";
		
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName),"GBK"));
		String [] lin;
		int i=0;
		int j=0;
		while((sLine = reader1.readLine())!= null){
			i++;
			lin=sLine.split("\\|\\|\\|");
			j++;
			logger.info("===="+j);
			for(int k=0;k<lin.length;k++){
				a1=lin[k];
				if(lin[k]!=null){
					a1=lin[k].replaceAll(" ", "");
				}else{
					a1="";				
				}
				selectSql.setString(k+1, a1);
			}
			selectSql.addBatch();
			if(i>500){
				selectSql.executeBatch();
				connection.commit(); 
				i=0;
			}
		}
		reader1.close();
		selectSql.executeBatch();
		connection.commit(); 
	}
	
	
	
	public  void Cdata() throws Exception{
		String fileName="D:\\fcr\\CONV_ACCT_HOLD.txt";
		String sLine="";
		String insertSql=" insert into FCR_CONV_ACCT_HOLD(COD_HOLD_NO,COD_HOLD_REF_NO,COD_DEP_NO,COD_HOLD_STATUS,HOLD_TYPE,COD_MC_ACCT_NO,COD_CCY,COD_CARD_NO)values(?,?,?,?,?,?,?,?)";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(insertSql);
		
		String a1="";
		String a2="";
		String a3="";
		String a4="";
		String a5="";
		String a6="";
		String a7="";
		String a8="";
		
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName),"GBK"));
		String [] lin;
		int i=0;
		int j=0;
		while((sLine = reader1.readLine())!= null){
			i++;
			lin=sLine.split("\\|\\|\\|");
			j++;
			logger.info("===="+j);
			for(int k=0;k<lin.length;k++){
				a1=lin[k];
				if(lin[k]!=null){
					a1=lin[k].replaceAll(" ", "");
				}else{
					a1="";				
				}
				selectSql.setString(k+1, a1);
			}
			selectSql.addBatch();
			if(i>500){
				selectSql.executeBatch();
				connection.commit(); 
				i=0;
			}
		}
		reader1.close();
		selectSql.executeBatch();
		connection.commit(); 
	}

}
