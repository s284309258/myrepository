package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYLock extends CommonExecuteUnit {
	private String commitNum="";
	private String messages="";
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				Lock();
				logger.info("................����ҵ��������ɣ�..............");
				
			
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum = getProperty("LockName", "");
		messages = getProperty("Messages", "");
	}
	
	public void Lock() throws Exception{
		String attribute1="";
		String al="select bl.attribute1 from batch_lock bl where bl.lockno='"+commitNum+"'";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			attribute1=rs.getString("attribute1");
		}
		rs.close();
		if(!"0".equals(attribute1)){
			throw new Exception("·����"+commitNum+"��attribute1ֵ��Ϊ0�������ڴ�ͣ :"+messages+" !");
		}
	}
}
