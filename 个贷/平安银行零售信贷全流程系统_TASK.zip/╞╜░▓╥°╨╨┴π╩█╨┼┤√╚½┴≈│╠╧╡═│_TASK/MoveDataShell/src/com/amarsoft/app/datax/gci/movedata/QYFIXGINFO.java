package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYFIXGINFO extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ�����г�����¼ѺƷ״̬�������ݣ�.............");
				UpdateGI();
				logger.info("................�����г�����¼ѺƷ״̬����������ɣ�..............");
				
				logger.info("................��ʼ�����޳�����¼ѺƷѺƷ״̬�������ݣ�.............");
				CreateData();
				logger.info("................�����޳�����¼ѺƷѺƷ״̬����������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void UpdateGI() throws SQLException{
		String al = "select ga.guarantyid,ga.status from qy_guaranty_audit ga,guaranty_info gi where ga.guarantyid=gi.guarantyid ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		String up="update guaranty_info gi set gi.manstatus='05',gi.status=? where gi.guarantyid=? ";
		PreparedStatement ups=connection.prepareStatement(up);
		int i=0,j=0;
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("status"));
			ups.setString(2, rs.getString("guarantyid"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				logger.info("................����ѺƷ״̬"+j+"���������ݣ�..............");
				i=0;
			}
		}
		rs.close();
		connection.commit();
		
	}

	public void CreateData() throws SQLException {
		String al = "select gi.guarantyid,gi.manstatus,case when lb.finishdate<='2012/10/01' then '05' else '02' end as Gstatus from "
				+ " guaranty_info gi,guaranty_relative gr,loan_balance lb where gi.guarantyid like 'QY%' "
				+ " and gi.status is null and gi.guarantyid=gr.guarantyid "
				+ " and lb.contractserialno=gr.objectno  and lb.putoutno like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		String up="update guaranty_info gi set gi.manstatus='05',gi.status=? where gi.guarantyid=? ";
		PreparedStatement ups=connection.prepareStatement(up);
		int i=0,j=0;
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("Gstatus"));
			ups.setString(2, rs.getString("guarantyid"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				logger.info("................����ѺƷ״̬"+j+"���������ݣ�..............");
				i=0;
			}
		}
		rs.close();
		connection.commit();

	}

}
