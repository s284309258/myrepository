package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateGJJPutoutno extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ���¹����������ݣ�.............");
				UpdateGJJPutoutno();
				logger.info("................���¹�������������ɣ�..............");
				

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void UpdateGJJPutoutno() throws SQLException{
		String al = "select lb.putoutno,gl.gjj_loan_no from gjj_loan_combi gl,qy_loan_balance lb where gl.mer_loan_no=lb.loan_no ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		String up="update gjj_loan_combi lg set lg.mer_loan_no=? where lg.gjj_loan_no=? ";
		PreparedStatement ups=connection.prepareStatement(up);
		int i=0,j=0;
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("putoutno"));
			ups.setString(2, rs.getString("gjj_loan_no"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				logger.info("................���¹�������"+j+"���������ݣ�..............");
				i=0;
			}
		}
		rs.close();
		ups.executeBatch();
		connection.commit();
		logger.info("................���¹�������"+j+"���������ݣ�..............");
		
	}

}
