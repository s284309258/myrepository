package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYFIXData1 extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ�޸��˻����������ݣ�.............");
				upFDData();
				logger.info("................�޸��˻�������������ɣ�..............");

				logger.info("................��ʼ�������˿ͻ����ݣ�.............");
				deleteINDData();
				logger.info("................�������˿ͻ�������ɣ�..............");

				logger.info("................��ʼ�޸����״̬���ݣ�.............");
				upINDData();
				logger.info("................�޸����״̬������ɣ�..............");
				
				logger.info("................��ʼ�޸���˾�ͻ����ݣ�.............");
				deleteENDData();
				logger.info("................�޸���˾�ͻ�������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	// ���������ݸ���Ϊ����״̬
	public void upFDData() throws SQLException {
		String al = " select fd.putoutno from fare_detail fd ,qy_loan_balance lb where fd.putoutno=lb.putoutno "
				+ " and lb.loanstatus not in ('0','1','4','5') and lb.putoutno like 'QY%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		String del = "update fare_detail fd set fd.actualmoney=fd.paymoney ,fd.offflag='1' where fd.putoutno=? ";
		PreparedStatement dps = connection.prepareStatement(del);
		ResultSet rs = ps.executeQuery();
		int i = 0, j = 0;
		while (rs.next()) {
			i++;
			j++;
			dps.setString(1, rs.getString("putoutno"));
			dps.addBatch();
			if (i >= 1000) {
				dps.executeBatch();
				connection.commit();
				i = 0;
				logger.info("................�޸���������" + j + "��ɣ�..............");
			}
		}
		rs.close();
		dps.executeBatch();
		connection.commit();
	}

	// ɾ��IND_INFO�ظ�����
	public void deleteINDData() throws SQLException {
		String al = " select ii.customerid from ind_info ii,customer_info ci where  "
				+ "   ii.customerid like 'QY%' "
				+ "    and ii.customerid=ci.customerid "
				+ "    and ci.customertype not in ('03','04') ";
		PreparedStatement ps = connection.prepareStatement(al);
		String del = "delete from ind_info ii where ii.customerid= ? ";
		PreparedStatement dps = connection.prepareStatement(del);
		ResultSet rs = ps.executeQuery();
		int i = 0, j = 0;
		while (rs.next()) {
			i++;
			j++;
			dps.setString(1, rs.getString("customerid"));
			dps.addBatch();
			if (i >= 1000) {
				dps.executeBatch();
				connection.commit();
				i = 0;
				logger.info("................�޸����˿ͻ�����" + j + "��ɣ�..............");
			}
		}
		rs.close();
		dps.executeBatch();
		connection.commit();
	}

	// ɾ��END_INFO�ظ�����
	public void deleteENDData() throws SQLException {
		String al = " select ii.customerid "
				+ "  from ent_info ii, customer_info ci "
				+ "   where ii.customerid like 'QY%' "
				+ "     and ii.customerid = ci.customerid "
				+ "     and ci.customertype <>'05'";
		PreparedStatement ps = connection.prepareStatement(al);
		String del = "delete from ent_info ii where ii.customerid= ? ";
		PreparedStatement dps = connection.prepareStatement(del);
		ResultSet rs = ps.executeQuery();
		int i = 0, j = 0;
		while (rs.next()) {
			i++;
			j++;
			dps.setString(1, rs.getString("customerid"));
			dps.addBatch();
			if (i >= 1000) {
				dps.executeBatch();
				connection.commit();
				i = 0;
				logger.info("................�޸���˾�ͻ�����" + j + "��ɣ�..............");
			}
		}
		rs.close();
		dps.executeBatch();
		connection.commit();
	}

	// �޸�IND_INFO���״̬����
	public void upINDData() throws SQLException {
		String al = " select Marriage from  "
				+ " (select distinct Marriage from ind_info ii where ii.customerid like 'QY%' ) dd where not exists (  "
				+ " select cl.codeno,cl.itemno  from code_library cl where cl.codeno='Marriage' and cl.isinuse='1' and dd.marriage=cl.itemno) ";
		PreparedStatement ps = connection.prepareStatement(al);
		String del = " update ind_info ii set ii.marriage='20' where ii.marriage=? ";
		PreparedStatement dps = connection.prepareStatement(del);
		ResultSet rs = ps.executeQuery();
		String ads = "";
		while (rs.next()) {
			ads = "";
			if (rs.getString("Marriage") == null) {
				ads = "";
			} else {
				ads = rs.getString("Marriage");
			}
			dps.setString(1, ads);
			dps.addBatch();
			dps.executeBatch();
			connection.commit();

		}
		rs.close();
	}

}
