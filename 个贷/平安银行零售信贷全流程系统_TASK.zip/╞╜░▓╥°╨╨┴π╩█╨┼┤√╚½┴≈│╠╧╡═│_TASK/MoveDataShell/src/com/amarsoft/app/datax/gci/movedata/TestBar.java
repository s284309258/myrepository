package com.amarsoft.app.datax.gci.movedata;

import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.ConnectionManager;
import com.amarsoft.are.sql.Transaction;

public class TestBar {

	//������ǰ׺
    private static String barNOPrefix ="KB00029";

    //���ݿ����Ӵ�
	public static Transaction getSqlca() throws Exception {
		String sUrl = "jdbc:oracle:thin:@10.25.17.143:1598:d2bloan";
		//String sUrl = "jdbc:oracle:thin:@10.25.17.143:1621:bbbloan";
		String sDriverName = "oracle.jdbc.driver.OracleDriver";
		String sUserName = "rcpmopr";
		String sUserPass = "paic1234";
		return ConnectionManager.getTransaction(sUrl, sDriverName, sUserName, sUserPass);

	}
	
	//����µ�������
	public static String getBarCodeNo(int startI){
		String barNO = "";
		int startILength = String.valueOf(startI).length();
		
		barNO = getZero(7-startILength) + startI;
		
		return barNOPrefix+barNO;
	}
	
	//���ǰ��0
	public static String getZero(int len){
		String str = "";
		for(int i=0;i<len;i++){
			str=str+"0";
		}
		
		return str;
	}
	
	public static void main(String[] args) throws Exception {
			
			String serialno = ""; //��ͬ��
			String bar_code_no = "";//�ϵ�������
			String new_code_no = "";//�µ�������
			int startI= 0; //�µ����������
		
	        Transaction Sqlca = getSqlca();
	        
	        String sql = "SELECT  bar_code_no,serialno FROM qy_business_contract";
	        System.out.println("ִ�е�SQL��"+sql);
	        ASResultSet asrs = Sqlca.getResultSet(sql);
	        try {
				Sqlca.conn.setAutoCommit(false);
				while(asrs.next()){
					startI++;
					
					serialno = asrs.getString("serialno");
					bar_code_no = asrs.getString("bar_code_no");
					new_code_no = getBarCodeNo(startI);
					
					//���bar_code_noΪ�ղŸ���
					if(null==bar_code_no||"".equals(bar_code_no)){
						sql="update qy_business_contract bc set bc.bar_code_no='"+new_code_no+"' where bc.serialno='"+serialno+"' ";
						System.out.println("ִ�е�SQL��"+sql);
						Sqlca.executeSQL(sql);
					}
				}
				
				Sqlca.conn.commit();
				asrs.close();
			} catch (Exception e) {
				Sqlca.conn.rollback();
				throw new Exception("updateBarCode...ʧ�ܣ�" + e.getMessage());
			}
	}
}
