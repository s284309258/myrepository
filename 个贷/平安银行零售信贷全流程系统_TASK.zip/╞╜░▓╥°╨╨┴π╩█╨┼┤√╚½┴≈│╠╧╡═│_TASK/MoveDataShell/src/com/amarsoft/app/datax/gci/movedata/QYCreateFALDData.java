package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFALDData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼɾ��LD��ִ����ݣ�.............");
				DeleteALLData();				
				logger.info("................ɾ��LD��ִ����ݽ�����..............");
				
				logger.info("................��ʼ���ɴ�ִ�LG��Ŀ���ݣ�.............");
				CreateLGData();
				logger.info("................���ɴ�ִ�LG��Ŀ��ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
	public void DeleteALLData() throws SQLException{
		String al="delete from qy_ledger_detail where putoutno like 'DL%' ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void CreateLGData() throws SQLException{
		int i=0,j=0;
		String al="  select lg.putoutno,'' as BILLNO ,'99999' as TRANSID,'99' as SORTID,'' as OCCURTIME,'"+deductDate
				+"' as OCCURDATA,lg.currency,lg.subjectno,  "
				+" lg.creditbalance ,lg.debitbalance,'1' as HANDSTATUS,lg.orgid,lg.serialno    "
				+" from qy_ledger_general lg where (lg.creditbalance<>0 or lg.debitbalance<>0)  "
				+" and lg.putoutno like 'DL%' ";
		
		String insert=" insert into qy_ledger_detail(putoutno,billno,transid,sortid,occurtime,occurdate," 
				+" currency,subjectno,creditamt,debitamt,handstatus,orgid,serialno) " 
				+" values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inst=connection.prepareStatement(insert);
			
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inst.setString(1, rs.getString("putoutno"));
			inst.setString(2, rs.getString("BILLNO"));
			inst.setString(3, rs.getString("TRANSID"));
			inst.setString(4, rs.getString("SORTID"));
			inst.setString(5, rs.getString("OCCURTIME"));
			inst.setString(6, rs.getString("OCCURDATA"));
			inst.setString(7, rs.getString("currency"));
			inst.setString(8, rs.getString("subjectno"));
			inst.setDouble(9, rs.getDouble("creditbalance"));
			inst.setDouble(10, rs.getDouble("debitbalance"));
			inst.setString(11, rs.getString("HANDSTATUS"));
			inst.setString(12, rs.getString("orgid"));
			inst.setString(13, rs.getString("serialno"));
			inst.addBatch();
			
			if(i>1000){
				inst.executeBatch();
				connection.commit();
				i=0;
				logger.info("...........���� "+j+" ������..............");
			}
		}
		inst.executeBatch();
		connection.commit();
		rs.close();
		
	}
	

}
