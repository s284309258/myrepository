package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFeeLGData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����֧��̯������LG�������ݣ�.............");
				CreateLGData1();
				logger.info("................����֧������LG����������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateLGData1() throws SQLException{
		String al="	insert into qy_ledger_general(PUTOUTNO,SUBJECTNO,ORGID,CURRENCY,CREDITBALANCE,DEBITBALANCE,ACCOUNTNO,SERIALNO,DIRECTION,SUBJECTNAME)   "
				+" select 'QYF'||f.serialno  as putoutno,qr.subjectno as subjectn,(select oi.orgid from org_info oi where oi.mainframeorgid=f.orgid) as orgid,f.currency, 0.0 as creditbalance,nvl(f.amount,0)-nvl(f.finishamt,0) as debitbalance,   "
				+" qr.teamflag as accountno ,'QYF'||f.serialno||qr.subjectno as serialno,qr.direction,qr.digest as subjectname from qy_acct_fee_detail f,QY_FEE_SDB_PAB_SUBJECT q,qy_loan_subject_rule qr      "
				+" where f.csubjectno=q.sdbsubject and qr.subjectno=q.pabsubject   "
				+" and f.feetype in ('810','820','830','840','850','860','870')     "
				+"  union   "
				+"  select 'QYF'||f.serialno as putoutno,qr.subjectno as subjectno,(select oi.orgid from org_info oi where oi.mainframeorgid=f.orgid) as orgid,f.currency, 0.0  as creditbalance, 0.0 as debitbalance,qr.teamflag as accountno,  "
				+"  'QYF'||f.serialno||qr.subjectno as serialno, qr.direction,qr.digest as subjectname from qy_acct_fee_detail f,QY_FEE_SDB_PAB_SUBJECT q,qy_loan_subject_rule qr     "
				+"  where f.csubjectno=q.sdbsubject and qr.subjectno=q.dsubjectno    "
				+"  and f.feetype in ('810','820','830','840','850','860','870')  "
				+"  union     "
				+"  select 'QYF'||f.serialno as putoutno,'4031503' as subjectno,(select oi.orgid from org_info oi where oi.mainframeorgid=f.orgid) as orgid,f.currency, nvl(f.amount,0)-nvl(f.finishamt,0) as creditbalance, 0.0 as debitbalance,'404' as accountno,  "
				+"  'QYF'||f.serialno||'4031503' as serialno, 'C' as direction,'�����Ŵ�-ICSϵͳ������' as subjectname from qy_acct_fee_detail f,QY_FEE_SDB_PAB_SUBJECT q,qy_loan_subject_rule qr   "
				+"  where f.csubjectno=q.sdbsubject and qr.subjectno=q.pabsubject     "
				+"  and f.feetype in ('810','820','830','840','850','860','870')  ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
		
	

	
		
}
