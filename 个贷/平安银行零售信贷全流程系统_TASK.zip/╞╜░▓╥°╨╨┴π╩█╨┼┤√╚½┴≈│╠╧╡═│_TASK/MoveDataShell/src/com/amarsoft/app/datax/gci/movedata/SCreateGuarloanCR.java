package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class SCreateGuarloanCR extends CommonExecuteUnit {
	

	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				//CreateLBdata();
				CreateLBdata1();
				logger.info("................����ҵ��������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void CreateLBdata() throws SQLException{
		
		String insertSql=" insert into QY_GUAR_LOAN_CR (QYTYPE,GI_GUARANTYID,LB_PUTOUT_NO,BC_SERIALNO )values(?,?,?,?) ";
		PreparedStatement insertPS;
		insertPS=connection.prepareStatement(insertSql);
		
		String selectSql="select lb.putoutno from qy_loan_balance lb where lb.contractserialno='SDBCONTNO' ";
		PreparedStatement selectPS;
		selectPS=connection.prepareStatement(selectSql);
		
		ResultSet rs=selectPS.executeQuery();
		
		int i=0;
		int j=0;
		while(rs.next()){
			i++;
			j++;
			insertPS.setString(1, "LN");
			insertPS.setString(2, rs.getString("putoutno"));
			insertPS.setString(3, rs.getString("putoutno"));
			insertPS.setString(4, "");
			insertPS.addBatch();
			if(i==commitNum){
				insertPS.executeBatch();
				connection.commit();
				i=0;
				logger.info("................���ɽ��ѺƷ���� "+j+" ��..............");
			}
			
		}
		insertPS.executeBatch();
		connection.commit();
		rs.close();
	}
	
	public void CreateLBdata1() throws Exception{
		String insertSql=" insert into QY_GUAR_LOAN_CR (QYTYPE,GI_GUARANTYID,LB_PUTOUT_NO,BC_SERIALNO )values(?,?,?,?) ";
		PreparedStatement insertPS;
		insertPS=connection.prepareStatement(insertSql);
		
		String selectSql="select lb.Contractserialno from qy_loan_balance lb where lb.contractserialno<>'SDBCONTNO' ";
		PreparedStatement selectPS;
		selectPS=connection.prepareStatement(selectSql);
		
		ResultSet rs=selectPS.executeQuery();
		
		int i=0;
		int j=0;
		while(rs.next()){
			i++;
			j++;
			insertPS.setString(1, "CR");
			insertPS.setString(2, rs.getString("Contractserialno"));
			insertPS.setString(3, "");
			insertPS.setString(4, rs.getString("Contractserialno"));
			insertPS.addBatch();
			if(i==commitNum){
				insertPS.executeBatch();
				connection.commit();
				i=0;
				logger.info("................���ɺ�ͬѺƷ���� "+j+" ��..............");
			}
			
		}
		insertPS.executeBatch();
		connection.commit();
		rs.close();
	}
		
	
}
