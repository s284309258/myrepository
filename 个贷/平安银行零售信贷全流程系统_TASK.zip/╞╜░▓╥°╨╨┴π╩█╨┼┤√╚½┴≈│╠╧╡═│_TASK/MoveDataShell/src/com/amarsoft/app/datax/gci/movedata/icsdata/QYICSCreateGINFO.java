package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateGINFO  extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
        //    OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����icsѺƷ���ݣ�.............");
				CreateCI();
				logger.info("................����icsѺƷ������ɣ�..............");
							
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	public void CreateCI() throws SQLException{
		String al="insert into GUARANTY_INFO                                                                          "
				+"  (GUARANTYID,GUARANTYTYPE,OWNERID,OWNERNAME,OWNERTYPE,RIGHTID,OTHERRIGHTID,                       "
				+"   GUARANTYNAME,LOCATION,AMOUNT,GUARANTYDATE,OWNDATE,DESCRIPT,PURPOSE,GUARANTYPRICE,               "
				+"   EVALMETHOD,EVALORGID,EVALORGNAME,EVALDATE,EVALNETVALUE,CONFIRMVALUE,FLAG1,FLAG2,                "
				+"   REGORG, REGDATE, WODATE,OTHERASSUMPSIT,INPUTORGID,INPUTUSERID,INPUTDATE,                        "
				+"   UPDATEUSERID,UPDATEDATE,REMARK,CURRENCY,EVALCURRENCY,DATAFLAG,STOREINDEX,                       "
				+"   FILEINDEXNO,HOUSEAREA,INSURNO,INSURSUM,ASSURENAME,DATE1,DATE2,SIGNORG,                          "
				+"   DATE3,DATE4,OPENORG,HOUSETYPE,REGUSER,MANSTATUS,DISPATCHDATE,STATUS,REPORTFLAG)                 "
				+"  select distinct replace(GUARANTYID00,'QY','QYICS'),                                              "
				+"         case when GUARANTYTYPE00='000000' then '030150' else GUARANTYTYPE00 end,                  "
				+"         replace(OWNERID00,'QY','QYICS'), OWNERNAME00,OWNERTYPE00,RIGHTID00,OTHERRIGHTID00,        "
				+"         GUARANTYNAME00,LOCATION00,AMOUNT00,'','',DESCRIPT00,PURPOSE00,GUARANTYPRICE00,            "
				+"         '03',EVALORGID00,EVALORGNAME00,'',EVALNETVALUE00,CONFIRMVALUE00,FLAG100,FLAG200,          "
				+"         '','','',OTHERASSUMPSIT00,'','','',UPDATEUSERID00,'',REMARK00,CURRENCY00,EVALCURRENCY00,  "
				+"         '2',STOREINDEX00,FILEINDEXNO00,HOUSEAREA00,INSURNO00,INSURSUM00,ASSURENAME00,             "
				+"         '','','','','','','',REGUSER00,'04','',STATUS00,''                                        "
				+"    from QY_GUARANTY_INFO_ICS                                                                      ";
		PreparedStatement ps =connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
