package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYSaveCustomerData extends CommonExecuteUnit {


	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ������˿ͻ����ݣ�.............");
				UpdateBecifSDB();
				logger.info("................������˿ͻ�������ɣ�..............");
							
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	/**
	 * ����SDB�������˿ͻ�����
	 * @throws SQLException
	 */
	public void UpdateBecifSDB() throws SQLException{
		int i=0,j=0;
		String selectD="       select qi.customerid,qb.SOURCE_ID,qb.BECIF_NO,qb.CUST_NO,      "
				+"       qb.NAME,qb.SEX_CD,qb.BIRTH_DATE,qb.ID_TYPE_CD,qb.ID_NO,        "
				+"       qb.ID_NO_1,qb.CUST_TYPE,qb.IDENTIFY_RULE,qb.REMARK,qb.ISS_CTRY,"
				+"       qb.PROF_CDE,qb.IDSY_PFSN,qb.FIN_CTRL_LVL,qb.MATRL_STS,         "
				+"       qb.EDUCAT_LVL,qb.EMPR,qb.ALIAS_NAM,qb.PF_STAFF,qb.HOME_ADDR,   "
				+"       qb.HOME_ZIP_CDE,qb.WORK_ADDR, qb.WORK_ZIP_CDE,qb.COMM_ADDR,    "
				+"       qb.HOME_TEL,qb.MOBILE,qb.WORK_TEL,qb.PHONE1_EXT,qb.EMAIL_ADDR, "
				+"       qb.VALID_ID_NO,qb.CREATED_BY,qb.CREATED_DATE,qb.UPDATED_BY,qb.UPDATED_DATE "
				+"  from tempintf.retail_perloan_mapping qb, qy_customer_info qi        "
				+" where qb.source_id =qi.source_id        ";
		String insertD="insert into retail_perloan_mapping (CUSTOMERID,SOURCE_ID,BECIF_NO,CUST_NO,NAME,SEX_CD,BIRTH_DATE,ID_TYPE_CD,   "
				+"  ID_NO,ID_NO_1,CUST_TYPE,IDENTIFY_RULE,REMARK,ISS_CTRY,PROF_CDE,IDSY_PFSN,FIN_CTRL_LVL,   "
				+"  MATRL_STS,EDUCAT_LVL,EMPR,ALIAS_NAM,PF_STAFF,HOME_ADDR,HOME_ZIP_CDE,WORK_ADDR,WORK_ZIP_CDE,   "
				+"  COMM_ADDR,HOME_TEL,MOBILE,WORK_TEL,PHONE1_EXT,EMAIL_ADDR,VALID_ID_NO,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATED_DATE)values   "
				+"  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";		
		
		PreparedStatement insert = connection.prepareStatement(insertD);
		
		PreparedStatement ps = connection.prepareStatement(selectD);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			insert.setString(1, rs.getString("customerid")) ;
			insert.setString(2, rs.getString("SOURCE_ID")) ;
			insert.setString(3, rs.getString("BECIF_NO")) ;
			insert.setString(4, rs.getString("CUST_NO")) ;
			insert.setString(5, rs.getString("NAME")) ;
			insert.setString(6, rs.getString("SEX_CD")) ;
			insert.setString(7, rs.getString("BIRTH_DATE")) ;
			insert.setString(8, rs.getString("ID_TYPE_CD")) ;
			insert.setString(9, rs.getString("ID_NO")) ;
			insert.setString(10, rs.getString("ID_NO_1")) ;
			insert.setString(11, rs.getString("CUST_TYPE")) ;
			insert.setString(12, rs.getString("IDENTIFY_RULE")) ;
			insert.setString(13, rs.getString("REMARK")) ;
			insert.setString(14, rs.getString("ISS_CTRY")) ;
			insert.setString(15, rs.getString("PROF_CDE")) ;
			insert.setString(16, rs.getString("IDSY_PFSN")) ;
			insert.setString(17, rs.getString("FIN_CTRL_LVL")) ;
			insert.setString(18, rs.getString("MATRL_STS")) ;
			insert.setString(19, rs.getString("EDUCAT_LVL")) ;
			insert.setString(20, rs.getString("EMPR")) ;
			insert.setString(21, rs.getString("ALIAS_NAM")) ;
			insert.setString(22, rs.getString("PF_STAFF")) ;
			insert.setString(23, rs.getString("HOME_ADDR")) ;
			insert.setString(24, rs.getString("HOME_ZIP_CDE")) ;
			insert.setString(25, rs.getString("WORK_ADDR")) ;
			insert.setString(26, rs.getString("WORK_ZIP_CDE")) ;
			insert.setString(27, rs.getString("COMM_ADDR")) ;
			insert.setString(28, rs.getString("HOME_TEL")) ;
			insert.setString(29, rs.getString("MOBILE")) ;
			insert.setString(30, rs.getString("WORK_TEL")) ;
			insert.setString(31, rs.getString("PHONE1_EXT")) ;
			insert.setString(32, rs.getString("EMAIL_ADDR")) ;
			insert.setString(33, rs.getString("VALID_ID_NO")) ;
			insert.setString(34, rs.getString("CREATED_BY")) ;
			insert.setString(35, rs.getString("CREATED_DATE")) ;
			insert.setString(36, rs.getString("UPDATED_BY")) ;
			insert.setString(37, rs.getString("UPDATED_DATE")) ;
			insert.addBatch();
			if(i>999){
				insert.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"�����˿ͻ�������ɣ�..............");
			}
			
		}
		insert.executeBatch();
		connection.commit();
		rs.close();
				
	}
	

	

}
