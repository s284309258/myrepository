package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateBCSale extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ���º�ͬ��Ӫ����Ա���ݣ�.............");
				updateBCSales();
				logger.info("................���º�ͬ��Ӫ����Ա������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void updateBCSales() throws SQLException{
		int i=0,j=0;
		String al="select bc.serialno as bcno,sm.serialno as smno from sale_manager sm,business_contract bc where sm.workid=bc.operateuserid and bc.serialno like  'QY%' ";
		PreparedStatement ps=connection.prepareStatement(al);
		String up="update business_contract bc set bc.operateuserid=?  where bc.serialno=? ";
		PreparedStatement ups=connection.prepareStatement(up);
		ResultSet rs =ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			ups.setString(1, rs.getString("smno"));
			ups.setString(2, rs.getString("bcno"));
			ups.addBatch();
			if(i>=1000){
				ups.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"��������ɣ�..............");
			}
		}
		rs.close();
		ups.executeBatch();
		connection.commit();
		logger.info("................����"+j+"��������ɣ�..............");
	
	}
	
}
