package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCFINANCE extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateData();
				logger.info("................����ҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	// public void CreateData() throws SQLException{
	// CallableStatement cs =connection.prepareCall("call QY_CFINANCE_106PR()");
	// //ִ�д洢����
	// cs.execute();
	// cs.close();
	// }

	public void CreateData() throws SQLException {
		String al = "insert into qy_customer_finance(  "
				+ "  SERIALNO,OBJECTNO,OBJECTTYPE,CUSTOMERID,FAMILYADD,  "
				+ "    FAMILYZIP,EMAILADD,FAMILYTEL,MOBILETELEPHONE,FAMILYSTATUS,OWNOTHERPROPERTY,  "
				+ "    CHILDFLAG,LOCALYEAR,FIRSTTEL,FIRSTEMAIL,MONTHINCOME,MONTHCASHOUT,INSURFLAG,  "
				+ "    SOCIALINSURANCEFLAG,LOCALHOUSEFLAG,HOUSEZONE,HOUSEAREA,FAMILYASSET,PROPERTYSETES,CORPEXTENSION)   "
				+ "      select   "
				+ "     'QY20121030'||SEQ_CLEAN.NEXTVAL  as  SERIALNO,  "
				+ "     bc.serialno  as  OBJECTNO,  "
				+ "     'SWContractApply'  as  OBJECTTYPE,  "
				+ "     bc.CUSTOMERID  as  CUSTOMERID,  "
				+ "     ii.FAMILYADD  as  FAMILYADD,  "
				+ "     ii.FAMILYZIP  as  FAMILYZIP,  "
				+ "     ii.EMAILADD  as  EMAILADD,  "
				+ "     ii.FAMILYTEL  as  FAMILYTEL,  "
				+ "     ii.MOBILETELEPHONE  as  MOBILETELEPHONE,  "
				+ "     ii.FAMILYSTATUS  as  FAMILYSTATUS,  "
				+ "     ii.OWNOTHERPROPERTY  as  OWNOTHERPROPERTY,  "
				+ "    ii.CHILDFLAG  as  CHILDFLAG,  "
				+ "     ii.LOCALYEAR  as  LOCALYEAR,  "
				+ "    ii.FIRSTTEL  as  FIRSTTEL,  "
				+ "    ii.FIRSTEMAIL  as  FIRSTEMAIL,  "
				+ "    ii.SELFMONTHINCOME  as  MONTHINCOME,  "
				+ "    ii.MONTHCASHOUT  as  MONTHCASHOUT,  "
				+ "     ii.INSURFLAG  as  INSURFLAG,  "
				+ "    ii.SOCIALINSURANCEFLAG  as  SOCIALINSURANCEFLAG,  "
				+ "    ii.LOCALHOUSEFLAG  as  LOCALHOUSEFLAG,  "
				+ "     ii.HOUSEZONE  as  HOUSEZONE,  "
				+ "    ii.HOUSEAREA  as  HOUSEAREA,  "
				+ "    ii.FAMILYASSET  as  FAMILYASSET,  "
				+ "    ii.PROPERTYSETES  as  PROPERTYSETES,  "
				+ "    ii.CORPEXTENSION  as  CORPEXTENSION  "
				+ "    from qy_ind_info ii,qy_business_contract bc  "
				+ "    where ii.customerid=bc.customerid  "
				+ "    and bc.businesstype like '2%'  "
				+ "    AND bc.businesskind='SWPM' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}

}
