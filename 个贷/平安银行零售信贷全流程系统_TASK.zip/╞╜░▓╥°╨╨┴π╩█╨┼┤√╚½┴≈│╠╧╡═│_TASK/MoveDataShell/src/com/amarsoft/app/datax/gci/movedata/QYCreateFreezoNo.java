package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateFreezoNo extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���½������ݣ�.............");
				CreateData();
				logger.info("................���½���������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0;
		String al=" select ci.serialno,fr.cod_hold_ref_no "
				+"  from CAPITALCONTROL_INFO CI,fcr_conv_acct_hold fr where  ci.flag='1'  "
				+"   and fr.cod_card_no=ci.acct_no and fr.cod_hold_no=ci.freeze_no  "
				+"   and fr.hold_type = '0' ";
		String insertSql="update CAPITALCONTROL_INFO ci set freeze_no=? where serialno=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("cod_hold_ref_no"));
			inps.setString(2, rs.getString("serialno"));
	
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		inps.close();
		ps.close();
		rs.close();
	}
	
	
	
}
