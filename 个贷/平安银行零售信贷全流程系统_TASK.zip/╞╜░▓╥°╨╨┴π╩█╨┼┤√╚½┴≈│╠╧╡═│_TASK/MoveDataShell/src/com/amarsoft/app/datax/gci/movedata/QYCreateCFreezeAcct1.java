package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCFreezeAcct1 extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���뱣֤���ʺ�ֹ��������ݣ�.............");
				CreateData();
				logger.info("................���뱣֤���ʺ�ֹ�����������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0,k=1000000;
		String al="select nvl(lq.fcr_mac_no, lq.guar_ac_no) as accno, nvl(lq.fcr_ac_des, lq.guar_ac_des)  as des from qy_ls_proj_guar lq";
		String insertSql="insert into credit_freeze_acct(serialno,freezeacctno,freezeno,depositserialno,status,updatedate,freezestatus) "
				+" values(?,?,?,?,?,?,?) ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			k++;
			inps.setString(1, "QYA"+k);
			inps.setString(2, rs.getString("accno"));
			inps.setString(3, "");
			inps.setString(4, rs.getString("des"));
			inps.setString(5, "1");
			inps.setString(6, deductDate);
			inps.setString(7, "A");
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		ps.close();
		inps.close();
		rs.close();
	}
	
	
	
}
