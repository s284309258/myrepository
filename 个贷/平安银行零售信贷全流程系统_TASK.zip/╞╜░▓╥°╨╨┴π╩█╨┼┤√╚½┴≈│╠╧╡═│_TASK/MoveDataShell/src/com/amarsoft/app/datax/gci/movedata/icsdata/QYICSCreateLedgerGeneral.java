package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

/**
 * ����ICS����qy_ledger_general_ics������
 * 
 * @author EX-SHISHENGHUA001
 * 
 */
public class QYICSCreateLedgerGeneral extends CommonExecuteUnit {
	private String commitNum = "";

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����qy_ledger_general_icsҵ�����ݣ�.............");
				CreateData();
				CreateBD();
				UpdateD();
				UpdateD1();
				UpdateD2();
				UpdateD3();
				// UpdateD4();
				Update5();
				CreateLG1();
				logger.info("................����qy_ledger_general_icsҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateData() throws Exception {
		String al = " insert into qy_ledger_general_ics(PUTOUTNO,SUBJECTNO,ORGID,CURRENCY,CREDITBALANCE,DEBITBALANCE,ACCOUNTNO,SERIALNO,DIRECTION,SUBJECTNAME)"
				+ " select lb.putoutno,   "
				+ "       qr.subjectno,  "
				+ "       lb.orgid,      "
				+ "       lb.currency,   "
				+ "       decode(qr.direction,'D',              "
				+ "  decode(lb.loanstatus,       "
				+ "  '0',decode(qr.teamflag,     "
				+ "          '132',0.0,          "
				+ "          '133', 0.0,         "
				+ "          '403',0.0,          "
				+ "          '404',0.0,   "
				+ "          '501',0.0,          "
				+ "          '608',0.0,          "
				+ "          '609',0.0,          "
				+ "          '621',0.0,          "
				+ "          '622',0.0,          "
				+ "          0.0),"
				+ "  '1',decode(qr.teamflag,     "
				+ "          '132',0.0,          "
				+ "          '133', 0.0,         "
				+ "          '403',0.0,          "
				+ "          '404',0.0,   "
				+ "          '501',0.0,          "
				+ "          '608',0.0,          "
				+ "          '609',0.0,          "
				+ "          '621',0.0,          "
				+ "          '622',0.0,          "
				+ "          0.0),"
				+ "  '4',decode(qr.teamflag,     "
				+ "          '132',0.0,          "
				+ "          '133', 0.0,         "
				+ "          '403',0.0,          "
				+ "          '404',0.0,          "
				+ "          '501',0.0,          "
				+ "          '608',0.0,          "
				+ "          '609',0.0,          "
				+ "          '621',0.0,          "
				+ "          '622',0.0,          "
				+ "          0.0),"
				+ "  '5',decode(qr.teamflag,     "
				+ "          '132',0.0,          "
				+ "          '133', 0.0,         "
				+ "          '403',0.0,          "
				+ "          '404',0.0,          "
				+ "          '501',0.0,          "
				+ "          '608',0.0,          "
				+ "          '609',0.0,          "
				+ "          '621',0.0,          "
				+ "          '622',0.0,          "
				+ "          0.0),"
				+ "  0.0),"
				+ "   decode(lb.loanstatus,      "
				+ "  '0',decode(qr.teamflag,     "
				+ "            '132',0.0,"
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0, "
				+ "            '501',0.0,     "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '1',decode(qr.teamflag,     "
				+ "            '132', 0.0,       "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0, "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,      "
				+ "            '622',0.0,             "
				+ "            0.0),             "
				+ "  '4',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,           "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '5',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,           "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  0.0) "
				+ "       ) as CREDITBALANCE,    "
				+ "       decode(qr.direction,'C',              "
				+ "  decode(lb.loanstatus,       "
				+ "  '0',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,           "
				+ "            0.0),             "
				+ "  '1',decode(qr.teamflag,     "
				+ "            '132', 0.0,       "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '4',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0, "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '5',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0, "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  0.0),"
				+ "   decode(lb.loanstatus,      "
				+ "    '0',decode(qr.teamflag,   "
				+ "            '132',0.0,     "
				+ "            '133', 0.0,"
				+ "            '403',0.0,        "
				+ "            '404',0.0, "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '1',decode(qr.teamflag,     "
				+ "            '132', 0.0,       "
				+ "            '133', 0.0,"
				+ "            '403',0.0,        "
				+ "            '404',0.0, "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '4',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  '5',decode(qr.teamflag,     "
				+ "            '132',0.0,        "
				+ "            '133', 0.0,       "
				+ "            '403',0.0,        "
				+ "            '404',0.0,        "
				+ "            '501',0.0,        "
				+ "            '608',0.0,        "
				+ "            '609',0.0,        "
				+ "            '621',0.0,        "
				+ "            '622',0.0,        "
				+ "            0.0),             "
				+ "  0.0) "
				+ "       )  as DEBITBALANCE,    "
				+ "       qr.teamflag as ACCOUNTNO,             "
				+ "       'QIS'||lb.putoutno||qr.subjectno as SERIALNO,            "
				+ "       qr.direction,  "
				+ "       qr.digest as SUBJECTNAME              "
				+ "  from qy_loan_subject_rule qr,              "
				+ "       (select replace(qc.putoutno11,'QY','QYICS00') as putoutno ,             "
				+ " case when qc.businesstype11='99999' then         "
				+ " '1190030'     "
				+ " else   "
				+ " '1200010'     "
				+ " end    "
				+ " as businesstype,             "
				+ " '10000000' as businesssubtype,"
				+ " qc.loanterm11 as loanterm,    "
				+ " qc.loanstatus11 as loanstatus,"
				+ " oi.orgid,      "
				+ " qc.currency11 as currency,    "
				+ " qc.normalbalance11 + qc.overduebalance11 as balance,            "
				+ " qc.intebase11 as intebase,    "
				+ " qc.periodinte11 as periodinte,"
				+ " qc.PAYINNERINTE11 as PAYINNERINTE,"
				+ " qc.PAYINNERINTEFINE11 as PAYINNERINTEFINE,       "
				+ " qc.PAYOUTINTE11 as PAYOUTINTE,"
				+ " qc.PAYOUTINTEFINE11 as PAYOUTINTEFINE,           "
				+ "case   "
				+ "  when qc.customertype11 <> '0003' then          "
				+ "   '010'       "
				+ "  else "
				+ "   '020'       "
				+ "end as customertype,          "
				+ "qc.bankflag11 as bankflag     "
				+ "          from qy_loan_balance_ics qc, org_info oi              "
				+ "         where qc.orgid11 = oi.mainframeorgid(+) "
				+ "    ) lb        "
				+ "   where ((qr.businesstype like '%' || lb.businesstype || '%') or              "
				+ "       (qr.businesstype = 'all'))            "
				+ " and ((qr.businesssubtype like '%' || lb.businesssubtype || '%') or            "
				+ "       (qr.businesssubtype = 'all'))         "
				+ "   and lb.loanterm > qr.minloanterm          "
				+ "   and lb.loanterm <= qr.maxloanterm         "
				+ "   and (qr.customertype = lb.customertype or qr.customertype = 'all')          "
				+ "   and qr.status = '1'"
				+ "   order by lb.putoutno,qr.subjectno        ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	public void CreateBD() throws SQLException {
		String al = "insert into qy_ledger_general_ics(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+ " select replace(ql.putoutno,'QY','QYICS00') ,qm.pabsubjectno,oi.orgid,ql.currency,0.0,0.0,qm.pabaccno,'QYICS'||ql.putoutno||qm.pabsubjectno,qm.DIRECTION,qm.pabsubjectname  "
				+ " from qy_ics_subjectno_map qm,qy_pab_ledger_general_ics ql,org_info oi "
				+ " where qm.icssubjectno=ql.subjectno and ql.orgid=oi.mainframeorgid ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ���±������������--ok
	public void UpdateD() throws SQLException {
		String al = "select lb.normalbalance11+lb.overduebalance11 as ATME,replace(lb.putoutno11,'QY','QYICS00') as putoutno from qy_loan_balance_ics lb where lb.loanstatus11 in('0','1') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();

		String update1 = "update qy_ledger_general_ics lg set lg.creditbalance=?,lg.debitbalance=? where lg.putoutno=? and lg.accountno='133' ";
		PreparedStatement ups1 = connection.prepareStatement(update1);

		String update2 = "update qy_ledger_general_ics lg set lg.creditbalance=?,lg.debitbalance=? where lg.putoutno=? and lg.accountno='404' ";
		PreparedStatement ups2 = connection.prepareStatement(update2);

		while (rs.next()) {
			ups1.setDouble(1, 0.0);
			ups1.setDouble(2, rs.getDouble("ATME"));
			ups1.setString(3, rs.getString("putoutno"));
			ups1.addBatch();

			ups2.setDouble(1, rs.getDouble("ATME"));
			ups2.setDouble(2, 0.0);
			ups2.setString(3, rs.getString("putoutno"));
			ups2.addBatch();
		}
		rs.close();

		ups1.executeBatch();
		connection.commit();

		ups2.executeBatch();
		connection.commit();
	}

	// ���º�������--ok
	public void UpdateD1() throws SQLException {
		String al = "select lb.normalbalance11+lb.overduebalance11 as ATME,replace(lb.putoutno11,'QY','QYICS00') as putoutno from qy_loan_balance_ics lb where lb.loanstatus11 in('4','5') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();

		String update1 = "update qy_ledger_general_ics lg set lg.creditbalance=?,lg.debitbalance=? where lg.putoutno=? and lg.accountno='608' ";
		PreparedStatement ups1 = connection.prepareStatement(update1);

		while (rs.next()) {
			ups1.setDouble(1, rs.getDouble("ATME"));
			ups1.setDouble(2, 0.0);
			ups1.setString(3, rs.getString("putoutno"));
			ups1.addBatch();
		}
		rs.close();

		ups1.executeBatch();
		connection.commit();
	}

	// ����������Ϣ
	public void UpdateD2() throws SQLException {
		String al = " insert into qy_ledger_general_ics(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+ " select lg.putoutno, "
				+ "        '1320202', "
				+ "        lg.orgid, "
				+ "        lg.currency, "
				+ "        0.0, "
				+ "        case when lb.loanstatus11='0' then "
				+ "        PAYINTE11 + PAYINNERINTE11 + PAYOUTINTE11 + PAYINNERINTEFINE11 + "
				+ "        PAYOUTINTEFINE11 + PERIODINTEBASE11 + PERIODINTE11 + INTEBASE11 "
				+ "        else 0.0 end, "
				+ "        '132', "
				+ "        'XX' || lg.putoutno || '01', "
				+ "        'D', "
				+ "        '����ס�����Ҵ���Ӧ����Ϣ' "
				+ "   from qy_ledger_general_ics lg, qy_loan_balance_ics lb "
				+ "  where lg.putoutno = replace(lb.putoutno11, 'QY', 'QYICS00') "
				+ "    and lg.subjectno = '1330401' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

		String al1 = " insert into qy_ledger_general_ics(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+ "  select lg.putoutno, "
				+ "     '5010204', "
				+ "    lg.orgid, "
				+ "     lg.currency, "
				+ "     case when lb.loanstatus11='0' then "
				+ "     PAYINTE11 + PAYINNERINTE11 + PAYOUTINTE11 + PAYINNERINTEFINE11 + "
				+ "     PAYOUTINTEFINE11 + PERIODINTEBASE11 + PERIODINTE11 + INTEBASE11 "
				+ "     else 0.0 end, "
				+ "     0.0, "
				+ "     '501', "
				+ "      'XX' || lg.putoutno || '02', "
				+ "      'C', "
				+ "      '����ס�����Ҵ�����Ϣ����' "
				+ "    from qy_ledger_general_ics lg, qy_loan_balance_ics lb "
				+ "   where lg.putoutno = replace(lb.putoutno11, 'QY', 'QYICS00') "
				+ "     and lg.subjectno = '1330401' ";
		PreparedStatement ps1 = connection.prepareStatement(al1);
		ps1.execute();
		connection.commit();

	}

	// ���·�Ӧ����Ϣ
	public void UpdateD3() throws SQLException {
		String al = "select PAYINTE11 + PAYINNERINTE11 + PAYOUTINTE11 + PAYINNERINTEFINE11 + "
				+ "     PAYOUTINTEFINE11 + PERIODINTEBASE11 + PERIODINTE11 + INTEBASE11 as ATME,replace(lb.putoutno11,'QY','QYICS00') as putoutno from qy_loan_balance_ics lb where lb.loanstatus11='1' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();

		String update1 = "update qy_ledger_general_ics lg set lg.creditbalance=?,lg.debitbalance=? where lg.putoutno=? and lg.accountno='621' ";
		PreparedStatement ups1 = connection.prepareStatement(update1);

		while (rs.next()) {
			ups1.setDouble(1, rs.getDouble("ATME"));
			ups1.setDouble(2, 0.0);
			ups1.setString(3, rs.getString("putoutno"));
			ups1.addBatch();
		}
		rs.close();

		ups1.executeBatch();
		connection.commit();
	}

	// ���º�����Ϣ
	public void UpdateD4() throws SQLException {
		String al = "select PAYINTE11 + PAYINNERINTE11 + PAYOUTINTE11 + PAYINNERINTEFINE11 + "
				+ "     PAYOUTINTEFINE11 + PERIODINTEBASE11 + PERIODINTE11 + INTEBASE11 as ATME,replace(lb.putoutno11,'QY','QYICS00') as putoutno from qy_loan_balance_ics lb where lb.loanstatus11 in('4','5') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();

		String update1 = "update qy_ledger_general_ics lg set lg.creditbalance=?,lg.debitbalance=? where lg.putoutno=? and lg.accountno='609' ";
		PreparedStatement ups1 = connection.prepareStatement(update1);

		while (rs.next()) {
			ups1.setDouble(1, rs.getDouble("ATME"));
			ups1.setDouble(2, 0.0);
			ups1.setString(3, rs.getString("putoutno"));
			ups1.addBatch();
		}
		rs.close();

		ups1.executeBatch();
		connection.commit();
	}

	// ��������Ϣ�Ĵ�����Ϣ��������
	public void Update5() throws SQLException {
		String al = "update qy_ledger_general_ics lg set lg.creditbalance=0.0,lg.debitbalance=0.0 where lg.accountno in ('132','501','621','609') "
				+ " and lg.putoutno in (select ld.putoutno from qy_ledger_general_ics ld where ld.subjectno in ('1250100','1250201','1250301') )";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ����133�����Ŀ
	public void CreateLG1() throws SQLException {
		String al = "insert into qy_ledger_general_ics(putoutno,subjectno,orgid,currency,creditbalance,debitbalance,accountno,serialno,direction,subjectname) "
				+ " select replace(lg.putoutno11, 'QY', 'QYICS00') as putoutno, "
				+ "       '1250201', "
				+ "       oi.orgid,lg.currency11,0.0,0.0,'133','QYX'||replace(lg.putoutno11, 'QY', 'QYICS00')||'1250201001','D','����ί�д���' "
				+ "   from qy_loan_balance_ics lg,org_info oi "
				+ "  where not exists "
				+ "  (select 1 "
				+ "           from qy_ledger_general_ics l "
				+ "          where l.accountno = '133' "
				+ "            and l.putoutno = replace(lg.putoutno11, 'QY', 'QYICS00')) "
				+ "   and lg.orgid11=oi.mainframeorgid     ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

}
