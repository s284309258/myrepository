package com.amarsoft.app.datax.gci.movedata;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateBarCod extends CommonExecuteUnit {
	
	//������ǰ׺
    private static String barNOPrefix ="KB00029";
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���ɺ�ͬ���������ݣ�.............");
				CreateBarCod();
				logger.info("................���ɺ�ͬ������������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateBarCod() throws SQLException{
		String serialno = ""; //��ͬ��
		String bar_code_no = "";//�ϵ�������
		String new_code_no = "";//�µ�������
		int startI= 0; //�µ����������
		int i=0,j=0;
        
        String sql = "SELECT  bar_code_no,serialno FROM qy_business_contract bc ";
        String updates ="update qy_business_contract bc set bc.bar_code_no=? where bc.serialno=? ";
        PreparedStatement ps=connection.prepareStatement(sql);
        PreparedStatement ps1=connection.prepareStatement(updates);
        
        ResultSet asrs = ps.executeQuery();
			while(asrs.next()){
				startI++;
				i++;
				j++;
				serialno = asrs.getString("serialno");
				new_code_no = getBarCodeNo(startI);
				ps1.setString(1, new_code_no);
				ps1.setString(2, serialno);
				ps1.addBatch();
				if(i>1000){
					ps1.executeBatch();
					connection.commit();
					i=0;
					logger.info("...............����"+j+"�����������ݣ�..............");
				}

			}
			ps1.executeBatch();
			connection.commit();
			asrs.close();
	}
	
	
	//����µ�������
	public static String getBarCodeNo(int startI){
		String barNO = "";
		int startILength = String.valueOf(startI).length();
		
		barNO = getZero(7-startILength) + startI;
		
		return barNOPrefix+barNO;
	}
	
	//���ǰ��0
	public static String getZero(int len){
		String str = "";
		for(int i=0;i<len;i++){
			str=str+"0";
		}
		return str;
	}
	
}
