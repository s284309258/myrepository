package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSUpdateBT extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ICS����Ʒ�֣�.............");
				CreateUpdate1();
				CreateUpdate2();
				CreateUpdate3();
				logger.info("................����ICS����Ʒ��������ɣ�..............");
				
				logger.info("................���¹������������ͣ�.............");
				UpdateBaseRateType();
				logger.info("................���¹���������������ɣ�.............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	// ����LB������Ʒ��
	public void CreateUpdate1() throws SQLException {
		String al = "select lb.putoutno,lb.businesskind,lb.businesstype,qm.btype,case when qm.btype='2170100' then 'SWPM' else 'RCPM' end as typd  from  "
				+ " loan_balance lb,ledger_general lg,qy_ics_subjectno_map qm where lb.putoutno=lg.putoutno   "
				+ " 				 and lb.putoutno like 'QYICS%'   and lg.accountno='133'  and qm.pabsubjectno=lg.subjectno ";
		String up = "update loan_balance set businesstype=?,businesskind=? where putoutno=? ";
		PreparedStatement ps = connection.prepareStatement(al);

		PreparedStatement ups = connection.prepareStatement(up);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			ups.setString(1, rs.getString("btype"));
			ups.setString(2, rs.getString("typd"));
			ups.setString(3, rs.getString("putoutno"));
			ups.addBatch();
		}
		rs.close();
		ups.executeBatch();
		connection.commit();

		al = "select lb.putoutno,qb.businesstype from qy_ics_businesstype_map qb,loan_balance lb,org_info oi "
				+ " where lb.orgid=oi.orgid "
				+ " and oi.mainframeorgid=qb.orgid "
				+ " and lb.putoutno like 'QYICS%' "
				+ " and lb.businesstype='888' ";
		up = "update loan_balance set businesstype=?,businesskind=? where putoutno=? ";
		ps = connection.prepareStatement(al);
		ups = connection.prepareStatement(up);
		rs = ps.executeQuery();
		while (rs.next()) {
			ups.setString(1, rs.getString("businesstype"));
			ups.setString(2, "RCPM");
			ups.setString(3, rs.getString("putoutno"));
			ups.addBatch();
		}
		rs.close();
		ups.executeBatch();
		connection.commit();

	}

	// ����BC������Ʒ��
	public void CreateUpdate2() throws SQLException {
		String al = "select lb.putoutno, lb.businesstype, lb.businesskind "
				+ " from loan_balance lb, business_putout bp "
				+ "  where lb.putoutno = bp.serialno "
				+ "   and lb.putoutno like 'QYICS%' ";
		String up = "update business_putout bp set bp.businesstype=?,bp.businesskind=? where bp.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(al);
		PreparedStatement ups = connection.prepareStatement(up);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			ups.setString(1, rs.getString("businesstype"));
			ups.setString(2, rs.getString("businesskind"));
			ups.setString(3, rs.getString("putoutno"));
			ups.addBatch();
		}
		rs.next();
		ups.executeBatch();
		connection.commit();

	}

	// ����BP������Ʒ��
	public void CreateUpdate3() throws SQLException {
		String al = "select lb.contractserialno, lb.businesstype, lb.businesskind "
				+ "  from loan_balance lb, business_contract bp "
				+ "   where lb.contractserialno = bp.serialno "
				+ "     and lb.putoutno like 'QYICS%' ";
		String up = "update business_contract bp set bp.businesstype=?,bp.businesskind=? where bp.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(al);
		PreparedStatement ups = connection.prepareStatement(up);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			ups.setString(1, rs.getString("businesstype"));
			ups.setString(2, rs.getString("businesskind"));
			ups.setString(3, rs.getString("contractserialno"));
			ups.addBatch();
		}
		rs.next();
		ups.executeBatch();
		connection.commit();

	}
	
	//���¹�������������
	public void UpdateBaseRateType() throws SQLException{
		String al="update loan_balance lb set BaseRateType='030' where lb.putoutno like 'QYICS%' and lb.businesstype like '120%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
		
		String al1="update business_contract bc set BaseRateType='030' where bc.serialno like 'QYICS%' and bc.businesstype like '120%'";
		ps = connection.prepareStatement(al1);
		ps.execute();
		connection.commit();
		
		String al2="update business_putout bp set BaseRateType='030' where bp.serialno  like 'QYICS%' and bp.businesstype like '120%' ";
		ps = connection.prepareStatement(al2);
		ps.execute();
		connection.commit();
	}
}
