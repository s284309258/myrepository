package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateCFreezeAcctNo extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ���¶��������ݣ�.............");
				CreateData1();
				CreateData2();
				CreateData3();
				logger.info("................���¶�����������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData1() throws SQLException{
		int i=0,j=0;
		String al="select cf.serialno, fo.cod_hold_ref_no" +
				" from fcr_conv_other_hold fo, credit_freeze_acct cf" +
				" where cf.freezeacctno = fo.cod_event_id " +
				" and fo.txt_event_type = 'CARD'";
		String insertSql="update credit_freeze_acct cf set cf.freezeno=? where cf.serialno=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("cod_hold_ref_no"));
			inps.setString(2, rs.getString("serialno"));
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		rs.close();
	}
	
	
	public void CreateData2() throws SQLException{
		int i=0,j=0;
		String al="select cf.serialno, fd.cod_hold_ref_no" +
				" from fcr_conv_acct_hold fd, credit_freeze_acct cf " +
				" where fd.cod_mc_acct_no = cf.freezeacctno " +
				" and fd.hold_type = '2' " +
				" and (LPAD(fd.cod_dep_no, 4, '0') = cf.depositserialno or " +
				" LPAD(fd.cod_dep_no, 5, '0') = cf.depositserialno or " +
				" LPAD(fd.cod_dep_no, 6, '0') = cf.depositserialno)";
		String insertSql="update credit_freeze_acct cf set cf.freezeno=? where cf.serialno=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("cod_hold_ref_no"));
			inps.setString(2, rs.getString("serialno"));
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		rs.close();
	}
	
	
	public void CreateData3() throws SQLException{
		int i=0,j=0;
		String al="select cf.serialno, fd.cod_hold_ref_no" +
				" from fcr_conv_acct_hold fd, credit_freeze_acct cf" +
				" where fd.cod_card_no = cf.freezeacctno " +
				" and fd.hold_type = '2'" +
				" and (LPAD(fd.cod_dep_no, 4, '0') = cf.depositserialno or " +
				" LPAD(fd.cod_dep_no, 5, '0') = cf.depositserialno or " +
				" LPAD(fd.cod_dep_no, 6, '0') = cf.depositserialno)";
		String insertSql="update credit_freeze_acct cf set cf.freezeno=? where cf.serialno=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("cod_hold_ref_no"));
			inps.setString(2, rs.getString("serialno"));
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		ps.close();
		inps.close();
		rs.close();
	}
	
	
}
