package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCredit extends CommonExecuteUnit {
	

	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateBP();
				logger.info("................����ҵ��������ɣ�..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				UpdataBP();  //������100��2����
				logger.info("................����ҵ��������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void UpdataBP() throws Exception{
		String sSql="update qy_business_putout qp set qp.putoutstatus='1'";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(sSql);
		selectSql.executeUpdate();
		connection.commit();
	}
	
	public void CreateBP() throws SQLException{
		String sSql="select * from qy_loan_balance qb where qb.contractserialno='SDBCONTNO' "; 
		
		String al="insert into qy_business_putout bc"
				+"  (bc.SERIALNO,                  "
				+"   bc.CONTRACTSERIALNO,          "
				+"   bc.CUSTOMERID,                "
				+"   bc.CUSTOMERNAME,              "
				+"   bc.BUSINESSTYPE,              "
				+"   bc.BUSINESSSUBTYPE,           "
				+"   bc.CURRENCY,                  "
				+"   bc.OPERATEORGID,              "
				+"   bc.MAINRETURNTYPE,            "
				+"   bc.RETURNTYPE,                "
				+"   bc.RETURNPERIOD,              "
				+"   bc.DEDUCTACCNO,               "
				+"   bc.DEDUCTACCNO1,              "
				+"   bc.DEDUCTACCNO2,              "
				+"   bc.GRACETERMFLAG,             "
				+"   bc.GRACETERM,                 "
				+"   bc.PUTOUTDATE,                "
				+"   bc.MATURITYDATE,              "
				+"   bc.BEGINDATE,                 "
				+"   bc.LOANTERM,                  "
				+"   bc.GAINAMOUNT,                "
				+"   bc.GAINCYC,                   "
				+"   bc.BASERATE,                  "
				+"   bc.RATECODE,                  "
				+"   bc.RATEMODE,                  "
				+"   bc.RATEFLOATTYPE,             "
				+"   bc.RATEFLOAT,                 "
				+"   bc.BUSINESSRATE,              "
				+"   bc.BASERATETYPE,              "
				+"   bc.BUSINESSSUM,               "
				+"   bc.UPDATEDATE,                "
				+"   bc.INPUTUSERID,               "
				+"   bc.RATEFLOATFLAG,             "
				+"   bc.HOLDBALANCE,               "
				+"   bc.RATEADJUSTTYPE,            "
				+"   bc.DISDATE,                   "
				+"   bc.LOANACCNO,                 "
				+"   bc.DSINTEPROPORTION,          "
				+"   bc.DUNDEPOSITNO,              "
				+"   bc.BANKFLAG,                  "
				+"   bc.BUSINESSKIND,              "
				+"   bc.CUSTOMERTYPE)              "
				+"  (select "
				+" lb.PUTOUTNO							,	"
				+" lb.CONTRACTSERIALNO       ,  "
				+" lb.CUSTOMERID             ,  "
				+" lb.CUSTOMERNAME           ,  "
				+" lb.BUSINESSTYPE           ,  "
				+" lb.BUSINESSSUBTYPE        ,  "
				+" lb.CURRENCY               ,  "
				+" lb.ORGID                  ,  "
				+" lb.MAINRETURNTYPE         ,  "
				+" lb.RETURNTYPE             ,  "
				+" lb.RETURNPERIOD           ,  "
				+" lb.DEDUCTACCNO            ,  "
				+" lb.DEDUCTACCNO1           ,  "
				+" lb.DEDUCTACCNO2           ,  "
				+" lb.GRACEPERIODCODE        ,  "
				+" lb.GRACEPERIOD            ,  "
				+" lb.PUTOUTDATE             ,  "
				+" lb.MATURITYDATE           ,  "
				+" lb.BEGINDATE              ,  "
				+" lb.LOANTERM               ,  "
				+" lb.GAINAMOUNT             ,  "
				+" lb.GAINCYC                ,  "
				+" lb.BASERATE               ,  "
				+" lb.RATECODE               ,  "
				+" lb.RATEMODE               ,  "
				+" lb.RATEFLOATTYPE          ,  "
				+" lb.RATEFLOAT              ,  "
				+" lb.PUTOUTRATE             ,  "
				+" lb.EXECUTERATE            ,  "
				+" lb.BUSINESSSUM            ,  "
				+" lb.UPDATEDATE             ,  "
				+" lb.USERID                 ,  "
				+" lb.RATEFLOATFLAG          ,  "
				+" lb.HOLDBALANCE            ,  "
				+" lb.RATEADJUSTTYPE         ,  "
				+" lb.DISDATE                ,  "
				+" lb.LOANACCNO              ,  "
				+" lb.DSINTEPROPORTION       ,  "
				+" lb.TRUSTACCNO             ,  "
				+" lb.BANKFLAG               ,  "
				+" lb.BUSINESSKIND           ,  "
				+" lb.CUSTOMERTYPE              "
				+"     from qy_loan_balance lb  " 
				+" where not exists ( select 1 from qy_business_putout qb where qb.SERIALNO = lb.PUTOUTNO )    "
				+"  )                              ";


		
		
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(al);
		selectSql.execute();
		connection.commit();
		
//		ResultSet rs=selectSql.executeQuery();
//		while(rs.next()){
//			logger.info("======="+rs.getString("PUTOUTNO"));
//		}
//		rs.close();
	}
		
	
}
