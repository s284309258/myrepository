package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateEBS extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
			
				logger.info("................��ʼ����E���׻��������ݣ�.............");
				UpdateLXData();
				logger.info("................����E���׻�����������ɣ�..............");
				
			
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void UpdateLXData() throws Exception{
		String al="insert into acc_edep     "
				+"  (CONTRACTSERIALNO,     "
				+"   CR_LINE_DESC,         "
				+"   MAINT_STS,            "
				+"   PAYM_OC_IND,          "
				+"   SETL_OC_IND,          "
				+"   INT_ADJ_PCT,          "
				+"   STS,"
				+"   UPDATEDATE,           "
				+"   ACCT_NO,              "
				+"   MAX_PCT,              "
				+"   MAX_AMT,              "
				+"   APPROVEUSER,          "
				+"   INPUTDATE,            "
				+"   INPUTUSERID,          "
				+"   ISACCEPTAPPLY,        "
				+"   SERIALNO)             "
				+"  select qc.serialno,    "
				+"         qe.cr_line_desc,"
				+"         '1',            "
				+"         case            "
				+"           when qe.paym_oc_ind = 'C' then  "
				+"            '0'          "
				+"           else          "
				+"            '1'          "
				+"         end as paym_oc_ind,               "
				+"         case            "
				+"           when qe.setl_oc_ind = 'C' then  "
				+"            '0'          "
				+"           else          "
				+"            '1'          "
				+"         end as SETL_OC_IND,               "
				+"         qe.INT_ADJ_PCT, "
				+"         case            "
				+"           when qe.sts = 'A' then          "
				+"            '1'          "
				+"           else          "
				+"            '1'          "
				+"         end as sts,     "
				+"         '',             "
				+"         qe.acct_no,     "
				+"         qe.max_pct,     "
				+"         qe.max_amt,     "
				+"         qe.last_chk_usr,"
				+"         replace(substr(qe.CREATE_DT, 0, 10), '-', '/'),     "
				+"         qe.CREATE_USR,  "
				+"         '1',            "
				+"         'QY' ||SEQ_CLEAN.NEXTVAL         "
				+"    from qy_eb_cr_ln qe, qy_business_contract qc             "
				+"   where qe.ctif_id_type = qc.ctif_id_type "
				+"     and qe.ctif_id_no = qc.ctif_id_no     "
				+"     and qe.ctif_iss_ctry = qc.ctif_iss_ctry                 "
				+"     and qe.cr_line = qc.cr_line           ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
	
}
