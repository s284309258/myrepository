package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateFZ extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				
				logger.info("................��ʼ���ɱ����������ݣ�.............");
				checkALLData();
				logger.info("................���ɱ�������������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	

	
	public void checkALLData() throws SQLException{
		String al="select ls.putoutno,     "
				+"       ls.sterm ,       "
				+"       ls.paydate ,      "
				+"       ls.paycurrentcorp+ls.payoverduecorp as duecorp,    "
				+"       ls.actualcurrentcorp+ls.actualoverduecorp as aduecorp,     "
				+"       ls.PAYINTE + ls.PAYINNERINTE + ls.PAYOUTINTE + ls.PAYINNERINTEFINE +  "
				+"       ls.PAYOUTINTEFINE + ls.PAYINNERINTOD + ls.PAYOUTINTEFOD as A ,     "
				+"       ls.ACTUALINTE+ls.ACTUALINNERINTE+ls.ACTUALOUTINTE+                "
				+"       ls.ACTUALINNERINTEFINE+ls.ACTUALOUTINTEFINE+ls.ACTUALINNERINTOD+ls.ACTUALOUTINTEFOD   as B    "
				+"  from qy_loanback_status ls    "
				+" where  "
				+"    ls.paydate>='2012/09/01' and     "
				+"   exists (select 1 from qy_loan_balance lb where lb.putoutno=ls.putoutno  "
				+"   and lb.orgid in ('0201','0251','0301','0800','0901')   "
				+"   and lb.loanstatus in ('0','1','4','5') )   ";
		String insert="insert into qy_loanback_status_tmp(putoutno,sterm,paydate,duecorp,aduecorp,a,b) values(?,?,?,?,?,?,?) ";
		PreparedStatement ps1=connection.prepareStatement(insert);
		PreparedStatement ps=connection.prepareStatement(al);
		
		int i=0,j=0;
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			ps1.setString(1, rs.getString("putoutno"));
			ps1.setString(2, rs.getString("sterm"));
			ps1.setString(3, rs.getString("paydate"));
			ps1.setString(4, rs.getString("duecorp"));
			ps1.setString(5, rs.getString("aduecorp"));
			ps1.setString(6, rs.getString("A"));
			ps1.setString(7, rs.getString("B"));
			ps1.addBatch();
			while(i>999){
				ps1.executeBatch();
				connection.commit();
				i=0;
				logger.info("....���� "+j+" ������..........");
			}
			
		}
		ps1.executeBatch();
		connection.commit();
		rs.close();
	}
	

}
