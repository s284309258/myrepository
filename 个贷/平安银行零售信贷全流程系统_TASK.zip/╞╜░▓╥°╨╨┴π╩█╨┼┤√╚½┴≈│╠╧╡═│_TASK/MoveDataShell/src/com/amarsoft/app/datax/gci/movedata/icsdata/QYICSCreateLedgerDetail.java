package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;


/**
 * ����ICS����QY_ledger_detail_ics������
 * @author EX-SHISHENGHUA001
 *
 */
public class QYICSCreateLedgerDetail extends CommonExecuteUnit {
	private String commitNum="";
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
          //  OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����QY_ledger_detail_icsҵ�����ݣ�.............");
				CreateData();
				logger.info("................����QY_ledger_detail_icsҵ��������ɣ�..............");
							
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum = getProperty("LockName", "");
	}
	
	public void CreateData() throws Exception{
		String al="insert into qy_ledger_detail_ics (PUTOUTNO,BILLNO,TRANSID,SORTID,OCCURTIME,OCCURDATE,CURRENCY,SUBJECTNO,CREDITAMT,DEBITAMT,HANDSTATUS,ORGID,SERIALNO) "+
          " select lg.putoutno,'','9999',lg.direction,'','"+deductDate+"',lg.currency,lg.subjectno,lg.creditbalance,lg.debitbalance,'1',lg.orgid,lg.serialno  from " +
          " qy_ledger_general_ics lg where lg.creditbalance <> 0 or lg.debitbalance <> 0 ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
}
