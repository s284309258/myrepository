package com.amarsoft.app.datax.gci;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.amarsoft.account.util.DateTools;
import com.amarsoft.app.datax.gci.util.FileMD5Tools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.FCRESBInstance;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;
import com.dc.eai.data.Array;
import com.dc.eai.data.CompositeData;

/**
 * �չ�����ļ�����
 * 
 * @author SHISHENGHUA001	
 * 
 */
public class DealWithSDBOF extends CommonExecuteUnit {
	
	//�ļ�·��
	private String fileUrl="";
	//�ļ�����
	private String sFileName="";
	
	private PreparedStatement psSql;
	private PreparedStatement detSql;
	private String sSql="";
	
	
	private String sOFDate="";			//��������
	private String sSubjectNo="";		//��Ŀ
	private String sBRNO="";			//���Ļ�����
	private String sCCY="";				//����
	private Double dCreditamt=0.0;		//����������
	private Double dDebitamt=0.0;		//�跽������
	
	

	
	


	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("============��ʼ��ʼ��������===============");
				initPara();
				logger.info("============��ʼ������������===============");
				
				logger.info("============��ʼ�����ˣ�===============");
				checkAllAmt();
				logger.info("============������ɣ�===============");
				
				logger.info("============��ʼ�Է��ˣ�===============");
				checkCDAmt();
				logger.info("============������ɣ�===============");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}



	/**
	 * ��ʼ������ģ�������õĲ���
	 */
	public void initPara() throws Exception {
		String sDate = StringFunction.replace(deductDate, "/", "");				
	}
	
	/**
	 * У������
	 * @throws Exception
	 */
	public void checkAllAmt() throws Exception{
		double clAMT=0.0;
		double dlAMT=0.0;
		String lastDate="";
		lastDate=DateTools.getRelativeDate(deductDate,"D",-1);
		String ETLFlage="";
		String ETLFlage1="";
		
		
		String dataSql="select ATTRIBUTE1 as C , ATTRIBUTE2 as D,ATTRIBUTE4 as ETLFlage from code_library cl where  codeno='SDBOFFileData' ";
    	PreparedStatement dataSqls;
    	dataSqls=connection.prepareStatement(dataSql);
    	ResultSet rsSDBData=dataSqls.executeQuery(); 
    	while(rsSDBData.next()){
    		clAMT=rsSDBData.getDouble("C");
    		dlAMT=rsSDBData.getDouble("D");
    		ETLFlage1=rsSDBData.getString("ETLFlage");
    	}
    	rsSDBData.close();
    	
    	//�������ݱ�־0 ETL����δ������ɣ�1Ϊ�������
    	String flageSql="select attribute1 AS Flage from ETLRETURN_VALUE ev where ev.codeno='SDBOFFILEFALGE' and ev.itemno='10' and ev.isinuse='1' ";
    	PreparedStatement flageSqls;
    	flageSqls=connection.prepareStatement(flageSql);
    	ResultSet rsFlageData=flageSqls.executeQuery(); 
    	while(rsFlageData.next()){
    		ETLFlage=rsFlageData.getString("Flage");
    	}
    	rsFlageData.close();
    	
    	//1������ɣ�0δ�������
    	if( "0".equals(ETLFlage)&& "0".equals(ETLFlage1)){
    		throw new Exception("�չ�ļ�δ������ɣ�");
    	}
		
			//������
	    	String soData=" select sb.C - st.damt as sumcamt, sb.T - st.camt sumdamt ,sb.currency, sb.subjectno "
	    			    +" from (select sum(so.creditbalance) as C, "
	    		        +"         sum(so.debitbalance) as T, "
	    		        +"       so.currency, "
	    		        +"       so.subjectno "
	    		        +"   from subject_balance so "
	    		        +"  where so.occurdate = ? "
	    		        +"    and so.subjectno = '40310402' "
	    		        +"  group by so.currency, so.subjectno) sb, "
	    		        +"  (select sum(sa.creditamt) as camt, "
	    		        +"         sum(sa.debitamt) as damt, "
	    		        +"         sa.currency, "
	    		        +"        case "
	    		        +"          when subjectno = '4031302' then "
	    		        +"           '40310402' "
	    		        +"          else "
	    		        +"            sa.subjectno "
	    		        +"         end as subjectno "
	    		        +"    from sdbof_amt sa "
	    		        +"   where sa.ofdate = ? "
	    		        +"   group by sa.currency, sa.subjectno) st ";

	    	
	    	String insertSql=" insert into SDBOF_ERRECODE (SERIALNO, OFDATE, SUBJECTNO, BRNO, CURRENCY, PABCREDITAMT, PABDEBITAMT,SDBCREDITAMT,SDBDEBITAMT,ORGID)"
					+" values (?,?,?,?,?,?,?,?,?,?)";
	    	PreparedStatement inSql;
	    	inSql=connection.prepareStatement(insertSql);
	    	    	
	    	double sumcamt=0.0;
	    	double sumdamt=0.0;
	    	String sCurrency="";
	    	String subjectno="";
	    	PreparedStatement saDataStatment;
	    	saDataStatment=connection.prepareStatement(soData);
	    	saDataStatment.setString(1, lastDate);
	    	saDataStatment.setString(2, lastDate);
	    	ResultSet soDataRs=saDataStatment.executeQuery();
	    	while(soDataRs.next()){
	    		sumcamt=soDataRs.getDouble("sumcamt");
	    		sumdamt=soDataRs.getDouble("sumdamt");
	    		sCurrency =soDataRs.getString("currency");
	    		subjectno =soDataRs.getString("subjectno");
	    		
	    		if((clAMT-sumcamt)!=0.0 || (dlAMT-sumdamt)!=0.0){
	    			
	    			inSql.setString(1, getSerialNo(connection,lastDate,"SDBOF_ERRECODE"));
	    			inSql.setString(2, lastDate);
	    			inSql.setString(3, subjectno);
	    			inSql.setString(4, "");
	    			inSql.setString(5, sCurrency);
	    			inSql.setDouble(6, clAMT-sumcamt);
	    			inSql.setDouble(7, dlAMT-sumdamt);
	    			inSql.setDouble(8, dCreditamt);
	    			inSql.setDouble(9, dDebitamt);
	    			inSql.setString(10, "");
	    			inSql.execute();
	    			logger.info("���� ��Ŀ: "+subjectno+" ���֣�"+sCurrency+"��ƽ�������ƽ��������Ϣ���ѯSDBOF_ERRECODE�� ");
	    		} 
	    	}
	    	inSql.close();	
	    	soDataRs.close();
	}
	
	/**
	 * ���������Ƿ����
	 * @throws Exception 
	 */
    public void checkCDAmt() throws Exception{
    	String sOrgID="";		//������
    	String sSubjectno="";	//��Ŀ��
    	String sCcy="";			//����
    	String sBrNo="";		//���Ļ�����
    	String sOFdate="";		//��������
    	Double dCreditamt=0.0;	//�չ�������
    	Double dDebitamt=0.0;	//�չ�跽���
    	Double dCAmt=0.0;		//ƽ������������
    	Double dDAmt=0.0;		//ƽ���跽������
    	Double dALLCAmt=0.0;		//ƽ�������ܶ�
    	Double dALLDAmt=0.0;		//ƽ���跽�ܶ�
    	String lastDate="";
    	lastDate=DateTools.getRelativeDate(deductDate,"D",-1);
    	
		int count=0;				//������
		int OFDataCount=0;
    	
    	String sdbOFSql =" select sf.OFDATE,sf.SUBJECTNO,sf.BRNO,sf.CURRENCY,sf.CREDITAMT,sf.DEBITAMT,oi.orgid from sdbof_amt sf,org_info oi   where oi.mainframeorgid=sf.BRNO and OFDATE= ?  ";   	
    	
    	String sDetailSql="    select so.creditbalance as CAmt,  "
                       +"  so.debitbalance as DAmt,  "
                       +"  so.orgid as orgid,  "
                       +"  so.subjectno as subjectno,  "
                       +"  so.currency as ccy  "
                       +"  from subject_balance so  "
                       +"  where  so.orgid = ?   "  
                       +"  and so.subjectno= ?   "  
                       +"  and so.currency= ?    "
                       +"  and so.occurdate = ?  ";
    	
    	String insertSql=" insert into SDBOF_ERRECODE (SERIALNO, OFDATE, SUBJECTNO, BRNO, CURRENCY, PABCREDITAMT, PABDEBITAMT,SDBCREDITAMT,SDBDEBITAMT,ORGID)"
    						+" values (?,?,?,?,?,?,?,?,?,?)";
    	
    
    	
    	
    		PreparedStatement sdbSql;
    		PreparedStatement detailSql;
    		PreparedStatement inSql;
    		
        	
    		sdbSql=connection.prepareStatement(sdbOFSql);			
    		detailSql=connection.prepareStatement(sDetailSql);
    		inSql=connection.prepareStatement(insertSql);

    		sdbSql.setString(1, lastDate);   	
    		ResultSet rsSdb=sdbSql.executeQuery();
    		ResultSet check=null;
    		while(rsSdb.next()){
    			OFDataCount++;
    			sOFdate=rsSdb.getString("OFDATE");
    			sSubjectno=rsSdb.getString("SUBJECTNO");	
    			if("4031302".equals(sSubjectno)){
    				sSubjectno="40310402";
    			}
    			sBrNo=rsSdb.getString("BRNO");	
    			sCcy=rsSdb.getString("CURRENCY");
    			dCreditamt=rsSdb.getDouble("CREDITAMT");
    			dDebitamt=rsSdb.getDouble("DEBITAMT");
    			sOrgID=rsSdb.getString("orgid");
    			
    			detailSql.setString(1, sOrgID);
    			detailSql.setString(2, sSubjectno);
    			detailSql.setString(3, sCcy);
    			detailSql.setString(4, sOFdate);
    			check=detailSql.executeQuery();
    			dCAmt=0.0;
    			dDAmt=0.0;
    			while(check.next()){
    				dCAmt=check.getDouble("CAmt");
    				dDAmt=check.getDouble("DAmt");
    			} 
    			
    			if((dCreditamt-dDAmt )!=0.0 || (dDebitamt-dCAmt)!=0.0 ){
    				
    				inSql.setString(1, getSerialNo(connection,sOFdate,"SDBOF_ERRECODE"));
    				inSql.setString(2, sOFdate);
    				inSql.setString(3, sSubjectno);
    				inSql.setString(4, sBrNo);
    				inSql.setString(5, sCcy);
    				inSql.setDouble(6, dCAmt);
    				inSql.setDouble(7, dDAmt);
    				inSql.setDouble(8, dCreditamt);
    				inSql.setDouble(9, dDebitamt);
    				inSql.setString(10, sOrgID);
    				inSql.execute();
    				count++;
    				logger.info("���ڷ�չ���Ļ�����"+sBrNo+"  �����ƽ��������Ϣ���ѯSDBOF_ERRECODE�� ");
    			} 		
    			check.close();
    		}
    		rsSdb.close();
    		inSql.close();	
    		detailSql.close();
    		sdbSql.close();
	    	if(count>0){
	    		logger.info("���˽����ƽ��������Ϣ���ѯSDBOF_ERRECODE����");
	    	}
	    	if(0==OFDataCount){
	    		logger.info("�չ"+lastDate+"�����ļ���������Ϊ0��");
	    	}
	    	
	    	//�����������ݱ�־0 ETL����δ������ɣ�1Ϊ�������
	    	String upFlagSqls="update ETLRETURN_VALUE ev set Attribute1='0' where ev.codeno='SDBOFFILEFALGE' and ev.itemno='10' and ev.isinuse='1' ";
	    	PreparedStatement upFlagSql;
	    	upFlagSql=connection.prepareStatement(upFlagSqls);	
	    	upFlagSql.executeUpdate();
	    	upFlagSql.close();
	    	
	    	
	    	//�����������ݱ�־0 ETL����δ������ɣ�1Ϊ�������
	    	String upFlagSqls1="update code_library cl set ATTRIBUTE4=0  where  codeno='SDBOFFileData' ";
	    	PreparedStatement upFlagSql1;
	    	upFlagSql1=connection.prepareStatement(upFlagSqls1);	
	    	upFlagSql1.executeUpdate();
	    	upFlagSql1.close();
	    	
  }	



    /**
     * ����������֧���ظ���
     * @throws SQLException
     */
	private void clearOldData() throws SQLException{
	 String	deletSql="delete from SDBOF_AMT where OFDATE=? ";
	 try {
		 detSql=connection.prepareStatement(deletSql);
		 detSql.setString(1, deductDate);
		 detSql.execute();
		 detSql.close();
	} catch (SQLException e) {
		detSql.close();
		unitStatus = TaskConstants.ES_FAILED;
		e.printStackTrace();
	}
	 
	}
		
		
	/**
	 * ȡ����ˮ��
	 * @param connection
	 * @param sDate
	 * @param Table
	 * @return
	 * @throws ParseException
	 * @throws SQLException
	 */
	private String getSerialNo(Connection connection,String sDate,String Table) throws ParseException, SQLException {
		String sSql = " select max(SerialNo)+1 as SerialNo from " +Table ;
		PreparedStatement psSqll = connection.prepareStatement(sSql);
		ResultSet rs = psSqll.executeQuery();
		String SerialNo="";
		if(rs.next())
		{
			SerialNo = rs.getString("SerialNo");
			if(SerialNo==null)
				SerialNo = DateTools.getStringDate(sDate)+"0000001";
		}
		rs.close();
		psSqll.close();
		return SerialNo;
	}
	
	/**
	 * У���ļ��Ƿ�Ϊ��
	 * 
	 * @param file
	 * @return ���ļ�����true ���ǿ� ����false
	 * @throws IOException
	 */
	private Boolean checkFileIsNull(File file) throws IOException {
		String sLine=null;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file)));
			if ((sLine = reader.readLine()) != null) {
					return false;
			} else {
				return true;
			}
		} catch (IOException ex) {
			throw new IOException();
		} finally {
			if (reader != null)
				reader.close();
		}
	}

	/**
	 * ת������
	 * @param sDate
	 * @return
	 */
	public String turnDateFormat(String sDate){
		String sReturn = sDate.substring(0,4)+"/"+sDate.substring(4,6)+"/"+sDate.substring(6,8);
		return sReturn;
	}
	
}
