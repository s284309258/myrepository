package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYStartMoveData extends CommonExecuteUnit {

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����Ǩ������У�飡.............");
				String pDate="";
				String flage="";
				String pDate106="";
				String flage106="";
				String lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE901' and bl.itemno='10'";
				PreparedStatement lps=connection.prepareStatement(lockSql);
				ResultSet rs =lps.executeQuery();
				while(rs.next()){
					pDate=rs.getString("attribute1");
					flage=rs.getString("attribute2");
				}
				rs.close();
				if("0".equals(flage)){
					throw new Exception("901����Ǩ��û����ɣ���������901����Ǩ����������");
				}else{
					lockSql=" select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE106' and bl.itemno='10'";
					lps=connection.prepareStatement(lockSql);
					rs =lps.executeQuery();
					while(rs.next()){
						pDate106=rs.getString("attribute1");
						flage106=rs.getString("attribute2");
					}
					rs.close();
					if(deductDate.equals(pDate106)&&"0".equals(flage106)){
						logger.info("................��ʼ����Ǩ��������.............");
					}else{
						throw new Exception("���첻��Ҫ����Ǩ��������");
					}
				}
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

}
