package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class SCreateGIData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateGI();
				logger.info("................����ҵ��������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void CreateGI() throws Exception{
	String insertSql="	insert into qy_guaranty_info (GUARANTYID, GUARANTYTYPE, OWNERID, OWNERNAME, OWNERTYPE, RIGHTID, OTHERRIGHTID, GUARANTYNAME, LOCATION, AMOUNT, GUARANTYDATE, OWNDATE, DESCRIPT, PURPOSE, GUARANTYPRICE, EVALMETHOD, EVALORGID, EVALORGNAME, EVALDATE, EVALNETVALUE, CONFIRMVALUE, FLAG1," 
			+" FLAG2, REGORG, REGDATE, WODATE, OTHERASSUMPSIT, INPUTORGID, INPUTUSERID, INPUTDATE, "
			+" UPDATEUSERID, UPDATEDATE, REMARK, CURRENCY, EVALCURRENCY, DATAFLAG, STOREINDEX, FILEINDEXNO, HOUSEAREA, " +
			" INSURNO, INSURSUM, ASSURENAME, DATE1, DATE2, SIGNORG, DATE3, DATE4, OPENORG, HOUSETYPE, REGUSER, MANSTATUS, DISPATCHDATE, " +
			" STATUS, REPORTFLAG, REPORTREMARK, INSURFLAG, INSURREMARK, REPORTDATE, GUARANTYRATE, GUARANTYAREA, MARKINDEX, KEEPINGINDEX, PIGEONHOLENO, REGBOOKINGDATE, EXCHANGEDATE, TRACKFREQUENCY, TRACKREASON, TRACKDATE, UNLOADREASON, VEHICLERACKNO, VEHICLENO, VEHICLEAUTONO, " +
			" GUARANTYSUBTYPE, PLACENO, DATE5, DATE6, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3, ATTRIBUTE4, ATTRIBUTE5, DATE7, DATE8, APPPROBLEM, APPFLAG, GUARANTYNO, CONTINUED, EXCHANGEFLAG, REGISTERPRICE, DEALPRICE, FIRSTPAY, COUNTRYAREA, ISCOMPLETED, DATAREADY, REEVALUATEVALUE, " +
			" OWNERCOUNT, RECOGNIZEFLAG, REALTYLOCATION, GROUNDSOURCE, COLLECTIONFLAG, OTHEROWNSFLAG, DEPOSITSERIALNO, CREDITRESULT, SELFLIVINGFLAG, HOUSELTVVALUE, BUSINESSKIND, ASSURECREDITSUM, GUARANTYLEVEL, BETTERFLAG, OTHERAREA, OTHERAREAREMARK, REEVALUATEDATE, STOP_TIME, " +
			" CONFIRMVALUEBANK, TASKGENTIME, TASKENDTIME, HANDOVERDATE, RECEIVEDOCDATE, GUARANTYFLAG, " +
			" ACTIVITYNO, ACTIVITYNAME, VEHICLETYPENO, STYLENO, STYLENAME, CARPRICE) "+
			" values (?, '030010', '1328579328', 'ʩ־�', null, '6229890200016778004', null, null, " +
			" null, null, null, null, null, null, null, null, null, null, " +
			" null, 90000.000000, 81000.000000, '0', '0', '99999', null, null, " +
			" null, '100130105', 'A00000', '2009/03/30', null, '2009/10/11', " +
			" null, 'RMB', 'RMB', '2', null, null, null, '6229890200016778004', 90000.000000, " +
			" null, null, null, null, null, null, null, null, null, '05', null, '02', null, null, " +
			" null, null, null, null, null, 0.000000, null, 'PAGY200903310000000001', null, null, " +
			" null, null, null, null, null, '6229890200016778004', null, null, null, null, null, " +
			" null, null, null, '90000', '01', null, null, null, null, null, '1', null, 0.000000, " +
			" 0.000000, null, 0.000000, '1', '1', 81000.000000, null, null, null, null, null, null, " +
			" null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, " +
			" null, null, null, null, null, null, null, null, null)";
	PreparedStatement insertPS;
	insertPS=connection.prepareStatement(insertSql);
	
	String selectSql=" select * from qy_guar_loan_cr " ;
	PreparedStatement selectPS;
	selectPS=connection.prepareStatement(selectSql);
	ResultSet rs = selectPS.executeQuery();
	int i=0;
	int j=0;
	while(rs.next()){
		i++;
		j++;
		insertPS.setString(1, rs.getString("gi_guarantyid"));
		insertPS.addBatch();
		if(i==commitNum){
			i=0;
			insertPS.executeBatch();
			connection.commit();
			logger.info("................����ҵ������ "+j+" ��..............");
		}
	}
	rs.close();
	insertPS.executeBatch();
	connection.commit();

	}
}
