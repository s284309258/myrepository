package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYOverMoveData extends CommonExecuteUnit {

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��������Ǩ���������ݴ�����.............");
				String al="update batch_lock bl set bl.attribute2='1' where bl.lockno='DATAMOVE106' and bl.itemno='10' ";
				PreparedStatement ps =connection.prepareStatement(al);
				ps.executeUpdate();
				connection.commit();
				logger.info("................����Ǩ�����������ɣ���ֹͣ������ѯ��..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

}
