package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateGIRightID extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����12��浥��.............");
				CreateData();
				logger.info("................����12��浥��ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0;
		String al=" select gi.guarantyid,it.account_no2, it.dep_seqno2 "
					+"  from guaranty_info gi, guaranty_relative gr, loan_balance lb,ics_type_acct it "
					+"   where gi.guarantyid = gr.guarantyid "
					+"     and gi.guarantytype = '030010' "
					+"     and gr.objectno = lb.contractserialno "
					+"     and gr.objecttype like '%ContractApply'"
					+"     and lb.loanstatus in ('0', '1', '4', '5') "
					+"     and lb.putoutno like 'QY%' "
					+"     and it.account_no1=gi.rightid "
					+"     and gi.depositserialno=it.dep_seqno1 ";
		String insertSql="update guaranty_info gi set gi.rightid=?,gi.depositserialno=? where gi.guarantyid=? ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			inps.setString(1, rs.getString("account_no2"));
			inps.setString(2, rs.getString("dep_seqno2"));
			inps.setString(3, rs.getString("guarantyid"));
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		inps.close();
		ps.close();
		rs.close();
	}
	
	
	
}
