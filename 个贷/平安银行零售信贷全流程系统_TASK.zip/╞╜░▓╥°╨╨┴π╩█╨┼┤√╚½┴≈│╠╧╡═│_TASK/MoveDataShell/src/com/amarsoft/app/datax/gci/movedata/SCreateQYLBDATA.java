package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.sql.ASResultSet;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class SCreateQYLBDATA extends CommonExecuteUnit {
	

	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateLBdata();
				logger.info("................����ҵ��������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void CreateLBdata() throws SQLException{
		
		String acc=" insert into qy_loan_balance (PUTOUTNO, CONTRACTSERIALNO, CUSTOMERID, CUSTOMERNAME, BUSINESSTYPE, BUSINESSSUBTYPE, CURRENCY, ORGID, MAINRETURNTYPE, RETURNTYPE, RETURNPERIOD, DEDUCTACCNO, DEDUCTACCNO1, " 
				+" DEDUCTACCNO2, GRACEPERIODCODE, GRACEPERIOD, PUTOUTDATE, MATURITYDATE, BEGINDATE, MONTHENDFLAG, LOANTERM, NEXTPAYDATE, CTERM, SCTERM, STERM, AHEADNUM, GAINAMOUNT, GAINCYC, LASTTERM, BASEDAYS, BASERATE, RATECODE, RATEMODE, RATEFLOATTYPE, RATEFLOAT, PUTOUTRATE, EXECUTERATE, FINERATEMODE," 
				+" FINERATEFLOATTYPE, FINERATECODE, FINERATETYPE, FINERATEFLOAT, FINERATE, LASTINTEDATE, LOANSTATUS, MONTHPAY, BUSINESSSUM, NORMALBALANCE, CURRENTBALANCE, DEFAULTBALANCE, OVERDUEBALANCE, PAYINTE, PAYINNERINTE, PAYOUTINTE, "
				+" PAYINNERINTEFINE, PAYOUTINTEFINE, PERIODINTEBASE, PERIODINTE, CORPFINEFLAG, INTEFINEFLAG, UPDATEDATE, CALCDAYINTEDATE, USERID, FINISHDATE, "
				+" APPVIPRATEDATE, RATEFLOATFLAG, HOLDBALANCE, CALCMATURITYDATE, RATEALTERDATE, RATEADJUSTTYPE, DISDATE, LOANACCNO, FAREFALG, CLASSIFYRESULT, BASERATETYPE, ACCORDINTEBASE, DSINTEPROPORTION, TRUSTACCNO, INTEBASE, BANKFLAG, BATCHPAYMENTFLAG, BUSINESSKIND, CUSTOMERTYPE, DMFLAG, QYCERTID, QYCERTTYPE, QYNAT) "
        +" values (?, ?, ?, ?, '1110020', '3110010', 'RMB', '0809', '1', '1', '1', '6222000100001', '', '', 'D', 3, '2010/05/01', '2015/05/01', '21', '', 60, '2012/05/21', 60, 24, 24, null, null, null, null, " 
        +" 360, 7.05000000, '01', '01', '01', 0.00000000, 7.05000000, 7.05000000, '01', 'L', '', '', null, null, '', '0', 5000.000000, 8000000.000000, 7000000.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, '1', '1', '', '2012/04/24', '', '', '2010/05/01', '', null, '', "
        +" '2012/04/24', '5', '', '', '', '', '010', null, null, '', null, 'PAB', '1', 'RCPM', '', '', '20001201001', 'Ind01', '01') ";
		
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(acc);
		int j=0;
		for(int i=15000001;i<=15300001;i++){
			j++;
			selectSql.setString(1, "QY2012051"+i);
			selectSql.setString(2, "QY2012051"+i);
			selectSql.setString(3, "QY2012051"+i);
			selectSql.setString(4, "Ǩ�ƿͻ�"+i);
			selectSql.addBatch();
			if(j==commitNum){
				selectSql.executeBatch();
				connection.commit();
				logger.info("................����ҵ������"+i+"����......");
				j=0;
			}
		}
		selectSql.executeBatch();
		connection.commit();
		
//		ResultSet rs=selectSql.executeQuery();
//		while(rs.next()){
//			logger.info("======="+rs.getString("PUTOUTNO"));
//		}
//		rs.close();
	}
		
	
}
