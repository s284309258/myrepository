package com.amarsoft.app.datax.gci;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateSHData extends CommonExecuteUnit {
	
	private String sDate="";
	private String sNextDate ="";
	private String sMaturityDate="";
	private String sLastDate="";
	private String createData="";
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("============��ʼ��ʼ��������===============");
				deleteData();
				initPara();
				logger.info("============��ʼ������������===============");
				
				logger.info("============��ʼ����ƽ���ػ��ļ����ݣ�===============");
								
				CreatData();
				logger.info("============�����ļ�������ɽ�����===============");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void deleteData() throws SQLException{
		String sFlageSql=" select attribute1 from code_library cl where cl.codeno='SHFILEFLAGE' ";
		String flage="0";
		ResultSet soDataRs=null;
    	PreparedStatement selSql;
    	selSql=connection.prepareStatement(sFlageSql);
    	soDataRs=selSql.executeQuery();
    	while(soDataRs.next()){
    		flage=soDataRs.getString("attribute1");
    	}
    	soDataRs.close();
    	
		if("0".equals(flage)){
			
			logger.info("=========ɾ������=============");
			String deleteSql="delete SHDATA_VAlUE sv where sv.inputdate='"+deductDate+"' ";
			PreparedStatement delSql;
			delSql=connection.prepareStatement(deleteSql);
			delSql.execute();
			delSql.close();
		}
	}
	
	public void initPara() throws Exception{
		
		String selectData=	"	select sv.customername,sv.certtype,sv.certid ,sv.sex ,sv.birthday ,sv.occupation ,sv.BUSINESSSUM ,lo.deductaccno, "+
				"	 sv.putoutdate ,sv.maturitydate ,sv.serialno ,sv.putoutno ,sv.emailadd ,sv.serialnos ,sv.pinganguard ,sv.MOBILETELEPHONE "+
				"	from  (select distinct  bc.customername, "+
				"	       ii.certtype as certtype,ii.certid,ii.sex ,ii.birthday,getitemname('Occupation', ii.occupation) as occupation, "+
				"	       bc.BUSINESSSUM,min(lb.putoutdate) as putoutdate ,bc.maturitydate,bc.serialno,min(lb.putoutno) as putoutno, "+
				"	        ii.emailadd,bc.serialno || '001' as serialnos,bc.pinganguard as pinganguard,ii.MOBILETELEPHONE "+
				"	   from business_contract bc,loan_balance lb,  ind_info ii "+
				"	  where bc.customerid = ii.customerid  and lb.contractserialno = bc.serialno and bc.pinganguard in ('010', '020') and  bc.bankflag='PAB' "+
				"	   group by bc.customername, ii.certtype , ii.certid, ii.sex , ii.birthday, ii.occupation, bc.BUSINESSSUM , "+
				"	       bc.maturitydate, bc.serialno, ii.emailadd,bc.serialno || '001', bc.pinganguard,ii.MOBILETELEPHONE)  SV,loan_balance lo "+
				"	        where sv.putoutno = lo.putoutno and lo.putoutdate=? ";
		
		 sDate = StringFunction.replace(deductDate, "/", "");	
		 sNextDate = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,1);
		 sLastDate = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_DAY,-1);
		 sMaturityDate = com.amarsoft.account.util.DateTools.getRelativeDate(deductDate,AccountConstants.TERM_UNIT_YEAR,1).substring(0,10);
		 commitNum =getProperty("commitNum",1);
		 createData = getProperty("createData",selectData);
		 
	}
	
	public void CreatData() throws SQLException{

		String insertSql="insert into SHDATA_VAlUE (SERIALNOS, CUSTOMERNAME, CERTTYPE, CERTID, " +
					   " SEX, BIRTHDAY, OCCUPATION, BUSINESSSUM, PUTOUTDATE, MATURITYDATE, " +
					   " CONTRACTSERIALNO, INUREDATE, INSURANCEENDTIME, DEDUCTACCNO, PUTOUTNO, EMAILADD,pinganguard,inputdate,MOBILETELEPHONE) "+
					   " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?) ";
		
		
		
		
		PreparedStatement inSql;
    	inSql=connection.prepareStatement(insertSql);
    	
    	
    	ResultSet soDataRs=null;
    	PreparedStatement selSql;
    	selSql=connection.prepareStatement(createData);
    	selSql.setString(1, sLastDate);
    	soDataRs=selSql.executeQuery();
    	int i=0;
    	while(soDataRs.next()){
    		i++;
    		 inSql.setString(1, soDataRs.getString("serialnos"));
    		 inSql.setString(2, soDataRs.getString("customername"));
    		 inSql.setString(3, soDataRs.getString("certtype"));
    		 inSql.setString(4, soDataRs.getString("certid"));
    		 inSql.setString(5, soDataRs.getString("sex"));
    		 inSql.setString(6, soDataRs.getString("birthday"));
    		 inSql.setString(7, soDataRs.getString("occupation"));
    		 inSql.setDouble(8, soDataRs.getDouble("businesssum"));
    		 inSql.setString(9, soDataRs.getString("putoutdate"));
    		 inSql.setString(10, soDataRs.getString("maturitydate"));
    		 inSql.setString(11, soDataRs.getString("serialno"));
    		 inSql.setString(12, deductDate);
    		 inSql.setString(13, sMaturityDate);
    		 inSql.setString(14, soDataRs.getString("deductaccno"));
    		 inSql.setString(15, soDataRs.getString("putoutno"));
    		 inSql.setString(16, soDataRs.getString("emailadd"));
    		 inSql.setString(17, soDataRs.getString("pinganguard"));
    		 inSql.setString(18, deductDate);
    		 inSql.setString(19, soDataRs.getString("MOBILETELEPHONE"));
    		 inSql.addBatch();
    		 if(i>commitNum){
    			 inSql.executeBatch();
    			 connection.commit();
    			 i=0;
    		 }
    		
    	}
    	inSql.executeBatch();
    	connection.commit();
    	inSql.close();
    	soDataRs.close();
    	selSql.close();
		
	}
	
	/**
	 * 
	 * @param a 
	 * @param b
	 * @param c
	 * @return
	 * 
	 * for(jdlfal)<br/>{
	 *   jdkf kdkdfjf
	 * }
	 */
	public int test(String a,int b,double c){
		return 1;
	}

	
	
}
