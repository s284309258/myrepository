package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class CreateQYPutoutSDBPAB extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateData();
				logger.info("................����ҵ��������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
		
	public void CreateData() throws SQLException{
		CallableStatement   cs =connection.prepareCall("call QY_PUTOUNO_SDB_PAB_106PR()");    
		  //ִ�д洢����   
		  cs.execute();      
		  cs.close();   
	}
	
//	public void CreateData() throws SQLException{
//		String inSql=" insert into QY_PUTOUNO_SDB_PAB(PUTOUTNO,Insttu_Cde,Loan_Typ,Loan_No,Loanstatus) "
//					+" select lb.putoutno,lb.insttu_cde,lb.loan_typ,lb.loan_no,lb.loanstatus from qy_loan_balance lb ";
//		PreparedStatement ps = connection.prepareStatement(inSql);
//		ps.execute();
//		connection.commit();
//	}
}
