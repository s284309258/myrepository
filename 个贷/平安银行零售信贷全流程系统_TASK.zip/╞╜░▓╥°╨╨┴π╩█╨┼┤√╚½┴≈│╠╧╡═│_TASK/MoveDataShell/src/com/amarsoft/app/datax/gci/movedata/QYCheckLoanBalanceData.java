package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCheckLoanBalanceData extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����������ϸ�����ݣ�.............");
				checkData();
				logger.info("................�������������ϸ��������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void checkData() throws SQLException{
		String al=" insert into qy_chk_loan_resulet     "
				+"  (NORGID, OORGID, "
				+"   NCUSTOMERNAME, OCUSTOMERNAME,    "
				+"   NPUTOUTNO, OPUTOUTNO,  "
				+"   NDEDUCTACCNO, ODEDUCTACCNO,      "
				+"   NDEDUCTACCNO1,ODEDUCTACCNO1,     "
				+"   NDEDUCTACCNO2, ODEDUCTACCNO2,    "
				+"   NBUSINESSSUM, OBUSINESSSUM,      "
				+"   NLOANTERM, OLOANTERM,  "
				+"   NTERM, OTERM,   "
				+"   NRATEMODE, ORATEMODE,  "
				+"   NRATEADJUSTTYPE, ORATEADJUSTTYPE,"
				+"   NRATEFLOAT, ORATEFLOAT,"
				+"   NEXECUTERATE, OEXECUTERATE,      "
				+"   NBEGINDATE, OBEGINDATE,"
				+"   NPUTOUTDATE, OPUTOUTDATE,        "
				+"   NMATURITYDATE, OMATURITYDATE,    "
				+"   NPRCP, PRCP)    "
				+"  select lb.orgid, ql.BCH_CDE,      "
				+"         lb.customername, ql.cust_name,    "
				+"         lb.putoutno, ql.loan_no,   "
				+"         lb.deductaccno, ql.acct_no1,      "
				+"         lb.deductaccno1, ql.acct_no2,     "
				+"         lb.deductaccno2, ql.acct_no3,     "
				+"         lb.businesssum, ql.ln_prcp,"
				+"         lb.loanterm, ql.ln_tnr,    "
				+"         (lb.CTERM - lb.sterm + 1) as NTERM, ql.os_tnr,     "
				+"         lb.ratemode, ql.rate_mode, "
				+"         lb.rateadjusttype, ql.rate_way,   "
				+"         lb.ratefloat, ql.int_rate_adj,    "
				+"         lb.executerate, ql.int_rat,"
				+"         lb.begindate, ql.due_day,  "
				+"         lb.maturitydate, ql.last_due_dt,  "
				+"         lb.putoutdate, ql.actv_dt, "
				+"         (lb.overduebalance + lb.normalbalance) as NPRCP, ql.os_prcp  "
				+"    from qy_chk_loan_detl ql, qy_loan_balance lb     "
				+"   where ql.loan_no = lb.putoutno   "
				+"     and (ql.BCH_CDE <> lb.orgid or ql.cust_name <> lb.customername or"
				+"         ql.ln_prcp <> lb.businesssum or   "
				+"         ql.os_prcp <> (lb.overduebalance + lb.normalbalance) or      "
				+"         ql.acct_no1 <> lb.deductaccno or ql.acct_no2 <> lb.deductaccno1 or  "
				+"         ql.acct_no3 <> lb.deductaccno2 or ql.ln_tnr <> lb.loanterm or"
				+"         ql.os_tnr <> (lb.CTERM - lb.sterm + 1) or   "
				+"         ql.rate_mode <> lb.ratemode or ql.rate_way <> lb.rateadjusttype or  "
				+"         ql.int_rate_adj <> lb.ratefloat or ql.int_rat <> lb.executerate or  "
				+"         ql.due_day <> lb.begindate or ql.actv_dt <> lb.putoutdate or "
				+"         ql.last_due_dt <> lb.maturitydate) ";
		PreparedStatement ps=connection.prepareStatement(al);
		ps.execute();
		connection.commit();
		
	}
	
	
}
