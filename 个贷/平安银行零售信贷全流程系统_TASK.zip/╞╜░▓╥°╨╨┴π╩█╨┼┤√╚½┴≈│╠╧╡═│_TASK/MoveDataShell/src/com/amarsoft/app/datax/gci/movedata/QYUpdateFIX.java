package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateFIX extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����FIX1���ݣ�.............");
				UpdateData1();
				logger.info("................����FIX1������ɣ�..............");
				
				logger.info("................��ʼ����FIX2���ݣ�.............");
				UpdateData2();
				logger.info("................����FIX2������ɣ�..............");
				
				logger.info("................��ʼ����FIX3���ݣ�.............");
				UpdateData3();
				logger.info("................����FIX3������ɣ�..............");
				
				logger.info("................��ʼ����FIX4���ݣ�.............");
				UpdateData4();
				logger.info("................����FIX4������ɣ�..............");
				
				logger.info("................��ʼ����FIX5���ݣ�.............");
				UpdateData5();
				logger.info("................����FIX5������ɣ�..............");
				
				logger.info("................��ʼ����FIX6���ݣ�.............");
				UpdateData6();
				logger.info("................����FIX6������ɣ�..............");
	
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void UpdateData1() throws Exception {
		String al = "update qy_business_contract bc set bc.putouttype='010' where  PUTOUTTYPE is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
		
	}
	
	public void UpdateData2() throws Exception {
		String al = "update qy_business_contract bc set bc.BASERATETYPE='030' where  bc.businesstype like '1200%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void UpdateData3() throws Exception {
		String al = "update qy_business_contract bc set CREDITBEGINDATE=PUTOUTDATE,CREDITENDDATE=MATURITYDATE where  CREDITBEGINDATE is null or CREDITENDDATE is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void UpdateData4() throws Exception {
		String al = "update qy_business_contract bc set bc.approveresult='020' where  bc.approveresult is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void UpdateData5() throws Exception {
		String al = "update qy_business_contract bc set bc.PaymentMode='0' where  bc.PaymentMode is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	
	public void UpdateData6() throws Exception {
		String al = "update qy_business_contract bc set bc.PHASETYPE='030' where  bc.PHASETYPE is null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}


}
