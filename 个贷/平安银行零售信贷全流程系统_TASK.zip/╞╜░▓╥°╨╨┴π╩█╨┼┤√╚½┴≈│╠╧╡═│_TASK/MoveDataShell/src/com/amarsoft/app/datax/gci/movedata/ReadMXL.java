package com.amarsoft.app.datax.gci.movedata;

public class ReadMXL {

}
