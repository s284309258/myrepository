package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateGJJRelative extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����GJJ���ݣ�.............");
				CreateData();
				logger.info("................����GJJ������ɣ�..............");

				logger.info("................���¹������������1���ݣ�.............");
				UpdateBCBarCodeRelative1();
				logger.info("................���¹������������1������ɣ�..............");
				
				logger.info("................���¹������������2���ݣ�.............");
				UpdateBCBarCodeRelative2();
				logger.info("................���¹������������2������ɣ�..............");
				
				logger.info("................���¹������������3���ݣ�.............");
				UpdateBCBarCodeRelative3();
				logger.info("................���¹������������3������ɣ�..............");
				
				logger.info("................���¹������������4���ݣ�.............");
				UpdateBCBarCodeRelative4();
				logger.info("................���¹������������4������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateData() throws SQLException {
		String inSql = " insert into qy_contract_relative(serialno,objecttype,objectno,relativesum) "
				+ " select case "
				+ "    when b.contractserialno = 'SDBCONTNO' then "
				+ "     b.initqybcno "
				+ "    else "
				+ "     b.contractserialno "
				+ "    end as T, "
				+ "    'GJJContract', "
				+ "   case "
				+ "     when c.contractserialno = 'SDBCONTNO' then "
				+ "      c.initqybcno "
				+ "     else "
				+ "      c.contractserialno "
				+ "   end as A, "
				+ "         b.businesssum "
				+ "   from qy_sh_gjj_lncomb q, qy_loan_balance b, qy_loan_balance c "
				+ "  where q.lb_no_1 = b.putoutno "
				+ "    and q.lb_no_2 = c.putoutno";
		PreparedStatement ps = connection.prepareStatement(inSql);
		ps.execute();
		connection.commit();
	}

	public void UpdateBCBarCodeRelative1() throws SQLException {

		String update = "update qy_business_contract bc set bc.TRADEBARCODE=? where bc.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(update);

		String selectSql = "select bc.bar_code_no,qg.lb_no_1 from qy_sh_gjj_lncomb qg,qy_business_contract bc, "
				+ " (select s.lb_no_1 from qy_sh_gjj_lncomb s group by s.lb_no_1 having count(s.lb_no_1)=1) dd "
				+ " where qg.lb_no_2=bc.serialno and qg.lb_no_1=dd.lb_no_1 ";
		PreparedStatement ps1 = connection.prepareStatement(selectSql);
		ResultSet rs = ps1.executeQuery();
		int i = 0, j = 0;
		while (rs.next()) {
			j++;
			i++;
			ps.setString(1, rs.getString("bar_code_no")+"______________");
			ps.setString(2, rs.getString("lb_no_1"));
			ps.addBatch();
			if (i > 100) {
				ps.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".......����.." + j + " �������� ��.............");
			}
		}
		rs.close();
		ps.executeBatch();
		connection.commit();
		logger.info(".......����.." + j + " �������� ��.............");
	}

	public void UpdateBCBarCodeRelative2() throws SQLException {

		String update = "update qy_business_contract bc set bc.TRADEBARCODE=? where bc.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(update);

		String selectSql = "select bc.bar_code_no,qg.lb_no_2 from qy_sh_gjj_lncomb qg,qy_business_contract bc, "
				+" (select s.lb_no_2 from qy_sh_gjj_lncomb s group by s.lb_no_2 having count(s.lb_no_2)=1) dd  "
				+"  where qg.lb_no_1=bc.serialno and qg.lb_no_2=dd.lb_no_2 ";
		PreparedStatement ps1 = connection.prepareStatement(selectSql);
		ResultSet rs = ps1.executeQuery();
		int i = 0, j = 0;
		while (rs.next()) {
			j++;
			i++;
			ps.setString(1, rs.getString("bar_code_no")+"______________");
			ps.setString(2, rs.getString("lb_no_2"));
			ps.addBatch();
			if (i > 100) {
				ps.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".......����.." + j + " �������� ��.............");
			}
		}
		rs.close();
		ps.executeBatch();
		connection.commit();
		logger.info(".......����.." + j + " �������� ��.............");
	}
	
	
	public void UpdateBCBarCodeRelative3() throws SQLException {
		String update = "update qy_business_contract bc set bc.TRADEBARCODE=? where bc.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(update);

		String selectSql = " select s.lb_no_2 from qy_sh_gjj_lncomb s group by s.lb_no_2 having count(s.lb_no_2)=2 ";
		PreparedStatement ps1 = connection.prepareStatement(selectSql);
		ResultSet rs = ps1.executeQuery();
		
		String selectSql2 = "select bc.bar_code_no from qy_sh_gjj_lncomb lb,business_contract bc where lb.lb_no_2=? and bc.serialno=lb.lb_no_1 ";
		PreparedStatement ps2 = connection.prepareStatement(selectSql2);
		ResultSet rs2 = null;
		int i=0,j=0;
		String barcode="";
		String bcno="";
		while(rs.next()){
			i++;
			j++;
			barcode="";
			bcno=rs.getString("lb_no_2");
			ps2.setString(1, bcno);
			rs2=ps2.executeQuery();
			while(rs2.next()){
				barcode+=rs2.getString("bar_code_no");
			}
			rs2.close();
			
			ps.setString(1, barcode);
			ps.setString(2, bcno);
			ps.addBatch();
			if(i>=100){
				ps.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".......����.." + j + " �������� ��.............");
			}
			
		}
		rs.close();
		ps.executeBatch();
		connection.commit();
		logger.info(".......����.." + j + " �������� ��.............");
		
	}
	
	
	public void UpdateBCBarCodeRelative4() throws SQLException {
		String update = "update qy_business_contract bc set bc.TRADEBARCODE=? where bc.serialno=? ";
		PreparedStatement ps = connection.prepareStatement(update);

		String selectSql = "select s.lb_no_1 from qy_sh_gjj_lncomb s group by s.lb_no_1 having count(s.lb_no_1)=2 ";
		PreparedStatement ps1 = connection.prepareStatement(selectSql);
		ResultSet rs = ps1.executeQuery();
		
		String selectSql2 = "select bc.bar_code_no from qy_sh_gjj_lncomb lb,business_contract bc where lb.lb_no_1=? and bc.serialno=lb.lb_no_2 ";
		PreparedStatement ps2 = connection.prepareStatement(selectSql2);
		ResultSet rs2 = null;
		int i=0,j=0;
		String barcode="";
		String bcno="";
		while(rs.next()){
			i++;
			j++;
			barcode="";
			bcno=rs.getString("lb_no_1");
			ps2.setString(1, bcno);
			rs2=ps2.executeQuery();
			while(rs2.next()){
				barcode+=rs2.getString("bar_code_no");
			}
			rs2.close();
			
			ps.setString(1, barcode);
			ps.setString(2, bcno);
			ps.addBatch();
			if(i>=100){
				ps.executeBatch();
				connection.commit();
				i = 0;
				logger.info(".......����.." + j + " �������� ��.............");
			}
			
		}
		rs.close();
		ps.executeBatch();
		connection.commit();
		logger.info(".......����.." + j + " �������� ��.............");
		
	}
	
	
	

}
