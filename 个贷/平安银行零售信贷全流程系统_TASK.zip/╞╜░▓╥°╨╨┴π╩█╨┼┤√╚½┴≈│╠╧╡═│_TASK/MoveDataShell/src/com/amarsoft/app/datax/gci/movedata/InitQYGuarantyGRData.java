package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.metadata.ColumnMetaData;
import com.amarsoft.are.metadata.TableMetaData;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class InitQYGuarantyGRData extends CommonExecuteUnit {
	
	private String sDate="";
	private String sNextDate ="";
	private String sMaturityDate="";
	private String sLastDate="";
	private String createData="";
	private int commitNum=1;
	private int initnumber=0;
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������...............");
				initData();
				logger.info(".................��ʼ������������...............");
				
				logger.info(".................��ʼ��ʼ��QY_GUAR_LOAN_CR1���ݣ�...............");
				initQYGR1();
				logger.info(".................��ʼ��QY_GUAR_LOAN_CR���ݽ�����...............");
				
								
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	
	//��ʼ��ѺƷ��ϵ������1
	public void initQYGR1() throws Exception{
		  CallableStatement   cs =connection.prepareCall("call UPDATE_GUAR_LOAN_CR_106PR()");    
		  //ִ�д洢����   
		  cs.execute();      
		  cs.close();   
	}	
	

}
