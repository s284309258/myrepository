package com.amarsoft.app.datax.gci;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amarsoft.DBConnection.DBConnection;
import com.amarsoft.Task.ExecProgram.ExecAbstract;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.are.ARE;
import com.amarsoft.are.log.Log;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.Task;
import com.amarsoft.task.TaskBuilder;

public class BatchTaskUnit extends ExecAbstract{
	
	public synchronized void run(){
		
		String are = "etc/are.xml";
		String task_batch = "../sys-config/datamove_task.xml";


		long lInterval = this.ti.getInterval();
	
        ARE.init(are);
        
        Log logger = ARE.getLog();
        Connection connection = null;
        try {
        	DBConnection dc = new DBConnection();
			connection =dc.getConn("Loan");
		//	updateBatchFlag(lInterval,connection);
			
			String sOFPreFlag = "0";
		    String sBatchDealFlag = "0";
		    String selectSql = " select bl.attribute1,bl.attribute2 from batch_lock bl where bl.lockno='DATAMOVE106' and bl.itemno='10' ";
		    PreparedStatement psInserSql = connection.prepareStatement(selectSql);
			ResultSet rs = psInserSql.executeQuery();
			if(rs.next())
			{
				sOFPreFlag = rs.getString("attribute1");
				sBatchDealFlag = rs.getString("attribute2");
			}
			rs.close();
			psInserSql.close();
	
			if(sBatchDealFlag.equals("0")){
				logger.info("��ʼ����Ǩ������");
				execute(task_batch);
				//add by dxu ,�����º���esb����
				executeEsbFlag(connection);
			}
		}
        catch (Exception e) {
        	logger.error("�������󣡴�����Ϣ��"+e.getMessage());
			e.printStackTrace();
		}
        finally
        {
        	clearResource(connection);
        }
	}

	//add by dxu ,�����º���esb����
	private void executeEsbFlag(Connection connection ) throws Exception {
		// TODO Auto-generated method stub
		OCIConfig.initEsbFlag(connection);
	}

	private void execute(String s) throws Exception
	{
		//String taskFile = ARE.getProperty();
		ARE.getLog().fatal("taskFile="+s);
		
		OCIConfig.loadOCIConfig(true);
		OCIConfig.setEnvironment("Cycle");
		OCIConfig.setDataSourceName("Loan");
		//OCIConfig.setEnvironment("Batch");
		//OCIConfig.setDataSourceName("ploan");
		Task task = TaskBuilder.buildTaskFromXML(s);
		if (task != null) {
			task.start();
		}
		else
			ARE.getLog().fatal("��������ʧ�ܣ�");

	}
	
	private void clearResource(Connection connection) {
		// �ر����ݿ�����
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				ARE.getLog().warn(e);
			}
			connection = null;
		}
	}
	
	/*
	 * �����ǰʱ��ﵽ������ִ��ʱ�䣬���±�ploan_setup�е�����ִ�б�־
	 * */
	private void updateBatchFlag(long lInterval,Connection connection) throws Exception
	{
		String sBatchExexuteTime = "";
		String sNextBatchExecuteDate = "";
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String sDate = formatter.format(cal.getTime());
		
		String selectSql = " select BatchBeginTime,NextBatchExecuteDate from ploan_setup ";
		PreparedStatement psSelectSql = connection.prepareStatement(selectSql);
		ResultSet rs = psSelectSql.executeQuery();
		if(rs.next())
		{
			sBatchExexuteTime=rs.getString("BatchBeginTime");
			sNextBatchExecuteDate = rs.getString("NextBatchExecuteDate");
		}
		rs.close();
		psSelectSql.close();
		
		if(sBatchExexuteTime==null || sBatchExexuteTime.length()==0)
			throw new Exception("ploan_setup������ִ��ʱ��δ���壡");
		if(sNextBatchExecuteDate==null || sNextBatchExecuteDate.length()==0)
			throw new Exception("ploan_setup���´�����ִ������δ���壡");
		
		String[] timeArray = sBatchExexuteTime.split(":");
		Calendar calendar = Calendar.getInstance();
		Calendar calendar1 = Calendar.getInstance();
		calendar.set(calendar.get(calendar.YEAR), calendar
				.get(calendar.MONTH), calendar.get(calendar.DATE), Integer
				.parseInt(timeArray[0]), Integer.parseInt(timeArray[1]),
				Integer.parseInt(timeArray[2]));
		
		if(calendar1.getTimeInMillis()>=calendar.getTimeInMillis() && sNextBatchExecuteDate.equals(sDate))
		{
			String updateSql = " update ploan_setup set BatchDealFlag = '1' ";
			PreparedStatement psInserSql = connection.prepareStatement(updateSql);
			psInserSql.execute();
			psInserSql.close();
		}
		
	}


}
