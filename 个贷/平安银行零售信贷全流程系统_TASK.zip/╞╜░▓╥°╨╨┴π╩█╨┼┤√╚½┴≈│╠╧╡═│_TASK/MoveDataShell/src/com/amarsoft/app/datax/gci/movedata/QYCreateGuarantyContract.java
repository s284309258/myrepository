package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateGuarantyContract  extends CommonExecuteUnit {
	
	private int commitNum=1;
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateQYGC();
				logger.info("................����ҵ��������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void CreateQYGC() throws SQLException{
		String selectSql="select distinct qc.vouchtype, "
						+"       gr.CONTRACTNO as CONTRACTNO,"
						+"       qc.serialno,  "
						+"       qc.customerid,"
						+"       qi.certtype,  "
						+"       qi.certid,    "
						+"       sum(gi.CONFIRMVALUE) as gnvalue"
						+"  from qy_guaranty_relative gr,       "
						+"       qy_business_contract qc,       "
						+"       qy_customer_info     qi,       "
						+"       qy_guaranty_info     gi        "
						+" where gr.objectno = qc.serialno      "
						+" and gr.guarantyid=gi.guarantyid      "
						+" and qc.customerid=qi.customerid      "
						+" group by                             "
						+" qc.vouchtype,                        "
						+"       gr.CONTRACTNO,                 "
						+"       qc.serialno,                   "
						+"       qc.customerid,                 "
						+"       qi.certtype,                   "
						+"       qi.certid                      ";
		
		String insertSql=" insert into qy_guaranty_contract ( "
				+" SERIALNO,"
				+" CONTRACTTYPE,"
				+" VOUCHTYPE,"
				+" CONTRACTSTATUS,"
				+" CONTRACTNO,"
				+" GUARANTORID,"
				+" GUARANTORNAME,"
				+" GUARANTYCURRENCY,"
				+" GUARANTYVALUE,"
				+" UPDATEDATE,"
				+" GUARANTYRATE,"
				+" GUARANTORTYPE,"
				+" CUSTOMERID,"
				+" CERTID,"
				+" CERTTYPE"
				+" )values (  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?, ?, ?, ? )";
		
		PreparedStatement insertPS;
		insertPS=connection.prepareStatement(insertSql);
		
		PreparedStatement selectPS;
		selectPS = connection.prepareStatement(selectSql);
		
		ResultSet rs = selectPS.executeQuery();
		
		int i=0;
		int j=0;
		while(rs.next()){
			i++;
			j++;
			insertPS.setString(1, rs.getString("CONTRACTNO"));
			insertPS.setString(2, "010");
			insertPS.setString(3, rs.getString("vouchtype"));
			insertPS.setString(4, "");
			insertPS.setString(5, rs.getString("serialno"));
			insertPS.setString(6, "");
			insertPS.setString(7, "");
			insertPS.setString(8, "RMB");
			insertPS.setDouble(9, rs.getDouble("gnvalue"));
			insertPS.setString(10, "");
			insertPS.setDouble(11, 0.0);
			insertPS.setString(12, "04");
			insertPS.setString(13, rs.getString("customerid"));
			insertPS.setString(14, rs.getString("certid"));
			insertPS.setString(15, rs.getString("certtype"));
			insertPS.addBatch();
			if(commitNum==i){
				i=0;
				insertPS.executeBatch();
				connection.commit();
				logger.info("................�������� "+j+" ��..............");
			}

		}
		rs.close();
		insertPS.executeBatch();
		connection.commit();
	}
}
