package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;


import com.amarsoft.account.Deal.TransProvider;
import com.amarsoft.account.change.LoanChange;
import com.amarsoft.account.entity.AttributeField;
import com.amarsoft.account.entity.BackBill;
import com.amarsoft.account.entity.BusinessPutOut;
import com.amarsoft.account.entity.LoanBalance;
import com.amarsoft.account.ledger.CreateLedger;
import com.amarsoft.account.ledger.LedgerDetail;
import com.amarsoft.account.ledger.LedgerGeneral;
import com.amarsoft.account.sysconfig.BusinessTypeConfig;
import com.amarsoft.account.sysconfig.InterestRateConfig;
import com.amarsoft.account.sysconfig.SystemConfig;
import com.amarsoft.account.util.AccountConstants;
import com.amarsoft.account.util.CalInterest;
import com.amarsoft.account.util.DateTools;
import com.amarsoft.account.util.StringTools;
import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.are.util.DataConvert;
import com.amarsoft.are.util.StringFunction;

public class QYLedgerGeneralPS extends QYTransProvider {
		
	
	/**
	 * @author ���ɷ�¼
	 * @param TransNo
	 * @param loanBalance
	 * @param billNo
	 * @param Conn
	 * @throws Exception
	 */
	public void CreateLedgerDeal(Connection Conn,String PutoutNo) throws Exception{
		String TransNo="1001";
		String billNo="230000"+PutoutNo;
		String OrgID="";
		String AccDate="2012/10/06";
		String Currency="";
		Double balance=0.0;
		String BusinessType="";
		String LoanTerm="";
		String bankFlag="";
		String BusinessSubType="";
		String CustomerType="";
		String BusinessKind="";
		
		String selectSql=" select qb.putoutno, "
				      +" oi.orgid,  "
				      +" qb.currency, "
				      +" qb.normalbalance + qb.overduebalance as balance, "
				      +" BusinessType, "
				      +" LoanTerm, "
				      +" bankFlag, "
				      +" BusinessSubType, "
				      +" CustomerType, "
				      +" BusinessKind "
				      +"  from qy_loan_balance qb, org_info oi "
				      +" where qb.orgid = oi.mainframeorgid "
				      +" and qb.putoutno = '"+PutoutNo+"' ";
		PreparedStatement selPs=Conn.prepareStatement(selectSql);
		ResultSet rs = selPs.executeQuery();
		System.out.println("==========1="+selectSql);
		while(rs.next()){
			System.out.println("==========0=");
			PutoutNo = rs.getString("PutoutNo");
			OrgID=rs.getString("orgid"); 
			Currency=rs.getString("currency"); 
			balance=rs.getDouble("balance");
			BusinessType=rs.getString("BusinessType"); 
			LoanTerm =rs.getString("LoanTerm");
			bankFlag=rs.getString("bankFlag");
			BusinessSubType=rs.getString("BusinessSubType");
			CustomerType=rs.getString("CustomerType");
			BusinessKind=rs.getString("BusinessKind");
		}
		rs.close();
		
		
		
		System.out.println("="+PutoutNo+"="+OrgID+"="+Currency
				+"="+balance+BusinessType+"="+LoanTerm+bankFlag
				+"="+BusinessSubType+"="+CustomerType+"="+BusinessKind);
		
		
		QYLedgerDetail qyLedgerDetail = new QYLedgerDetail();
		QYLedgerGeneral qyLedgerGeneral = new QYLedgerGeneral();
		qyLedgerDetail.OpenInsertQYLedgerDetail(Conn);
		qyLedgerGeneral.OpenInsertQYLedgerGeneral(Conn);
		qyLedgerGeneral.OpenUpdateQYLedgerGeneral(Conn);
		
		HashMap<String,AttributeField> inputPara = new HashMap<String,AttributeField>();
		inputPara = SetInputPara(inputPara,"SerialNo",TransNo+billNo);//������ˮ��
		inputPara = SetInputPara(inputPara,"PutOutNo",PutoutNo);
		inputPara = SetInputPara(inputPara,"BillNo",billNo);
		inputPara = SetInputPara(inputPara,"AccDate",AccDate);
		inputPara = SetInputPara(inputPara,"OrgID",OrgID);
		inputPara = SetInputPara(inputPara,"Currency",Currency);
		inputPara = SetInputPara(inputPara,"TransNo",TransNo);
		inputPara = SetInputPara(inputPara,"BusinessSum",balance);
		inputPara = SetInputPara(inputPara,"BusinessType",BusinessType);
		inputPara = SetInputPara(inputPara,"LoanTerm",LoanTerm);
		inputPara = SetInputPara(inputPara,"ActualMoney",0.0);
		inputPara = SetInputPara(inputPara,"ActualFee",0.0);
		inputPara = SetInputPara(inputPara,"AccountOpenFee",0.0);
		 //���ÿ�������ط���
		inputPara = SetInputPara(inputPara, "BackFee",0.0);
		inputPara = SetInputPara(inputPara, "CommissionFee",0.0);
		inputPara = SetInputPara(inputPara, "BankFlag","1");
		
		//С΢����γ��
		if("SWPM".equals(BusinessKind)){
			inputPara = SetInputPara(inputPara,"BusinessSubType",BusinessSubType);//��������
		}else{
			inputPara = SetInputPara(inputPara,"BusinessSubType","100000000000");//�������ֶ���Ч
		}
		
		inputPara = SetInputPara(inputPara,"CustomerType",CustomerType); //�ͻ�����
		inputPara = SetInputPara(inputPara,"LoanFeeType","2000000"); //�������ͣ��˴���Ч����������ڼӽ���
		inputPara = SetInputPara(inputPara,"BusinessKind",StringTools.getBusinessKindChange(BusinessKind));
		//�˻�����
		ArrayList<QYLedgerDetail> QYLedgerDetailList = new ArrayList<QYLedgerDetail>();
		QYLedgerDetail Ld = new QYLedgerDetail();
		
		QYLedgerDetailList = QYCreateLedger.getLedgerSubjectList(inputPara);
		for(int k=0;k<QYLedgerDetailList.size();k++){
			System.out.println("==========="+k);
			Ld = QYLedgerDetailList.get(k);
			qyLedgerGeneral.setPutOutNo(Ld.getPutOutNo());
			qyLedgerGeneral.setAccountNo(Ld.getAccountNo());
			qyLedgerGeneral.setSubjectNo(Ld.getSubjectNo());
			qyLedgerGeneral.setSubjectName(Ld.getSubjectname());//������Ŀ����
			qyLedgerGeneral.setCurrency(Ld.getCurrency());
			qyLedgerGeneral.setDebitBalance(Ld.getDebitAmt());
			qyLedgerGeneral.setCreditBalance(Ld.getCreditAmt());
			qyLedgerGeneral.setOrgID(Ld.getOrgID());
			qyLedgerGeneral.setSerialNo(getAccountNo(Conn));
			qyLedgerGeneral.setDirection(Ld.getLoanWay());
			qyLedgerGeneral.InsertQYLedgerGeneral();	
			System.out.println("==========="+Ld.getPutOutNo()+"=="+Ld.getAccountNo()+"=="+Ld.getSubjectNo()+"=="+Ld.getSubjectname()+"=="+Ld.getCurrency()
					+"=="+Ld.getDebitAmt()+"=="+Ld.getCreditAmt()+"=="+Ld.getOrgID()+"=="+Ld.getOrgID());
			
		}
		qyLedgerGeneral.executeBatch();
		
		HashMap<String,String>  hl=getAccountSubjectHashMap(getStringInputPara(inputPara,"PutOutNo"),Conn);
		
		//���Ŵ���
		LedgerDeal(qyLedgerDetail,qyLedgerGeneral,inputPara,hl);
		qyLedgerGeneral.executeBatch();
		qyLedgerDetail.executeBatch();
		for(int k=0;k<QYLedgerDetailList.size();k++){
			System.out.println("=======000===="+k);
			Ld = QYLedgerDetailList.get(k);
			System.out.println("==========="+Ld.getPutOutNo()+"=="+Ld.getAccountNo()+"=="+Ld.getSubjectNo()+"=="+Ld.getSubjectname()+"=="+Ld.getCurrency()
					+"=="+Ld.getDebitAmt()+"=="+Ld.getCreditAmt()+"=="+Ld.getOrgID()+"=="+Ld.getOrgID());
		}
		qyLedgerDetail.close();
		qyLedgerGeneral.close();
	}
		
		
	
	/**
     * �˺Ż�ȡ����
     * @param ledgerAccount
     * @param loanAccount
     * @return
	 * @throws Exception 
     */
    private String getAccountNo(Connection conn) throws Exception{
      // String accountNo=subjectno+OrgID+ObjectType+ObjectNo;
    	   String serialNo = com.amarsoft.account.util.StringTools.getSequence(conn,"SEQ_CLEAN");
    	  // transAction.disConnect();
           return serialNo;
    }
    
    
    public static HashMap<String,String> getAccountSubjectHashMap(String PutOutNo,Connection Conn) throws Exception{
		HashMap<String,String> accountSubjectHashMap = new HashMap<String,String>();//��Ŀ�˺Ŷ���
		String sqlLedgerGeneral = "select * from qy_ledger_general Where PutOutNo = ?";
		
		PreparedStatement psSelectLedgerGeneral = Conn.prepareStatement(sqlLedgerGeneral);
		psSelectLedgerGeneral.setString(1, PutOutNo);
		ResultSet rs = psSelectLedgerGeneral.executeQuery();
		while(rs.next()){
			accountSubjectHashMap.put(rs.getString("AccountNo"), rs.getString("SubjectNo"));	
		}
		rs.close();
		psSelectLedgerGeneral.close();
		
		return accountSubjectHashMap;
	}
}
