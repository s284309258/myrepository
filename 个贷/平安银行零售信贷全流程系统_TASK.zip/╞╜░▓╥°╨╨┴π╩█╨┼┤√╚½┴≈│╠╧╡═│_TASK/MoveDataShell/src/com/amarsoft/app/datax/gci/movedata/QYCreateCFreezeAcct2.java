package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateCFreezeAcct2 extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {				
				logger.info("................��ʼ����PAB�����浥�������ݣ�.............");
				CreateData();
				logger.info("................����PAB�����浥����������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	

	public void CreateData() throws SQLException{
		int i=0,j=0,k=1000000;
		String al="select distinct gi.rightid,gi.depositserialno " +
				" from loan_balance lb, guaranty_relative gr , guaranty_info gi " +
				" where lb.loanstatus in ('0', '1', '4', '5') " +
				" and gr.objectno = lb.contractserialno " +
				" and gr.objecttype  like '%ContractApply' " +
				" and gr.guarantyid = gi.guarantyid" +
				" and gi.guarantytype = '030010'" +
				" and gi.guarantyid not like 'QY%'" +
				" and length(gi.depositserialno) = 5";
		String insertSql="insert into credit_freeze_acct(serialno,freezeacctno,freezeno,depositserialno,status,updatedate,freezestatus) "
				+" values(?,?,?,?,?,?,?) ";
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement inps=connection.prepareStatement(insertSql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			k++;
			inps.setString(1, "QYB"+k);
			inps.setString(2, rs.getString("rightid"));
			inps.setString(3, "");
			inps.setString(4, rs.getString("depositserialno"));
			inps.setString(5, "1");
			inps.setString(6, deductDate);
			inps.setString(7, "A");
			inps.addBatch();
			if(i>999){
				inps.executeBatch();
				connection.commit();
				i=0;
				logger.info("................����"+j+"������..............");
			}
		}
		inps.executeBatch();
		connection.commit();
		ps.close();
		inps.close();
		rs.close();
	}
	
	
	
}
