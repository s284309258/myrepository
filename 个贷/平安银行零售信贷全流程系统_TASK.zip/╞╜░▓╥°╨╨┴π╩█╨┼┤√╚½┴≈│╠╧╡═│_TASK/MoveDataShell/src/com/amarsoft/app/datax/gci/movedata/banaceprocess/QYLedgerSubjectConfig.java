package com.amarsoft.app.datax.gci.movedata.banaceprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.amarsoft.account.exception.LoanException;
import com.amarsoft.account.ledger.SubjectInfo;
import com.amarsoft.account.ledger.TransEntry;
import com.amarsoft.account.ledger.TransactionCode;
import com.amarsoft.account.sysconfig.LedgerSubjectConfig;
import com.amarsoft.account.util.Logger;

public class QYLedgerSubjectConfig extends LedgerSubjectConfig  {
	private static boolean haveLoaded = false;
	private static HashMap<String,TransactionCode> LedgerInfoHashMap=null;
	
	private static HashMap<String,TransEntry> LedgerSubjectHashMap=null;
	
	private static HashMap<String,SubjectInfo> SubjectInfoHashMap=null;
	
	private static HashMap<String,TransEntry> FareLedgerSubjectHashMap=null;//������ר�Ŵ�������
	
	private static HashMap<String,TransEntry> BWLedgerSubjectHashMap=null;//������ר�Ŵ�������ҵ��
	
	public  QYLedgerSubjectConfig(Connection Conn) throws SQLException{
		loadLedgerInfoFromDB(false, Conn);
	}

	public static TransactionCode getTransactionCode(String id) throws LoanException{
		TransactionCode transactionCode = getLedgerInfoHashMap().get(id);
    	if(transactionCode==null) throw new LoanException("δ�ҵ���������"+id+"�Ķ��壬����Ľ��ױ�ţ�����δ��ʼ����������!");
        return transactionCode;
	}
	
	public static String getSubjectLoanWay(String SubjectNo) throws LoanException{
		SubjectInfo subjectInfo = getSubjectInfoHashMap().get(SubjectNo);
    	if(subjectInfo==null) throw new LoanException("δ�ҵ���Ŀ"+SubjectNo+"�Ķ��壬����Ŀ�Ŀ��ţ�����δ��ʼ����������!");
        return subjectInfo.getLoanWay();
	}
	
	//��¼����
	public static void loadLedgerInfoFromDB(boolean reload,Connection Conn) throws SQLException{		
		if(reload||!haveLoaded){//��Ҫ���¼��أ�������δ���ػ��ʽ���ã������
			LedgerInfoHashMap=new HashMap<String,TransactionCode>();
			LedgerSubjectHashMap=new HashMap<String,TransEntry>();
			SubjectInfoHashMap=new HashMap<String,SubjectInfo>();
			
			FareLedgerSubjectHashMap=new HashMap<String,TransEntry>();
			BWLedgerSubjectHashMap=new HashMap<String,TransEntry>();
			
			//��������
			String getTransAction = "select TransID,Name,DesCription,ExecuteScript from Trans_action where status = '1'" ;
			
			String getTransInfoSql = "select TransID,SortID,TeamFlag,Direction,Digest,SubjectNo,Amount,Status,ValidExpression " +
					"from Trans_Entry where TransID = ? and Status = '1' order by TeamFlag,SortID";
			
			PreparedStatement psGetTransInfo = Conn.prepareStatement(getTransInfoSql);		  
			PreparedStatement psGetTransActionInfo = Conn.prepareStatement(getTransAction);
			
			ResultSet rs = psGetTransActionInfo.executeQuery();
			while(rs.next()){
				String TransID = rs.getString("TransID");
				TransactionCode transAction = new TransactionCode();
				LedgerInfoHashMap.put(TransID, transAction);
				transAction.setTransID(TransID);
				transAction.setName(rs.getString("Name"));
				transAction.setDescription(rs.getString("DesCription"));
				transAction.setExecuteScript(rs.getString("ExecuteScript"));
				
				HashMap<String, TransEntry> transEntryHashMap = new HashMap<String, TransEntry>();
				psGetTransInfo.setString(1, TransID);
				ResultSet rs1 = psGetTransInfo.executeQuery();
				while(rs1.next()){
					TransEntry transEntry = new TransEntry();
					transEntryHashMap.put(rs1.getString("SortID"), transEntry);
					transEntry.setTransID(rs1.getString("TransID"));
				 	transEntry.setSortID(rs1.getString("SortID"));
				 	transEntry.setTeamFlag(rs1.getString("TeamFlag"));
				 	transEntry.setDirection(rs1.getString("Direction"));
				 	transEntry.setDigest(rs1.getString("Digest"));
				 	transEntry.setSubjectNo(rs1.getString("SubjectNo"));
				 	transEntry.setAmount(rs1.getString("Amount"));
				 	transEntry.setValidExpression(rs1.getString("ValidExpression"));
				}
				rs1.close();
				transAction.setTransEntryHashMap(transEntryHashMap);
			}
			rs.close();
			psGetTransActionInfo.close();
			psGetTransInfo.close();
			
			//��Ŀ����
			String getLedgerSubjectSql = "select SortID,TeamFlag,Direction,Digest,SubjectNo,ValidExpression " +
					"from loan_subject where Status = '1'";			
			PreparedStatement psLedgerSubjectInfo = Conn.prepareStatement(getLedgerSubjectSql);		  
			rs = psLedgerSubjectInfo.executeQuery();
			while(rs.next()){
				TransEntry transEntry = new TransEntry();
				LedgerSubjectHashMap.put(rs.getString("SubjectNo"), transEntry);
			 	transEntry.setSortID(rs.getString("SortID"));
			 	transEntry.setTeamFlag(rs.getString("TeamFlag"));
			 	transEntry.setDirection(rs.getString("Direction"));
			 	transEntry.setDigest(rs.getString("Digest"));
			 	transEntry.setSubjectNo(rs.getString("SubjectNo"));
			 	transEntry.setAmount("0");
			 	transEntry.setValidExpression(rs.getString("ValidExpression"));
			}
			rs.close();
			psLedgerSubjectInfo.close();

			//��Ŀ��Ϣ
			String SubjectInfoSql = "select * from subject_info where subjectlevel='3'";			
			PreparedStatement psSubjectInfo = Conn.prepareStatement(SubjectInfoSql);		  
			rs = psSubjectInfo.executeQuery();
			while(rs.next()){
				SubjectInfo subjectInfo = new SubjectInfo();
				SubjectInfoHashMap.put(rs.getString("SubjectNo"), subjectInfo);
				subjectInfo.setSubjectNo(rs.getString("SubjectNo"));
				subjectInfo.setSubjectName(rs.getString("SubjectName"));
				subjectInfo.setSubjectLevel(rs.getString("SubjectLevel"));
				subjectInfo.setLoanWay(rs.getString("LoanWay"));
				subjectInfo.setSubType(rs.getString("SubType"));
				subjectInfo.setStatus(rs.getString("Status"));
			}
			rs.close();
			psSubjectInfo.close();  
			
			
			
			//���ÿ�Ŀ���ã�С΢���������ò������˱�ר�ã�
			String getFareLedgerSubjectSql = "select SortID,TeamFlag,Direction,Digest,SubjectNo,ValidExpression " +
					"from loan_subject where Status = '1' and TeamFlag in ('94','95','40')";			
			PreparedStatement psFareLedgerSubjectInfo = Conn.prepareStatement(getFareLedgerSubjectSql);		  
			rs = psFareLedgerSubjectInfo.executeQuery();
			while(rs.next()){
				TransEntry transEntry = new TransEntry();
				FareLedgerSubjectHashMap.put(rs.getString("SubjectNo"), transEntry);
			 	transEntry.setSortID(rs.getString("SortID"));
			 	transEntry.setTeamFlag(rs.getString("TeamFlag"));
			 	transEntry.setDirection(rs.getString("Direction"));
			 	transEntry.setDigest(rs.getString("Digest"));
			 	transEntry.setSubjectNo(rs.getString("SubjectNo"));
			 	transEntry.setAmount("0");
			 	transEntry.setValidExpression(rs.getString("ValidExpression"));
			}
			rs.close();
			psFareLedgerSubjectInfo.close();
			
			//�����Ŀ���ã�С΢����������������˱�ר�ã�
			String getBWLedgerSubjectSql = "select SortID,TeamFlag,Direction,Digest,SubjectNo,ValidExpression " +
					"from loan_subject where Status = '1' and TeamFlag ='98' ";			
			PreparedStatement psBWLedgerSubjectInfo = Conn.prepareStatement(getBWLedgerSubjectSql);		  
			rs = psBWLedgerSubjectInfo.executeQuery();
			while(rs.next()){
				TransEntry transEntry = new TransEntry();
				BWLedgerSubjectHashMap.put(rs.getString("SubjectNo"), transEntry);
			 	transEntry.setSortID(rs.getString("SortID"));
			 	transEntry.setTeamFlag(rs.getString("TeamFlag"));
			 	transEntry.setDirection(rs.getString("Direction"));
			 	transEntry.setDigest(rs.getString("Digest"));
			 	transEntry.setSubjectNo(rs.getString("SubjectNo"));
			 	transEntry.setAmount("0");
			 	transEntry.setValidExpression(rs.getString("ValidExpression"));
			}
			rs.close();
			psBWLedgerSubjectInfo.close();

			haveLoaded=true;
		}else {
			Logger.log("�����Ѽ��أ��������¼��أ�");//����Ѿ����أ����Ҳ������¼��أ��򲻼���
		}
	}

	public static HashMap<String,TransactionCode> getLedgerInfoHashMap() {
		return LedgerInfoHashMap;
	}

	public static HashMap<String, TransEntry> getLedgerSubjectHashMap() {
		return LedgerSubjectHashMap;
	}
	
	public static HashMap<String, SubjectInfo> getSubjectInfoHashMap() {
		return SubjectInfoHashMap;
	}

	public static HashMap<String, TransEntry> getFareLedgerSubjectHashMap() {
		return FareLedgerSubjectHashMap;
	}
	
	public static HashMap<String, TransEntry> getBWLedgerSubjectHashMap() {
		return BWLedgerSubjectHashMap;
	}
	
}
