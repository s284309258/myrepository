package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateBP extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ics BP�����ݣ�.............");
				CreateCI();
				logger.info("................����ics BP��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = " insert into business_putout "
				+ "  (SERIALNO,CONTRACTSERIALNO,CUSTOMERID,CUSTOMERNAME,BUSINESSTYPE, "
				+ "  BUSINESSSUBTYPE,CURRENCY,OPERATEORGID,MAINRETURNTYPE,RETURNTYPE, "
				+ "  RETURNPERIOD,DEDUCTACCNO,DEDUCTACCNO1,DEDUCTACCNO2,GRACETERMFLAG, "
				+ "   GRACETERM,PUTOUTDATE,MATURITYDATE,BEGINDATE,LOANTERM,GAINAMOUNT, "
				+ "  GAINCYC,BASERATE,RATECODE,RATEMODE,RATEFLOATTYPE,RATEFLOAT,BUSINESSRATE, "
				+ "  BASERATETYPE,BUSINESSSUM,UPDATEDATE,INPUTUSERID,RATEFLOATFLAG,HOLDBALANCE, "
				+ "  RATEADJUSTTYPE,DISDATE,LOANACCNO,DSINTEPROPORTION,DUNDEPOSITNO,BANKFLAG, "
				+ "  BUSINESSKIND,CUSTOMERTYPE,PUTOUTSTATUS) "
				+ "  select PUTOUTNO,PUTOUTNO,CUSTOMERID,CUSTOMERNAME,BUSINESSTYPE,BUSINESSSUBTYPE, "
				+ "  CURRENCY,orgid,MAINRETURNTYPE,RETURNTYPE, RETURNPERIOD, DEDUCTACCNO, "
				+ "   '','',GRACEPERIODCODE, GRACEPERIOD,PUTOUTDATE, MATURITYDATE,BEGINDATE, "
				+ "   LOANTERM,GAINAMOUNT,GAINCYC,BASERATE, RATECODE, RATEMODE, RATEFLOATTYPE, "
				+ "  RATEFLOAT,PUTOUTRATE, EXECUTERATE,BUSINESSSUM,UPDATEDATE,USERID, "
				+ "   RATEFLOATFLAG,HOLDBALANCE,RATEADJUSTTYPE,'','', "
				+ "   DSINTEPROPORTION,'','PAB','RCPM','03','1' "
				+ "   from loan_balance lb where lb.putoutno like 'QYICS%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
