package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateFIXLB extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����FIX1���ݣ�.............");
				UpdateData1();
				logger.info("................����FIX1������ɣ�..............");

				logger.info("................��ʼ����FIX2���ݣ�.............");
				UpdateData2();
				logger.info("................����FIX2������ɣ�..............");

				logger.info("................��ʼ����FIX3���ݣ�.............");
				UpdateData3();
				logger.info("................����FIX3������ɣ�..............");

				logger.info("................��ʼ������Ŀ�������ݣ�.............");
				UpdateData4();
				UpdateData5();
				logger.info("................������Ŀ����������ɣ�..............");

				logger.info("................��ʼ����С΢��ͬռ�ö�Ƚ�����ݣ�.............");
				UpdateData6();
				logger.info("................����С΢��ͬռ�ö�Ƚ����ɣ�..............");
				
				logger.info("................��ʼ��������ͨ���������ݣ�.............");
				UpdateData8();
				logger.info("................��������ͨ������������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void UpdateData1() throws Exception {
		String al = " Update Loan_Balance lb Set Monthpay=0 Where putoutno Like 'QY%' And Mainreturntype='4' and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}

	public void UpdateData2() throws Exception {
		String al = "Update Loan_Balance Lb  "
				+ " Set Lb.Monthpay =   "
				+ "    (Select Nvl(Nvl(Payoverduecorp, 0) + Nvl(Payinte, 0) +   "
				+ "                Nvl(Payinnerinte, 0) + Nvl(Payoutinte, 0), 0)   "
				+ "      From Loanback_Status Ls   "
				+ "       Where Ls.Putoutno = Lb.Putoutno   "
				+ " 		        And Ls.Sterm = (select nvl(max(sterm)-1,1) from loanback_status ls1 where ls1.putoutno=lb.putoutno)"
				+ " 		and ls.aheadnum=0 )   "
				+ " 		  Where Lb.Putoutno Like 'QY%'   "
				+ " 		   And Lb.Mainreturntype = '1'   And lb.monthpay=0   "
				+ " 		     and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	public void UpdateData3() throws Exception {
		String al = "Update Loan_Balance Lb   Set Lb.Monthpay = "
				+ "     (Select Nvl(Payoverduecorp, 0) "
				+ "        From Loanback_Status Ls "
				+ "       Where Ls.Putoutno = Lb.Putoutno "
				+ "         And Ls.Sterm =(select nvl(max(sterm)-1,1) from loanback_status ls1 where ls1.putoutno=lb.putoutno) "
				+ " and ls.aheadnum=0) "
				+ " Where Lb.Putoutno Like 'QY%' "
				+ "   And Lb.Mainreturntype = '2' "
				+ "   And lb.monthpay=0 and lb.loanstatus in ('0','1','4','5') ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ������Ŀ����������
	public void UpdateData4() throws Exception {
		String al = "  select cl.lineid,(select oi.orgid from org_info oi where oi.mainframeorgid=PROJ_REGR_BCH) as org_id  "
				+ "  from qy_cl_info cl,qy_LS_PROJECT ql where cl.lineid='QY'|| LS_PROJECT_SEQ ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();
		String up = " update cl_info cl set cl.belong_org=? where cl.lineid=? ";
		PreparedStatement ups = connection.prepareStatement(up);
		int i = 0, j = 0;
		while (rs.next()) {
			i++;
			j++;
			ups.setString(1, rs.getString("org_id"));
			ups.setString(2, rs.getString("lineid"));
			ups.addBatch();
			if (i >= 1000) {
				ups.executeBatch();
				connection.commit();
				i = 0;
				logger.info("................����" + j + "��������ɣ�..............");
			}
		}
		rs.close();

		connection.commit();
	}

	// ������Ŀ����
	public void UpdateData5() throws Exception {
		String al = " update cl_info cl set cl.PROJECTNAME=cl.customername  where cl.lineid like 'QY%' and cl.parentlineid is null and cl.customerid like 'QYCL%' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}
	

	// ����С΢��ͬռ�ö�Ƚ��
	public void UpdateData6() throws Exception {
		String al = " update (  "
				+ "	select lb.businesssum,lb.normalbalance+lb.overduebalance as allbalance,bc.usesum,bc.usebalance   "
				+ "		from qy_loan_balance lb,business_contract bc where lb.putoutno=bc.serialno  "
				+ "		and lb.businesstype like '2%' and lb.contractserialno<>'SDBCONTNO' )  "
				+ "		dd set dd.usesum=dd.businesssum,dd.usebalance=dd.allbalance ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	// ������ż��Ϣ--��Ҫ�޸�
	public void UpdateData7() throws Exception {
		String al = "select lb.customerid as CUSTOMERID ,ql.customerid as RELATIVEID,'0401' as Relationship,ql.customername, "
				+ "	  case when length(ql.certid)=15 or length(ql.certid)=18 then 'Ind01' else 'Ind11' end as Certtype, "
				+ "	  ql.certid,'RMB' as Currencytype,'Ǩ������' as Describes, "
				+ "	 'CHN' as Country,'QYDC2012'||SEQ_CLEAN.NEXTVAL as Serialno "
				+ "	 from qy_ls_appt_spouse ls,qy_customer_info ql,qy_loan_balance lb where ls.appt_spouse_id_no=ql.certid "
				+ "	 and ls.appt_spouse_chi_name=ql.customername "
				+ "	 and lb.ls_appl_seq=ls.ls_appt_spouse_seq "
				+ "	 and lb.customerid is not null  ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		
		String ins="insert into CUSTOMER_RELATIVE(CUSTOMERID,RELATIVEID,Relationship,CUSTOMERNAME,Certtype,Certid,Currencytype,Describe,Country,Serialno)  "
				+ "	 values (?,?,?,?,?,?,?,?,?,?) ";
		PreparedStatement insps = connection.prepareStatement(ins);
		int i=0,j=0;
		while(rs.next()){
			i++;
			j++;
			insps.setString(1, rs.getString("CUSTOMERID"));
			insps.setString(2, rs.getString("RELATIVEID"));
			insps.setString(3, rs.getString("Relationship"));
			insps.setString(4, rs.getString("customername"));
			insps.setString(5, rs.getString("Certtype"));
			insps.setString(6, rs.getString("certid"));
			insps.setString(7, rs.getString("Currencytype"));
			insps.setString(8, rs.getString("Describes"));
			insps.setString(9, rs.getString("Country"));
			insps.setString(10, rs.getString("Serialno"));
			insps.addBatch();
			if(i>=1000){
				i=0;
				insps.executeBatch();
				connection.commit();
				logger.info("..............����"+j+"����ż����..............");
			}
		}
		rs.close();
		
		insps.executeBatch();
		connection.commit();
	}
	
	// ���´�������ͨ������
		public void UpdateData8() throws SQLException {
			String al="update business_contract bc set bc.approvedate=bc.putoutdate where bc.serialno like 'QY%' and bc.approvedate is null";
			PreparedStatement ps = connection.prepareStatement(al);
			ps.execute();
			connection.commit();
		}
		
		//���½�ݵ�����ʽ
		public void UpdateBPVt() throws SQLException{
			String al="select bc.serialno,bc.vouchtype,lr.openvipdate from " +
					"qy_loanbalance_relative lr,business_contract bc where lr.putoutno=bc.serialno ";
			PreparedStatement ps = connection.prepareStatement(al);
			ResultSet rs=ps.executeQuery();
			String up="update business_contract bc set bc.vouchtype=?  where bc.serialno=?";
			String up1="update business_putout bc set bc.vouchtype=? where bc.serialno=? ";
			
			PreparedStatement ups1=connection.prepareStatement(up);
			PreparedStatement ups2=connection.prepareStatement(up1);
			int i=0,j=0;
			while(rs.next()){
				i++;
				j++;
				ups1.setString(1, rs.getString("openvipdate"));
				ups1.setString(2, rs.getString("serialno"));
				ups1.addBatch();
				
				ups2.setString(1, rs.getString("openvipdate"));
				ups2.setString(2, rs.getString("serialno"));
				ups2.addBatch();
				if(i>=1000){
					ups1.executeBatch();
					connection.commit();
					ups2.executeBatch();
					connection.commit();
					i=0;
					logger.info("..............����"+j+"������..............");
				}
				
			}
			rs.close();
			ups1.executeBatch();
			connection.commit();
			ups2.executeBatch();
			connection.commit();	
			logger.info("..............����"+j+"������..............");
			
		}
		
		public void UpdateLRD() throws SQLException{
			String al="update loanbalance_relative lr set lr.openvipdate='2012/12/05' where lr.putoutno like 'QY%' ";
			PreparedStatement ps = connection.prepareStatement(al);
			ps.execute();
			connection.commit();
		}
		

}
