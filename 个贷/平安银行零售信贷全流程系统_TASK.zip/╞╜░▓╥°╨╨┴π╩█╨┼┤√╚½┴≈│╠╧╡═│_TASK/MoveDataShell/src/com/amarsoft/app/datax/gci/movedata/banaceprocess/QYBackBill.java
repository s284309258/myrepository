package com.amarsoft.app.datax.gci.movedata.banaceprocess;

public class QYBackBill {

}
