package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class InitQYCustomerData extends CommonExecuteUnit {


	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				initData();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����SDB�������˿ͻ����ݣ�.............");
				UpdateBecifSDB();
				logger.info("................����SDB�����ͻ�����������ɣ�..............");
				
				logger.info("................��ʼ����SDB������ҵ�ͻ����ݣ�.............");
				UpdateSDBEData();
				logger.info("................����SDB�����ͻ���ҵ������ɣ�..............");
				
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	/**
	 * ����SDB�������˿ͻ�����
	 * @throws SQLException
	 */
	public void UpdateBecifSDB() throws SQLException{
		String selectD="select qi.customerid,qb.becif_no from tempintf.retail_perloan_mapping qb,qy_customer_info qi " +
				" where qb.source_id=qi.SOURCE_ID and qi.nbecifno is null ";
		PreparedStatement ps = connection.prepareStatement(selectD);
		
		String updateD=" update qy_customer_info qi set qi.nbecifno=? where qi.customerid=? ";
		PreparedStatement pp = connection.prepareStatement(updateD);
		int i=0;
		int j=0;
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			i++;
			j++;
			pp.setString(1, rs.getString("becif_no"));
			pp.setString(2, rs.getString("customerid"));
			pp.addBatch();
			if(i>999){
				pp.executeBatch();
				connection.commit();
				logger.info("......���£�"+j+"������..........");
				i=0;
			}
		}
		pp.executeBatch();
		connection.commit();
		rs.close();
		logger.info("......���£�"+j+"������..........");
		
	}
	
	public void UpdateSDBEData() throws SQLException{
		String mfid="";
		String newBECIFNO="";
		String sCustomerID="";
		String al="select qi.CUSTOMERID,qi.customername,qi.certid,qi.sdb_id_type,qi.sdb_iss_ctry,qi.mfcustomerid from qy_customer_info qi where qi.nbecifno is null ";
		PreparedStatement ps=connection.prepareStatement(al);
		ResultSet rs=ps.executeQuery();
		
		ResultSet rd=null;
		String selectCI="select ql.BECIF_NO from tempintf.ORGANIZATION_INFO_INIT ql where ql.CI_NO=? ";
		PreparedStatement pd=connection.prepareStatement(selectCI);
		
		String updateSql="update qy_customer_info qi set qi.nbecifno=? where qi.CUSTOMERID= ? ";
		PreparedStatement pf=connection.prepareStatement(updateSql);
		
		while(rs.next()){
			mfid="";
			newBECIFNO="";
			sCustomerID="";
			mfid=rs.getString("mfcustomerid");
			sCustomerID=rs.getString("CUSTOMERID");
			pd.setString(1, mfid);
			rd=pd.executeQuery();
			while(rd.next()){
				newBECIFNO=rd.getString("BECIF_NO");
			}
			rd.close();
			
			pf.setString(1, newBECIFNO);
			pf.setString(2, sCustomerID);
			pf.execute();			
		}
		rs.close();
		
		connection.commit();
	}
	

}
