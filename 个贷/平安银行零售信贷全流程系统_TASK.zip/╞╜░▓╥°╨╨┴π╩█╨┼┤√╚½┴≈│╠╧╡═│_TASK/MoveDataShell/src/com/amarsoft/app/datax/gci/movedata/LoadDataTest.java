package com.amarsoft.app.datax.gci.movedata;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class LoadDataTest extends CommonExecuteUnit {
	
	
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ��ʼ��������.............");
				//Cdata();
				logger.info("................��ʼ������������..............");
				
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateFile();
				//CreateCI();
				logger.info("................����ҵ��������ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateFile() throws Exception{

		
		String fileName="D:\\0����Ǩ���ĵ�\\001_bloan-rcpm.txt";
		File file = new File(fileName);		
		DataOutputStream os = new DataOutputStream(new FileOutputStream(file));
		
		String selectData="select qi.carlno ,qb.putoutno,qi.camt from qy_BLOAN_PLAMT_ICS qi,qy_loan_balance qb where qi.accno=qb.deductaccno ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(selectData);
		ResultSet rs=selectSql.executeQuery();
		String tmp="";
		while(rs.next()){
			tmp="";
			tmp+=rs.getString("carlno")+"|";
			tmp+=rs.getString("putoutno")+"|";
			tmp+=rs.getString("camt")+"\n";
			logger.info("..................."+tmp);
			os.writeBytes(tmp);
		}
		rs.close();
		
	}
	
	public  void Cdata() throws Exception{
		String fileName="D:\\0����Ǩ���ĵ�\\01_ICS_PLAMT.TXT";
		String sLine="";
		String insertSql=" insert into QY_BLOAN_PLAMT_ICS(CARLNO,ACCNO,CAMT)values(?,?,?) ";
		PreparedStatement selectSql;
		selectSql=connection.prepareStatement(insertSql);
		
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName),"GBK"));
		String [] lin;
		while((sLine = reader1.readLine())!= null){
			lin=sLine.split("\\|");
			selectSql.setString(1, lin[0]);
			selectSql.setString(2, lin[1]);
			selectSql.setString(3, lin[2].replaceAll(" ", ""));
			logger.info("....."+lin[0]+"...."+lin[1]+"....."+lin[2].replaceAll(" ", ""));
			selectSql.addBatch();
		}
		reader1.close();
		selectSql.executeBatch();
		connection.commit();
	}

	
}
