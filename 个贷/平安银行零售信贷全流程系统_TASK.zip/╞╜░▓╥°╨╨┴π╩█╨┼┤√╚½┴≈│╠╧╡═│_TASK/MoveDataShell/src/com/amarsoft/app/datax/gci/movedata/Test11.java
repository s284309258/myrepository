package com.amarsoft.app.datax.gci.movedata;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.are.ARE;
import com.amarsoft.are.sql.Transaction;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class Test11 extends CommonExecuteUnit {

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
            OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				
				logger.info("................��ʼ���ļ���.............");
				CreateFile();
				logger.info("................�����ļ���ɣ�..............");
				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void CreateFile() throws Exception{
		String aa="";
//		QYBarCode ql=new QYBarCode();
//		Transaction Sqlcal=new Transaction(connection);
//		aa=ql.getApplyBarCode(Sqlcal, "QY10000230103741003553CHN00001", "99", "1122");
		logger.info("............."+aa);
	}
	

}
