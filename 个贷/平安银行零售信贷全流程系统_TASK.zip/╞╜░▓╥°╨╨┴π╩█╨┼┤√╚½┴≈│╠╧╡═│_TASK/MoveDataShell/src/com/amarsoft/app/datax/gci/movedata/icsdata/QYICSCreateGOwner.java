package com.amarsoft.app.datax.gci.movedata.icsdata;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYICSCreateGOwner extends CommonExecuteUnit {
	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
		//	OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����icsѺƷ���������ݣ�.............");
				CreateCI();
				logger.info("................����icsѺƷ������������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateCI() throws SQLException {
		String al = " insert into guaranty_owner(serialno,guarantyid,customerid,ownername,certtype,certid,lot,inputuser,inputorg,inputdate) "
				+ " select 'QYICS'||SEQ_CLEAN.NEXTVAL,gr.guarantyid,lb.customerid,lb.customername,ci.certtype,ci.certid,'',lb.userid,lb.orgid,lb.putoutdate "
				+ "  from loan_balance lb,guaranty_relative gr,customer_info ci where lb.putoutno=gr.objectno and "
				+ "   lb.customerid=ci.customerid and lb.putoutno like 'QYICS%'";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}
}
