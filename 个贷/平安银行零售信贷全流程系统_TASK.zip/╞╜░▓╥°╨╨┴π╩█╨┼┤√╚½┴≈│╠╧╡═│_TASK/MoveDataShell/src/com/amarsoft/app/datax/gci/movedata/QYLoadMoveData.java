package com.amarsoft.app.datax.gci.movedata;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;

public class QYLoadMoveData extends CommonExecuteUnit {

	@Override
	public int execute() {
		// TODO Auto-generated method stub
		return 0;
	}

}
