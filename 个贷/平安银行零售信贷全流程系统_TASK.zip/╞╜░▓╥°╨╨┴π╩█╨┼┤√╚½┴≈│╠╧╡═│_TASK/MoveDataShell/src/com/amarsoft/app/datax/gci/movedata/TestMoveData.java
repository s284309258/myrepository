package com.amarsoft.app.datax.gci.movedata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.amarsoft.are.sql.ConnectionManager;
import com.amarsoft.are.sql.Transaction;

public class TestMoveData {
	public static Transaction getSqlca() throws Exception {
		String sUrl = "jdbc:oracle:thin:@10.25.17.143:1621:bbbloan";
		String sDriverName = "oracle.jdbc.driver.OracleDriver";
		String sUserName = "rcpmdata";
		String sUserPass = "paic1234";
		return ConnectionManager.getTransaction(sUrl, sDriverName, sUserName, sUserPass);
	}
	
	public static Connection getConn() throws Exception {
		String sUrl = "jdbc:oracle:thin:@10.25.17.102:1521:pams";
		String sDriverName = "oracle.jdbc.driver.OracleDriver";
		String sUserName = "pams";
		String sUserPass = "amars0ft";
		return ConnectionManager.getConnection(sUrl, sDriverName, sUserName, sUserPass);
	}
	
	public static void main(String []args){
    	try {
    		Connection  conn = TestMoveData.getSqlca().conn;
    		String sqls="insert into inpute_data (putoutno,cretid,crettype)values(?,?,?)";
    		PreparedStatement selSql;
			selSql=conn.prepareStatement(sqls);
		//	selSql.execute();
			String rl="RL";
			System.out.println("==="+sqls);
			for(int i=2;i<22;i++){
					System.out.println("==="+i);
					selSql.setString(1, rl+i);
					selSql.setString(2, rl+i);
					selSql.setString(3, rl+i);
					selSql.addBatch();								
			}
			selSql.executeBatch();
			conn.commit();
			selSql.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  
	}
}
