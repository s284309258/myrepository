package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYFIXCDD extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {

				logger.info("................��ʼ����OPERATEORGID���ݣ�.............");
				UpdateData1();
				logger.info("................����OPERATEORGID������ɣ�..............");

				logger.info("................��ʼ���´�ִ�״̬���ݣ�.............");
				UpdateData2();
				logger.info("................���´�ִ�״̬������ɣ�..............");
				
				
				logger.info("................��ʼ���´�ִ���־���ݣ�.............");
				UpdateData3();
				logger.info("................���´�ִ���־������ɣ�..............");

				
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void UpdateData1() throws Exception {
		String al = "update finacing_account fa set fa.operateorgid=fa.orgid where fa.finacingtype<>'PAB' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}

	public void UpdateData2() throws Exception {
		String al = "update finacing_account fa set fa.status='0' where fa.finacingtype<>'PAB' and fa.canceldate is not null ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();
	}

	public void UpdateData3() throws Exception {
		String al = "Update FINACING_ACCOUNT Set FLAG='OLD' ";
		PreparedStatement ps = connection.prepareStatement(al);
		ps.execute();
		connection.commit();

	}


	

}
