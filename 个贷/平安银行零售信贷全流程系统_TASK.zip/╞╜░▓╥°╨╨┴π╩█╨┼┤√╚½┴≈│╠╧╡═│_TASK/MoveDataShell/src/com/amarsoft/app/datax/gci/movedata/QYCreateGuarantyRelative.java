package com.amarsoft.app.datax.gci.movedata;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYCreateGuarantyRelative extends CommonExecuteUnit {
	private int commitNum = 1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/** ------������---------------------- */
			OCIConfig.loadOCIConfig(true);
			/** -----------------------������---------------------- */
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
				logger.info("................��ʼ����ҵ�����ݣ�.............");
				CreateQYGR();
				CreateQYGR1();
				logger.info("................����ҵ��������ɣ�..............");

				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}

	public void CreateQYGR() throws Exception {
		int i = 0, j = 0;
		String al = " select distinct case when bc.BUSINESSKIND = 'RCPM' then  'CBContractApply' else 'SWContractApply' end as OBJECTTYPE, "
				+ "  nvl(cr.bc_serialno,cr.lb_putout_no) as OBJECTNO,nvl(cr.bc_serialno,cr.lb_putout_no) as CONTRACTNO, "
				+ "                     gi_guarantyid as GUARANTYID, 'NEW' as CHANNEL , '1' as STATUS "
				+ "        from qy_guar_loan_cr cr, qy_loan_balance bc "
				+ "       where  cr.bc_serialno=bc.contractserialno or cr.lb_putout_no=bc.putoutno ";
		String insertSql = " insert into qy_guaranty_relative (OBJECTTYPE, OBJECTNO, CONTRACTNO, GUARANTYID, CHANNEL, STATUS) values (?,?,?,?,?,?) ";
		PreparedStatement ps = connection.prepareStatement(al);
		PreparedStatement pg = connection.prepareStatement(insertSql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			i++;
			j++;
			pg.setString(1, rs.getString("OBJECTTYPE"));
			pg.setString(2, rs.getString("OBJECTNO"));
			pg.setString(3, rs.getString("CONTRACTNO"));
			pg.setString(4, rs.getString("GUARANTYID"));
			pg.setString(5, rs.getString("CHANNEL"));
			pg.setString(6, rs.getString("STATUS"));
			pg.addBatch();
			if (i > 999) {
				i = 0;
				pg.executeBatch();
				logger.info(".............����" + j + "������.............");
				connection.commit();
			}
		}
		pg.executeBatch();
		connection.commit();
		rs.close();
	}

	public void CreateQYGR1() throws Exception {
		int i = 0, j = 0;
		String al = " select distinct case when  lb.BUSINESSKIND = 'RCPM' then  'CBContractApply' else 'SWContractApply' end as OBJECTTYPE,lb.serialno,dd.gi_guarantyid "
				+ " from qy_business_contract lb, "
				+ " (select gc.bc_serialno,gc.gi_guarantyid from qy_guar_loan_cr gc where not exists ( "
				+ " select * from qy_guaranty_relative gr where gr.guarantyid=gc.gi_guarantyid )    "
				+ " and gc.bc_serialno is not null and gc.lb_putout_no is null ) dd where dd.bc_serialno=lb.serialno   ";
		String insertSql = " insert into qy_guaranty_relative (OBJECTTYPE, OBJECTNO, CONTRACTNO, GUARANTYID, CHANNEL, STATUS) values (?,?,?,?,?,?) ";
		PreparedStatement ps = connection.prepareStatement(al);
		PreparedStatement pg = connection.prepareStatement(insertSql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			i++;
			j++;
			pg.setString(1, rs.getString("OBJECTTYPE"));
			pg.setString(2, rs.getString("serialno"));
			pg.setString(3, rs.getString("serialno"));
			pg.setString(4, rs.getString("gi_guarantyid"));
			pg.setString(5, "NEW");
			pg.setString(6, "1");
			pg.addBatch();
			if (i > 999) {
				i = 0;
				pg.executeBatch();
				logger.info(".............����" + j + "������.............");
				connection.commit();
			}
		}
		pg.executeBatch();
		connection.commit();
		rs.close();
	}

}
