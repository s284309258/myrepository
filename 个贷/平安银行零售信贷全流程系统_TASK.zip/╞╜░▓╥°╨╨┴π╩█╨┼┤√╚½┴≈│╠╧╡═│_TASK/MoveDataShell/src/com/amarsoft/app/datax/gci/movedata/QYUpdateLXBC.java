package com.amarsoft.app.datax.gci.movedata;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.app.datax.gci.CommonExecuteUnit;
import com.amarsoft.impl.szpab.esb.OCIConfig;
import com.amarsoft.task.TaskConstants;

public class QYUpdateLXBC extends CommonExecuteUnit {
	private int commitNum=1;

	@Override
	public int execute() {
		try {
			String sInit = super.init();
			/**------������----------------------*/
          //  OCIConfig.loadOCIConfig(true);
            /**-----------------------������----------------------*/
			if (sInit.equalsIgnoreCase("skip")) {
				return TaskConstants.ES_SUCCESSFUL;
			} else {
			
				logger.info("................��ʼ��������Э������ݣ�.............");
				UpdateLXData();
				logger.info("................��������Э���������ɣ�..............");
				
				logger.info("................��ʼ�����ͬ�鲢���ݣ�.............");
				UpdateLXData1();
				logger.info("................�����ͬ�鲢������ɣ�..............");
				
				
			
				unitStatus = TaskConstants.ES_SUCCESSFUL;
				clearResource();
				return unitStatus;
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
			unitStatus = TaskConstants.ES_FAILED;
			clearResource();
			return unitStatus;
		}
	}
	
	public void initData(){
		commitNum =getProperty("commitNum",1);
	}
	
	public void UpdateLXData() throws Exception{
		int i=0;
		String al="select nvl(lb.INITQYBCNO,lb.contractserialno) as bcserialno,ql.AGREE_NO,lb.putoutno,ql.amt2,ql.amt1  from qy_loan_balance lb,QY_LB_BC_RL ql where lb.loan_no=ql.bill_no ";
		PreparedStatement ps = connection.prepareStatement(al);
		ResultSet rs = ps.executeQuery();
		
		String ups="update business_contract bc set bc.artificialno=?,bc.businesssum=?,bc.businesstype='1130050' where bc.serialno=? ";
		String up2="update business_putout bc set bc.limitsum=?,bc.businesstype='1130050' where bc.serialno=?";  //cur_c1.amt2
		String up3="update loan_balance bc set bc.businesstype='1130050',BATCHPAYMENTFLAG='0' where bc.putoutno=? ";
		PreparedStatement pp = connection.prepareStatement(ups);
		PreparedStatement pp2 = connection.prepareStatement(up2);
		PreparedStatement pp3 = connection.prepareStatement(up3);
		
		while(rs.next()){
			i++;
			pp.setString(1, rs.getString("AGREE_NO"));
			pp.setDouble(2, rs.getDouble("amt1"));
			pp.setString(3, rs.getString("bcserialno"));
			pp.addBatch();
			
			pp2.setString(1, rs.getString("amt2"));
			pp2.setString(2, rs.getString("putoutno"));
			pp2.addBatch();
			
			pp3.setString(1, rs.getString("putoutno"));
			pp3.addBatch();
			
			if(i>10){
				pp.executeBatch();
				pp2.executeBatch();
				pp3.executeBatch();
				connection.commit();
				i=0;
			}
		}
		
		pp.executeBatch();
		connection.commit();
		i=0;
		rs.close();
	}
	
	public void UpdateLXData1() throws SQLException{
		String al="select lg.agree_no from qy_lb_bc_rl lg,qy_loan_balance lb where lb.loan_no=lg.bill_no group by lg.agree_no having count(lg.agree_no)>1 ";
		
		String sl2="select bc.serialno from business_contract bc,guaranty_relative gr where bc.serialno=gr.objectno and bc.serialno like 'QY%' and bc.artificialno=? ";
		
		String ups="update loan_balance lb set lb.contractserialno=? where lb.putoutno  "
				+" in (select ld.putoutno from qy_lb_bc_rl lg,qy_loan_balance ld where ld.loan_no=lg.bill_no and lg.agree_no=?) ";
		
		PreparedStatement ps=connection.prepareStatement(al);
		PreparedStatement ps2=connection.prepareStatement(sl2);
		PreparedStatement ps3=connection.prepareStatement(ups);
		String bcno="";
		ResultSet rs=ps.executeQuery();
		ResultSet rs2=null;
		while(rs.next()){
			bcno="";
			ps2.setString(1, rs.getString("agree_no"));
			rs2=ps2.executeQuery();
			while(rs2.next()){
				bcno=rs2.getString("serialno");
			}
			rs2.close();
			ps3.setString(1, bcno);
			ps3.setString(2, rs.getString("agree_no"));
			ps3.execute();
			connection.commit();
		}
		rs.close();
		
	}
	
}
