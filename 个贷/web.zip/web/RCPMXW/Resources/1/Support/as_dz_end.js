function getTrueLength(mystr)
{
	var cArr = mystr.match(/[^x00-xff]/ig);
	return mystr.length+(cArr==null?0:cArr.length);
}

function  getLeft(mystr,leftLen)
{
	var mylen=mystr.length;
	var realNum=0;
	for(var i=1;i<=mylen;i++)
	{
		if(mystr.charCodeAt(i-1)<0||mystr.charCodeAt(i-1)>255)
			realNum++;
		if(i+realNum==leftLen) break;
		if(i+realNum>leftLen) {i--; break; }
	}
	return mystr.substring(0,i);
}	

function textareaMaxByIndex(iDW,iRow,iCol)  
{ 
	var obj=getASObjectByIndex(iDW,iRow,iCol); 
	var maxlimit=DZ[iDW][1][iCol][7]; 
	if(maxlimit==0) return; 
	//if (obj.value.length > maxlimit)  
	//	obj.value = obj.value.substring(0, maxlimit); 	
	if(getTrueLength(obj.value) > maxlimit)  
	{
		obj.value = getLeft(obj.value, maxlimit); 
	}
} 


/*ȥ��F2�ͷſ��˺���
function AsSaveResult(myobjname) 
{ 
}
*/	
function setItemDisabled(iDW,iRow,sCol,bDisabled)   { 
	var iCol = getColIndex(iDW,sCol);  
	try { 
		if(bDisabled) {
			if(DZ[iDW][1][iCol][12]=='3') document.frames("myiframe"+iDW).document.all("R"+iRow+"F"+iCol).nextSibling.nextSibling.style.display='none';
			document.frames("myiframe"+iDW).document.forms(0).document.all("R"+iRow+"F"+iCol).style.backgroundColor="#EFEFEF";  
			}
		else if(!bDisabled) { 
			if(DZ[iDW][1][iCol][12]=='3') document.frames("myiframe"+iDW).document.all("R"+iRow+"F"+iCol).nextSibling.nextSibling.style.display='';
			document.frames("myiframe"+iDW).document.forms(0).document.all("R"+iRow+"F"+iCol).style.backgroundColor="#FFFFFF";  
		}
		document.frames("myiframe"+iDW).document.forms(0).elements("R"+iRow+"F"+iCol).disabled = bDisabled; 
	}catch(e) {}
	//
}

//add in 2009/08/22
function setItemReadOnly(iDW,iRow,sCol,bReadOnly)  
{ 
	iCol = getColIndex(iDW,sCol); 
 
	document.frames("myiframe"+iDW).document.forms(0).elements("R"+iRow+"F"+iCol).readOnly = bReadOnly;
	try { 
		if(bReadOnly && DZ[iDW][1][iCol][12]=='3')
			document.frames("myiframe"+iDW).document.all("R"+iRow+"F"+iCol).nextSibling.nextSibling.style.display='none';
		if(!bReadOnly && DZ[iDW][1][iCol][12]=='3')	
			document.frames("myiframe"+iDW).document.all("R"+iRow+"F"+iCol).nextSibling.nextSibling.style.display='block';
	}catch(e) {}
} 

function myTabNext(myname,iRec,cutItemName)
{
	var myi=myname.substring(myname.length-1);
	var i,j="O",sName2="";
	for(i=0;i<document.frames(myname).document.all.length;i++)
	{
		if(document.frames(myname).document.all(i).name==cutItemName)
		{
			j="1";
			continue;
		}
		//if(j=="1" && document.frames(myname).document.all(i).name!=null && document.frames(myname).document.all(i).name.indexOf("R")!=-1)
		if(j=="1" && document.frames(myname).document.all(i).name!=null && document.frames(myname).document.all(i).name.indexOf("R")==0 )
		{
			sName2=document.frames(myname).document.all(i).name;
			if(document.frames(myname).document.all(i).disabled)
			{
				j="1";
				continue;
			}				  	 
			else
			{
				var iBegin2,iEnd2,iField2,iRec2;
				iBegin2=sName2.indexOf("R");
				iEnd2=sName2.indexOf("F");
				iRec2=parseInt(sName2.substring(iBegin2+1,iEnd2));
				iField2=parseInt(sName2.substring(iEnd2+1));
	
				if(DZ[myi][1][iField2][2]==1 && DZ[myi][1][iField2][3]==0) //��ʾ����ֻ��			
					break;
				else
				{
					j="1";
					continue;
				}
			}
		}
	}
	if(sName2!="") {
		var iBegin2,iEnd2,iField2,iRec2;
		iBegin2=sName2.indexOf("R");
		iEnd2=sName2.indexOf("F");
		iRec2=parseInt(sName2.substring(iBegin2+1,iEnd2));
		iField2=parseInt(sName2.substring(iEnd2+1));
		try {
		if(DZ[myi][1][iField2][3]==0)
			document.frames(myname).document.forms(0).elements(sName2).focus();
		} catch(e) { var a_a=1; }
		if(iRec!=iRec2)
	  		sR(cur_sel_rec[myi],iRec2,myname);
	}
}

function isDate(value,separator)
{
	if(value==null||value.length<10) return false;	
	var sItems = value.split(separator); // value.split("/");
	
    if (sItems.length!=3) return false;
    if (isNaN(sItems[0])) return false;
    if (isNaN(sItems[1])) return false;
    if (isNaN(sItems[2])) return false;
    //��ݱ���Ϊ4λ���·ݺ��ձ���Ϊ2λ
    if (sItems[0].length!=4) return false;
    if (sItems[1].length!=2) return false;
    if (sItems[2].length!=2) return false;

    if (parseInt(sItems[0],10)<1900 || parseInt(sItems[0],10)>2150) return false;
    if (parseInt(sItems[1],10)<1 || parseInt(sItems[1],10)>12) return false;
    if (parseInt(sItems[2],10)<1 || parseInt(sItems[2],10)>31) return false;

    if ((sItems[1]<=7) && ((sItems[1] % 2)==0) && (sItems[2]>=31)) return false;
    if ((sItems[1]>=8) && ((sItems[1] % 2)==1) && (sItems[2]>=31)) return false;
    //���겻������
    if (!((sItems[0] % 4)==0) && (sItems[1]==2) && (sItems[2]==29))
    {
            if ((sItems[1]==2) && (sItems[2]==29))
                    return false;
    }else
    {
            if ((sItems[1]==2) && (sItems[2]==30))
                    return false;
    }

    return true;
}

try{
	document.frames("myiframe0").document.body.oncontextmenu='self.event.returnValue=true';
}catch(e){}


try {	document.body.onkeydown=mykd; } catch(e) {var a=1;}
try {	document.onkeydown=mykd; } catch(e) {var a=1;}


//����datawindow�ļ����¼��Ĵ���
//����true����ʾ����Ҫdatawindow�ٴ�����false,��ʾ��Ҫdatawindow�ٴ���(��mykd�����෴)
function myHandleSpecialKey(myname)
{
	try {
		return !mykd(myname);
	}	catch(e) {return false;}
}

