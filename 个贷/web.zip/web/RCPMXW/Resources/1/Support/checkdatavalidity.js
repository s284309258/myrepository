//check CorpID
function CheckORG(CorpID)
{
    var financecode = new Array();
    if(CorpID=="00000000-0")	return false;
	for (i=0;i<CorpID.length;i++)
	{
		financecode[i]= CorpID.charCodeAt(i);
	}
    var w_i = new Array(8);
    var c_i = new Array(8);
    s = 0,c = 0;
    w_i[0] = 3;
    w_i[1] = 7;
    w_i[2] = 9;
    w_i[3] = 10;
    w_i[4] = 5;
    w_i[5] = 8;
    w_i[6] = 4;
    w_i[7] = 2;
    if(financecode[8] != 45)	return false;
    for(i = 0; i < 10; i++)
    {
        c = financecode[i];
        if(c <= 122 && c >= 97)
            return false;
    }

    fir_value = financecode[0];
    sec_value = financecode[1];
    if(fir_value >= 65 && fir_value <= 90)
        c_i[0] = (fir_value + 32) - 87;
    else if(fir_value >= 48 && fir_value <= 57)
        c_i[0] = fir_value - 48;
    else
        return false;
    s += w_i[0] * c_i[0];
    if(sec_value >= 65 && sec_value <= 90)
        c_i[1] = (sec_value - 65) + 10;
    else if(sec_value >= 48 && sec_value <= 57)
        c_i[1] = sec_value - 48;
    else
        return false;
    s += w_i[1] * c_i[1];
    for(j = 2; j < 8; j++)
    {
        if(financecode[j] < 48 || financecode[j] > 57)
            return false;
        c_i[j] = financecode[j] - 48;
        s += w_i[j] * c_i[j];
    }

    c = 11 - s % 11;
    return financecode[9] == 88 && c == 10 || c == 11 && financecode[9] == 48 || c == financecode[9] - 48;
}

//����У��
function checkDate(sDate) 
{
	var checkedDate = sDate;
	var year,month,day;	
	//����Ϊ�� ���Ȳ�����8��14 ���ش���
	var maxDay = new Array(0,31,29,31,30,31,30,31,31,30,31,30,31);
	//if(checkedDate == null ) return false;
	checkedDate = checkedDate.trim();
	if (checkedDate.length != 8 && checkedDate.length != 14) 
	{
		return false;
	}		
	year = checkedDate.substring(0, 4).trim();
	month = checkedDate.substring(4, 6).trim();
	day = checkedDate.substring(6, 8).trim();
	
	// ������1��4λ ��С��1900 ���ش���
	if (year < 1900) {
		return false;
	}
	// ������5��6λ ����1��12����֮�� ���ش���
	if (month < 1 || month > 12) {
		return false;
	}
	// ������7��8λ ����1��maxDay[month]����֮�� ���ش���
	if (day > maxDay[month] || day == 0) {
		return false;
	}
	// ������2�·����ڴ���29
	if (day == 29 && month == 2 && (year % 4 != 0 || year % 100 == 0) && (year % 4 != 0 || year % 400 != 0)) 
	{
		return false;
	}
	if (checkedDate.length == 14) 
	{
		// ���ڳ���Ϊ14λ			
		var hour = checkedDate.substring(8, 10);
		var miniute = checkedDate.substring(10, 12);
		var second = checkedDate.substring(12, 14);
		
		// ������9��10λ Сʱ��0��23����֮�� ���ش���
		if (hour > 23 || hour < 0) {
			return false;
		}
		// ������11��12λ ������0��59����֮�� ���ش���
		if (miniute > 59 || miniute < 0) {
			return false;
		}
		// ������13��14λ ����0��59����֮�� ���ش���
		if (second > 59 || second < 0) {
			return false;
		}
	}
	return true;
}

function checkPersonId(personId) 
{
	var strJiaoYan = new Array("1","0","X","9","8","7","6","5","4","3","2");
	var intQuan = new Array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2,1);
	var intTemp = 0;
	for (i = 0; i < personId.length - 1; i++)
    {
			intTemp += personId.substring(i, i + 1) * intQuan[i];
    }
	intTemp %= 11;
	return personId.substring(personId.length - 1)==strJiaoYan[intTemp];
}

//����֤У��
function CheckLisince(ID)
{    	
	var checkedValue = ID;		
	checkedValue = checkedValue.trim();
	if (checkedValue.length != 15 && checkedValue.length != 18)
		return false;
	var dateValue;
	if (checkedValue.length == 15)
		dateValue = "19" + checkedValue.substring(6, 12);		
	else
		dateValue = checkedValue.substring(6, 14);
	if (!checkDate(dateValue))
		return false;
	if (checkedValue.length == 18)		    
		return checkPersonId(checkedValue);
	return true;   
}

//������ŵ���ȷ�Լ������
function CheckLoanCardID(loanCardCode) 
{
	var financecode = new Array();
	for (i=0;i<loanCardCode.length;i++)
	{
	 	financecode[i]= loanCardCode.charCodeAt(i);
	}
	var weightValue = new Array(14);
	var checkValue = new Array(14);
	totalValue = 0;
	c = 0;
	weightValue[0] = 1;
	weightValue[1] = 3;
	weightValue[2] = 5;
	weightValue[3] = 7;
	weightValue[4] = 11;
	weightValue[5] = 2;
	weightValue[6] = 13;
	weightValue[7] = 1;
	weightValue[8] = 1;
	weightValue[9] = 17;
	weightValue[10] = 19;
	weightValue[11] = 97;
	weightValue[12] = 23;
	weightValue[13] = 29;
	for ( j = 0; j < 14; j++) 
	{
		if (financecode[j] >= 65 && financecode[j] <= 90) 
		{
			checkValue[j] = (financecode[j] - 65) + 10;
		} else if (financecode[j] >= 48 && financecode[j] <= 57) 
		{
			checkValue[j] = financecode[j] - 48;
		} else 
		{
			return false;
		}
		totalValue += weightValue[j] * checkValue[j];
	}
	c = 1 + totalValue % 97;
	val = (financecode[14] - 48) * 10 + (financecode[15] - 48);
	return val == c;
}

//У����������
function CheckPostalcode(Postalcode)
{
	var str = Postalcode;
	str = str.trim();	
	if (str.length > 0)
	{
		if (str.length != 6)
		{		       
			return false;
		}

		var Letters = "1234567890";
		for (i = 0;i < str.length;i++)
		{
			var CheckChar = str.charAt(i);
			if (Letters.indexOf(CheckChar) == -1)
			{			        
				return false;
			}
		}
	}
	return true;
}

/*~[Describe=У����������ŵ��ֻ�����;InputParam=�ֻ�����;OutPutParam=��;]~*/
function CheckPhoneCodeWithZone(PhoneCode)
{
	var patrn=/^[+]{1}(\d){6,19}$/;
	if( typeof(PhoneCode) != "undefined" && PhoneCode.length !=0 ){
		if (!patrn.exec(PhoneCode)) return false;
		
	}
	return true;
}

/*~[Describe=У���й������ֻ�����;InputParam=�ֻ�����;OutPutParam=��;]~*/
function CheckPhoneCode(PhoneCode)
{
	var patrn=/^[1]{1}(\d){10}$/;
	if( typeof(PhoneCode) != "undefined" && PhoneCode.length !=0 ){
		if (!patrn.exec(PhoneCode)) return false;
		
	}
	return true;
}

//У������ʼ���ַ
function CheckEMail(EMail)
{
	var Count = 0;
	var str = EMail;
	str = str.trim();
	if (str.length > 0)
	{
		var Letters = "@";
		//����ַ������Ƿ����"@"�ַ�
		if (str.indexOf(Letters) == -1)
		{			        
			return false;
		}
		//����ַ������Ƿ���ڶ��"@"�ַ�
		for (i = 0;i < str.length;i++)
		{
			var CheckChar = str.charAt(i);
			if (Letters.indexOf(CheckChar) >= 0)
			{			        
				Count = Count + 1;
			}
		}
		if(Count > 1)
		{
			return false;
		}
	}
	return true;
}

function CheckTypeScript(sCheckWord,sCheckType)
{
	sCheckWord = sCheckWord.trim();
	if(sCheckType=="2")
	{
		var patrn=/^[0-9,.]{1,20}$/;
		if (!patrn.exec(sCheckWord)) return false
		return true
	 }
}


//У���˺����ֶ��Ƿ�Ϊ����
function CheckNo(sCheckNo)
{
	for(var i = 0; i < sCheckNo.length ; i ++)
	{
		var c = sCheckNo.charAt(i);
		if(c < '0' || c > '9')
		{
			return false;
		}
	}
	return true;
}


/*~[Describe=У�鸴�ϵ绰����;InputParam=��������,������,�绰��,�ֻ���;OutPutParam=��;]~*/
function checkGroupTell( zone,area,tel,extension ){

	var zonePattern=/^[+]{1}[0-9]{2,6}$/;
	var areaPattern=/^[0-9]{3,4}$/;
	var telPattern=/^[0-9]{7,8}$/;
	var extensionPattern=/^[0-9]{0,8}$/;
	if( typeof(zone) != "undefined" && zone.length !=0
			&& typeof(area) != "undefined" && area.length !=0
			&& typeof(tel) != "undefined" && tel.length !=0 ){
		if (!zonePattern.exec(zone)) return false;
		if (!areaPattern.exec(area)) return false;
		if (!telPattern.exec(tel)) return false;
		
	}
	
	if( typeof(extension) != "undefined" && extension.length !=0 ){
		if (!extensionPattern.exec(extension)) 
			return false;
	}	
	return true;
}

/*~[Describe=У������֤������;InputParam=֤������,֤������;OutPutParam=��;]~*/
function checkAllCertID( certType,certID){
	certType = getItemValue(0,getRow(),"CertType");
	certID = getItemValue(0,getRow(),"CertID");
	if(typeof(certType) == "undefined" || certType == "" 
		|| typeof(certID) == "undefined" || certID == ""){
		return true;	
	}
	// ʿ��֤���߾���֤
	if( certType == "Ind04" || certType == "Ind05") {
		for ( var i = 0 ; i < certID.length ; i++){
			var c = certID.charAt(i);
			if( c == "��" || c == "��" ||c == "��" || c == " " || c == "-" || c == "/" || c == ","){
				return false;
			}
		}
	}
	// �۰ľ���/̨��ͬ�������ڵ�ͨ��֤
	if( certType == "Ind06" || certType == "Ind07") {
		for ( var i = 0 ; i < certID.length ; i++){
			var c = certID.charAt(i);
			if( c >= "a" && c <= "z"){
				return false;
			}
		}
	}
	// ����֤
	if( certType == "Ind10" ) {
		for ( var i = 0 ; i < certID.length ; i++){
			var c = certID.charAt(i);
			if( c == "��" || c == "��" ||c == "��" || c == " " || c == "-" || c == "/" || c == ","){
				return false;
			}
		}
	}
	// ����֤,��ʱ����֤
	if( certType == "Ind01"){
		return CheckLisince(certID);
	}
	return true;
}

/*~[Describe=У����˿ͻ�����;InputParam=�ͻ�����;OutPutParam=��;]~*/
function checkFullName(sFullName){
	if(typeof(sFullName) == "undefined" || sFullName == "") return true;
	for ( var i = 0 ; i < sFullName.length ; i++){
		var c = sFullName.charAt(i);
		if(c == "." || c == "," || c == " " || c == "-" || c == "��" || c == "-" || c == " "){
			return false;
		}
	}
	return true;
}

