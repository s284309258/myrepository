var sScreenWidth = screen.availWidth;
var sScreenHeight = screen.availHeight;
var sDefaultDialogStyle= "dialogWidth="+sScreenWidth+"px;dialogHeight="+sScreenHeight+"px;resizable=yes;maximize:yes;help:no;status:no;";
var OpenStyle="width="+sScreenWidth+"px,height="+sScreenHeight+"px,top=0,left=0,toolbar=no,scrollbars=yes,resizable=yes,status=no,menubar=no";
var sDefaultModelessDialogStyle = "dialogLeft="+(sScreenWidth*0.6)+";dialogWidth="+(sScreenWidth*0.4)+"px;dialogHeight="+(sScreenHeight)+"px;resizable=yes;status:yes;maximize:yes;help:no;";
var sDefaultDialogStyle2 = "dialogLeft="+(sScreenWidth*0.35)+";dialogWidth="+(sScreenWidth*0.65)+"px;dialogHeight="+(sScreenHeight)+"px;resizable=yes;status:yes;maximize:yes;help:no;";

function over_change(index,src,clrOver)
{
		if (!src.contains(event.fromElement)) 
	 	{ 
	 		src.style.cursor = 'hand';
	 		src.background = clrOver;
	 	}
}

function out_change(index,src,clrIn)
{
		if (!src.contains(event.toElement))
		{
			src.style.cursor = 'default';
			src.background = clrIn;
		}
}

bIsLocked=false;

function checkIfLocked()
{
	if(bIsLocked)
	{
		if(!confirm("���Ѿ��õ�����ʽ����һ����ҳ�棬�뿪��ҳ�潫���ܵ��³�����\n�ô��󽫲���Ӱ��ϵͳ�������С�\n��ȷ��Ҫ�뿪��ҳ����")) 
			return true;
		else 
			return false;
	}
	else	
		return true;
}

function randomNumber()
{
	today = new Date();
	num = Math.abs(Math.sin(today.getTime()));
	return num;  
}

//���ڼ�麯��	
function isDate(sItemName) 
{
	var value = Query.elements(sItemName).value;
	var sItems = value.split("/");
	
	if (sItems.length!=3) return false;
	if (isNaN(sItems[0])) return false;
	if (isNaN(sItems[1])) return false;
	if (isNaN(sItems[2])) return false;
	if (parseInt(sItems[0],10)<1900 || parseInt(sItems[0],10)>2150) return false;
	if (parseInt(sItems[1],10)<1 || parseInt(sItems[1],10)>12) return false;
	if (parseInt(sItems[2],10)<1 || parseInt(sItems[2],10)>31) return false;
	return true;
}	


//�ı乤������С
function resizeLeft()
{
	try{
		if(myleft.width==1) 
		{
			myleft.width=myleftwidth;
			//self.mymiddle.style.cssText="cursor:w-resize";
		}
		else 
		{
			myleftwidth=myleft.width;
			myleft.width=1;
			//self.mymiddle.style.cssText="cursor:e-resize";
		 }
	}catch(e){
		
	}
}
	 
function resizeTop()
{
	if(mytop.height==25) 
	{
		mytop.height=mytopheight;
		//self.mymiddle.style.cssText="cursor:w-resize";
	}
	else 
	{
		mytopheight=top.mytop.height 
		mytop.height=25;
		//self.mymiddle.style.cssText="cursor:e-resize";
	 }

}


function setObjectInfo(sObjectType,sValueString,iArgDW,iArgRow,sStyle)
{
	//sObjectType����������
	//sValueString��ʽ�� ������� @ ID���� @ ID�ڷ��ش��е�λ�� @ Name���� @ Name�ڷ��ش��е�λ��
	//iArgDW: �ڼ���DW��Ĭ��Ϊ0
	//iArgRow: �ڼ��У�Ĭ��Ϊ0
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:700px;dialogHeight:540px;resizable:yes;scrollbars:no;status:no;help:no";
	var iDW = iArgDW;
	if(iDW == null) iDW=0;
	var iRow = iArgRow;
	if(iRow == null) iRow=0;
	
	var sValues = sValueString.split("@");
	
	var sParaString = sValues[0];
	
	var i=sValues.length;
   	i=i-1;
   	if (i%2!=0)
   	{
   		alert("setObjectInfo()���ز����趨����!\r\n��ʽΪ:@ID����@ID�ڷ��ش��е�λ��...");
		return;
   	}
	else
	{	
		var j=i/2,m,sColumn,iID;	
		//sObjectNoString = PopPage("/SystemManage/SelectionDialog/GetObjectNo.jsp?ObjectType="+sObjectType+"&ParaString="+sParaString,"","dialogWidth:640px;dialogHeight:480px;resizable:yes;scrollbars:no");
		sObjectNoString = selectObjectInfo(sObjectType,sParaString,sStyle);
		if(typeof(sObjectNoString)=="undefined" )
		{
			return;	
		}
		else if(sObjectNoString=="_CANCEL_"  )
		{
			return;
		}
		else if(sObjectNoString=="_CLEAR_")
		{
			for(m=1;m<=j;m++)
			{
				sColumn = sValues[2*m-1];
				if(sColumn!="")
					setItemValue(iDW,iRow,sColumn,"");
			}
	
		}
		else if(sObjectNoString!="_NONE_" && sObjectNoString!="undefined")
		{
			sObjectNos = sObjectNoString.split("@");
			for(m=1;m<=j;m++)
			{
				sColumn = sValues[2*m-1];
				iID = parseInt(sValues[2*m],10);
				if(sColumn!="")
					setItemValue(iDW,iRow,sColumn,sObjectNos[iID]);
			}
	
		}
		else
		{
			//alert("ѡȡ������ʧ�ܣ��������ͣ�"+sObjectType);
			return;
		}
		return sObjectNoString;
	}	
}
	
function selectObjectInfo(sObjectType,sParaString,sStyle)
{
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:680px;dialogHeight:540px;resizable:yes;scrollbars:no;status:no;help:no";
	sObjectNoString = PopPage("/Frame/ObjectSelect.jsp?ObjectType="+sObjectType+"&ParaString="+sParaString,"",sStyle);
	
	return sObjectNoString;
}

function createObject(sObjectType,sParaString,sStyle)
{
	alert("�����������ϣ���ο�ExampleList.jsp��ʹ��popComp���");
	/*
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:520px;dialogHeight:420px;resizable:yes;status:no;scrollbars:no";
	sObjectNoString = PopPage("/Frame/ObjectCreationDialog.jsp?ObjectType="+sObjectType+"&ParaString="+sParaString,"",sStyle);
	return sObjectNoString;
	*/
}

function openObject(sObjectType,sObjectNo,sViewID,sStyle)
{		
	OpenComp("ObjectViewer","/Frame/ObjectViewer.jsp","ObjectType="+sObjectType+"&ObjectNo="+sObjectNo+"&ViewID="+sViewID,"_blank",sStyle);
}

function OpenObject(sObjectType,sObjectNo,sViewID,sStyle){
	openObject(sObjectType,sObjectNo,sViewID,sStyle);
}

function popObject(sObjectType,sObjectNo,sViewID,sDialogStyle,sDialogParas)
{
	popComp("ObjectViewer","/Frame/ObjectViewer.jsp","ObjectType="+sObjectType+"~ObjectNo="+sObjectNo+"~ViewID="+sViewID,sDialogStyle,sDialogParas);
}

function PopObject(sObjectType,sObjectNo,sViewID,sDialogStyle,sDialogParas)
{
	popObject(sObjectType,sObjectNo,sViewID,sDialogStyle,sDialogParas);
}

function openObjectInFrame(sObjectType,sObjectNo,sViewID,sFrameID)
{
	OpenComp("ObjectViewer","/Frame/ObjectViewer.jsp","ObjectType="+sObjectType+"&ObjectNo="+sObjectNo+"&ViewID="+sViewID,sFrameID,"");
}

function maximizeWindow(){
	window.moveTo(0,0);
	if (document.all) 
	{ 
  		top.window.resizeTo(screen.availWidth,screen.availHeight); 
	} 
 
	else if (document.layers||document.getElementById) 
	{ 
  		if (top.window.outerHeight<screen.availHeight||top.window.outerWidth<screen.availWidth) 
  		{ 
    		top.window.outerHeight = screen.availHeight; 
    		top.window.outerWidth = screen.availWidth; 
  		} 
	} 
}

function openComp(sCompID,sCompURL,sPara,sTargetWindow,sStyle){
	return OpenComp(sCompID,sCompURL,sPara,sTargetWindow,sStyle);
}
function OpenComp(sCompID,sCompURL,sPara,sTargetWindow,sStyle)
{
	var sToDestroyClientID="";
	var sWindowToUnload = sTargetWindow;
	if(sCompURL.indexOf("?")>=0){
		alert("�������URL�д���\"?\"���뽫��������ڵ����������д��룡");
		return;
	}

	if(sTargetWindow=="_blank") {
		sToDestroyClientID = "";
		return popComp(sCompID,sCompURL,sPara);
	}else{
		if(sTargetWindow==null || sTargetWindow=="_self") sWindowToUnload="self";
		if(sTargetWindow==null || sTargetWindow=="_top") sWindowToUnload="top";

		try{
			//�޸���ʾ
			oWindow = eval(sWindowToUnload);
			sToDestroyClientID = oWindow.sCompClientID; //add in 2005/04/25
		}catch(e){
			sToDestroyClientID = "";
		}

		try{if(!oWindow.checkModified()) return;}catch(e1){}
	}
	var sURL = sWebRootPath + "/Redirector.jsp?ComponentID="+sCompID+"&OpenerClientID="+sCompClientID+"&ToDestroyClientID="+sToDestroyClientID+"&ComponentURL="+sCompURL+"&"+sPara+"&rand1="+randomNumber();
	window.open(sURL,sTargetWindow,sStyle);
}
function OpenPage(sURL,sTargetWindow,sStyle)
{
	var sPageURL=""; 
	if(sURL.indexOf("?")<0) sPageURL = sWebRootPath + sURL + "?&";
	else sPageURL = sWebRootPath + sURL+"&";

	if(sTargetWindow=="_blank"){
		alert("���󣺵�����ҳ���벻Ҫʹ��OpenPage������");
	}
	
	var sToDestroyPageClientID = ""; // byhu 20050604

	sWindowToUnload="";
	if(sTargetWindow==null || sTargetWindow=="_self"){
		sWindowToUnload="self";
	}else if(sTargetWindow=="_top"){
		sWindowToUnload="top";
	}else if(sTargetWindow=="_blank"){
		sWindowToUnload="";
	}else if(sTargetWindow=="_parent"){
		sWindowToUnload="parent";
	}else sWindowToUnload=sTargetWindow;
	try{
		//�޸���ʾ
		oWindow = eval(sWindowToUnload);
		sToDestroyPageClientID = oWindow.sPageClientID; // byhu 20050604
	}catch(e){
	}
	try{
		oWindow = eval(sWindowToUnload);
		if(!oWindow.checkModified()) return;
	}catch(e){
	}
	
	sPageURL = sPageURL + "CompClientID="+sCompClientID+"&ToDestroyPageClientID="+sToDestroyPageClientID+"&rand1="+randomNumber();
	//alert(sPageURL);
	window.open(sPageURL,sTargetWindow,sStyle);
}

//add in 2012/03/29
function OpenCompComplex(whichFlag,sCompID,sCompURL,sPara,sTargetWindow,sStyle)
{
	
	//����ҳ����ù�ϵ btan 2011/03/17
	//setPageRela(sCompURL);
	
	var sToDestroyClientID="";
	var sWindowToUnload = sTargetWindow;
	if(sCompURL.indexOf("?")>=0){
		alert("�������URL�д���\"?\"���뽫��������ڵ����������д��룡");
		return;
	}

	//if(sTargetWindow=="_blank") {
	//	sToDestroyClientID = "";
	//	return popComp(sCompID,sCompURL,sPara);
	//}else{
		if(sTargetWindow==null || sTargetWindow=="_self") sWindowToUnload="self";
		if(sTargetWindow==null || sTargetWindow=="_top") sWindowToUnload="top";

		try{
			//�޸���ʾ
			oWindow = eval(sWindowToUnload);
			sToDestroyClientID = oWindow.sCompClientID; //add in 2005/04/25
		}catch(e){
			sToDestroyClientID = "";
		}

		try{if(!oWindow.checkModified()) return;}catch(e1){}
	//}
	var sNewWebRootPath = "";
	if(whichFlag=="PUBLIC") sNewWebRootPath = s_url_mnpm;
	if(whichFlag=="RCPM") sNewWebRootPath = s_url_rcpm;
	if(whichFlag=="SWPM") sNewWebRootPath = s_url_swpm;
	
	var sURL = sNewWebRootPath + "/Redirector.jsp?ComponentID="+sCompID+"&OpenerClientID="+sCompClientID+"&ToDestroyClientID="+sToDestroyClientID+"&ComponentURL="+sCompURL+"&"+sPara+"&rand1="+randomNumber();
	window.open(sURL,sTargetWindow,sStyle);
}


function popComp(sComponentID,sComponentURL,sParaString,sStyle,sDialogParameters)
{
	var sDialogStyle = "";
	if(typeof(sStyle)=="undefined" || sStyle=="") sDialogStyle= sDefaultDialogStyle;
	else sDialogStyle = sStyle;

	var sActualDialogParameters = "";
	if(typeof(sDialogParameters)!="undefined" && sDialogParameters!="") sActualDialogParameters= sDialogParameters;

	var sCompParaString = sParaString;
	while(sCompParaString.indexOf("&")>=0) sCompParaString = sCompParaString.replace("&","$[and]");
	return PopPage("/Frame/OpenCompDialog.jsp?ComponentID="+sComponentID+"&ComponentURL="+sComponentURL+"&ParaString="+sCompParaString+"&"+sActualDialogParameters,"",sDialogStyle);
}

function PopComp(sComponentID,sComponentURL,sParaString,sStyle,sDialogParameters)
{
	return popComp(sComponentID,sComponentURL,sParaString,sStyle,sDialogParameters);
}

function PopPage(sURL,sTargetWindow,sStyle)
{
	var sDialogStyle = "";
	if(typeof(sStyle)=="undefined" || sStyle=="") sDialogStyle= sDefaultDialogStyle;
	else sDialogStyle = sStyle;

	var sPageURL=""; 
	if(sURL.indexOf("?")<0) sPageURL = sWebRootPath+sURL+"?";
	else sPageURL = sWebRootPath+sURL+"&";
	
	sPageURL = sPageURL + "CompClientID="+sCompClientID+"&rand1="+randomNumber();
	//alert(sPageURL);
	
	//modify in 2009/08/20 
	//..........RunMethodҲҪ�ģ�����������������
	//return window.showModalDialog(sPageURL,sTargetWindow,sDialogStyle);
	//��Ӧ��jspҪ���ӣ���<body><%=xxxxx%></body>
	if( sPageURL.indexOf("/Common/ToolsB/GetCompAttribute.jsp")>=0 ||
		sPageURL.indexOf("/Common/ToolsB/GetDay.jsp")>=0 ||
		sPageURL.indexOf("/Common/ToolsB/GetNow.jsp")>=0 ||
		sPageURL.indexOf("/Common/ToolsB/GetSerialNo.jsp")>=0||
		sPageURL.indexOf("/Common/ToolsB/RunMethod.jsp")>=0)
	{
		//var sSerialNo = PopPage("/Common/ToolsB/GetCEBSerialNo.jsp?SerialNoType="+sSerialNoType+"&OrgID="+sOrgID.....
    	//RunMethod(ClassName,MethodName,Args){
    	ShowMessage("���ڻ�ȡ�����Ϣ�����Ժ�......",true,false);
		var myAjax = new Ajax();
		myAjax.setTargetPage(sPageURL);
		myArg = new Array();
		//myArg.push("ClassName="+ClassName);
		//myArg.push("MethodName="+MethodName);
		//myArg.push("Args="+Args);
		myAjax.sendRequest(myArg);
		var sReturnResult = getResult();
		hideMessage(); 
		return sReturnResult;	
	}
	else
		return window.showModalDialog(sPageURL,sTargetWindow,sDialogStyle);
			
}

function PopModelessPage(sURL,sTargetWindow,sStyle){
	var sDialogStyle = "";
	if(typeof(sStyle)=="undefined" || sStyle=="") sDialogStyle= sDefaultModelessDialogStyle;
	else sDialogStyle = sStyle;

	var sPageURL=""; 
	if(sURL.indexOf("?")<0) sPageURL = sWebRootPath+sURL+"?";
	else sPageURL = sWebRootPath+sURL+"&";
	
	sPageURL = sPageURL + "ShowSysArea=false&CompClientID="+sCompClientID+"&rand1="+randomNumber();
	//alert(sPageURL);
	return window.showModelessDialog(sPageURL,sTargetWindow,sDialogStyle);
}
function PopModelessComp(sComponentID,sComponentURL,sParaString,sStyle)
{
	var sDialogStyle = "";
	if(typeof(sStyle)=="undefined" || sStyle=="") sDialogStyle= sDefaultModelessDialogStyle;
	else sDialogStyle = sStyle;

	var sCompParaString = sParaString;
	while(sCompParaString.indexOf("&")>=0) sCompParaString = sCompParaString.replace("&","$[and]");
	return PopModelessPage("/Frame/OpenCompDialog.jsp?ComponentID="+sComponentID+"&ComponentURL="+sComponentURL+"&ParaString="+sCompParaString,"",sDialogStyle);
}

function ShowCompHelp(sCompID)
{ 					
		PopModelessComp('OnlineHelp','/Common/help/HelpFrame.jsp','ObjectType=ComponentDefinition&ObjectNo='+sCompID+'&CommentType=Help');
}
function ShowHelp(sHelpID)
{ 					
		PopModelessComp('OnlineHelp','/Common/help/HelpFrame.jsp','CommentItemID='+sHelpID);
}
function viewSource()
{
	var ress  =parent.location;
	window.location="view-source:"+ress;
}
function key_up(e){
	if( document.event.shiftKey  && document.event.ctrlKey && document.event.altKey   )
	{
		alert("ss");
		return;
	}
}
function GetPropertiesString(objObject) //byhu: �˺������Բ쿴����������������
{
   var varProp;
   var strProperties = objObject.id + "\n";

   for (varProp in objObject)
   {
      strProperties += varProp + " = " + objObject[varProp] + "\n";
   }
   return strProperties;
}

function reloadSelf(){
	//��ס��ǰ��ҳ�ź��к�
	rememberPageRow();
	if(document.forms("DOFilter")==null){
		self.location.reload();
	} else if(typeof(document.forms("DOFilter"))=="undefined"){
		self.location.reload();
	}else{
		document.forms("DOFilter").submit();
	}
}
function rememberPageRow(){
	//document.all("DWCurPage").value=curpage[0];
	//document.all("DWCurRow").value=getRow(0);
}

//add by hxd in 2008/04/10 
function reloadCurrentRow_old(iDW,iTempCurrRow)
{
 	var ii=0,mycond=" 1e1eq2qu3u1 "; 
	for(ii=0;ii<f_c[iDW];ii++)
	{
		if(DZ[iDW][1][ii][1]==1) 
		{
			if(DZ[iDW][1][ii][12]==1||DZ[iDW][1][ii][12]==3||DZ[iDW][1][ii][12]==4)
				mycond = mycond + " and " + DZ[iDW][1][ii][15] + "e1eq2qu3u'"+DZ[iDW][2][iTempCurrRow][ii]+"'";
			else
				mycond = mycond + " and " + DZ[iDW][1][ii][15] + "e1eq2qu3u"+DZ[iDW][2][iTempCurrRow][ii];
		}
	}	
	
 	var myoldstatus = window.status;   
 	window.status="���ڴӷ�����������ݸ��µ�ǰ��¼�����Ժ�....";   
 	self.showModalDialog(sPath+"GetDWCurrRow.jsp?dw="+DZ[iDW][0][1]+"&cond="+real2Amarsoft(mycond)+"&rand="+amarRand(),window.self,"dialogWidth=10;dialogHeight=1;status:no;center:yes;help:no;minimize:yes;maximize:no;border:thin;statusbar:no"); 
 	window.status=myoldstatus; 
 	   
	for(ii=0;ii<f_c[iDW];ii++) 
	{	
		setItemValue(iDW,getRow(iDW),DZ[iDW][1][ii][15],DZ[iDW][2][iTempCurrRow][ii]+"A");
	}	
}

//add by hxd in 2008/04/10 
function reloadCurrentRow(_iDW,_iTempCurrRow)
{
	var iDW=0;
	var iTempCurrRow=0;
	
	if(arguments.length==0)
	{
		iDW = 0;
		iTempCurrRow = getRow(0);
	}
	
	if(arguments.length==1)
	{
		iDW = _iDW ;
		iTempCurrRow = getRow(iDW);
	}
	
	if(arguments.length==2)
	{
		iDW = _iDW ;
		iTempCurrRow = _iTempCurrow;
	}
		
	var bHaveKey = false;
 	var ii=0,mycond=""; 
 	
 	mycond = "dw="+DZ[iDW][0][1]+"&row="+iTempCurrRow;
 	
	for(ii=0;ii<f_c[iDW];ii++)
	{
		if(DZ[iDW][1][ii][1]==1) 
		{
			bHaveKey = true;
			mycond = mycond+"&col"+ii+"="+real2Amarsoft(DZ[iDW][2][iTempCurrRow][ii]);
		}
	}	
	
	if(!bHaveKey)
	{
		alert("��DW����û�ж������������ܶ�̬���£�");
		return;
	}

 	var myoldstatus = window.status;   
 	window.status="���ڴӷ�����������ݸ��µ�ǰ��¼�����Ժ�....";   
 	self.showModalDialog(sPath+"GetDWCurrRow.jsp?"+mycond+"&rand="+amarRand(),window.self,
 		"dialogWidth=10;dialogHeight=1;status:no;center:yes;help:no;minimize:yes;maximize:no;border:thin;statusbar:no"); 
 	window.status=myoldstatus; 
 	   
	for(ii=0;ii<f_c[iDW];ii++) 
	{	
		try {
		setItemValue(iDW,iTempCurrRow,DZ[iDW][1][ii][15],DZ[iDW][2][iTempCurrRow][ii]);
		}catch(e){}
	}	
}

function setDialogTitle(sTitleText){
/**
	try {

		oTitleTD = top.document.all("TitleTD");
		oTitleTR = top.document.all("TitleTR");
		if(typeof(oTitleTD)=="undefined") return;
		if(sTitleText==""){
			oTitleTR.style.display = "none";
			oTitleTD.innerHTML="";
		}else{
			oTitleTR.style.display = "";
			oTitleTD.innerHTML="&nbsp;&nbsp;<b>"+sTitleText+"</b>";
		}
	}catch(e){}
	**/
	setCardTitle(sTitleText);
}
//������Ϣ��ʾ add by yyduan 2009-4-15 setCardTitle setTaskTitle
function setCardTitle(sTitleText){

	try {
		oTitleTD = top.document.all("CardTitle");
		if(typeof(oTitleTD)=="undefined") return;
		if(sTitleText==""){
			oTitleTD.innerHTML="";
		}else{
			oTitleTD.innerHTML="&nbsp;��Ϣ��ʾ&nbsp;|&nbsp;"+sTitleText+"&nbsp;&nbsp;";
		}
			}
		catch(e){}
}
function setTaskTitle(sTitleText){
	oTitleTD = top.document.all("TaskTitle");
	if(typeof(oTitleTD)=="undefined") return;
	if(sTitleText==""){
		oTitleTD.innerHTML="";
	}else{
		oTitleTD.innerHTML="&nbsp;��������&nbsp;|&nbsp;"+sTitleText+"&nbsp;&nbsp;";
	}
}
function hideSystemWindow(){
	oTitleTD = top.document.all("TaskTitle");
	if(typeof(oTitleTD)=="undefined") return;
	if(sTitleText==""){
		oTitleTD.innerHTML="";
	}else{
		oTitleTD.innerHTML="&nbsp;��������&nbsp;|&nbsp;"+sTitleText+"&nbsp;&nbsp;";
	}
}
/*~[Describe=������ѡ���봰�ڣ����ý����ص�ֵ���õ�ָ������;InputParam=��;OutPutParam=��;]~*/
/*
 *����ֵ��ʽΪ: Field1,Field2,......@FieldName1,FieldName2,................. 
 *ǰ���������ݿ�洢������������ʾ��	    
*/
function selectMore(sFieldID,sSelName,sParaString){	
		var sCond = "'������'";
    	var sFieldValue =  getItemValue(0,0,sFieldID);		
		if(typeof(sFieldValue)!="undefined" && sFieldValue.length!=0)
		{
			var sArray = sFieldValue.split("@");
			var i1=1;
			for(i1=1;i1<sArray.length-1;i1++)//��1��ʼȥ�����߲�����''
				sCond += "@'"+sArray[i1]+"'";
		}
		if(typeof(sParaString) == "undefined")
		{
			sParaString = "";
		}
      var sReturn =PopPage("/Common/ToolsA/SelectMore.jsp?Cond="+sCond+"&CodeNo="+sSelName+"&ParaString="+sParaString,"","dialogWidth=60;dialogheight=30;status:no;center:yes;help:no;minimize:no;maximize:no;border:thin;statusbar:no");       	
	  var sNewReturn = "";
	  var sFieldID = "";
	  var sFieldName = "";
	  //alert(sReturn.length+" "+sReturn);
	  if(typeof(sReturn)!="undefined" && sReturn.length!=0 && sReturn!="_NONE_"  && sReturn!="NoData")
	   {
			sMoreCodeEnable = sReturn.split("@")[0];
			sNewReturn = sReturn.split("@")[1];	 
			sFieldID =  sReturn.split("@")[2];  
			sFieldName =  sReturn.split("@")[3];  
			ssMoreCodeEnable = sMoreCodeEnable.replace(/,/g,"@");	//��,�Ż���@���Ŵ浽���ݿ�	
			//������仰����ȥ��
			if(typeof(ssMoreCodeEnable)!="undefined" && ssMoreCodeEnable.length!=0) ssMoreCodeEnable = "@"+ssMoreCodeEnable+"@";
			sNewReturn = sNewReturn.replace(/,/g,"\r\n"); //��,��ȫ�滻�ɻ��з� ���н�����ʾ
	     	setItemValue(0,getRow(),sFieldID,ssMoreCodeEnable)//����ͳһ������@
			setItemValue(0,getRow(),sFieldName,sNewReturn);//�趨��Ӧ����
	   }
	  else// if(sReturn=="NoData")
	   {
	      setItemValue(0,getRow(),sFieldID,"");
		  setItemValue(0,getRow(),sFieldName,"");//�趨��Ӧ����
	   }
	}
/*
 * ��ѡcheckbox����
 *����my_handle_checkbox  myHideCheckBoxRela
 *����
 *��һ��
 *ASResultSet rs0 = Sqlca.getASResultSet("select itemno,itemname from code_library where codeno='YesNo' and IsInUse='1' order by sortno ");
 *	while(rs0.next())
 *	{
 *		String sItemNo = rs0.getString("itemno");
 *		sString += "<input type=\"checkbox\" onclick=javascript:parent.my_handle_checkbox(this,\"RoleStatus\") id=\"RoleStatus_"+sItemNo+"\" value=\""+sItemNo+"\"  > "+rs0.getString("itemname");
 *	}
 *	rs0.getStatement().close();
 *	doTemp.setEditStyle("RoleStatus","1");//���checkbox,�������ø��ֶ�Ϊinput����(��������������),input�ؼ��ᱻstep3�ĺ�������,����֮��unit���checkbox
 *	doTemp.setUnit("RoleStatus",sString);
 *ע�⣺������my_load,initRow()֮����Ҫ����myHideCheckBoxRela���������������Ҫ����myHideCheckBoxRela
	1.as_add("myiframe0");  ---����Ϊ--->as_add("myiframe0","myHideCheckBoxRela('RoleStatus'));
	2.as_save("myiframe0"); ---����Ϊ--->as_save("myiframe0","myHideCheckBoxRela('RoleStatus')");	
*/
function my_handle_checkbox(obj,sFieldName)
{
	var i = 0;
	var sResult = "@";
	for(i=0;i<myiframe0.document.all.length;i++)
	{
		if(myiframe0.document.all(i).id.indexOf(sFieldName+"_")>=0 && myiframe0.document.all(i).checked)
		{
			//if(sResult!="") sResult+=","+myiframe0.document.all(i).value;
			//else sResult=myiframe0.document.all(i).value;
			sResult+=myiframe0.document.all(i).value+"@";
		}	
	}
	if(sResult=="@") sResult = "";//add by yy
	setItemValue(0,0,sFieldName,sResult);
}

function myHideCheckBoxRela(sFieldName)
{
	//����input
	getASObject(0,0,sFieldName).style.display="none";
	//���¶�checkbox��ֵ 
	var sResult = getItemValue(0,0,sFieldName);
	var aResult = sResult.split("@"); 
	var i=0,j=0;
	for(i=0;i<myiframe0.document.all.length;i++)
	{
		if(myiframe0.document.all(i).id.indexOf(sFieldName+"_")>=0 )
		{
			myiframe0.document.all(i).checked = false;
			for(j=0;j<aResult.length;j++)
			{
				if(myiframe0.document.all(i).value == aResult[j])
				{
					myiframe0.document.all(i).checked = true;
					break;
				}
			}
		}	
	}		
}
/**
 * ��ݼ���¼���������
 * @return
 */
function DBQuickSelect(obj)
{
    this.obj = obj;
    this.row = "";
    this.column = "";
    this.ColumnGBName = "";
    this.ColumnName = "";
    this.ColumnGBNameIndex = 0;
    this.ColumnNameIndex = 15;
    if(this.obj==null)
       return;
    this.init();
}

DBQuickSelect.prototype.init = function()
 {
	var array = this.obj.name.split("F");
	this.row = array[0].replace("R","");
	this.column = array[1];
	this.ColumnGBName = DZ[0][1][this.column][this.ColumnGBNameIndex];
	this.ColumnName  = DZ[0][1][this.column][this.ColumnNameIndex];
 }
 
DBQuickSelect.prototype.getValue = function()
 {
	if(this.obj==null)
       	return "";
	else
	   return this.obj.value;
 }

var SelectQuickOBJ = new DBQuickSelect(null);

function onElementQuickFocus(obj)
{
	//obj.style.borderWidth='0.05cm';
	//obj.style.borderColor='RED';
	//obj.style.borderStyle='solid'
	//obj.style.color='blue'
	SelectQuickOBJ = new DBQuickSelect(obj);
}
function onElementQuickBlur(obj)
{
    obj.style.borderWidth='0.0';
	obj.style.borderColor='';
	obj.style.borderStyle=''
	obj.style.color=''
}
//add by 2009-8-7 ���ò��ɼ�
function setColNameVisible(colname,vistrue)  
{
	var index = getColIndex(0,colname);
	if(vistrue)
	DZ[0][1][index][2]=1;
	else { 
		DZ[0][1][index][2]=0; 
		//DZ[0][1][index][4]="1"; 
		setItemRequired(0,0,colname,false);
		}
}
//----
function sessionOut()
{
	if(confirm("ȷ���˳���ϵͳ��"))
		OpenPage("/SignOut.jsp","_top","");
}

// byhu 2005.08.04 ����һ��ASMethod��������ֵ
function returnText2(){
    return amarsoft2Real(PopPage("/Common/ToolsB/RunMethod2.jsp"));
}
function RunMethod2(ClassName,MethodName,Args){
      saveParaToComp("ClassName="+ClassName+"&MethodName="+MethodName+"&Args="+Args,"returnText2()");
}

function RunMethod(ClassName,MethodName,Args){
		//zywei 2008/10/13 ��ִ���߼��Ĵ����Ƶ��û���̫��ע�ĵط�
		//return PopPage("/Common/ToolsB/RunMethod.jsp?ClassName="+ClassName+"&MethodName="+MethodName+"&Args="+Args,"","width:0px;height:0px");
		return PopPage("/Common/ToolsB/RunMethod.jsp?ClassName="+ClassName+"&MethodName="+MethodName+"&Args="+Args,"","resizable=yes;dialogWidth=0;dialogHeight=0;center:no;status:no;statusbar:no");
}

function RunMethod9(ClassName,MethodName,Args){ 
		//zywei 2008/10/13 ��ִ���߼��Ĵ����Ƶ��û���̫��ע�ĵط�
		//return PopPage("/Common/ToolsB/RunMethod9.jsp?ClassName="+ClassName+"&MethodName="+MethodName+"&Args="+Args,"","width:0px;height:0px");
		return PopPage("/Common/ToolsB/RunMethod9.jsp?ClassName="+ClassName+"&MethodName="+MethodName+"&Args="+Args,"","resizable=yes;dialogWidth=0;dialogHeight=0;center:no;status:no;statusbar:no");
}


/*~[Describe=��ʼ����ˮ���ֶ�;InputParam=��;OutPutParam=��;]~*/
function getSerialNo(sTableName,sColumnName,sPrefix) 
{
	//ʹ��GetSerialNo.jsp����ռһ����ˮ��
	return PopPage("/Common/ToolsB/GetSerialNo.jsp?TableName="+sTableName+"&ColumnName="+sColumnName+"&Prefix="+sPrefix,"","resizable=yes;dialogWidth=0;dialogHeight=0;center:no;status:no;statusbar:no");
}
	
	
	

//*************************begin********************
//Author:thong
//Create Date?2005-9-7 8:20
//Describe:��ҳ�����ύ��ѯ�����󣬳��ֽ�������ֱ���µ�ҳ�������ȫ��load������
//**************************************************
function onSubmit(sUrl,sParameter) {
	var waitingInfo = document.getElementById(getNetuiTagName("waitingInfo"));
	//������ʾ
	waitingInfo.style.display = ""; 
	//������ʼ
	progress_update(); 
	//�������
	for(i=0;i<1000000;i++){
		j=i+i;
	}
	
	OpenPage(sUrl,sParameter,""); 
}

//Modify Date?2006-2-16 17:20 Ϊ�˼�˲�ͬ��form��������һ������sFormName
function onFromAction(sUrl,sFormName) {
	var waitingInfo = document.getElementById(getNetuiTagName("waitingInfo"));
	waitingInfo.style.display = ""; 
	progress_update(); 
	for(i=0;i<1000000;i++){
		j=i+i;
	}
	if(sFormName == "report")
	{
		document.report.action = sUrl;
		document.report.submit();
	}
	if(sFormName == "DOFilter")
	{
		sUrl.submit();
	}
	
}

// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
var netui_names = new Object();
netui_names.selectButton="portlet_15_1selectButton"
// method which will return a real id for a tagId
function getNetuiTagName(id) {
	return netui_names[id];
}

// method which will return a real id for a tagId,
// the tag parameter will be used to find the scopeId for
// containers that may scope their ids
function getNetuiTagName(id, tag) {
	var scopeId = getScopeId(tag);
	if (scopeId == "")
		return netui_names[id];
	else
		return netui_names[scopeId + "__" + id];
}

// method which get a tag will find any scopeId that,
// was inserted by the containers
function getScopeId(tag) {
	if (tag == null)
		return "";
	if (tag.getAttribute) { 
		if (tag.getAttribute('scopeId') != null)
			return tag.getAttribute('scopeId');
	} 
	if (tag.scopeId != null)
		return tag.scopeId;
		return getScopeId(tag.parentNode);
}

// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
var netui_names = new Object();
netui_names.waitingInfo="waitingInfo"

//������
var progressEnd = 18; 
//��������ɫ
var progressColor = 'green'; 
var progressInterval = 200; // set to time between updates (milli-seconds)

var progressAt = progressEnd;
var progressTimer;

function progress_clear() {
	for (var i = 1; i <= progressEnd; i++) 
		document.getElementById('progress'+i).style.backgroundColor = 'transparent';
	progressAt = 0;
}
function progress_update() {
progressAt++;
	if (progressAt > progressEnd) progress_clear();
	else document.getElementById('progress'+progressAt).style.backgroundColor = progressColor;
	progressTimer = setTimeout('progress_update()',progressInterval);
}
function progress_stop() {
	clearTimeout(progressTimer);
	progress_clear();
}	
//*******************************end*********************************
	
//add zywei 2005/08/31 ��Ҫ��ʹ����select_catalog���Զ����ѯѡ����Ϣ		
function setObjectValue(sObjectType,sPataString,sValueString,iArgDW,iArgRow,sStyle)
{
	//sObjectType����������
	//sValueString��ʽ�� ������� @ ID���� @ ID�ڷ��ش��е�λ�� @ Name���� @ Name�ڷ��ش��е�λ��
	//iArgDW: �ڼ���DW��Ĭ��Ϊ0
	//iArgRow: �ڼ��У�Ĭ��Ϊ0
	
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:700px;dialogHeight:540px;resizable:yes;scrollbars:no;status:no;help:no";
	var iDW = iArgDW;
	if(iDW == null) iDW=0;
	var iRow = iArgRow;
	if(iRow == null) iRow=0;
	
	var sValues = sValueString.split("@");
	
	var i=sValues.length;
 	i=i-1;
 	if (i%2!=0)
 	{
 		alert("setObjectValue()���ز����趨����!\r\n��ʽΪ:@ID����@ID�ڷ��ش��е�λ��...");
		return;
 	}else
	{	
		
		var j=i/2,m,sColumn,iID;			
		sObjectNoString = selectObjectValue(sObjectType,sPataString,sStyle);		
		if(typeof(sObjectNoString)=="undefined" )
		{
			return;	
		}else if(sObjectNoString=="_CANCEL_"  )
		{
			return;
		}else if(sObjectNoString=="_CLEAR_")
		{
			for(m=1;m<=j;m++)
			{
				sColumn = sValues[2*m-1];
				if(sColumn!="")
					setItemValue(iDW,iRow,sColumn,"");
			}	
		}else if(sObjectNoString!="_NONE_" && sObjectNoString!="undefined")
		{
			sObjectNos = sObjectNoString.split("@");
			for(m=1;m<=j;m++)
			{
				sColumn = sValues[2*m-1];
				iID = parseInt(sValues[2*m],10);
				
				if(sColumn!="")
				{					
					if(sObjectNos[iID]!="undefined")
						setItemValue(iDW,iRow,sColumn,sObjectNos[iID]);
					else
						setItemValue(iDW,iRow,sColumn,"");
				}
			}	
		}else
		{
			//alert("ѡȡ������ʧ�ܣ��������ͣ�"+sObjectType);
			return;
		}
		return sObjectNoString;
	}	
}

//add zywei 2005/08/31 ��Ҫ��ʹ����select_catalog���Զ����ѯѡ����Ϣ	
function selectObjectValue(sObjectType,sParaString,sStyle)
{
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:680px;dialogHeight:540px;resizable:yes;scrollbars:no;status:no;help:no";
	//sObjectNoString = PopComp("SelectGridDialog","/Frame/SelectGridDialog.jsp","SelName="+sObjectType+"&ParaString="+sParaString,sStyle);
	sObjectNoString = PopPage("/Frame/DialogSelect.jsp?SelName="+sObjectType+"&ParaString="+sParaString,"",sStyle);
	return sObjectNoString;
}

//add zywei 2005/08/31 ��Ҫ��ʹ����select_catalog���Զ����ѯѡ����Ϣ	
function selectMultipleGrid(sObjectType,sParaString,sStyle)
{
	if(typeof(sStyle)=="undefined" || sStyle=="") sStyle = "dialogWidth:680px;dialogHeight:540px;resizable:yes;scrollbars:no;status:no;help:no";
	//sObjectNoString = PopComp("SelectGridDialog","/Frame/SelectGridDialog.jsp","SelName="+sObjectType+"&ParaString="+sParaString,sStyle);
	sObjectNoString = PopComp("SelectMultipleGridDialog","/Frame/SelectMultipleGridDialog.jsp","SelName="+sObjectType+"&ParaString="+sParaString,sStyle);
	return sObjectNoString;
}

//add by byhu 2006.08.03 �༭����
function editRule(sTable,sRegisteredColumn)
{
	sScript=getItemValue(0,getRow(),sRegisteredColumn);
	saveParaToComp("Script="+sScript,"openRuleEditor('"+sTable+"','"+sRegisteredColumn+"')");
	//openRuleEditor(sTable,sRegisteredColumn,sScript);
}

function openRuleEditor(sTable,sColumnName)
{
	var sDialogWidth = "780px", sDialogHeight="580px";
	if(sScreenWidth>=1000) sDialogWidth = "950px", sDialogHeight="700px";
	//sValue = PopComp("RuleEditor","/Common/Configurator/RuleManage/RuleEditor.jsp","Table="+sTable+"&Column="+sColumnName,"dialogwidth:"+sDialogWidth+";dialogheight:"+sDialogHeight+";resizable:yes;");
	sValue = PopComp("RuleEditor","/Common/Configurator/RuleManage/RuleEditor.jsp","Table="+sTable+"&Column="+sColumnName,"");
	if (sValue!=null && sValue!='undefined') {
		setItemValue(0,getRow(),sColumnName,sValue);
	}
}

/**�����������ȡ����*/
function getCompAttribute(sAttributeID){
	var sReturn = PopPage("/Common/ToolsB/GetCompAttribute.jsp?AttributeID="+sAttributeID);
	return sReturn;
}

/**���Խű�*/
function testRule(sScript){
	sScript = real2Amarsoft(sScript);
	var sData = getCompAttribute("ScenarioPara");
	if(sData==null ||sData=="null" || sData=="") sData = selectObjectValue("SelectAllCBTestApply","","");
	if(typeof(sData)=="undefined" || sData==""  || sData=="_CANCEL_" || sData=="_CLEAR_" || sData=="_NONE_" ) return;
	sDatas = sData.split("@");
	
	var sScriptScenario = getCompAttribute("Scenario");
	if(sScriptScenario==null ||sScriptScenario=="null" || sScriptScenario=="") sScriptScenario = selectObjectValue("SelectAllScriptScenario","","");
	if(typeof(sScriptScenario)=="undefined" || sScriptScenario=="") return;
	if(sScriptScenario=="_CANCEL_") return;
	sScriptScenario = sScriptScenario.split("@")[0];
	
	//var sPath = RunMethod("Configurator","TestBusinessRule",sScriptScenario+",TaskNo="+sDatas[1]+","+sScript);
	var sPath = PopPage("/Common/Configurator/RuleManage/TestScript.jsp?Scenario="+sScriptScenario+"&ParaString=TaskNo="+sDatas[1]+"&Script="+sScript,"","width:0px;height:0px");
	if(typeof(sPath)=="undefined") return;
	if(sPath=="_CANCEL_") return;
	
	if(sPath.indexOf("LogID=")>=0){
		PopComp("DecisionFlow","/Common/Configurator/RuleManage/DecisionFlowDisplay.jsp","Path="+sPath);
	}else{
		alert("����ִ�еĽ��Ϊ:\n\n"+sPath);
	}
}

//���������ͻ
function checkPrimaryKey(sTable,sColumnString){
	var sParameters = "Type=PRIMARYKEY&TableName="+sTable+"";
	var sColumns=sColumnString.split("@");
	for(var i=0;i<sColumns.length;i++){
		if(i==4){
			alert("�ؼ������4��");
			return false;
		}
		sParameters+="&FieldName"+(i+1)+"="+sColumns[i];
		sParameters+="&FieldValue"+(i+1)+"="+getItemValue(0,0,sColumns[i]);
	}
	sReturnValue = PopPage("/Common/ToolsB/CheckPrimaryKeyAction.jsp?"+sParameters,"","dialogWidth=0;dialogHeight=0;center:no;status:no;statusbar:no");
	if(sReturnValue == "TRUE")
	{
		return true;
	}else{
		return false;
	}
}
/*
*   syang 2008/11/25
* 	�����־��ش���
*/
function AuditLog(){
	this.NameList = "argNameList=";
	this.ValueList = "argValueList=";
	this.asAjax = new Ajax();
	this.postArg = new Array();
	
	
	//��ʼ���������������
	this.init = function(WebRootPath,pagePath){
		//���ID��ϵͳ�������������ķ�ʽ����
		this.asAjax.setTargetPage(WebRootPath+pagePath+"?CompClientID="+sCompClientID+"&rand1="+randomNumber());
	}
	
	this.put = function(key,value){
		this.NameList += (key+"~");
		this.ValueList += (value+"~");
	}
	
	this.addLog = function(){
		this.postArg.push(this.NameList);
		this.postArg.push(this.ValueList);
		lockPage(true);
		this.asAjax.sendRequest(this.postArg);
		lockPage(false);
		this.reset();
		return ajaxReturn;
	}
	//�ָ��ص�����ǰ��״̬
	this.reset = function(){
	    OperateUserId = "";
	    OperateOrgId = "";
	    nameArray = this.NameList.split("=")[1].split("~");
	    valueArray = this.ValueList.split("=")[1].split("~");
	    
	    for(var i=0,len=nameArray.length;i<len;i++){
	    	if(nameArray[i] == "OperateUserId"){
	    		OperateUserId = valueArray[i];
	    		continue;
	    	}
	    	if(nameArray[i] == "OperateOrgId"){
	    		OperateOrgId = valueArray[i];
	    		continue;
	    	}
	    }
	    this.NameList = "argNameList=";
		this.ValueList = "argValueList=";
		this.postArg.length = 0;
	    auditLog.put("OperateUserId",OperateUserId);
	    auditLog.put("OperateOrgId",OperateOrgId);
	}
	
}

//add by syang ͨ��ajax�ύҳ��
//---------------------------------------------------------------------
function Ajax(){
}
Ajax.prototype.targetPage = "";
Ajax.prototype.setTargetPage = function (page){
	this.targetPage = page;
}
Ajax.prototype.result = "";
//����xmlHttp
Ajax.prototype.createXMLHttp = function() {

		if (typeof XMLHttpRequest != "undefined") {
			return new XMLHttpRequest();
		}else if(window.ActiveXObject){
			
			var aVersions = ["MSXML2.XMLHttp.5.0",
							 "MSXML2.XMLHttp.4.0",
							 "MSXML2.XMLHttp.3.0",
							 "MSXML2.XMLHttp",
							 "Microsoft.XMLHttp"
							];
			for (var i = 0; i < aVersions.length; i++) {
				try {
					var oXmlHttp = new ActiveXObject(aVersions[i]);
					return oXmlHttp;
					}catch (oError) {
					}
			}
		}
		throw new Error("XMLHttp object could be created.");
	}
//����
Ajax.prototype.sendRequest = function(ParamArray) {
		var page=this.targetPage;
		var sBody = this.getRequestBody(ParamArray);
		sBody = encodeURI(sBody);
		sBody = encodeURI(sBody);
		var oXmlHttp = this.createXMLHttp();
		oXmlHttp.open("post",page,false);
		oXmlHttp.setRequestHeader("cache-control","no-cache"); 
		oXmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		oXmlHttp.onreadystatechange = function () {
			if (oXmlHttp.readyState == 4) {
				if (oXmlHttp.status == 200) {
					getResult(oXmlHttp.responseText);
				}else if(oXmlHttp.status == 404){
					alert("�ļ���"+page+"δ�ҵ�");
				}else {
					alert("ϵͳ�ڲ�����" + oXmlHttp.statusText);
				}
			}
		};
		oXmlHttp.send(sBody);
	}
//���÷���Body//������ʽ��{key=value,key1=value1����}�����飩
Ajax.prototype.getRequestBody = function(ParamArray){
		var aParams = ParamArray;
		return aParams.join("&");
	}

//��ȡ����ֵ
var ajaxReturn = "";
function getResult(arg){
	var re = /(<body>)([\s\S]+)(<\/body>)/i;//ƥ��<body>�ַ���</body>
	var sResult = "";
	if(re.test(arg)){
		sResult = RegExp.$2;				//ȡ��body�е��ַ���
		sResult = sResult.replace(/\s+|\r+\n+/gi,"");//ȥ���ո񣬿���
		ajaxReturn = sResult;
	}
	//add in 2009/08/20
	return ajaxReturn;	
}

function lockPage(arg){
	element = document.getElementsByTagName("input");
	for(var i=0,len=element.length;i<len;i++){
		element[i].disabled = arg;
	}
	element = document.getElementsByTagName("select");
		for(var i=0,len=element.length;i<len;i++){
		element[i].disabled = arg;
	}
	element = document.getElementsByTagName("span");
		for(var i=0,len=element.length;i<len;i++){
		element[i].disabled = arg;
	}
}
//------------------------------------------------------------------------------------------------



	
	
	
		/*
	��;��ȥ���ַ�����߿ո���
	���룺str���ַ���
	���أ� ȥ���ո���ַ���  
	*/
	function lTrim(str){
	    var i = 0;
	        while(str.charCodeAt(i) <=32 )
	        {
	            ++i;
	        }
	        str = str.substring(i);
			return str;
	}
	
	/*
	��;��ȥ���ַ����ұ߿ո���
	���룺str���ַ���
	���أ� ȥ���ո���ַ���
	*/
	function rTrim(str){
	    var i = str.length-1;
	        while(str.charCodeAt(i) <=32)
	        {
	            --i;
	        }
	        str = str.substring(0,i+1);
			return str;
	}
	
	/*
	��;��ȥ���ַ����������߿ո���
	���룺str���ַ���
	���أ� ȥ���ո���ַ���
	*/
	function trim(str){
		return lTrim(rTrim(str));
	}
	
	/*
	��;������str1���Ƿ����str2
	���룺str1���ַ�����str2�����������ַ���
	���أ����������򷵻�str1�д�str2��һ�ַ���ʼ�������ַ��������򷵻ؿ��ַ���e��	
	*/
	function substringAfter( str1,  str2) { 
	   var index = str1.indexOf(str2);
	   if(index==-1) return "";
	   return str1.substring(index+str2.length);
	} 
	
	/*
	��;������str1���Ƿ����str2
	���룺str1���ַ�����str2�����������ַ���
	���أ����������򷵻�str1��str2ǰ�������ַ��������򷵻ؿ��ַ�����
	*/
	function substringBefore( str1,  str2) { 
	   var index = str1.indexOf(str2);
	   if(index==-1) return "";
	   return str1.substring(0,index);
	} 
	
	/*
	��;������source����str1��Str2֮�������
	���룺sSource��Դ����str1���ַ���1��str2���ַ���2
	���أ�������str1��Str2���򷵻�str1��str2����ַ��������򷵻ؿ��ַ�����
	*/
	function substringBetween(sSource, str1,  str2) { 
	   var stringAfter = substringAfter(sSource,str1);
	   var stringBetween = substringBefore(stringAfter,str2);
	   return stringBetween;
	}
	
	function parseReturnXML(sSource,segment,sVariable){
		
		var segString = substringBetween(sSource,"<"+segment+">","</"+segment+">");
		if(segString==""){
			return "";
		}else if(sVariable==null || sVariable==""){
			return segString;
		}else{
			var sValue = trim(substringBetween(segString,"<"+sVariable+">","</"+sVariable+">"))
			return sValue;
		}
	}
	
	//�ж��Ƿ��Ǻ���  add by ycsun  2007-8-22
	function isChinese(str)
	{
	   var lst = /[u00-uFF]/;
	   return !lst.test(str);
	}
	
	//�����ַ����ĳ��� add by ycsun  2007-8-22
	function strlen(str)
	{
	   var strlength=0;
	   for (i=0;i<str.length;i++)
	  {
	     if (isChinese(str.charAt(i))==true)
	        strlength=strlength + 2;
	     else
	        strlength=strlength + 1;
	  }
	return strlength;
	}
	
	//��ȫ���ַ�ת��Ϊ����ַ� add by xjzhao
	function ConvertString(str)
	{
		sReturn = '';
		for(var i = 0; i < str.length; i++)
		{
			sReturn += String.fromCharCode(str.charCodeAt(i)> 125 ? (str.charCodeAt(i)-65248) : str.charCodeAt(i));
		}
		return sReturn;
	}
	
	//add by xjzhao ��15λ����֤����ת��Ϊ18λ
	function Change15to18(sID)
	{
		var id1 = sID;
		var id2 = id1.substr(0,6)+'19'+id1.substr(6);
		var id1 = id2;
		var iTemp = 16,iJYM = 0,iTemp0 = 0;
		while(iTemp >= 0)
		{
			iTemp0 = 18 - iTemp;
			if(iTemp0 == 1)	iTemp0 = 1;
			else if(iTemp0 == 1)	iTemp0 = 1;
			else if(iTemp0 == 2)	iTemp0 = 2;
			else if(iTemp0 == 3)	iTemp0 = 4;
			else if(iTemp0 == 4)	iTemp0 = 8;
			else if(iTemp0 == 5)	iTemp0 = 5;
			else if(iTemp0 == 6)	iTemp0 = 10;
			else if(iTemp0 == 7)	iTemp0 = 9;
			else if(iTemp0 == 8)	iTemp0 = 7;
			else if(iTemp0 == 9)	iTemp0 = 3;
			else if(iTemp0 == 10)	iTemp0 = 6;
			else if(iTemp0 == 11)	iTemp0 = 1;
			else if(iTemp0 == 12)	iTemp0 = 2;
			else if(iTemp0 == 13)	iTemp0 = 4;
			else if(iTemp0 == 14)	iTemp0 = 8;
			else if(iTemp0 == 15)	iTemp0 = 5;
			else if(iTemp0 == 16)	iTemp0 = 10;
			else if(iTemp0 == 17)	iTemp0 = 9;
			else if(iTemp0 == 18)	iTemp0 = 7;
			
			iJYM = iJYM + id1.substring(iTemp,iTemp+1)*iTemp0;
			iTemp = iTemp -1;
		}
			iJYM = iJYM % 11;
			if(iJYM == 0) sJYM = "1";
			else if(iJYM == 1) sJYM = "0";
			else if(iJYM == 2) sJYM = "X";
			else if(iJYM == 3) sJYM = "9";
			else if(iJYM == 4) sJYM = "8";
			else if(iJYM == 5) sJYM = "7";
			else if(iJYM == 6) sJYM = "6";
			else if(iJYM == 7) sJYM = "5";
			else if(iJYM == 8) sJYM = "4";
			else if(iJYM == 9) sJYM = "3";
			else if(iJYM == 10) sJYM = "2";
	
			id2 = id2+sJYM;
			
			return id2;
	}
	
	//add by xjzhao ��18λ����֤����ת��Ϊ15λ
	function Change18to15(sID)
	{
		var id1 = sID;
		var id2 = id1.substr(0,6)+id1.substring(8,17);
		var id1 = id2;
		return id1;
	}
	
	//����֤ת��
	function ConvertID(sCertType,sCertID)
	{
		if(typeof(sCertType) == "undefined" || sCertType.length == 0
		|| typeof(sCertID) == "undefined" || sCertID.length == 0)
		{
			return "";
		}
		
		sCertID = ConvertString(sCertID);
		//�ж�����֤�Ϸ���,��������֤����Ӧ����15��18λ��
		if(sCertType == 'Ind01' || sCertType =='Ind08')
		{
			if (!CheckLisince(sCertID))
			{
				return "";
			}
			else
			{
				if(sCertID.length == 15)
				{
					var sCertIDValue = Change15to18(sCertID)
					return sCertIDValue;
				}
				else if(sCertID.length == 18)
				{
					var sCertIDValue = Change18to15(sCertID)
					return sCertIDValue;
				}
			}
		}
		return "";
	}