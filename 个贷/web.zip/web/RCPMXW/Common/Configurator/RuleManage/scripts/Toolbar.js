// unselectable ='no' update
// toolbars object
var objToolbars = new Toolbars("toolbar");

// toolbars
var __count = 100;
var __aAllComponents = new Array();
var __aAllComponentsTag = new Array();
var __aAllTagComponents = new Array();
// all popup iframes
var __aAllPopups = new Array();
var __hasCancel    = false;
var __isMode       = "";


//---------------------------------------------------------------------------------------------
// TOOLBARS Object
//---------------------------------------------------------------------------------------------
function Toolbars(containerid)
{
  this.aToolbars = new Array();
  this.container = containerid;
  this.backcolor = "";
  this.language  = "EN";
  
  this.add           = __toolbars_add;
  this.create        = __toolbars_create;
  this.clear         = __toolbars_clear;
  this.getComponents = __toolbars_getcomponents;
//  this.getTagComponents = __toolbars_gettagcomponents;
  this.reset         = __toolbars_reset;
  this.hide          = __toolbars_hide;
  this.show          = __toolbars_show;
  this.__getStatus   = __toolbars_getstatus;

  this.createToolbar     = __toolbars_create_toolbar;
  this.createLabel       = __toolbars_create_label;
  this.createButton      = __toolbars_create_button;
  this.createCheckButton = __toolbars_create_checkbutton;
  this.createMenuButton  = __toolbars_create_menubutton;
  this.createMenuItem    = __toolbars_create_menuitem;
  this.createColorButton = __toolbars_create_colorbutton;
  this.createPopupButton = __toolbars_create_popupbutton;
  this.createCombo       = __toolbars_create_combo;
  this.createStyleCombo  = __toolbars_create_stylecombo;
  this.createStyleComboItem = __toolbars_create_stylecomboitem;
  this.createInput       = __toolbars_create_input;
  this.createSeparator   = __toolbars_create_separator;
  this.createDistance    = __toolbars_create_distance;
  
  this.getElementById    = __toolbars_getobject;
  this.getElementByTag   = __toolbars_getobjecttag;
  
  // get an event if mouse is pressed
  document.onmousedown = __toolbars_mousedown;
}

function __toolbars_mousedown()
{
	objToolbars.reset();
}

function __toolbars_getstatus()
{
	var status = "";

	for(var i=0;i<__aAllComponents.length;i++) {
		var item = __aAllComponents[i];
		if(item.typeIntern == "CHECKBUTTON") {
			status = status + item.tag + ":" + (item.pressed ? "1" : "0") + ";";
		}
		if(item.typeIntern == "MENUBUTTON") {
			status = status + item.tag + ":" + item.selectedItem.tag2 + ";";
		}
		if(item.typeIntern == "STYLECOMBO") {
			status = status + item.tag + ":" + item.selectedItem.tag2 + ";";
		}
		if(item.typeIntern == "COLORSELECTOR") {
			status = status + item.tag + ":" + item.color + ";";
		}
		if(item.typeIntern == "INPUT") {
			status = status + item.tag + ":" + item.getText() + ";";
		}
		if(item.typeIntern == "POPUPBUTTON") {
			status = status + item.tag + ":" + item.value + ";";
		}
	}	
	return status;
}

function __toolbars_getobject(id)
{
	for(var i=0;i<__aAllComponents.length;i++) {
		if(__aAllComponents[i].id == id)
			return __aAllComponents[i];
	}	
}

function __toolbars_getobjecttag(tag)
{
/*
	for(var i=0;i<__aAllComponents.length;i++) {
		if(__aAllComponents[i].tag == tag)
			return __aAllComponents[i];
	}	
*/
	return __aAllComponentsTag[tag];
}

function __toolbars_create_toolbar()
{
	return new Toolbar();
}

function __toolbars_create_label(text)
{
	return new Label(text);
}

function __toolbars_create_button(text,image,action,tooltip,tag)
{
	return new Button(text,image,action,tooltip,tag);
}

function __toolbars_create_checkbutton(text,image,action,tooltip,tag,status,group)
{
	return new CheckButton(text,image,action,tooltip,tag,status,group);
}

function __toolbars_create_menubutton(text,image,image2,action,tooltip,tooltip2,tag)
{
	return new MenuButton(text,image,image2,action,tooltip,tooltip2,tag);
}

function __toolbars_create_menuitem(text,image,title,value,tag1,tag2)
{
	return new ComboItem(text,image,title,value,tag1,tag2);
}

function __toolbars_create_colorbutton(image,image2,action,tooltip,tooltip2,tag,color)
{
	return new ColorSelector(image,image2,action,tooltip,tooltip2,tag,color);
}

function __toolbars_create_popupbutton(text,image,action,tooltip,tag,page)
{
	return new PopupButton(text,image,action,tooltip,tag,page);
}

function __toolbars_create_combo(action)
{
	return new Combo(action);
}

function __toolbars_create_stylecombo(action,tooltip,tag)
{
	return new StyleCombo(action,tooltip,tag);
}

function __toolbars_create_stylecomboitem(text,image,title,value,tag1,tag2)
{
	return new ComboItem(text,image,title,value,tag1,tag2);
}

function __toolbars_create_input(width,value,action,tag)
{
	return new Input(width,value,action,tag);
}

function __toolbars_create_separator(image)
{
	return new Separator(image)
}

function __toolbars_create_distance(width, useBackground)
{
	return new Distance(width, useBackground)
}

function __toolbars_getcomponents()
{
  return __aAllComponents;
}

//function __toolbars_gettagcomponents()
//{
//  return __aAllTagComponents;
//}

function __toolbars_clear()
{
  this.aToolbars = new Array();
}

function __toolbars_add(toolbar)
{
  var id = this.aToolbars.length;
  this.aToolbars[id] = toolbar;
  toolbar.id = __count;
  __count++;
  // set background color autom.
	if(this.backcolor == "") {
			this.backcolor = "#E8E8F0";
	}
}

function __toolbars_create()
{
  var temp = "";
  var temp1 = "<div unselectable='on' id='" + this.container + "_v" + "' style='width: 100%;height:";
  var temp2 = "px;background-color: " + this.backcolor + "'>";
  var height = 0;

  // get code for all toolbars
  for (var i=0;i<this.aToolbars.length;i++) {
    var toolbar = this.aToolbars[i];
    // calculate the height
    height = height + toolbar.height;
    temp+="<table unselectable='on' id='" + toolbar.id + "' class='htmlToolbarOut' width='100%' cellpadding=0 cellspacing=0 border=0><tr unselectable='on'><td unselectable='on'>";
    if(toolbar.fullsize)
      temp+="<table unselectable='on' style='width:100%;"
    else
      temp+="<table unselectable='on' style='width:1%;"
    if(!toolbar.border) {
      temp+= "border: 0";
    }
    temp+= "' class='htmlToolbarIn'  cellpadding=0 cellspacing=0 border=0><tr unselectable='on'>";
    for (var j=0;j<toolbar.aComponents.length;j++) {
      var component = toolbar.aComponents[j];
      var html = component.create();
      temp+=html;
    }
    var eva = "";

    if(!__hasCancel) {
      if( (i == 0 && __isMode == "I")  ) {
        eva = "<a href='javascript: editCancel()'><img src='"+this.design+"close.gif' border=0></a>";
        __hasCancel = true;
      }
    }
    temp+="</tr></table>";
    if(toolbar.fullsize)
      temp+="</td><td unselectable='on'></td></tr></table>";
    else
      temp+="</td><td  unselectable='on'  onclick='objToolbars.reset();' style='border:0;width=100%' align='right'>" + eva + "</td></tr></table>";
  }
  temp+="</div>";
  // write html code in div
  var objContainer = document.getElementById(this.container);
  objContainer.innerHTML = temp1 + height + temp2 + temp;
//alert(objContainer.innerHTML)
}

function __toolbars_reset()
{
  try {
    for (var i=0;i<__aAllPopups.length;i++) {
      var popup = __aAllPopups[i];
      popup.init();
    }
  } catch(Error) {}
}

function __toolbars_hide()
{
  try {
    if(browser.ns6)
      document.getElementById(this.container + "_v").style.visibility = 'hidden';
    else
      document.getElementById(this.container + "_v").style.display = 'none';
  } catch(Error) {}
}

function __toolbars_show()
{
  if(browser.ns6)
    document.getElementById(this.container + "_v").style.visibility = 'visible';
  else
    document.getElementById(this.container + "_v").style.display = 'inline';
}

//---------------------------------------------------------------------------------------------
// TOOLBAR Object
//---------------------------------------------------------------------------------------------
function Toolbar()
{
  this.id     = "";
  this.height = 27;
  this.border = false;
  this.action = "";
  this.design = "";
  this.fullsize = false;
  this.visible = true;

  this.aComponents = new Array();
  this.add         = __toolbar_add;
  this.setVisible  = __toolbar_setvisible;
}

function __toolbar_add(component)
{
  var id = this.aComponents.length;
  this.aComponents[id] = component;
  component.id = __count;
  component.toolbar = this;
  component.design = this.design;
  __count++;

  // we ned this for access within events
  var id = __aAllComponents.length;
  __aAllComponents[id] = component;

  // optimization so that only the buttons with tag are set
  if(component.tag) {
    __aAllComponentsTag[component.tag] = component;
  }

  //var id = __aAllTagComponents.length;
  //if(component.tag) {
  //  __aAllTagComponents[id] = component;
  //}
}

function __toolbar_setvisible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}




//---------------------------------------------------------------------------------------------
// CHECKBUTTON Object
//---------------------------------------------------------------------------------------------
function CheckButton(text,image,action,tooltip,tag,status,group)
{
	var button = new Button(text,image,action,tooltip,tag);
	button.type = "C";
	if(status)
		button.pressed = true;
	button.group = group;
  button.typeIntern = "CHECKBUTTON";
	return button;
}

//---------------------------------------------------------------------------------------------
// BUTTON Object
//---------------------------------------------------------------------------------------------
function Button(text,image,action,tooltip,tag)
{
  this.id      = "";
  //this.width   = width;
  this.toolbar = null;
  this.tag     = tag;
  this.text    = text;
  this.action  = action;
  this.image   = image;
  this.group   = "";
	this.type    = "S";
  this.typeIntern = "BUTTON";
  this.gate       = false;

  // try to cache the image
  //this.imageObj = new Image();
  //this.imageObj.src = image;

  this.tooltip = tooltip;
  this.design  = "";
  this.pressed = false;
  this.enabled = true;
  this.visible = true;
	// "parent." is used
  this.useparent = false;

  this.setVisible   = __button_visible;
  this.setEnabled   = __button_enable;
  this.setStatus    = __button_status;
  this.setImage     = __button_setimage;

  this.onmouseup    = __button_mouseup;
  this.onmousedown  = __button_mousedown;
  this.onmouseover  = __button_mouseover;
  this.onmouseout   = __button_mouseout;

  // MDEARMAN - 04-06-2004 - Added for keyboard accessibility
  this.onfocus  = __button_focus;
  this.onblur   = __button_blur;
  this.onclick  = __button_click;

  this.create       = __button_create;
}

function __button_direct(id,action)
{
	try {
		for (var j=0;j<__aAllComponents.length;j++) {
			if(__aAllComponents[j].id == id){
				var component = __aAllComponents[j];

				if(component.enabled) {
					if(action == "OVER")
						component.onmouseover();
					if(action == "OUT")
						component.onmouseout();
					if(action == "DOWN")
						component.onmousedown();
					if(action == "UP") {
						component.onmouseup();
						if(component.toolbar.action != "") {
							//if(component.tag != "" && component.tag != null) {
								eval(component.toolbar.action + "('" + component.id + "')");
							//}
						}
					}
					// MDEARMAN 04-06-2004 - Added for keyboard accessibility
					else if(action == "FOCUS")
						component.onfocus();
					else if(action == "BLUR")
						component.onblur();
					else if(action == "CLICK")
						component.onclick();
					return;
				}
			}
		}
	} catch(Error) {}
}

function __button_create()
{
  var temp = "<td id='" + this.id + "_v'";

  if(this.width != "")
    temp+= " width='" + this.width + "'";
  temp+= "><table style='width:100%' cellspacing=1 cellpadding=0 border=0><tr>";
  temp+= "<td align='center'";
  if(this.width != "")
    temp+= " width='" + this.width + "'";
  temp+= " nowrap id='" + this.id + "' ";
	if(!this.pressed)
		temp+= "class='htmlButtonStandard' ";
	else
		temp+= "class='htmlButtonActive' ";
  temp+= "onmouseover='__button_direct(" + this.id + ",\"OVER\")'";
  temp+= "onmouseout='__button_direct(" + this.id + ",\"OUT\")'";
  temp+= "onmousedown='__button_direct(" + this.id + ",\"DOWN\")'";
  temp+= "onmouseup='__button_direct(" + this.id + ",\"UP\")'";

	// MDEARMAN 04-06-2004 - Added for keyboard accessibility
  temp+= "onfocus='__button_direct(" + this.id + ",\"FOCUS\")' ";
  temp+= "onblur='__button_direct(" + this.id + ",\"BLUR\")' ";
  temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __button_direct(" + this.id + ",\"CLICK\")' ";
  temp+= "tabindex='1' ";
  temp+= "title='" + this.tooltip + "' ";

  temp+= ">";

  if(this.image) {
    this.imageid = this.id + "_image";
    temp+= "<img  unselectable='on' id='" + this.imageid + "' title='" + this.tooltip + "' align='absmiddle' border='0' src='" +  this.image + "'>";
  }
  if(this.text) {
    if(this.enabled)
      temp+= "<span id='" + this.id + "_text' style='vertical-align: middle; height:16px; margin-left: 2px;margin-right: 2px;' unselectable='on'> " + this.text + "</span>";
    else
      temp+= "<span id='" + this.id + "_text' style='vertical-align: middle; height:16px; margin-left: 2px;margin-right: 2px;color:gray' unselectable='on'> " + this.text + "</span>";
  }
  temp+= "</td></tr></table></td>";
  return temp;
}

function __button_visible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __button_enable(value)
{
  this.enabled = value;
  if(value)
		document.getElementById(this.id + "_text").style.color = "black";
  else
		document.getElementById(this.id + "_text").style.color = "gray";
/*
  var button = document.getElementById(this.id);
  if(value) {
    button.className = 'htmlButtonDisabled';
    button.innerHTML = "<span class='htmlButtonDisabledContainer'><span class='htmlButtonDisabledContainer'>" + button.innerHTML + "</span></span>";
  } else {
    button.className = 'htmlButtonStandard';
    button.innerHTML = button.firstChild.firstChild.innerHTML;
  }
 */
}

function __button_status(value)
{
  if(this.pressed == value)
    return;

  this.pressed = value;
  if(value) {
    document.getElementById(this.id).className='htmlButtonActive';
  } else {
    document.getElementById(this.id).className='htmlButtonStandard';
  }
}

function __button_setimage(image)
{
  this.image = image;
  document.getElementById(this.imageid).src = image;
}


function __button_mouseup()
{
  if(!this.enabled)
    return;

	//try {
		// check if button is member of a group
		if(this.type == "C") {
			if(this.gate) {
				this.gate = false;
			} else {
				if(this.pressed) {
					if(this.group == "") {
						this.pressed = false;
						document.getElementById(this.id).className='htmlButtonStandard';
					}
				} 
			}
			if(this.pressed) {
				// release all others in group
				for(var i=0; i<__aAllComponents.length;i++) {
					var button = __aAllComponents[i];
					if(button.id != this.id && this.group != "" && button.type == "C" && button.group == this.group && button.pressed) {
						button.setStatus(false);
						break;
					}
				} 		
			}
		} else {
			document.getElementById(this.id).className='htmlButtonHover';
		}
		if(this.action != "") {
			if(this.useparent)
				eval("parent." + this.action + "('" + this.id + "')");
			else
				eval(this.action + "('" + this.id + "')");
		}
//	} catch(Error) {}
}

function __button_mousedown()
{
  __toolbars_reset();
  if(!this.enabled)
    return;
	if(this.type == "C") {
		if(!this.pressed){
		  document.getElementById(this.id).className='htmlButtonActive';
		  this.pressed = true;
		  this.gate = true;
		}
	} else {
	  document.getElementById(this.id).className='htmlButtonActive';
	}
}

function __button_mouseover()
{
  if(!this.enabled)
    return;
	if(!this.pressed) 
	  document.getElementById(this.id).className='htmlButtonHover';
}

function __button_mouseout()
{
  if(!this.enabled)
    return;
  if(this.pressed == false)
    document.getElementById(this.id).className='htmlButtonStandard';
  else
    document.getElementById(this.id).className='htmlButtonActive';
}

// MDEARMAN 04-06-2004 - Added for keyboard accessibility
function __button_focus()
{

window.status = "focus";

	this.onmouseover();
}

function __button_blur()
{
window.status = "blur";

	this.onmouseout();
}

function __button_click()
{
window.status = "click";

	try {
		this.onmousedown();
		this.onmouseup();

		if (this.toolbar.action != "") {
			if (this.tag != "" && this.tag != null)
			eval( this.toolbar.action + "('" + this.id + "')");
		}
	} catch(Error) {}
}



//---------------------------------------------------------------------------------------------
// Combo Object
//---------------------------------------------------------------------------------------------
function Combo(action)
{
  this.id = "";
  this.action = action;
  this.visible = true;
  this.typeIntern = "COMBO";

  this.setSelected = __combo_setselected;
  this.getSelected = __combo_getselected;

  this.clear           = __combo_clear;
  this.setSelectedText = __combo_settext;
  this.create          = __combo_create;
  this.add             = __combo_add;
  this.setVisible      = __combo_setvisible;
}

function __combo_setvisible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __combo_create()
{
  var temp = "<td id='" + this.id + "_v" + "' style='padding-left: 2px'><select id='" + this.id + "' class='htmlCombo' onchange=\"javascript: __combo_direct(" + this.id + ")\"></select></td>";
  return temp;
}

function __combo_clear()
{
  var combo = document.getElementById(this.id);
  while(combo.length) {
    combo.remove(0);
  }
}

function __combo_settext(value)
{
  var combo = document.getElementById(this.id);
  len = combo.length;
  for(var i=0;i<len;i++) {
    if(combo.options[i].value == value) {
      combo.selectedIndex = i;
      break;
    }
  }
}

function __combo_add(value,key)
{
  var combo = document.getElementById(this.id);
  var item = document.createElement("option");
  item.text = value;
  item.value = key;
  if(browser.ie) {
    combo.add(item);
  } else {
    combo.add(item,null);
  }
}
function __combo_getselected()
{
  var temp = "";
  try {
    var combo = document.getElementById(this.id);
    temp = combo.options[combo.selectedIndex].value;
  } catch(Error){}
  return temp;
}
function __combo_setselected(value)
{
  var temp = "";
  try {
    var combo = document.getElementById(this.id);
    len = combo.length;
    for(var i=0;i<len;i++) {
      if(combo.options[i].value == value) {
        combo.selectedIndex = i;
        break;
      }
    }
  } catch(Error){}
}
function __combo_direct(id)
{
	try {
		for (var j=0;j<__aAllComponents.length;j++) {
			if(__aAllComponents[j].id == id){
				var component = __aAllComponents[j];
				if(component.action != "") {
					eval(component.action + "('" + component.tag + "')");
				}
				return;
			}
		}
	} catch(Error) {}
}

//---------------------------------------------------------------------------------------------
// Separator Object
//---------------------------------------------------------------------------------------------
function Separator(image)
{
  this.image   = image;
  this.create  = __separator_create;
  this.design  = "";
  this.typeIntern = "SEPARATOR";
}

function __separator_create()
{
  //var temp = "<td class='htmlButtonStandard'><img border='0' src='" +  this.image + "'></td>";
  var temp = "<td><img border='0' src='" +  this.image + "'></td>";
  return temp;
}

//---------------------------------------------------------------------------------------------
// Distance Object
//---------------------------------------------------------------------------------------------
function Distance(width,useBackground)
{
  this.width   = width;
  this.create  = __distance_create;
  this.design  = "";
  this.background  = useBackground;
  this.typeIntern = "DISTANCE";
}

function __distance_create()
{
  var temp = "";
  if(this.background)
    temp = "<td class='htmlToolbarDistance'><div style='width:" + this.width + "px'></div></td>";
  else
    temp = "<td><div style='width:" + this.width + "px'></div></td>";
  return temp;
}

// MDEARMAN 04-06-2004 - End of keyboard accessibility functions




//-----------------------------------------------------------------------------------------------------
// STYLE COMBO
//-----------------------------------------------------------------------------------------------------
var __scombo_clicked;

function StyleCombo(action,tooltip,tag)
{
  this.id      = "";
  this.width   = "100px";
  this.popupwidth   = "100px";
  this.popupheight  = "";
  this.toolbar = null;
  this.action  = action;
  this.tag     = tag;
  this.tooltip = tooltip;
  this.design  = "";
  this.enabled = true;
  this.visible = true;
	this.selectedIndex = 0;
  this.selectedItem = null;
  this.typeIntern = "STYLECOMBO";
  // id of combo text. Needed for changes
  this.textid  = "";
  // name of property like "tag1". This value is displayed as combo text
  this.displayValue = null;
  // all combo items
  this.aItems = new Array();
  // define new menu
  this.menu = new Menu("__scombo_item_click");
  // no image col
  this.menu.imageColumn = false;
  // the callback from htmlMenu.html
  this.menu.callbackInternal = "__style_combo_callback";
  //this.menu.callback = action;
  // is a popup
  this.menu.isPopupMode = true;

  this.setVisible   = __scombo_visible;
  this.setEnabled   = __scombo_enable;
  this.setStatus    = __scombo_status;

  this.onmouseup    = __scombo_mouseup;
  this.onmousedown  = __scombo_mousedown;
  this.onmouseover  = __scombo_mouseover;
  this.onmouseout   = __scombo_mouseout;

  this.create       = __scombo_create;
  this.add          = __scombo_add;
  this.setSelected  = __scombo_setselected;
  this.setSelectedText  = __scombo_setselected_text;
  this.setSelectedIndex  = __scombo_setselectedindex;
  this.getSelected  = __scombo_getselected;
  this.init         = __scombo_init;
  this.clear        = __scombo_clear;
  this.getItemByValue = __scombo_getbyvalue;
  this.setVisible   = __scombo_setvisible;
}

function __scombo_setvisible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __scombo_getbyvalue(value)
{
  for(var i=0; i<this.aItems.length;i++) {
    var item = this.aItems[i];
    if(item.value.toUpperCase() == value)
      return item;
  }
}

function __scombo_init()
{
  try {
		var popup = __toolbar_getPopupObject();
    if(popup.style.visibility != "hidden") {
      popup.style.visibility = "hidden";
    }
    document.getElementById(this.id).className='htmlComboStandard';
    this.pressed = false;
  } catch(Error) {}
}

function __scombo_clear()
{
  this.aItems = new Array();
}

function __scombo_setselected_text(value)
{
  for(var i=0;i<this.aItems.length;i++) {
    var item = this.aItems[i];
    if(value.toUpperCase() == item.value.toUpperCase()) {
      this.setSelected(item);
      break;
    }
  }
}

function __scombo_getselected()
{
  return this.selectedItem;
}

function __scombo_setselected(item)
{
	try {
		var text = (this.displayValue != null) ? eval("item." + this.displayValue):item.text;
		if(document.getElementById(this.textid).innerHTML != text) {
			document.getElementById(this.textid).innerHTML = text;
		}
		this.selectedItem = item;
	} catch(Error) {}
}

function __scombo_setselectedindex(index)
{
  for(var i=0;i<this.aItems.length;i++) {
    var item = this.aItems[i];
    if(i == index) {
      this.setSelected(item);
      break;
    }
  }
}

function __scombo_add(item)
{
  var id = this.aItems.length;
  this.aItems[id] = item;
  item.id = __count;
  item.parent = this;
  __count++;
}

function __style_combo_callback(id)
{
	try {
		var item = __scombo_clicked.menu.getItemById(id);
		__scombo_clicked.setSelected(item);
		__scombo_clicked.init();
		if(__scombo_clicked.action != "") {
			//eval("parent." + __scombo_clicked.action + "(\"" + item.text + "\",\"" + item.value + "\",\"" + item.tag1 + "\",\"" + item.tag2 + "\")" );
			eval(__scombo_clicked.action + "(\"" + __scombo_clicked.id + "\")" );
		}
	} catch(Error) {}
}

function __scombo_direct(id,action)
{
  for (var j=0;j<__aAllComponents.length;j++) {
    if(__aAllComponents[j].id == id){
      var component = __aAllComponents[j];
      if(action == "OVER")
        component.onmouseover();
      if(action == "OUT")
        component.onmouseout();
      if(action == "DOWN") {
        // get the position
        var tablepopup = __toolbar_getPopupObject(); //document.getElementById("__stylepopup" + component.id);
        var obj = document.getElementById(id);
        var x = __toolbar_GetPositonX(obj);
        var y = __toolbar_GetPositonY(obj);
        tablepopup.style.left = x;
        tablepopup.style.top = y + obj.offsetHeight;
        // save the current button
        __scombo_clicked = component;
        component.onmousedown();
      }
      if(action == "UP") {
        component.onmouseup();
      }
      return;
    }
  }
}

function __scombo_popup_click(tag)
{
	try {
		__scombo_clicked.init();
		if(__scombo_clicked.action != "") {
			eval(__scombo_clicked.action + "('" + tag + "')");
		}
	} catch(Error) {}
}

function __scombo_create()
{
  var text = "";
  var temp2 = "";

	try {
		// set design because we don't have it after add
		this.menu.design = this.design;

		if(this.aItems.length == 0)
			text = "";
		else
			text = (this.displayValue != null) ? eval("this.aItems[this.selectedIndex]." + this.displayValue):this.aItems[this.selectedIndex].text;
		var temp = "<td id='" + this.id + "_v" + "'><table style='width:" + this.width + "' title='" + this.tooltip + "' cellspacing=0 cellpadding=0 border=0 id='" + this.id + "' ";
		temp+= " class='htmlComboStandard' ";
		temp+= " onmouseover='__scombo_direct(" + this.id + ",\"OVER\")'";
		temp+= " onmouseout='__scombo_direct(" + this.id + ",\"OUT\")'";
		temp+= " onmousedown='__scombo_direct(" + this.id + ",\"DOWN\")'";
		temp+= " onmouseup='__scombo_direct(" + this.id + ",\"UP\")'";
		temp+= ">";
		temp+= "<tr><td width='100%' nowrap>";
		temp+= "<span id='" + this.id + "_text' style='padding-left:3px;padding-right:3px;' unselectable='on'>" + text + "</span>";
		temp+= "</td><td>";
		temp+= "<img unselectable='on' id='__image' title='" + this.tooltip + "' align='absmiddle' border='0' src='"+this.design+"combo_arrow.gif'>";
		temp+= "</td></tr></table></td>";

		if(__toolbar_getPopupObject() == null) {
			var iframe = document.createElement("iframe");
			iframe.id           = "__toolbar_popup";
			iframe.style.position = "absolute";
			iframe.style.visibility = "hidden";
			iframe.frameBorder = 0;
			iframe.unselectable = "on";
			iframe.style.zIndex = 10000;
			document.body.appendChild(iframe);
		}

		// define container
		this.menu.id = "__toolbar_popup"; //"__stylepopup" + this.id;
		// define text id
		this.textid = this.id + "_text";
		// set selection
		this.selectedItem = this.aItems[this.selectedIndex];

		// add the id to the popup collection
		var count = __aAllPopups.length;
		__aAllPopups[count] = this;      //"__scombo_popup_cancel('" + this.id + "')";
	} catch(Error) {}
  return temp;
}

function __scombo_visible(value)
{
  this.visible = value;
}

function __scombo_enable(value)
{
  this.enabled = value;
  var button = document.getElementById(this.id);
  if(value) {
    button.className = 'htmlButtonDisabled';
    button.innerHTML = "<span class='htmlButtonDisabledContainer'><span class='htmlButtonDisabledContainer'>" + button.innerHTML + "</span></span>";
  } else {
    button.className = 'htmlButtonStandard';
    button.innerHTML = button.firstChild.firstChild.innerHTML;
  }
}

function __scombo_status(value)
{
  this.pressed = value;
  if(value) {
    document.getElementById(this.id).className='htmlComboPopup';
  } else {
    document.getElementById(this.id).className='htmlComboStandard';
  }
}

function __scombo_mouseup()
{
  if(!this.enabled)
    return;
}

function __scombo_mousedown()
{
//  __toolbars_reset();

  if(!this.enabled)
    return;

  if(!this.pressed) {
    __toolbars_reset();
    // create menu
    this.menu.clear();
    for(i=0;i<this.aItems.length;i++) {
      var item = this.aItems[i];
      this.menu.add(new MenuItem(item.text,item.image,item.title,item.value,item.tag1,item.tag2));
    }
    document.getElementById(this.id).className='htmlComboPopup';
    //document.getElementById("__stylepopup" + this.id).style.visibility = "visible";
    var popup = __toolbar_getPopupObject();
		popup.style.width  = this.popupwidth;
		popup.style.height = this.popupheight;
		popup.style.border = "1px solid #002E96";

		// add content
		var doc = popup.contentWindow.document;
		doc.open();
		doc.write(__toolbar_getMenuCode());
		doc.close();

		var html = this.menu.create(30);
		popup.style.height = this.menu.height;
		if(browser.ie) {
			doc.body.style.overflow = "auto";
			doc.body.innerHTML = html;
	    doc.body.style.backgroundColor = "white";
	    popup.style.visibility = "visible";
		} else {
			__toolbar_temp_doc = doc;
			__toolbar_temp_html = html;
			__toolbar_temp_color = "white";
			setTimeout("__toolbar_delay_moz()",50);
		}

    // set the height if not greater than specified
    var height;
    if(parseInt(this.menu.height) > parseInt(this.popupheight))
      height = this.popupheight;
    else
      height = this.menu.height;
    //document.getElementById("__stylepopup" + this.id).style.height = height;
    popup.style.height = height;

    this.pressed = true;
  } else {
    __toolbars_reset();
    this.pressed = false;
  }
}

function __scombo_mouseover()
{
  if(!this.enabled)
    return;

  if(this.pressed)
    document.getElementById(this.id).className='htmlComboPopup';
  else
    document.getElementById(this.id).className='htmlComboHover';
}

function __scombo_mouseout()
{
  if(!this.enabled)
    return;

  if(!this.pressed)
    document.getElementById(this.id).className='htmlComboStandard';
  else
    document.getElementById(this.id).className='htmlComboPopup';
}

function ComboItem(text,image,title,value,tag1,tag2)
{
  this.id      = "";
  this.parent  = "";
  this.text    = text;
  this.image   = image;
  this.title   = title;
  this.value   = value;
  if(tag1)
    this.tag1    = tag1;
  else
    this.tag1    = "";
  if(tag2)
    this.tag2    = tag2;
  else
    this.tag2    = "";
  this.typeIntern = "COMBOITEM";
}





//--------------------------------------------------------------------------------------------------
// COLOR Selector
//--------------------------------------------------------------------------------------------------
var __csbutton_clicked;
function ColorSelector(image,image2,action,tooltip,tooltip2,tag,color)
{
  this.id      = "";
  this.toolbar = null;
  this.action  = action;
  this.tag     = tag;
  this.image   = image;
  this.image2   = image2;
  this.tooltip = tooltip;
  this.tooltip2 = tooltip2;
  this.color   = "red";
  if(color)
		this.color   = color;
  this.design  = "";
  this.pressed = false;
  this.enabled = true;
  this.visible = true;
  this.typeIntern = "COLORSELECTOR";

  this.setVisible   = __csbutton_visible;
  this.setEnabled   = __csbutton_enable;

  this.onmouseup    = __csbutton_mouseup;
  this.onmousedown  = __csbutton_mousedown;
  this.onmouseover  = __csbutton_mouseover;
  this.onmouseout   = __csbutton_mouseout;

  // MDEARMAN - 04-06-2004 - Added for keyboard accessibility
  this.onfocus  = __csbutton_focus;
  this.onblur   = __csbutton_blur;
  this.onclick  = __csbutton_click;

  this.create       = __csbutton_create;
  this.init         = __csbutton_init;
}

function __csbutton_init()
{
  try {
		var popup = __toolbar_getPopupObject();
    if(popup.style.visibility != "hidden") {
      popup.style.visibility = "hidden";
      //__csbutton_clicked.onmouseup();
    }
    document.getElementById(this.id + "_1").className='htmlButtonStandard';
    this.pressed = false;
  } catch(Error) {}
}

function __csbutton_direct(id,action,part)
{
  for (var j=0;j<__aAllComponents.length;j++) {
    if(__aAllComponents[j].id == id){
      var component = __aAllComponents[j];
      if(action == "OVER")
        component.onmouseover(part);
      else if(action == "OUT")
        component.onmouseout(part);
      else if(action == "DOWN") {
        if(part==1) {
          // get the position
          var popup = __toolbar_getPopupObject(); //document.getElementById("__cspopup" + id);
          var obj = document.getElementById(id);
          var x = __toolbar_GetPositonX(obj) - 2;
          var y = __toolbar_GetPositonY(obj);
          popup.style.left = x;
          popup.style.top = y + obj.offsetHeight;
          // save the current button
          __csbutton_clicked = component;
        }
        component.onmousedown(part);
      }
      else if(action == "UP") {
        component.onmouseup(part);
      }
			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			else if(action == "FOCUS")
				component.onfocus(part);
			else if(action == "BLUR")
				component.onblur(part);
			else if(action == "CLICK") {
        if(part==1) {
          // get the position
          var popup = __toolbar_getPopupObject();
          var obj = document.getElementById(id);
          var x = __toolbar_GetPositonX(obj);
          var y = __toolbar_GetPositonY(obj);
          popup.style.left = x;
          popup.style.top = y + obj.offsetHeight;
          // save the current button
          __csbutton_clicked = component;
        }
        component.onmousedown(part);
      }
      return;
    }
  }
}

function __csbutton_popup_click(color)
{
	try {
		__csbutton_clicked.init();
		if(color != "") {
			if(color == "NOCOLOR") {
				document.getElementById("__color" + __csbutton_clicked.id).style.backgroundColor = "black";
				__csbutton_clicked.color = "";
			} else {
				document.getElementById("__color" + __csbutton_clicked.id).style.backgroundColor = color;
				__csbutton_clicked.color = color;
			}
			if(__csbutton_clicked.action != "") {
				eval(__csbutton_clicked.action + "('" + __csbutton_clicked.id + "')");
			}
		}
	} catch(Error) {}
}

function __csbutton_create()
{
  var iframe = null;
  
  var temp = "<td id='" + this.id + "_v" + "'><table cellspacing=1 cellpadding=0 border=0><tr><td nowrap id='" + this.id + "' ";
      temp+= "class='htmlButtonStandard' ";
      temp+= "onmouseover='__csbutton_direct(" + this.id + ",\"OVER\",0)'";
      temp+= "onmouseout='__csbutton_direct(" + this.id + ",\"OUT\",0)'";
      temp+= "onmousedown='__csbutton_direct(" + this.id + ",\"DOWN\",0)'";
      temp+= "onmouseup='__csbutton_direct(" + this.id + ",\"UP\",0)'";

			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			temp+= "onfocus='__csbutton_direct(" + this.id + ",\"FOCUS\", 0)' ";
			temp+= "onblur='__csbutton_direct(" + this.id + ",\"BLUR\", 0)' ";
			temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __csbutton_direct(" + this.id + ",\"CLICK\", 0)' ";
			temp+= "tabindex='1' ";
			temp+= "title='" + this.tooltip + "' ";

      temp+= ">";
  if(this.image)
    temp+= "<img id='__image" + this.id + "' title='" + this.tooltip + "' align='absmiddle' border='0' src='" +  this.image + "'>";
  if(this.text)
    temp+= " " + this.text;
  temp+= "<br><div id='__color" + this.id + "' style='font-family: Arial;font-size:3px;width:16px;height:4px;background-color:" + this.color + ";'></div>";
  temp+= "</td>";

  temp+= "<td nowrap id='" + this.id + "_1" + "' ";
  temp+= "class='htmlButtonStandard' ";
  temp+= "onmouseover='__csbutton_direct(" + this.id + ",\"OVER\",1)'";
  temp+= "onmouseout='__csbutton_direct(" + this.id + ",\"OUT\",1)'";
  temp+= "onmousedown='__csbutton_direct(" + this.id + ",\"DOWN\",1)'";
  temp+= "onmouseup='__csbutton_direct(" + this.id + ",\"UP\",1)'";

	// MDEARMAN 04-06-2004 - Added for keyboard accessibility
	temp+= "onfocus='__csbutton_direct(" + this.id + ",\"FOCUS\", 1)' ";
	temp+= "onblur='__csbutton_direct(" + this.id + ",\"BLUR\", 1)' ";
	temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __csbutton_direct(" + this.id + ",\"CLICK\", 1)' ";
	temp+= "tabindex='1' ";
	temp+= "title='" + this.tooltip + "' ";

  temp+= ">";
  if(this.image2)
    temp+= "<img id='__image2" + this.id + "' title='" + this.tooltip2 + "' align='absmiddle' border='0' src='" +  this.image2 + "'>";
  temp+= "</td></tr></table></td>";

  //temp+= "<iframe unselectable='on' id='__cspopup" + this.id + "' src='popup/color.html?language=" + objToolbars.language + "&style=&bgcolor=" + objToolbars.backcolor + "' style='overflow:hidden;visibility:hidden;position:absolute;width:140px;height:128px' frameborder='0' scrolling='no'></iframe>";
	if(__toolbar_getPopupObject() == null) {
		iframe = document.createElement("iframe");
		iframe.id           = "__toolbar_popup";
		iframe.style.position = "absolute";
		iframe.style.visibility = "hidden";
		iframe.style.zIndex = 10000;
		iframe.frameBorder = 0;
		iframe.unselectable = "on";
		document.body.appendChild(iframe);
	}
	
  // add the id to the popup collection
  var count = __aAllPopups.length;
  __aAllPopups[count] = this;  //"__csbutton_popup_cancel()";

  return temp;
}

function __csbutton_visible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __csbutton_enable(value)
{
  this.enabled = value;
  var button = document.getElementById(this.id);
  if(value) {
    button.className = 'htmlButtonDisabled';
    button.innerHTML = "<span class='htmlButtonDisabledContainer'><span class='htmlButtonDisabledContainer'>" + button.innerHTML + "</span></span>";
  } else {
    button.className = 'htmlButtonStandard';
    button.innerHTML = button.firstChild.firstChild.innerHTML;
  }
}

function __csbutton_mouseup(part)
{
	try {
		if(part==0) {
			document.getElementById(this.id).className='htmlButtonHover';
			if(this.action != "") {
				var color = document.getElementById("__color" + this.id).style.backgroundColor;
				eval(this.action + "('" + this.id + "')");
			}
		}
	} catch(Error) {}
}

function __csbutton_mousedown(part)
{
  if(!this.enabled)
    return;

  if(part==0) {
    document.getElementById(this.id).className='htmlButtonActive';
  } else {
    if(!this.pressed) {
      __toolbars_reset();
      document.getElementById(this.id + "_1").className='htmlButtonPopup';
			var popup = __toolbar_getPopupObject();
			popup.style.width  = 140;
			popup.style.height = 134;
			var color = objToolbars.backcolor;
			// remove # because of Mozilla
			if(color.substring(0,1) == "#")
				color = color.substring(1,color.length);
		  popup.src = "/www/color.html?language=" + objToolbars.language + "&id=" + __toolbar_getIframe().id + "&bgcolor=" + color;
      popup.style.visibility = "visible";
      this.pressed = true;
    } else {
      __toolbars_reset();
      this.pressed = false;
    }
  }
}

function __csbutton_mouseover(part)
{
  if(!this.enabled)
    return;
  document.getElementById(this.id).className='htmlButtonHover';
  if(this.pressed)
    document.getElementById(this.id + "_1").className='htmlButtonPopup';
  else
    document.getElementById(this.id + "_1").className='htmlButtonHover';
}

function __csbutton_mouseout(part)
{
  if(!this.enabled)
    return;

  document.getElementById(this.id).className='htmlButtonStandard';
  if(this.pressed == false)
    document.getElementById(this.id + "_1").className='htmlButtonStandard';
  else
    document.getElementById(this.id + "_1").className='htmlButtonPopup';
}

// MDEARMAN 04-07-2004 - Added for keyboard accessibility
function __csbutton_focus(part)
{
	this.onmouseover(part);
}

function __csbutton_blur(part)
{
	this.onmouseout(part);
}

function __csbutton_click(part)
{
	this.onmousedown(part);
}
// MDEARMAN 04-07-2004 - End of keyboard accessibility functions


//-------------------------------------------------------------------------------------------------
// COLOR BUTTON
//-------------------------------------------------------------------------------------------------
function ColorButton(color,tooltip,tag)
{
  this.id      = "";
  this.color   = color;
  this.toolbar = null;
  this.tag     = tag;
  this.tooltip = tooltip;
  this.design  = "";
  this.pressed = false;
  this.enabled = true;
  this.visible = true;
  this.typeIntern = "COLORBUTTON";

  this.onmouseup    = __cbutton_mouseup;
  this.onmousedown  = __cbutton_mousedown;
  this.onmouseover  = __cbutton_mouseover;
  this.onmouseout   = __cbutton_mouseout;

  // MDEARMAN - 04-06-2004 - Added for keyboard accessibility
  this.onfocus  = __cbutton_focus;
  this.onblur   = __cbutton_blur;
  this.onclick  = __cbutton_click;

  this.create       = __cbutton_create;
  this.init         = __cbutton_init;
  this.setVisible   = __cbutton_visible;
}

function __cbutton_visible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id).style.display = "inline";
	else
	  document.getElementById(this.id).style.display = "none";
}

function __cbutton_init()
{
  if(document.getElementById("__tablepopup").style.visibility != "hidden") {
    document.getElementById("__tablepopup").style.visibility = "hidden";
    this.pressed = false;
    this.onmouseup();
  }
}

function __cbutton_direct(id,action)
{
	try {
		for (var j=0;j<__aAllComponents.length;j++) {
			if(__aAllComponents[j].id == id){
				var component = __aAllComponents[j];
				if(action == "OVER")
					component.onmouseover();
				else if(action == "OUT")
					component.onmouseout();
				else if(action == "DOWN")
					component.onmousedown();
				else if(action == "UP") {
					component.onmouseup();
					if(component.toolbar.action != "") {
						if(component.tag != "" && component.tag != null)
							eval( component.toolbar.action + "('" + component.id + "')");
					}
				}

				// MDEARMAN 04-06-2004 - Added for keyboard accessibility
				else if(action == "FOCUS")
					component.onfocus();
				else if(action == "BLUR")
					component.onblur();
				else if(action == "CLICK") {
					component.onclick();
						if(component.toolbar.action != "") {
							if(component.tag != "" && component.tag != null)
								eval( component.toolbar.action + "('" + component.id + "')");
						}
				}
				return;
			}
		}
	} catch(Error) {}
}

function __cbutton_popup_click(row,col)
{
	try {
		//__pbutton_popup_cancel();
		__pbutton_clicked.init();
		if(__pbutton_clicked.action != "") {
			eval(__pbutton_clicked.action + "(" + row + "," + col + ")");
		}
	} catch(Error) {}
}

function __cbutton_create()
{
  var temp = "<td nowrap id='" + this.id + "' ";
      temp+= "class='htmlButtonStandard' ";
      temp+= "onmouseover='__cbutton_direct(" + this.id + ",\"OVER\")'";
      temp+= "onmouseout='__cbutton_direct(" + this.id + ",\"OUT\")'";
      temp+= "onmousedown='__cbutton_direct(" + this.id + ",\"DOWN\")'";
      temp+= "onmouseup='__cbutton_direct(" + this.id + ",\"UP\")'";

			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			temp+= "onfocus='__cbutton_direct(" + this.id + ",\"FOCUS\")' ";
			temp+= "onblur='__cbutton_direct(" + this.id + ",\"BLUR\")' ";
			temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __cbutton_direct(" + this.id + ",\"CLICK\")' ";
			temp+= "tabindex='1' ";
			temp+= "title='" + this.tooltip + "' ";

      temp+= ">";

  temp+= "<div unselectable='on' style='height:11px;width:11px;font-family: Arial;font-size:3px;background-color:" + this.color + ";'></div>";
  temp+= "</td>";
  return temp;
}

function __cbutton_mouseup()
{
	try {
		if(!this.enabled)
			return;
		document.getElementById(this.id).className='htmlButtonHover';
		if(this.action != "") {
			eval(this.action);
		}
	} catch(Error) {}
}

function __cbutton_mousedown()
{
  __toolbars_reset();
  if(!this.enabled)
    return;
  document.getElementById(this.id).className='htmlButtonActive';
}

function __cbutton_mouseover()
{
  if(!this.enabled)
    return;
  document.getElementById(this.id).className='htmlButtonHover';
}

function __cbutton_mouseout()
{
  if(!this.enabled)
    return;
  if(this.pressed == false)
    document.getElementById(this.id).className='htmlButtonStandard';
  else
    document.getElementById(this.id).className='htmlButtonActive';
}

// MDEARMAN 04-07-2004 - Added for keyboard accessibility
function __cbutton_focus()
{
	this.onmouseover();
}

function __cbutton_blur()
{
	this.onmouseout();
}

function __cbutton_click()
{
	this.onmousedown();
}
// MDEARMAN 04-07-2004 - End of keyboard accessibility functions


//-----------------------------------------------------------------------------------------------------
// POPUP BUTTON
//-----------------------------------------------------------------------------------------------------
var __mbutton_clicked;

function PopupButton(text,image,action,tooltip,tag,page)
{
  this.id      = "";
	this.text    = text;
  this.popupwidth   = "150px";
  this.popupheight  = "90px";
  this.toolbar = null;
  this.action  = action;
  this.value   = "";
  this.page    = page;
  this.tag     = tag;
  this.image   = image;
  this.tooltip = tooltip;
  this.design  = "";
  this.pressed = false;
  this.enabled = true;
  this.visible = true;
  this.typeIntern = "POPUPBUTTON";

  this.setVisible   = __mbutton_visible;
  this.setEnabled   = __mbutton_enable;
  this.setStatus    = __mbutton_status;

  this.onmouseup    = __mbutton_mouseup;
  this.onmousedown  = __mbutton_mousedown;
  this.onmouseover  = __mbutton_mouseover;
  this.onmouseout   = __mbutton_mouseout;

  // MDEARMAN - 04-06-2004 - Added for keyboard accessibility
  this.onfocus  = __mbutton_focus;
  this.onblur   = __mbutton_blur;
  this.onclick  = __mbutton_click;

  this.create           = __mbutton_create;
  this.init             = __mbutton_init;
}

function __mbutton_init()
{
  try {
 		var popup = __toolbar_getPopupObject();
		if(popup.style.visibility != "hidden") {
				popup.style.visibility = "hidden";
		}
    document.getElementById(this.id).className='htmlButtonStandard';
    this.pressed = false;
  } catch(Error) {}
}

function __mbutton_direct(id,action)
{
  for (var j=0;j<__aAllComponents.length;j++) {
    if(__aAllComponents[j].id == id){
      var component = __aAllComponents[j];
      if(action == "OVER")
        component.onmouseover();
      if(action == "OUT")
        component.onmouseout();
      if(action == "DOWN") {
        // get the position
        var popup = __toolbar_getPopupObject();
        var obj = document.getElementById(id);
        var x = __toolbar_GetPositonX(obj) - 2;
        var y = __toolbar_GetPositonY(obj) + 1;
        popup.style.left = x;
        popup.style.top = y + obj.offsetHeight - 3;
        // save the current button
        __mbutton_clicked = component;
        component.onmousedown();
      }
      if(action == "UP") {
        component.onmouseup();
      }

 			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			else if(action == "FOCUS")
				component.onfocus();
			else if(action == "BLUR")
				component.onblur();
			else if(action == "CLICK") {
				if(!this.pressed) {
					// get the position
					var popup = __toolbar_getPopupObject();
					var obj = document.getElementById(id);
					var x = __toolbar_GetPositonX(obj);
					var y = __toolbar_GetPositonY(obj);
					popup.style.left = x;
					popup.style.top = y + obj.offsetHeight - 3;
					// save the current button
					__mbutton_clicked = component;
					component.onclick();
					this.pressed = true;
				}	else {
					__toolbars_reset();
				}
			}
			return;
    }
  }
}

function __mbutton_popup_click(tag)
{
	try {
		//__mbutton_popup_cancel();
		__mbutton_clicked.init();
		__mbutton_clicked.value = tag;
		if(__mbutton_clicked.action != "") {
			eval(__mbutton_clicked.action + "('" + __mbutton_clicked.id + "')");
		}
	} catch(Error) {}
}

function __mbutton_create()
{
  var temp = "<td id='" + this.id + "_v" + "'><table cellspacing=1 cellpadding=0 border=0><tr><td unselectable='ON' nowrap id='" + this.id + "' ";
      temp+= "class='htmlButtonStandard' ";
      temp+= "onmouseover='__mbutton_direct(" + this.id + ",\"OVER\")'";
      temp+= "onmouseout='__mbutton_direct(" + this.id + ",\"OUT\")'";
      temp+= "onmousedown='__mbutton_direct(" + this.id + ",\"DOWN\")'";
      temp+= "onmouseup='__mbutton_direct(" + this.id + ",\"UP\")'";

			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			temp+= "onfocus='__mbutton_direct(" + this.id + ",\"FOCUS\")' ";
			temp+= "onblur='__mbutton_direct(" + this.id + ",\"BLUR\")' ";
			temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __mbutton_direct(" + this.id + ",\"CLICK\")' ";
			temp+= "tabindex='1' ";
			temp+= "title='" + this.tooltip + "' ";

      temp+= ">";
  if(this.image)
    temp+= "<img  unselectable='ON' id='__image' title='" + this.tooltip + "' align='absmiddle' border='0' src='" +  this.image + "'>";
  if(this.text)
    temp+= " " + this.text;
  temp+= "</td></tr></table></td>";

  //temp+= "<iframe unselectable='on' id='__menupopup" + this.id + "' src='popup/" + this.menu + "?language=" + language + "&style=" + design + "&bgcolor=" + globalToolbarColor + "' style='overflow:hidden;visibility:hidden;position:absolute;left:10px;width:" + this.width + ";height:" + this.height + "' frameborder='0' scrolling='no'></iframe>";
	if(__toolbar_getPopupObject() == null) {
		iframe = document.createElement("iframe");
		iframe.id           = "__toolbar_popup";
		iframe.style.position = "absolute";
		iframe.style.visibility = "hidden";
		iframe.style.width = this.popupwidth;
		iframe.style.height = this.popupheight;
		iframe.style.zIndex = 10000;
		iframe.frameBorder = 0;
		iframe.unselectable = "on";
		document.body.appendChild(iframe);
	}

  // add the id to the popup collection
  var count = __aAllPopups.length;
  __aAllPopups[count] = this; //"__mbutton_popup_cancel()";
  return temp;
}

function __mbutton_visible(value)
{
  this.visible = value;

	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __mbutton_enable(value)
{
  this.enabled = value;
  var button = document.getElementById(this.id);
  if(value) {
    button.className = 'htmlButtonDisabled';
    button.innerHTML = "<span class='htmlButtonDisabledContainer'><span class='htmlButtonDisabledContainer'>" + button.innerHTML + "</span></span>";
  } else {
    button.className = 'htmlButtonStandard';
    button.innerHTML = button.firstChild.firstChild.innerHTML;
  }
}

function __mbutton_status(value)
{
  this.pressed = value;
  if(value) {
    document.getElementById(this.id).className='htmlButtonPopup';
  } else {
    document.getElementById(this.id).className='htmlButtonStandard';
  }
}

function __mbutton_mouseup()
{
  if(!this.enabled)
    return;
}

function __mbutton_mousedown()
{
  if(!this.enabled)
    return;

  if(!this.pressed) {
    document.getElementById(this.id).className='htmlButtonPopup';
		var popup = __toolbar_getPopupObject();
		popup.style.width = this.popupwidth;
		popup.style.height = this.popupheight;
		if(this.page != "")
			popup.src = this.page + "?language=" + objToolbars.language + "&style="  + "&id=" + __toolbar_getIframe().id + "&bgcolor=" + objToolbars.backcolor;
    popup.style.visibility = "visible";
    this.pressed = true;
  } else {
    __toolbars_reset();
    this.pressed = false;
  }
}

function __mbutton_mouseover()
{
  if(!this.enabled)
    return;

  if(this.pressed)
    document.getElementById(this.id).className='htmlButtonPopup';
  else
    document.getElementById(this.id).className='htmlButtonHover';
}

function __mbutton_mouseout()
{
  if(!this.enabled)
    return;

  if(this.pressed == false)
    document.getElementById(this.id).className='htmlButtonStandard';
  else
    document.getElementById(this.id).className='htmlButtonPopup';
}

// MDEARMAN 04-07-2004 - Added for keyboard accessibility
function __mbutton_focus()
{
	this.onmouseover();
}

function __mbutton_blur()
{
	this.onmouseout();
}

function __mbutton_click()
{
	this.onmousedown();
}


//--------------------------------------------------------------------------------------------------
// MENU Button
//--------------------------------------------------------------------------------------------------
var __mnbutton_clicked;
function MenuButton(text,image,image2,action,tooltip,tooltip2,tag)
{
  this.id      = "";
  this.toolbar = null;
  this.text    = text;
  this.action  = action;
  this.tag     = tag;
  this.image   = image;
  this.image2   = image2;
  this.tooltip = tooltip;
  this.tooltip2 = tooltip2;
  this.design  = "";
  this.pressed = false;
  this.enabled = true;
  this.visible = true;
  this.update  = true;
  this.typeIntern = "MENUBUTTON";

  // name of property like "tag1". This value is displayed as combo text
  this.displayValue = null;
  // all combo items
  this.aItems = new Array();
	// the selected item
  this.selectedIndex = 0;
  this.selectedItem = null;
  this.popupwidth = 150;

  // define new menu
  this.menu = new Menu("__mncombo_item_click");
  // no image col
  this.menu.imageColumn = true;
  // the callback from htmlMenu.html
  this.menu.callbackInternal = "__mnbutton_callback";
  //this.menu.callback = action;
  // is a popup
  this.menu.isPopupMode = true;

  this.setVisible   = __mnbutton_visible;
  this.setEnabled   = __mnbutton_enable;

  this.onmouseup    = __mnbutton_mouseup;
  this.onmousedown  = __mnbutton_mousedown;
  this.onmouseover  = __mnbutton_mouseover;
  this.onmouseout   = __mnbutton_mouseout;

  // MDEARMAN - 04-06-2004 - Added for keyboard accessibility
  this.onfocus  = __mnbutton_focus;
  this.onblur   = __mnbutton_blur;
  this.onclick  = __mnbutton_click;

  this.setSelected      = __mnbutton_setselected;
  this.setSelectedText  = __mnbutton_setselected_text;
  this.getSelected      = __mnbutton_getselected;
  this.getItemByValue   = __mnbutton_getbyvalue;
  this.add              = __mnbutton_add;
  this.create           = __mnbutton_create;
  this.init             = __mnbutton_init;
}

function __mnbutton_getbyvalue(value)
{
  for(var i=0; i<this.aItems.length;i++) {
    var item = this.aItems[i];
    if(item.value.toUpperCase() == value)
      return item;
  }
}

function __mnbutton_setselected_text(value)
{
  for(var i=0;i<this.aItems.length;i++) {
    var item = this.aItems[i];
    if(value == item.value) {
      this.setSelected(item);
      break;
    }
  }
}

function __mnbutton_getselected()
{
  return this.selectedItem;
}

function __mnbutton_setselected(item)
{
	try {
		var text = (this.displayValue != null) ? eval("item." + this.displayValue):item.text;
		if(this.update) {
			if(document.getElementById(this.id + "_text")) {
				// change only if text changed
				if(document.getElementById(this.id + "_text").innerHTML != text) {
					document.getElementById(this.id + "_text").innerHTML = text;
				}
			}
			document.getElementById(this.id + "_image").src = item.image;
		}
		this.selectedItem = item;
	} catch(Error) {}
}

function __mnbutton_add(item)
{
  var id = this.aItems.length;
  this.aItems[id] = item;
  item.id = __count;
  item.parent = this;
  __count++;
}

function __mnbutton_init()
{
  try {
		var popup = __toolbar_getPopupObject();
    if(popup.style.visibility != "hidden") {
      popup.style.visibility = "hidden";
    }
		document.getElementById(this.id).className='htmlButtonStandard';
		document.getElementById(this.id + "_1").className='htmlButtonStandard';
    this.pressed = false;
  } catch(Error) {}
}

function __mnbutton_callback(id)
{
	try {
		var item = __mnbutton_clicked.menu.getItemById(id);
		__mnbutton_clicked.setSelected(item);
		__mnbutton_clicked.init();
		if(__mnbutton_clicked.action != "") {
			//eval("parent." + __mnbutton_clicked.action + "(\"" + item.text + "\",\"" + item.value + "\",\"" + item.tag1 + "\",\"" + item.tag2 + "\")" );
			eval(__mnbutton_clicked.action + "(\"" + __mnbutton_clicked.id + "\")" );
		}
	} catch(error) {}
}

function __mnbutton_direct(id,action,part)
{
  for (var j=0;j<__aAllComponents.length;j++) {
    if(__aAllComponents[j].id == id){
      var component = __aAllComponents[j];
      if(action == "OVER")
        component.onmouseover(part);
      else if(action == "OUT")
        component.onmouseout(part);
      else if(action == "DOWN") {
        if(part==1) {
          // get the position
          var popup = __toolbar_getPopupObject(); //document.getElementById("__mnpopup" + id);
          var obj = document.getElementById(id);
          var x = __toolbar_GetPositonX(obj) - 2;
          var y = __toolbar_GetPositonY(obj);
          popup.style.left = x;
          popup.style.top = y + obj.offsetHeight;
          // save the current button
          __mnbutton_clicked = component;
        }
        component.onmousedown(part);
      }
      else if(action == "UP") {
        component.onmouseup(part);
      }
			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			else if(action == "FOCUS")
				component.onfocus(part);
			else if(action == "BLUR")
				component.onblur(part);
			else if(action == "CLICK") {
        if(part==1) {
          // get the position
          var popup = __toolbar_getPopupObject();
          var obj = document.getElementById(id);
          var x = __toolbar_GetPositonX(obj);
          var y = __toolbar_GetPositonY(obj);
          popup.style.left = x;
          popup.style.top = y + obj.offsetHeight;
          // save the current button
          __mnbutton_clicked = component;
        }
        component.onmousedown(part);
      }
      return;
    }
  }
}

function __mnbutton_create()
{
  var iframe = null;

  // set design because we don't have it after add
  this.menu.design = this.design;

  // set selection
  this.selectedItem = this.aItems[this.selectedIndex];
  
  var temp = "<td id='" + this.id + "_v" + "'><table cellspacing=1 cellpadding=0 border=0><tr><td nowrap id='" + this.id + "' ";
      temp+= "class='htmlButtonStandard' ";
      temp+= "onmouseover='__mnbutton_direct(" + this.id + ",\"OVER\",0)'";
      temp+= "onmouseout='__mnbutton_direct(" + this.id + ",\"OUT\",0)'";
      temp+= "onmousedown='__mnbutton_direct(" + this.id + ",\"DOWN\",0)'";
      temp+= "onmouseup='__mnbutton_direct(" + this.id + ",\"UP\",0)'";

			// MDEARMAN 04-06-2004 - Added for keyboard accessibility
			temp+= "onfocus='__mnbutton_direct(" + this.id + ",\"FOCUS\", 0)' ";
			temp+= "onblur='__mnbutton_direct(" + this.id + ",\"BLUR\", 0)' ";
			temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __mnbutton_direct(" + this.id + ",\"CLICK\", 0)' ";
			temp+= "tabindex='1' ";
			temp+= "title='" + this.tooltip + "' ";

      temp+= ">";
  if(this.update) {
    temp+= "<img id='" + this.id + "_image' title='" + this.tooltip + "' align='absmiddle' border='0' src='" +  this.selectedItem.image + "'>";
  } else if (this.image) {
    temp+= "<img id='" + this.id + "_image' title='" + this.tooltip + "' align='absmiddle' border='0' src='" +  this.image + "'>";
  }
  if(this.text)
    temp+= "<span style='margin-left: 2px' id='" + this.id + "_text' unselectable='on'> " + this.text + "</span>";
  temp+= "</td>";

  temp+= "<td nowrap id='" + this.id + "_1" + "' ";
  temp+= "class='htmlButtonStandard' ";
  temp+= "onmouseover='__mnbutton_direct(" + this.id + ",\"OVER\",1)'";
  temp+= "onmouseout='__mnbutton_direct(" + this.id + ",\"OUT\",1)'";
  temp+= "onmousedown='__mnbutton_direct(" + this.id + ",\"DOWN\",1)'";
  temp+= "onmouseup='__mnbutton_direct(" + this.id + ",\"UP\",1)'";

	// MDEARMAN 04-06-2004 - Added for keyboard accessibility
	temp+= "onfocus='__mnbutton_direct(" + this.id + ",\"FOCUS\", 1)' ";
	temp+= "onblur='__mnbutton_direct(" + this.id + ",\"BLUR\", 1)' ";
	temp+= "onkeypress='if (window.event.keyCode == 32 || window.event.keyCode == 13) __mnbutton_direct(" + this.id + ",\"CLICK\", 1)' ";
	temp+= "tabindex='1' ";
	temp+= "title='" + this.tooltip + "' ";

  temp+= ">";
  if(this.image2)
    temp+= "<img id='__image2" + this.id + "' title='" + this.tooltip2 + "' align='absmiddle' border='0' src='" +  this.image2 + "'>";
  temp+= "</td></tr></table></td>";

	if(__toolbar_getPopupObject() == null) {
		var iframe = document.createElement("iframe");
		iframe.id           = "__toolbar_popup";
		iframe.style.position = "absolute";
		iframe.style.visibility = "hidden";
		iframe.frameBorder = 0;
		iframe.unselectable = "on";
		iframe.style.zIndex = 10000;
		document.body.appendChild(iframe);
	}

  // define container
  this.menu.id = "__toolbar_popup"; //"__stylepopup" + this.id;
	
  // add the id to the popup collection
  var count = __aAllPopups.length;
  __aAllPopups[count] = this;  //"__mnbutton_popup_cancel()";

  return temp;
}

function __mnbutton_visible(value)
{
  this.visible = value;

	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __mnbutton_enable(value)
{
  this.enabled = value;
  var button = document.getElementById(this.id);
  if(value) {
    button.className = 'htmlButtonDisabled';
    button.innerHTML = "<span class='htmlButtonDisabledContainer'><span class='htmlButtonDisabledContainer'>" + button.innerHTML + "</span></span>";
  } else {
    button.className = 'htmlButtonStandard';
    button.innerHTML = button.firstChild.firstChild.innerHTML;
  }
}

function __mnbutton_mouseup(part)
{
	try {
		if(part==0) {
			document.getElementById(this.id).className='htmlButtonStandard';
			document.getElementById(this.id + "_1").className='htmlButtonStandard';
			if(this.action != "") {
				//eval("parent." + this.action + "(\"" + this.selectedItem.text + "\",\"" + this.selectedItem.value + "\",\"" + this.selectedItem.tag1 + "\",\"" + this.selectedItem.tag2 + "\")" );
				eval(this.action + "(\"" + this.id + "\")" );
			}
		}
	} catch(Error) {}
}

function __mnbutton_mousedown(part)
{
  if(!this.enabled)
    return;

  if(part==0) {
    document.getElementById(this.id).className='htmlButtonActive';
  } else {
    if(!this.pressed) {
			__toolbars_reset();
			// create menu
			this.menu.clear();
			for(i=0;i<this.aItems.length;i++) {
				var item = this.aItems[i];
				var url = __toolbar_getUrl();
				// the image path has to be adjusted
				var imagepath = item.image;
				this.menu.add(new MenuItem(item.text,imagepath,item.title,item.value,item.tag1,item.tag2));
			}
			document.getElementById(this.id).className='htmlComboPopup';
			//document.getElementById("__stylepopup" + this.id).style.visibility = "visible";
			
			var popup = __toolbar_getPopupObject();
			popup.style.width  = this.popupwidth;
			popup.style.border = "1px solid #002E96";

			// add content
			var doc = popup.contentWindow.document;
			doc.open();
			doc.write(__toolbar_getMenuCode());
			doc.close();
			// MenuFrame"

			// set the html content
			//var doc = document.getElementById("__stylepopup" + this.id).contentWindow.document;
			//var doc = popup.contentWindow.document;

			var html = this.menu.create(30);
			popup.style.height = this.menu.height;

			this.pressed = true;

			if(browser.ie) {
				doc.body.style.overflow = "auto";
				doc.body.innerHTML = html;
				popup.style.visibility = "visible";
			} else {
				__toolbar_temp_doc = doc;
				__toolbar_temp_html = html;
				__toolbar_temp_color = "white";
				setTimeout("__toolbar_delay_moz()",50);
			}

			//doc.body.style.backgroundColor = "white";
			// set the height if not greater than specified
    } else {
      __toolbars_reset();
    }
  }
}

var __toolbar_temp_doc;
var __toolbar_temp_html;
var __toolbar_temp_color = "";

function __toolbar_delay_moz()
{
	try {
		var temp = __toolbar_temp_doc.body;
	} catch(error) {
		setTimeout("__toolbar_delay_moz()",50);
		return;	
	}

	try {
		__toolbar_temp_doc.body.style.overflow = "auto";
		__toolbar_temp_doc.body.innerHTML = __toolbar_temp_html;
		if(__toolbar_temp_color != "") {
			__toolbar_temp_doc.body.style.backgroundColor = __toolbar_temp_color;
		}
		var popup = __toolbar_getPopupObject();
		popup.style.visibility = "visible";
	} catch(error) {}
}

function __mnbutton_mouseover(part)
{
  if(!this.enabled)
    return;
  document.getElementById(this.id).className='htmlButtonHover';
  if(this.pressed)
    document.getElementById(this.id + "_1").className='htmlButtonPopup';
  else
    document.getElementById(this.id + "_1").className='htmlButtonHover';
}

function __mnbutton_mouseout(part)
{
  if(!this.enabled)
    return;

  document.getElementById(this.id).className='htmlButtonStandard';
  if(this.pressed == false)
    document.getElementById(this.id + "_1").className='htmlButtonStandard';
  else
    document.getElementById(this.id + "_1").className='htmlButtonPopup';
}

// MDEARMAN 04-07-2004 - Added for keyboard accessibility
function __mnbutton_focus(part)
{
	this.onmouseover(part);
}

function __mnbutton_blur(part)
{
	this.onmouseout(part);
}

function __mnbutton_click(part)
{
	this.onmousedown(part);
}
// MDEARMAN 04-07-2004 - End of keyboard accessibility functions


//---------------------------------------------------------------------------------------------
// LABEL Object
//---------------------------------------------------------------------------------------------
function Label(text)
{
	this.id         = "";
	this.text       = text;
  this.tag = "";
  this.design     = "";
  this.visible    = true;
  this.typeIntern = "LABEL";
  
  this.create     = __label_create;
  this.setVisible = __label_setvisible;
  
}

function __label_create()
{
  var temp = "<td nowrap id='" + this.id + "_v" + "'><span id='" + this.id + "' class='htmlToolbarLabel'>" + this.text + "</span></td>";
  return temp;
}

function __label_setvisible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}


//---------------------------------------------------------------------------------------------
// Input Object
//---------------------------------------------------------------------------------------------
function Input(width, value, action, tag)
{
	this.id      = "";
	if(width)
		this.width   = width;
	else
		this.width   = "70";
	this.value     = value;
	this.action    = action;
	this.tag       = tag;
	this.readOnly  = false;
	this.maxlength = 100;
	this.password  = false;
  this.tooltip = "";
  this.design    = "";
  this.visible   = true;
  this.typeIntern = "INPUT";

  this.create  = __input_create;
  this.setVisible = __input_setvisible;
  this.getText = __input_gettext;
}

function __input_create()
{
	var ro = this.readOnly ? " READONLY " : "";
	var type = this.password ? "password" : "text";
	var action = this.action != "" ? this.action + "('" + this.id + "',event.keyCode)" : "";
	
  var temp = "<td id='" + this.id + "_v" + "'><input title='" + this.tooltip + "' tabindex='1' type='" + type + "' id='" + this.id + "' maxlength='" + this.maxlength + "' " + ro + "onmouseout=\"this.className='htmlToolbarInput'\" onmouseover=\"this.className='htmlToolbarInputHover'\" onkeyup=\"" + action + "\" class='htmlToolbarInput' style='width:" + this.width + ";' value='" + this.value + "'></td>";
  return temp;
}

function __input_setvisible(value)
{
  this.visible = value;
	if(value)
	  document.getElementById(this.id + "_v").style.display = "inline";
	else
	  document.getElementById(this.id + "_v").style.display = "none";
}

function __input_gettext()
{
	try {
		return document.getElementById(this.id).value;
	} catch(error) {}
}

//------------------------------------------------------------------------------
// GLOBAL functions
//------------------------------------------------------------------------------

function __toolbar_setmode(value)
{
  __isMode = value;
}



function __toolbar_GetPositonY(obj)
{
  var y = 0;
  var parent = obj;
  while(parent.tagName.toUpperCase() != "BODY") {
    if(parent.tagName.toUpperCase() != "TR") {
      y = y + parent.offsetTop;
    }
    parent = parent.parentNode;
  }
	y = y + parseInt(__toolbar_getIframePositionY());

  return y - 1;
}

function __toolbar_GetPositonX(obj)
{
  var x = 0;
  var parent = obj;
  while(parent.tagName.toUpperCase() != "BODY") {
    x = x + parent.offsetLeft;
    parent = parent.parentNode;
  }
	x = x + parseInt(__toolbar_getIframePositionX());

  return x - 2;
}

function __toolbar_getPopupObject()
{
  return document.getElementById("__toolbar_popup");
}

function __toolbar_getIframe()
{
	return window.frameElement;
}

function __toolbar_getIframePositionX()
{
	var iframe = __toolbar_getIframe();
	if(iframe.style.position.toUpperCase() == "ABSOLUTE") {
		return iframe.style.left;
	} else {
		var parent = iframe;
		var x = 0;
		while(parent.tagName.toUpperCase() != "BODY") {
//alert(parent.tagName)
//alert(parent.offsetLeft)

		  if(parent.tagName.toUpperCase() != "FORM") {
			  x = x + parent.offsetLeft;
			}
		  parent = parent.parentNode;
		}
		//return x - 4;
		return x;
	}
}

function __toolbar_getIframePositionY()
{
	var iframe = __toolbar_getIframe();
	if(iframe.style.position.toUpperCase() == "ABSOLUTE") {
		return iframe.style.top;
	} else {
		var parent = iframe;
		var y = 0;
		while(parent.tagName.toUpperCase() != "BODY") {
//alert(parent.tagName)
//alert(parent.offsetTop)

			if(parent.tagName.toUpperCase() != "TR" && parent.tagName.toUpperCase() != "FORM") {
				y = y + parent.offsetTop;
			}
			parent = parent.parentNode;
		}
//alert("IFRAME top: " + y);
		//return y - 2;
		return y;
	}
}

function __toolbar_getUrl()
{
	// determine path for CSS
	var url = parent.document.getElementById(__toolbar_getIframe().id).contentWindow.document.location.href;
	var idx = url.indexOf("/toolbar/");
	return url.substring(0,idx);
}

function __toolbar_getMenuCode()
{
	var temp = "";
	// add iframe content
	temp+= "<html>";
	temp+= "<head>";
	temp+= "<link rel='stylesheet' href='" + StylePath + "/Css/ToolBar/htmlMenu.css' type='text/css'>";
	temp+= 	unescape("%3Cscript%20language%3Djavascript%3E%0D%0A%0D%0Afunction%20onClick%28par%2Cid%2Cfunc%29%20%7B%0D%0A%09document.getElementById%28par%29.contentWindow.func%28id%29%3B%0D%0A%7D%0D%0A%0D%0Afunction%20onOver%28table%2Crow%2Cdesign%29%20%7B%0D%0A%09table.className%20%3D%20%27MenuItemHover%27%3B%0D%0A%09table.cellPadding%20%3D%201%3B%0D%0A%09document.getElementById%28row%20+%20%27.2%27%29.className%20%3D%20%27MenuItemHoverText%27%3B%0D%0A%7D%0D%0A%0D%0Afunction%20onOut%28table%2Crow%2Cdesign%29%20%7B%0D%0A%09table.className%20%3D%20%27MenuItem%27%3B%0D%0A%09table.cellPadding%20%3D%202%3B%0D%0A%09document.getElementById%28row%20+%20%27.2%27%29.className%20%20%3D%20%27MenuItemFont%27%3B%0D%0A%7D%0D%0A%3C/script%3E");
	temp+= "</head>";
	temp+= "<body style='margin:0;overflow:hidden'>";
	temp+= "</body>";
	return temp;
}

// called from popups
function toolbarPopupAction(mode, tag)
{
	if(mode == "POPUPBUTTON")
		__mbutton_popup_click(tag);
	if(mode == "COLORBUTTON")
		__csbutton_popup_click(tag);
}