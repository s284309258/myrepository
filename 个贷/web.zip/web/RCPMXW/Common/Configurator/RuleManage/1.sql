
CREATE TABLE RULE_ELEMENT(
    ElementID     VARCHAR2(40)     NOT NULL,
    ObjectID      VARCHAR2(40)     NOT NULL,
    ParentID      VARCHAR2(40),
    ObjectName    VARCHAR2(40),
    OrderNo       VARCHAR2(10),
    Image         VARCHAR2(40),
    Property      VARCHAR2(40),
    Describe      VARCHAR2(250),
    Status        VARCHAR2(1),
    CONSTRAINT PK1_1 PRIMARY KEY (ElementID)
)
;


CREATE TABLE RULE_OBJECT(
    ObjectID      VARCHAR2(40)     NOT NULL,
    ParentID      VARCHAR2(40),
    ObjectName    VARCHAR2(40),
    OrderNo       VARCHAR2(10),
    Image         VARCHAR2(40),
    Property      VARCHAR2(40),
    Describe      VARCHAR2(250),
    Status        VARCHAR2(1),
    CONSTRAINT PK1 PRIMARY KEY (ObjectID)
)
;



INSERT INTO RULE_OBJECT values ('Objects',null,'����','0010',null,null,null,'1');
INSERT INTO RULE_OBJECT values ('Methods',null,'����','0020',null,null,null,'1');
INSERT INTO RULE_OBJECT values ('Params',null,'��������','0030',null,null,null,'1');
INSERT INTO RULE_OBJECT values ('Customer','Objects','�ͻ�','0010','businessmen.png','Customer',null,'1');
INSERT INTO RULE_OBJECT values ('Apply','Objects','����','0020','form_blue.png','Apply',null,'1');
INSERT INTO RULE_OBJECT values ('Guaranty','Objects','����Ʒ','0030','houses.png','Guaranty',null,'1');
INSERT INTO RULE_OBJECT values ('User','Objects','�û�������','0040','id_cards.png','User',null,'1');
INSERT INTO RULE_OBJECT values ('PublicMethod','Methods','���÷���','0010','document_gear.png','PublicMethod',null,'1');
INSERT INTO RULE_OBJECT values ('CustomerMethod','Methods','�Զ��巽��','0020','document_add.png','CustomerMethod',null,'1');
INSERT INTO RULE_OBJECT values ('PublicParam','Params','ȫ�ֱ���','0010','book_green.png','PublicParam',null,'1');
INSERT INTO RULE_OBJECT values ('ProtectParam','Params','�ֲ�����','0020','book_red.png','ProtectParam',null,'1');
INSERT INTO RULE_OBJECT values ('Constant','Params','����','0030','book_yellow.png','Constant',null,'1');


INSERT INTO RULE_ELEMENT values ('CustomerMan','Customer',null,'����˱���','0010',null,'CustomerMan',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerFamily','Customer',null,'��ͥ���','0020',null,'CustomerFamily',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerAge','Customer','CustomerMan','����','0010',null,'CustomerAge','20-60����ľ�����ȫ�����������й����񼰸۰�̨����','1');
INSERT INTO RULE_ELEMENT values ('CustomerBuy','Customer','CustomerMan','�Ƿ��˹���','0020',null,'CustomerBuy',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerWork','Customer','CustomerMan','��������','0030',null,'CustomerWork',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerIncome','Customer','CustomerFamily','��ͥ������','0010',null,'CustomerIncome',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerMoney','Customer','CustomerFamily','�Գ��ʽ�','0020',null,'CustomerMoney',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerLoanCount','Customer','CustomerFamily','�Ѵ������','0030',null,'CustomerLoanCount',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerCareer','Customer','CustomerFamily','������ҵ','0040',null,'CustomerCareer',null,'1');
INSERT INTO RULE_ELEMENT values ('CustomerFamilyCount','Customer','CustomerFamily','��ͥ��Ա','0050',null,'CustomerFamilyCount',null,'1');